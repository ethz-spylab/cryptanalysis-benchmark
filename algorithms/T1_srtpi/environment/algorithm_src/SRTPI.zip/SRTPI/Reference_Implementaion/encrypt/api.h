#ifndef api_h
#define api_h

#define CRYPTO_SECRETKEYBYTES 2100736
#define CRYPTO_PUBLICKEYBYTES 268288
#define CRYPTO_BYTES 488

#define CRYPTO_ALGNAME "SRTP"

int crypto_encrypt_keypair(
	unsigned char *pk,
	unsigned char *sk
);
int crypto_encrypt(
	unsigned char *c, unsigned long long *clen,
	const unsigned char *m, unsigned long long mlen,
	const unsigned char *pk
);
int crypto_encrypt_open(
	unsigned char *m, unsigned long long *mlen,
	const unsigned char *c, unsigned long long clen,
	const unsigned char *sk
);
//more information 
#define CRYPTO_RANDOMBYTES 40
#define CRYPTO_MESSAGEBYTES 24
#define CRYPTO_VERSION "1.0"
#endif /* api_h */ 