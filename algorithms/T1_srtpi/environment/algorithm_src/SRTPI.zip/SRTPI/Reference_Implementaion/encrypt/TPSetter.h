#include"F2.h"

/*https://en.wikipedia.org/wiki/Moore%E2%80%93Penrose_inverse
the wiki page of pseudo inverse(Moore–Penrose inverse)
tr=transpose(c1),cplus=tr((c1*tr)^-1) you can see in the book in a clearer way*/
//input: uninitialized matrix c and cplus, t the size of t in the TP system
//inplace output:random matrix c, and cplus the pseudo inverse of c
void setCandCPseudoInverse(matrix* c, matrix*cplus, const unsigned int t) {
	int n = 4 * t, m = 3 * t, i, j;
	matrix c1, in, tr, mu;
	int tries = 0;
	Set(&c1, m, n);
	Set(c, n, n);
	while (1)
	{
		pureRandomFill(&c1);
		tr = transpose(&c1);
		mu = Mult(&c1, &tr);
		in = inverse(&mu);
		if (in.row != 0)break;
		Delete(&tr);
		Delete(&mu);
	}
	//set c
	memcpy(c->matrix, c1.matrix, n*m / 8);

	Delete(&mu);
	mu = Mult(&tr, &in);
	Delete(&c1);
	Delete(&tr);

	Delete(&in);
	//set cplus
	Set(cplus, n, n);
	for (i = 0; i < cplus->row; i++)
	{
		for (j = 0; j < cplus->column; j++)
		{
			if (j < m / 8)
				cplus->matrix[i*cplus->column + j] = mu.matrix[i*mu.column + j];
		}
	}
	Delete(&mu);
}

//input:matrix M without values in m13,the t of the TP system, L12 L13 L23 the blocks from matrix L
//inplace output:matrix M with values in m13 (m13=m12*l23+l12*l23+l13)
void setM13(matrix* M, int t, const matrix* L12, const matrix* L13, const matrix* L23) {
	matrix ML, LL, add, M12, M13;
	Set(&M12, t, 2 * t);
	int i;
	for (i = 0; i < M12.row; i++)
		memcpy(M12.matrix + i*M12.column, M->matrix + i*M->column + t / 8, M12.column);
	ML = Mult(&M12, L23);
	LL = Mult(L12, L23);
	add = Add(&LL, L13);
	M13 = Add(&add, &ML);
	for (i = 0; i < M13.row; i++)
		memcpy(M->matrix + i*M->column + 3 * t / 8, M13.matrix + i*M13.column, M13.column);
	Delete(&M12);
	Delete(&M13);
	Delete(&ML);
	Delete(&LL);
	Delete(&add);
}

//input:uninitialized matrix Q,matrix PR PL X(X0) C U CPlus of th TP system
//pi the permotion of the system, L12 L13 L23 the blocks of L, t of the TP system
//inplace output:initialized matrix Q with values
void setQ(matrix*Q, const matrix*PR, const matrix*PL, const matrix*X, const matrix*C,
			const matrix*U, const matrix*CPlus, const unsigned short*  pi, const matrix*L12,
			const matrix*L13, const matrix*L23, const unsigned int t) {
	unsigned int n = 4 * t;
	int t3 = 3 * t, i;
	matrix M, identity, CCPlus, CPlusC, IMinusCplus, IMinusC, multl, URoof, PRI, PRIT, PRkPL, XPlusU, qj, MPlusURoof, Vec, CPlusM, tempvec, qLast, Qt;
	//set M
	Set(&M, n, n);

	unsigned char eight = 0;
	for (i = 0; i < t; i++, eight += (i % 8) ? 0 : 1)
	{
		M.matrix[i*M.column + eight] = 1 << (7 - i % 8);//identity block
		memcpy(M.matrix + i*M.column + t*M.column + (t * 3) / 8, L23->matrix + i*L23->column, L23->column);//L23 block first middle
		memcpy(M.matrix + i*M.column + 2 * t*M.column + (t * 3) / 8, L23->matrix + i*L23->column + t*L23->column, L23->column);//L23 block second middle
		M.matrix[i*M.column + t*M.column + t / 8 + eight] = 1 << (7 - i % 8);//identity block first middle
		M.matrix[i*M.column + 2 * t*M.column + t / 8 + eight + 2] = 1 << (7 - i % 8);
	}

	//set U
	identity = identityMatrix(n);
	CCPlus = Mult(C, CPlus);
	CPlusC = Mult(CPlus, C);
	IMinusCplus = Add(&identity, &CPlusC);
	IMinusC = Add(&identity, &CCPlus);
	multl = Mult(&IMinusCplus, U);
	URoof = Mult(&multl, &IMinusC);
	Delete(&identity);
	Delete(&CCPlus);
	Delete(&CPlusC);
	Delete(&IMinusCplus);
	Delete(&IMinusC);
	Delete(&multl);
	//set kruniker mult
	PRI = inverse(PR);
	PRIT = transpose(&PRI);
	PRkPL = KroneckerMult(&PRIT, PL);
	Delete(&PRI);
	Delete(&PRIT);

	//set X0+URoof
	XPlusU = Add(X, &URoof);
	Delete(&URoof);
	//set Q

	int size = 2 * t*t + 8;
	int nn = n*n;
	Set(Q, size, nn);

	int loc = -1;
	unsigned short r, c, j, s;

	//set qLast
	setM13(&M, t, L12, L13, L23);
	CPlusM = Mult(CPlus, &M);
	MPlusURoof = Add(&XPlusU, &CPlusM);
	Vec = vec(&MPlusURoof);
	qLast = MatrixVectorMult(&PRkPL, &Vec);
	memcpy(Q->matrix + (size - 8)*Q->column, qLast.matrix, qLast.column);
	Delete(&Vec);
	Delete(&MPlusURoof);
	Delete(&CPlusM);
	//set the rest of the qj
	for (s = 0; s < size - 8; s++)
	{
		j = pi[s];
		r = j / (2 * t);
		c = j - 2 * t*r;
		M.matrix[t / 8 + r* M.column + c / 8] = 1 << (7 - (c) % 8);
		setM13(&M, t, L12, L13, L23);
		CPlusM = Mult(CPlus, &M);
		MPlusURoof = Add(&XPlusU, &CPlusM);
		Vec = vec(&MPlusURoof);
		tempvec = MatrixVectorMult(&PRkPL, &Vec);
		qj = Add(&tempvec, &qLast);
		Delete(&Vec);
		Delete(&MPlusURoof);
		Delete(&CPlusM);
		Delete(&tempvec);
		M.matrix[t / 8 + r* M.column + c / 8] = 0;
		memcpy(Q->matrix + s*Q->column, qj.matrix, qj.column);
		Delete(&qj);
	}
	Delete(&qLast);
	Delete(&M);
	Delete(&XPlusU);
	Delete(&PRkPL);

	Qt = transpose(Q);
	Delete(Q);
	*Q = Qt;
}

//input:uninitialized matrix L, L12 L13 L23 the parts of L
//inplace output:initialized matrix L
void setL(matrix*L, int t, const matrix*L12, const matrix*L13, const matrix*L23) {
	int n = 4 * t, i, t3 = 3 * t;
	Set(L, n, n);
	matrix id = identityMatrix(2 * t);
	for (i = 0; i < t; i++)
	{
		memcpy(L->matrix + i*L->column, id.matrix + i*id.column, id.column);//i block
		memcpy(L->matrix + i*L->column + t / 8, L12->matrix + i*L12->column, L12->column);//L12 block
		memcpy(L->matrix + i*L->column + (t / 8) * 3, L13->matrix + i*L13->column, L13->column);//L13 block
		memcpy(L->matrix + i*L->column + (t / 8) + t*L->column, id.matrix + i*id.column, id.column);//i2 block first middle
		memcpy(L->matrix + i*L->column + (t / 8) + 2 * t*L->column, id.matrix + i*id.column + t*id.column, id.column);//i2 block second middle
		memcpy(L->matrix + i*L->column + (t / 8) * 3 + t*L->column, L23->matrix + i*L23->column, L23->column);//L23 block first middle
		memcpy(L->matrix + i*L->column + (t / 8) * 3 + 2 * t*L->column, L23->matrix + i*L23->column + t*L23->column, L23->column);//L23 block first middle
	}
	Delete(&id);
}

//input:matrix X, and A B C D the matrixes of the Riccati operator
//output:Riccati operator of X ( R(X)=XCX+XD+AX+B (in this field add and sub are the same))
matrix RX(matrix* X, matrix* A, matrix* B, matrix* C, matrix* D) {
	matrix YW, XC, XCX, XD, AX, Add1, Minus1;
	XC = Mult(X, C);
	XCX = Mult(&XC, X);
	Delete(&XC);
	XD = Mult(X, D);
	AX = Mult(A, X);
	Add1 = Add(&XCX, &XD);
	Minus1 = Add(&Add1, &AX);
	Delete(&Add1);
	YW = Add(&Minus1, B);
	Delete(&XCX);
	Delete(&XD);
	Delete(&AX);
	Delete(&Minus1);
	return YW;
}

//fast and stable algoritem that dont inverse gama directaly but choose such gama that we can inverse by its parts, more explanations how it works in the book 
//input:uninitialized gamai, A B X0 C  Cplus t of the TP system
//inplace output:initialized gamai, the inverse of gama( because we dont need gama itself) 
void setGAX0D(matrix* Gamai, matrix*A, matrix*X0, matrix*D, const matrix*C, const matrix*Cplus, int t){
	int n = 4 * t;

	matrix D22, D21, G11, H, G, Hi;
	Set(&D22, n / 2, n / 2);
	Set(&D21, n / 2, n / 2);
	pureRandomFill(&D21);
	//set D22
	int i8, i, j;
	unsigned char a = 0xff, ran=0;
	for (i = 0; i < n / 2; i++)
	{
		i8 = i / 8;
		randombytes(&ran, 1);
		D22.matrix[i*D22.column + i8] = (((a) << (8 - i % 8))&ran);

		randombytes(D22.matrix + i*D22.column, i8);
	}
	//set G11
	Set(&G11, n / 2, n / 2);
	for (i = 0; i < n / 2; i++)
	{
		i8 = i / 8;
		randombytes(&ran, 1);
		G11.matrix[i*G11.column + i8] = (((a) << (8 - i % 8))&ran);

		randombytes(G11.matrix + i*G11.column, i8);
	}
	//set H
	LURandomfill(&H, &Hi, n);
	//set D
	Set(D, n, n);
	D->row /= 2;
	pureRandomFill(D);
	D->row *= 2;

	for (i = 0; i < n / 2; i++)
	{
		memcpy(D->matrix + n / 2 * D->column + i*D->column, D21.matrix + i*D21.column, D21.column);
		memcpy(D->matrix + n / 2 * D->column + D->column / 2 + i*D->column, D22.matrix + i*D22.column, D22.column);
	}
	//set G
	Set(&G, n, n);
	for (i = 0; i < n / 2; i++)
	{
		memcpy(G.matrix + i*G.column, G11.matrix + i*G11.column, G11.column);
		memcpy(G.matrix + n / 2 * G.column + i*G.column, D21.matrix + i*D21.column, D21.column);
		memcpy(G.matrix + n / 2 * G.column + G.column / 2 + i*G.column, D22.matrix + i*D22.column, D22.column);
	}
	Delete(&D21);
	Delete(&D22);
	Delete(&G11);
	//set A
	matrix GD, mult1, mult2;
	GD = Add(&G, D);
	mult1 = Mult(Cplus, &GD);
	mult2 = Mult(&mult1, C);
	*A = Add(&H, &mult2);
	Delete(&mult1);
	Delete(&mult2);
	//set X0
	matrix add, Y0, I;
	Set(&Y0, n, n);
	pureRandomFill(&Y0);
	I = identityMatrix(n);
	mult1 = Mult(Cplus, C);
	add = Add(&I, &mult1);
	Delete(&mult1);
	mult2 = Mult(&add, &Y0);
	Delete(&add);
	mult1 = Mult(C, Cplus);
	add = Add(&I, &mult1);
	Delete(&mult1);
	mult1 = Mult(&mult2, &add);
	Delete(&mult2);
	mult2 = Mult(Cplus, &GD);
	*X0 = Add(&mult2, &mult1);
	Delete(&mult1);
	Delete(&mult2);
	Delete(&GD);
	Delete(&add);
	Delete(&Y0);
	//set gamai
	matrix temp, paw, Gt, pawa, pawb;

	Gt = transpose(&G);
	pawa = identityMatrix(n);
	Set(&pawb, n, n);
	memcpy(pawb.matrix, Hi.matrix, n*n / 8);

	Delete(&G);
	Delete(&H);
	*Gamai = KroneckerMult(&I, &Hi);
	for (i = 1; i < n; i++)
	{


		temp = Mult(&pawa, &Gt);
		Delete(&pawa);
		pawa.matrix = temp.matrix;

		temp = Mult(&pawb, &Hi);
		Delete(&pawb);
		pawb.matrix = temp.matrix;

		paw = KroneckerMult(&pawa, &pawb);

		temp = Add(Gamai, &paw);
		Delete(Gamai);
		Gamai->matrix = temp.matrix;
		Delete(&paw);
	}
	Delete(&Hi);
	Delete(&Gt);
	Delete(&I);
	Delete(&pawa);
	Delete(&pawb);

}