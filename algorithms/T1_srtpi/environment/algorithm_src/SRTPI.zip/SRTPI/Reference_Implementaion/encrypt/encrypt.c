#include"TPSetter.h"
#define t 16


int crypto_encrypt_keypair(
	unsigned char *pk,
	unsigned char *sk
)
//sk=C+Z0+PLi+PR+RX0+pi+Gamai
//pk=AW+BW+CW+DW+Q
//step by step like in the book
{

	int  n = 4 * t, m = 3 * t;
	matrix A, B, C, D, Cplus, Gamai, L, L12, L13, L23, X0, Z0, U0, PR, PL;

	//sk
	Set(&B, n, n);
	pureRandomFill(&B);

	setCandCPseudoInverse(&C, &Cplus, t);

	memcpy(sk, C.matrix, 512);

	setGAX0D(&Gamai, &A, &X0, &D, &C, &Cplus, t);

	Set(&L12, t, 2 * t);
	pureRandomFill(&L12);

	Set(&L13, t, t);
	pureRandomFill(&L13);

	Set(&L23, 2 * t, t);
	pureRandomFill(&L23);

	setL(&L, t, &L12, &L13, &L23);

	matrix temp1, temp2;
	temp1 = Mult(&C, &Cplus);
	temp2 = Mult(&temp1, &L);
	Delete(&temp1);
	Delete(&L);
	temp1 = Mult(&temp2, &temp2);
	Delete(&temp2);
	Z0 = Mult(&Cplus, &temp1);

	memcpy(sk + 512, Z0.matrix, 512);


	Delete(&temp1);
	Set(&U0, n, n);
	pureRandomFill(&U0);

	matrix PLi, PRi;
	LURandomfill(&PL, &PLi, n);
	LURandomfill(&PR, &PRi, n);

	memcpy(sk + 1024, PLi.matrix, 512);

	memcpy(sk + 1536, PR.matrix, 512);

	matrix RX0 = RX(&X0, &A, &B, &C, &D);
	memcpy(sk + 2048, RX0.matrix, 512);

	Delete(&RX0);

	unsigned short*pi = randomPermotion(t);

	memcpy(sk + 2560, pi, 1024);

	memcpy(sk + 3584, Gamai.matrix, 2097152);

	Delete(&Gamai);
	//pk

	matrix AW, BW, CW, DW, Q;

	temp1 = Mult(&PL, &A);
	AW = Mult(&temp1, &PLi);
	Delete(&temp1);
	memcpy(pk, AW.matrix, 512);

	temp1 = Mult(&PL, &B);
	BW = Mult(&temp1, &PRi);
	Delete(&temp1);
	memcpy(pk + 512, BW.matrix, 512);

	temp1 = Mult(&PR, &C);
	CW = Mult(&temp1, &PLi);
	Delete(&temp1);
	memcpy(pk + 1024, CW.matrix, 512);

	temp1 = Mult(&PR, &D);
	DW = Mult(&temp1, &PRi);
	Delete(&temp1);
	memcpy(pk + 1536, DW.matrix, 512);


	setQ(&Q, &PR, &PL, &X0, &C, &U0, &Cplus, pi, &L12, &L13, &L23, t);
	memcpy(pk + 2048, Q.matrix, 266240);

	Delete(&A);
	Delete(&B);
	Delete(&C);
	Delete(&D);
	Delete(&Cplus);

	Delete(&L12);
	Delete(&L13);
	Delete(&L23);
	Delete(&X0);
	Delete(&Z0);
	Delete(&U0);
	Delete(&PR);
	Delete(&PL);
	free(pi);
	Delete(&AW);
	Delete(&BW);
	Delete(&CW);
	Delete(&DW);
	Delete(&Q);
	Delete(&PLi);
	Delete(&PRi);
	return 0;
}

int crypto_encrypt(
	unsigned char *c, unsigned long long *clen,
	const unsigned char *m, unsigned long long mlen,
	const unsigned char *pk
)
//message of size 24 byte and the output is a encrypt  message of the size 512 so the overhead is 488
{
	if (mlen !=24)
	{
		//wrong size for encryption
		return -1;
	}
	*clen = 512;
	matrix V, X, Q, QV, YW, AW, BW, CW, DW;
	int n = 4 * t;
	Set(&V, 1, 520);

	//public key to matrixes
	Set(&AW, n, n);
	memcpy(AW.matrix, pk, 512);
	Set(&BW, n, n);
	memcpy(BW.matrix, pk + 512, 512);
	Set(&CW, n, n);
	memcpy(CW.matrix, pk + 1024, 512);
	Set(&DW, n, n);
	memcpy(DW.matrix, pk + 1536, 512);
	Set(&Q, 4096, 520);
	memcpy(Q.matrix, pk + 2048, 266240);
	//message byts
	memcpy(V.matrix, m, 24);
	//random byts
	randombytes(V.matrix + 24, 40);

	V.matrix[V.column - 1] = 0x80;
	QV = MatrixVectorMult(&Q, &V);
	X = mat(&QV, n, n);

	YW = RX(&X, &AW, &BW, &CW, &DW);
	memcpy(c, YW.matrix, n*n / 8);

	Delete(&X);
	Delete(&QV);
	Delete(&YW);
	Delete(&V);
	Delete(&Q);
	Delete(&AW);
	Delete(&BW);
	Delete(&CW);
	Delete(&DW);
	return 0;
}

int crypto_encrypt_open(
	unsigned char *m, unsigned long long *mlen,
	const unsigned char *c, unsigned long long clen,
	const unsigned char *sk
)
{
	if (clen !=512)
	{
		//wrong size for encryption
		return -1;
	}
	int n = 4 * t;
	unsigned short i, s, r, co;
	*mlen = 24;
	unsigned short*pi;
	unsigned char *m12bit, *messbit, *mess;
	matrix YW, C, Gamai, Z0, PLi, PR, RX0;
	matrix PLY, Y, Minus1, W, Vec, GamaiW, V, M, m12;
	Set(&YW, n, n);

	Set(&C, n, n);
	memcpy(C.matrix, sk, 512);

	Set(&Z0, n, n);
	memcpy(Z0.matrix, sk + 512, 512);

	Set(&PLi, n, n);
	memcpy(PLi.matrix, sk + 1024, 512);

	Set(&PR, n, n);
	memcpy(PR.matrix, sk + 1536, 512);

	Set(&RX0, n, n);
	memcpy(RX0.matrix, sk + 2048, 512);

	pi = malloc(2 * t*t * sizeof(short));
	memcpy(pi, sk + 2560, 1024);

	Set(&Gamai, 4096, 4096);
	memcpy(Gamai.matrix, sk + 3584, 2097152);

	Set(&m12, t, 32);
	messbit = malloc(192);

	memcpy(YW.matrix, c, 512);
	PLY = Mult(&PLi, &YW);
	Y = Mult(&PLY, &PR);
	Minus1 = Add(&Y, &RX0);
	W = Add(&Minus1, &Z0);
	Vec = vec(&W);
	GamaiW = MatrixVectorMult(&Gamai, &Vec);
	V = mat(&GamaiW, n, n);
	M = Mult(&C, &V);
	for (i = 0; i < t; i++)
		memcpy(m12.matrix + i*m12.column, M.matrix + i*M.column + 2, m12.column);

	m12bit = charToBitArray(m12.matrix, 64);
	for (i = 0; i < 192; i++)
	{
		s = pi[i];
		r = s / (2 * t);
		co = s - 2 * t*r;
		messbit[i] = m12bit[r * 32 + co];
	}
	mess = BitArrayTochar(messbit, 24);
	memcpy(m, mess, 24);

	Delete(&PLY);
	Delete(&Y);
	Delete(&Minus1);
	Delete(&W);
	Delete(&Vec);
	Delete(&GamaiW);
	Delete(&V);
	Delete(&M);
	free(pi);
	free(m12bit);
	free(messbit);
	free(mess);
	Delete(&m12);
	Delete(&YW);
	Delete(&C);
	Delete(&Gamai);
	Delete(&Z0);
	Delete(&PLi);
	Delete(&PR);
	Delete(&RX0);
	return 0;
}