//this file contains matrix function over F2(Galois field 2) , such as add, mult, inverse, etc`... 
#pragma once
#include"rng.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//for each byte states false if the number of 1 in the byte is parity and true otherwise
//we will use this later in the mult, you will see why   
unsigned char parity[] = { 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00, 0x01, 0x00, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0x00 };
//unsigned char paritybit(unsigned char a) {
//	unsigned	char s = 0;
//	for (int i = 0; i < 8; i++)
//	{
//		s ^= (unsigned char)(((unsigned char)(a << i)) >> 7);
//	}
//	return s;
//}

typedef struct {
	unsigned int column;//column the matrix have in the progrem
	unsigned int acolumn;//column the matrix have over the filed
						//each column is 8 acolumn over the filed because each var is a bit)
	unsigned int row;//rows the matrix have
	unsigned char* matrix;//the matrix itself
}matrix;

//input:uninitialized in memory matrix m
//inplace output:initialized in memory matrix m
void Allocation(matrix* m) {
	m->matrix = malloc(m->row*m->column + 1);//aloocate the data for the whole matrix
	memset(m->matrix, 0, m->row*m->column);//set all the data to zero
}

//input:initialized matrix m
//inplace output:uninitialized matrix m
void Delete(matrix* m) {
	free(m->matrix);//free the data
					//m->matrix = NULL;
}

//input:uninitialized matrix m 
//inplace output:initialized matrix m
void Set(matrix* m, const unsigned int r, const unsigned int c) {
	m->row = r;
	m->acolumn = c; //how many columns are over the field
	m->column = c / 8; //how many columns are saved by the computer
	Allocation(m);
}

matrix INVALIDMAT;//for each invalid operation, i will return this invalid matrix 

//input: initialized matrix m
//inplace output:matrix m with random values
void pureRandomFill(matrix* m){// fiiling the matrix with random byts(bits)

	randombytes(m->matrix, m->row*m->column);
	//for (int i = 0; i < m->row*m->column; i++)
	//m->matrix[i] = rand() % 256;
}



//aritmetics

//input:matrix a 
//output:transpose(a)
//taken from http://www.hackersdelight.org/hdcodetxt/transpose8.c.txt
matrix transpose(const matrix* a) {
	matrix T;
	Set(&T, a->acolumn, a->row);
	unsigned char *pa, *pt;
	unsigned long long x, t;
	int i, r, c;
	for (r = 0; r < T.column; r++)
	{
		for (c = 0; c < a->column; c++)
		{
			pa = a->matrix + a->column*r * 8 + c;//takes the first 8 rows from the first column, the from the second column, and each column represent 8 actual columns
			for (i = 0; i <= 7; i++) {    // Load 8 bytes from the
				x = x << 8 | *(pa); // input array and pack
				pa += a->column; // them into x.
			}

			t = (x ^ (x >> 7)) & 0x00AA00AA00AA00AALL;
			x = x ^ t ^ (t << 7);
			t = (x ^ (x >> 14)) & 0x0000CCCC0000CCCCLL;
			x = x ^ t ^ (t << 14);
			t = (x ^ (x >> 28)) & 0x00000000F0F0F0F0LL;
			x = x ^ t ^ (t << 28);
			pt = T.matrix + T.column*(c * 8 + 7) + r;
			for (i = 7; i >= 0; i--) {   // Store result into
				*pt = x;// output array B.
				pt -= T.column;
				x = x >> 8;
			}
		}
	}

	return T;
}

//input:number of rows for the identity matrix
//output:identity matrix with rank rows
matrix identityMatrix(const int rank) {
	matrix i;
	Set(&i, rank, rank);
	int k, j;
	unsigned char *pi = i.matrix;
	for (k = 0; k < i.column; k++)
	{
		for (j = 0; j < 8; j++)
		{
			*(pi) = 1 << (7 - j);//the MSB(most signifigent bit) is the first column
			pi += i.column;
		}
		pi++;
	}
	return i;

}

//input:matrix a
//output:vec(a),the first value of the vector will be the first row first acolumn,
//the second will be second row first acolumn an so on, and the values will be organized in one row that will be the vector
//turns matrix a into vector v
matrix vec(const matrix* a) {
	int size = a->column*a->row;
	int i, j;
	matrix v;
	v = transpose(a);
	v.row = 1;
	v.column = size;
	v.acolumn = size * 8;
	return v;
}
	
//input:v vector matrix(1 row),r number of rows for the output matrix,c number of columns for the output matrix
//output:mat(v)
//turns vector v into matrix a
matrix mat(matrix* v, const int r, const int c){

	matrix a;
	v->row = c;
	v->column = r / 8;
	v->acolumn = r;
	a = transpose(v);//in this implementation every matrix is a row vector and the you know when the next actual row is by the column value
	return a;
}

//input:matrix a,matrix b
//output:a+b if possible, INVALIDMAT otherwise 
matrix Add(const matrix* a, const matrix* b) {
	if (a->row != b->row || a->column != b->column)return INVALIDMAT;
	matrix c;
	int i;
	unsigned char *pc, *pa, *pb;
	Set(&c, a->row, a->acolumn);
	pc = c.matrix;
	pa = a->matrix;
	pb = b->matrix;
	for (i = 0; i < a->row*a->column; i++)
		*(pc++) = *(pa++) ^ *(pb++);//xor
	return c;
}

//input:matrix a,matrix b
//output:a*b if possible, INVALIDMAT otherwise 
matrix Mult(const matrix* a, const matrix* b) {
	if(a->acolumn!=b->row)return INVALIDMAT;
	matrix c;
	Set(&c, a->row, b->acolumn);
	matrix bt;
	int i, h, j, k;
	bt = transpose(b);//now we can access each acutle column of b by the proper row of it 
	unsigned char *pc, *pb, *pa;
	pa = a->matrix;
	pb = bt.matrix;
	pc = c.matrix;
	
	unsigned char sum = 0;//a value wich represents one bit in the current byte in c
	char curr = 0;
	for (i = 0; i < a->row; i++)
	{
		for (h = 0; h < b->column; h++)//bt->row/8
		{
			for (j = 0; j < 8; j++)
			{
				for (k = 0; k < bt.column; k++)
				{
					sum ^= *(pa++)&*(pb++);//mult the 8 elements and adding them to the total sum each time
				}
				curr ^= ((parity[sum]) << (7 - j));// now we have a byte in sum and we need to add all the bits in him so we do it by the parity array
				sum = 0;
				pa -= bt.column;//we are repeting the same row of a the number of rows in b
			}
			*(pc++) = curr;
			curr = 0;
		}
		pa += a->column;
		pb = bt.matrix;
	}
	Delete(&bt);
	return c;
}

//input:matrix m, vector matrix v
//output:m*v if possible, INVALIDMAT otherwise 
matrix MatrixVectorMult(const matrix*m, const matrix*v) {
	//i need to mult each row in m in all of v,and because v is organized as one row
	//i mult each row of m with the row that represents the column vector v 
	if(m->column!=v->column)return INVALIDMAT;
	
	matrix a;
	Set(&a, 1, m->row);
	unsigned char *pm, *pa, *pv;
	pm = m->matrix;
	pa = a.matrix;
	pv = v->matrix;
	unsigned char sum = 0;
	int i, h, j;
	for (i = 0; i < m->row / 8; i++)
	{
		for (h = 0; h < 8; h++)
		{
			for (j = 0; j < v->column; j++)
			{
				sum ^= *(pm++) & *(pv++);
			}
			*(pa) |= parity[sum] << (7 - h);
			pv = v->matrix;
			sum = 0;
		}
		pa++;
	}
	return a;
}

//https://en.wikipedia.org/wiki/Kronecker_product this is the Kronecker product wikipedia page
//input:matrix a, matrix b
//output:a Kronecker product b, there is always an output
matrix KroneckerMult(const matrix* a, const matrix* b) {
	matrix c;
	Set(&c, a->row*b->row, a->acolumn*b->acolumn);
	unsigned char afactor;
	int ar, ac, i, br;
	int cur;
	for (ar = 0; ar < a->row; ar++)
	{
		for (ac = 0; ac < a->column; ac++)
		{
			afactor = a->matrix[ar*a->column + ac];
			
			for (i = 0; i < 8; i++)
			{
				cur = ar*c.column * b->row + ac * 8 * b->column + i*b->column;
				if (afactor >> 7)
				{
					for (br = 0; br < b->row; br++)
						memcpy(c.matrix + br*c.column + cur, b->matrix + br*b->column, b->column);
				}
				afactor <<= 1;
			}
		}
	}
	return c;
}

/*a small matlab code that is like this code
//function B=invmod2(A,n)
//H=[A eye(n,n)];
//for j=1:n
//    for k=j:n
//        if H(k,j)~=0
//            break;
//        end
//    end
//        v=H(j,:);
//        H(j,:)=H(k,:);
//        H(k,:)=v;
//        for i=1:n
//            if i~=j
//                if H(i,j)==1
//                    H(i,:)=mod(H(i,:)+H(j,:),2);
//                end
//            end
//        end
//end
B=H(1:n,n+1:2*n);*/
//input:matrix a
//output:inverse of a if a have an inverse, INVALIDMAT otherwise
matrix inverse(const matrix* a) {
	if(a->row!=a->acolumn)return INVALIDMAT;
	int i, j, k, t;
	matrix h, b;
	char* v = malloc(a->row * 2 + 1);
	//setting b
	Set(&h, a->row * 2, a->acolumn);
	memcpy(h.matrix, a->matrix, a->row*a->column);
	//filling h with [a|I]
	for (k = 0; k < a->row; k++)
		h.matrix[a->row*a->column + k*h.column + k / 8] = 1 << (7 - k % 8);

	for (j = 0; j < a->row; j++)
	{
		for (k = j; k < a->row; k++)
		{
			if (((unsigned char)(h.matrix[k*a->column + j / 8] << j % 8)) >> 7)
				break;
		}
		if (k >= a->row) {
			return INVALIDMAT;
		}
		//swap row j with row k
		if (j != k) {

			memcpy(v, h.matrix + j*a->column, h.column);
			memcpy(h.matrix + j*a->column, h.matrix + k*a->column, h.column);
			memcpy(h.matrix + k*a->column, v, h.column);
			memcpy(v, a->row*a->column + h.matrix + j*a->column, h.column);
			memcpy(h.matrix + a->row*a->column + j*a->column, h.matrix + a->row*a->column + k*a->column, h.column);
			memcpy(h.matrix + a->row*a->column + k*a->column, v, h.column);
		}
		//end of swap
		for (i = 0; i < a->row; i++)
		{
			if (i != j)
			{
				if (((unsigned char)(h.matrix[i*a->column + j / 8] << j % 8)) >> 7)
				{
					for (t = 0; t < h.column; t++)
					{
						h.matrix[i*a->column + t] ^= h.matrix[j*a->column + t];
						h.matrix[a->row*a->column + i*a->column + t] ^= h.matrix[a->row*a->column + j*a->column + t];
					}
				}
			}
		}
	}
	//define the inevrse
	Set(&b, a->row, a->acolumn);
	memcpy(b.matrix, h.matrix + a->row*a->column, a->row*a->column);
	free(v);
	Delete(&h);
	return b;
}

//input:uninitialized matrix m,uninitialized matrix mi,t number of rows and acolumns in m and mi
//inplace output:random matrix m, and mi the inverse of m 
void LURandomfill(matrix* m, matrix * mi, int t){
	//this way the matrix will be 100% inversable and the inverse time should improved
	matrix L, U, temp;
	Set(&L, t, t);
	Set(&U, t, t);
	int i8, i, j;
	unsigned char a = 0xff, ran=0;
	//filling l and u random lower matrix	
	for (i = 0; i < t; i++)
	{
		i8 = i / 8;
		randombytes(&ran, 1);
		L.matrix[i*L.column + i8] = (((a) << (7 - i % 8))&ran) | (1 << (7 - i % 8));
		randombytes(&ran, 1);
		U.matrix[i*L.column + i8] = (((a) << (7 - i % 8))&ran) | (1 << (7 - i % 8));

		randombytes(L.matrix + i*L.column, i8);
		randombytes(U.matrix + i*L.column, i8);
	}
	//the transpose of U will be an upper matrix
	temp = U;
	U = transpose(&U);
	Delete(&temp);
	
	//Li = *inverse(&L);//needs improvments
	//Ui = *inverse(&U);
	//*mi = *Mult(&Ui, &Li);
	*m = Mult(&L, &U);
	*mi = inverse(m);
	Delete(&L);
	Delete(&U);
	/*Delete(&Li);
	Delete(&Ui);*/
}

//input:a array of char values, l the size of array a
//output:array with only bit values, where each 8 cells is one cell from a
//if a was {0x80} so B is {1,0,0,0,0,0,0,0}
unsigned char* charToBitArray(unsigned char* a, int l){
	unsigned char* B = malloc(l * 8);
	unsigned char cur;
	int i, j;
	for (i = 0; i < l; i++)
	{
		cur = a[i];
		for (j = 7; j >= 0; j--)
		{
			B[i * 8 + j] = cur % 2;
			cur >>= 1;
		}
	}
	return B;
}

//input:B array of bit values, l the size of output array
//output:array with char values, where each 1 cell is 8 cells from B
unsigned char* BitArrayTochar(unsigned char* B, int l){
	unsigned char* a = malloc(l);
	unsigned char cur;
	int i, j;
	for (i = 0; i < l; i++)
	{

		for (j = 0; j <8; j++)
		{
			cur = (cur << 1) | B[i * 8 + j];
		}
		a[i] = cur;
	}
	return a;
}

//input:t the size of the Permotion
//output:random permotion, where each cell in the permotion contain a number between 0 to 2*t*t-1, and each number appers only on time
unsigned short* randomPermotion(int t){
	unsigned short temp, i, cur, size = 2 * t  * t;
	unsigned short* pi = malloc(size * sizeof(short));//the permotion
	unsigned char *ran = malloc(2);
	for (i = 0; i < size; i++)
	{
		pi[i] = i;
	}
	for (i = 0; i<size; ++i) {
		randombytes(ran, 2);
		//now ran is a random number between 0 and 2^16, but i want him to be between 0 and 511
		cur = ((short)ran[0] << 1) ^ ((short)ran[0]);

		temp = pi[i];
		pi[i] = pi[cur];
		pi[cur] = temp;
	}
	free(ran);
	return pi;
}