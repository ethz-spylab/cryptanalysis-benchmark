
../KAT_MCT:

ReadMe.txt

Instructions to compile stuff here


ecoh.c

Most internal function definitions


ecoh.h

Header file


ecoh.main.c

Runs KAT and MCT.


ecoh.param.c

Contains curve constants, and tables of precomputed values.


ecoh.w32.exe

32-bit application


ecoh.w64.exe

64-bit applicaton.



The following files are NIST files and the resulting KAT and MCT
files, with _### indicating the output for ECOH-###.


ExtremelyLongMsgKAT.txt
ExtremelyLongMsgKAT_224.64.txt
ExtremelyLongMsgKAT_256.64.txt
ExtremelyLongMsgKAT_384.64.txt
ExtremelyLongMsgKAT_512.64.txt

LongMsgKAT.txt
LongMsgKAT_224.64.txt
LongMsgKAT_256.64.txt
LongMsgKAT_384.64.txt
LongMsgKAT_512.64.txt

MonteCarlo.txt
MonteCarlo_224.64.txt
MonteCarlo_256.64.txt
MonteCarlo_384.64.txt
MonteCarlo_512.64.txt

ShortMsgKAT.txt
ShortMsgKAT_224.64.txt
ShortMsgKAT_256.64.txt
ShortMsgKAT_384.64.txt
ShortMsgKAT_512.64.txt



../Optimized_32bit:

Makefile

Run make or gmake, to compile with gcc


ecoh.h

Header file


ecoh.param.c

Contains curve constants, and tables of precomputed values.


ecoh283.c

Functions specific to curve B-283


ecoh409.c

Functions specific to curve B-283


ecoh571.c

Functions specific to curve B-283


ecohmain224.c

Main file for ECOH-224.


ecohmain256.c

Main file for ECOH-256.


ecohmain384.c

Main file for ECOH-384.


ecohmain512.c

Main file for ECOH-512.



../Optimized_64bit:

Makefile

Run make or gmake, to compile with gcc


ecoh.h

Header file


ecoh.param.c

Contains curve constants, and tables of precomputed values.


ecoh283.c

Functions specific to curve B-283


ecoh409.c

Functions specific to curve B-283


ecoh571.c

Functions specific to curve B-283


ecohmain224.c

Main file for ECOH-224.


ecohmain256.c

Main file for ECOH-256.


ecohmain384.c

Main file for ECOH-384.


ecohmain512.c

Main file for ECOH-512.



../README:

readme.txt

This file


README_DOS.txt

Dos version of this file


../Reference_Implementation:

ReadMe.txt

Local readme file.


ecoh.c

Most internal function definitions


ecoh.h

Header file


ecoh.main.c

Runs KAT and MCT.


ecoh.param.c

Contains curve constants, and tables of precomputed values.


../Supporting_Documentation:

ecoh.pdf

Specification and anlaysis.



