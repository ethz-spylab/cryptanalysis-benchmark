
Algorithm Name:         ECOH (Elliptic Curve Only Hash)
Principal Submitter:    Daniel R. L. Brown

Date:			30 October 2008

Contents of this ReadMe

1) Description of Files
2) Development Environment
3) Compiling on Windows
	a) 32-bit
	b) 64-bit
4) Compiling on Linux
	a) 32-bit
	b) 64-bit
5) Debug Prepocessor Flag



1)Description of Files
====================================================================

The four source code files 

	ecoh.h
	ecoh.c
	ecoh.main.c
	ecoh.param.c

found in KAT_MCT and Reference_Implementation Directories are identical, as is this ReadMe file found in both directories.

ecoh.c	- Implements the major cryptographic operations for ECOH. It contains the necessary finite field and elliptic curve operations used in ECOH, as well as the formatting and hashing functions.  An attempt was made to give a reference for every algorihm utilized in the source code.  It was written to provide a single source file implementation for all the security levels on multiple curves.

ecoh.h 	- The header file for ECOH. This file contains function declarations for the major hashing routines as defined in the SHA-3 API document, as well as structures utilizied by ECOH.

ecoh.param.c - A parameter file.  This file contains elliptic curve parameters and look-up tables to reduce the amount of code in ecoh.c hopefully in an attempt to make the code more readable.

ecoh.main.c - This file is a modified version of the genKAT.c file provided by NIST.  The changes are minimal to add some debugging and intermediate values, as well as to #include the appropriate .h file for ECOH.


2) Development Environment
======================================================================
The Reference implementation was developed to compile on both Windows and Linux on running 32-bit or 64-bit OSes.

The development machine was an AMD Athlon 64 X2 Dual Core Processor 6000+ 3.00 Ghz with 4GB RAM, configured to dual boot between 
Windows Vista Ultimate 64-bit OS with Service Pack 1, and Ubuntu 8.04 Desktop 64-bit OS.

The code was written in Visual Studio 2005 Professional Edition, Version 8.0.50727.867 installed with the x64 compiler.  Most of the development was done within a Visual Studio project environment with the goal that only simple cross-platform compile lines would be needed.

3) Compiling on Windows
======================================================================
Microsoft Visual Studios installs "Visual Studio 2005 Command Prompt" and "Visual Studio 2005 x64 Win64 Command Prompt" when the x64 compiler option is selected during intial install.

a) 32-bit
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Open "Visual Studio 2005 Command Prompt"

Change directory that contains the source code and to which the logged on user has read/write access, and use the commandline

"cl /Feecoh /O2 /GL ecoh.main.c ecoh.param.c ecoh.c"

NOTE:  To include ecoh in other applications it should be sufficient to include the ecoh.h file in other sources, and compile with ecoh.param.c and ecoh.c.


b) 64-bit
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Open "Visual Studio 2005 x64 Win64 Command Prompt"

Change directory to the one that contains the source code and to which the logged on user has read/write access, and use the commandline

"cl /Feecoh /O2 /GL -D "_x64_" ecoh.main.c ecoh.param.c ecoh.c"

NOTE:  To include ecoh in other applications it should be sufficient to include the ecoh.h file in other sources, and compile with ecoh.param.c and ecoh.c.


4) Compiling on Linux
=======================================================================
Ubuntu 8.04 was installed with gcc-4.2 and any necessary dependencies


a) 32-bit
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Change directory to the one that contains the source code and to which the logged on user has read/write access, and use the commandline

"gcc -o ecoh.exe -O3 ecoh.param.c ecoh.c ecoh.main.c"

NOTE:  To include ecoh in other applications it should be sufficient to include the ecoh.h file in other sources, and compile with ecoh.param.c and ecoh.c.


b) 64-bit
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Change directory to the one that contains the source code and to which the logged on user has read/write access, and use the commandline

"gcc -o ecoh.exe -m64 -D "_x64_" -O3 ecoh.param.c ecoh.c ecoh.main.c"

NOTE:  To include ecoh in other applications it should be sufficient to include the ecoh.h file in other sources, and compile with ecoh.param.c and ecoh.c.


5) Debug Mode
=======================================================================
There is a preprocessor flag _DEBUG that when defined will enable the executable to the print out intermediate values to stdout.  Additionally, a function call to Intermediate( ) in ecoh.main.c will be called prior to the generation of the KAT files.


