/* shiftopt.c
** Author:  Ronald L. Rivest
** Address: Room 32G-692 Stata Center 
**          32 Vassar Street 
**          Cambridge, MA 02139
** Email:   rivest@mit.edu
** Date:    9/25/2008
**
** (The following license is known as "The MIT License")
** 
** Copyright (c) 2008 Ronald L. Rivest
** 
** Permission is hereby granted, free of charge, to any person obtaining a copy
** of this software and associated documentation files (the "Software"), to deal
** in the Software without restriction, including without limitation the rights
** to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
** copies of the Software, and to permit persons to whom the Software is
** furnished to do so, subject to the following conditions:
** 
** The above copyright notice and this permission notice shall be included in
** all copies or substantial portions of the Software.
** 
** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
** IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
** FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
** AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
** LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
** OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
** THE SOFTWARE.
**
** (end of license)
**
** Routines to find good shift values for MD6.
*/

#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <time.h>
/* Useful macros: min and max */
#define min(a,b) ((a)<(b)? (a) : (b))
#define max(a,b) ((a)>(b)? (a) : (b))

int gcd(int a, int b)
{ if (b==0) return a;
  return gcd(b,a%b);
}

/*
** Beginning of parameters defining md6 version to be optimized.
*/

/* wordsize w ( = 64, 32, 16, or 8 bits/word) */
#define w 64                     /* w = 64, 32, 16, or 8 */
#if (w==8)
  typedef uint8_t md6_word;      /* md6_word is a w-bit unsigned integer */
#elif (w==16)
  typedef uint16_t md6_word;     /* md6_word is a w-bit unsigned integer */
#elif (w==32)
  typedef uint32_t md6_word;     /* md6_word is a w-bit unsigned integer */
#elif (w==64)
  typedef uint64_t md6_word;     /* md6_word is a w-bit unsigned integer */
#endif

/* constants defining round constants, adjusted for word size w */
md6_word S0 = 0x0123456789abcdefULL >> (64-w);     
md6_word sqrt6 = 0x7311c2812425cfa0ULL >> (64-w);  

#define n 89              /* size of compression function input (words) */
#define c 16              /* size of compression function output (words) */

int taps[6] = {17,18,21,31,67,89};  /* tap positions in NLFSR */
#define t0 taps[0]
#define t1 taps[1]
#define t2 taps[2]
#define t3 taps[3]
#define t4 taps[4]
#define t5 taps[5]

#define r 178             /* number of rounds in compression function */
#define t (r*c)           /* number of computation steps in c.f. */
int LB = 1;               /* least allowable shift amount */
int UB = (w/2);           /* max allowable shift amount   */
int shift_block_size = 1; /* shifts repeat for this many rounds (1,2,4,8,16) */
int gamma_limit = 5;      /* lower bnd on min wt of ginv on a weight-one 
			     word */

int trials = 1000000;          /* number of seeds to try         */ 


/* Bit count routines.
*/

/* bitcount array */
static int bc_setup = 0;
static int bc[256];       /* gives popcount for each byte */

void init_bc()
/* initialize bc array, and set bc_setup flag */
{ int i;
  bc[0] = 0;
  for (i=1;i<256;i++) bc[i] = bc[i>>1]+(i&1);
  bc_setup = 1;
}

int popcount(unsigned char *x, int xlen)
/* Return number of 1's in byte string x of length xlen */
{
  int i, count = 0;
  if (bc_setup==0) init_bc();
  for (i=0;i<xlen;i++)
    count += bc[x[i]];
  return count;
}

int wt(md6_word x)
/* return hamming weight of an md6_word */
{
  return popcount((unsigned char *)&x,w/8);
}

/* The function g and its inverse; the gamma function
*/

md6_word g(md6_word x,int rr,int ell)
/* g is the basic diffusion operator in MD6 */
{
  x = x ^ (x >> rr);
  x = x ^ (x << ell);
  return x;
}

md6_word ginv(md6_word x, int rr, int ell)
/* ginv is the inverse of g */
{
  int i;
  md6_word y,z,xx,yy;
  y = 0;
  xx = x;
  for (i=0;xx != 0;i++)
    { y = y ^ xx;
      xx = xx << ell;
    }
  z = 0;
  yy = y;
  for (i=0;yy!=0;i++)
    { z = z ^ yy;
      yy = yy >> rr;
    }
  return z;
}

int get_gamma(int rr, int ell)
{ /* compute min(wt(ginv(y))) for y of weight one. */
  md6_word x,y;
  int minwt = w;
  int i;
  for (i=0;i<w;i++)
    {
      y = ((md6_word)1)<<i;
      x = ginv(y,rr,ell);
      minwt = min(minwt,wt(x));
    }
  return minwt;
}

/* Random number routines
** (Written here explicitly to make sure generation is repeatable.)
** Based on RC4.
*/

/* RC4 state */
unsigned char RC4_S[256];   
unsigned char RC4_i, RC4_j;          

unsigned char RC4_byte()
/* run generator one step; return random byte */
{ 
  unsigned char si,sj;
  RC4_i = RC4_i+1;
  RC4_j = RC4_j + RC4_S[RC4_i];
  si = RC4_S[RC4_i];
  sj = RC4_S[RC4_j];
  RC4_S[RC4_j] = si;
  RC4_S[RC4_i] = sj;
  return RC4_S[(si+sj)&0xff];
}

void RC4_init(long long seed)
/* Initialize RC4 generator from given seed. */
{
  int i, j, temp;
  for (i=0;i<256;i++) RC4_S[i] = i;
  for (j=0;j<64;j++)
    if (((seed>>j)&1) == 1)
      { /* swap two values in S if seed bit is one */
	temp = RC4_S[2*j]; 
	RC4_S[2*j] = RC4_S[2*j+1]; 
	RC4_S[2*j+1] = temp;
      }
  RC4_i = 0;
  RC4_j = 0;
  for (i=0;i<1000;i++) RC4_byte();   /* stir... */
}

/* Routine to generate random shift table
*/

void generate_random_shifts(long long seed, int R[], int L[])
/* Generate random shift values, from seed; place in R, L */
{ 
  int i;
  int s;
  int limit;

  RC4_init(seed);
  for (i=0;i<c;i++)
    { /* each shift value is between 1 and w/2, inclusive */
      limit = 1000;
      while (limit > 0)  /* until we have a good pair of shifts */
	{ limit--;
	  /* generate a random pair */
	  R[i] = (LB + (RC4_byte() % (UB-LB+1)));
	  L[i] = (LB + (RC4_byte() % (UB-LB+1)));

	  /* Make sure that R[i] and L[i] don't divide each other */
	  if ( (R[i] % L[i]) == 0 ) continue;
	  if ( (L[i] % R[i]) == 0 ) continue;

	  /* following tests are only for w=32 or 64, so break otherwise */
	  if (w<32) break;

	  /* test it for acceptability wrt gamma_limit */
	  if (get_gamma(R[i],L[i]) < gamma_limit ) continue; 

	  /* Note that left shift here is followed by a right
	  ** shift s steps later, where s=t0, t5, or t5-t0
	  ** (only paying attention to linear terms in feedback).
	  ** Make sure these shift don't interact badly, either.
	  */
	  s = t0 % c;
	  if (s>0 && i>=s)
	    { if (R[i] % L[i-s] == 0) continue; /* R[i] with previous L */
	      if (L[i-s] % R[i] == 0) continue;
	    }
	  if (s>0 && i+s>=c)
	    { if (R[i+s-c] % L[i] == 0) continue; /* R[i+s-c] with previous L */
	      if (L[i] % R[i+s-c] == 0) continue;
	    }

	  s = t5 % c;
	  if (s>0 && i>=s)
	    { if (R[i] % L[i-s] == 0) continue; /* R[i] with previous L */
	      if (L[i-s] % R[i] == 0) continue;
	    }
	  if (s>0 && i+s>=c)
	    { if (R[i+s-c] % L[i] == 0) continue; /* R[i+s-c] with previous L */
	      if (L[i] % R[i+s-c] == 0) continue;
	    }

	  s = (t5-t0) % c;
	  if (s>0 && i>=s)
	    { if (R[i] % L[i-s] == 0) continue; /* R[i] with previous L */
	      if (L[i-s] % R[i] == 0) continue;
	    }
	  if (s>0 && i+s>=c)
	    { if (R[i+s-c] % L[i] == 0) continue; /* R[i+s-c] with previous L */
	      if (L[i] % R[i+s-c] == 0) continue;
	    }
	  break;
	} /* end of while loop searching for R[i],L[i] pair */
      if (limit==0) printf("limit reached for seed = %lld\n",seed);
      /* ignore this setting and copy from i-1 if shifts repeat */
      if (i%shift_block_size != 0)
	{ R[i] = R[i-1]; L[i] = L[i-1]; }
    }
}

/* Routines to work with linear polynomials
*/

typedef md6_word poly[n+1];
/* If f is a poly, then 
**   f[0] is the constant term (i.e. either 0 or 1)
**   f[1..n] represent the linear terms 
**      there are nw terms (bits are 1-1 correspondence with bits of N)
**   higher-order terms are discarded.
*/

typedef poly polyword[w];

polyword AP[t+n];   /* polys for all bits of the computation! */

void const_poly(poly A, int value)
/* let poly A represent the constant value given (0 or 1) */
{
  int i;
  A[0] = value & 1;
  for (i=1;i<=n;i++) A[i] = 0;
}

void var_poly(poly A, int i, int j)
/* let poly A represent polynomial with only term being
** bit j of word i, 0<=j<w, 1<=i<n. Linear term, a variable.
*/
{
  const_poly(A,0);
  A[i] = (1LL<<j);
}

int LC_poly(poly A)
/* Return the "linear complexity" of polynomial A,
** defined as the number of linear terms it has.
*/
{
  return popcount((unsigned char *)(&A[1]),n*(w/8));
}

void const_polyword(polyword A, md6_word value)
/* set polyword A to the given constant value */
{
  int i;
  for (i=0;i<w;i++) const_poly(A[i],(value>>i)&1);
}

void xor_poly(poly A, poly B, poly C)
/* let poly A represent xor of poly's B and C */
{
  int i;
  for (i=0;i<=n;i++) 
    A[i] = B[i] ^ C[i];
}

void xor_polyword(polyword A, polyword B, polyword C)
/* let polyword A represent xor of polywords B and C */
{
  int i;
  for (i=0;i<w;i++) xor_poly(A[i],B[i],C[i]);
}

void and_poly(poly A, poly B, poly C)
/* let poly A represent the product of polys B and C */
/* A should not be equal to B or C                   */
{
  int i;
  A[0] = B[0] * C[0];
  for (i=1;i<=n;i++) 
    A[i] = 0;
  if (B[0]==1)
    for (i=1;i<=n;i++)
      A[i] ^= C[i];
  if (C[0]==1)
    for (i=1;i<=n;i++)
      A[i] ^= B[i];
}

void and_polyword(polyword A, polyword B, polyword C)
/* let polyword A represent and of polywords B and C */
{
  int i;
  for (i=0;i<w;i++) and_poly(A[i],B[i],C[i]);
}

void copy_poly(poly A, poly B)
/* set poly A = B */
{
  int i;
  for (i=0;i<=n;i++) A[i] = B[i];
}

void copy_polyword(polyword A, polyword B)
/* set polyword A = B */
{
  int i;
  for (i=0;i<w;i++) copy_poly(A[i],B[i]);
}

void shiftr_polyword(polyword A, polyword B, int rs)
/* let polyword A = polyword B shifted right by rs positions */
{
  int i;
  for (i=0;i<w-rs;i++)
    copy_poly(A[i],B[i+rs]);
  for (i=w-rs;i<w;i++)
    const_poly(A[i],0);
}

void shiftl_polyword(polyword A, polyword B, int ls)
/* let polyword A = polyword B shifted left by ls positions */
{
  int i;
  for (i=0;i<ls;i++)
    const_poly(A[i],0);
  for (i=ls;i<w;i++)
    copy_poly(A[i],B[i-ls]);
}

/* Routines to compute linear polynomials for all bits
** in the compression function.
*/

void init_AP()
/* initialize polywords AP[0..n-1] to single linear terms */
{
  int i,j;
  for (i=1;i<=n;i++)
    for (j=0;j<w;j++)
      var_poly(AP[i-1][j],i,j);
}

void compress_AP(int taps[], int R[], int L[],int rounds)
/* run compression algorithm on AP for given number of rounds*/
{
  md6_word S = S0;
  int i;

  for (i=n;i<n+rounds*c;i++)
    {
      polyword x,temp;
      const_polyword(x,S);
      xor_polyword(x,x,AP[i-t5]);
      xor_polyword(x,x,AP[i-t0]);
      and_polyword(temp,AP[i-t1],AP[i-t2]);
      xor_polyword(x,x,temp);
      and_polyword(temp,AP[i-t3],AP[i-t4]);
      xor_polyword(x,x,temp);
      shiftr_polyword(temp,x,R[i%c]);
      xor_polyword(x,x,temp);
      shiftl_polyword(temp,x,L[i%c]);
      xor_polyword(x,x,temp);
      copy_polyword(AP[i],x);
      if ((i-n)%16==15) S = (S << 1) ^ (S >> (w-1)) ^ (S & sqrt6);
    }
}

/* Compute heuristic quality measure.
*/

long long measure_sumdevsq(int taps[], int R[], int L[], int rounds)
/* Measure the sum, over each of the first 12 rounds,
** of the sum over all bits computed in those rounds,
** of the squared deviations of the differences of
** of their linear complexities from (n*w)/2
*/
{
  int i,ii,j;
  long long LC, min_LC, dev;
  init_AP();
  compress_AP(taps,R,L,rounds);
  long long sumdevsq = 0;

  for (ii=n;ii<n+rounds*c;ii=ii+c)
    {
      for (i=ii;i<ii+c;i++)
	{
	  min_LC = (1LL << 50);
	  for (j=w-1;j>=0;j--)
	    { LC = LC_poly(AP[i][j]);
	      if (LC < min_LC) min_LC = LC;
	      dev = LC-(n*w/2);
	      sumdevsq += dev*dev;
	    }
	}
    }
  return sumdevsq;
}

/* Print solution.
*/

void print_soln(long long seed,int taps[],int R[],int L[],
		long long sumdevsq,int rounds)
{
  int i,ii,j;
  long long LC, min_LC;
  printf("seed = %lld, w = %d, n = %d, c = %d, LB = %d, UB = %d, taps = ",seed,w,n,c,LB,UB);
  for (i=0;i<=5;i++) printf("%2d ",taps[i]);
  printf("\n");
  if (w>=32) printf("gamma_limit = %d\n",gamma_limit);
  printf("i:       ");
  for (i=0;i<c;i++) printf("%2d ",i);
  printf("\n");
  printf("R:       ");
  for (i=0;i<c;i++) printf("%2d ",R[i]);
  printf("\n");
  printf("L:       ");
  for (i=0;i<c;i++) printf("%2d ",L[i]);
  printf("\n");
  printf("Linear complexities (minimum within each word, for last %d rounds):",rounds);
  for (ii=n;ii<n+rounds*c;ii=ii+c)
    {
      printf("\n%4d: ",ii);
      for (i=ii;i<ii+c;i++)
	{
	  min_LC = (1LL << 50);
	  for (j=w-1;j>=0;j--)
	    { LC = LC_poly(AP[i][j]);
	      if (LC < min_LC) min_LC = LC;
	    }
	  printf("%4lld ",min_LC);
	}
    }
  printf("\n");
  printf("sumdevsq: %lld\n",sumdevsq);
  printf("sqrt mean squared deviation: %f\n",sqrt((double)sumdevsq/(rounds*c*w)));
  printf("\n");
  fflush(NULL);
}

/* Search for best solution.
*/

int best_R[c];
int best_L[c];

void save_soln(int R[], int L[])
/* save R, L as current "best" soln */
{ int i;
  for (i=0;i<c;i++)
    {
      best_R[i] = R[i];
      best_L[i] = L[i];
    }
}

void print_best()
/* print out best_R, best_L in a couple of nice ways */
{ int i;
  printf("Best solution:\n");

  printf("plain:\n");
  printf("R:       ");
  for (i=0;i<c;i++) printf("%2d ",best_R[i]);
  printf("\n");
  printf("L:       ");
  for (i=0;i<c;i++) printf("%2d ",best_L[i]);
  printf("\n\n");

  printf("tex:\n");
  for (i=0;i<c;i++) 
    { printf("%2d ",best_R[i]);
      if (i!=c-1) printf("& ");
    }
  printf("\n");
  for (i=0;i<c;i++) 
    { printf("%2d ",best_L[i]);
      if (i!=c-1) printf("& ");
    }
  printf("\n\n");

  printf("C:\n");
  for (i=0;i<c;i++) 
    printf("#define RL%02d loop_body(%2d,%2d)\n",i,best_R[i],best_L[i]);
  printf("\n\n");
}

void shift_search(int taps[])
/* Loop to find best set of shifts for given taps */
{
  long long seed = 0;
  int R[c];
  int L[c];
  long long measure_sumdevsq(int taps[], int R[], int L[], int rounds);
  long long best_sumdevsq, sumdevsq;
  int rounds = 12;      /* rounds to measure for sumdevsq */

  best_sumdevsq = (1LL<<50);
  for (seed = 0;seed<trials;seed++)
    {
      if ((seed%10000) == 0) 
	{ printf("seed = %lld\n",seed);
	  fflush(stdout);
	}
      generate_random_shifts(seed, R, L);
      sumdevsq = measure_sumdevsq(taps,R,L,rounds);
      if (sumdevsq < best_sumdevsq)
	{
	  best_sumdevsq = sumdevsq;
	  print_soln(seed,taps,R,L,sumdevsq,rounds);
	  save_soln(R,L);
	}      
    }
  print_best();
}

/* main.
*/

int main(int argc, char **argv)
{
  time_t now;

  printf("MD6 shift optimization routine.\n");
  time(&now); printf("%s\n",ctime(&now));
  shift_search(taps);
  printf("Done. ");
  time(&now); printf("%s\n",ctime(&now));
  return 0;
}
