/* tapopt.c
** Author:  Ronald L. Rivest
** Address: Room 32G-692 Stata Center 
**          32 Vassar Street 
**          Cambridge, MA 02139
** Email:   rivest@mit.edu
** Date:    9/25/2008
**
** (The following license is known as "The MIT License")
** 
** Copyright (c) 2008 Ronald L. Rivest
** 
** Permission is hereby granted, free of charge, to any person obtaining a copy
** of this software and associated documentation files (the "Software"), to deal
** in the Software without restriction, including without limitation the rights
** to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
** copies of the Software, and to permit persons to whom the Software is
** furnished to do so, subject to the following conditions:
** 
** The above copyright notice and this permission notice shall be included in
** all copies or substantial portions of the Software.
** 
** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
** IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
** FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
** AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
** LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
** OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
** THE SOFTWARE.
**
** (end of license)
**
** This file is part of the definition of the MD6 hash function.
** This used to determine tap positions for the MD6 hash function.
**
** See  http://groups.csail.mit.edu/cis/md6  for more information.
*/

#include <stdlib.h>
#include <stdio.h>

int gcd(int a, int b)
/* Return gcd of integers a and b */
{
  a = abs(a);
  b = abs(b);
  if (b == 0)
    return a;
  return gcd(b,a%b);
}

int relp(int a, int b)
/* Return True (1) iff a and b are relatively prime. */
{
  if (gcd(a,b)==1)
    return 1;
  else
    return 0;
}

int measure(int taps[],int t,int n,int c)
/*  Measure avalanche effect.
**  Returns number of shift register steps required so that 
**  last c elements computed are all fully dependent on original
**  inputs, and that this doesn't change with more computation.
*/
{
  int i,j,last_partial;
  int t0 = taps[0];
  int t1 = taps[1];
  int t2 = taps[2];
  int t3 = taps[3];
  int t4 = taps[4];
  int t5 = taps[5];
  int n8 = (n+7)/8;  /* number of bytes needed for an n-bit vector */
  unsigned char d[t+n][(n+7)/8];   /* "depends upon" array */
  unsigned char nmask[(n+7)/8];    /* bit array of n ones */

  /* Initialize nmask to bit array of n ones */
  for (i=0;i<n/8;i++)
    nmask[i] = 0xff;
  if ((n%8) != 0)
    nmask[(n-1)/8] = (-1)<<(8-(n%8));

  /* initialize d to identity matrix in d[0..n-1]; zeros in d[n..t+n-1] */
  for (i=0;i<t+n;i++)
    for (j=0;j<n8;j++)
       d[i][j] = 0;
  for (i=0;i<n;i++)
      d[i][i/8] = 0x80 >> (i%8);
  
  last_partial = n-1;
  for (i=n;i<t+n;i++)
    {
      for (j=0;j<n8;j++)
	{ d[i][j] = d[i-t0][j] | d[i-t1][j] | d[i-t2][j] | d[i-t3][j] 
	    | d[i-t4][j] | d[i-t5][j];
	  /* printf("%02x",d[i][j]); */
	  if (d[i][j] != nmask[j]) last_partial = i;
	}
      if (i-last_partial >= n) break;
    }
  return (last_partial-(n-1)+c);
}

void search(int n, int c)
/* Search for best tap positions t0...t5,
** in terms of minimizing time taken to achieve full avalanche.
** (in this formal sense...)
** for a n-word NLFSR
** where c < t0 < t1 < t2 < t3 < t4 < t5 = n
** taps must be nonzero mod c
** taps must not be equal to each other mod c
*/
{
int dep;
int best_dep = 10000;                          /* arbitrary large value */
int taps[6];
int best_taps[6];
int t = 1000;                                  /* just a large number, of steps */
int t0,t1,t2,t3,t4,t5;
int j;

for (j=0;j<6;j++) best_taps[j] = 0;

printf("Beginning search for optimal tap positions for n = %d, c = %d\n",n,c);
for (t0 = c+1; t0<n-4; t0++)
  {
    if ((t0%c)==0) continue;
    if (!relp(t0,n)) continue;
    printf("\nt0 = %d: ",t0); fflush(stdout);
    for (t1=t0+1;t1<n-3;t1++)
      {
	if ((t1%c)==0) continue;
	if ((t1-t0)%c==0) continue;
	if (!relp(t1,n)) continue;
	/* printf("%d ",t1); */
	for (t2=t1+1;t2<n-2;t2++)
	  {
	    if ((t2%c)==0) continue;
	    if (((t2-t0)%c)==0) continue;
	    if (((t2-t1)%c)==0) continue;
	    if (!relp(t2,n)) continue;
	    for (t3=t2+1;t3<n-1;t3++)
	      {
		if ((t3%c)==0) continue;
		if (((t3-t0)%c)==0) continue;
		if (((t3-t1)%c)==0) continue;
                if (((t3-t2)%c)==0) continue;
		if (!relp(t3,n)) continue;
		for (t4=t3+1;t4<n;t4++)
		  {
		    if ((t4%c)==0) continue;
		    if (((t4-t0)%c)==0) continue;
		    if (((t4-t1)%c)==0) continue;
		    if (((t4-t2)%c)==0) continue;
		    if (((t4-t3)%c)==0) continue;
		    if (!relp(t4,n)) continue;
		    if ((t4-t3)==(t2-t1)) continue;
		    t5 = n;
		    taps[0] = t0;
		    taps[1] = t1;
		    taps[2] = t2;
		    taps[3] = t3;
		    taps[4] = t4;
		    taps[5] = t5;
		    /* now see how good taps are... */
		    dep = measure(taps,t,n,c);
		    if (dep<=best_dep)
		      { 
			for (j=0;j<6;j++) 
			  best_taps[j] = taps[j];
			/* printf("%d %d %d %d %d %d --- %d\n",
			**        t0,t1,t2,t3,t4,t5,dep);
			*/
			best_dep = dep;
		      }
		  } /* end of loop on t4 */
	      } /* end of loop on t3 */
	  } /* end of loop on t2 */
      } /* end of loop on t1 */
  } /* end of loop on t0 */
printf("Optimal tap positions: %d %d %d %d %d %d\n",
       best_taps[0],best_taps[1],best_taps[2],best_taps[3],
       best_taps[4],best_taps[5]);
printf("Achieves full dependence in %d steps.\n",best_dep);
}

int main(int argc, char *argv[])
{
  int n,c;
  if (argc != 3) 
    { 
      printf("Usage: tapopt.exe n c\n");
      exit(0);
    }
  n = atoi(argv[1]);
  c = atoi(argv[2]);
  search(n,c); 
  return 0;
}

