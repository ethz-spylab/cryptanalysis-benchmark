/*
Assess the properties of the X-box substitution - difference propagation

We test only differences propagated from one byte to any byte after a number of X-box applications.
Resource availability rules out checking all masks against all masks for all inputs, so we test over
2^27 random chosen inputs (from an LFSR).

Bob Hattersley 06Oct08
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define PASSES 1			// Number of whole X-box applications
#define INPUTS 0x8000000	// Number of trials

	static const unsigned int xbox00[] = {
		0xbb9af663, 0x2b666d7d, 0xa50c1275, 0xaf814e78, 0xe638a9f6, 0xb7939e6e, 0xb117aa69, 0x4be9fac2,
		0x43a37038, 0xebb40d08, 0xbd1ec26d, 0xd5dbdf20, 0xecb5f5f2, 0x50b930da, 0x114a5da5, 0x242d1f79,
		0xc307b1da, 0xad469893, 0x4164a6db, 0xaa47606e, 0xea31c1ee, 0x9de7f44c, 0x8c3a6251, 0xe57ab3e7,
		0x148c73b5, 0xd2da27cd, 0x9c6238b8, 0x17ce69b4, 0xbc9b0e80, 0x99a416b9, 0x22a92b6c, 0xcc4cc3df,
		0x03d5d197, 0x6ed6e2dc, 0x347545b1, 0x5e778e05, 0x46655e12, 0xcb4d3b1a, 0x619d90d1, 0xc6c19feb,
		0x4527441c, 0x18851b8c, 0x7acd5acf, 0x645bbeda, 0xa0ca3c5d, 0xd8577bf5, 0xc2827d1f, 0xf522e93a,
		0x6c113434, 0x48abe0f6, 0xd9d2b711, 0x4e2fd4f0, 0x7e8eb82c, 0xb3d07ca3, 0xed303933, 0xb95d20ad,
		0xee72233f, 0x71c5ca2b, 0xae0482ba, 0xfe2a79d9, 0x73021cd7, 0xdf56831a, 0x8470e88c, 0xa64e084a,
		0xe7bd6549, 0x2c6795c2, 0x513cfc6e, 0x7dcca259, 0xfcedaf5f, 0x3036a72b, 0x1f84e31c, 0x9f2022e7,
		0x138d8b1a, 0xcdc90f72, 0xd1983d9c, 0x0551e5f8, 0xd699c565, 0x7f0b74ae, 0xd35feb61, 0xa880b6cb,
		0x92ac8603, 0x557f1e80, 0x6a950052, 0x76c432be, 0x5bb1a074, 0xeff7efa9, 0x0613ffe7, 0x9ea5ee0c,
		0x36b29332, 0x4226bc92, 0x8efdb4e4, 0xce8b1562, 0x07963316, 0x02501d11, 0x1cc6f906, 0x44a28890,
		0xd45e13b0, 0x7586288e, 0x906b50c8, 0x6b10cc98, 0x8abe5627, 0x83711028, 0xc1c06755, 0x29a1bbe2,
		0x8f78782d, 0x6852d690, 0x69d71a68, 0xa9057a14, 0x10cf913c, 0x492e2c51, 0x3ef819f1, 0x93294ac7,
		0x91ee9c21, 0x1d4335d2, 0x08dd4132, 0x26eac9fc, 0xb55448e6, 0x3dba03e8, 0x4faa184e, 0x62df8a82,
		0x8dbfaec4, 0x82f4dccf, 0xdb1561a0, 0xda90ad5a, 0x7287d06c, 0x6d94f882, 0x6719a48d, 0xd71c09ad,
		0x47e0924d, 0x60185c8d, 0xf0e4c791, 0xf7e53f6f, 0x9821dadb, 0x32f17112, 0x0e5975c2, 0xf660f390,
		0xcac8f74c, 0x1bc7012e, 0x282477f4, 0xc80f21b6, 0x3f7dd5e8, 0x9b63c0d0, 0xffafb597, 0xa38826fc,
		0x39f9e1f0, 0x2f258f10, 0x80330add, 0xded34f4f, 0x58f3bab6, 0x54fad2bf, 0xb6165206, 0xa20dea1f,
		0x0d1b6fde, 0xf4a72577, 0x8b3b9a22, 0x7403e48f, 0xdd915542, 0x1900d7c3, 0xe4ff7f95, 0x5a346c44,
		0xfd686340, 0x40e16a93, 0x4ce80298, 0x65de72a9, 0x85f524ed, 0x6f532ea3, 0x5d359482, 0x1a42cdfb,
		0xcf0ed96a, 0x563d047a, 0x95ad7e06, 0x3abbfbc9, 0x37375f3d, 0x31b36b38, 0xfbec574a, 0xacc354d6,
		0x798f4057, 0xc045ab79, 0xc7445385, 0xb255b0de, 0x25a8d339, 0x53fb2a60, 0x011207f8, 0x1208471e,
		0x3374bdd4, 0x1509bfef, 0xe3fe874e, 0xf2231151, 0xbe5cd8d9, 0x2ea043c7, 0x96ef6410, 0x669c68b7,
		0x8879807a, 0x2de259b9, 0xdc1499e7, 0x527ee6ed, 0x780a8cd8, 0x9ae60c63, 0x81b6c672, 0xc98aed01,
		0xf1610b20, 0x5ff24214, 0x276f05be, 0xfa699bd4, 0x86b73e87, 0x0c9ea370, 0x206efd45, 0xa14ff045,
		0x21eb31a0, 0x4a6c36ef, 0x0097cb67, 0x3c3fcfb5, 0x04d4299c, 0xe8f617d6, 0xe0bc9d20, 0x635a46d9,
		0xb8d8ecb9, 0xc40649ec, 0x9428b28d, 0x0a1a9762, 0xabc2ac5a, 0x4d6dce1c, 0xf92b81c3, 0xbfd91441,
		0x7c496e01, 0xe973db19, 0xba1f3a7a, 0xf3a6ddf2, 0xb4d1848d, 0x5976763c, 0xa7cbc468, 0xb0926673,
		0x387c2d73, 0x7b4896f7, 0x2ae3a16d, 0x70400602, 0xc5838522, 0x976aa8b8, 0x57b8c8c6, 0x5cb05830,
		0xa489de7c, 0x1e012f50, 0x232ce77b, 0xe13951fe, 0x0fdcb94b, 0xf8ae4d13, 0x0b9f5bb4, 0x35f0899f,
		0x89fc4cb9, 0x3b3e3760, 0xd01df1d7, 0xe27b4bf4, 0x8732f24c, 0x164ba5a9, 0x09588d45, 0x7741fee9
	};

static unsigned int xbox[256];
static unsigned int hits[256][4][256];	// Number of hits in each byte with each pair of input and output differences
static unsigned int lfsr = 1;

unsigned int Xbox (unsigned int in) {
	int i;
	for (i=0; i<PASSES; i++) {
		in ^= xbox[in & 0xFF];
		in = (in>>8) | (in<<24);
		in ^= xbox[in & 0xFF];
		in = (in>>8) | (in<<24);
		in ^= xbox[in & 0xFF];
		in = (in>>8) | (in<<24);
		in ^= xbox[in & 0xFF];
		in = (in>>8) | (in<<24);
	}
	return in;
}

unsigned int random(unsigned char bits) {
	unsigned int i, bit;
	i = 0;

	while(bits--) {
		i<<=1;
		bit = lfsr & 1;
		lfsr >>= 1;
		if ( bit ) {
			lfsr ^= 0x8cf3ee80;
			i++;
		}
	}
	return i;
}

void main(int argc, char *argv[]) {
	unsigned int in, out, i, j, k, test, count;
	unsigned char key1, key2, work;
	int bias, min, max;
	double mean, sd;

	key1 = 0;
	sscanf_s(argv[1], "%x", &key2);
	printf ("Key2 %d\n", key2);

	for(i=0; i<256; i++) {
		work = (xbox00[i]>>8) & 0xff;
		work = (work<<key2) | (work>>(8-key2));
		xbox[i] = (xbox00[i]&0xffff00ff) | work<<8;
	}

	for (i=0; i<256; i++) for (k=0; k<4; k++ ) for (j=0; j<256; j++) hits[i][k][j] = 0;

// Some input values
	in = random(32);
	count = 0;
	do {
		out = Xbox(in);

// For each input difference
		for (i=1; i<256; i++) {
			test = out ^ Xbox(in ^ i);

		// Count up hits in each byte - we expect roughly trials/256
			for (k=0; k<4; k++) {
				hits[i][k][test&0xFF]++;
				test >>= 8;
			}
		}

		in = random(32);

		if ((count&0xFFFFF) == 0) {
			if ((count&0x3FFFFFF) == 0) printf("\n%8.8x ", count);
			printf(".");
			fflush(stdout);
		}
	} while (++count<INPUTS);
	printf("\n");

// Analysis
	min = 0;
	max = 0;

	mean = 0;
	sd = 0;

	for (i=1; i<256; i++) {
		for (k=0; k<4; k++) {
			for (j=0; j<256; j++) {
				bias = hits[i][k][j] - INPUTS/256;
				if (bias < min) min = bias;
				if (bias > max) max = bias;
				printf("Indiff %3u byte %d outdiff %3u hits %10d\n", i, k, j, hits[i][k][j]);
				mean += (double) bias;
				sd += (double) bias * bias;
			}
		}
	}
	sd = sd - mean * mean / 255 / 4 / 256 ;
	mean = mean / 255 / 4 / 256;
	sd = sd / (255*4*256-1);
	sd = sqrt(sd);

	printf ( "\nMinimum bias %d, maximum bias %d, max diff prop prob %d/%d\n", min, max, max+INPUTS/256, INPUTS );
	printf ( "Mean: %13.6e, standard deviation: %13.6e\n\n", mean, sd );
}