// Test the pseudo-randomness of the digest.

// Over 2^16 16-bit message values in [0-2^16-1], accumulate the number of hits on values [0,255] from
// each byte of the digest.  The number of values for which a particular hit count is achieved should 
// be Poisson with mean 256.  We can test each distribution with Chi-square.  Since there are 64 results,
// we must expect some low Chi-square tail probabilities - so the overall summary P-value is 
// 1-(1-min(chi-square P-value))^64 - and we reject at the 5% level if the smallest Chi-square tail
// probability is less than 0.00080.

// Extreme numbers of hits should also be highly unlikely, but are not well tested for by Chi-square since
// they are rare and have to be aggregated.  We reject at 5% with k or fewer hits if the chance of getting
// k or fewer hits in 64x2^8 trials should be <5% - so we reject if any count is 186 or less; and 
// similarly at the top end if any count is 333 or greater.

// Bob Hattersley 08Oct08

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Waterfall.h"

static unsigned int hits[64][256];

void main (int argc, char *argv[]) {
	unsigned int in;
	BitSequence out[64];
	int i, j, hit, hitcount[512], min, max, tot;
	hashState hashstate;

	memset(hits, 0, sizeof(hits));

	in = 0;
	do {
		Init(&hashstate, 512);
		Update(&hashstate, (BitSequence *) &in, 16);
		Final(&hashstate, out);

		for(i=0; i<64; i++) {
			if (++hits[i][out[i]] >=512) { printf("512 or more hits on %2.2x in byte %d!\n", out[i], i); exit(0); };
		}
			
	} while (++in<65536);
	printf("\n");

	for (i=0; i<64; i++) {
		memset(hitcount, 0, sizeof(hitcount));
		for (j=0; j<256; j++) {
			hitcount[hits[i][j]]++;
		}

		tot = 0;
		min = 512;
		for (hit=0; hit<224; hit++) {
			if (hitcount[hit]>0 && min>hit) min = hit;
			tot += hitcount[hit];
		}
		printf ("Up to 224\t%d\n", tot);
		printf ("225 to 229\t%d\n", hitcount[225]+hitcount[226]+hitcount[227]+hitcount[228]+hitcount[229]);
		printf ("230 to 232\t%d\n", hitcount[230]+hitcount[231]+hitcount[232]);
		printf ("233 to 235\t%d\n", hitcount[233]+hitcount[234]+hitcount[235]);
		printf ("236 to 237\t%d\n", hitcount[236]+hitcount[237]);
		printf ("238 to 239\t%d\n", hitcount[238]+hitcount[239]);
		printf ("240 to 241\t%d\n", hitcount[240]+hitcount[241]);
		printf ("242 to 243\t%d\n", hitcount[242]+hitcount[243]);
		printf ("244 to 245\t%d\n", hitcount[244]+hitcount[245]);

		for (hit=246; hit<266; hit++) printf("%d\t%d\n", hit, hitcount[hit]);

		printf ("266 to 267\t%d\n", hitcount[266]+hitcount[267]);
		printf ("268 to 269\t%d\n", hitcount[268]+hitcount[269]);
		printf ("270 to 271\t%d\n", hitcount[270]+hitcount[271]);
		printf ("272 to 273\t%d\n", hitcount[272]+hitcount[273]);
		printf ("274 to 275\t%d\n", hitcount[274]+hitcount[275]);
		printf ("276 to 277\t%d\n", hitcount[276]+hitcount[277]);
		printf ("278 to 280\t%d\n", hitcount[278]+hitcount[279]+hitcount[280]);
		printf ("281 to 284\t%d\n", hitcount[281]+hitcount[282]+hitcount[283]+hitcount[284]);
		printf ("285 to 289\t%d\n", hitcount[285]+hitcount[286]+hitcount[287]+hitcount[288]+hitcount[289]);

		tot = 0;
		max = 0;
		for (hit=290; hit<512; hit++) {
			if (hitcount[hit]>0) max = hit;
			tot += hitcount[hit];
		}
		printf ("From 290\t%d\n", tot);
		printf ("Min\t%d\nMax\t%d\n\n", min, max);
	}
}
