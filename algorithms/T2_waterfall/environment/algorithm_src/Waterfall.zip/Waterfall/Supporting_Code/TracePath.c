/*
Program to support the proof of second pre-image resistance in the Waterfall Hash.

A shortest path algorithm over the 2^29 possible Stream states, which may be used for example
to determine the smallest number of steps in a scheme (from where the alternative message 
deviates from the original message to where a collision across the whole state occurs) or the 
smallest distance of a scheme, in the sense of #constraints - #variables.

Each state (over 3 Streams) is represented by a bit field, with one bit for each word of each
stream.  The representation of each stream is rotated so that the most significant bit 
represents the last updated word.  We record only whether the word is converged (same with 
alternative message as with original message) or diverged (different).  The state is used as 
an index into an array of bytes which records only the minimum distance on any path found so 
far back to the zero (all converged) state.

(It would be more efficient to store information about the next step along the shortest path,
except that limited memory prevents this.)

Bob Hattersley 22Sep08
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define OBJ 2				// Minimising: 1 Streams and Pools distance (constraints - variables), 2 Steps
#define STREAMFACT 2		// Factor to apply to Stream constraint/variable = 32/units
#define POOLFACT 1			// Factor to apply to Pool update - half STREAMFACT
#define MAXDIST 126			// Maximum distance we allow at any point (<127, next value means path to zero not yet found)
#define STREAMS 3			// Number of streams
#define BITS1 16			// Bits for Stream = number of words in Stream
#define BITS2 7
#define BITS3 6

#define STEPS (1<<STREAMS)  // Maximum number of next steps (to new Stream states)
#define OFF1 0				// Offsets for stream bits
#define OFF2 (OFF1+BITS1)
#define OFF3 (OFF2+BITS2)
#define MASK1 ((1<<BITS1)-1)				// Masks to identify stream states
#define MASK2 (((1<<BITS2)-1)<<OFF2)
#define MASK3 (((1<<BITS3)-1)<<OFF3)
#define MAXSTATE (1<<BITS1<<BITS2<<BITS3)	// Maximum total number of states = 2^BITS1 * 2^BITS2 * ...

char mindist[(unsigned int)MAXSTATE];		// Minimum distance back to state 0 (eventually)

// Given current state for each stream and new status for current word (1 bit), return the new whole state
int NewState(int istate1, int inew1, int istate2, int inew2, int istate3, int inew3) {
	istate1 >>= 1;
	istate1 |= (inew1 << (BITS1-1));
	istate2 >>= 1;
	istate2 |= (inew2 << (BITS2-1));
	istate3 >>= 1;
	istate3 |= (inew3 << (BITS3-1));
	return(istate1 | (istate2<<OFF2) | (istate3<<OFF3));
}

// Look for next step on shortest route to 0
int CheckSteps(unsigned int istate, unsigned int *pjstate, int *pichoice) {
	int istate1, istate2, istate3;		// Start state divided up between separate streams
	int iprev1, iprev2, iprev3;			// Status in previous position 0=converged, 1=diverged
	int icurr1, icurr2, icurr3;			// Current status in the current position
	int inew1, inew2, inew3;			// New status in the current position
	int inew;							// Loop over combinations of new states
	int idist;							// Distance from old state to new state
	int istream1, istream2, istream3;	// Total differences in each stream, previous position + current position
	int istreamt;						// Sum of differences istream1 + istream2 + istream3
	int istreamp;						// Product (istream1+1)*(istream2+1)*(istream3+1) - distinguishes patterns
	int inewt;							// Total differences in new states
	int iret;							// Return value = new distance to zero
	unsigned int jstate;				// Next state on shortest path

	iret = MAXDIST + 1;

// Extract current state details and derived values
	istate1 = istate & MASK1;
	istate2 = (istate & MASK2) >> OFF2;
	istate3 = (istate & MASK3) >> OFF3;

	iprev1 = istate1 >> (BITS1-1);
	icurr1 = istate1 & 1;
	istream1 = iprev1 + icurr1;

	iprev2 = istate2 >> (BITS2-1);
	icurr2 = istate2 & 1;
	istream2 = iprev2 + icurr2;

	iprev3 = istate3 >> (BITS3-1);
	icurr3 = istate3 & 1;
	istream3 = iprev3 + icurr3;

	istreamt = istream1 + istream2 + istream3;
	istreamp = (istream1+1) * (istream2+1) * (istream3+1);

// Loop over possible new states for current words in each stream
	for (inew=0; inew<STEPS; inew++) {
		inew1 = inew & 1;
		inew2 = (inew & 2) >> 1;
		inew3 = (inew & 4) >> 2;
		idist = 0;

	// The new state we are trying to get to: skip if we haven't got a route from that state to 0 yet
		jstate = NewState(istate1, inew1, istate2, inew2, istate3, inew3);
		if (mindist[jstate]>MAXDIST) continue;

		inewt = inew1 + inew2 + inew3;

	// Always possible to make all three different (add 1 variable)
		if (inewt == 3) {
			idist--;

	// If no current differences - either all diverge (which has been handled) or none (no cost)
		} else if (istreamp == 1) {
			if (inewt != 0) continue;

	// One current difference: either that stream stays diverged (no variable, no constraint), or
	// the other two diverge (one variable, one constraint)
		} else if (istreamp == 2) {
			if (istream1==inew1 && istream2==inew2 && istream3==inew3) {
			} else if (istream1+inew1==1 && istream2+inew2==1 && istream3+inew3==1) {
			} else {
				continue;
			}

	// Two current differences in separate streams: we might converge the two while diverging the 
	// other (one variable, two constraints), or any one can be converged (one variable & one 
	// constraint or no variable & no constraint)
		} else if (istreamp == 4) {
			if (istream1+inew1==1 && istream2+inew2==1 && istream3+inew3==1) {
				idist++;
			} else if (inewt != 2) {
				continue;
			}

	// Two current differences in the same stream: that stream might converge by itself (one 
	// constraint, no variable), or it might stay diverged (no variable, no constraint) or that 
	// stream might converge and the other two diverge (one variable, one constraint)
		} else if (istreamp == 3) {
			if (inewt == 0) {
				idist++;
			} else if (istream1==inew1*2 && istream2==inew2*2 && istream3==inew3*2) {
			} else if (istream1+inew1*2==2 && istream2+inew2*2==2 && istream3+inew3*2==2) {
			} else {
				continue;
			}

	// Three current differences, two in one stream: the stream with two differences might
	// converge by itself (one constraint); we can leave the two diverged (no variable, no
	// constraint), or we can choose one of them to converge (one variable, one constraint); we
	// could converge the two streams with differences (one variable, two constraints), but
	// note that we cannot converge the two streams with fewer than two differences at the same
	// time
		} else if (istreamp == 6) {
			if (inewt == 2) {
			} else if (inewt == 1 && istream1*inew1<2 && istream2*inew2<2 && istream3*inew3<2) {
				idist++;
			} else {
				continue;
			}

	// Otherwise there are differences in all streams, or four differences in two streams: we
	// can converge any one (one constraint, one variable), any two (two constraints, one 
	// variable) or all three (three constraints, one variable). (Same distances with different
	// numbers of constraints/variables in the case of four differences in two streams.)
		} else {
			idist += 2 - inewt;
		}

	// Mode 1 minimises required coincidence level
		if (OBJ==1) {
		// Scale for Stream distance
			idist *= STREAMFACT;

		// Change to Pools - if either Stream 2 or 3 are diverged
			if (inew2) idist += POOLFACT;
			if (inew3) idist += POOLFACT;

	// Mode two - just count number of steps
		} else if (OBJ==2) {
			idist = 1;

		} else {
			exit(0);
		}

	// If new route is shorter than the incumbent, then record it (also count choices of shortest routes)
		if (mindist[jstate] + idist <= iret) {
			if (mindist[jstate] + idist < iret) {
				iret = mindist[jstate] + idist;
				*pjstate = jstate;
				*pichoice = 1;
			} else {
				(*pichoice)++;
			}
		}
	}
	return iret;
}

// Main program
void main () {
	unsigned int istate, jstate;		// Whole old and new states
	int ipass, ichange, itest;
	int i, itop, imin;
	int ichoice;						// Number of choices at this point on the path
	unsigned int distcount[256];

// State zero is different - we don't allow it to go anywhere
	mindist[0] = 0;

// Initialise distances from each state
	for(istate=1; istate<MAXSTATE; istate++) {
		mindist[istate] = MAXDIST + 1;
	}

// Start point is one step away the zero state
	itop = NewState(0, 1, 0, 1, 0, 1);

// Loop indefinitely over the states, looking for ways to get to zero, until no changes occur
	ichange = 1;
	ipass = 0;
	imin = MAXDIST + 1;

	while(ichange && ipass<131072) {
		ichange = 0;
		ipass++;
		printf("Pass %d\n", ipass);
		fflush(stdout);

		for(istate=1; istate<MAXSTATE; istate++) {
			itest = CheckSteps(istate, &jstate, &ichoice);
			if (itest<mindist[istate]) {
				ichange = 1;
				mindist[istate] = itest;
			}
		}

// See if we have found a shorter route from the top back to zero
		if (mindist[itop]<imin) {
			imin = mindist[itop];
			if (OBJ==1) i = 2*POOLFACT - STREAMFACT;
			else if (OBJ==2) i = 1;
			printf("Found one, distance %d\n", mindist[itop]+i);
			if (mindist[itop]+i<0) ichange = 0;
		}
	}

// Done - print a result, which now means checking all the way through for the route
	if (OBJ==1) printf ("Minimising Stream + Pool distance, Stream factor %d, Pool factor %d\n",
																					STREAMFACT, POOLFACT);
	else if (OBJ==2) printf ("Minimising number of steps\n");

	printf("Stream1 %d stream2 %d stream3 %d\n", BITS1, BITS2, BITS3);
	if (OBJ==1) i = i = 2*POOLFACT - STREAMFACT;
	else if (OBJ==2) i = 1;
	printf("Finished after %d passes, minimum distance %d\n", ipass, mindist[itop]+i);

// Start point is really 0 so show it
	ipass = 0;
	istate = 0;
	printf("%4d", ipass);
	printf(" ");
	for(i=0; i<BITS1; i++) {
		printf("%d", (istate>>i)&1);
	}
	printf(" ");
	for(i=OFF2; i<OFF2+BITS2; i++) {
		printf("%d", (istate>>i)&1);
	}
	printf(" ");
	for(i=OFF3; i<OFF3+BITS3; i++) {
		printf("%d", (istate>>i)&1);
	}
	jstate = itop;
	if (OBJ==1) i = 2*POOLFACT - STREAMFACT;
	else if (OBJ==2) i = 1;
	printf(" step %2d total %3d\n", i, mindist[jstate]+i);
	ipass++;

// Subsequent lines
	istate = itop;
	while(istate) {
		printf("%4d", ipass);
		printf(" ");
		for(i=0; i<BITS1; i++) {
			printf("%d", (istate>>i)&1);
		}
		printf(" ");
		for(i=OFF2; i<OFF2+BITS2; i++) {
			printf("%d", (istate>>i)&1);
		}
		printf(" ");
		for(i=OFF3; i<OFF3+BITS3; i++) {
			printf("%d", (istate>>i)&1);
		}

		itest = CheckSteps(istate, &jstate, &ichoice);
		printf(" step %2d total %3d choices %d\n", mindist[istate]-mindist[jstate], mindist[istate], ichoice);

		istate = jstate;
		ipass++;
	}

// Final line is the zero state for completeness
	printf("%4d", ipass);
	printf(" ");
	for(i=0; i<BITS1; i++) {
		printf("%d", (istate>>i)&1);
	}
	printf(" ");
	for(i=OFF2; i<OFF2+BITS2; i++) {
		printf("%d", (istate>>i)&1);
	}
	printf(" ");
	for(i=OFF3; i<OFF3+BITS3; i++) {
		printf("%d", (istate>>i)&1);
	}
	printf("\n");

// Just for interest, how many states are at each distance from zero?
	for (i=0; i<=MAXDIST+1; i++) distcount[i] = 0;
	for (i=0; i<MAXSTATE; i++) distcount[mindist[i]]++;
	printf("\nStates at each distance:\n");
	for (i=0; i<MAXDIST+1; i++) if(distcount[i]) printf("%3d %8d\n", i, distcount[i]);
	printf("States too far away: %d\n", distcount[MAXDIST+1]);
}

