/*
Assess the properties of the X-box substitution - difference propagation extension

We have found a specific one-byte difference propagation and refined that to a difference propagation
from one byte to one word.  This test extends this to find input word differences that have maximum
hits with that output word.

Bob Hattersley 06Oct08
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define SHIFT 5				// Hashing function parameter
#define TABLE (1<<(32-SHIFT))	// Hash table size

	static const unsigned int xboxinv[] = {
		0x6a950052, 0xebb48608, 0x69d70d68, 0xe8f68bd6, 0x6c111a34, 0xed309c33, 0x6f5317a3, 0xee72913f,
		0x669c34b7, 0xe7bdb249, 0x65de39a9, 0xe4ffbf95, 0x60182e8d, 0xe139a8fe, 0x635a23d9, 0xe27ba5f4,
		0x7287686c, 0xf3a6eef2, 0x71c5652b, 0xf0e4e391, 0x7403728f, 0xf522f43a, 0x77417fe9, 0xf660f990,
		0x7e8e5c2c, 0xffafda97, 0x7dcc5159, 0xfcedd75f, 0x780a46d8, 0xf92bc0c3, 0x7b484bf7, 0xfa69cdd4,
		0x5bb15074, 0xda90d65a, 0x58f35db6, 0xd9d2db11, 0x5d354a82, 0xdc14cce7, 0x5e774705, 0xdf56c11a,
		0x57b864c6, 0xd699e265, 0x54fa69bf, 0xd5dbef20, 0x513c7e6e, 0xd01df8d7, 0x527e73ed, 0xd35ff561,
		0x43a33838, 0xc282be1f, 0x40e13593, 0xc1c0b355, 0x4527221c, 0xc406a4ec, 0x46652f12, 0xc744a985,
		0x4faa0c4e, 0xce8b8a62, 0x4ce80198, 0xcdc98772, 0x492e1651, 0xc80f90b6, 0x4a6c1bef, 0xcb4d9d1a,
		0x08dda032, 0x89fc26b9, 0x0b9fadb4, 0x8abe2b27, 0x0e59bac2, 0x8f783c2d, 0x0d1bb7de, 0x8c3a3151,
		0x04d4949c, 0x85f512ed, 0x07969916, 0x86b71f87, 0x02508e11, 0x83710828, 0x011283f8, 0x803305dd,
		0x10cfc83c, 0x91ee4e21, 0x138dc51a, 0x92ac4303, 0x164bd2a9, 0x976a54b8, 0x1509dfef, 0x9428598d,
		0x1cc6fc06, 0x9de77a4c, 0x1f84f11c, 0x9ea5770c, 0x1a42e6fb, 0x9b6360d0, 0x1900ebc3, 0x98216ddb,
		0x39f9f0f0, 0xb8d876b9, 0x3abbfdc9, 0xbb9a7b63, 0x3f7deae8, 0xbe5c6cd9, 0x3c3fe7b5, 0xbd1e616d,
		0x35f0c49f, 0xb4d1428d, 0x36b2c932, 0xb7934f6e, 0x3374ded4, 0xb25558de, 0x3036d32b, 0xb1175569,
		0x21eb98a0, 0xa0ca1e5d, 0x22a9956c, 0xa38813fc, 0x276f82be, 0xa64e044a, 0x242d8f79, 0xa50c0975,
		0x2de2acb9, 0xacc32ad6, 0x2ea0a1c7, 0xaf812778, 0x2b66b67d, 0xaa47306e, 0x2824bbf4, 0xa9053d14,
		0xae0441ba, 0x2f25c710, 0xad464c93, 0x2c67cac2, 0xa8805bcb, 0x29a1dde2, 0xabc2565a, 0x2ae3d06d,
		0xa20d751f, 0x232cf37b, 0xa14f7845, 0x206efe45, 0xa4896f7c, 0x25a8e939, 0xa7cb6268, 0x26eae4fc,
		0xb6162906, 0x3737af3d, 0xb55424e6, 0x3475a2b1, 0xb0923373, 0x31b3b538, 0xb3d03ea3, 0x32f1b812,
		0xba1f1d7a, 0x3b3e9b60, 0xb95d10ad, 0x387c9673, 0xbc9b0780, 0x3dba81e8, 0xbfd90a41, 0x3ef88cf1,
		0x9f2011e7, 0x1e019750, 0x9c621cb8, 0x1d439ad2, 0x99a40bb9, 0x18858d8c, 0x9ae60663, 0x1bc7802e,
		0x932925c7, 0x1208a31e, 0x906b28c8, 0x114aaea5, 0x95ad3f06, 0x148cb9b5, 0x96ef3210, 0x17ceb4b4,
		0x8732794c, 0x0613ffe7, 0x8470748c, 0x0551f2f8, 0x81b66372, 0x0097e567, 0x82f46ecf, 0x03d5e897,
		0x8b3b4d22, 0x0a1acb62, 0x8879407a, 0x0958c645, 0x8dbf57c4, 0x0c9ed170, 0x8efd5ae4, 0x0fdcdc4b,
		0xcc4ce1df, 0x4d6d671c, 0xcf0eec6a, 0x4e2f6af0, 0xcac8fb4c, 0x4be97dc2, 0xc98af601, 0x48ab70f6,
		0xc045d579, 0x416453db, 0xc307d8da, 0x42265e92, 0xc6c1cfeb, 0x47e0494d, 0xc583c222, 0x44a24490,
		0xd45e89b0, 0x557f0f80, 0xd71c84ad, 0x563d027a, 0xd2da93cd, 0x53fb1560, 0xd1989e9c, 0x50b918da,
		0xd857bdf5, 0x59763b3c, 0xdb15b0a0, 0x5a343644, 0xded3a74f, 0x5ff22114, 0xdd91aa42, 0x5cb02c30,
		0xfd68b140, 0x7c493701, 0xfe2abcd9, 0x7f0b3aae, 0xfbecab4a, 0x7acd2dcf, 0xf8aea613, 0x798f2057,
		0xf1618520, 0x70400302, 0xf2238851, 0x73020ed7, 0xf7e59f6f, 0x76c419be, 0xf4a79277, 0x7586148e,
		0xe57ad9e7, 0x645b5fda, 0xe638d4f6, 0x6719528d, 0xe3fec34e, 0x62df4582, 0xe0bcce20, 0x619d48d1,
		0xe973ed19, 0x68526b90, 0xea31e0ee, 0x6b106698, 0xeff7f7a9, 0x6ed671dc, 0xecb5faf2, 0x6d947c82
	};

static unsigned int flags[0x10000000];	// For each input difference, the number of hits up to 3, packed
static unsigned short hits[TABLE];	// Number of hits for each input difference that occurs more than 3 times
static unsigned int hashvalue[TABLE];// Hash table (the non-cryptographic type)

#define GETFLAG(x) (flags[x/16]&(3<<(x%16)))
#define ADDFLAG(x) flags[x/16] += 1<<(x%16);

// Inverse X-box
unsigned int XboxInv (unsigned int out) {
	out = (out<<8) | (out>>24);
	out ^= xboxinv[out & 0xFF];
	out = (out<<8) | (out>>24);
	out ^= xboxinv[out & 0xFF];
	out = (out<<8) | (out>>24);
	out ^= xboxinv[out & 0xFF];
	out = (out<<8) | (out>>24);
	out ^= xboxinv[out & 0xFF];
	return out;
}

void main(int argc, char *argv[]) {
	unsigned int outdiff, out, test, hash;
	int hitcount[65536], i, full, max;

	sscanf_s(argv[1], "%x", &outdiff);
	printf("Outdiff %8.8x\n", outdiff);

	for (i=0; i<TABLE; i++) hits[i] = hashvalue[i] = 0;
	memset(flags, 0, sizeof(flags));

// All possible output values - just store count of entries in the hash table for those with more than three hits
	out = 0;
	do {
		test = XboxInv(out) ^ XboxInv(out ^ outdiff);
		i = GETFLAG(test);
		if(i==3) {

		// Stupid hash function - but that's OK because the values should be very smooth
			hash = (test>>SHIFT) ^ (test&(TABLE-1));

		// Find the entry in the hash table, or add a new one if necessary - stupid hash table, but values should be sparse
			full = 0;
			while(test!=hashvalue[hash]) {
				if(!hashvalue[hash]) {
					hashvalue[hash] = test;
					hits[hash] = 3; // We know this is the fourth time we found this one
					break;
				}
				if(++hash >= TABLE) {
					if (full) { printf("Hash table full!\n"); exit(0); }
					hash = 0;
					full = 1;
				}
			}
			hits[hash]++;
			if(!hits[hash]) { printf("More than 65536 hits!\n"); exit(0); }
		} else {
			ADDFLAG(test);
		}

		if ((out&0xFFFFF) == 0) {
			if ((out&0x3FFFFFF) == 0) printf("\n%8.8x ", out);
			printf(".");
			fflush(stdout);
		}
	} while (++out);
	printf("\n");

// Analysis
	for (i=0; i<65536; i++) hitcount[i] = 0;

	for (i=0; i<TABLE; i++) {
		hitcount[hits[i]]++;
	}

	max = 0;
	for (i=1; i<65536; i++) {
		if (hitcount[i]) {
			printf ("Hits\t%d\tcount\t%d\n", i, hitcount[i]);
			if (i>max) max = i;
		}
	}

	printf("Maximum hits %d\n", max);

	for (i=0; i<TABLE; i++) {
		if(hits[i]==max) printf("Maximum occurs with input difference %8.8x\n", hashvalue[i]);
	}
}