/*
Assess the properties of the X-box substitution - linear correlation

We test only linear relations between one byte and the same byte after a number of X-box applications.
Having found a good relationship for bytes 0 we can then extend that to bytes 0 and 1 together, and 
so on.  Resource availability rules out checking all masks against all masks for all inputs, so we run
the test for a pseudo-random sample (from an LFSR).

Bob Hattersley 06Oct08
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define BYTE 0		// Which byte we are looking at
#define INPUTS 0x1000000 // Number of input values to test

	static const unsigned int xbox[] = {
		0xbb9a4063, 0x2b668d7d, 0xa50c3275, 0xaf811c78, 0xe638eff6, 0xb793746e, 0xb1176e69, 0x4be946c2,
		0x43a30338, 0xebb4bd08, 0xbd1e5a6d, 0xd5dbd420, 0xecb5c1f2, 0x50b923da, 0x114a95a5, 0x242db479,
		0xc307e3da, 0xad467793, 0x416468db, 0xaa470b6e, 0xea31dbee, 0x9de7414c, 0x8c3a0a51, 0xe57ae2e7,
		0x148c82b5, 0xd2daa8cd, 0x9c6227b8, 0x17ce8fb4, 0xbc9b3c80, 0x99a430b9, 0x22a9ae6c, 0xcc4cdadf,
		0x03d5d397, 0x6ed64adc, 0x347599b1, 0x5e777c05, 0x46651412, 0xcb4da61a, 0x619d73d1, 0xc6c1f4eb,
		0x4527191c, 0x1885b68c, 0x7acd16cf, 0x645b64da, 0xa0ca255d, 0xd85786f5, 0xc282851f, 0xf522cf3a,
		0x6c112134, 0x48ab4bf6, 0xd9d2e011, 0x4e2f51f0, 0x7e8e672c, 0xb3d005a3, 0xed30a733, 0xb95d2bad,
		0xee72aa3f, 0x71c55e2b, 0xae047aba, 0xfe2a87d9, 0x730235d7, 0xdf56fa1a, 0x84704f8c, 0xa64e3f4a,
		0xe7bd8949, 0x2c67f1c2, 0x513c456e, 0x7dcc6a59, 0xfcedec5f, 0x3036e82b, 0x1f84ca1c, 0x9f202ae7,
		0x138dfe1a, 0xcdc9bc72, 0xd198a59c, 0x0551c9f8, 0xd699d965, 0x7f0b01ae, 0xd35fce61, 0xa88060cb,
		0x92ac7803, 0x557f3480, 0x6a953b52, 0x76c422be, 0x5bb16b74, 0xeff7cca9, 0x0613c4e7, 0x9ea54c0c,
		0x36b2f232, 0x42266592, 0x8efd61e4, 0xce8bb162, 0x0796a216, 0x0250b511, 0x1cc6c706, 0x44a27f90,
		0xd45eb2b0, 0x75862f8e, 0x906b13c8, 0x6b105d98, 0x8abe1027, 0x83713328, 0xc1c08855, 0x29a1e6e2,
		0x8f78072d, 0x68525090, 0x69d73668, 0xa9050614, 0x10cff33c, 0x492e2d51, 0x3ef8b7f1, 0x93291ec7,
		0x91ee7521, 0x1d43a1d2, 0x08dd9b32, 0x26eadffc, 0xb5541fe6, 0x3dbabae8, 0x4faa374e, 0x62df7e82,
		0x8dbf6cc4, 0x82f455cf, 0xdb158ba0, 0xda90ed5a, 0x7287536c, 0x6d944782, 0x6719698d, 0xd71cbfad,
		0x47e0724d, 0x6018158d, 0xf0e4d891, 0xf7e5a46f, 0x982156db, 0x32f18312, 0x0e5981c2, 0xf660c290,
		0xcac8c04c, 0x1bc7bb2e, 0x282480f4, 0xc80fabb6, 0x3f7dd1e8, 0x9b635bd0, 0xffafe197, 0xa38828fc,
		0x39f9cbf0, 0x2f25fc10, 0x80333edd, 0xded39c4f, 0x58f366b6, 0x54fa52bf, 0xb6161206, 0xa20d4e1f,
		0x0d1b8cde, 0xf4a7a977, 0x8b3b7622, 0x7403498f, 0xdd919142, 0x1900d0c3, 0xe4ff8495, 0x5a340d44,
		0xfd688a40, 0x40e10e93, 0x4ce83a98, 0x65de02a9, 0x85f529ed, 0x6f532ca3, 0x5d357182, 0x1a42ddfb,
		0xcf0ed76a, 0x563d397a, 0x95ad0406, 0x3abbc6c9, 0x3737943d, 0x31b38e38, 0xfbec904a, 0xacc311d6,
		0x798f1b57, 0xc045ee79, 0xc7449285, 0xb25563de, 0x25a8d239, 0x53fb2e60, 0x0112b8f8, 0x1208981e,
		0x3374e5d4, 0x1509e4ef, 0xe3fef84e, 0xf223b351, 0xbe5c57d9, 0x2ea09ac7, 0x96ef0910, 0x669c0fb7,
		0x88797b7a, 0x2de297b9, 0xdc14f7e7, 0x527e48ed, 0x780a7dd8, 0x9ae63d63, 0x81b65872, 0xc98acd01,
		0xf161be20, 0x5ff21a14, 0x276fb9be, 0xfa69f6d4, 0x86b72487, 0x0c9eea70, 0x206ec545, 0xa14f4345,
		0x21eba3a0, 0x4a6c20ef, 0x0097de67, 0x3c3fdcb5, 0x04d4af9c, 0xe8f6b0d6, 0xe0bcf520, 0x635a18d9,
		0xb8d84db9, 0xc4069fec, 0x9428628d, 0x0a1af062, 0xabc26d5a, 0x4d6d5c1c, 0xf92bfbc3, 0xbfd93141,
		0x7c490c01, 0xe973d619, 0xba1f267a, 0xf3a6d5f2, 0xb4d1798d, 0x5976003c, 0xa7cb5968, 0xb0920873,
		0x387cad73, 0x7b4870f7, 0x2ae3eb6d, 0x70403802, 0xc583f922, 0x976a6fb8, 0x57b85fc6, 0x5cb01730,
		0xa489547c, 0x1e01ac50, 0x232cc87b, 0xe13993fe, 0x0fdce74b, 0xf8ae9d13, 0x0b9f96b4, 0x35f0ff9f,
		0x89fc1db9, 0x3b3ea060, 0xd01dc3d7, 0xe27b9ef4, 0x8732424c, 0x164be9a9, 0x0958fd45, 0x774144e9
	};

static unsigned int hits[256][256];	// Number of hits with each possible pair of masks
static unsigned int lfsr = 1;

unsigned int Xbox (unsigned int in) {
	in ^= xbox[in & 0xFF];
	in = (in>>8) | (in<<24);
	in ^= xbox[in & 0xFF];
	in = (in>>8) | (in<<24);
	in ^= xbox[in & 0xFF];
	in = (in>>8) | (in<<24);
	in ^= xbox[in & 0xFF];
	in = (in>>8) | (in<<24);
	return in;
}

unsigned int random(unsigned char bits) {
	unsigned int i, bit;
	i = 0;

	while(bits--) {
		i<<=1;
		bit = lfsr & 1;
		lfsr >>= 1;
		if ( bit ) {
			lfsr ^= 0x8cf3ee80;
			i++;
		}
	}
	return i;
}

void main(int argc, char *argv[]) {
	unsigned int inmask, outmask, istart, in, out, i, j, test1, test2, count;
	int bias, max, maxi, maxj;

	sscanf_s(argv[1], "%x", &inmask);
	sscanf_s(argv[2], "%x", &outmask);
	printf("Byte %d inmask %8.8x outmask %8.8x\n", BYTE, inmask, outmask);

	if (BYTE==0) istart = 1; // Zero input or output byte doesn't make any sense for first byte, but does for the rest
	else istart = 0;

	for (i=0; i<256; i++) for (j=0; j<256; j++) hits[i][j] = 0;

// Loop over input values
	count = 0;
	do {
		in = random(32);
		out = Xbox(in);

// For each pair of input and output masks, check linear relation
		for (i=istart; i<256; i++) {
#if BYTE==0
			test1 = in & i;
#else
			test1 = inmask | i<<(8*BYTE);
			test1 = in & test1;
#endif
			for (j=istart; j<256; j++) {
#if BYTE==0
				test2 = test1 ^ (out&j);
#else
				test2 = outmask | j<<(8*byte);
				test2 = test1 ^ (out & test2);
#endif

// Check parity - we expect number of trials/2 hits or thereabouts - bias either way is important
#if BYTE>1
				test2 ^= test2>>16;
#endif
#if BYTE>0
				test2 ^= test2>>8;
#endif
				test2 ^= test2>>4;
				test2 ^= test2>>2;
				test2 ^= test2>>1;
				hits[i][j] += test2 & 1;
			}
		}

		if ((count&0xFFFFF) == 0) {
			if ((count&0x3FFFFFF) == 0) printf("\n%8.8x ", count);
			printf(".");
			fflush(stdout);
		}
	} while (++count<INPUTS);
	printf("\n");

// Analysis
	max = 0;

	for (i=istart; i<256; i++) {
		for (j=istart; j<256; j++) {
			bias = abs(hits[i][j] - INPUTS/2);
			if (bias > max) {
				max = bias;
				maxi = i;
				maxj = j;
			}
			printf("Masks\t%3d\t%3d\thits\t%d\tbias\t%d\n", i, j, hits[i][j], bias);
		}
	}
	printf ("Maximum bias %d with masks %8.8x %8.8x\n", max, inmask | maxi<<(8*BYTE), outmask | maxj<<(8*BYTE));
}