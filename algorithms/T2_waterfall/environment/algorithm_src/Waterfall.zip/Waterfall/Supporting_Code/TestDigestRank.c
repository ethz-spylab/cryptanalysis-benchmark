// Test the pseudo-randomness of the digest.

// This one tests the rank of 16x16 binary matrices extracted from half the output as the message varies over
// [0,2^28-1].  We learn that a random binary matrix MxQ has rank k with probability:

//      2^(r.(Q+M-r)) . prod(i=0,... r-1) (1-2^(i-Q)).(1-2^(i-M))/(1-2^(i-r))

// Bob Hattersley 08Oct08

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "externs.h"
#include "matrix.h"
#include "Waterfall.h"

// Need to define these just to get the NIST code to link
BitSequence	*epsilon;				// BIT STREAM
TP			tp;						// TEST PARAMETER STRUCTURE
FILE			*stats[NUMOFTESTS+1];	// FILE OUTPUT STREAM
FILE			*results[NUMOFTESTS+1];	// FILE OUTPUT STREAM


void main (int argc, char *argv[]) {
	unsigned int in;
	BitSequence out[64];
	unsigned short *pout;
	int pass, i, j, hits[17], hit;
	BitSequence **matrix;

	for (i=0; i<17; i++) hits[i] = 0;
	matrix = create_matrix(16, 16);

	in = 0;
	do {

		Hash(512, (BitSequence *) &in, 32, out);

// Do it for both halves of the output
		pout = (unsigned short *) out;
		for (pass=0; pass<2; pass++) {

		// Fill the matrix
			for (i=0; i<16; i++) {
				for (j=0; j<16; j++) matrix[i][j] = ((*pout)>>j) & 1;
				pout++;
			}

		// Get the rank and store
			hits[computeRank(16, 16, matrix)]++;
		}

		if ((in&0xFFFFF) == 0) {
			if ((in&0x3FFFFFF) == 0) printf("\n%8.8x ", in);
			printf(".");
			fflush(stdout);
		}
	} while (++in<0x10000000);
	printf("\n");

// Hope we don't have any rank 0!
	for (hit=0; hit<17; hit++) printf("%d\t%d\n", hit, hits[hit]);
}
