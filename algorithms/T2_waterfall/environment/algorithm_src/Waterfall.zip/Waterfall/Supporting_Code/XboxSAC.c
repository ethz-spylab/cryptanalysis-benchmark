// Assess the goodness of the X-box substitution - strict avalanche condition  and bit independence 
// condition between first byte and all bytes

// Bob Hattersley 08Oct08

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define SUBSTEPS 4 // X-box substeps
static unsigned int SAC[8][32];		/* Strict avalanche condition */
static unsigned int BIC[8][32][32];	/* Bit independence condition */

	static const unsigned int xbox[] = {
		0xbb9a4063, 0x2b668d7d, 0xa50c3275, 0xaf811c78, 0xe638eff6, 0xb793746e, 0xb1176e69, 0x4be946c2,
		0x43a30338, 0xebb4bd08, 0xbd1e5a6d, 0xd5dbd420, 0xecb5c1f2, 0x50b923da, 0x114a95a5, 0x242db479,
		0xc307e3da, 0xad467793, 0x416468db, 0xaa470b6e, 0xea31dbee, 0x9de7414c, 0x8c3a0a51, 0xe57ae2e7,
		0x148c82b5, 0xd2daa8cd, 0x9c6227b8, 0x17ce8fb4, 0xbc9b3c80, 0x99a430b9, 0x22a9ae6c, 0xcc4cdadf,
		0x03d5d397, 0x6ed64adc, 0x347599b1, 0x5e777c05, 0x46651412, 0xcb4da61a, 0x619d73d1, 0xc6c1f4eb,
		0x4527191c, 0x1885b68c, 0x7acd16cf, 0x645b64da, 0xa0ca255d, 0xd85786f5, 0xc282851f, 0xf522cf3a,
		0x6c112134, 0x48ab4bf6, 0xd9d2e011, 0x4e2f51f0, 0x7e8e672c, 0xb3d005a3, 0xed30a733, 0xb95d2bad,
		0xee72aa3f, 0x71c55e2b, 0xae047aba, 0xfe2a87d9, 0x730235d7, 0xdf56fa1a, 0x84704f8c, 0xa64e3f4a,
		0xe7bd8949, 0x2c67f1c2, 0x513c456e, 0x7dcc6a59, 0xfcedec5f, 0x3036e82b, 0x1f84ca1c, 0x9f202ae7,
		0x138dfe1a, 0xcdc9bc72, 0xd198a59c, 0x0551c9f8, 0xd699d965, 0x7f0b01ae, 0xd35fce61, 0xa88060cb,
		0x92ac7803, 0x557f3480, 0x6a953b52, 0x76c422be, 0x5bb16b74, 0xeff7cca9, 0x0613c4e7, 0x9ea54c0c,
		0x36b2f232, 0x42266592, 0x8efd61e4, 0xce8bb162, 0x0796a216, 0x0250b511, 0x1cc6c706, 0x44a27f90,
		0xd45eb2b0, 0x75862f8e, 0x906b13c8, 0x6b105d98, 0x8abe1027, 0x83713328, 0xc1c08855, 0x29a1e6e2,
		0x8f78072d, 0x68525090, 0x69d73668, 0xa9050614, 0x10cff33c, 0x492e2d51, 0x3ef8b7f1, 0x93291ec7,
		0x91ee7521, 0x1d43a1d2, 0x08dd9b32, 0x26eadffc, 0xb5541fe6, 0x3dbabae8, 0x4faa374e, 0x62df7e82,
		0x8dbf6cc4, 0x82f455cf, 0xdb158ba0, 0xda90ed5a, 0x7287536c, 0x6d944782, 0x6719698d, 0xd71cbfad,
		0x47e0724d, 0x6018158d, 0xf0e4d891, 0xf7e5a46f, 0x982156db, 0x32f18312, 0x0e5981c2, 0xf660c290,
		0xcac8c04c, 0x1bc7bb2e, 0x282480f4, 0xc80fabb6, 0x3f7dd1e8, 0x9b635bd0, 0xffafe197, 0xa38828fc,
		0x39f9cbf0, 0x2f25fc10, 0x80333edd, 0xded39c4f, 0x58f366b6, 0x54fa52bf, 0xb6161206, 0xa20d4e1f,
		0x0d1b8cde, 0xf4a7a977, 0x8b3b7622, 0x7403498f, 0xdd919142, 0x1900d0c3, 0xe4ff8495, 0x5a340d44,
		0xfd688a40, 0x40e10e93, 0x4ce83a98, 0x65de02a9, 0x85f529ed, 0x6f532ca3, 0x5d357182, 0x1a42ddfb,
		0xcf0ed76a, 0x563d397a, 0x95ad0406, 0x3abbc6c9, 0x3737943d, 0x31b38e38, 0xfbec904a, 0xacc311d6,
		0x798f1b57, 0xc045ee79, 0xc7449285, 0xb25563de, 0x25a8d239, 0x53fb2e60, 0x0112b8f8, 0x1208981e,
		0x3374e5d4, 0x1509e4ef, 0xe3fef84e, 0xf223b351, 0xbe5c57d9, 0x2ea09ac7, 0x96ef0910, 0x669c0fb7,
		0x88797b7a, 0x2de297b9, 0xdc14f7e7, 0x527e48ed, 0x780a7dd8, 0x9ae63d63, 0x81b65872, 0xc98acd01,
		0xf161be20, 0x5ff21a14, 0x276fb9be, 0xfa69f6d4, 0x86b72487, 0x0c9eea70, 0x206ec545, 0xa14f4345,
		0x21eba3a0, 0x4a6c20ef, 0x0097de67, 0x3c3fdcb5, 0x04d4af9c, 0xe8f6b0d6, 0xe0bcf520, 0x635a18d9,
		0xb8d84db9, 0xc4069fec, 0x9428628d, 0x0a1af062, 0xabc26d5a, 0x4d6d5c1c, 0xf92bfbc3, 0xbfd93141,
		0x7c490c01, 0xe973d619, 0xba1f267a, 0xf3a6d5f2, 0xb4d1798d, 0x5976003c, 0xa7cb5968, 0xb0920873,
		0x387cad73, 0x7b4870f7, 0x2ae3eb6d, 0x70403802, 0xc583f922, 0x976a6fb8, 0x57b85fc6, 0x5cb01730,
		0xa489547c, 0x1e01ac50, 0x232cc87b, 0xe13993fe, 0x0fdce74b, 0xf8ae9d13, 0x0b9f96b4, 0x35f0ff9f,
		0x89fc1db9, 0x3b3ea060, 0xd01dc3d7, 0xe27b9ef4, 0x8732424c, 0x164be9a9, 0x0958fd45, 0x774144e9
	};

unsigned int Xbox (unsigned int in) {
	int i;
	for (i=0; i<SUBSTEPS; i++) {
		in ^= xbox[in & 0xFF];
		in = (in>>8) | (in<<24);
	}
	return in;
}

void main(int argc, char *argv[]) {
	int i, j, k;
	unsigned int mask, in, out, diff, min, max;
	double mean, sd;

	for (i=0; i<8; i++) for (j=0; j<32; j++) SAC[i][j] = 0;
	for (i=0; i<8; i++) for (j=0; j<32; j++) for (k=0; k<j; k++) BIC[i][j][k] = 0;

	in = 0;
	do {
		out = Xbox(in);
		for (i=0; i<8; i++) {
			mask = 1<<i;
			if (!(in & mask)) {		// Don't double count
				diff = out ^ Xbox(in^mask);
				for (j=0; j<32; j++) {
					if (diff & (1<<j)) {
						SAC[i][j]++;
						for (k=0; k<j; k++) if ((diff>>k)&1) BIC[i][j][k]++;
					}
				}
			}
		}
		if ((in&0xFFFFF) == 0) {
			if ((in&0x3FFFFFF) == 0) printf("\n%8.8x ", in);
			printf(".");
			fflush(stdout);
		}
	} while (++in);
	printf("\n");

// SAC analysis
	min = 0xFFFFFFFF;
	max = 0;
	mean = 0;
	sd = 0;

	for (i=0; i<8; i++) {
		for (j=0; j<32; j++) {
			if (SAC[i][j] > max) max = SAC[i][j];
			if (SAC[i][j] < min) min = SAC[i][j];
			mean += (double) SAC[i][j];
			sd += ((double) SAC[i][j] - 0x40000000) * ((double) SAC[i][j] - 0x40000000);
			printf("Bit %2d changes bit %2d %12u times\n", i, j, SAC[i][j]);
		}
	}
	mean = mean / 256;
	sd = sd / 256;
	sd = sqrt(sd);

	printf ( "\nMinimum SAC count %d, -%d, maximum SAC count %d, +%d\n", min, 0x40000000-min, max, max-0x40000000 );
	printf ( "Mean: %13.6e, standard deviation: %13.6e\n\n", mean, sd );

// BIC analysis
	min = 0xFFFFFFFF;
	max = 0;
	mean = 0;
	sd = 0;

	for (i=0; i<8; i++) {
		for (j=0; j<32; j++) {
			for (k=0; k<j; k++) {
				if (BIC[i][j][k] > max) max = BIC[i][j][k];
				if (BIC[i][j][k] < min) min = BIC[i][j][k];
				mean += (double) BIC[i][j][k];
				sd += ((double) BIC[i][j][k] - 0x20000000) * ((double) BIC[i][j][k] - 0x20000000);
				printf("Bit %2d changes bit %2d and %2d %12u times\n", i, j, k, BIC[i][j][k]);
			}
		}
	}

	mean = mean / 3968;
	sd = sd / 3968;
	sd = sqrt(sd);
	printf ( "\n\nMinimum BIC count %d, -%d, maximum BIC count %d, +%d\n", min, 0x20000000-min, max, max-0x20000000 );
	printf ( "Mean: %13.6e, standard deviation: %13.6e\n", mean, sd );

}