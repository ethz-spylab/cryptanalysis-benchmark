// Test the pseudo-randomness of the digest.

// Over all 2^32 32-bit message values, accumulate the number of hits on values [0,2^32-1] from one word
// of the digest.  The number of values for which a particular hit count is achieved should be Poisson 
// with mean 1.  We can test each distribution with Chi-square.

// Large number of hits should also be highly unlikely, but are not well tested for by Chi-square since
// they are rare and have to be aggregated.  We reject at 5% with k or more hits if the chance of getting
// k or more hits in 16x2^32 trials should be <5% - so we set k to 15.

// Unfortunately under 32-bit there isn't room for 2^32 values up to 14 even if packed 2 per byte.  So
// we pack two per byte but also do two full passes, throwing away half the values in each half.  (Picking
// up even values first, then odds.)

// Variation - test auto-correlation between values in the same position, offset by a number of calls,
// by counting exclusive-ored values - set constant AUTOCORR to the offset, or zero for base distribution.
// This test failed with offset 1.  Therefore we ran again using the HMAC form.

// Another variation - correlation between two words in the digest - set PARALLEL to the spatial offset.

// Bob Hattersley 10Oct08

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Waterfall.h"

#define AUTOCORR 0	// If doing an auto-correlation test - what is the offset
#define PARALLEL 1	// If checking differences between two words

static unsigned char hits[0x40000000];
#define GETHITS(i) ((i&2) ? hits[i>>2]>>4 : hits[i>>2]&0x0f)
#define ADDHITS(i) \
	if (i&2) hits[i>>2] += 0x10; \
	else hits[i>>2] += 0x01;

void main (int argc, char *argv[]) {
	unsigned int in, val, *pout, *pout2;
	BitSequence out[64], ipad[64], opad[64];
	int pass, word, word2, i, hit, hitcount[16], max;
	hashState hashstate;

#if AUTOCORR
	unsigned int trail[AUTOCORR];
	for (i=0; i<AUTOCORR; i++) trail[i] = 0;	// First few outputs are not auto-correlated but this is not significant
	for (i=0; i<64; i++) { ipad[i]=0x36; opad[i]=0x5c; }	// HMAC data
#endif

	sscanf_s(argv[1], "%d", &word);
	pout = (unsigned int *)out + word;
	word2 = -1;
#if PARALLEL
	sscanf_s(argv[2], "%d", &word2);
	pout2 = (unsigned int *)out + word2;
#endif

	printf("Word %d auto-correlation %d parallel %d\n", word, AUTOCORR, word2);

	for (i=0; i<16; i++) hitcount[i] = 0;

// Lack of memory means we have to take two passes
	for ( pass=0; pass<2; pass++ ) {
		memset(hits, 0, sizeof(hits));

		in = 0;
		do {
#if AUTOCORR
		// For auto-correlation, do the whole HMAC with a zero key
			Init(&hashstate, 512);
			Update(&hashstate, ipad, 512);
			Update(&hashstate, (BitSequence *) &in, 32);
			Final(&hashstate, out);

			Init(&hashstate, 512);
			Update(&hashstate, opad, 512);
			Update(&hashstate, out, 512);
			Final(&hashstate, out);
#else
		// Otherwise just hash
			Hash(512, (BitSequence *) &in, 32, out);
#endif

#if AUTOCORR
			val = *pout ^ trail[0];
			for (i=0; i<AUTOCORR-1; i++) trail[i] = trail[i+1];
			trail[AUTOCORR-1] = *pout;
#elif PARALLEL
			val = *pout ^ *pout2;
#else
			val = *pout;
#endif

		// Throw away half the output values in each pass because of memory problem
			if ((val&1) == pass) {
				if (GETHITS(val)==15) { printf("16 or more hits on %8.8x!\n", val); exit(0); }
				ADDHITS(val)
			}

			if ((in&0xFFFFF) == 0) {
				if ((in&0x3FFFFFF) == 0) printf("\n%8.8x ", in);
				printf(".");
				fflush(stdout);
			}
		} while (++in);
		printf("\n");

		in = 0;
		do {
			hitcount[GETHITS(in)]++;
		} while(++in<0x80000000);
	}

	for (hit=0; hit<11; hit++) printf("%d\t%d\n", hit, hitcount[hit]);

	printf ("From 11\t%d\n", hitcount[11]+hitcount[12]+hitcount[13]+hitcount[14]+hitcount[15]);

	max = 0;
	for (hit=11; hit<16; hit++) if(hitcount[hit]>0) max = hit;
	printf ("Max\t%d\n", max);
}
