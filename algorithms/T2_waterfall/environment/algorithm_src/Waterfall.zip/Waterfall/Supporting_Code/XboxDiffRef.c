/*
Assess the properties of the X-box substitution - difference propagation refinement

We have found a specific difference propagation - from a difference in byte 0 to a difference in one 
output byte.  This test refines this to differences from byte 0 to the whole output word.

Bob Hattersley 06Oct08
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define INDIFF 0xf4			// Difference in input byte 0
#define OUTBYTE 1			// Byte of output difference
#define OUTDIFF 0xdf		// Difference in output byte

	static const unsigned int xbox[] = {
		0xbb9a7b63, 0x2b66b67d, 0xa50c0975, 0xaf812778, 0xe638d4f6, 0xb7934f6e, 0xb1175569, 0x4be97dc2,
		0x43a33838, 0xebb48608, 0xbd1e616d, 0xd5dbef20, 0xecb5faf2, 0x50b918da, 0x114aaea5, 0x242d8f79,
		0xc307d8da, 0xad464c93, 0x416453db, 0xaa47306e, 0xea31e0ee, 0x9de77a4c, 0x8c3a3151, 0xe57ad9e7,
		0x148cb9b5, 0xd2da93cd, 0x9c621cb8, 0x17ceb4b4, 0xbc9b0780, 0x99a40bb9, 0x22a9956c, 0xcc4ce1df,
		0x03d5e897, 0x6ed671dc, 0x3475a2b1, 0x5e774705, 0x46652f12, 0xcb4d9d1a, 0x619d48d1, 0xc6c1cfeb,
		0x4527221c, 0x18858d8c, 0x7acd2dcf, 0x645b5fda, 0xa0ca1e5d, 0xd857bdf5, 0xc282be1f, 0xf522f43a,
		0x6c111a34, 0x48ab70f6, 0xd9d2db11, 0x4e2f6af0, 0x7e8e5c2c, 0xb3d03ea3, 0xed309c33, 0xb95d10ad,
		0xee72913f, 0x71c5652b, 0xae0441ba, 0xfe2abcd9, 0x73020ed7, 0xdf56c11a, 0x8470748c, 0xa64e044a,
		0xe7bdb249, 0x2c67cac2, 0x513c7e6e, 0x7dcc5159, 0xfcedd75f, 0x3036d32b, 0x1f84f11c, 0x9f2011e7,
		0x138dc51a, 0xcdc98772, 0xd1989e9c, 0x0551f2f8, 0xd699e265, 0x7f0b3aae, 0xd35ff561, 0xa8805bcb,
		0x92ac4303, 0x557f0f80, 0x6a950052, 0x76c419be, 0x5bb15074, 0xeff7f7a9, 0x0613ffe7, 0x9ea5770c,
		0x36b2c932, 0x42265e92, 0x8efd5ae4, 0xce8b8a62, 0x07969916, 0x02508e11, 0x1cc6fc06, 0x44a24490,
		0xd45e89b0, 0x7586148e, 0x906b28c8, 0x6b106698, 0x8abe2b27, 0x83710828, 0xc1c0b355, 0x29a1dde2,
		0x8f783c2d, 0x68526b90, 0x69d70d68, 0xa9053d14, 0x10cfc83c, 0x492e1651, 0x3ef88cf1, 0x932925c7,
		0x91ee4e21, 0x1d439ad2, 0x08dda032, 0x26eae4fc, 0xb55424e6, 0x3dba81e8, 0x4faa0c4e, 0x62df4582,
		0x8dbf57c4, 0x82f46ecf, 0xdb15b0a0, 0xda90d65a, 0x7287686c, 0x6d947c82, 0x6719528d, 0xd71c84ad,
		0x47e0494d, 0x60182e8d, 0xf0e4e391, 0xf7e59f6f, 0x98216ddb, 0x32f1b812, 0x0e59bac2, 0xf660f990,
		0xcac8fb4c, 0x1bc7802e, 0x2824bbf4, 0xc80f90b6, 0x3f7deae8, 0x9b6360d0, 0xffafda97, 0xa38813fc,
		0x39f9f0f0, 0x2f25c710, 0x803305dd, 0xded3a74f, 0x58f35db6, 0x54fa69bf, 0xb6162906, 0xa20d751f,
		0x0d1bb7de, 0xf4a79277, 0x8b3b4d22, 0x7403728f, 0xdd91aa42, 0x1900ebc3, 0xe4ffbf95, 0x5a343644,
		0xfd68b140, 0x40e13593, 0x4ce80198, 0x65de39a9, 0x85f512ed, 0x6f5317a3, 0x5d354a82, 0x1a42e6fb,
		0xcf0eec6a, 0x563d027a, 0x95ad3f06, 0x3abbfdc9, 0x3737af3d, 0x31b3b538, 0xfbecab4a, 0xacc32ad6,
		0x798f2057, 0xc045d579, 0xc744a985, 0xb25558de, 0x25a8e939, 0x53fb1560, 0x011283f8, 0x1208a31e,
		0x3374ded4, 0x1509dfef, 0xe3fec34e, 0xf2238851, 0xbe5c6cd9, 0x2ea0a1c7, 0x96ef3210, 0x669c34b7,
		0x8879407a, 0x2de2acb9, 0xdc14cce7, 0x527e73ed, 0x780a46d8, 0x9ae60663, 0x81b66372, 0xc98af601,
		0xf1618520, 0x5ff22114, 0x276f82be, 0xfa69cdd4, 0x86b71f87, 0x0c9ed170, 0x206efe45, 0xa14f7845,
		0x21eb98a0, 0x4a6c1bef, 0x0097e567, 0x3c3fe7b5, 0x04d4949c, 0xe8f68bd6, 0xe0bcce20, 0x635a23d9,
		0xb8d876b9, 0xc406a4ec, 0x9428598d, 0x0a1acb62, 0xabc2565a, 0x4d6d671c, 0xf92bc0c3, 0xbfd90a41,
		0x7c493701, 0xe973ed19, 0xba1f1d7a, 0xf3a6eef2, 0xb4d1428d, 0x59763b3c, 0xa7cb6268, 0xb0923373,
		0x387c9673, 0x7b484bf7, 0x2ae3d06d, 0x70400302, 0xc583c222, 0x976a54b8, 0x57b864c6, 0x5cb02c30,
		0xa4896f7c, 0x1e019750, 0x232cf37b, 0xe139a8fe, 0x0fdcdc4b, 0xf8aea613, 0x0b9fadb4, 0x35f0c49f,
		0x89fc26b9, 0x3b3e9b60, 0xd01df8d7, 0xe27ba5f4, 0x8732794c, 0x164bd2a9, 0x0958c645, 0x77417fe9
	};

static unsigned short hits[16777216];	// Number of hits for each set of output differences in other bytes

unsigned int Xbox (unsigned int in) {
	in ^= xbox[in & 0xFF];
	in = (in>>8) | (in<<24);
	in ^= xbox[in & 0xFF];
	in = (in>>8) | (in<<24);
	in ^= xbox[in & 0xFF];
	in = (in>>8) | (in<<24);
	in ^= xbox[in & 0xFF];
	in = (in>>8) | (in<<24);
	return in;
}

void main() {
	unsigned int in, test, log;
	int hitcount[65536], i, max;

	for (i=0; i<16777216; i++) hits[i] = 0;
	log = 0x3ffffff;

// All possible initial values
	in = 0;
	do {
		test = Xbox(in) ^ Xbox(in ^ INDIFF);

	// Only interested in differences that match our differential
#if OUTBYTE==0
		if ((test&0xff) != OUTDIFF) continue;
#elif OUTBYTE==1
		if ((test&0xff00) != (OUTDIFF<<8)) continue;
#elif OUTBYTE==2
		if ((test&0xff0000) != (OUTDIFF<<16)) continue;
#else
		if ((test&0xff000000) != (OUTDIFF<<24)) continue;
#endif

	// Store a hit
#if OUTBYTE==0
		i = test>>8;
#elif OUTBYTE==1
		i = (test>>8) | (test&0xff);
#elif OUTBYTE==2
		i = ((test&0xff000000)>>8) | (test&0xffff);
#else
		i = test;
#endif

		hits[i]++;
		if(!hits[i]) {
			printf("More than 65536 hits! %8.8x\n", test);
			exit(0);
		}

		if (in>log) {
			printf("%8.8x\n", in);
			log += 0x4000000;
			fflush(stdout);
		}
	} while (++in);

// Analysis
	printf("\nIndiff %2.2x outbyte %d outdiff %2.2x\n", INDIFF, OUTBYTE, OUTDIFF);
	for (i=0; i<65536; i++) hitcount[i] = 0;

	for (i=0; i<16777216; i++) {
		hitcount[hits[i]]++;
	}

	max = 0;
	for (i=0; i<65536; i++) {
		if (hitcount[i]) {
			printf ("Hits\t%d\tcount\t%d\n", i, hitcount[i]);
			if (i>max) max = i;
		}
	}

	for (i=0; i<16777216; i++) {
		if(hits[i]==max) {
#if OUTBYTE==0
			test = i<<8 | OUTDIFF; 
#elif OUTBYTE==1
			test = ((i&0xffff00)<<8) | (OUTDIFF<<8) | (i & 0xff);
#elif OUTBYTE==2
			test = ((i&0xff0000)<<8) | (OUTDIFF<<16) | (i&0xffff);
#else
			test = (OUTDIFF<<24) | i;
#endif			
			printf("Maximum %d occurs with difference %8.8x\n", max, test);
		}
	}
}