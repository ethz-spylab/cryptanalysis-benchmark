/*
Waterfall Hash Algorithm version 1.7 8-bit small version A

Generates a fixed length message digest of up to 512 bits in 32-bit increments from an 
unlimited-length message, with resistance to a range of cryptographic attacks.

The 8-bit version uses only chars to estimate the size and performance on an 8-bit processor.  It assumes
a little-endian byte order in each word.  This small variant calculates 3 of the 4 bytes in each X-box
entry on the fly to reduce program storage to below 2KB.

See "Waterfall Hash Design 1.0" for details.

Bob Hattersley 12Oct08
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include "Waterfall.h"

#define FINALUPDATES 16 // Number of Update Steps in Final with fixed input
#define FINALSTEPS 4	// Number of Final Steps in Final after combining with Pools

#define DEBUG 0  // 0: no output, 1: API calls, 2: input, main step results, 3: full processing breakdown

#if DEBUG>0
#include <stdio.h>
#endif

// Rijndael S-box
static const unsigned char sbox[256] = {
	0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
	0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
	0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
	0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
	0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
	0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
	0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
	0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
	0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
	0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
	0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
	0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
	0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
	0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
	0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
	0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
};


// -------------------------------------------------------------------------------------------------

// API routine to initialise hash algorithm state and check required message digest length

HashReturn Init ( hashState *state, int hashbitlen ) {
	unsigned char i;

// Check message digest length is valid (whole 32-bit words, at most 16 of them)
	if (hashbitlen<=0 || hashbitlen>512 || hashbitlen%32) return BAD_HASHBITLEN;
	state->hashbitlen = hashbitlen;

// Initialise input buffer to empty
	state->inputbits = 0;
	state->inputbytes = 0;
	for (i=0; i<4; i++) {
		state->inputblocks[i] = 0;
		state->inputslabs[i] = 0;
	}

// Put the digest length into the first word of Stream 2 (Stream 1 may be used for a key)
	state->stream2[0] = hashbitlen & 0xff;
	state->stream2[1] = hashbitlen >> 8;

// Initialise Streams to zeros
	for (i=0; i<STREAM1*4; i++) state->stream1[i] = 0;
	state->pstream1 = state->stream1 + STREAM1*4 - 4;
	for (i=2; i<STREAM2*4; i++) state->stream2[i] = 0;
	state->pstream2 = state->stream2 +  STREAM2*4 - 4;
	for (i=0; i<STREAM3*4; i++) state->stream3[i] = 0;
	state->pstream3 = state->stream3 +  STREAM3*4 - 4;

// Initialise Pools to zeros
	for (i=0; i<POOL*4; i++) state->pool2[i] = 0;
	state->ppool2 = state->pool2 + POOL*4 - 4;
	for (i=0; i<POOL*4; i++) state->pool3[i] = 0;
	state->ppool3 = state->pool3 + POOL*4 - 4;

#if DEBUG>0
	printf("Waterfall initialised: hashbitlen %d\n", hashbitlen);
#endif
	return SUCCESS;
}

// -------------------------------------------------------------------------------------------------

// Perform the X-box 32-bit to 32-bit substitution making sure that each byte (almost certainly)
// depends on every byte

static void Xbox ( unsigned char *pword ) {
	unsigned char work1, work2;

#if DEBUG>2
	printf("  X-box steps: %2.2x%2.2x%2.2x%2.2x", *(pword+3), *(pword+2), *(pword+1), *pword);
#endif
	work1 = sbox[*(pword+0)];
	*(pword+0) = work1;
	work2 = work1 ^ (work1<<2) ^ (work1>>6) ^ (work1<<3);
	*(pword+1) ^= (work2<<7) | (work2>>1) ^ 0x3b;
	*(pword+2) ^= work1 ^ (work1<<5) ^ (work1>>3) ^ (work1>>7) ^ 0x95;
	*(pword+3) ^= work1 ^ (work1<<7) ^ (work1>>1) ^ (work1>>5) ^ 0x6a;

#if DEBUG>2
	printf(" %2.2x%2.2x%2.2x%2.2x", *pword, *(pword+3), *(pword+2), *(pword+1));
#endif

	work1 = sbox[*(pword+1)];
	*(pword+1) = work1;
	work2 = work1 ^ (work1<<2) ^ (work1>>6) ^ (work1<<3);
	*(pword+2) ^= (work2<<7) | (work2>>1) ^ 0x3b;
	*(pword+3) ^= work1 ^ (work1<<5) ^ (work1>>3) ^ (work1>>7) ^ 0x95;
	*(pword+0) ^= work1 ^ (work1<<7) ^ (work1>>1) ^ (work1>>5) ^ 0x6a;

#if DEBUG>2
	printf(" %2.2x%2.2x%2.2x%2.2x", *(pword+1), *pword, *(pword+3), *(pword+2));
#endif

	work1 = sbox[*(pword+2)];
	*(pword+2) = work1;
	work2 = work1 ^ (work1<<2) ^ (work1>>6) ^ (work1<<3);
	*(pword+3) ^= (work2<<7) | (work2>>1) ^ 0x3b;
	*(pword+0) ^= work1 ^ (work1<<5) ^ (work1>>3) ^ (work1>>7) ^ 0x95;
	*(pword+1) ^= work1 ^ (work1<<7) ^ (work1>>1) ^ (work1>>5) ^ 0x6a;

#if DEBUG>2
	printf(" %2.2x%2.2x%2.2x%2.2x", *(pword+2), *(pword+1), *pword, *(pword+3));
#endif

	work1 = sbox[*(pword+3)];
	*(pword+3) = work1;
	work2 = work1 ^ (work1<<2) ^ (work1>>6) ^ (work1<<3);
	*(pword+0) ^= (work2<<7) | (work2>>1) ^ 0x3b;
	*(pword+1) ^= work1 ^ (work1<<5) ^ (work1>>3) ^ (work1>>7) ^ 0x95;
	*(pword+2) ^= work1 ^ (work1<<7) ^ (work1>>1) ^ (work1>>5) ^ 0x6a;

#if DEBUG>2
	printf(" %2.2x%2.2x%2.2x%2.2x\n", *(pword+3), *(pword+2), *(pword+1), *pword);
#endif
}

// -------------------------------------------------------------------------------------------------

// Copy a word from one place to another

static void CopyWord ( unsigned char *pto, const unsigned char *pfrom ) {
	*pto++ = *pfrom++;
	*pto++ = *pfrom++;
	*pto++ = *pfrom++;
	*pto = *pfrom;
}

// -------------------------------------------------------------------------------------------------

// Exclusive-or a word from one place onto another

static void XorWord ( unsigned char *pto, const unsigned char *pfrom ) {
	*pto++ ^= *pfrom++;
	*pto++ ^= *pfrom++;
	*pto++ ^= *pfrom++;
	*pto ^= *pfrom;
}

// -------------------------------------------------------------------------------------------------

// Perform a single update step given an input word

static void UpdateStep ( hashState *state, const unsigned char *pinput ) {
	unsigned char word1[4], word2[4], word3[4];

#if DEBUG>1
	printf(" Update step input %2.2x%2.2x%2.2x%2.2x\n", *(pinput+3), *(pinput+2), *(pinput+1), *pinput);
#endif

// Extract previous entries from Streams
	CopyWord(word1, state->pstream1);
	CopyWord(word2, state->pstream2);
	CopyWord(word3, state->pstream3);

#if DEBUG>2
	printf("  Previous stream values %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x\n", 
		word1[3], word1[2], word1[1], word1[0], word2[3], word2[2], word2[1], word2[0], word3[3], word3[2], word3[1], word3[0]);
#endif

// Advance Stream positions rotationally
	state->pstream1 += 4;
	if (state->pstream1 == state->stream1+STREAM1*4) state->pstream1 = state->stream1;
	state->pstream2 += 4;
	if (state->pstream2 == state->stream2+STREAM2*4) state->pstream2 = state->stream2;
	state->pstream3 += 4;
	if (state->pstream3 == state->stream3+STREAM3*4) state->pstream3 = state->stream3;

#if DEBUG>2
	printf("  Current stream positions %d %d %d\n", (state->pstream1-state->stream1)/4,
			(state->pstream2-state->stream2)/4, (state->pstream3-state->stream3)/4);
	printf("  Current stream values  %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x\n",
			*(state->pstream1+3), *(state->pstream1+2), *(state->pstream1+1), *state->pstream1, 
			*(state->pstream2+3), *(state->pstream2+2), *(state->pstream2+1), *state->pstream2, 
			*(state->pstream3+3), *(state->pstream3+2), *(state->pstream3+1), *state->pstream3);
#endif

// Update the current position in each Stream using the input word and the previous entry, using the X-box
// for non-linearity and mixing in the word
	XorWord(state->pstream1, word1);
	XorWord(state->pstream1, pinput);
	Xbox(state->pstream1);

	word2[0] ^= 1;
	XorWord(state->pstream2, word2);
	XorWord(state->pstream2, pinput);
	Xbox(state->pstream2);

	word3[0] ^= 2;
	XorWord(state->pstream3, word3);
	XorWord(state->pstream3, pinput);
	Xbox(state->pstream3);

#if DEBUG>2
	printf("  New stream values      %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x\n",
			*(state->pstream1+3), *(state->pstream1+2), *(state->pstream1+1), *state->pstream1, 
			*(state->pstream2+3), *(state->pstream2+2), *(state->pstream2+1), *state->pstream2, 
			*(state->pstream3+3), *(state->pstream3+2), *(state->pstream3+1), *state->pstream3);
#endif

// Update Pools 2 and 3 from the current words in Stream 2 and 3 with simple exclusive-or
	state->ppool2 +=4;
	if(state->ppool2==state->pool2+POOL*4) {
		state->ppool2 = state->pool2;
		state->ppool3 = state->pool3;
	} else {
		state->ppool3 += 4;
	}
	XorWord(state->ppool2, state->pstream2);
	XorWord(state->ppool3, state->pstream3);

#if DEBUG>2
	printf("  New pool values at %d: %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x\n", (state->ppool2-state->pool2)/4,
			*(state->ppool2+3), *(state->ppool2+2), *(state->ppool2+1), *state->ppool2, 
			*(state->ppool3+3), *(state->ppool3+2), *(state->ppool3+1), *state->ppool3);
#endif
}

// -------------------------------------------------------------------------------------------------

// Add one block - but we are storing effectively a long long in bytes

static void AddBlock ( hashState *state ) {
	if (!++state->inputblocks[0]) {
		if (!++state->inputblocks[1]) {
			if (!++state->inputblocks[2]) {
				if (!++state->inputblocks[3]) {
					if (!++state->inputslabs[0]) {
						if (!++state->inputslabs[1]) {
							if (!++state->inputslabs[2]) state->inputslabs[3]++;
						}
					}
				}
			}
		}
	}
}

// -------------------------------------------------------------------------------------------------

// API routine to process some passed data into the hash state

HashReturn Update ( hashState *state, const BitSequence *data, DataLength databitlen ) {
	unsigned long long left;
	unsigned char i, ibuff, bits, j;
	const unsigned char *pinput;
	unsigned char last;

#if DEBUG>0
	printf("Update: databitlen %d\n", databitlen);
#endif

// Number of bytes left in the input data
	left = databitlen / 8;

// If there is something in the buffer, fill up the buffer first
	ibuff = state->inputbytes;

	if (ibuff) {
		while (ibuff<64 && left>0) {
#if DEBUG>2
			printf("  Input byte %2.2x\n", *data);
#endif
			state->inputbuffer[ibuff++] = *data++;
			left--;
		}

// If the buffer is now full, process the buffer, then mark it empty
		if (ibuff==64) {
			pinput = state->inputbuffer;
			for (j=0; j<16; j++) {
				UpdateStep(state, pinput);
				pinput += 4;
			}
			AddBlock(state);
			UpdateStep(state, state->inputblocks);
			state->inputbytes = 0;
			ibuff = 0;
		}
	}

// Pointer to the rest of the data
	pinput = data;

// If there is something left in the input data, process as many whole blocks as we can
	while (left>=64) {
		for (j=0; j<16; j++) {
#if DEBUG>2
		printf("  Input byte %2.2x\n  Input byte %2.2x\n  Input byte %2.2x\n  Input byte %2.2x\n",
				*pinput, *(pinput+1), *(pinput+2), *(pinput+3));
#endif
			UpdateStep(state, pinput);
			pinput += 4;
		}
		AddBlock(state);
		UpdateStep(state, state->inputblocks);
		left -= 64;
	}

// Copy remaining whole bytes into the buffer
	data = pinput;
	while (left) {
#if DEBUG>2
		printf("  Input byte %2.2x\n", *data);
#endif
		state->inputbuffer[ibuff++] = *data++;
		left--;
	}
	state->inputbytes = ibuff;

// Handle a part of a byte (only in the last update) - zero least significant bits before storing
	bits = (unsigned char) (databitlen % 8);
	if (bits) {
		last = *data;
		last >>= 8-bits;
		last <<= 8-bits;
#if DEBUG>2
		printf("  Input partial byte %2.2x %d\n", last, bits);
#endif
		state->inputbuffer[ibuff] = last;
		state->inputbits = bits;
	}

#if DEBUG>1
	printf(" Stream 1:\n");
	for(i=0; i<STREAM1*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->stream1[i+3], state->stream1[i+2], state->stream1[i+1], state->stream1[i]);
		if((i&31)==28) printf("\n");
	}
	printf(" Stream 2:\n ");
	for(i=0; i<STREAM2*4; i+=4) printf(" %2.2x%2.2x%2.2x%2.2x", state->stream2[i+3], state->stream2[i+2], state->stream2[i+1], state->stream2[i]);
	printf("\n");
	printf(" Stream 3:\n ");
	for(i=0; i<STREAM3*4; i+=4) printf(" %2.2x%2.2x%2.2x%2.2x", state->stream3[i+3], state->stream3[i+2], state->stream3[i+1], state->stream3[i]);
	printf("\n");
	printf(" Pool 2:\n");
	for(i=0; i<POOL*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->pool2[i+3], state->pool2[i+2], state->pool2[i+1], state->pool2[i]);
		if((i&31)==28) printf("\n");
	}
	printf(" Pool 3:\n");
	for(i=0; i<POOL*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->pool3[i+3], state->pool3[i+2], state->pool3[i+1], state->pool3[i]);
		if((i&31)==28) printf("\n");
	}
#endif

	return SUCCESS;
}

// -------------------------------------------------------------------------------------------------

// Use a part of a Pool to to process a copy of Stream 1

#define WORK (STREAM1*4)

static void FinalStep ( unsigned char *pworkin, unsigned char *ppool, unsigned char *pworkout ) {
	unsigned char i, *pw, *p1, *p2, *p3, *p4;

// Swap bits rotationally between elements of the array
	for (i=0; i<STREAM1; i++) {
		pworkout[i] = (pworkin[i] & 0x14141414) | (pworkin[(i+3)%STREAM1] & 0x28282828) | 
					(pworkin[(i+7)%STREAM1] & 0x42424242) | (pworkin[(i+12)%STREAM1] & 0x81818181);
	}
// Swap bits rotationally between elements of the arrays
	pw = pworkout;
	p1 = pworkin;
	p2 = pworkin + 12;
	p3 = pworkin + 28;
	p4 = pworkin + 48;
	do {
		*pw = (*p1 & 0x14) | (*p2 & 0x28) | (*p3 & 0x42) | (*p4 & 0x81);
		if(++p1>=pworkin+WORK) p1 = pworkin;
		if(++p2>=pworkin+WORK) p2 = pworkin;
		if(++p3>=pworkin+WORK) p3 = pworkin;
		if(++p4>=pworkin+WORK) p4 = pworkin;
	} while (++pw < pworkout+WORK);

#if DEBUG>2
	printf("  Bits swapped:\n");
	for(i=0; i<WORK; i+=4) {
		if((i&31)==0) printf("  ");
		printf(" %2.2x%2.2x%2.2x%2.2x", pworkout[i+3], pworkout[i+2], pworkout[i+1], pworkout[i]);
		if((i&31)==28) printf("\n");
	}
#endif

// Apply the X-box to each word
	for (i=0; i<WORK; i+=4) Xbox(&pworkout[i]);

#if DEBUG>2
	printf("  X-box applied:\n");
	for(i=0; i<WORK; i+=4) {
		if((i&31)==0) printf("  ");
		printf(" %2.2x%2.2x%2.2x%2.2x", pworkout[i+3], pworkout[i+2], pworkout[i+1], pworkout[i]);
		if((i&31)==28) printf("\n");
	}
#endif

// If it is passed, exclusive-or a section of a Pool into the copy of Stream 1
	if (ppool != NULL) for (i=0; i<WORK; i++) pworkout[i] ^= ppool[i];

#if DEBUG>2
	printf("  Masked:\n");
	for(i=0; i<WORK; i+=4) {
		if((i&31)==0) printf("  ");
		printf(" %2.2x%2.2x%2.2x%2.2x", pworkout[i+3], pworkout[i+2], pworkout[i+1], pworkout[i]);
		if((i&31)==28) printf("\n");
	}
#endif
}

// -------------------------------------------------------------------------------------------------

// API routine to complete the algorithm and return the message digest

HashReturn Final ( hashState *state, BitSequence *hashval ) {
	unsigned char i, pass, *pinput, *pworkin, *pworkout, *pwork, *ppool;
	unsigned char inputbits[4];

#if DEBUG>0
	printf("Final\n");
#endif

// May need to process the contents of the input buffer
	if (state->inputbits || state->inputbytes) {

	// Zero the end of the buffer (we don't want data going in twice)
		i = state->inputbytes + (state->inputbits+7) / 8;
		for(; i<64; i++) state->inputbuffer[i] = 0;

	// Process the buffer
		pinput = state->inputbuffer;
		for (i=0; i<16; i++) {
			UpdateStep(state, pinput);
			pinput += 4;
		}
		AddBlock(state);
		UpdateStep(state, state->inputblocks);
	}

// Always process the bit count and slab count
	inputbits[0] = state->inputbits + (state->inputbytes<<3);
	inputbits[1] = state->inputbytes>>5;
	inputbits[2] = 0;
	inputbits[3] = 0;
	UpdateStep(state, inputbits);
	UpdateStep(state, state->inputslabs);

// Perform 16 update steps with fixed input
	inputbits[1] = 0;
	for(i=0; i<FINALUPDATES; i++) {
		inputbits[0] = i;
		UpdateStep(state, inputbits);
	}

#if DEBUG>1
	printf(" Stream 1 after input:\n");
	for(i=0; i<STREAM1*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->stream1[i+3], state->stream1[i+2], state->stream1[i+1], state->stream1[i]);
		if((i&31)==28) printf("\n");
	}
	printf(" Stream 2 after input:\n ");
	for(i=0; i<STREAM2*4; i+=4) printf(" %2.2x%2.2x%2.2x%2.2x", state->stream2[i+3], state->stream2[i+2], state->stream2[i+1], state->stream2[i]);
	printf("\n");
	printf(" Stream 3 after input:\n ");
	for(i=0; i<STREAM3*4; i+=4) printf(" %2.2x%2.2x%2.2x%2.2x", state->stream3[i+3], state->stream3[i+2], state->stream3[i+1], state->stream3[i]);
	printf("\n");
	printf(" Pool 2 after input:\n");
	for(i=0; i<POOL*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->pool2[i+3], state->pool2[i+2], state->pool2[i+1], state->pool2[i]);
		if((i&31)==28) printf("\n");
	}
	printf(" Pool 3 after input:\n");
	for(i=0; i<POOL*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->pool3[i+3], state->pool3[i+2], state->pool3[i+1], state->pool3[i]);
		if((i&31)==28) printf("\n");
	}
#endif

// Take a copy of Stream 1
	for(i=0; i<WORK; i++) state->inputbuffer[i] = state->stream1[i];

// Work arrays are used alternately as input and output
	pworkin = state->inputbuffer;
	pworkout = state->stream2;  // Note we have made sure there is enough room in the hashState struct for 64 bytes here

// Perform mangling steps, combining with Pool 2
	ppool = state->pool2;
	for(pass=0; pass<POOLFACTOR; pass++) {
#if DEBUG>1
		printf(" Combining with Pool 2 pass %d\n", pass);
#endif
		FinalStep(pworkin, ppool, pworkout);
		pwork = pworkin;
		pworkin = pworkout;
		pworkout = pwork;
		ppool += WORK;
	}
	
// Same with Pool 3
	ppool = state->pool3;
	for(pass=0; pass<POOLFACTOR; pass++) {
#if DEBUG>1
		printf(" Combining with Pool 3 pass %d\n", pass);
#endif
		FinalStep(pworkin, ppool, pworkout);
		pwork = pworkin;
		pworkin = pworkout;
		pworkout = pwork;
		ppool += WORK;
	}

// Same steps but with no Pool data
	for(pass=0; pass<FINALSTEPS; pass++) {
#if DEBUG>1
		printf(" Mixing without Pools pass %d\n", pass);
#endif
		FinalStep(pworkin, NULL, pworkout);
		pwork = pworkin;
		pworkin = pworkout;
		pworkout = pwork;
	}

#if DEBUG>1
	printf(" Mangled copy of Stream 1:\n");
	for(i=0; i<WORK; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", pworkin[i+3], pworkin[i+2], pworkin[i+1], pworkin[i]);
		if((i&31)==28) printf("\n");
	}
#endif

// Exclusive-or the mangled copy of Stream 1 with Stream 1
	for(i=0; i<WORK; i++) pworkin[i] ^= state->stream1[i];

// And with each section of each Pool to make Final one-way with respect to each of these
	ppool = state->pool2;
	for(pass=0; pass<POOLFACTOR; pass++) {
		for(i=0; i<WORK; i++) pworkin[i] ^= ppool[i];
		ppool += WORK;
	}

	ppool = state->pool3;
	for(pass=0; pass<POOLFACTOR; pass++) {
		for(i=0; i<WORK; i++) pworkin[i] ^= ppool[i];
		ppool += WORK;
	}
	
#if DEBUG>1
	printf(" Final digest:\n");
	for(i=0; i<WORK; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", pworkin[i+3], pworkin[i+2], pworkin[i+1], pworkin[i]);
		if((i&31)==28) printf("\n");
	}
#endif

// Return all the bytes required (little-endian transfer)
	for(i=0; i<(state->hashbitlen/8); i++) hashval[i] = pworkin[i];
	return SUCCESS;
}

// -------------------------------------------------------------------------------------------------

// Perform the complete hash process in one call

HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen,
				BitSequence *hashval) {
	HashReturn ret;
	hashState state;

	ret = Init(&state, hashbitlen);
	if (ret != SUCCESS) return ret;

	ret = Update(&state, data, databitlen);
	if (ret != SUCCESS) return ret;

	ret = Final(&state, hashval);
	return ret;
}