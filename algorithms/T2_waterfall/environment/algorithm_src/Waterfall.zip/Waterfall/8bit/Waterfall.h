/*
Waterfall Hash Algorithm 1.7 8-bit version A

Include file to define data types and function prototypes.  See Waterfall.c for details.

Bob Hattersley 09Oct08
*/

#ifndef __WATERFALL_H__
#define __WATERFALL_H__

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

typedef unsigned char BitSequence;		// Data type of input data
typedef unsigned long long DataLength;	// Data type for input data length in bits
typedef enum { SUCCESS = 0, FAIL = 1, BAD_HASHBITLEN = 2 } HashReturn;	// Returns from functions

#define STREAM1 16					// Stream lengths (32-bit words)
#define STREAM2 7
#define STREAM3 6
#define POOLFACTOR 2				// Length of each Pool as a multiple of Stream 1
#define POOL (STREAM1*POOLFACTOR)	// Pool lengths (32-bit words)

// Structure to hold Waterfall Hash state data
typedef struct {
	unsigned int hashbitlen;		// Requested number of bits in message digest

	unsigned char inputbuffer[64];	// Input buffer of 512 bits

	unsigned char stream1[STREAM1*4];	// Stream 1
	unsigned char stream2[STREAM2*4];	// Stream 2
	unsigned char stream3[STREAM3*4];	// Stream 3

// Note that we have reordered so that we can use Stream 2 onwards as a work array in Final ... assuming
// pointers would be 16-bit we do not need any further padding
	unsigned char inputbytes;		// Number of whole bytes currently in buffer
	unsigned char inputbits;		// Number of bits currently in last partial byte
	unsigned char inputblocks[4];	// Number of blocks of input (512 bits) currently processed
	unsigned char inputslabs[4];	// Number of slabs of input (2^41 bits) currently processed

	unsigned char *pstream1;		// Pointer into Stream 1
	unsigned char *pstream2;		// Pointer into Stream 2
	unsigned char *pstream3;		// Pointer into Stream 3
	unsigned char *ppool2;			// Pointer into Pool 2
	unsigned char *ppool3;			// Pointer into Pool 3

	unsigned char pool2[POOL*4];		// Pool 2 - NB there is no Pool 1
	unsigned char pool3[POOL*4];		// Pool 3
} hashState;

// Function prototypes
HashReturn Init(hashState *state, int hashbitlen);										// Initialisation
HashReturn Update(hashState *state, const BitSequence *data, DataLength databitlen);	// Update state data with input
HashReturn Final(hashState *state, BitSequence *hashval);								// Return message digest
HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen,
				BitSequence *hashval);													// Do it all at once

#ifdef __cplusplus
}
#endif

#endif // __WATERFALL_H__
