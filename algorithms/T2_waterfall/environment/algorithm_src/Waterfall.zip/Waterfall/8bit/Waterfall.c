/*
Waterfall Hash Algorithm version 1.7 8-bit version A

Generates a fixed length message digest of up to 512 bits in 32-bit increments from an 
unlimited-length message, with resistance to a range of cryptographic attacks.

The 8-bit version uses only chars to estimate the size and performance on an 8-bit processor.  It assumes
a little-endian byte order in each word.

See "Waterfall Specification 1.0" for details.

Bob Hattersley 12Oct08
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include "Waterfall.h"

#define FINALUPDATES 16 // Number of Update Steps in Final with fixed input
#define FINALSTEPS 4	// Number of Final Steps in Final after combining with Pools

#define DEBUG 0  // 0: no output, 1: API calls, 2: input, main step results, 3: full processing breakdown

#if DEBUG>0
#include <stdio.h>
#endif

// X-box calculated from Rijndael S-box
	static const unsigned char xbox[] = {
		0x63, 0x40, 0x9a, 0xbb, 0x7d, 0x8d, 0x66, 0x2b, 0x75, 0x32, 0x0c, 0xa5, 0x78, 0x1c, 0x81, 0xaf,
		0xf6, 0xef, 0x38, 0xe6, 0x6e, 0x74, 0x93, 0xb7, 0x69, 0x6e, 0x17, 0xb1, 0xc2, 0x46, 0xe9, 0x4b,
		0x38, 0x03, 0xa3, 0x43, 0x08, 0xbd, 0xb4, 0xeb, 0x6d, 0x5a, 0x1e, 0xbd, 0x20, 0xd4, 0xdb, 0xd5,
		0xf2, 0xc1, 0xb5, 0xec, 0xda, 0x23, 0xb9, 0x50, 0xa5, 0x95, 0x4a, 0x11, 0x79, 0xb4, 0x2d, 0x24,
		0xda, 0xe3, 0x07, 0xc3, 0x93, 0x77, 0x46, 0xad, 0xdb, 0x68, 0x64, 0x41, 0x6e, 0x0b, 0x47, 0xaa,
		0xee, 0xdb, 0x31, 0xea, 0x4c, 0x41, 0xe7, 0x9d, 0x51, 0x0a, 0x3a, 0x8c, 0xe7, 0xe2, 0x7a, 0xe5,
		0xb5, 0x82, 0x8c, 0x14, 0xcd, 0xa8, 0xda, 0xd2, 0xb8, 0x27, 0x62, 0x9c, 0xb4, 0x8f, 0xce, 0x17,
		0x80, 0x3c, 0x9b, 0xbc, 0xb9, 0x30, 0xa4, 0x99, 0x6c, 0xae, 0xa9, 0x22, 0xdf, 0xda, 0x4c, 0xcc,
		0x97, 0xd3, 0xd5, 0x03, 0xdc, 0x4a, 0xd6, 0x6e, 0xb1, 0x99, 0x75, 0x34, 0x05, 0x7c, 0x77, 0x5e,
		0x12, 0x14, 0x65, 0x46, 0x1a, 0xa6, 0x4d, 0xcb, 0xd1, 0x73, 0x9d, 0x61, 0xeb, 0xf4, 0xc1, 0xc6,
		0x1c, 0x19, 0x27, 0x45, 0x8c, 0xb6, 0x85, 0x18, 0xcf, 0x16, 0xcd, 0x7a, 0xda, 0x64, 0x5b, 0x64,
		0x5d, 0x25, 0xca, 0xa0, 0xf5, 0x86, 0x57, 0xd8, 0x1f, 0x85, 0x82, 0xc2, 0x3a, 0xcf, 0x22, 0xf5,
		0x34, 0x21, 0x11, 0x6c, 0xf6, 0x4b, 0xab, 0x48, 0x11, 0xe0, 0xd2, 0xd9, 0xf0, 0x51, 0x2f, 0x4e,
		0x2c, 0x67, 0x8e, 0x7e, 0xa3, 0x05, 0xd0, 0xb3, 0x33, 0xa7, 0x30, 0xed, 0xad, 0x2b, 0x5d, 0xb9,
		0x3f, 0xaa, 0x72, 0xee, 0x2b, 0x5e, 0xc5, 0x71, 0xba, 0x7a, 0x04, 0xae, 0xd9, 0x87, 0x2a, 0xfe,
		0xd7, 0x35, 0x02, 0x73, 0x1a, 0xfa, 0x56, 0xdf, 0x8c, 0x4f, 0x70, 0x84, 0x4a, 0x3f, 0x4e, 0xa6,
		0x49, 0x89, 0xbd, 0xe7, 0xc2, 0xf1, 0x67, 0x2c, 0x6e, 0x45, 0x3c, 0x51, 0x59, 0x6a, 0xcc, 0x7d,
		0x5f, 0xec, 0xed, 0xfc, 0x2b, 0xe8, 0x36, 0x30, 0x1c, 0xca, 0x84, 0x1f, 0xe7, 0x2a, 0x20, 0x9f,
		0x1a, 0xfe, 0x8d, 0x13, 0x72, 0xbc, 0xc9, 0xcd, 0x9c, 0xa5, 0x98, 0xd1, 0xf8, 0xc9, 0x51, 0x05,
		0x65, 0xd9, 0x99, 0xd6, 0xae, 0x01, 0x0b, 0x7f, 0x61, 0xce, 0x5f, 0xd3, 0xcb, 0x60, 0x80, 0xa8,
		0x03, 0x78, 0xac, 0x92, 0x80, 0x34, 0x7f, 0x55, 0x52, 0x3b, 0x95, 0x6a, 0xbe, 0x22, 0xc4, 0x76,
		0x74, 0x6b, 0xb1, 0x5b, 0xa9, 0xcc, 0xf7, 0xef, 0xe7, 0xc4, 0x13, 0x06, 0x0c, 0x4c, 0xa5, 0x9e,
		0x32, 0xf2, 0xb2, 0x36, 0x92, 0x65, 0x26, 0x42, 0xe4, 0x61, 0xfd, 0x8e, 0x62, 0xb1, 0x8b, 0xce,
		0x16, 0xa2, 0x96, 0x07, 0x11, 0xb5, 0x50, 0x02, 0x06, 0xc7, 0xc6, 0x1c, 0x90, 0x7f, 0xa2, 0x44,
		0xb0, 0xb2, 0x5e, 0xd4, 0x8e, 0x2f, 0x86, 0x75, 0xc8, 0x13, 0x6b, 0x90, 0x98, 0x5d, 0x10, 0x6b,
		0x27, 0x10, 0xbe, 0x8a, 0x28, 0x33, 0x71, 0x83, 0x55, 0x88, 0xc0, 0xc1, 0xe2, 0xe6, 0xa1, 0x29,
		0x2d, 0x07, 0x78, 0x8f, 0x90, 0x50, 0x52, 0x68, 0x68, 0x36, 0xd7, 0x69, 0x14, 0x06, 0x05, 0xa9,
		0x3c, 0xf3, 0xcf, 0x10, 0x51, 0x2d, 0x2e, 0x49, 0xf1, 0xb7, 0xf8, 0x3e, 0xc7, 0x1e, 0x29, 0x93,
		0x21, 0x75, 0xee, 0x91, 0xd2, 0xa1, 0x43, 0x1d, 0x32, 0x9b, 0xdd, 0x08, 0xfc, 0xdf, 0xea, 0x26,
		0xe6, 0x1f, 0x54, 0xb5, 0xe8, 0xba, 0xba, 0x3d, 0x4e, 0x37, 0xaa, 0x4f, 0x82, 0x7e, 0xdf, 0x62,
		0xc4, 0x6c, 0xbf, 0x8d, 0xcf, 0x55, 0xf4, 0x82, 0xa0, 0x8b, 0x15, 0xdb, 0x5a, 0xed, 0x90, 0xda,
		0x6c, 0x53, 0x87, 0x72, 0x82, 0x47, 0x94, 0x6d, 0x8d, 0x69, 0x19, 0x67, 0xad, 0xbf, 0x1c, 0xd7,
		0x4d, 0x72, 0xe0, 0x47, 0x8d, 0x15, 0x18, 0x60, 0x91, 0xd8, 0xe4, 0xf0, 0x6f, 0xa4, 0xe5, 0xf7,
		0xdb, 0x56, 0x21, 0x98, 0x12, 0x83, 0xf1, 0x32, 0xc2, 0x81, 0x59, 0x0e, 0x90, 0xc2, 0x60, 0xf6,
		0x4c, 0xc0, 0xc8, 0xca, 0x2e, 0xbb, 0xc7, 0x1b, 0xf4, 0x80, 0x24, 0x28, 0xb6, 0xab, 0x0f, 0xc8,
		0xe8, 0xd1, 0x7d, 0x3f, 0xd0, 0x5b, 0x63, 0x9b, 0x97, 0xe1, 0xaf, 0xff, 0xfc, 0x28, 0x88, 0xa3,
		0xf0, 0xcb, 0xf9, 0x39, 0x10, 0xfc, 0x25, 0x2f, 0xdd, 0x3e, 0x33, 0x80, 0x4f, 0x9c, 0xd3, 0xde,
		0xb6, 0x66, 0xf3, 0x58, 0xbf, 0x52, 0xfa, 0x54, 0x06, 0x12, 0x16, 0xb6, 0x1f, 0x4e, 0x0d, 0xa2,
		0xde, 0x8c, 0x1b, 0x0d, 0x77, 0xa9, 0xa7, 0xf4, 0x22, 0x76, 0x3b, 0x8b, 0x8f, 0x49, 0x03, 0x74,
		0x42, 0x91, 0x91, 0xdd, 0xc3, 0xd0, 0x00, 0x19, 0x95, 0x84, 0xff, 0xe4, 0x44, 0x0d, 0x34, 0x5a,
		0x40, 0x8a, 0x68, 0xfd, 0x93, 0x0e, 0xe1, 0x40, 0x98, 0x3a, 0xe8, 0x4c, 0xa9, 0x02, 0xde, 0x65,
		0xed, 0x29, 0xf5, 0x85, 0xa3, 0x2c, 0x53, 0x6f, 0x82, 0x71, 0x35, 0x5d, 0xfb, 0xdd, 0x42, 0x1a,
		0x6a, 0xd7, 0x0e, 0xcf, 0x7a, 0x39, 0x3d, 0x56, 0x06, 0x04, 0xad, 0x95, 0xc9, 0xc6, 0xbb, 0x3a,
		0x3d, 0x94, 0x37, 0x37, 0x38, 0x8e, 0xb3, 0x31, 0x4a, 0x90, 0xec, 0xfb, 0xd6, 0x11, 0xc3, 0xac,
		0x57, 0x1b, 0x8f, 0x79, 0x79, 0xee, 0x45, 0xc0, 0x85, 0x92, 0x44, 0xc7, 0xde, 0x63, 0x55, 0xb2,
		0x39, 0xd2, 0xa8, 0x25, 0x60, 0x2e, 0xfb, 0x53, 0xf8, 0xb8, 0x12, 0x01, 0x1e, 0x98, 0x08, 0x12,
		0xd4, 0xe5, 0x74, 0x33, 0xef, 0xe4, 0x09, 0x15, 0x4e, 0xf8, 0xfe, 0xe3, 0x51, 0xb3, 0x23, 0xf2,
		0xd9, 0x57, 0x5c, 0xbe, 0xc7, 0x9a, 0xa0, 0x2e, 0x10, 0x09, 0xef, 0x96, 0xb7, 0x0f, 0x9c, 0x66,
		0x7a, 0x7b, 0x79, 0x88, 0xb9, 0x97, 0xe2, 0x2d, 0xe7, 0xf7, 0x14, 0xdc, 0xed, 0x48, 0x7e, 0x52,
		0xd8, 0x7d, 0x0a, 0x78, 0x63, 0x3d, 0xe6, 0x9a, 0x72, 0x58, 0xb6, 0x81, 0x01, 0xcd, 0x8a, 0xc9,
		0x20, 0xbe, 0x61, 0xf1, 0x14, 0x1a, 0xf2, 0x5f, 0xbe, 0xb9, 0x6f, 0x27, 0xd4, 0xf6, 0x69, 0xfa,
		0x87, 0x24, 0xb7, 0x86, 0x70, 0xea, 0x9e, 0x0c, 0x45, 0xc5, 0x6e, 0x20, 0x45, 0x43, 0x4f, 0xa1,
		0xa0, 0xa3, 0xeb, 0x21, 0xef, 0x20, 0x6c, 0x4a, 0x67, 0xde, 0x97, 0x00, 0xb5, 0xdc, 0x3f, 0x3c,
		0x9c, 0xaf, 0xd4, 0x04, 0xd6, 0xb0, 0xf6, 0xe8, 0x20, 0xf5, 0xbc, 0xe0, 0xd9, 0x18, 0x5a, 0x63,
		0xb9, 0x4d, 0xd8, 0xb8, 0xec, 0x9f, 0x06, 0xc4, 0x8d, 0x62, 0x28, 0x94, 0x62, 0xf0, 0x1a, 0x0a,
		0x5a, 0x6d, 0xc2, 0xab, 0x1c, 0x5c, 0x6d, 0x4d, 0xc3, 0xfb, 0x2b, 0xf9, 0x41, 0x31, 0xd9, 0xbf,
		0x01, 0x0c, 0x49, 0x7c, 0x19, 0xd6, 0x73, 0xe9, 0x7a, 0x26, 0x1f, 0xba, 0xf2, 0xd5, 0xa6, 0xf3,
		0x8d, 0x79, 0xd1, 0xb4, 0x3c, 0x00, 0x76, 0x59, 0x68, 0x59, 0xcb, 0xa7, 0x73, 0x08, 0x92, 0xb0,
		0x73, 0xad, 0x7c, 0x38, 0xf7, 0x70, 0x48, 0x7b, 0x6d, 0xeb, 0xe3, 0x2a, 0x02, 0x38, 0x40, 0x70,
		0x22, 0xf9, 0x83, 0xc5, 0xb8, 0x6f, 0x6a, 0x97, 0xc6, 0x5f, 0xb8, 0x57, 0x30, 0x17, 0xb0, 0x5c,
		0x7c, 0x54, 0x89, 0xa4, 0x50, 0xac, 0x01, 0x1e, 0x7b, 0xc8, 0x2c, 0x23, 0xfe, 0x93, 0x39, 0xe1,
		0x4b, 0xe7, 0xdc, 0x0f, 0x13, 0x9d, 0xae, 0xf8, 0xb4, 0x96, 0x9f, 0x0b, 0x9f, 0xff, 0xf0, 0x35,
		0xb9, 0x1d, 0xfc, 0x89, 0x60, 0xa0, 0x3e, 0x3b, 0xd7, 0xc3, 0x1d, 0xd0, 0xf4, 0x9e, 0x7b, 0xe2,
		0x4c, 0x42, 0x32, 0x87, 0xa9, 0xe9, 0x4b, 0x16, 0x45, 0xfd, 0x58, 0x09, 0xe9, 0x44, 0x41, 0x77
	};

// -------------------------------------------------------------------------------------------------

// API routine to initialise hash algorithm state and check required message digest length

HashReturn Init ( hashState *state, int hashbitlen ) {
	unsigned char i;

// Check message digest length is valid (whole 32-bit words, at most 16 of them)
	if (hashbitlen<=0 || hashbitlen>512 || hashbitlen%32) return BAD_HASHBITLEN;
	state->hashbitlen = hashbitlen;

// Initialise input buffer to empty
	state->inputbits = 0;
	state->inputbytes = 0;
	for (i=0; i<4; i++) {
		state->inputblocks[i] = 0;
		state->inputslabs[i] = 0;
	}

// Put the digest length into the first word of Stream 2 (Stream 1 may be used for a key)
	state->stream2[0] = hashbitlen & 0xff;
	state->stream2[1] = hashbitlen >> 8;

// Initialise Streams to zeros
	for (i=0; i<STREAM1*4; i++) state->stream1[i] = 0;
	state->pstream1 = state->stream1 + STREAM1*4 - 4;
	for (i=2; i<STREAM2*4; i++) state->stream2[i] = 0;
	state->pstream2 = state->stream2 +  STREAM2*4 - 4;
	for (i=0; i<STREAM3*4; i++) state->stream3[i] = 0;
	state->pstream3 = state->stream3 +  STREAM3*4 - 4;

// Initialise Pools to zeros
	for (i=0; i<POOL*4; i++) state->pool2[i] = 0;
	state->ppool2 = state->pool2 + POOL*4 - 4;
	for (i=0; i<POOL*4; i++) state->pool3[i] = 0;
	state->ppool3 = state->pool3 + POOL*4 - 4;

#if DEBUG>0
	printf("Waterfall initialised: hashbitlen %d\n", hashbitlen);
#endif
	return SUCCESS;
}

// -------------------------------------------------------------------------------------------------

// Perform the X-box 32-bit to 32-bit substitution making sure that each byte depends on every byte

void Xbox ( unsigned char *pword ) {
	unsigned const char *pxbox;

#if DEBUG>2
	printf("  X-box steps: %2.2x%2.2x%2.2x%2.2x", *(pword+3), *(pword+2), *(pword+1), *pword);
#endif

	pxbox = xbox + *pword * 4;
	*pword ^= *pxbox++;
	*(pword+1) ^= *pxbox++;
	*(pword+2) ^= *pxbox++;
	*(pword+3) ^= *pxbox;

#if DEBUG>2
	printf(" %2.2x%2.2x%2.2x%2.2x", *pword, *(pword+3), *(pword+2), *(pword+1));
#endif

	pxbox = xbox + *(pword+1) * 4;
	*(pword+1) ^= *pxbox++;
	*(pword+2) ^= *pxbox++;
	*(pword+3) ^= *pxbox++;
	*pword ^= *pxbox;

#if DEBUG>2
	printf(" %2.2x%2.2x%2.2x%2.2x", *(pword+1), *pword, *(pword+3), *(pword+2));
#endif

	pxbox = xbox + *(pword+2) * 4;
	*(pword+2) ^= *pxbox++;
	*(pword+3) ^= *pxbox++;
	*pword ^= *pxbox++;
	*(pword+1) ^= *pxbox;

#if DEBUG>2
	printf(" %2.2x%2.2x%2.2x%2.2x", *(pword+2), *(pword+1), *pword, *(pword+3));
#endif

	pxbox = xbox + *(pword+3) * 4;
	*(pword+3) ^= *pxbox++;
	*pword ^= *pxbox++;
	*(pword+1) ^= *pxbox++;
	*(pword+2) ^= *pxbox;

#if DEBUG>2
	printf(" %2.2x%2.2x%2.2x%2.2x\n", *(pword+3), *(pword+2), *(pword+1), *pword);
#endif
}

// -------------------------------------------------------------------------------------------------

// Copy a word from one place to another

void CopyWord ( unsigned char *pto, const unsigned char *pfrom ) {
	*pto++ = *pfrom++;
	*pto++ = *pfrom++;
	*pto++ = *pfrom++;
	*pto = *pfrom;
}

// -------------------------------------------------------------------------------------------------

// Exclusive-or a word from one place onto another

void XorWord ( unsigned char *pto, const unsigned char *pfrom ) {
	*pto++ ^= *pfrom++;
	*pto++ ^= *pfrom++;
	*pto++ ^= *pfrom++;
	*pto ^= *pfrom;
}

// -------------------------------------------------------------------------------------------------

// Perform a single update step given an input word

static void UpdateStep ( hashState *state, const unsigned char *pinput ) {
	unsigned char word1[4], word2[4], word3[4];

#if DEBUG>1
	printf(" Update step input %2.2x%2.2x%2.2x%2.2x\n", *(pinput+3), *(pinput+2), *(pinput+1), *pinput);
#endif

// Extract previous entries from Streams
	CopyWord(word1, state->pstream1);
	CopyWord(word2, state->pstream2);
	CopyWord(word3, state->pstream3);

#if DEBUG>2
	printf("  Previous stream values %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x\n", 
		word1[3], word1[2], word1[1], word1[0], word2[3], word2[2], word2[1], word2[0], word3[3], word3[2], word3[1], word3[0]);
#endif

// Advance Stream positions rotationally
	state->pstream1 += 4;
	if (state->pstream1 == state->stream1+STREAM1*4) state->pstream1 = state->stream1;
	state->pstream2 += 4;
	if (state->pstream2 == state->stream2+STREAM2*4) state->pstream2 = state->stream2;
	state->pstream3 += 4;
	if (state->pstream3 == state->stream3+STREAM3*4) state->pstream3 = state->stream3;

#if DEBUG>2
	printf("  Current stream positions %d %d %d\n", (state->pstream1-state->stream1)/4,
			(state->pstream2-state->stream2)/4, (state->pstream3-state->stream3)/4);
	printf("  Current stream values  %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x\n",
			*(state->pstream1+3), *(state->pstream1+2), *(state->pstream1+1), *state->pstream1, 
			*(state->pstream2+3), *(state->pstream2+2), *(state->pstream2+1), *state->pstream2, 
			*(state->pstream3+3), *(state->pstream3+2), *(state->pstream3+1), *state->pstream3);
#endif

// Update the current position in each Stream using the input word and the previous entry, using the X-box
// for non-linearity and mixing in the word
	XorWord(state->pstream1, word1);
	XorWord(state->pstream1, pinput);
	Xbox(state->pstream1);

	word2[0] ^= 1;
	XorWord(state->pstream2, word2);
	XorWord(state->pstream2, pinput);
	Xbox(state->pstream2);

	word3[0] ^= 2;
	XorWord(state->pstream3, word3);
	XorWord(state->pstream3, pinput);
	Xbox(state->pstream3);

#if DEBUG>2
	printf("  New stream values      %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x\n",
			*(state->pstream1+3), *(state->pstream1+2), *(state->pstream1+1), *state->pstream1, 
			*(state->pstream2+3), *(state->pstream2+2), *(state->pstream2+1), *state->pstream2, 
			*(state->pstream3+3), *(state->pstream3+2), *(state->pstream3+1), *state->pstream3);
#endif

// Update Pools 2 and 3 from the current words in Stream 2 and 3 with simple exclusive-or
	state->ppool2 +=4;
	if(state->ppool2==state->pool2+POOL*4) {
		state->ppool2 = state->pool2;
		state->ppool3 = state->pool3;
	} else {
		state->ppool3 += 4;
	}
	XorWord(state->ppool2, state->pstream2);
	XorWord(state->ppool3, state->pstream3);

#if DEBUG>2
	printf("  New pool values at %d: %2.2x%2.2x%2.2x%2.2x %2.2x%2.2x%2.2x%2.2x\n", (state->ppool2-state->pool2)/4,
			*(state->ppool2+3), *(state->ppool2+2), *(state->ppool2+1), *state->ppool2, 
			*(state->ppool3+3), *(state->ppool3+2), *(state->ppool3+1), *state->ppool3);
#endif
}

// -------------------------------------------------------------------------------------------------

// Add one block - but we are storing effectively a long long in bytes

void AddBlock ( hashState *state ) {
	if (!++state->inputblocks[0]) {
		if (!++state->inputblocks[1]) {
			if (!++state->inputblocks[2]) {
				if (!++state->inputblocks[3]) {
					if (!++state->inputslabs[0]) {
						if (!++state->inputslabs[1]) {
							if (!++state->inputslabs[2]) state->inputslabs[3]++;
						}
					}
				}
			}
		}
	}
}

// -------------------------------------------------------------------------------------------------

// API routine to process some passed data into the hash state

HashReturn Update ( hashState *state, const BitSequence *data, DataLength databitlen ) {
	unsigned long long left;
	unsigned char i, ibuff, bits, j;
	const unsigned char *pinput;
	unsigned char last;

#if DEBUG>0
	printf("Update: databitlen %d\n", databitlen);
#endif

// Number of bytes left in the input data
	left = databitlen / 8;

// If there is something in the buffer, fill up the buffer first
	ibuff = state->inputbytes;

	if (ibuff) {
		while (ibuff<64 && left>0) {
#if DEBUG>2
			printf("  Input byte %2.2x\n", *data);
#endif
			state->inputbuffer[ibuff++] = *data++;
			left--;
		}

// If the buffer is now full, process the buffer, then mark it empty
		if (ibuff==64) {
			pinput = state->inputbuffer;
			for (j=0; j<16; j++) {
				UpdateStep(state, pinput);
				pinput += 4;
			}
			AddBlock(state);
			UpdateStep(state, state->inputblocks);
			state->inputbytes = 0;
			ibuff = 0;
		}
	}

// Pointer to the rest of the data
	pinput = data;

// If there is something left in the input data, process as many whole blocks as we can
	while (left>=64) {
		for (j=0; j<16; j++) {
#if DEBUG>2
		printf("  Input byte %2.2x\n  Input byte %2.2x\n  Input byte %2.2x\n  Input byte %2.2x\n",
				*pinput, *(pinput+1), *(pinput+2), *(pinput+3));
#endif
			UpdateStep(state, pinput);
			pinput += 4;
		}
		AddBlock(state);
		UpdateStep(state, state->inputblocks);
		left -= 64;
	}

// Copy remaining whole bytes into the buffer
	data = pinput;
	while (left) {
#if DEBUG>2
		printf("  Input byte %2.2x\n", *data);
#endif
		state->inputbuffer[ibuff++] = *data++;
		left--;
	}
	state->inputbytes = ibuff;

// Handle a part of a byte (only in the last update) - zero least significant bits before storing
	bits = (unsigned char) (databitlen % 8);
	if (bits) {
		last = *data;
		last >>= 8-bits;
		last <<= 8-bits;
#if DEBUG>2
		printf("  Input partial byte %2.2x %d\n", last, bits);
#endif
		state->inputbuffer[ibuff] = last;
		state->inputbits = bits;
	}

#if DEBUG>1
	printf(" Stream 1:\n");
	for(i=0; i<STREAM1*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->stream1[i+3], state->stream1[i+2], state->stream1[i+1], state->stream1[i]);
		if((i&31)==28) printf("\n");
	}
	printf(" Stream 2:\n ");
	for(i=0; i<STREAM2*4; i+=4) printf(" %2.2x%2.2x%2.2x%2.2x", state->stream2[i+3], state->stream2[i+2], state->stream2[i+1], state->stream2[i]);
	printf("\n");
	printf(" Stream 3:\n ");
	for(i=0; i<STREAM3*4; i+=4) printf(" %2.2x%2.2x%2.2x%2.2x", state->stream3[i+3], state->stream3[i+2], state->stream3[i+1], state->stream3[i]);
	printf("\n");
	printf(" Pool 2:\n");
	for(i=0; i<POOL*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->pool2[i+3], state->pool2[i+2], state->pool2[i+1], state->pool2[i]);
		if((i&31)==28) printf("\n");
	}
	printf(" Pool 3:\n");
	for(i=0; i<POOL*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->pool3[i+3], state->pool3[i+2], state->pool3[i+1], state->pool3[i]);
		if((i&31)==28) printf("\n");
	}
#endif

	return SUCCESS;
}

// -------------------------------------------------------------------------------------------------

// Use a part of a Pool to to process a copy of Stream 1

#define WORK (STREAM1*4)

static void FinalStep ( unsigned char *pworkin, unsigned char *ppool, unsigned char *pworkout ) {
	unsigned char i, *pw, *p1, *p2, *p3, *p4;

// Swap bits rotationally between elements of the array
	for (i=0; i<STREAM1; i++) {
		pworkout[i] = (pworkin[i] & 0x14141414) | (pworkin[(i+3)%STREAM1] & 0x28282828) | 
					(pworkin[(i+7)%STREAM1] & 0x42424242) | (pworkin[(i+12)%STREAM1] & 0x81818181);
	}
// Swap bits rotationally between elements of the arrays
	pw = pworkout;
	p1 = pworkin;
	p2 = pworkin + 12;
	p3 = pworkin + 28;
	p4 = pworkin + 48;
	do {
		*pw = (*p1 & 0x14) | (*p2 & 0x28) | (*p3 & 0x42) | (*p4 & 0x81);
		if(++p1>=pworkin+WORK) p1 = pworkin;
		if(++p2>=pworkin+WORK) p2 = pworkin;
		if(++p3>=pworkin+WORK) p3 = pworkin;
		if(++p4>=pworkin+WORK) p4 = pworkin;
	} while (++pw < pworkout+WORK);

#if DEBUG>2
	printf("  Bits swapped:\n");
	for(i=0; i<WORK; i+=4) {
		if((i&31)==0) printf("  ");
		printf(" %2.2x%2.2x%2.2x%2.2x", pworkout[i+3], pworkout[i+2], pworkout[i+1], pworkout[i]);
		if((i&31)==28) printf("\n");
	}
#endif

// Apply the X-box to each word
	for (i=0; i<WORK; i+=4) Xbox(&pworkout[i]);

#if DEBUG>2
	printf("  X-box applied:\n");
	for(i=0; i<WORK; i+=4) {
		if((i&31)==0) printf("  ");
		printf(" %2.2x%2.2x%2.2x%2.2x", pworkout[i+3], pworkout[i+2], pworkout[i+1], pworkout[i]);
		if((i&31)==28) printf("\n");
	}
#endif

// If it is passed, exclusive-or a section of a Pool into the copy of Stream 1
	if (ppool != NULL) for (i=0; i<WORK; i++) pworkout[i] ^= ppool[i];

#if DEBUG>2
	printf("  Masked:\n");
	for(i=0; i<WORK; i+=4) {
		if((i&31)==0) printf("  ");
		printf(" %2.2x%2.2x%2.2x%2.2x", pworkout[i+3], pworkout[i+2], pworkout[i+1], pworkout[i]);
		if((i&31)==28) printf("\n");
	}
#endif
}

// -------------------------------------------------------------------------------------------------

// API routine to complete the algorithm and return the message digest

HashReturn Final ( hashState *state, BitSequence *hashval ) {
	unsigned char i, pass, *pinput, *pworkin, *pworkout, *pwork, *ppool;
	unsigned char inputbits[4];

#if DEBUG>0
	printf("Final\n");
#endif

// May need to process the contents of the input buffer
	if (state->inputbits || state->inputbytes) {

	// Zero the end of the buffer (we don't want data going in twice)
		i = state->inputbytes + (state->inputbits+7) / 8;
		for(; i<64; i++) state->inputbuffer[i] = 0;

	// Process the buffer
		pinput = state->inputbuffer;
		for (i=0; i<16; i++) {
			UpdateStep(state, pinput);
			pinput += 4;
		}
		AddBlock(state);
		UpdateStep(state, state->inputblocks);
	}

// Always process the bit count and slab count
	inputbits[0] = state->inputbits + (state->inputbytes<<3);
	inputbits[1] = state->inputbytes>>5;
	inputbits[2] = 0;
	inputbits[3] = 0;
	UpdateStep(state, inputbits);
	UpdateStep(state, state->inputslabs);

// Perform 16 update steps with fixed input
	inputbits[1] = 0;
	for(i=0; i<FINALUPDATES; i++) {
		inputbits[0] = i;
		UpdateStep(state, inputbits);
	}

#if DEBUG>1
	printf(" Stream 1 after input:\n");
	for(i=0; i<STREAM1*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->stream1[i+3], state->stream1[i+2], state->stream1[i+1], state->stream1[i]);
		if((i&31)==28) printf("\n");
	}
	printf(" Stream 2 after input:\n ");
	for(i=0; i<STREAM2*4; i+=4) printf(" %2.2x%2.2x%2.2x%2.2x", state->stream2[i+3], state->stream2[i+2], state->stream2[i+1], state->stream2[i]);
	printf("\n");
	printf(" Stream 3 after input:\n ");
	for(i=0; i<STREAM3*4; i+=4) printf(" %2.2x%2.2x%2.2x%2.2x", state->stream3[i+3], state->stream3[i+2], state->stream3[i+1], state->stream3[i]);
	printf("\n");
	printf(" Pool 2 after input:\n");
	for(i=0; i<POOL*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->pool2[i+3], state->pool2[i+2], state->pool2[i+1], state->pool2[i]);
		if((i&31)==28) printf("\n");
	}
	printf(" Pool 3 after input:\n");
	for(i=0; i<POOL*4; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", state->pool3[i+3], state->pool3[i+2], state->pool3[i+1], state->pool3[i]);
		if((i&31)==28) printf("\n");
	}
#endif

// Take a copy of Stream 1
	for(i=0; i<WORK; i++) state->inputbuffer[i] = state->stream1[i];

// Work arrays are used alternately as input and output
	pworkin = state->inputbuffer;
	pworkout = state->stream2;  // Note we have made sure there is enough room in the hashState struct for 64 bytes here

// Perform mangling steps, combining with Pool 2
	ppool = state->pool2;
	for(pass=0; pass<POOLFACTOR; pass++) {
#if DEBUG>1
		printf(" Combining with Pool 2 pass %d\n", pass);
#endif
		FinalStep(pworkin, ppool, pworkout);
		pwork = pworkin;
		pworkin = pworkout;
		pworkout = pwork;
		ppool += WORK;
	}
	
// Same with Pool 3
	ppool = state->pool3;
	for(pass=0; pass<POOLFACTOR; pass++) {
#if DEBUG>1
		printf(" Combining with Pool 3 pass %d\n", pass);
#endif
		FinalStep(pworkin, ppool, pworkout);
		pwork = pworkin;
		pworkin = pworkout;
		pworkout = pwork;
		ppool += WORK;
	}

// Same steps but with no Pool data
	for(pass=0; pass<FINALSTEPS; pass++) {
#if DEBUG>1
		printf(" Mixing without Pools pass %d\n", pass);
#endif
		FinalStep(pworkin, NULL, pworkout);
		pwork = pworkin;
		pworkin = pworkout;
		pworkout = pwork;
	}

#if DEBUG>1
	printf(" Mangled copy of Stream 1:\n");
	for(i=0; i<WORK; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", pworkin[i+3], pworkin[i+2], pworkin[i+1], pworkin[i]);
		if((i&31)==28) printf("\n");
	}
#endif

// Exclusive-or the mangled copy of Stream 1 with Stream 1
	for(i=0; i<WORK; i++) pworkin[i] ^= state->stream1[i];

// And with each section of each Pool to make Final one-way with respect to each of these
	ppool = state->pool2;
	for(pass=0; pass<POOLFACTOR; pass++) {
		for(i=0; i<WORK; i++) pworkin[i] ^= ppool[i];
		ppool += WORK;
	}

	ppool = state->pool3;
	for(pass=0; pass<POOLFACTOR; pass++) {
		for(i=0; i<WORK; i++) pworkin[i] ^= ppool[i];
		ppool += WORK;
	}
	
#if DEBUG>1
	printf(" Final digest:\n");
	for(i=0; i<WORK; i+=4) {
		if((i&31)==0) printf(" ");
		printf(" %2.2x%2.2x%2.2x%2.2x", pworkin[i+3], pworkin[i+2], pworkin[i+1], pworkin[i]);
		if((i&31)==28) printf("\n");
	}
#endif

// Return all the bytes required (little-endian transfer)
	for(i=0; i<(state->hashbitlen/8); i++) hashval[i] = pworkin[i];
	return SUCCESS;
}

// -------------------------------------------------------------------------------------------------

// Perform the complete hash process in one call

HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen,
				BitSequence *hashval) {
	HashReturn ret;
	hashState state;

	ret = Init(&state, hashbitlen);
	if (ret != SUCCESS) return ret;

	ret = Update(&state, data, databitlen);
	if (ret != SUCCESS) return ret;

	ret = Final(&state, hashval);
	return ret;
}