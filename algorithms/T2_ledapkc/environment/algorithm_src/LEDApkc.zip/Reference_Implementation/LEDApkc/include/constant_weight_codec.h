/**
 *
 * <constant_weight_codec.h>
 *
 * @version 1.0 (September 2017)
 *
 * Reference ISO-C99 Implementation of LEDAkem cipher" using GCC built-ins.
 *
 * In alphabetical order:
 *
 * @author Marco Baldi <m.baldi@univpm.it>
 * @author Alessandro Barenghi <alessandro.barenghi@polimi.it>
 * @author Franco Chiaraluce <f.chiaraluce@univpm.it>
 * @author Gerardo Pelosi <gerardo.pelosi@polimi.it>
 * @author Paolo Santini <p.santini@pm.univpm.it>
 *
 * This code is hereby placed in the public domain.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS ''AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **/

#pragma once
#include "qc_ldpc_parameters.h"
#include "gf2x_limbs.h"
#include "gf2x_arith_mod_xPplusOne.h"
/*----------------------------------------------------------------------------*/


#define SAFE_BIT_SIZE_CW_ENCODING MAX_ENCODABLE_BIT_SIZE_CW_ENCODING-(MAX_ENCODABLE_BIT_SIZE_CW_ENCODING/30)

void constant_weight_to_binary_approximate(unsigned char *const bitstreamOut,
      const DIGIT constantWeightIn[]);
int binary_to_constant_weight_approximate(DIGIT *constantWeightOut,
      const unsigned char *const bitstreamIn,
      const int bitLength);

/* Maximum size in in bits of the binary string encoded via constant weight
 * encoding. It should always exceed HASH_BIT_SIZE, and it does for suggested
 * parameter sets */
#define CONSTANT_WEIGHT_ENCODED_DATA_ACTUAL_BIT_LENGTH (SAFE_BIT_SIZE_CW_ENCODING - (SAFE_BIT_SIZE_CW_ENCODING + K) % 8)

#if CONSTANT_WEIGHT_ENCODED_DATA_ACTUAL_BIT_LENGTH < HASH_BIT_SIZE
#error Not enough capacity in constant weight encoding to hold the hash digest
#endif

uint64_t bitstream_read(const unsigned char *const stream,
                        const unsigned int bit_amount,
                        unsigned int *bit_cursor);
void bitstream_write(unsigned char *output,
                     const unsigned int amount_to_write,
                     unsigned int *output_bit_cursor,
                     uint64_t value_to_write);
