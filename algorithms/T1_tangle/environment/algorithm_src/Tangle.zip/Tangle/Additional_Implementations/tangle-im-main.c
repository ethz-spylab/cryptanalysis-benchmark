/*
	Tangle - a hash function for the NIST SHA-3 competition
	Intermediate values main program
	2008 (c) Rafael Alvarez

	*** This implementation is Little-Endian and should be modified for Big-Endian machines
	*** Uses a 64bit integer for total message size in bits, Tangle supports up to 128 bits for message size

*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tangle.h"

void PrintHash(U8 *h,int l,FILE * file)
{
	int i;
	for(i=0;i<l;i++)
	{
		if(i%32==0) fprintf(file,"\n");
		fprintf(file,"%02X",h[i]);
	}
	fprintf(file,"\n");
}



#define NumBytes(x) (((x-1)/8)+1)

FILE * freport;

int main()
{
	U8 message[1024];
	U32 i,j;
	U8 H[128];
	int bitlengths[] = {224, 256, 384, 512, 768, 1024};

	char name[100];




	/* 1 block message */

	memset(message,0,1024);
	message[0]='a';
	message[1]='b';
	message[2]='c';

	for(j=0; j<6; j++)
	{
		sprintf(name,"1block-%d.txt",bitlengths[j]);
		freport = fopen(name,"w+b");

		fprintf(freport,"#Tangle-%d 1 block message ('abc') intermediate values\n",bitlengths[j]);

		Hash(bitlengths[j],message,24,H);

		fprintf(freport,"Final Hash:");
		PrintHash(H,bitlengths[j]/8,freport);

		fprintf(freport,"\n");

		fclose(freport);
	}


	/* 2 block message */

	memset(message,0,1024);
	for(i=0;i<800;i+=4)
	{
		message[i]   = 'A';
		message[i+1] = 'B';
		message[i+2] = 'C';
		message[i+3] = 'D';
	}

	for(j=0; j<6; j++)
	{
		sprintf(name,"2block-%d.txt",bitlengths[j]);
		freport = fopen(name,"w+b");

		fprintf(freport,"#Tangle-%d 2 block message ('ABCD' x 200 times) intermediate values\n",bitlengths[j]);

		Hash(bitlengths[j],message,800*8,H);

		fprintf(freport,"Final Hash:");
		PrintHash(H,bitlengths[j]/8,freport);

		fprintf(freport,"\n");

		fclose(freport);
	}

	return 0;
}

