module	LZDR_RAM(i_clk,	i_reset, i_fE,
	i_fWr0,	i_fRd0,	i_Addr0,	i_Data0, o_Data0,
	i_fWr1,	i_fRd1,	i_Addr1,	i_Data1, o_Data1
);
parameter	mw = 10;

input	wire			i_clk, i_reset;
input	wire			i_fE;
input	wire			i_fWr0,	i_fWr1;
input	wire			i_fRd0,	i_fRd1;
input	wire	[mw-1:0]i_Addr0,i_Addr1;
input	wire	[31:0]	i_Data0,i_Data1;
output	wire	[31:0]	o_Data0,o_Data1;

wire	Mem_i_clk;
wire	Mem_i_fCEN0;
wire	Mem_i_fCEN1;
wire	Mem_i_fWEN0;
wire	Mem_i_fWEN1;
wire	[mw-1:0]	Mem_i_Addr1;
wire	[31:0]		Mem_i_Data1;

reg				r_fE;
reg		[31:0]	r_E;
reg		[mw-1:0]r_AddrE;

assign	fWrE		= i_fWr0 && i_fE;
assign	Mem_i_clk	= ~i_clk;
assign	Mem_i_fCEN0	= !(i_fWr0 || i_fRd0);	
assign	Mem_i_fCEN1	= !(i_fWr1 || r_fE || i_fRd1);
assign	Mem_i_fWEN0	= !(i_fWr0 && !i_fE);
assign	Mem_i_fWEN1	= !(i_fWr1 ||  r_fE);
assign	Mem_i_Addr1	= r_fE ? r_AddrE : i_Addr1;
assign	Mem_i_Data1	= r_fE ? r_E     : i_Data1;

always@(posedge i_clk, negedge i_reset)
	if(!i_reset)begin
		r_fE	<= 0;
		r_AddrE	<= 0;
		r_E		<= 0;
	end else begin
		r_fE	<= fWrE;
		if(fWrE)begin
			r_AddrE	<= i_Addr0;
			r_E		<= {
				o_Data0[31:30], i_Data0[29:26], o_Data0[25:16],
				o_Data0[15:14], i_Data0[13:10], o_Data0[ 9: 0]};
		end
end


DPRAM_1024X32M8 RAM0 (
    .CLKA        (Mem_i_clk		),
    .CENA        (Mem_i_fCEN0	),
    .WENA        (Mem_i_fWEN0	),
    .AA          (i_Addr0		),
    .DA          (i_Data0		),
    .QA          (o_Data0		),

    .CLKB        (Mem_i_clk		),
    .CENB        (Mem_i_fCEN1	),
    .WENB        (Mem_i_fWEN1	),
    .AB          (Mem_i_Addr1	),
    .DB          (Mem_i_Data1	),
    .QB          (o_Data1		)
);

endmodule
