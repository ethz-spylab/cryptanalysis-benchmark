module	DPRAM_4096X32M8(
	input	wire			CLKA        ,
	input	wire			CENA        ,
	input	wire			WENA        ,
	input	wire	[11:0]	AA          ,
	input	wire	[31:0]	DA          ,
	output	wire	[31:0]	QA          ,

	input	wire			CLKB        ,
	input	wire			CENB        ,
	input	wire			WENB        ,
	input	wire	[11:0]	AB          ,
	input	wire	[31:0]	DB          ,
	output	wire	[31:0]	QB          

);

reg		[31:0]		m_mem	[0:4095];

always@(posedge CLKA)
	if(		!CENA && !WENA)	m_mem[AA] <= DA;
	else if(!CENB && !WENB)	m_mem[AB] <= DB;

always@(posedge CLKA)
	if(!CENA)	QA	<= m_mem[AA];	else	QA	<= 0;

always@(posedge CLKB)
	if(!CENB)	QB	<= m_mem[AB];	else	QB	<= 0;

endmodule

module	DPRAM_2048X32M8(
	input	wire			CLKA        ,
	input	wire			CENA        ,
	input	wire			WENA        ,
	input	wire	[10:0]	AA          ,
	input	wire	[31:0]	DA          ,
	output	wire	[31:0]	QA          ,

	input	wire			CLKB        ,
	input	wire			CENB        ,
	input	wire			WENB        ,
	input	wire	[10:0]	AB          ,
	input	wire	[31:0]	DB          ,
	output	wire	[31:0]	QB          

);

reg		[31:0]		m_mem	[0:2047];

always@(posedge CLKA)
	if(		!CENA && !WENA)	m_mem[AA] <= DA;
	else if(!CENB && !WENB)	m_mem[AB] <= DB;


always@(posedge CLKA)
	if(!CENA)	QA	<= m_mem[AA];	else	QA	<= 0;

always@(posedge CLKB)
	if(!CENB)	QB	<= m_mem[AB];	else	QB	<= 0;

endmodule

module	DPRAM_1024X32M8(
	input	wire			CLKA        ,
	input	wire			CENA        ,
	input	wire			WENA        ,
	input	wire	[ 9:0]	AA          ,
	input	wire	[31:0]	DA          ,
	output	wire	[31:0]	QA          ,

	input	wire			CLKB        ,
	input	wire			CENB        ,
	input	wire			WENB        ,
	input	wire	[ 9:0]	AB          ,
	input	wire	[31:0]	DB          ,
	output	wire	[31:0]	QB          

);

reg		[31:0]		m_mem	[0:1023];

always@(posedge CLKA)
	if(		!CENA && !WENA)	m_mem[AA] <= DA;
	else if(!CENB && !WENB)	m_mem[AB] <= DB;


always@(posedge CLKA)
	if(!CENA)	QA	<= m_mem[AA];	else	QA	<= 0;

always@(posedge CLKB)
	if(!CENB)	QB	<= m_mem[AB];	else	QB	<= 0;

endmodule
