/* algorithm
 1: for (cnt_n = 0 ; cnt_n < n ; cnt_n++)	
 2: 	if		(fKG)	{	W1 = Mem[cnt_n/ 2];		Sum = Sel_E(W1, cnt_n % 2)			}	// E
 3: 	else if	(fEnc0)	{							Sum = 2								}
 4: 	else if	(fEnc1)	{	W1 = Mem[cnt_n/32];		Sum = Sel(W1, cnt_n % 32, 16) << 9	}	// M
 5: 	else			{	W1 = Mem[cnt_n/ 4];		Sum = Sel(W1, cnt_n %  4,  8)		}	// C2
 6: 	  
 7: 	for (cnt_dgr = 0 ; cnt_dgr < 128 ; cnt_dgr++)	{
 8: 		W0 = Mem[0x200 + cnt_dgr/2];	{sign, dgr} = Sel_S(W0, cnt_dgr % 2);
 9: 		{neg, dgr'} = cnt_n ? dgr;
10: 		neg' = neg ^ sign ^ fKG;
11: 		W1 = Mem[dgr'/2];
12: 		if (neg')	T -= Sel_A(W1, dgr' % 2);
13: 		else		T += Sel_A(W1, dgr' % 2);
14: 		if (cnt_dgr != 127)	Sum = T;
15: 		else
16: 			if		(fKG)	W = (W << 16) +   T;
17: 			else if	(fEnc0)	W = (W <<  8) +  (T >> 2);
18: 			else if	(fEnc1)	W = (W <<  8) +  (T >> 2);
19: 			else			W = (W <<  1) + ((T >> 7) ^ ((T % 2) >> 6));
20: 	}
21: 	if ((fKG   && cnt_n %  2 ==  1) ||
22: 		(fEnc0 && cnt_n %  4 ==  3) ||
23: 		(fEnc1 && cnt_n %  4 ==  3) ||
24: 		(fDec  && cnt_n % 32 == 31))	Out32 = W;		// size: n/32 = 1024/32 = 32 = 0x20 words
*/


module	LZDR(i_clk, i_reset,
	i_Start,i_Mode,	i_Reg,	i_Addr,	
	i_fWr,	i_Data, o_fWrRdy,	
	i_fRd,	o_Data,	o_fRdRdy
);

//parameter	n = 128, log2n = 7;
parameter	n = 1024, log2n = 10;

input	i_clk;
input	i_reset;

input						i_Start;		// Start signal
input			[1:0]		i_Mode;			// Select mode(ENC0: 0, ENC1: 1, DEC: 2, KEY_GEN: 3)
input						i_fWr;			// Write enable
input						i_fRd;			// Read enable
input			[2:0]		i_Reg;			// Register(A: 0, B: 1, C1: 2, C2: 3, S or R: 4, E: 5, M: 6)
input			[log2n-2:0]	i_Addr;			// Address
input			[31:0]		i_Data;			// input data - S/R: 11-bit x 2, E: 9-bit x 2, A/B: 10-bit x 2, M: 8-bit, C1/C2: 8-bit x 4
output	wire				o_fRdRdy;		// ready for reading
output	wire				o_fWrRdy;		// ready for writing
output	wire	[31:0]		o_Data;			// output data - B: 10-bit x 2, M: 32-bit, C1/C2: 8-bit x 4

reg		[31:0]		NextWord;				// W	in algorithm
wire	[log2n-1:0]	DgrP;					// dgr'	in algorithm
wire				fNegP;					// neg	in algorithm

// Registers
reg		[1:0]		c_state,	n_state;	// state for FSM
reg		[31:0]		c_Word,		n_Word;		// Register for W		in algorithm
reg		[9:0]		c_Sum,		n_Sum;		// Register for Sum		in algorithm
reg		[log2n-4:0]	c_CntDgr,	n_CntDgr;	// Register for cnt_dgr	in algorithm
reg		[log2n-1:0]	c_CntN,		n_CntN;		// Register for cnt_n	in algorithm
reg		[log2n-1:0]	c_DgrP,		n_DgrP;		// Register for dgr'	in algorithm
reg					c_fNegP,	n_fNegP;	// Register for neg'	in algorithm

reg		[ 9:0]		InitValue;				// initial value of n_Sum

// part bits of the word from memory
wire	[10:0]	ReadSR;			// S or R
wire	[ 9:0]	ReadAB;			// A or B
wire	[ 3:0]	ReadE;			// E 
wire	[ 7:0]	ReadM8;			// M (encryption)
wire			ReadM;			// M (decryption)
wire	[ 7:0]	ReadC1;			// C1 
wire	[ 7:0]	ReadC2;			// C2 

wire	[31:0]	E_in;			// re-arranged E (2 x 11-bit input(-255 ~ +255) -> 2 x 4-bit E(-7 ~ +7))
wire	[31:0]	M_in;			// re-arranged M (8-bit input -> 2 x 4-bit)

wire	[log2n-1:0]	NextCnt;		// cnt_n +1 or cnt_dgr +1

// Inputs and outputs of sub-module
//	Memory
wire				Mem_i_fWr0,	Mem_i_fWr1;		// write enable of memory
wire	[log2n-1:0]	Mem_i_Addr0,Mem_i_Addr1;	// address of memory
wire	[31:0]		Mem_i_Data0,Mem_i_Data1;	// input of memory
wire	[31:0]		Mem_o_Data0,Mem_o_Data1;	// output of memory

//	LZDR_E: -255 ~ +255 -> -7~ + 7
wire	[3:0]	E0_o, E1_o;						// output of LZDR_E module 

//	Adder: Sum_o = Sum_i_0 +- Sum_i_1
wire	[9:0]	Sum_i_0, Sum_i_1;				// inputs of adder
wire	[9:0]	Sum_o;							// output of adder: T in algorithm

// Flags
reg		fLastData	;	// the last bits of one word
wire	fIdle		,	// states
		fInit		,
        fCal		,
		fLast		,
		fSum		;
wire	fRegC2		,	// i_Reg
		fRegS		,
		fRegE		,
		fRegM		;
wire	fWrRegE		,	// write enable of Reg
		fWrRegM		;
wire	f1stCntDgr	,	// counter
		fLastCntN	,
		fLastCntDgr	,
		fIncCntDgr	,
		fIncCntN	;
wire	fEnc0		,	// modes
		fEnc1		,
		fEnc		,
		fDec		,
		fKG			;
wire	fPause		;	

parameter	REG_A	= 3'h0,	// Registers
			REG_B	= 3'h1,
			REG_C1	= 3'h2,
			REG_C2	= 3'h3,
			REG_S	= 3'h4,
			REG_E	= 3'h5,
			REG_M	= 3'h6;
parameter	ENC0	= 2'h0,	// Mode
			ENC1	= 2'h1,
			DEC		= 2'h2,
			KEY_GEN = 2'h3;
parameter	IDLE	= 3'h0,	// state
			INIT	= 3'h1,
			CAL		= 3'h3,
			LAST	= 2'h2;
parameter	START_SR= 1'b1,	// start address
			START_C2= 2'b01;

assign	o_Data		= NextWord;
assign	o_fRdRdy	= fLast && fLastData;	// If c_state == LAST and 32bit full data, read
assign	o_fWrRdy	= fIdle;				// If c_state == IDLE, write
	
always@(posedge i_clk, negedge i_reset)
	if(!i_reset) begin
		c_state		<= 0;
		c_CntDgr	<= 0;
		c_CntN		<= 0;
		c_Word		<= 0;
		c_Sum		<= 0;
		c_DgrP		<= 0;
		c_fNegP		<= 0;
	end else begin
		c_state		<= n_state	;
		c_CntDgr	<= n_CntDgr	;
		c_CntN		<= n_CntN	;
		c_Word		<= n_Word	;
		c_Sum		<= n_Sum	;
		c_DgrP		<= n_DgrP	;
		c_fNegP		<= n_fNegP	;
	end

// Input/Output definition of dual port momery
assign	Mem_i_fWr0	= fIdle && i_fWr;		// 1st port-WE
assign	Mem_i_fWr1	= 1'b0;					// 2nd port-WE
assign	Mem_i_fRd0	= fIncCntDgr;			// 1st port-RE
assign	Mem_i_fRd1	= !fIdle;				// 2nd port-RE
assign	Mem_i_Data0	= fWrRegE ? E_in : fWrRegM ? M_in : i_Data;	// 1st port-input data
assign	Mem_i_Data1	= 0;										// 2nd port-input data

// 1st port-address
assign	Mem_i_Addr0	= fIncCntDgr? {START_SR, 3'b0, c_CntDgr[log2n-4:1]}	:	// Read-S/R
					  fIdle		? fRegS ? {START_SR, i_Addr}			:	// Write-S/R : C2 : A(+E)/B(+M)/C1
					  			  fRegC2? {START_C2, i_Addr[log2n-3:0]}	: i_Addr : 0;

// 2nd port-address							  
assign	Mem_i_Addr1 = fSum		? fDec	? c_DgrP[log2n-1:2]	: c_DgrP[log2n-1:1]	:	// Active - C1 : A/B
					  fInit		? fEnc1	? c_CntN[log2n-1:3]	:						// Initial value - M : E : C2
								  fKG	? c_CntN[log2n-1:1]	: {START_C2, c_CntN[log2n-1:2]} : 0;

LZDR_RAM	RAM0(i_clk, fWrRegE | fWrRegM,
	Mem_i_fWr0,	Mem_i_fRd0,	Mem_i_Addr0,	Mem_i_Data0,	Mem_o_Data0,
	Mem_i_fWr1,	Mem_i_fRd1,	Mem_i_Addr1,	Mem_i_Data1,	Mem_o_Data1
);

// Store E(4-bit x 2) and M(8-bit) to ullage space of A and B
assign	E_in	= {	2'b0, E0_o, 10'b0, 
					2'b0, E1_o, 10'b0};	
assign	M_in	= { 2'b0, i_Data[7:4], 10'b0,
					2'b0, i_Data[3:0], 10'b0};

LZDR_E	E0(i_Data[16+:9], E0_o);
LZDR_E	E1(i_Data[0 +:9], E1_o);

// Flags
assign	fIdle	= c_state == IDLE	,
		fInit	= c_state == INIT	,
		fCal	= c_state == CAL	,
		fLast	= c_state == LAST	;
assign	fSum	= c_state == CAL	|| c_state == LAST;	
assign	fEnc0	= i_Mode == ENC0   					,
		fEnc1	= i_Mode == ENC1   					,
		fEnc	= i_Mode == ENC0 || i_Mode == ENC1	,
		fDec	= i_Mode == DEC  					,
		fKG		= i_Mode == KEY_GEN					;
assign	fRegC2	= i_Reg   == REG_C2	,	
		fRegS	= i_Reg   == REG_S	,
		fRegM	= i_Reg   == REG_M	,
		fRegE	= i_Reg   == REG_E	;
assign	fWrRegE	= fIdle && i_fWr && fRegE,	
		fWrRegM	= fIdle && i_fWr && fRegM;	
assign	fLastCntN	= &c_CntN,	
		fLastCntDgr	= &c_CntDgr,
		f1stCntDgr	= c_CntDgr	== 0;
assign	fIncCntDgr	= c_state == INIT || c_state == CAL;
assign	fIncCntN	= fLast && !fPause;

// S, R, A, B, M(8-bit), M(1-bit), C1(8-bit), C2(8-bit) from memory
assign	ReadSR	= c_CntDgr		[0] ? Mem_o_Data0[0 +:11] : Mem_o_Data0[16+:11];
assign	ReadAB	= c_DgrP		[0] ? Mem_o_Data1[0 +:10] : Mem_o_Data1[16+:10];
assign	ReadE	= c_CntN		[0] ? Mem_o_Data1[10+: 4] : Mem_o_Data1[26+: 4];
assign	ReadM8	= {Mem_o_Data1[26+: 4], Mem_o_Data1[10+: 4]};
assign	ReadM	= ReadM8		[ ~c_CntN	[2:0]];
assign	ReadC1	= Mem_o_Data1	[{~c_DgrP[1:0], 3'b0}+:8];
assign	ReadC2	= Mem_o_Data1	[{~c_CntN	[1:0], 3'b0}+:8];

assign	{fNegN, DgrP}	= c_CntN - ReadSR[9:0];

// Sum = Sum +- (A or B or C1)
assign	Sum_i_0		= c_Sum;
assign	Sum_i_1		= fSum   ? fDec ? ReadC1 : ReadAB : 0;
assign	Sum_o		= c_fNeg ? Sum_i_0 - Sum_i_1 : Sum_i_0 + Sum_i_1;

assign	fPause		= o_fRdRdy && !i_fRd;

// c_CntN +1 or c_CntDgr + 1
assign	NextCnt		= (fIncCntN ? c_CntN : c_CntDgr) + 1;

always@*	// output values
	case(i_Mode)
		KEY_GEN	:	begin	NextWord = {c_Word, 6'b0, Sum_o};	fLastData =  c_CntN[  0];	end // B
		DEC		:	begin	NextWord = {c_Word, ^Sum_o[7:6]};	fLastData = &c_CntN[4:0];	end // M
		default	:	begin	NextWord = {c_Word, Sum_o[9:2]};	fLastData = &c_CntN[1:0];	end // C1, C2
	endcase

always@*	// initial values
	case(i_Mode)
		ENC0	: InitValue = 2;						// ENC0: 2
        ENC1	: InitValue = {ReadM, 9'h2}	;			// ENC1: (M 1-bit << 2) + 2
        DEC		: InitValue = ReadC2;					// DEC : C2
        default	: InitValue = {{6{ReadE[3]}}, ReadE};	// KG  : E
	endcase
		
always@*
begin
	n_DgrP		= fIncCntDgr? DgrP						: c_DgrP;
	n_fNegP		= fIncCntDgr? fNeg ^ fKG ^ ReadSR[10]	: c_fNegP;
	n_Word		= fIncCntN	? NextWord 					: c_Word;

	n_CntN		= fIdle	? 0 : fIncCntN	? NextCnt	: c_CntN;
	n_CntDgr	= fIdle	? 0 : fIncCntDgr? NextCnt	: c_CntDgr;

	n_Sum		= fInit		? InitValue :
				  fCal		? Sum_o 	: c_Sum;

	n_state = c_state;
	case(c_state)
		IDLE	:	if(i_Start)			n_state = INIT;
		INIT	:						n_state = CAL;	// lines 2-
		CAL		:	if(fLastCntDgr)		n_state = LAST;	// lines 7-10, 11-14, 7-10, 11-14, ..., 7-10
		LAST	:	if(!fPause)							// lines 11-14, 15-19, 
						if(fLastCntN)	n_state = IDLE;	//                     20-24
						else			n_state = INIT;
	endcase
end

endmodule


// -255 ~ 255 => -7 ~ + 7
module	LZDR_E(
	input	wire	[8:0]	i_RN,
	output	reg		[3:0]	o_E
);

always@*
	if(!i_RN[8])	case(i_RN[7:0])
		8'h00	:	o_E = 4'h0;		8'h01	:	o_E = 4'h0;		8'h02	:	o_E = 4'h0;		8'h03	:	o_E = 4'h0;
		8'h04	:	o_E = 4'h0;		8'h05	:	o_E = 4'h0;		8'h06	:	o_E = 4'h0;		8'h07	:	o_E = 4'h0;
		8'h08	:	o_E = 4'h0;		8'h09	:	o_E = 4'h0;		8'h0a	:	o_E = 4'h0;		8'h0b	:	o_E = 4'h0;
		8'h0c	:	o_E = 4'h0;		8'h0d	:	o_E = 4'h0;		8'h0e	:	o_E = 4'h0;		8'h0f	:	o_E = 4'h0;
		8'h10	:	o_E = 4'h0;		8'h11	:	o_E = 4'h0;		8'h12	:	o_E = 4'h0;		8'h13	:	o_E = 4'h0;
		8'h14	:	o_E = 4'h0;		8'h15	:	o_E = 4'h0;		8'h16	:	o_E = 4'h0;		8'h17	:	o_E = 4'h0;
		8'h18	:	o_E = 4'h0;		8'h19	:	o_E = 4'h0;		8'h1a	:	o_E = 4'h0;		8'h1b	:	o_E = 4'h0;
		8'h1c	:	o_E = 4'h0;		8'h1d	:	o_E = 4'h0;		8'h1e	:	o_E = 4'h0;		8'h1f	:	o_E = 4'h0;
		8'h20	:	o_E = 4'h0;		8'h21	:	o_E = 4'h0;		8'h22	:	o_E = 4'h0;		8'h23	:	o_E = 4'h0;
		8'h24	:	o_E = 4'h0;		8'h25	:	o_E = 4'h0;		8'h26	:	o_E = 4'h0;		8'h27	:	o_E = 4'h0;
		8'h28	:	o_E = 4'h0;		8'h29	:	o_E = 4'h0;		8'h2a	:	o_E = 4'h0;		8'h2b	:	o_E = 4'h1;
		8'h2c	:	o_E = 4'h1;		8'h2d	:	o_E = 4'h1;		8'h2e	:	o_E = 4'h1;		8'h2f	:	o_E = 4'h1;
		8'h30	:	o_E = 4'h1;		8'h31	:	o_E = 4'h1;		8'h32	:	o_E = 4'h1;		8'h33	:	o_E = 4'h1;
		8'h34	:	o_E = 4'h1;		8'h35	:	o_E = 4'h1;		8'h36	:	o_E = 4'h1;		8'h37	:	o_E = 4'h1;
		8'h38	:	o_E = 4'h1;		8'h39	:	o_E = 4'h1;		8'h3a	:	o_E = 4'h1;		8'h3b	:	o_E = 4'h1;
		8'h3c	:	o_E = 4'h1;		8'h3d	:	o_E = 4'h1;		8'h3e	:	o_E = 4'h1;		8'h3f	:	o_E = 4'h1;
		8'h40	:	o_E = 4'h1;		8'h41	:	o_E = 4'h1;		8'h42	:	o_E = 4'h1;		8'h43	:	o_E = 4'h1;
		8'h44	:	o_E = 4'h1;		8'h45	:	o_E = 4'h1;		8'h46	:	o_E = 4'h1;		8'h47	:	o_E = 4'h1;
		8'h48	:	o_E = 4'h1;		8'h49	:	o_E = 4'h1;		8'h4a	:	o_E = 4'h1;		8'h4b	:	o_E = 4'h1;
		8'h4c	:	o_E = 4'h1;		8'h4d	:	o_E = 4'h1;		8'h4e	:	o_E = 4'h1;		8'h4f	:	o_E = 4'h1;
		8'h50	:	o_E = 4'h1;		8'h51	:	o_E = 4'h1;		8'h52	:	o_E = 4'h1;		8'h53	:	o_E = 4'h1;
		8'h54	:	o_E = 4'h1;		8'h55	:	o_E = 4'h1;		8'h56	:	o_E = 4'h1;		8'h57	:	o_E = 4'h1;
		8'h58	:	o_E = 4'h1;		8'h59	:	o_E = 4'h1;		8'h5a	:	o_E = 4'h1;		8'h5b	:	o_E = 4'h1;
		8'h5c	:	o_E = 4'h1;		8'h5d	:	o_E = 4'h1;		8'h5e	:	o_E = 4'h1;		8'h5f	:	o_E = 4'h1;
		8'h60	:	o_E = 4'h1;		8'h61	:	o_E = 4'h1;		8'h62	:	o_E = 4'h1;		8'h63	:	o_E = 4'h1;
		8'h64	:	o_E = 4'h1;		8'h65	:	o_E = 4'h1;		8'h66	:	o_E = 4'h1;		8'h67	:	o_E = 4'h1;
		8'h68	:	o_E = 4'h1;		8'h69	:	o_E = 4'h1;		8'h6a	:	o_E = 4'h1;		8'h6b	:	o_E = 4'h1;
		8'h6c	:	o_E = 4'h1;		8'h6d	:	o_E = 4'h1;		8'h6e	:	o_E = 4'h1;		8'h6f	:	o_E = 4'h1;
		8'h70	:	o_E = 4'h1;		8'h71	:	o_E = 4'h1;		8'h72	:	o_E = 4'h1;		8'h73	:	o_E = 4'h1;
		8'h74	:	o_E = 4'h1;		8'h75	:	o_E = 4'h1;		8'h76	:	o_E = 4'h1;		8'h77	:	o_E = 4'h1;
		8'h78	:	o_E = 4'h1;		8'h79	:	o_E = 4'h2;		8'h7a	:	o_E = 4'h2;		8'h7b	:	o_E = 4'h2;
		8'h7c	:	o_E = 4'h2;		8'h7d	:	o_E = 4'h2;		8'h7e	:	o_E = 4'h2;		8'h7f	:	o_E = 4'h2;
		8'h80	:	o_E = 4'h2;		8'h81	:	o_E = 4'h2;		8'h82	:	o_E = 4'h2;		8'h83	:	o_E = 4'h2;
		8'h84	:	o_E = 4'h2;		8'h85	:	o_E = 4'h2;		8'h86	:	o_E = 4'h2;		8'h87	:	o_E = 4'h2;
		8'h88	:	o_E = 4'h2;		8'h89	:	o_E = 4'h2;		8'h8a	:	o_E = 4'h2;		8'h8b	:	o_E = 4'h2;
		8'h8c	:	o_E = 4'h2;		8'h8d	:	o_E = 4'h2;		8'h8e	:	o_E = 4'h2;		8'h8f	:	o_E = 4'h2;
		8'h90	:	o_E = 4'h2;		8'h91	:	o_E = 4'h2;		8'h92	:	o_E = 4'h2;		8'h93	:	o_E = 4'h2;
		8'h94	:	o_E = 4'h2;		8'h95	:	o_E = 4'h2;		8'h96	:	o_E = 4'h2;		8'h97	:	o_E = 4'h2;
		8'h98	:	o_E = 4'h2;		8'h99	:	o_E = 4'h2;		8'h9a	:	o_E = 4'h2;		8'h9b	:	o_E = 4'h2;
		8'h9c	:	o_E = 4'h2;		8'h9d	:	o_E = 4'h2;		8'h9e	:	o_E = 4'h2;		8'h9f	:	o_E = 4'h2;
		8'ha0	:	o_E = 4'h2;		8'ha1	:	o_E = 4'h2;		8'ha2	:	o_E = 4'h2;		8'ha3	:	o_E = 4'h2;
		8'ha4	:	o_E = 4'h2;		8'ha5	:	o_E = 4'h2;		8'ha6	:	o_E = 4'h2;		8'ha7	:	o_E = 4'h2;
		8'ha8	:	o_E = 4'h2;		8'ha9	:	o_E = 4'h2;		8'haa	:	o_E = 4'h2;		8'hab	:	o_E = 4'h2;
		8'hac	:	o_E = 4'h2;		8'had	:	o_E = 4'h2;		8'hae	:	o_E = 4'h2;		8'haf	:	o_E = 4'h2;
		8'hb0	:	o_E = 4'h2;		8'hb1	:	o_E = 4'h2;		8'hb2	:	o_E = 4'h2;		8'hb3	:	o_E = 4'h2;
		8'hb4	:	o_E = 4'h2;		8'hb5	:	o_E = 4'h3;		8'hb6	:	o_E = 4'h3;		8'hb7	:	o_E = 4'h3;
		8'hb8	:	o_E = 4'h3;		8'hb9	:	o_E = 4'h3;		8'hba	:	o_E = 4'h3;		8'hbb	:	o_E = 4'h3;
		8'hbc	:	o_E = 4'h3;		8'hbd	:	o_E = 4'h3;		8'hbe	:	o_E = 4'h3;		8'hbf	:	o_E = 4'h3;
		8'hc0	:	o_E = 4'h3;		8'hc1	:	o_E = 4'h3;		8'hc2	:	o_E = 4'h3;		8'hc3	:	o_E = 4'h3;
		8'hc4	:	o_E = 4'h3;		8'hc5	:	o_E = 4'h3;		8'hc6	:	o_E = 4'h3;		8'hc7	:	o_E = 4'h3;
		8'hc8	:	o_E = 4'h3;		8'hc9	:	o_E = 4'h3;		8'hca	:	o_E = 4'h3;		8'hcb	:	o_E = 4'h3;
		8'hcc	:	o_E = 4'h3;		8'hcd	:	o_E = 4'h3;		8'hce	:	o_E = 4'h3;		8'hcf	:	o_E = 4'h3;
		8'hd0	:	o_E = 4'h3;		8'hd1	:	o_E = 4'h3;		8'hd2	:	o_E = 4'h3;		8'hd3	:	o_E = 4'h3;
		8'hd4	:	o_E = 4'h3;		8'hd5	:	o_E = 4'h3;		8'hd6	:	o_E = 4'h3;		8'hd7	:	o_E = 4'h3;
		8'hd8	:	o_E = 4'h3;		8'hd9	:	o_E = 4'h3;		8'hda	:	o_E = 4'h3;		8'hdb	:	o_E = 4'h3;
		8'hdc	:	o_E = 4'h4;		8'hdd	:	o_E = 4'h4;		8'hde	:	o_E = 4'h4;		8'hdf	:	o_E = 4'h4;
		8'he0	:	o_E = 4'h4;		8'he1	:	o_E = 4'h4;		8'he2	:	o_E = 4'h4;		8'he3	:	o_E = 4'h4;
		8'he4	:	o_E = 4'h4;		8'he5	:	o_E = 4'h4;		8'he6	:	o_E = 4'h4;		8'he7	:	o_E = 4'h4;
		8'he8	:	o_E = 4'h4;		8'he9	:	o_E = 4'h4;		8'hea	:	o_E = 4'h4;		8'heb	:	o_E = 4'h4;
		8'hec	:	o_E = 4'h4;		8'hed	:	o_E = 4'h4;		8'hee	:	o_E = 4'h4;		8'hef	:	o_E = 4'h4;
		8'hf0	:	o_E = 4'h4;		8'hf1	:	o_E = 4'h5;		8'hf2	:	o_E = 4'h5;		8'hf3	:	o_E = 4'h5;
		8'hf4	:	o_E = 4'h5;		8'hf5	:	o_E = 4'h5;		8'hf6	:	o_E = 4'h5;		8'hf7	:	o_E = 4'h5;
		8'hf8	:	o_E = 4'h5;		8'hf9	:	o_E = 4'h5;		8'hfa	:	o_E = 4'h5;		8'hfb	:	o_E = 4'h6;
		8'hfc	:	o_E = 4'h6;		8'hfd	:	o_E = 4'h6;		8'hfe	:	o_E = 4'h6;		8'hff	:	o_E = 4'h7;
	endcase else case(i_RN[7:0])
		8'h00	:	o_E = 4'h0;		8'h01	:	o_E = 4'h0;		8'h02	:	o_E = 4'h0;		8'h03	:	o_E = 4'h0;
		8'h04	:	o_E = 4'h0;		8'h05	:	o_E = 4'h0;		8'h06	:	o_E = 4'h0;		8'h07	:	o_E = 4'h0;
		8'h08	:	o_E = 4'h0;		8'h09	:	o_E = 4'h0;		8'h0a	:	o_E = 4'h0;		8'h0b	:	o_E = 4'h0;
		8'h0c	:	o_E = 4'h0;		8'h0d	:	o_E = 4'h0;		8'h0e	:	o_E = 4'h0;		8'h0f	:	o_E = 4'h0;
		8'h10	:	o_E = 4'h0;		8'h11	:	o_E = 4'h0;		8'h12	:	o_E = 4'h0;		8'h13	:	o_E = 4'h0;
		8'h14	:	o_E = 4'h0;		8'h15	:	o_E = 4'h0;		8'h16	:	o_E = 4'h0;		8'h17	:	o_E = 4'h0;
		8'h18	:	o_E = 4'h0;		8'h19	:	o_E = 4'h0;		8'h1a	:	o_E = 4'h0;		8'h1b	:	o_E = 4'h0;
		8'h1c	:	o_E = 4'h0;		8'h1d	:	o_E = 4'h0;		8'h1e	:	o_E = 4'h0;		8'h1f	:	o_E = 4'h0;
		8'h20	:	o_E = 4'h0;		8'h21	:	o_E = 4'h0;		8'h22	:	o_E = 4'h0;		8'h23	:	o_E = 4'h0;
		8'h24	:	o_E = 4'h0;		8'h25	:	o_E = 4'h0;		8'h26	:	o_E = 4'h0;		8'h27	:	o_E = 4'h0;
		8'h28	:	o_E = 4'h0;		8'h29	:	o_E = 4'h0;		8'h2a	:	o_E = 4'h0;		8'h2b	:	o_E = 4'hf;
		8'h2c	:	o_E = 4'hf;		8'h2d	:	o_E = 4'hf;		8'h2e	:	o_E = 4'hf;		8'h2f	:	o_E = 4'hf;
		8'h30	:	o_E = 4'hf;		8'h31	:	o_E = 4'hf;		8'h32	:	o_E = 4'hf;		8'h33	:	o_E = 4'hf;
		8'h34	:	o_E = 4'hf;		8'h35	:	o_E = 4'hf;		8'h36	:	o_E = 4'hf;		8'h37	:	o_E = 4'hf;
		8'h38	:	o_E = 4'hf;		8'h39	:	o_E = 4'hf;		8'h3a	:	o_E = 4'hf;		8'h3b	:	o_E = 4'hf;
		8'h3c	:	o_E = 4'hf;		8'h3d	:	o_E = 4'hf;		8'h3e	:	o_E = 4'hf;		8'h3f	:	o_E = 4'hf;
		8'h40	:	o_E = 4'hf;		8'h41	:	o_E = 4'hf;		8'h42	:	o_E = 4'hf;		8'h43	:	o_E = 4'hf;
		8'h44	:	o_E = 4'hf;		8'h45	:	o_E = 4'hf;		8'h46	:	o_E = 4'hf;		8'h47	:	o_E = 4'hf;
		8'h48	:	o_E = 4'hf;		8'h49	:	o_E = 4'hf;		8'h4a	:	o_E = 4'hf;		8'h4b	:	o_E = 4'hf;
		8'h4c	:	o_E = 4'hf;		8'h4d	:	o_E = 4'hf;		8'h4e	:	o_E = 4'hf;		8'h4f	:	o_E = 4'hf;
		8'h50	:	o_E = 4'hf;		8'h51	:	o_E = 4'hf;		8'h52	:	o_E = 4'hf;		8'h53	:	o_E = 4'hf;
		8'h54	:	o_E = 4'hf;		8'h55	:	o_E = 4'hf;		8'h56	:	o_E = 4'hf;		8'h57	:	o_E = 4'hf;
		8'h58	:	o_E = 4'hf;		8'h59	:	o_E = 4'hf;		8'h5a	:	o_E = 4'hf;		8'h5b	:	o_E = 4'hf;
		8'h5c	:	o_E = 4'hf;		8'h5d	:	o_E = 4'hf;		8'h5e	:	o_E = 4'hf;		8'h5f	:	o_E = 4'hf;
		8'h60	:	o_E = 4'hf;		8'h61	:	o_E = 4'hf;		8'h62	:	o_E = 4'hf;		8'h63	:	o_E = 4'hf;
		8'h64	:	o_E = 4'hf;		8'h65	:	o_E = 4'hf;		8'h66	:	o_E = 4'hf;		8'h67	:	o_E = 4'hf;
		8'h68	:	o_E = 4'hf;		8'h69	:	o_E = 4'hf;		8'h6a	:	o_E = 4'hf;		8'h6b	:	o_E = 4'hf;
		8'h6c	:	o_E = 4'hf;		8'h6d	:	o_E = 4'hf;		8'h6e	:	o_E = 4'hf;		8'h6f	:	o_E = 4'hf;
		8'h70	:	o_E = 4'hf;		8'h71	:	o_E = 4'hf;		8'h72	:	o_E = 4'hf;		8'h73	:	o_E = 4'hf;
		8'h74	:	o_E = 4'hf;		8'h75	:	o_E = 4'hf;		8'h76	:	o_E = 4'hf;		8'h77	:	o_E = 4'hf;
		8'h78	:	o_E = 4'hf;		8'h79	:	o_E = 4'he;		8'h7a	:	o_E = 4'he;		8'h7b	:	o_E = 4'he;
		8'h7c	:	o_E = 4'he;		8'h7d	:	o_E = 4'he;		8'h7e	:	o_E = 4'he;		8'h7f	:	o_E = 4'he;
		8'h80	:	o_E = 4'he;		8'h81	:	o_E = 4'he;		8'h82	:	o_E = 4'he;		8'h83	:	o_E = 4'he;
		8'h84	:	o_E = 4'he;		8'h85	:	o_E = 4'he;		8'h86	:	o_E = 4'he;		8'h87	:	o_E = 4'he;
		8'h88	:	o_E = 4'he;		8'h89	:	o_E = 4'he;		8'h8a	:	o_E = 4'he;		8'h8b	:	o_E = 4'he;
		8'h8c	:	o_E = 4'he;		8'h8d	:	o_E = 4'he;		8'h8e	:	o_E = 4'he;		8'h8f	:	o_E = 4'he;
		8'h90	:	o_E = 4'he;		8'h91	:	o_E = 4'he;		8'h92	:	o_E = 4'he;		8'h93	:	o_E = 4'he;
		8'h94	:	o_E = 4'he;		8'h95	:	o_E = 4'he;		8'h96	:	o_E = 4'he;		8'h97	:	o_E = 4'he;
		8'h98	:	o_E = 4'he;		8'h99	:	o_E = 4'he;		8'h9a	:	o_E = 4'he;		8'h9b	:	o_E = 4'he;
		8'h9c	:	o_E = 4'he;		8'h9d	:	o_E = 4'he;		8'h9e	:	o_E = 4'he;		8'h9f	:	o_E = 4'he;
		8'ha0	:	o_E = 4'he;		8'ha1	:	o_E = 4'he;		8'ha2	:	o_E = 4'he;		8'ha3	:	o_E = 4'he;
		8'ha4	:	o_E = 4'he;		8'ha5	:	o_E = 4'he;		8'ha6	:	o_E = 4'he;		8'ha7	:	o_E = 4'he;
		8'ha8	:	o_E = 4'he;		8'ha9	:	o_E = 4'he;		8'haa	:	o_E = 4'he;		8'hab	:	o_E = 4'he;
		8'hac	:	o_E = 4'he;		8'had	:	o_E = 4'he;		8'hae	:	o_E = 4'he;		8'haf	:	o_E = 4'he;
		8'hb0	:	o_E = 4'he;		8'hb1	:	o_E = 4'he;		8'hb2	:	o_E = 4'he;		8'hb3	:	o_E = 4'he;
		8'hb4	:	o_E = 4'he;		8'hb5	:	o_E = 4'hd;		8'hb6	:	o_E = 4'hd;		8'hb7	:	o_E = 4'hd;
		8'hb8	:	o_E = 4'hd;		8'hb9	:	o_E = 4'hd;		8'hba	:	o_E = 4'hd;		8'hbb	:	o_E = 4'hd;
		8'hbc	:	o_E = 4'hd;		8'hbd	:	o_E = 4'hd;		8'hbe	:	o_E = 4'hd;		8'hbf	:	o_E = 4'hd;
		8'hc0	:	o_E = 4'hd;		8'hc1	:	o_E = 4'hd;		8'hc2	:	o_E = 4'hd;		8'hc3	:	o_E = 4'hd;
		8'hc4	:	o_E = 4'hd;		8'hc5	:	o_E = 4'hd;		8'hc6	:	o_E = 4'hd;		8'hc7	:	o_E = 4'hd;
		8'hc8	:	o_E = 4'hd;		8'hc9	:	o_E = 4'hd;		8'hca	:	o_E = 4'hd;		8'hcb	:	o_E = 4'hd;
		8'hcc	:	o_E = 4'hd;		8'hcd	:	o_E = 4'hd;		8'hce	:	o_E = 4'hd;		8'hcf	:	o_E = 4'hd;
		8'hd0	:	o_E = 4'hd;		8'hd1	:	o_E = 4'hd;		8'hd2	:	o_E = 4'hd;		8'hd3	:	o_E = 4'hd;
		8'hd4	:	o_E = 4'hd;		8'hd5	:	o_E = 4'hd;		8'hd6	:	o_E = 4'hd;		8'hd7	:	o_E = 4'hd;
		8'hd8	:	o_E = 4'hd;		8'hd9	:	o_E = 4'hd;		8'hda	:	o_E = 4'hd;		8'hdb	:	o_E = 4'hd;
		8'hdc	:	o_E = 4'hc;		8'hdd	:	o_E = 4'hc;		8'hde	:	o_E = 4'hc;		8'hdf	:	o_E = 4'hc;
		8'he0	:	o_E = 4'hc;		8'he1	:	o_E = 4'hc;		8'he2	:	o_E = 4'hc;		8'he3	:	o_E = 4'hc;
		8'he4	:	o_E = 4'hc;		8'he5	:	o_E = 4'hc;		8'he6	:	o_E = 4'hc;		8'he7	:	o_E = 4'hc;
		8'he8	:	o_E = 4'hc;		8'he9	:	o_E = 4'hc;		8'hea	:	o_E = 4'hc;		8'heb	:	o_E = 4'hc;
		8'hec	:	o_E = 4'hc;		8'hed	:	o_E = 4'hc;		8'hee	:	o_E = 4'hc;		8'hef	:	o_E = 4'hc;
		8'hf0	:	o_E = 4'hc;		8'hf1	:	o_E = 4'hb;		8'hf2	:	o_E = 4'hb;		8'hf3	:	o_E = 4'hb;
		8'hf4	:	o_E = 4'hb;		8'hf5	:	o_E = 4'hb;		8'hf6	:	o_E = 4'hb;		8'hf7	:	o_E = 4'hb;
		8'hf8	:	o_E = 4'hb;		8'hf9	:	o_E = 4'hb;		8'hfa	:	o_E = 4'hb;		8'hfb	:	o_E = 4'ha;
		8'hfc	:	o_E = 4'ha;		8'hfd	:	o_E = 4'ha;		8'hfe	:	o_E = 4'ha;		8'hff	:	o_E = 4'h9;
	endcase
endmodule
