/* algorithm
 A. Key generation
 1: for (cnt_m = 0 ; cnt_m < m ; cnt_m++){
 2: 	for (cnt_n = 0 ; cnt_n < n/2 ; cnt_n++)	// In32: A��s elements in cnt_m-th row �� 0x2600~0x272F
 3: 		Mem[0x2600 + cnt_n] = In32;	
 4: 	for (cnt_l = 0 ; cnt_l < l/2 ; cnt_l++)	// In32: E��s elements in cnt_m-th row �� 0x2600~0x267F
 5: 		Mem[0x2600 + cnt_l] = (Mem[0x2600 + cnt_l] & Mask) | GetE(In32);
 6: 	for (cnt_l = 0 ; cnt_l < l ; cnt_l++){
 7: 		for (cnt_n = 0 ; cnt_n < n ; cnt_n++){
 8: 			W0 = Mem[0x2600 + cnt_n/2];	A = Sel_A(W0, cnt_n % 2);
 9: 			W1 = Mem[(cnt_n �� l + cnt_l)/16];	S = Sel_S(W1, cnt_l % 16);
10: 			if (cnt_n == 0)	Sum = 0 ? S �� A;
11: 			else			Sum = Sum ? S �� A;
12:			}
13: 		W0 = Mem[0x2600 + cnt_l/2];	E = Sel_E(W0, cnt_l % 2) �� 10;
14: 		if (E �� 3)	W = (W �� 16) + (Sum ? (E & 7));	// E is negative number
15: 		else		W = (W �� 16) + (Sum + E);	// E is positive number
16:		}
17: 	if (cnt_l % 2)	Out32 = W;
18: }                              

 B. Encryption
 1: for (cnt_n = 0 ; cnt_n < n ; cnt_n++){
 2: 	for (cnt_m = 0 ; cnt_m < m ; cnt_m++){		// In16: A��s elements in Cntn-th column
 3: 		W1 = Mem[0x40 + cnt_m/16];	R = Sel_S(W1, cnt_m % 16);
 4: 		if (cnt_m == 0)	T = 2 + R �� In16;
 5: 		else 			T = Sum + R �� In16;
 6: 		if (cnt_m < m ? 1)	Sum = T
 7: 		else				W = (W �� 8) + (T �� 2);
 8:		}
 9: 	if (cnt_n % 4 == 3)	Mem[0x2600 + cnt_n/2] = W;
10:	}
11: for (cnt_l = 0 ; cnt_l < l ; cnt_l++)	{
12: 	for (cnt_m = 0 ; cnt_m < m ; cnt_m++){		// In16: B��s elements in Cntl-th column
13: 		W0 = Mem[cnt_l/32];			M = Sel_M(W0, cnt_l % 32);
14: 		W1 = Mem[0x40 + cnt_m/16];	R = Sel_S(W1, cnt_n % 16);
15: 		if (cnt_m == 0)	T = (M �� 9) +2 + R �� In16;
16: 		else 			T = Sum + R �� In16;
17: 		if (cnt_m != m ? 1)	Sum = T
18: 		else				W = (W �� 8) + (T �� 2);
19:		}
20: 	if (cnt_l % 4 == 3)	Mem[0x2700 + cnt_l/2] = W;
21:	}

 C. Decryption
 1:	for (cnt_l = 0 ; cnt_l < l ; cnt_l++)	{	// In16: A��s elements in Cntn-th column
 2:		W0 = Mem[0x2700 + cnt_l/4];	C2 = Sel_C(W1, cnt_l % 4);
 3:		Sum = C2;
 4:		for (cnt_n = 0 ; cnt_n < n ; cnt_n++)	{
 5:			W0 = Mem[cnt_n/4];	C1 = Sel_C(W0, cnt_n % 4);
 6:			W1 = Mem[(cnt_n �� l + cnt_l)/16];	S = Sel_S(W1, cnt_l % 16, 2);
 7:			T = Sum + S �� C1;
 8:			if (cnt_n != n ? 1)	Sum = T;
 9:			else				W = (W �� 1) + (T �� 7 ^ (T % 2) �� 6); 
10:		}
11:		if (cnt_l % 32 == 31)	Mem[cnt_l/32] = W;
12:	}
*/

module	LZDL(i_clk, i_reset,
	i_Start,i_Mode,	i_Reg,	i_Addr,	o_fDone, o_fBusy,
	i_fWr,	i_Data,	o_fWrRdy,	
	i_fRd,	o_Data,	o_fRdRdy
);
//*
parameter	n = 608,	log2n = 10;
parameter	m = 960,	log2m = 10;
parameter	l = 256,	log2l = 8;
parameter	RAM_SIZE= 14'h2730;
parameter	START_A	= 5'b10011,
			START_C1= 6'b100110,
			START_C2= 8'b10011100,
			START_R	= 1'b1,
			START_E	= {START_A, {log2n-log2l{1'b0}}};
parameter	aw = log2n+log2l-4;
parameter	mw = log2n+log2l-4;

/*/ test parameter
parameter	n = 60,		log2n = 6;
parameter	m = 96,		log2m = 7;
parameter	l = 64,		log2l = 6;
parameter	RAM_SIZE= 14'h120;
parameter	START_A	= 4'b1000,
			START_C1= 5'b10000,
			START_C2= 5'b10001,
			START_R	= 1'b1;
parameter	aw = 8;
parameter	mw = 9;
//*/
input	i_clk;
input	i_reset;

input						i_Start;	// Start signal
input			[1:0]		i_Mode;		// Select mode(ENC0: 0, ENC1: 1, DEC: 2, KEY_GEN: 3)
input						i_fWr;		// Write enable
input						i_fRd;		// Read enable
input			[2:0]		i_Reg;		// Register(A: 0, B: 1, C1: 2, C2: 3, S or R: 4, E: 5, M: 6)
input			[aw-1:0]	i_Addr;		// Address
input			[31:0]		i_Data;		// input data - S/R: 2-bit x 16, E: 9-bit x 2, A/B: 10-bit x 2, M: 32-bit, C1/C2: 8-bit x 4
output	wire				o_fRdRdy;	// ready for reading
output	wire				o_fWrRdy;	// ready for writing
output	wire	[31:0]		o_Data;  	// output data - B: 10-bit x 2, M: 32-bit, C1/C2: 8-bit x 4
output	wire				o_fDone;	// flag that the module is finished
output	wire				o_fBusy;	// flag that the module is busy

wire	[31:0]		NextWord;			// W					in algorithm

// Registers
reg		[3:0]		c_state,n_state;	// state for FSM
reg		[31:0]		c_Word,	n_Word;		// Register for W		in algorithm
reg		[9:0]		c_Sum,	n_Sum;  	// Register for Sum		in algorithm
reg		[log2l-1:0]	c_CntL,	n_CntL;		// Register for cnt_l	in algorithm
reg		[log2m-1:0]	c_CntM,	n_CntM;		// Register for cnt_m	in algorithm
reg		[log2n-1:0]	c_CntN,	n_CntN;		// Register for cnt_n	in algorithm

// part bits of the word from memory
wire	[9:0]	ReadA;
wire	[7:0]	ReadC12;
wire	[1:0]	ReadSR;
wire			ReadM;
wire	[3:0]	ReadE;


wire	[31:0]	E_in;	// re-arranged E (2 x 11-bit input(-255 ~ +255) -> 2 x 4-bit E(-7 ~ +7))
wire	[31:0]	S_in;	// re-calculated S (by 10 -> 00, S can have only one of 00, 01, and 11)

wire	[log2m-1:0]	NextCnt;
// Inputs and outputs of sub-module
//	Memory
reg				Mem_i_fWr0,	Mem_i_fWr1;		// write enable of memory
reg				Mem_i_fRd0,	Mem_i_fRd1;		// read enable of memory
reg		[mw-1:0]Mem_i_Addr0,Mem_i_Addr1;	// address of memory     
reg		[31:0]	Mem_i_Data0,Mem_i_Data1;	// input of memory       
wire	[31:0]	Mem_o_Data0,Mem_o_Data1;	// output of memory      

//	LZDR_E: -255 ~ +255 -> -7~ + 7
wire	[3:0]	E0_o;
wire	[3:0]	E1_o;

//	Adder: Sum_o = Sum_i_0 +- Sum_i_1
wire	[9:0]	Sum_i_0, Sum_i_1;			// inputs of adder
wire	[9:0]	Sum_o;						// output of adder: T in algorithm

wire	[1:0]	CntC12;			// one of c_CntL and c_CntN for reading C1 or C2
wire	[3:0]	CntSR;			// one of c_CntM and c_CntL for reading S  or R

// Flags
wire	fIdle		,	// states
		fAin		,
		fEin		,
		fCalB		,	
		fBout		,
		fCalC1		,
		fCalC2		,
		fCalM		,
		fDone		;
wire	fRegC1		,	// i_Reg
		fRegC2		,
		fRegS		,
		fRegR		,
		fRegM		;
wire	fFullWrdB	,	// full word
		fFullWrdC1	,
		fFullWrdC2	,
		fFullWrdM		;
wire	fBtoWrd		,	// needed to go in c_Word
		fCtoWrd		,
		fMtoWrd		;
wire	fRdRegB		,	// read enable of Reg
		fRdRegC1	,
		fRdRegC2	,
		fRdRegM		;
wire	fEnc		,	// modes
		fDec		,
		fKeyGen		;
wire	f1stCntM	,	// counter
		f1stCntN	,
		fLastCntL	,
		fLastCntM	,
		fLastCntN	,
		fIncCntL	,
		fIncCntM	,	
		fIncCntN;	
wire	fStoreSum	;	// Update c_Sum
wire	fInitKG		,	// 1st clock cycle of KG, ENC0 and ENC1
		fInitEnc0	,
		fInitEnc1	;

integer	i;
parameter	REG_C1	= 3'h0,	// Registers
			REG_C2	= 3'h1,
			REG_S	= 3'h2,
			REG_M	= 3'h3,
			REG_A	= 3'h4,
			REG_E	= 3'h5,
			REG_R	= 3'h6;
parameter	ENC		= 2'h1,	// Mode
			DEC		= 2'h2,
			KEY_GEN = 2'h3;
parameter	IDLE	= 4'h0,	// state
			A_IN	= 4'h1,
			E_IN	= 4'h2,
			CAL_B	= 4'h3,
			B_OUT	= 4'h4,
			CAL_C1	= 4'h5,
			CAL_C2	= 4'h6,
			INIT_M	= 4'h7,
			CAL_M	= 4'h8,
			WR_M	= 4'h9,
			DONE	= 4'ha;
parameter	ROW0	= 5'b10011;		// start address
// Outputs
// Keygen : B from NextWord
// Enc : C1/C2 from the 1st port of MEM
// Dec : M from the 2nd prot of MEM
assign	o_Data		= fRdRegC1 || fRdRegC2	? Mem_o_Data0 : 
					  fRdRegM				? Mem_o_Data1 : NextWord;
assign	o_fDone		= fDone;
assign	o_fBusy		= !fIdle;
assign	o_fRdRdy	= fIdle	|| fFullWrdB;
assign	o_fWrRdy	= fIdle || 				// S for Keygen, M/R for Enc, S/C1/C2 for Dec
					  fAin	|| fEin		|| 	// for KeyGen
					  fCalC1 || fCalC2;		// for Enc
	
// Flags
assign	fIdle		= c_state == IDLE	,	// states
		fAin		= c_state == A_IN	,
		fEin		= c_state == E_IN	,
		fCalB		= c_state == CAL_B	,
		fBout		= c_state == B_OUT	,
		fCalC1		= c_state == CAL_C1	,
		fCalC2		= c_state == CAL_C2	,
		fInitM		= c_state == INIT_M	,
		fCalM		= c_state == CAL_M	,
		fWrM		= c_state == WR_M	,
		fDone		= c_state == DONE	;
assign	fRegC1		= i_Reg == REG_C1	,	// i_Reg
		fRegC2		= i_Reg == REG_C2	,	
		fRegS		= i_Reg == REG_S	,	
		fRegR		= i_Reg == REG_R	,	
		fRegM		= i_Reg == REG_M	;	
assign	fWrRegSR	= i_fWr && fIdle	&& (fRegS || fRegR)	,	// write enable of Reg
		fWrRegR		= i_fWr && fIdle	&& fRegR	,
		fWrRegE		= i_fWr && fEin					,
		fWrRegA0	= i_fWr && fAin					,
		fWrRegA1	= i_fWr && fCalC1				,
		fWrRegA		= i_fWr &&(fCalC1	|| fAin)	,
		fWrRegB		= i_fWr && fCalC2				,
		fWrRegC1	= i_fWr && fIdle	&& fRegC1	,
		fWrRegC2	= i_fWr && fIdle	&& fRegC2	,
		fWrRegM		= i_fWr && fIdle	&& fRegM 	;
assign	fRdRegB		= i_fRd && fBout			,	// read enable of Reg
		fRdRegC1	= i_fRd && fIdle && fRegC1	,	
		fRdRegC2	= i_fRd && fIdle && fRegC2	,
		fRdRegM		= i_fRd && fIdle && fRegM	;	
assign	fEnc		= i_Mode == ENC,		// modes
		fDec		= i_Mode == DEC  	,
		fKeyGen		= i_Mode == KEY_GEN	;
assign	f1stCntM		= c_CntM == 0,		// counter
		f1stCntN		= c_CntN == 0,
		fLastCntN		= c_CntN == (fCalC2 ? l - 1 : fAin ? n/2 - 1 : n - 1),
		fLastCntL		= c_CntL == (fEin ? l/2 - 1 : l - 1),
		fLastCntM		= c_CntM == m - 1;
assign	fIncCntN	=  fCalB					||
					   fWrRegA0					||
					  (fWrRegA1	&& fLastCntM	)	||
					   fCalM					;
assign	fIncCntL	=  fWrRegE					||
					  (fBout	&& !c_CntL[0])	||
					   fRdRegB					||
					  (fWrRegB	&& fLastCntM	)	||	
					  (fCalM	&& fLastCntN	&& !fFullWrdM	)	|| fWrM;
assign	fIncCntM	= (fRdRegB	&& fLastCntL	)	||
					   fWrRegA1					||
					   fWrRegB					;
				  
assign	fStoreSum	= fCalB					||	// CAL_B
					 (fWrRegA	&& fCalC1)	||	// CAL_C1
					  fWrRegB				||	// CAL_C2
					  fCalM;					// CAL_M

// 32-bit word is fulled with B, C1, C2, or M			  
assign	fFullWrdB	= fBout						&&  c_CntL[  0];
assign	fFullWrdC1	= fLastCntM &&	fWrRegA1	&& &c_CntN[1:0];
assign	fFullWrdC2	= fLastCntM &&	fWrRegB		&& &c_CntL[1:0];
assign	fFullWrdM	= fLastCntN &&	fCalM		&& &c_CntL[4:0];

// Fill 32-bit word with B, C1, C2, or M
assign	fBtoWrd	= fBout;
assign	fCtoWrd	= fLastCntM && (fWrRegA1 || fWrRegB);
assign	fMtoWrd	= fLastCntN && fCalM;

// c_CntM + 1, c_CntL + 1, or c_CntN + 1
assign	NextCnt	= (fIncCntM && !fLastCntM ? c_CntM : fIncCntL && !fLastCntL ? c_CntL : c_CntN) + 1;

always@(posedge i_clk, negedge i_reset)
	if(!i_reset) begin
		c_state		<= 0;
		c_CntL		<= 0;
		c_CntM		<= 0;
		c_CntN		<= 0;
		c_Sum		<= 0;
		c_Word		<= 0;
	end else begin
		c_state		<= n_state		;
		c_CntL		<= n_CntL		;
		c_CntM		<= n_CntM		;
		c_CntN		<= n_CntN		;
		c_Sum		<= n_Sum		;
		c_Word		<= n_Word		;
	end

LZDL_RAM	RAM0(i_clk, fWrRegE,
	Mem_i_fWr0,	Mem_i_fRd0,	Mem_i_Addr0,	Mem_i_Data0,	Mem_o_Data0,
	Mem_i_fWr1,	Mem_i_fRd1,	Mem_i_Addr1,	Mem_i_Data1,	Mem_o_Data1
);

always@*	// Input/Output definition of dual port momery
begin	
	Mem_i_fRd0	= fRdRegC1	|| fRdRegC2		|| fCalM	|| fCalB	|| fInitM	|| fInitEnc1	|| fBout;
	Mem_i_fRd1	= fRdRegM					|| fCalM	|| fCalB	|| fCalC1	|| fCalC2;
	Mem_i_fWr0	= fWrRegC1	|| fWrRegC2		|| fWrRegA0 || 
				  fWrRegE	|| 
				  fFullWrdC1|| fFullWrdC2	|| fWrM;
	Mem_i_fWr1	= fWrRegM	|| 
				  fWrRegSR;
	Mem_i_Data0	= fWrRegC1	|| fWrRegC2	|| fWrRegA0	? i_Data	: 
				  fWrRegE							? E_in		: NextWord;
	Mem_i_Data1	= fWrRegM							? i_Data	: 
				  fWrRegSR							? S_in		: NextWord;
	Mem_i_Addr0	= fIdle	&& fRegC1			? {START_C1, i_Addr[log2n-3:0]} :		// C1(Write)
  				  fIdle	&& fRegC2			? {START_C2, i_Addr[log2l-3:0]} :		// C1(Write)
  				  fFullWrdC2|| fInitM		? {START_C2, c_CntL[log2l-1:2]} : 		// C2(Write/Read)
  				  fInitEnc1	|| fWrM			? c_CntL[log2l-1:5]				:		// M (Read)
  				  fEin						? {START_E,  c_CntL[log2l-2:0]}	:		// E (Write)
  				  fBout						? {START_E,  c_CntL[log2l-1:1]}	:		// E (Read)
  				  fFullWrdC1|| fCalM		? {START_C1, c_CntN[log2n-1:2]} :		// C1(Write/Read)
  				  fCalB						? {START_A,  c_CntN[log2n-1:1]} : 		// A (Read)
  				  fAin						? {START_A,  c_CntN[log2n-2:0]} : 0;	// A (Write)
	Mem_i_Addr1 = fCalB 	|| fCalM		? {c_CntN,	 c_CntL[log2l-1:4]}	:		// S (Read)
				  fCalC1	|| fCalC2		? {START_R,	 c_CntM[log2m-1:4]}	: 		// R (Read)
				  fIdle	&& fRegR			? {START_R,	 i_Addr[log2m-5:0]}	: 		// R (Write)
				  fIdle && (fRegS || fRegM)	? i_Addr						: 0;	// S (Write), M(Write/Read)
end

// Change 10 to 00
assign	S_in = {&i_Data[2*15+:2], i_Data[2*15],
				&i_Data[2*14+:2], i_Data[2*14],
				&i_Data[2*13+:2], i_Data[2*13],
				&i_Data[2*12+:2], i_Data[2*12],
				&i_Data[2*11+:2], i_Data[2*11],
				&i_Data[2*10+:2], i_Data[2*10],
				&i_Data[2* 9+:2], i_Data[2* 9],
				&i_Data[2* 8+:2], i_Data[2* 8],
				&i_Data[2* 7+:2], i_Data[2* 7],
				&i_Data[2* 6+:2], i_Data[2* 6],
				&i_Data[2* 5+:2], i_Data[2* 5],
				&i_Data[2* 4+:2], i_Data[2* 4],
				&i_Data[2* 3+:2], i_Data[2* 3],
				&i_Data[2* 2+:2], i_Data[2* 2],
				&i_Data[2* 1+:2], i_Data[2* 1],
				&i_Data[2* 0+:2], i_Data[2* 0]};

LZDL_E	E0(i_Data[16+:8], E0_o[2:0]);	assign	E0_o[3] = i_Data[16+8];
LZDL_E	E1(i_Data[0 +:8], E1_o[2:0]);	assign	E1_o[3] = i_Data[0 +8];


// Store E(4-bit x 2) to ullage space of A 
assign	E_in	= {	2'b0, E0_o, 10'b0, 
					2'b0, E1_o, 10'b0};

// A(10-bit), E(4-bit), C1/C2(8-bit), S/R(2-bit), M(1-bit) from memory
assign	CntC12	= fFullWrdC2|| fInitM ? c_CntL[1:0] : c_CntN[1:0],
		CntSR	= fCalC1	|| fCalC2 ? c_CntM[3:0] : c_CntL[3:0];
assign	ReadA	= c_CntN[0] ? Mem_o_Data0[0 +:10] : Mem_o_Data0[16+:10],
		ReadE	= c_CntL[0] ? Mem_o_Data0[10+: 4] : Mem_o_Data0[26+: 4],
		ReadC12	= Mem_o_Data0[{~CntC12, 3'b0}+: 8],	
		ReadSR	= Mem_o_Data1[{~CntSR , 1'b0}+: 2],	
		ReadM	= Mem_o_Data0[ ~c_CntL[4:0]];
// Sum = (0, 2, (M << 9) + 2, or Sum) +- (E, C1, C2, or A)
assign	fInitKG		= fCalB		&& f1stCntN,
		fInitEnc0	= fWrRegA1	&& f1stCntM,
		fInitEnc1	= fWrRegB	&& f1stCntM
assign	Sum_i_0	= fInitKG	? 0 : fInitEnc0 ? 9'h2 : fInitEnc1 ? {ReadM, 9'h2} : c_Sum,
		Sum_i_1	= fBout		? ReadE[2:0]: 
				  ReadSR[0] ? 
				  	fCalM	? ReadC12	: 
					fCalB	? ReadA		: i_Data : 0,
		Sum_o	= (fBout 	? ReadE[3] : ReadSR[1] ^ fKeyGen) ? Sum_i_0 - Sum_i_1 : Sum_i_0 + Sum_i_1;


assign	NextWord= fBtoWrd	? {c_Word, 6'b0, Sum_o}		: 
				  fCtoWrd	? {c_Word,       Sum_o[9:2]}: 
				  fMtoWrd	? {c_Word,		^Sum_o[7:6]}: c_Word;

always@*
begin
	n_Word		= NextWord;
	n_CntN		= fIncCntN	? fLastCntN ? 0	: NextCnt : c_CntN;
	n_CntL		= fIncCntL	? fLastCntL ? 0	: NextCnt : c_CntL;	
	n_CntM		= fIncCntM	? fLastCntM ? 0	: NextCnt : c_CntM;
	n_Sum		= fStoreSum ? Sum_o			: 
				  fInitM	? ReadC12		: c_Sum;

	n_state = c_state;
	case(c_state)
		IDLE	:	if(i_Start)	case(i_Mode)
						ENC		:							n_state = CAL_C1;
						DEC		:							n_state = INIT_M;
						KEY_GEN	:							n_state = A_IN;
					endcase
		// KeyGen:	1. A_IN: CntN increase -> 2. E_IN: CntL increase -> 3. CAL_B: CntN(B) increase ->
		// 			4. B_OUT: CntL increase -> If final CntL, 3 + CntM increase,	otherwise, 3
		// 								    -> If final CntM, IDLE,				otherwise, 1
		A_IN	:	if(fWrRegA0	&& fLastCntN)				n_state = E_IN;
		E_IN	:	if(fWrRegE  && fLastCntL)				n_state = CAL_B;
		CAL_B	:	if(fLastCntN)							n_state = B_OUT;
		B_OUT	:	if(!c_CntL[0] || fRdRegB)
						if(fLastCntL)						
							if(fLastCntM)					n_state = IDLE;
							else							n_state = A_IN;	
						else								n_state = CAL_B;
		// Enc0: CntM increase -> If final CntM, CntN increase -> if final CntN, CAL_C2
		CAL_C1	:	if(fWrRegA1 && fLastCntM && fLastCntN)	n_state = CAL_C2;
		
		// Enc1: CntM increase -> If final CntM, CntL increase -> if CntN, IDLE
		CAL_C2	:	if(fWrRegB	&& fLastCntM && fLastCntL)	n_state = IDLE;	

		// Dec: 1. INIT_M -> 2. CAL_M: CntN increase -> 32th bit of M
		//		3. WR_M: CntL increase -> If final CntL, DONE. otherwise, INIT_M
		INIT_M	:											n_state = CAL_M;
		CAL_M	:	if(fLastCntN)                           
						if(fFullWrdM)						n_state = WR_M;
						else								n_state = INIT_M;
		WR_M	:	if(fLastCntL)							n_state = DONE;
					else 									n_state = INIT_M;
		DONE	:											n_state = IDLE;
	endcase
end

endmodule

// -255 ~ 255 => -7 ~ + 7
module	LZDL_E(
	input	wire	[7:0]	i_RN,
	output	reg		[2:0]	o_E
);

always@*
	case(i_RN)
		8'h00	:	o_E = 3'h0;		8'h01	:	o_E = 3'h0;		8'h02	:	o_E = 3'h0;		8'h03	:	o_E = 3'h0;
		8'h04	:	o_E = 3'h0;		8'h05	:	o_E = 3'h0;		8'h06	:	o_E = 3'h0;		8'h07	:	o_E = 3'h0;
		8'h08	:	o_E = 3'h0;		8'h09	:	o_E = 3'h0;		8'h0a	:	o_E = 3'h0;		8'h0b	:	o_E = 3'h0;
		8'h0c	:	o_E = 3'h0;		8'h0d	:	o_E = 3'h0;		8'h0e	:	o_E = 3'h0;		8'h0f	:	o_E = 3'h0;
		8'h10	:	o_E = 3'h0;		8'h11	:	o_E = 3'h0;		8'h12	:	o_E = 3'h0;		8'h13	:	o_E = 3'h0;
		8'h14	:	o_E = 3'h0;		8'h15	:	o_E = 3'h0;		8'h16	:	o_E = 3'h0;		8'h17	:	o_E = 3'h0;
		8'h18	:	o_E = 3'h0;		8'h19	:	o_E = 3'h0;		8'h1a	:	o_E = 3'h0;		8'h1b	:	o_E = 3'h0;
		8'h1c	:	o_E = 3'h0;		8'h1d	:	o_E = 3'h0;		8'h1e	:	o_E = 3'h0;		8'h1f	:	o_E = 3'h0;
		8'h20	:	o_E = 3'h0;		8'h21	:	o_E = 3'h0;		8'h22	:	o_E = 3'h0;		8'h23	:	o_E = 3'h0;
		8'h24	:	o_E = 3'h0;		8'h25	:	o_E = 3'h0;		8'h26	:	o_E = 3'h0;		8'h27	:	o_E = 3'h0;
		8'h28	:	o_E = 3'h0;		8'h29	:	o_E = 3'h0;		8'h2a	:	o_E = 3'h0;		8'h2b	:	o_E = 3'h1;
		8'h2c	:	o_E = 3'h1;		8'h2d	:	o_E = 3'h1;		8'h2e	:	o_E = 3'h1;		8'h2f	:	o_E = 3'h1;
		8'h30	:	o_E = 3'h1;		8'h31	:	o_E = 3'h1;		8'h32	:	o_E = 3'h1;		8'h33	:	o_E = 3'h1;
		8'h34	:	o_E = 3'h1;		8'h35	:	o_E = 3'h1;		8'h36	:	o_E = 3'h1;		8'h37	:	o_E = 3'h1;
		8'h38	:	o_E = 3'h1;		8'h39	:	o_E = 3'h1;		8'h3a	:	o_E = 3'h1;		8'h3b	:	o_E = 3'h1;
		8'h3c	:	o_E = 3'h1;		8'h3d	:	o_E = 3'h1;		8'h3e	:	o_E = 3'h1;		8'h3f	:	o_E = 3'h1;
		8'h40	:	o_E = 3'h1;		8'h41	:	o_E = 3'h1;		8'h42	:	o_E = 3'h1;		8'h43	:	o_E = 3'h1;
		8'h44	:	o_E = 3'h1;		8'h45	:	o_E = 3'h1;		8'h46	:	o_E = 3'h1;		8'h47	:	o_E = 3'h1;
		8'h48	:	o_E = 3'h1;		8'h49	:	o_E = 3'h1;		8'h4a	:	o_E = 3'h1;		8'h4b	:	o_E = 3'h1;
		8'h4c	:	o_E = 3'h1;		8'h4d	:	o_E = 3'h1;		8'h4e	:	o_E = 3'h1;		8'h4f	:	o_E = 3'h1;
		8'h50	:	o_E = 3'h1;		8'h51	:	o_E = 3'h1;		8'h52	:	o_E = 3'h1;		8'h53	:	o_E = 3'h1;
		8'h54	:	o_E = 3'h1;		8'h55	:	o_E = 3'h1;		8'h56	:	o_E = 3'h1;		8'h57	:	o_E = 3'h1;
		8'h58	:	o_E = 3'h1;		8'h59	:	o_E = 3'h1;		8'h5a	:	o_E = 3'h1;		8'h5b	:	o_E = 3'h1;
		8'h5c	:	o_E = 3'h1;		8'h5d	:	o_E = 3'h1;		8'h5e	:	o_E = 3'h1;		8'h5f	:	o_E = 3'h1;
		8'h60	:	o_E = 3'h1;		8'h61	:	o_E = 3'h1;		8'h62	:	o_E = 3'h1;		8'h63	:	o_E = 3'h1;
		8'h64	:	o_E = 3'h1;		8'h65	:	o_E = 3'h1;		8'h66	:	o_E = 3'h1;		8'h67	:	o_E = 3'h1;
		8'h68	:	o_E = 3'h1;		8'h69	:	o_E = 3'h1;		8'h6a	:	o_E = 3'h1;		8'h6b	:	o_E = 3'h1;
		8'h6c	:	o_E = 3'h1;		8'h6d	:	o_E = 3'h1;		8'h6e	:	o_E = 3'h1;		8'h6f	:	o_E = 3'h1;
		8'h70	:	o_E = 3'h1;		8'h71	:	o_E = 3'h1;		8'h72	:	o_E = 3'h1;		8'h73	:	o_E = 3'h1;
		8'h74	:	o_E = 3'h1;		8'h75	:	o_E = 3'h1;		8'h76	:	o_E = 3'h1;		8'h77	:	o_E = 3'h1;
		8'h78	:	o_E = 3'h1;		8'h79	:	o_E = 3'h2;		8'h7a	:	o_E = 3'h2;		8'h7b	:	o_E = 3'h2;
		8'h7c	:	o_E = 3'h2;		8'h7d	:	o_E = 3'h2;		8'h7e	:	o_E = 3'h2;		8'h7f	:	o_E = 3'h2;
		8'h80	:	o_E = 3'h2;		8'h81	:	o_E = 3'h2;		8'h82	:	o_E = 3'h2;		8'h83	:	o_E = 3'h2;
		8'h84	:	o_E = 3'h2;		8'h85	:	o_E = 3'h2;		8'h86	:	o_E = 3'h2;		8'h87	:	o_E = 3'h2;
		8'h88	:	o_E = 3'h2;		8'h89	:	o_E = 3'h2;		8'h8a	:	o_E = 3'h2;		8'h8b	:	o_E = 3'h2;
		8'h8c	:	o_E = 3'h2;		8'h8d	:	o_E = 3'h2;		8'h8e	:	o_E = 3'h2;		8'h8f	:	o_E = 3'h2;
		8'h90	:	o_E = 3'h2;		8'h91	:	o_E = 3'h2;		8'h92	:	o_E = 3'h2;		8'h93	:	o_E = 3'h2;
		8'h94	:	o_E = 3'h2;		8'h95	:	o_E = 3'h2;		8'h96	:	o_E = 3'h2;		8'h97	:	o_E = 3'h2;
		8'h98	:	o_E = 3'h2;		8'h99	:	o_E = 3'h2;		8'h9a	:	o_E = 3'h2;		8'h9b	:	o_E = 3'h2;
		8'h9c	:	o_E = 3'h2;		8'h9d	:	o_E = 3'h2;		8'h9e	:	o_E = 3'h2;		8'h9f	:	o_E = 3'h2;
		8'ha0	:	o_E = 3'h2;		8'ha1	:	o_E = 3'h2;		8'ha2	:	o_E = 3'h2;		8'ha3	:	o_E = 3'h2;
		8'ha4	:	o_E = 3'h2;		8'ha5	:	o_E = 3'h2;		8'ha6	:	o_E = 3'h2;		8'ha7	:	o_E = 3'h2;
		8'ha8	:	o_E = 3'h2;		8'ha9	:	o_E = 3'h2;		8'haa	:	o_E = 3'h2;		8'hab	:	o_E = 3'h2;
		8'hac	:	o_E = 3'h2;		8'had	:	o_E = 3'h2;		8'hae	:	o_E = 3'h2;		8'haf	:	o_E = 3'h2;
		8'hb0	:	o_E = 3'h2;		8'hb1	:	o_E = 3'h2;		8'hb2	:	o_E = 3'h2;		8'hb3	:	o_E = 3'h2;
		8'hb4	:	o_E = 3'h2;		8'hb5	:	o_E = 3'h3;		8'hb6	:	o_E = 3'h3;		8'hb7	:	o_E = 3'h3;
		8'hb8	:	o_E = 3'h3;		8'hb9	:	o_E = 3'h3;		8'hba	:	o_E = 3'h3;		8'hbb	:	o_E = 3'h3;
		8'hbc	:	o_E = 3'h3;		8'hbd	:	o_E = 3'h3;		8'hbe	:	o_E = 3'h3;		8'hbf	:	o_E = 3'h3;
		8'hc0	:	o_E = 3'h3;		8'hc1	:	o_E = 3'h3;		8'hc2	:	o_E = 3'h3;		8'hc3	:	o_E = 3'h3;
		8'hc4	:	o_E = 3'h3;		8'hc5	:	o_E = 3'h3;		8'hc6	:	o_E = 3'h3;		8'hc7	:	o_E = 3'h3;
		8'hc8	:	o_E = 3'h3;		8'hc9	:	o_E = 3'h3;		8'hca	:	o_E = 3'h3;		8'hcb	:	o_E = 3'h3;
		8'hcc	:	o_E = 3'h3;		8'hcd	:	o_E = 3'h3;		8'hce	:	o_E = 3'h3;		8'hcf	:	o_E = 3'h3;
		8'hd0	:	o_E = 3'h3;		8'hd1	:	o_E = 3'h3;		8'hd2	:	o_E = 3'h3;		8'hd3	:	o_E = 3'h3;
		8'hd4	:	o_E = 3'h3;		8'hd5	:	o_E = 3'h3;		8'hd6	:	o_E = 3'h3;		8'hd7	:	o_E = 3'h3;
		8'hd8	:	o_E = 3'h3;		8'hd9	:	o_E = 3'h3;		8'hda	:	o_E = 3'h3;		8'hdb	:	o_E = 3'h3;
		8'hdc	:	o_E = 3'h4;		8'hdd	:	o_E = 3'h4;		8'hde	:	o_E = 3'h4;		8'hdf	:	o_E = 3'h4;
		8'he0	:	o_E = 3'h4;		8'he1	:	o_E = 3'h4;		8'he2	:	o_E = 3'h4;		8'he3	:	o_E = 3'h4;
		8'he4	:	o_E = 3'h4;		8'he5	:	o_E = 3'h4;		8'he6	:	o_E = 3'h4;		8'he7	:	o_E = 3'h4;
		8'he8	:	o_E = 3'h4;		8'he9	:	o_E = 3'h4;		8'hea	:	o_E = 3'h4;		8'heb	:	o_E = 3'h4;
		8'hec	:	o_E = 3'h4;		8'hed	:	o_E = 3'h4;		8'hee	:	o_E = 3'h4;		8'hef	:	o_E = 3'h4;
		8'hf0	:	o_E = 3'h4;		8'hf1	:	o_E = 3'h5;		8'hf2	:	o_E = 3'h5;		8'hf3	:	o_E = 3'h5;
		8'hf4	:	o_E = 3'h5;		8'hf5	:	o_E = 3'h5;		8'hf6	:	o_E = 3'h5;		8'hf7	:	o_E = 3'h5;
		8'hf8	:	o_E = 3'h5;		8'hf9	:	o_E = 3'h5;		8'hfa	:	o_E = 3'h5;		8'hfb	:	o_E = 3'h6;
		8'hfc	:	o_E = 3'h6;		8'hfd	:	o_E = 3'h6;		8'hfe	:	o_E = 3'h6;		8'hff	:	o_E = 3'h7;
	endcase
endmodule
