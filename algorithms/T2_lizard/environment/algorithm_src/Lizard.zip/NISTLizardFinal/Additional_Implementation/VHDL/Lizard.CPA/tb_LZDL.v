`timescale 1 ns / 1 ns
module	tb_LZDL;
//*
parameter	n = 608,	log2n = 10;
parameter	m = 960,	log2m = 10;
parameter	l = 256,	log2l = 8;
/*/
parameter	n = 60,		log2n = 6;
parameter	m = 96,		log2m = 7;
parameter	l = 64,		log2l = 6;
//*/
parameter	aw = log2n+log2l-4;
parameter	SIZE_M = l     ,
			SIZE_S = n*l* 2,
			SIZE_A = m*n*16,
			SIZE_B = m*l*16,
			SIZE_R = m  * 2,
			SIZE_C1= n  * 8,
			SIZE_C2= l  * 8;
reg		clk;
reg		rst;

reg		[1:0]		LZD_i_Mode;
reg					LZD_i_Start;
reg					LZD_i_fWr;
reg					LZD_i_fRd;
reg		[2:0]		LZD_i_Reg;
reg		[aw-1:0]	LZD_i_Addr;
reg		[31:0]		LZD_i_Data;
wire	[31:0]		LZD_o_Data;
wire				LZD_o_fRdRdy;
wire				LZD_o_fWrRdy;

reg		[SIZE_A -1:0]	r_A;	
reg		[SIZE_R -1:0]	r_R;	
reg		[SIZE_B -1:0]	r_B, r_E;	
reg		[SIZE_S -1:0]	r_S;	
reg		[SIZE_M -1:0]	r_M, r_Mi;	
reg		[SIZE_C1-1:0]	r_C1;
reg		[SIZE_C2-1:0]	r_C2;
reg		[79:0]			r_str;

wire	[255:0]	A256;
wire	[255:0]	B256;
wire	[255:0]	S256;
wire	[255:0]	E256;
wire	[255:0]	R256;

assign	S256 = r_S[SIZE_S-1-:256];
assign	A256 = r_A[SIZE_A-1-:256];
assign	B256 = r_B[SIZE_B-1-:256];
assign	E256 = r_E[SIZE_B-1-:256];
assign	R256 = r_R[SIZE_R-1-:256];

integer	i, k, j, p, fp, r;

parameter	REG_C1	= 3'h0,
			REG_C2	= 3'h1,
			REG_S	= 3'h2,
			REG_M	= 3'h3,
			REG_A	= 3'h4,
			REG_E	= 3'h5,
			REG_R	= 3'h6,
			REG_B	= 3'h7;
parameter	ENC		= 2'h1,
			DEC		= 2'h2,
			KEY_GEN = 2'h3;
parameter	REPEAT	= 100000;		
parameter	M = 1024'h5e2abb3cd8d001430daf52ef3e090caa283d131a6200552147017b363252577a37c91176e0a914c4c150a25ea08649816128d5567288429cd1c5aed8e9c3344495e9e6022ce9a3be61b81bc6c3b9f7c9d762cf9691bbb018dca9d86d996afabcf769c0cd080033aac04bc94f5bde8e0d81cec81de66d930ae392f333613db379;
parameter	M1 = 1024'h000102030405060708090A0B0C0D0E0F000102030405060708090A0B0C0D0E0F000102030405060708090A0B0C0D0E0F000102030405060708090A0B0C0D0E0F000102030405060708090A0B0C0D0E0F000102030405060708090A0B0C0D0E0F000102030405060708090A0B0C0D0E0F000102030405060708090A0B0C0D0E0F;
parameter	S = 2064'h02C7002401CF020E03E901D802ED023D028F00A4009002F5013103AC03ED002C0067015503A20258017001CA022D00F800AC017B0072010C002203990039039801FB009B02AE0024030500BB02DF033F0132027A004100F702160118012C0363016C031D015A011A039100D3006D03B9000702C90066026103F30052002E003600A00204021002E101FA0039023D010F01140191014700F002A3016E02A702B90180027703380322012A011603B901E8004101FA034E004C030C009501FF039301F4019F0338038400070191004700ED0177032B02E2001E021801EF039E036C03E500A3007901B0017B03D3035100C6009C004D006A000E00AE01A300ED02EE003a;

always
	#5 clk = ~clk;


LZDL	LZD(clk, rst,
	LZD_i_Start, LZD_i_Mode, LZD_i_Reg,	LZD_i_Addr, LZD_o_fDone, LZD_o_fBusy,
	LZD_i_fWr,	LZD_i_Data,	LZD_o_fWrRdy,
	LZD_i_fRd,	LZD_o_Data,	LZD_o_fRdRdy
);

initial
begin
	clk = 0;
	rst	= 0;
	r_str	= "";
	LZD_i_Start	= 0;
	LZD_i_Mode	= 0;
	LZD_i_fWr	= 0;
	LZD_i_fRd	= 0;
	LZD_i_Reg	= 0;
	LZD_i_Addr	= 0;
	LZD_i_Data	= 0;
	r_A = 0;
	r_B = 0;

	@(negedge clk)	rst = 1;
/*
	r_S = S;	r_C1 = C1;	r_C2 = C2;
	Dec();
	if(M1 != r_M) begin
		$display("Diff %x", M - r_M);
		$stop;
	end
	*/
	$monitor("%s", r_str);
	for(p = 0 ; p < REPEAT ; p = p + 1)	begin
		KeyGen();
//		LoadData();
		Enc();
		Dec();
		SaveData();
	end
	$display("No Error!!!");
	$stop;
end

task KeyGen;
begin
	r_str[79:40] = "KG  -";
	WrRN	(REG_S);		// RN	-> S, r_S
//	$display("S  : %x", r_S);
	Start	(KEY_GEN);
	for(k = 0 ; k < m ; k = k + 1)	begin
		WrRN	(REG_A);	// RN	-> A, r_A
		WrRN	(REG_E);	// RN	-> E, r_E
		RdWords	(REG_B);	// B	-> r_B
	end
//	$display("A  : %x", r_A);
//	$display("B  : %x", r_B);
end
endtask

task Enc;
begin
	r_str[79:40] = "ENC";

	WrRN	(REG_R);	// RN	-> R
	WrRN	(REG_M);	// RN	-> M, r_Mi
	$display("M : %x", r_Mi);	

	Start	(ENC);
	WrWords	(REG_A);	// r_A	-> A
	WrWords	(REG_B);	// r_B	-> B

	RdWords	(REG_C1);//	$display("C1 : %x", r_C1);//	C1	-> r_C1
	RdWords	(REG_C2);//	$display("C2 : %x", r_C2);//	C2	-> r_C2
end
endtask

task Dec;
reg	[n*8-1:0]	r_TmpC2;
begin
	r_TmpC2 = r_C2;
	r_str[79:40] = "DEC -";
	WrWords	(REG_S);	// r_S	-> S
	WrWords	(REG_C1);	// r_C1	-> C1
	WrWords	(REG_C2);	// r_C2	-> C2
	
	Start	(DEC);	@(negedge LZD_o_fDone);

	RdWords	(REG_M);	// M	-> r_M
//	$display("M : %x", r_Mi);
//	$display("M': %x", r_M);
	
	if(r_Mi != r_M) begin
		$display("Ex    : %x", r_Mi);
		$display("Rx    : %x", r_M);
		$display("Diff  : %x", r_Mi ^ r_M);
		SaveData();
		$stop;
	end
end
endtask

task	LoadData;
reg	[31:0]	r_read;
begin
	fp = $fopen("key.txt", "r");
	//*
	for(i = 0 ; i < SIZE_S /32 ; i = i + 1)	begin	r = $fscanf(fp, "%8x", r_read);	r_S  = {r_S , r_read};	end
	for(i = 0 ; i < SIZE_A /32 ; i = i + 1)	begin	r = $fscanf(fp, "%8x", r_read);	r_A  = {r_A , r_read};	end
	for(i = 0 ; i < SIZE_B /32 ; i = i + 1)	begin	r = $fscanf(fp, "%8x", r_read);	r_B  = {r_B , r_read};	end
	for(i = 0 ; i < SIZE_B /32 ; i = i + 1)	begin	r = $fscanf(fp, "%8x", r_read);	r_E  = {r_E , r_read};	end
	for(i = 0 ; i < SIZE_R /32 ; i = i + 1)	begin	r = $fscanf(fp, "%8x", r_read);	r_R  = {r_R , r_read};	end
//	for(i = 0 ; i < SIZE_C1/32 ; i = i + 1)	begin	r = $fscanf(fp, "%8x", r_read);	r_C1 = {r_C1, r_read};	end
//	for(i = 0 ; i < SIZE_C2/32 ; i = i + 1)	begin	r = $fscanf(fp, "%8x", r_read);	r_C2 = {r_C2, r_read};	end
//	for(i = 0 ; i < SIZE_M /32 ; i = i + 1)	begin	r = $fscanf(fp, "%8x", r_read);	r_Mi = {r_Mi, r_read};	end
//	for(i = 0 ; i < SIZE_M /32 ; i = i + 1)	begin	r = $fscanf(fp, "%8x", r_read);	r_M  = {r_M , r_read};	end
	//*/
	/*
	r = $fscanf(fp, "%5248x", r_S   );
    r = $fscanf(fp, "%2334720x", r_A   );
    r = $fscanf(fp, "%983040x", r_B   );
    r = $fscanf(fp, "%983040x", r_E   );
    r = $fscanf(fp, "%480x", r_R   );
    r = $fscanf(fp, "%1216x", r_C1  );
    r = $fscanf(fp, "%512x", r_C2  );
    r = $fscanf(fp, "%64x", r_M   );
    r = $fscanf(fp, "%64x", r_M   );
	*/
	$fclose(fp);
end
endtask

task	SaveData;
begin
	fp = $fopen("key.txt", "w");
	$fdisplay(fp, "%x", r_S);
	$fdisplay(fp, "%x", r_A);
    $fdisplay(fp, "%x", r_B);
    $fdisplay(fp, "%x", r_E);
    $fdisplay(fp, "%x", r_R);
	$fdisplay(fp, "%x", r_C1);
    $fdisplay(fp, "%x", r_C2);
	$fdisplay(fp, "%x", r_Mi);
	$fdisplay(fp, "%x", r_M);
	$fclose(fp);
end
endtask

task	Start;
input	[1:0]	i_Mode;
begin	
	LZD_i_Mode = i_Mode;
	@(negedge clk)	LZD_i_Start = 1;
	@(negedge clk)	LZD_i_Start = 0;
end
endtask

task	WrWord;
input	[2:0]	i_Reg;
input	[31:0]	i_Addr;
input	[31:0]	i_Data;
begin
	r_str[39:0] = "Write";
	LZD_i_Reg = i_Reg;
	LZD_i_Addr = i_Addr;
	LZD_i_Data= i_Data;
	if(LZD_o_fWrRdy)	#1;
	else	begin
		LZD_i_fWr = 0;
		wait(LZD_o_fWrRdy);
		@(negedge clk);
	end
	LZD_i_fWr = 1;
	@(negedge clk)	LZD_i_fWr = 0;
end
endtask

task	WrRN;
input	[2:0]	i_Reg;
reg		[31:0]	r_len;
reg		[31:0]	r_RN;
begin
	r_str[39:0] = "Write";
	case(i_Reg)	// counting words
		REG_S	:	r_len = SIZE_S/32;
		REG_R	:	r_len = m* 2  /32;
		REG_A	:	r_len = n*16  /32;
		REG_M	:	r_len = l     /32;	
		REG_E	:	r_len = l     /2;	
	endcase
	LZD_i_Reg	= i_Reg;
	for(i = 0 ; i < r_len ; i = i + 1) begin
		r_RN = $random;
		if(		i_Reg == REG_A)	r_RN = r_RN & 32'h03FF03FF;
		else if(i_Reg == REG_E)	r_RN = r_RN & 32'h01FF01FF;

		WrWord(i_Reg, i, r_RN);
		case(i_Reg)
			REG_A	: begin r_A = {r_A, r_RN};	end
			REG_S	: begin r_S = {r_S, r_RN};	end
			REG_R	: begin r_R = {r_R, r_RN};	end
			REG_M	: begin r_Mi= {r_Mi,r_RN};	end
			REG_E	: begin r_E = {r_E, r_RN};	end
		endcase
	end
end
endtask

task	WrWords;
input	[2:0]		i_Reg;
reg		[31:0]		r_Len;
begin
	case(i_Reg)
		REG_S	: r_Len = SIZE_S /32;
		REG_A	: r_Len = SIZE_A /32;
		REG_B	: r_Len = SIZE_B /32;
		REG_C1	: r_Len = SIZE_C1/32;
		REG_C2	: r_Len = SIZE_C2/32;
	endcase

	r_str[39:0] = "Write";
	LZD_i_Reg = i_Reg;
	if(i_Reg == REG_A)	begin
		for(k = 0 ; k < n ; k = k + 1) begin
			for(j = 0 ; j < m ; j = j + 1) begin
				WrWord(REG_A, 0, r_A[SIZE_A-1-:16]);
				r_A	= {r_A[0+:SIZE_A-n*16], r_A[SIZE_A-1-:n*16]};
			end
			r_A	= {r_A[0+:SIZE_A-16], r_A[SIZE_A-1-:16]};
		end
		r_A = {r_A[0+:n*16], r_A[n*16+:SIZE_A-n*16]};
	end else if(i_Reg == REG_B)	begin
		for(k = 0 ; k < l ; k = k + 1) begin
			for(j = 0 ; j < m ; j = j + 1) begin
				WrWord(REG_B, 0, r_B[SIZE_B-1-:16]);
				r_B	= {r_B[0+:SIZE_B-l*16], r_B[SIZE_B-1-:l*16]};
			end
			r_B	= {r_B[0+:SIZE_B-16], r_B[SIZE_B-1-:16]};
		end
		r_B = {r_B[0+:l*16], r_B[l*16+:SIZE_B-l*16]};
	end else for(i = 0 ; i < r_Len ; i = i + 1) begin
		LZD_i_Addr = i;
		case(i_Reg)
			REG_S	: begin WrWord(i_Reg, i, r_S [SIZE_S -1-:32]);	r_S  = {r_S [0+:SIZE_S -32], r_S [SIZE_S -1-:32]};	end
			REG_C1	: begin WrWord(i_Reg, i, r_C1[SIZE_C1-1-:32]);	r_C1 = {r_C1[0+:SIZE_C1-32], r_C1[SIZE_C1-1-:32]};	end
			REG_C2	: begin WrWord(i_Reg, i, r_C2[SIZE_C2-1-:32]);	r_C2 = {r_C2[0+:SIZE_C2-32], r_C2[SIZE_C2-1-:32]};	end
		endcase
	end
end
endtask

task	RdWords;
input	[2:0]	i_Reg;
reg		[31:0]	r_Len;
begin
	case(i_Reg)
		REG_M	: r_Len = SIZE_M /32;
		REG_S	: r_Len = SIZE_S /32;
		REG_A	: r_Len = n/2;
		REG_B	: r_Len = l/2;
		REG_C1	: r_Len = SIZE_C1/32;
		REG_C2	: r_Len = SIZE_C2/32;
	endcase

	r_str[39:0] = "Read ";
	LZD_i_Reg= i_Reg;
	for(i = 0 ; i < r_Len ; i = i + 1) begin
		LZD_i_Addr = i;	
		if(i_Reg == REG_S || i_Reg == REG_A || i_Reg == REG_B)
		if(!LZD_o_fRdRdy)	begin
			LZD_i_fRd = 0;
			wait(LZD_o_fRdRdy);
			@(negedge clk);
		end
		LZD_i_fRd = 1;
		#1
		case(i_Reg)
			REG_M	: r_M = {r_M , LZD_o_Data};
			REG_S	: r_S = {r_S , LZD_o_Data};
			REG_A	: r_A = {r_A , LZD_o_Data};
			REG_B	: r_B = {r_B , LZD_o_Data};
			REG_C1	: r_C1= {r_C1, LZD_o_Data};
			REG_C2	: r_C2= {r_C2, LZD_o_Data};
		endcase
		@(negedge clk)	LZD_i_fRd = 0;
	end
end
endtask

endmodule
