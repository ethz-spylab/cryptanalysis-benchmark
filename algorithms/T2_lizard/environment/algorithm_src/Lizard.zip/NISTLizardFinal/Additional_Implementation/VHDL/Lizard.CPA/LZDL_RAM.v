module	LZDL_RAM(i_clk, i_reset, i_fE,
	i_fWr0,	i_fRd0,	i_Addr0,	i_Data0, o_Data0,
	i_fWr1,	i_fRd1,	i_Addr1,	i_Data1, o_Data1
);
parameter	mw = 14;

input	wire			i_clk, i_reset;
input	wire			i_fE;
input	wire			i_fWr0,	i_fWr1;
input	wire			i_fRd0,	i_fRd1;
input	wire	[mw-1:0]i_Addr0,i_Addr1;
input	wire	[31:0]	i_Data0,i_Data1;
output	wire	[31:0]	o_Data0,o_Data1;

wire	[31:0]	Mem0_o_Data0,	Mem0_o_Data1;
wire	[31:0]	Mem1_o_Data0,	Mem1_o_Data1;
wire	[31:0]	Mem2_o_Data0,	Mem2_o_Data1;

wire			Mem0_i_fCEN0,	Mem1_i_fCEN0,	Mem2_i_fCEN0	;
wire			Mem0_i_fCEN1,	Mem1_i_fCEN1,	Mem2_i_fCEN1	;
wire			Mem0_i_fWEN0,	Mem1_i_fWEN0,	Mem2_i_fWEN0	;
wire			Mem0_i_fWEN1,	Mem1_i_fWEN1,	Mem2_i_fWEN1	;

reg				r_fE;
reg		[31:0]	r_E;
reg		[10:0]	r_AddrE;
wire	[10:0]	Mem2_i_Addr1;
wire	[31:0]	Mem2_i_Data1;

assign	fWrE	= i_fWr0 && i_fE && i_Addr0[mw-1];
always@(posedge i_clk, negedge i_reset)
	if(!i_reset)begin
		r_fE	<= 0;
		r_AddrE	<= 0;
		r_E		<= 0;
	end else begin
		r_fE	<= fWrE;
		if(fWrE)begin
			r_AddrE	<= i_Addr0;
			r_E		<= {
				Mem2_o_Data0[31:30], i_Data0[29:26], Mem2_o_Data0[25:16],
				Mem2_o_Data0[15:14], i_Data0[13:10], Mem2_o_Data0[ 9: 0]};
		end
	end
assign	Mem2_i_Addr1	= r_fE ? r_AddrE : i_Addr1;
assign	Mem2_i_Data1	= r_fE ? r_E     : i_Data1;

assign	o_Data0	= i_Addr0[mw-1] ? Mem2_o_Data0 : i_Addr0[mw-2] ? Mem1_o_Data0 : Mem0_o_Data0;
assign	o_Data1	= i_Addr1[mw-1] ? Mem2_o_Data1 : i_Addr1[mw-2] ? Mem1_o_Data1 : Mem0_o_Data1;

assign	Mem_i_clk	= ~i_clk;
assign	Mem0_i_fCEN0	= !((i_fWr0 || i_fRd0) && !i_Addr0[mw-1] && !i_Addr0[mw-2]),	
		Mem0_i_fCEN1	= !((i_fWr1 || i_fRd1) && !i_Addr1[mw-1] && !i_Addr1[mw-2]),	
		Mem1_i_fCEN0	= !((i_fWr0 || i_fRd0) && !i_Addr0[mw-1] &&  i_Addr0[mw-2]),	
		Mem1_i_fCEN1	= !((i_fWr1 || i_fRd1) && !i_Addr1[mw-1] &&  i_Addr1[mw-2]),	
		Mem2_i_fCEN0	= !((i_fWr0 || i_fRd0) &&  i_Addr0[mw-1]),						
		Mem2_i_fCEN1	=!(((i_fWr1 || i_fRd1) &&  i_Addr1[mw-1]) || r_fE),
		Mem0_i_fWEN0	= !(i_fWr0 && !i_Addr0[mw-1] && !i_Addr0[mw-2]),
        Mem0_i_fWEN1	= !(i_fWr1 && !i_Addr1[mw-1] && !i_Addr1[mw-2]),
        Mem1_i_fWEN0	= !(i_fWr0 && !i_Addr0[mw-1] &&  i_Addr0[mw-2]),
        Mem1_i_fWEN1	= !(i_fWr1 && !i_Addr1[mw-1] &&  i_Addr1[mw-2]),
        Mem2_i_fWEN0	= !(i_fWr0 &&  i_Addr0[mw-1] && !i_fE) ,
        Mem2_i_fWEN1	=!((i_fWr1 &&  i_Addr1[mw-1]) || r_fE);

DPRAM_4096X32M8 RAM0 (
    .CLKA        (Mem_i_clk			),
    .CENA        (Mem0_i_fCEN0		),
    .WENA        (Mem0_i_fWEN0		),
    .AA          (i_Addr0[11:0]		),
    .DA          (i_Data0			),
    .QA          (Mem0_o_Data0		),

    .CLKB        (Mem_i_clk			),
    .CENB        (Mem0_i_fCEN1		),
    .WENB        (Mem0_i_fWEN1		),
    .AB          (i_Addr1[11:0]		),
    .DB          (i_Data1			),
    .QB          (Mem0_o_Data1		)
);

DPRAM_4096X32M8 RAM1 (
    .CLKA        (Mem_i_clk			),
    .CENA        (Mem1_i_fCEN0		),
    .WENA        (Mem1_i_fWEN0		),
    .AA          (i_Addr0[11:0]		),
    .DA          (i_Data0			),
    .QA          (Mem1_o_Data0		),

    .CLKB        (Mem_i_clk			),
    .CENB        (Mem1_i_fCEN1		),
    .WENB        (Mem1_i_fWEN1		),
    .AB          (i_Addr1[11:0]		),
    .DB          (i_Data1			),
    .QB          (Mem1_o_Data1		)
);

DPRAM_2048X32M8 RAM2 (
    .CLKA        (Mem_i_clk			),
    .CENA        (Mem2_i_fCEN0		),
    .WENA        (Mem2_i_fWEN0		),
    .AA          (i_Addr0[10:0]		),
    .DA          (i_Data0			),
    .QA          (Mem2_o_Data0		),

    .CLKB        (Mem_i_clk			),
    .CENB        (Mem2_i_fCEN1		),
    .WENB        (Mem2_i_fWEN1		),
    .AB          (Mem2_i_Addr1		),
    .DB          (Mem2_i_Data1		),
    .QB          (Mem2_o_Data1		)
);
endmodule
