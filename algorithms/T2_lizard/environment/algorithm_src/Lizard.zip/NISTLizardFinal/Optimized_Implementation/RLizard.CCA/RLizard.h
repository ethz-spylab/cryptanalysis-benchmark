#ifndef LIZARD_H
#define LIZARD_H

#include <stdint.h>
#include "params.h"
#include "api.h"

#define iter 10000		// iteration number for keygen & EncDec test
#define testnum 10	// repeatetion number of Enc Dec procedure in a single iteration

#define sft (sizeof(size_t) * 4 - 1)

typedef unsigned char SecretKey[CRYPTO_SECRETKEYBYTES];
typedef unsigned char PublicKey[CRYPTO_PUBLICKEYBYTES];

clock_t start, finish, elapsed1, elapsed2;

int crypto_encrypt_keypair(unsigned char *pk, unsigned char *sk);
int crypto_encrypt(unsigned char *c, unsigned long long *clen, const unsigned char *m, unsigned long long mlen, const unsigned char *pk);
int crypto_encrypt_open(unsigned char *m, unsigned long long *mlen, const unsigned char *c, unsigned long long clen, const unsigned char *sk);

#endif