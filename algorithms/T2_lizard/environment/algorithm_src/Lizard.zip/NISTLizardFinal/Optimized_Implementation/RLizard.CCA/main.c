#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

#include "RLizard.h"

PublicKey pk;
SecretKey sk;
unsigned char sk_t[CRYPTO_SECRETKEYBYTES + CRYPTO_PUBLICKEYBYTES];

void Keygen_ring() {
	elapsed1 = clock();
	for (int l = 0; l < iter; ++l) {
		crypto_encrypt_keypair(pk, sk);
	}
	elapsed1 = clock() - elapsed1;

	printf("    Keygen Time: %f ms\n", elapsed1 * 1000. / CLOCKS_PER_SEC / iter);
}

void EncDecTest_RING() {
	// Set a messages
#ifdef RING_CATEGORY1
	unsigned char m1[32] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
		0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F };
	unsigned char m2[32] = { 0, };
#endif
#if defined(RING_CATEGORY3_N1024) || defined(RING_CATEGORY3_N2048)
	unsigned char m1[48] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
		0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
		0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F };
	unsigned char m2[48] = { 0, };
#endif
#ifdef RING_CATEGORY5
	unsigned char m1[64] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
		0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
		0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
		0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F };
	unsigned char m2[64] = { 0, };
#endif
	unsigned long long mlen1 = sizeof(m1), clen, mlen2;
	unsigned char *c = (unsigned char*)calloc(CRYPTO_BYTES, sizeof(unsigned char));
	int i, res = 0;

	elapsed1 = 0;
	elapsed2 = 0;
	
	memcpy(sk_t, sk, sizeof(unsigned char) * CRYPTO_SECRETKEYBYTES);
	memcpy(sk_t + CRYPTO_SECRETKEYBYTES, pk, sizeof(unsigned char) * CRYPTO_PUBLICKEYBYTES);

	for (int l = 0; l < iter; ++l) {
		for (i = 0; i < testnum; i++) {
			crypto_encrypt(c, &clen, m1, mlen1, pk);
			res = crypto_encrypt_open(m2, &mlen2, c, clen, sk_t);
		}

		if (res == 1) {
			printf("    Decryption Validity Error Type 1 : c3 components\n");
			break;
		}

		if (res == 2) {
			printf("    Decryption Validity Error Type 2 : c2 components\n");
			break;
		}

		// Correctness check
		for (i = 0; i < mlen1; ++i) {
			if (m1[i] != m2[i]) {
				printf("Correctness Error, %d\n", i);
				break;
			}
		}
		if (i < mlen1) break;
	}
	printf("    Enc Time: %f ms\n", elapsed1 * 1000. / CLOCKS_PER_SEC / testnum / iter);
	printf("    Dec Time: %f ms\n", elapsed2 * 1000. / CLOCKS_PER_SEC / testnum / iter);
}

void main() {
	printf("\n  //////////////////////////////////////////////////////////////////\n\n");
	printf("\t\t"PARAMNAME" Parameter\n\n");
	printf("    LWE dimension: %d, \t\tLWR dimension: %d\n", LWE_N, LWE_N);
	printf("    Plaintext dimension: %d, \t\tPlaintext Modulus: %d bits\t\n", (LAMBDA * 2), LOG_T);
	printf("    Public Key modulus: %d bits, \tCiphertext modulus: %d bits\t\n\n", LOG_Q, LOG_P);
	printf("  //////////////////////////////////////////////////////////////////\n\n");
	printf("\t\t\tPerformance Test\n\n");

	// Key Generation
	KEYGEN();

	// Enc and Dec
	ENCDECTEST();
}