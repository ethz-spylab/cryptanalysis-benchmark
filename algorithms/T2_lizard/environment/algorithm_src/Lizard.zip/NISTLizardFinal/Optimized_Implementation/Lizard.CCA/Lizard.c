#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Lizard.h"
#include "randombytes.h"
#include "sha512.h"
#include <libkeccak.a.headers/SP800-185.h>

uint16_t seed[LWE_M * LWE_L * 2];
int count = 0;

#ifdef NOISE_D1
#define SAMPLE_DG Sample_D1
const uint16_t CDF_TABLE[9] = { 78, 226, 334, 425, 473, 495, 506, 510, 511 }; // out of [0, 511]
const size_t TABLE_LENGTH = 9;

uint16_t Sample_D1() {
	uint16_t rnd = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x01ff;
	uint16_t sign = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x01;
	uint16_t sample = 0;
	for (size_t i = 0; i < TABLE_LENGTH - 1; ++i) {
		sample += (CDF_TABLE[i] - rnd) >> 15;
	}
	sample = ((-sign) ^ sample) + sign;
	return sample;
}
#endif
#ifdef NOISE_D2
#define SAMPLE_DG Sample_D2
const uint16_t CDF_TABLE[4] = { 458, 946, 1020, 1023 }; // out of [0, 1023]
const size_t TABLE_LENGTH = 4;

uint16_t Sample_D2() {
	uint16_t rnd = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x03ff;
	uint16_t sign = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x01;
	uint16_t sample = 0;
	for (size_t i = 0; i < TABLE_LENGTH - 1; ++i) {
		sample += (CDF_TABLE[i] - rnd) >> 15;
	}
	sample = ((-sign) ^ sample) + sign;
	return sample;
}
#endif
#ifdef NOISE_D3
#define SAMPLE_DG Sample_D3
const uint16_t CDF_TABLE[5] = { 151, 382, 482, 507, 511 }; // out of [0, 511]
const size_t TABLE_LENGTH = 5;

uint16_t Sample_D3() {
	uint16_t rnd = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x01ff;
	uint16_t sign = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x01;
	uint16_t sample = 0;
	for (size_t i = 0; i < TABLE_LENGTH - 1; ++i) {
		sample += (CDF_TABLE[i] - rnd) >> 15;
	}
	sample = ((-sign) ^ sample) + sign;
	return sample;
}
#endif
#ifdef NOISE_D4
#define SAMPLE_DG Sample_D4
const uint16_t CDF_TABLE[6] = { 121, 325, 445, 494, 508, 511 }; // out of [0, 511]
const size_t TABLE_LENGTH = 6;

uint16_t Sample_D4() {
	uint16_t rnd = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x01ff;
	uint16_t sign = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x01;
	uint16_t sample = 0;
	for (size_t i = 0; i < TABLE_LENGTH - 1; ++i) {
		sample += (CDF_TABLE[i] - rnd) >> 15;
	}
	sample = ((-sign) ^ sample) + sign;
	return sample;
}
#endif
#ifdef NOISE_D5
#define SAMPLE_DG Sample_D5
const uint16_t CDF_TABLE[12] = { 262, 761, 1188, 1518, 1748, 1892, 1974, 2016, 2035, 2043, 2046, 2047 }; // out of [0, 2047]
const size_t TABLE_LENGTH = 12;

uint16_t Sample_D5() {
	uint16_t rnd = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x07ff;
	uint16_t sign = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x01;
	uint16_t sample = 0;
	for (size_t i = 0; i < TABLE_LENGTH - 1; ++i) {
		sample += (CDF_TABLE[i] - rnd) >> 15;
	}
	sample = ((-sign) ^ sample) + sign;
	return sample;
}
#endif
#ifdef NOISE_D6
#define SAMPLE_DG Sample_D6
const uint16_t CDF_TABLE[4] = { 380, 874, 1008, 1023 }; // out of [0, 1023]
const size_t TABLE_LENGTH = 4;

uint16_t Sample_D6() {
	uint16_t rnd = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x03ff;
	uint16_t sign = seed[count == LWE_M * LWE_L * 2 ? count = 0 : count++] & 0x01;
	uint16_t sample = 0;
	for (size_t i = 0; i < TABLE_LENGTH - 1; ++i) {
		sample += (CDF_TABLE[i] - rnd) >> 15;
	}
	sample = ((-sign) ^ sample) + sign;
	return sample;
}
#endif

/**
  * @param	pk		[in] public key for encryption. pk = (A, B)
  * @param	sk		[in] private key for decryption
  */
int crypto_encrypt_keypair(unsigned char *pk, unsigned char *sk) {
	int i, j, k;

	uint8_t sk_t[LWE_N * LWE_L];
	uint16_t pk_A[LWE_M * LWE_N];
	uint16_t pk_B[LWE_M * LWE_L];

	// Generate a random matrix A
	randombytes((unsigned char*)pk_A, PublicKey_A);
	for (i = 0; i < LWE_M; ++i) {
		for (j = 0; j < LWE_N; ++j) {
			pk_A[i * LWE_N + j] <<= _16_LOG_Q;
			pk[(i * LWE_N * 2) + (j * 2)] = pk_A[i * LWE_N + j] >> 8;
			pk[(i * LWE_N * 2) + (j * 2 + 1)] = pk_A[i * LWE_N + j] & 0xff;
		}
	}

	// Generate a secret matrix S
	randombytes(sk_t, LWE_L * LWE_N);
	// Secret distribution ZO(1/2)
#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY5_N1088)
	for (i = 0; i < LWE_L * LWE_N; ++i) {
		if ((sk_t[i] & 0x03) == 0x00)
			sk[i] = -1;
		else if ((sk_t[i] & 0x03) == 0x01)
			sk[i] = 1;
		else
			sk[i] = 0;
	}
#endif
	// Secret distribution ZO(1/4)
#if defined(CCA_CATEGORY1_N663) || defined(CCA_CATEGORY3_N952) || defined(CCA_CATEGORY5_N1300)
	for (i = 0; i < LWE_L * LWE_N; ++i) {
		if ((sk_t[i] & 0x07) == 0x00)
			sk[i] = -1;
		else if ((sk_t[i] & 0x07) == 0x01)
			sk[i] = 1;
		else
			sk[i] = 0;
	}
#endif

	// Initialize B as an error matrix E
	randombytes((unsigned char*)seed, LWE_M * LWE_L * 4);
	for (i = 0; i < LWE_M; ++i) {
		for (j = 0; j < LWE_L; ++j) {
			pk_B[i * LWE_L + j] = SAMPLE_DG() << _16_LOG_Q;
		}
	}

	// Add -AS to B. Resulting B = -AS + E
	for (i = 0; i < LWE_M; ++i) {
		uint16_t* A_i = pk_A + LWE_N * i;
		uint16_t* B_i = pk_B + LWE_L * i;
		for (k = 0; k < LWE_N; ++k) {
			uint8_t* sk_k = sk + LWE_L * k;
			uint16_t A_ik = A_i[k];
			for (j = 0; j < LWE_L; j += 2) {
				B_i[j] -= A_ik * (char)sk_k[j];
				B_i[j+1] -= A_ik * (char)sk_k[j+1];
			}
		}
	}

	for (i = 0; i < LWE_M; ++i) {
		for (j = 0; j < LWE_L; ++j) {
			pk[PublicKey_A + (i * LWE_L * 2) + (j * 2)] = pk_B[i * LWE_L + j] >> 8;
			pk[PublicKey_A + (i * LWE_L * 2) + (j * 2 + 1)] = pk_B[i * LWE_L + j] & 0xff;
		}
	}

	return 0;
}

/**
  * @param	c		[out] data to be encrypted. c = (c1, (a, b) c2)
  * @param	clen	[in] data length to be encrypted
  * @param	m		[in] data for encryption
  * @param	mlen	[in] data length for encryption
  * @param	pk		[in] public key for encryption. pk = (A, B)
  */
int crypto_encrypt(unsigned char *c, unsigned long long *clen, const unsigned char *m, unsigned long long mlen, const unsigned char *pk) {
	start = clock();

	int i, j, hw = 0;
	int neg_start = 0, back_position = HR;

	uint8_t r[LWE_M] = { 0, };
	uint16_t r_idx[HR];
	uint16_t b[LWE_L] = { 0, };
	uint16_t a[LWE_N] = { 0, };
	
	uint64_t delta[LWE_L / 64];
	uint64_t *hash = NULL;
	uint64_t c1[LAMBDA / 32] = { 0, };

	TupleElement tuple;
	unsigned char *S = "";

	// Generate a random vector delta
	randombytes((unsigned char*)delta, LWE_L / 8);
	
	// Compute the hash values G(delta) and H'(delta)
#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY1_N663)
	hash = (uint64_t *)calloc(8, sizeof(uint64_t));
	sha512((unsigned char*)delta, 32, (unsigned char*)hash, 64);
#endif
#if defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY3_N952)
	hash = (uint64_t *)calloc(12, sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = 48 * 8;
	TupleHash256(&tuple, 1, (unsigned char*)hash, 12 * 8 * 8, S, strlen(S) * 8);
#endif
#if defined(CCA_CATEGORY5_N1088) || defined(CCA_CATEGORY5_N1300)
	hash = (uint64_t *)calloc(16, sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = 64 * 8;
	TupleHash256(&tuple, 1, (unsigned char*)hash, 16 * 8 * 8, S, strlen(S) * 8);
#endif

	// Set c1 = M xor G(delta)
	for (i = 0; i < LAMBDA / 32; ++i) {
		c1[i] = (((uint64_t)m[i * 8] << 56) + ((uint64_t)m[i * 8 + 1] << 48) + ((uint64_t)m[i * 8 + 2] << 40) + ((uint64_t)m[i * 8 + 3] << 32)
			+ ((uint64_t)m[i * 8 + 4] << 24) + ((uint64_t)m[i * 8 + 5] << 16) + ((uint64_t)m[i * 8 + 6] << 8) + ((uint64_t)m[i * 8 + 7] & 0xff)) ^ hash[i];
	}
	for (i = 0; i < LAMBDA / 32; i++) {
		c[i * 8] = (unsigned char)(c1[i] >> 56);
		c[i * 8 + 1] = (unsigned char)(c1[i] >> 48);
		c[i * 8 + 2] = (unsigned char)(c1[i] >> 40);
		c[i * 8 + 3] = (unsigned char)(c1[i] >> 32);
		c[i * 8 + 4] = (unsigned char)(c1[i] >> 24);
		c[i * 8 + 5] = (unsigned char)(c1[i] >> 16);
		c[i * 8 + 6] = (unsigned char)(c1[i] >> 8);
		c[i * 8 + 7] = (unsigned char)(c1[i] & 0xff);
	}

	// Set c3 = H'(delta)
#ifdef CCA_CATEGORY1_N663
	for (i = 0; i < LAMBDA / 32; i++) {
		c[(LWE_L / 8) + LWE_N + LWE_L + i * 8] = (unsigned char)(hash[i + LAMBDA / 32] >> 56);
		c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 1] = (unsigned char)(hash[i + LAMBDA / 32] >> 48);
		c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 2] = (unsigned char)(hash[i + LAMBDA / 32] >> 40);
		c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 3] = (unsigned char)(hash[i + LAMBDA / 32] >> 32);
		c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 4] = (unsigned char)(hash[i + LAMBDA / 32] >> 24);
		c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 5] = (unsigned char)(hash[i + LAMBDA / 32] >> 16);
		c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 6] = (unsigned char)(hash[i + LAMBDA / 32] >> 8);
		c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 7] = (unsigned char)(hash[i + LAMBDA / 32] & 0xff);
	}
#endif
#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY3_N952) || defined(CCA_CATEGORY5_N1088) || defined(CCA_CATEGORY5_N1300)
	for (i = 0; i < LAMBDA / 32; i++) {
		c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8] = (unsigned char)(hash[i + LAMBDA / 32] >> 56);
		c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 1] = (unsigned char)(hash[i + LAMBDA / 32]>> 48);
		c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 2] = (unsigned char)(hash[i + LAMBDA / 32] >> 40);
		c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 3] = (unsigned char)(hash[i + LAMBDA / 32] >> 32);
		c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 4] = (unsigned char)(hash[i + LAMBDA / 32] >> 24);
		c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 5] = (unsigned char)(hash[i + LAMBDA / 32] >> 16);
		c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 6] = (unsigned char)(hash[i + LAMBDA / 32] >> 8);
		c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 7] = (unsigned char)(hash[i + LAMBDA / 32] & 0xff);
	}
#endif

	// Set r = H(delta)
	hash = (uint64_t*)calloc(LWE_M / 64, sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = LWE_L;
	TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_M, S, strlen(S) * 8);

#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY1_N663) || defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY3_N952) || defined(CCA_CATEGORY5_N1300)
	i = 0;
	do {
		j = (uint16_t)hash[i] & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 10) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 12) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 22) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 24) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 34) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 36) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 46) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 48) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 58) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		i++;
		if (i == LWE_M / 64) {
			i = 0;
			tuple.input = (unsigned char*)hash;
			tuple.inputBitLen = LWE_M;
			TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_M, S, strlen(S) * 8);
		}
	} while (hw < HR);
#endif
#ifdef CCA_CATEGORY5_N1088
	i = 0;
	do {
		j = (uint16_t)hash[i] & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 11) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 13) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 24) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 26) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 37) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 39) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 50) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		i++;
		if (i == LWE_M / 64) {
			i = 0;
			tuple.input = (unsigned char*)hash;
			tuple.inputBitLen = LWE_M;
			TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_M, S, strlen(S) * 8);
		}
	} while (hw < HR);
#endif
	
	// Generate r_idx
	for (i = 0; i < LWE_M; ++i) {
		if (r[i] == 0x01)
			r_idx[neg_start++] = i;
		else if (r[i] == 0xff)
			r_idx[--back_position] = i;
	}

	// Initialize b as q/2 * delta
	for (i = 0; i < (LAMBDA / 32); ++i) { for (j = 0; j < 64; ++j) { b[64 * i + j] = ((uint16_t)(delta[i] >> j)) << _16_LOG_T; } }

	// Compute A^T * r and B^T * r, and then add to ct.a and ct.b, respectively.
	for (i = 0; i < HR; ++i) {
		uint16_t branch = (2 * ((i - neg_start) >> sft & 0x1) - 1);
		for (j = 0; j < LWE_L; ++j) {
			uint16_t pk_A_ri = pk[(LWE_N * 2 * r_idx[i]) + j * 2] << 8 | pk[(LWE_N * 2 * r_idx[i]) + j * 2 + 1];
			uint16_t pk_B_ri = pk[(PublicKey_A + LWE_L * 2 * r_idx[i]) + j * 2] << 8 | pk[(PublicKey_A + LWE_L * 2 * r_idx[i]) + j * 2 + 1];
			a[j] += branch * pk_A_ri;
			b[j] += branch * pk_B_ri;
		}
		for (j = LWE_L; j < LWE_N; ++j) {
			uint16_t pk_A_ri = pk[(LWE_N * 2 * r_idx[i]) + j * 2] << 8 | pk[(LWE_N * 2 * r_idx[i]) + j * 2 + 1];
			a[j] += branch * pk_A_ri;
		}
	}

	// Send a and b from mod q to mod p
#ifdef CCA_CATEGORY1_N663
	for (i = 0; i < LWE_L; ++i) {
		c[(LWE_L / 8) + i] = ((a[i] + RD_ADD) & RD_AND) >> 8;
		c[(LWE_L / 8) + LWE_N + i] = ((b[i] + RD_ADD) & RD_AND) >> 8;
	}
	for (i = LWE_L; i < LWE_N; ++i) {
		c[(LWE_L / 8) + i] = ((a[i] + RD_ADD) & RD_AND) >> 8;
	}
	*clen = (LWE_L / 8) + LWE_N + LWE_L + (LAMBDA / 4);
#endif
#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY3_N952) || defined(CCA_CATEGORY5_N1088) || defined(CCA_CATEGORY5_N1300)
	for (i = 0; i < LWE_L; ++i) {
		a[i] = (a[i] + RD_ADD) & RD_AND;
		c[(LWE_L / 8) + i * 2] = a[i] >> 8;
		c[(LWE_L / 8) + i * 2 + 1] = a[i] & 0xff;

		b[i] = (b[i] + RD_ADD) & RD_AND;
		c[(LWE_L / 8) + (LWE_N * 2) + i * 2] = b[i] >> 8;
		c[(LWE_L / 8) + (LWE_N * 2) + i * 2 + 1] = b[i] & 0xff;
	}
	for (i = LWE_L; i < LWE_N; ++i) {
		a[i] = (a[i] + RD_ADD) & RD_AND;
		c[(LWE_L / 8) + i * 2] = a[i] >> 8;
		c[(LWE_L / 8) + i * 2 + 1] = a[i] & 0xff;
	}
	*clen = (LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + (LAMBDA / 4);
#endif

	free(hash);

	finish = clock();
	elapsed1 += (finish - start);

	return 0;
}

/**
  * @param	m		[out] data for decryption
  * @param	mlen	[in] data length for decryption
  * @param	c		[in] encrypted data. c = (c1, (a, b), c3)
  * @param	clen	[in] encrypted data length
  * @param	sk		[in] private/public key for decryption. sk, pk = (A, B)
  */
int crypto_encrypt_open(unsigned char *m, unsigned long long *mlen, const unsigned char *c, unsigned long long clen, const unsigned char *sk) {
	start = clock();
	int res = 0;
	int i, j, hw = 0;
	int neg_start = 0, back_position = HR;

	uint8_t r[LWE_M] = { 0, };
	uint16_t decomp_delta[LWE_L];
	uint16_t b[LWE_L];
	uint16_t a[LWE_N] = { 0, };
	uint16_t r_idx[HR];

	uint64_t delta[LWE_L / 64] = { 0, };
	uint64_t c1[LAMBDA / 32] = { 0, };
	uint64_t c3[LAMBDA / 32] = { 0, };
	uint64_t *hash = NULL;

	TupleElement tuple;
	unsigned char *S = "";

#ifdef CCA_CATEGORY1_N663
	for (i = 0; i < LWE_L; ++i) { decomp_delta[i] = c[(LWE_L / 8) + LWE_N + i] << 8; } // Initialize delta as b
	// Compute delta = (delta + S^T * a)
	for (i = 0; i < LWE_N; ++i) {
		//uint8_t* sk_i = sk + LWE_L * i;
		uint16_t ctx_ai = c[(LWE_L / 8) + i] << 8;
		for (j = 0; j < LWE_L; ++j) {
			decomp_delta[j] += ctx_ai * (char)sk[LWE_L * i + j];
		}
	}
#endif
#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY3_N952) || defined(CCA_CATEGORY5_N1088) || defined(CCA_CATEGORY5_N1300)
	for (i = 0; i < LWE_L; ++i) { decomp_delta[i] = c[(LWE_L / 8) + (LWE_N * 2) + i * 2] << 8 | c[(LWE_L / 8) + (LWE_N * 2) + i * 2 + 1] & 0xff; } // Initialize decomp_delta as b	
	// Compute delta = (delta + S^T * a)
	for (i = 0; i < LWE_N; ++i) {
		//uint8_t* sk_i = sk + LWE_L * i;
		uint16_t ctx_ai = c[(LWE_L / 8) + i * 2] << 8 | c[(LWE_L / 8) + i * 2 + 1] & 0xff;
		for (j = 0; j < LWE_L; ++j) {
			decomp_delta[j] += ctx_ai * (char)sk[LWE_L * i + j];
		}
	}
#endif

	// Compute delta = 2/p * delta
	for (i = 0; i < LWE_L; ++i) {
		decomp_delta[i] += DEC_ADD;
		decomp_delta[i] >>= _16_LOG_T;
	}

	// Set delta
	for (i = 0; i < (LAMBDA / 32); ++i) {
		for (j = 0; j < 64; ++j) {
			uint64_t a = ((uint64_t)decomp_delta[64 * i + j]) << j;
			delta[i] ^= a;
		}
	}

	// Compute the hash values H'(delta) and G(delta)
#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY1_N663)
	hash = (uint64_t *)calloc(8, sizeof(uint64_t));
	sha512((unsigned char*)delta, 32, (unsigned char*)hash, 64);
#endif
#if defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY3_N952)
	hash = (uint64_t *)calloc(12, sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = 48 * 8;
	TupleHash256(&tuple, 1, (unsigned char*)hash, 12 * 8 * 8, S, strlen(S) * 8);
#endif
#if defined(CCA_CATEGORY5_N1088) || defined(CCA_CATEGORY5_N1300)
	hash = (uint64_t *)calloc(16, sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = 64 * 8;
	TupleHash256(&tuple, 1, (unsigned char*)hash, 16 * 8 * 8, S, strlen(S) * 8);
#endif

	// M = c1 xor G(delta)
	for (i = 0; i < LAMBDA / 32; ++i) {
		c1[i] = (uint64_t)c[i * 8] << 56;
		c1[i] += (uint64_t)c[i * 8 + 1] << 48;
		c1[i] += (uint64_t)c[i * 8 + 2] << 40;
		c1[i] += (uint64_t)c[i * 8 + 3] << 32;
		c1[i] += (uint64_t)c[i * 8 + 4] << 24;
		c1[i] += (uint64_t)c[i * 8 + 5] << 16;
		c1[i] += (uint64_t)c[i * 8 + 6] << 8;
		c1[i] += (uint64_t)c[i * 8 + 7];
	}
	for (i = 0; i < LAMBDA / 32; ++i) {
		m[i * 8] = (unsigned char)((c1[i] ^ hash[i]) >> 56);
		m[i * 8 + 1] = (unsigned char)((c1[i] ^ hash[i]) >> 48);
		m[i * 8 + 2] = (unsigned char)((c1[i] ^ hash[i]) >> 40);
		m[i * 8 + 3] = (unsigned char)((c1[i] ^ hash[i]) >> 32);
		m[i * 8 + 4] = (unsigned char)((c1[i] ^ hash[i]) >> 24);
		m[i * 8 + 5] = (unsigned char)((c1[i] ^ hash[i]) >> 16);
		m[i * 8 + 6] = (unsigned char)((c1[i] ^ hash[i]) >> 8);
		m[i * 8 + 7] = (unsigned char)((c1[i] ^ hash[i]));
	}
	
	*mlen = sizeof(c1);

	// Set c3
#ifdef CCA_CATEGORY1_N663
	for (i = 0; i < LAMBDA / 32; ++i) {
		c3[i] = (((uint64_t)(c[(LWE_L / 8) + LWE_N + LWE_L + i * 8] & 0xff) << 56) + ((uint64_t)(c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 1] & 0xff) << 48)
			+ ((uint64_t)(c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 2] & 0xff) << 40) + ((uint64_t)(c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 3] & 0xff) << 32)
			+ ((uint64_t)(c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 4] & 0xff) << 24) + ((uint64_t)(c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 5] & 0xff) << 16)
			+ ((uint64_t)(c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 6] & 0xff) << 8) + ((uint64_t)c[(LWE_L / 8) + LWE_N + LWE_L + i * 8 + 7] & 0xff));
	}
#endif
#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY3_N952) || defined(CCA_CATEGORY5_N1088) || defined(CCA_CATEGORY5_N1300)
	for (i = 0; i < LAMBDA / 32; ++i) {
		c3[i] = (((uint64_t)(c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8] & 0xff) << 56) + ((uint64_t)(c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 1] & 0xff) << 48)
			+ ((uint64_t)(c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 2] & 0xff) << 40) + ((uint64_t)(c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 3] & 0xff) << 32)
			+ ((uint64_t)(c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 4] & 0xff) << 24) + ((uint64_t)(c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 5] & 0xff) << 16)
			+ ((uint64_t)(c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 6] & 0xff) << 8) + ((uint64_t)c[(LWE_L / 8) + (LWE_N * 2) + (LWE_L * 2) + i * 8 + 7] & 0xff));
	}
#endif

	// If c3 ≠ H'(delta), then terminate
#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY1_N663)
	if ((hash[LAMBDA / 32] != c3[0]) || (hash[LAMBDA / 32 + 1] != c3[1]) || (hash[LAMBDA / 32 + 2] != c3[2]) || (hash[LAMBDA / 32 + 3] != c3[3]))
		return res = 1;
#endif
#if defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY3_N952)
	if ((hash[LAMBDA / 32] != c3[0]) || (hash[LAMBDA / 32 + 1] != c3[1]) || (hash[LAMBDA / 32 + 2] != c3[2]) || (hash[LAMBDA / 32 + 3] != c3[3])
		|| (hash[LAMBDA / 32 + 4] != c3[4]) || (hash[LAMBDA / 32 + 5] != c3[5]))
		return res = 1;
#endif
#if defined(CCA_CATEGORY5_N1088) || defined(CCA_CATEGORY5_N1300)
	if ((hash[LAMBDA / 32] != c3[0]) || (hash[LAMBDA / 32 + 1] != c3[1]) || (hash[LAMBDA / 32 + 2] != c3[2]) || (hash[LAMBDA / 32 + 3] != c3[3])
		|| (hash[LAMBDA / 32 + 4] != c3[4]) || (hash[LAMBDA / 32 + 5] != c3[5]) || (hash[LAMBDA / 32 + 6] != c3[6]) || (hash[LAMBDA / 32 + 7] != c3[7]))
		return res = 1;
#endif

	// Set r = H(delta)
	hash = (uint64_t*)calloc(LWE_M / 64, sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = LWE_L;
	TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_M, S, strlen(S) * 8);

#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY1_N663) || defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY3_N952) || defined(CCA_CATEGORY5_N1300)
	i = 0;
	do {
		j = (uint16_t)hash[i] & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 10) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 12) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 22) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 24) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 34) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 36) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 46) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 48) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 58) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		i++;
		if (i == LWE_M / 64) {
			i = 0;
			tuple.input = (unsigned char*)hash;
			tuple.inputBitLen = LWE_M;
			TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_M, S, strlen(S) * 8);
		}
	} while (hw < HR);
#endif
#ifdef CCA_CATEGORY5_N1088
	i = 0;
	do {
		j = (uint16_t)hash[i] & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 11) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 13) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 24) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 26) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 37) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 39) & (LWE_M - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 50) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		i++;
		if (i == LWE_M / 64) {
			i = 0;
			tuple.input = (unsigned char*)hash;
			tuple.inputBitLen = LWE_M;
			TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_M, S, strlen(S) * 8);
		}
	} while (hw < HR);
#endif
	
	// Generate r_idx
	for (i = 0; i < LWE_M; ++i) {
		if (r[i] == 0x01)
			r_idx[neg_start++] = i;
		else if (r[i] == 0xff)
			r_idx[--back_position] = i;
	}

	// Initialize b' as q/2 * delta
	for (i = 0; i < LWE_L; ++i) { b[i] = decomp_delta[i] << _16_LOG_T; }

	// Compute A^T * r and B^T * r, and then add to a' and b', respectively.
	for (i = 0; i < HR; ++i) {
		uint16_t branch = (2 * ((i - neg_start) >> sft & 0x1) - 1);
		for (j = 0; j < LWE_L; ++j) {
			uint16_t pk_A_ri = sk[(CRYPTO_SECRETKEYBYTES + LWE_N * 2 * r_idx[i]) + j * 2] << 8 | sk[(CRYPTO_SECRETKEYBYTES + LWE_N * 2 * r_idx[i]) + j * 2 + 1];
			uint16_t pk_B_ri = sk[(CRYPTO_SECRETKEYBYTES + PublicKey_A + LWE_L * 2 * r_idx[i]) + j * 2] << 8 | sk[(CRYPTO_SECRETKEYBYTES + PublicKey_A + LWE_L * 2 * r_idx[i]) + j * 2 + 1];
			a[j] += branch * pk_A_ri;
			b[j] += branch * pk_B_ri;
		}
		for (j = LWE_L; j < LWE_N; ++j) {
			uint16_t pk_A_ri = sk[(CRYPTO_SECRETKEYBYTES + LWE_N * 2 * r_idx[i]) + j * 2] << 8 | sk[(CRYPTO_SECRETKEYBYTES + LWE_N * 2 * r_idx[i]) + j * 2 + 1];
			a[j] += branch * pk_A_ri;
		}
	}

	// Send a and b from mod q to mod p
	for (i = 0; i < LWE_L; ++i) { 
		a[i] = (a[i] + RD_ADD) & RD_AND;
		b[i] = (b[i] + RD_ADD) & RD_AND; 
	}
	for (i = LWE_L; i < LWE_N; ++i) { 
		a[i] = (a[i] + RD_ADD) & RD_AND; 
	}

	// If (a, b) ≠ (a', b'), then terminate
#ifdef CCA_CATEGORY1_N663
	for (i = 0; i < LWE_N; ++i) {
		if (a[i] >> 8 != c[(LWE_L / 8) + i]) {
			res = 2;
			break;
		}
	}
	for (i = 0; i < LWE_L; ++i) {
		if (b[i] >> 8 != c[(LWE_L / 8) + LWE_N + i]) {
			res = 2;
			break;
		}
	}
#endif
#if defined(CCA_CATEGORY1_N536) || defined(CCA_CATEGORY3_N816) || defined(CCA_CATEGORY3_N952) || defined(CCA_CATEGORY5_N1088) || defined(CCA_CATEGORY5_N1300)
	for (i = 0; i < LWE_N; ++i) {
		if (a[i] != ((c[(LWE_L / 8) + i * 2] & 0xff) << 8 | c[(LWE_L / 8) + i * 2 + 1] & 0xff)) {
			res = 2;
			break;
		}
	}
	for (i = 0; i < LWE_L; ++i) {
		if (b[i] != ((c[(LWE_L / 8) + (LWE_N * 2) + i * 2] & 0xff) << 8 | c[(LWE_L / 8) + (LWE_N * 2) + i * 2 + 1] & 0xff)) {
			res = 2;
			break;
		}
	}
#endif

	if (res != 0) { for (i = 0; i < *mlen; ++i) { m[i] = 0; } }

	free(hash);
	
	finish = clock();
	elapsed2 += (finish - start);

	return res;
}
