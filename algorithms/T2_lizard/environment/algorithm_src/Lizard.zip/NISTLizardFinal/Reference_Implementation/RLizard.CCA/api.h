#ifndef API_H
#define API_H

#include "params.h"

#define PublicKey_A (LWE_N * 2)
#define PublicKey_B (LWE_N * 2)

#define CRYPTO_SECRETKEYBYTES LWE_N
#define CRYPTO_PUBLICKEYBYTES (PublicKey_A + PublicKey_B)

#ifdef RING_CATEGORY1
#define CRYPTO_BYTES (LAMBDA / 4) + LWE_N + LWE_N + (LWE_N / 8)
#endif
#if defined(RING_CATEGORY3_N1024) || defined(RING_CATEGORY3_N2048) || defined(RING_CATEGORY5)
#define CRYPTO_BYTES (LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + (LWE_N / 8)
#endif

#define CRYPTO_ALGNAME PARAMNAME

#endif