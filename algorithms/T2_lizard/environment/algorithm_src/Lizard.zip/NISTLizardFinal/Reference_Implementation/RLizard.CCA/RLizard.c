#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "RLizard.h"
#include "randombytes.h"
#include <libkeccak.a.headers/SP800-185.h>

uint16_t seed[PublicKey_B];
int count = 0;

#ifdef NOISE_D1
#define SAMPLE_DG Sample_D1
const uint16_t CDF_TABLE[4] = { 190, 437, 504, 511 }; // out of [0, 511]
const size_t TABLE_LENGTH = 4;

uint16_t Sample_D1() {
	uint16_t rnd = seed[count == PublicKey_B ? count = 0 : count++] & 0x01ff;
	uint16_t sign = seed[count == PublicKey_B ? count = 0 : count++] & 0x01;
	uint16_t sample = 0;
	for (size_t i = 0; i < TABLE_LENGTH - 1; ++i) {
		sample += (CDF_TABLE[i] - rnd) >> 15;
	}
	sample = ((-sign) ^ sample) + sign;
	return sample;
}
#endif
#ifdef NOISE_D2
#define SAMPLE_DG Sample_D2
const uint16_t CDF_TABLE[6] = { 279, 722, 941, 1009, 1022, 1023 }; // out of [0, 1023]
const size_t TABLE_LENGTH = 6;

uint16_t Sample_D2() {
	uint16_t rnd = seed[count == PublicKey_B ? count = 0 : count++] & 0x03ff;
	uint16_t sign = seed[count == PublicKey_B ? count = 0 : count++] & 0x01;
	uint16_t sample = 0;
	for (size_t i = 0; i < TABLE_LENGTH - 1; ++i) {
		sample += (CDF_TABLE[i] - rnd) >> 15;
	}
	sample = ((-sign) ^ sample) + sign;
	return sample;
}
#endif
#ifdef NOISE_D3
#define SAMPLE_DG Sample_D3
const uint16_t CDF_TABLE[8] = { 407, 1127, 1623, 1889, 2000, 2036, 2045, 2047 }; // out of [0, 2047]
const size_t TABLE_LENGTH = 8;

uint16_t Sample_D3() {
	uint16_t rnd = seed[count == PublicKey_B ? count = 0 : count++] & 0x07ff;
	uint16_t sign = seed[count == PublicKey_B ? count = 0 : count++] & 0x01;
	uint16_t sample = 0;
	for (size_t i = 0; i < TABLE_LENGTH - 1; ++i) {
		sample += (CDF_TABLE[i] - rnd) >> 15;
	}
	sample = ((-sign) ^ sample) + sign;
	return sample;
}
#endif
#ifdef NOISE_D4
#define SAMPLE_DG Sample_D4
const uint16_t CDF_TABLE[10] = { 154, 443, 676, 838, 936, 987, 1010, 1019, 1022, 1023 }; // out of [0, 1023]
const size_t TABLE_LENGTH = 10;

uint16_t Sample_D4() {
	uint16_t rnd = seed[count == PublicKey_B ? count = 0 : count++] & 0x03ff;
	uint16_t sign = seed[count == PublicKey_B ? count = 0 : count++] & 0x01;
	uint16_t sample = 0;
	for (size_t i = 0; i < TABLE_LENGTH - 1; ++i) {
		sample += (CDF_TABLE[i] - rnd) >> 15;
	}
	sample = ((-sign) ^ sample) + sign;
	return sample;
}
#endif

/**
  * @param	pk		[in] public key for encryption. pk = (a, b)
  * @param	sk		[in] private key for decryption
  */
int crypto_encrypt_keypair(unsigned char *pk, unsigned char *sk) {
	int i, j, hw = 0, tmp, count1 = 0;

	uint16_t pk_a[LWE_N];
	uint16_t pk_b[LWE_N];

	uint16_t seed1[16];

	// Generate a random polynomial a
	randombytes((unsigned char*)pk_a, PublicKey_A);
	for (int i = 0; i < LWE_N; ++i) {
		pk_a[i] <<= _16_LOG_Q;
		pk[i * 2] = pk_a[i] >> 8;
		pk[i * 2 + 1] = pk_a[i] & 0xff;
	}

	memset(sk, 0, sizeof(unsigned char) * LWE_N);
	randombytes((unsigned char*)seed1, 32);
	// Set a secret polynomial s
	while (hw < HS) {
		tmp = seed1[count1++] & (LWE_N - 1);
		if (sk[tmp] == 0) {
			sk[tmp] = (seed1[count1++] & 0x02) - 1;
			hw++;
		}
		if (count1 >= 15) {
			randombytes((unsigned char*)seed1, 32);
			count1 = 0;
		}
	}

	// Initialize b as an error polynomial e
	randombytes((unsigned char*)seed, PublicKey_B * 2);
	for (int i = 0; i < LWE_N; ++i)
		pk_b[i] = SAMPLE_DG() << _16_LOG_Q;

	// Add -a * s to b. Resulting b = -a * s + e
	for (i = 0; i < LWE_N; ++i) {
		for (j = 0; j < LWE_N; ++j) {
			uint16_t tmp1 = (i + j) < LWE_N ? 1 : -1;
			pk_b[(i + j) % LWE_N] -= tmp1 * (pk[j * 2] << 8 | pk[j * 2 + 1]) * (char)sk[i];
		}
	}

	for (i = 0; i < LWE_N; ++i) {
		pk[PublicKey_A + (i * 2)] = pk_b[i] >> 8;
		pk[PublicKey_A + (i * 2 + 1)] = pk_b[i] & 0xff;
	}
	
	return 0;
}

/**
  * @param	c		[out] data to be encrypted. c = (c1, c2, c3)
  * @param	clen	[in] data length to be encrypted
  * @param	m		[in] data for encryption
  * @param	mlen	[in] data length for encryption
  * @param	pk		[in] public key for encryption. pk = (a, b)
  */
int crypto_encrypt(unsigned char *c, unsigned long long *clen, const unsigned char *m, unsigned long long mlen, const unsigned char *pk) {
	start = clock();
	int i, j, hw = 0;

	uint8_t r[LWE_N] = { 0, };
	uint16_t c2h_a[LWE_N] = { 0, };
	uint16_t c2h_b[LWE_N] = { 0, };
	
	uint64_t delta[LWE_N / 64];
	uint64_t *hash = NULL;
	uint64_t c1[LAMBDA / 32] = { 0, };

	TupleElement tuple;
	unsigned char *S = "";

	// Generate a random polynomial delta
	randombytes((unsigned char*)delta, LWE_N / 8);

	// Compute the hash values G(delta) and H'(delta)
	hash = (uint64_t *)calloc((LAMBDA / 32) + (LWE_N / 64), sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = LWE_N;
	TupleHash256(&tuple, 1, (unsigned char*)hash, ((LAMBDA / 32) + (LWE_N / 64)) * 8 * 8, S, strlen(S) * 8);

	// Set c1 = m xor G(delta)
	for (i = 0; i < LAMBDA / 32; ++i) {
		c1[i] = (((uint64_t)m[i * 8] << 56) + ((uint64_t)m[i * 8 + 1] << 48) + ((uint64_t)m[i * 8 + 2] << 40) + ((uint64_t)m[i * 8 + 3] << 32)
			+ ((uint64_t)m[i * 8 + 4] << 24) + ((uint64_t)m[i * 8 + 5] << 16) + ((uint64_t)m[i * 8 + 6] << 8) + ((uint64_t)m[i * 8 + 7] & 0xff)) ^ hash[i];
	}
	for (i = 0; i < LAMBDA / 32; i++) {
		c[i * 8] = (unsigned char)(c1[i] >> 56);
		c[i * 8 + 1] = (unsigned char)(c1[i] >> 48);
		c[i * 8 + 2] = (unsigned char)(c1[i] >> 40);
		c[i * 8 + 3] = (unsigned char)(c1[i] >> 32);
		c[i * 8 + 4] = (unsigned char)(c1[i] >> 24);
		c[i * 8 + 5] = (unsigned char)(c1[i] >> 16);
		c[i * 8 + 6] = (unsigned char)(c1[i] >> 8);
		c[i * 8 + 7] = (unsigned char)(c1[i] & 0xff);
	}

	// Set c3 = H'(delta)
#ifdef RING_CATEGORY1
	for (i = 0; i < 16; i++) {
		c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8] = (unsigned char)(hash[i + LAMBDA / 32] >> 56);
		c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 1] = (unsigned char)(hash[i + LAMBDA / 32] >> 48);
		c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 2] = (unsigned char)(hash[i + LAMBDA / 32] >> 40);
		c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 3] = (unsigned char)(hash[i + LAMBDA / 32] >> 32);
		c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 4] = (unsigned char)(hash[i + LAMBDA / 32] >> 24);
		c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 5] = (unsigned char)(hash[i + LAMBDA / 32] >> 16);
		c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 6] = (unsigned char)(hash[i + LAMBDA / 32] >> 8);
		c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 7] = (unsigned char)(hash[i + LAMBDA / 32] & 0xff);
	}
#endif
#if defined(RING_CATEGORY3_N1024) || defined(RING_CATEGORY3_N2048) || defined(RING_CATEGORY5)
	for (i = 0; i < (LWE_N / 64); i++) {
		c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8] = (unsigned char)(hash[i + LAMBDA / 32] >> 56);
		c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 1] = (unsigned char)(hash[i + LAMBDA / 32]>> 48);
		c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 2] = (unsigned char)(hash[i + LAMBDA / 32] >> 40);
		c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 3] = (unsigned char)(hash[i + LAMBDA / 32] >> 32);
		c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 4] = (unsigned char)(hash[i + LAMBDA / 32] >> 24);
		c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 5] = (unsigned char)(hash[i + LAMBDA / 32] >> 16);
		c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 6] = (unsigned char)(hash[i + LAMBDA / 32] >> 8);
		c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 7] = (unsigned char)(hash[i + LAMBDA / 32] & 0xff);
	}
#endif

	// Set r = H(delta)
	hash = (uint64_t *)calloc(LWE_N / 64, sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = LWE_N;
	TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_N, S, strlen(S) * 8);

#if defined(RING_CATEGORY1) || defined(RING_CATEGORY3_N1024) 
	i = 0;
	do {
		j = (uint16_t)hash[i] & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 10) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 12) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 22) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 24) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 34) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 36) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 46) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 48) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 58) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		i++;
		if (i == LWE_N / 64) {
			i = 0;
			tuple.input = (unsigned char*)hash;
			tuple.inputBitLen = LWE_N;
			TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_N, S, strlen(S) * 8);
		}
	} while (hw < HR);
#endif
#if defined(RING_CATEGORY3_N2048) || defined(RING_CATEGORY5)
	i = 0;
	do {
		j = (uint16_t)hash[i] & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 11) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 13) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 24) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 26) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 37) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 39) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 50) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		i++;
		if (i == LWE_N / 64) {
			i = 0;
			tuple.input = (unsigned char*)hash;
			tuple.inputBitLen = LWE_N;
			TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_N, S, strlen(S) * 8);
		}
	} while (hw < HR);
#endif

	// Initialize c2h_b as q/2 * delta
	for (i = 0; i < LWE_N / 64; ++i) { for (j = 0; j < 64; ++j) { c2h_b[64 * i + j] = ((uint16_t)(delta[i] >> j)) << _16_LOG_T; } }
	
	// Compute a * r and b * r, and then add to c2h_a and c2h_b, respectively.
	for (i = 0; i < LWE_N; ++i) {
		for (j = 0; j < LWE_N; ++j) {
			uint16_t tmp = i + j < LWE_N ? 1 : -1;
			c2h_a[(i + j) % LWE_N] += tmp * ((pk[j * 2] << 8 | pk[j * 2 + 1]) * (char)r[i]);
			c2h_b[(i + j) % LWE_N] += tmp * ((pk[PublicKey_A + j * 2] << 8 | pk[PublicKey_A + j * 2 + 1]) * (char)r[i]);
		}
	}

	// Send c2h_a and c2h_b from mod q to mod p
#ifdef RING_CATEGORY1
	for (i = 0; i < LWE_N; ++i) {
		c[(LAMBDA / 4) + i] = ((c2h_a[i] + RD_ADD) & RD_AND) >> 8;
		c[(LAMBDA / 4) + LWE_N + i] = ((c2h_b[i] + RD_ADD) & RD_AND) >> 8;
	}
	*clen = (LAMBDA / 4) + LWE_N + LWE_N + (LWE_N / 8);
#endif
#if defined(RING_CATEGORY3_N1024) || defined(RING_CATEGORY3_N2048) || defined(RING_CATEGORY5)
	for (i = 0; i < LWE_N; ++i) {
		c2h_a[i] = (c2h_a[i] + RD_ADD) & RD_AND;
		c[(LAMBDA / 4) + i * 2] = c2h_a[i] >> 8;
		c[(LAMBDA / 4) + i * 2 + 1] = c2h_a[i] & 0xff;
		c2h_b[i] = (c2h_b[i] + RD_ADD) & RD_AND;
		c[(LAMBDA / 4) + (LWE_N * 2) + i * 2] = c2h_b[i] >> 8;
		c[(LAMBDA / 4) + (LWE_N * 2) + i * 2 + 1] = c2h_b[i] & 0xff;
	}
	*clen = (LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + (LWE_N / 8);
#endif
	
	free(hash);

	finish = clock();
	elapsed1 += (finish - start);

	return 0;
}

/**
  * @param	m		[out] data for decryption
  * @param	mlen	[in] data length for decryption
  * @param	c		[in] encrypted data. c = (c1, c2, c3)
  * @param	clen	[in] encrypted data length
  * @param	sk		[in] private/public key for decryption. sk, pk = (A, B)
  */
int crypto_encrypt_open(unsigned char *m, unsigned long long *mlen, const unsigned char *c, unsigned long long clen, const unsigned char *sk) {
	start = clock();
	int res = 0;
	int i, j, hw = 0;

	uint8_t r[LWE_N] = { 0, };

	uint16_t decomp_delta[LWE_N];
	uint16_t c2h_b[LWE_N] = { 0, };
	uint16_t c2h_a[LWE_N] = { 0, };

	uint64_t delta[LWE_N / 64] = { 0, };
	uint64_t c1[LAMBDA / 32];
	uint64_t c3[LWE_N / 8];
	uint64_t *hash = NULL;

	TupleElement tuple;
	unsigned char *S = "";
	
#ifdef RING_CATEGORY1
	for (i = 0; i < LWE_N; ++i) decomp_delta[i] = c[(LAMBDA / 4) + LWE_N + i] << 8; // Initialize delta as c2h_b
	// Compute delta = (delta + c1 * s)
	for (i = 0; i < LWE_N; ++i) {
		for (j = 0; j < LWE_N; ++j) {
			uint16_t tmp = i + j < LWE_N ? 1 : -1;
			decomp_delta[(i + j) % LWE_N] += tmp * ((c[(LAMBDA / 4) + j] << 8) * (char)sk[i]);
		}
	}
#endif
#if defined(RING_CATEGORY3_N1024) || defined(RING_CATEGORY3_N2048) || defined(RING_CATEGORY5)
	for (i = 0; i < LWE_N; ++i) decomp_delta[i] = c[(LAMBDA / 4) + (LWE_N * 2) + i * 2] << 8 | c[(LAMBDA / 4) + (LWE_N * 2) + i * 2 + 1] & 0xff;	// Initialize delta as c2h_b
	// Compute delta = (delta + c1 * s)
	for (i = 0; i < LWE_N; ++i) {
		for (j = 0; j < LWE_N; ++j) {
			uint16_t tmp = i + j < LWE_N ? 1 : -1;
			decomp_delta[(i + j) % LWE_N] += tmp * ((c[(LAMBDA / 4) + j * 2] << 8 | c[(LAMBDA / 4) + j * 2 + 1] & 0xff) * (char)sk[i]);
		}
	}
#endif
	
	// Compute delta = 2/p * delta
	for (i = 0; i < LWE_N; ++i) {
		decomp_delta[i] += DEC_ADD;
		decomp_delta[i] >>= _16_LOG_T;
	}
	
	// Set delta
	for (i = 0; i < (LWE_N / 64); ++i) {
		for (j = 0; j < 64; ++j) {
			uint64_t a = ((uint64_t)decomp_delta[64 * i + j]) << j;
			delta[i] ^= a;
		}
	}
	
	// Compute the hash values H'(delta)
	hash = (uint64_t *)calloc((LAMBDA / 32) + (LWE_N / 64), sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = LWE_N;
	TupleHash256(&tuple, 1, (unsigned char*)hash, ((LAMBDA / 32) + (LWE_N / 64)) * 8 * 8, S, strlen(S) * 8);
	
	// Set c3
	// If c3 ≠ H'(delta), then terminate
#ifdef RING_CATEGORY1
	for (i = 0; i < LWE_N / 64; ++i) {
		c3[i] = (((uint64_t)(c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8] & 0xff) << 56) + ((uint64_t)(c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 1] & 0xff) << 48)
			+ ((uint64_t)(c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 2] & 0xff) << 40) + ((uint64_t)(c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 3] & 0xff) << 32)
			+ ((uint64_t)(c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 4] & 0xff) << 24) + ((uint64_t)(c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 5] & 0xff) << 16)
			+ ((uint64_t)(c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 6] & 0xff) << 8) + ((uint64_t)c[(LAMBDA / 4) + LWE_N + LWE_N + i * 8 + 7] & 0xff));
	}

	if ((hash[LAMBDA / 32] != c3[0]) || (hash[LAMBDA / 32 + 1] != c3[1]) || (hash[LAMBDA / 32 + 2] != c3[2]) || (hash[LAMBDA / 32 + 3] != c3[3])
		|| (hash[LAMBDA / 32 + 4] != c3[4]) || (hash[LAMBDA / 32 + 5] != c3[5]) || (hash[LAMBDA / 32 + 6] != c3[6]) || (hash[LAMBDA / 32 + 7] != c3[7])
		|| (hash[LAMBDA / 32 + 8] != c3[8]) || (hash[LAMBDA / 32 + 9] != c3[9]) || (hash[LAMBDA / 32 + 10] != c3[10]) || (hash[LAMBDA / 32 + 11] != c3[11])
		|| (hash[LAMBDA / 32 + 12] != c3[12]) || (hash[LAMBDA / 32 + 13] != c3[13]) || (hash[LAMBDA / 32 + 14] != c3[14]) || (hash[LAMBDA / 32 + 15] != c3[15]))
		return res = 1;
#endif
#ifdef RING_CATEGORY3_N1024
	for (i = 0; i < LWE_N / 64; ++i) {
		c3[i] = (((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8] & 0xff) << 56) + ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 1] & 0xff) << 48)
			+ ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 2] & 0xff) << 40) + ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 3] & 0xff) << 32)
			+ ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 4] & 0xff) << 24) + ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 5] & 0xff) << 16)
			+ ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 6] & 0xff) << 8) + ((uint64_t)c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 7] & 0xff));
	}

	if ((hash[LAMBDA / 32] != c3[0]) || (hash[LAMBDA / 32 + 1] != c3[1]) || (hash[LAMBDA / 32 + 2] != c3[2]) || (hash[LAMBDA / 32 + 3] != c3[3])
		|| (hash[LAMBDA / 32 + 4] != c3[4]) || (hash[LAMBDA / 32 + 5] != c3[5]) || (hash[LAMBDA / 32 + 6] != c3[6]) || (hash[LAMBDA / 32 + 7] != c3[7])
		|| (hash[LAMBDA / 32 + 8] != c3[8]) || (hash[LAMBDA / 32 + 9] != c3[9]) || (hash[LAMBDA / 32 + 10] != c3[10]) || (hash[LAMBDA / 32 + 11] != c3[11])
		|| (hash[LAMBDA / 32 + 12] != c3[12]) || (hash[LAMBDA / 32 + 13] != c3[13]) || (hash[LAMBDA / 32 + 14] != c3[14]) || (hash[LAMBDA / 32 + 15] != c3[15]))
		return res = 1;
#endif
#ifdef RING_CATEGORY3_N2048
	for (i = 0; i < LWE_N / 64; ++i) {
		c3[i] = (((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8] & 0xff) << 56) + ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 1] & 0xff) << 48)
			+ ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 2] & 0xff) << 40) + ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 3] & 0xff) << 32)
			+ ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 4] & 0xff) << 24) + ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 5] & 0xff) << 16)
			+ ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 6] & 0xff) << 8) + ((uint64_t)c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 7] & 0xff));
	}

	if ((hash[LAMBDA / 32] != c3[0]) || (hash[LAMBDA / 32 + 1] != c3[1]) || (hash[LAMBDA / 32 + 2] != c3[2]) || (hash[LAMBDA / 32 + 3] != c3[3])
		|| (hash[LAMBDA / 32 + 4] != c3[4]) || (hash[LAMBDA / 32 + 5] != c3[5]) || (hash[LAMBDA / 32 + 6] != c3[6]) || (hash[LAMBDA / 32 + 7] != c3[7])
		|| (hash[LAMBDA / 32 + 8] != c3[8]) || (hash[LAMBDA / 32 + 9] != c3[9]) || (hash[LAMBDA / 32 + 10] != c3[10]) || (hash[LAMBDA / 32 + 11] != c3[11])
		|| (hash[LAMBDA / 32 + 12] != c3[12]) || (hash[LAMBDA / 32 + 13] != c3[13]) || (hash[LAMBDA / 32 + 14] != c3[14]) || (hash[LAMBDA / 32 + 15] != c3[15])
		|| (hash[LAMBDA / 32 + 16] != c3[16]) || (hash[LAMBDA / 32 + 17] != c3[17]) || (hash[LAMBDA / 32 + 18] != c3[18]) || (hash[LAMBDA / 32 + 19] != c3[19])
		|| (hash[LAMBDA / 32 + 20] != c3[20]) || (hash[LAMBDA / 32 + 21] != c3[21]) || (hash[LAMBDA / 32 + 22] != c3[22]) || (hash[LAMBDA / 32 + 23] != c3[23])
		|| (hash[LAMBDA / 32 + 24] != c3[24]) || (hash[LAMBDA / 32 + 25] != c3[25]) || (hash[LAMBDA / 32 + 26] != c3[26]) || (hash[LAMBDA / 32 + 27] != c3[27])
		|| (hash[LAMBDA / 32 + 28] != c3[28]) || (hash[LAMBDA / 32 + 29] != c3[29]) || (hash[LAMBDA / 32 + 30] != c3[30]) || (hash[LAMBDA / 32 + 31] != c3[31]))
		return res = 1;
#endif
#ifdef RING_CATEGORY5
	for (i = 0; i < LWE_N / 64; ++i) {
		c3[i] = (((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8] & 0xff) << 56) + ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 1] & 0xff) << 48)
			+ ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 2] & 0xff) << 40) + ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 3] & 0xff) << 32)
			+ ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 4] & 0xff) << 24) + ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 5] & 0xff) << 16)
			+ ((uint64_t)(c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 6] & 0xff) << 8) + ((uint64_t)c[(LAMBDA / 4) + (LWE_N * 2) + (LWE_N * 2) + i * 8 + 7] & 0xff));
	}

	if ((hash[LAMBDA / 32] != c3[0]) || (hash[LAMBDA / 32 + 1] != c3[1]) || (hash[LAMBDA / 32 + 2] != c3[2]) || (hash[LAMBDA / 32 + 3] != c3[3])
		|| (hash[LAMBDA / 32 + 4] != c3[4]) || (hash[LAMBDA / 32 + 5] != c3[5]) || (hash[LAMBDA / 32 + 6] != c3[6]) || (hash[LAMBDA / 32 + 7] != c3[7])
		|| (hash[LAMBDA / 32 + 8] != c3[8]) || (hash[LAMBDA / 32 + 9] != c3[9]) || (hash[LAMBDA / 32 + 10] != c3[10]) || (hash[LAMBDA / 32 + 11] != c3[11])
		|| (hash[LAMBDA / 32 + 12] != c3[12]) || (hash[LAMBDA / 32 + 13] != c3[13]) || (hash[LAMBDA / 32 + 14] != c3[14]) || (hash[LAMBDA / 32 + 15] != c3[15])
		|| (hash[LAMBDA / 32 + 16] != c3[16]) || (hash[LAMBDA / 32 + 17] != c3[17]) || (hash[LAMBDA / 32 + 18] != c3[18]) || (hash[LAMBDA / 32 + 19] != c3[19])
		|| (hash[LAMBDA / 32 + 20] != c3[20]) || (hash[LAMBDA / 32 + 21] != c3[21]) || (hash[LAMBDA / 32 + 22] != c3[22]) || (hash[LAMBDA / 32 + 23] != c3[23])
		|| (hash[LAMBDA / 32 + 24] != c3[24]) || (hash[LAMBDA / 32 + 25] != c3[25]) || (hash[LAMBDA / 32 + 26] != c3[26]) || (hash[LAMBDA / 32 + 27] != c3[27])
		|| (hash[LAMBDA / 32 + 28] != c3[28]) || (hash[LAMBDA / 32 + 29] != c3[29]) || (hash[LAMBDA / 32 + 30] != c3[30]) || (hash[LAMBDA / 32 + 31] != c3[31]))
		return res = 1;
#endif
	
	// Set r = H(delta)
	hash = (uint64_t *)calloc(LWE_N / 64, sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = LWE_N;
	TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_N, S, strlen(S) * 8);

#if defined(RING_CATEGORY1) || defined(RING_CATEGORY3_N1024) 
	i = 0;
	do {
		j = (uint16_t)hash[i] & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 10) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 12) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 22) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 24) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 34) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 36) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 46) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 48) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 58) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		i++;
		if (i == LWE_N / 64) {
			i = 0;
			tuple.input = (unsigned char*)hash;
			tuple.inputBitLen = LWE_N;
			TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_N, S, strlen(S) * 8);
		}
	} while (hw < HR);
#endif
#if defined(RING_CATEGORY3_N2048) || defined(RING_CATEGORY5)
	i = 0;
	do {
		j = (uint16_t)hash[i] & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 11) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 13) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 24) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 26) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 37) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		j = (uint16_t)(hash[i] >> 39) & (LWE_N - 1);
		if (r[j] == 0) {
			r[j] = ((uint16_t)(hash[i] >> 50) & 0x02) - 1;
			hw++;
			if (hw == HR)
				break;
		}
		i++;
		if (i == LWE_N / 64) {
			i = 0;
			tuple.input = (unsigned char*)hash;
			tuple.inputBitLen = LWE_N;
			TupleHash256(&tuple, 1, (unsigned char*)hash, LWE_N, S, strlen(S) * 8);
		}
	} while (hw < HR);
#endif
	
	// Initialize c2h_b' as q/2 * delta
	for (i = 0; i < LWE_N; ++i) { c2h_b[i] = decomp_delta[i] << _16_LOG_T; }

	// Compute a * r and b * r, and then add to c2h_a' and c2h_b', respectively.
	for (i = 0; i < LWE_N; ++i) {
		for (j = 0; j < LWE_N; ++j) {
			uint16_t tmp = i + j < LWE_N ? 1 : -1;
			c2h_a[(i + j) % LWE_N] += tmp * ((sk[CRYPTO_SECRETKEYBYTES + j * 2] << 8 | sk[CRYPTO_SECRETKEYBYTES + j * 2 + 1]) * (char)r[i]);
			c2h_b[(i + j) % LWE_N] += tmp * ((sk[CRYPTO_SECRETKEYBYTES + PublicKey_A + j * 2] << 8 | sk[CRYPTO_SECRETKEYBYTES + PublicKey_A + j * 2 + 1]) * (char)r[i]);
		}
	}

	// Send c2h_a' and c2h_b' from mod q to mod p
	for (i = 0; i < LWE_N; ++i) { 
		c2h_a[i] = (c2h_a[i] + RD_ADD) & RD_AND;
		c2h_b[i] = (c2h_b[i] + RD_ADD) & RD_AND; 
	}
	
	// If (c2h_a, c2h_b) ≠ (c2h_a', c2h_b'), then terminate
#ifdef RING_CATEGORY1
	for (i = 0; i < LWE_N; ++i) {
		if (c2h_a[i] >> 8 != (c[(LAMBDA / 4) + i] & 0xff)) {
			res = 2;
			break;
		}
		if (c2h_b[i] >> 8 != (c[(LAMBDA / 4) + LWE_N + i] & 0xff)) {
			res = 2;
			break;
		}
	}
#endif
#if defined(RING_CATEGORY3_N1024) || defined(RING_CATEGORY3_N2048) || defined(RING_CATEGORY5)
	for (i = 0; i < LWE_N; ++i) {
		if (c2h_a[i] != ((c[(LAMBDA / 4) + i * 2] & 0xff) << 8 | c[(LAMBDA / 4) + i * 2 + 1] & 0xff)) {
			res = 2;
			break;
		}
		if (c2h_b[i] != ((c[(LAMBDA / 4) + (LWE_N * 2) + i * 2] & 0xff) << 8 | c[(LAMBDA / 4) + (LWE_N * 2) + i * 2 + 1] & 0xff)) {
			res = 2;
			break;
		}
	}
#endif

	// Compute the hash values G(delta)
	hash = (uint64_t *)calloc((LAMBDA / 32) + (LWE_N / 64), sizeof(uint64_t));
	tuple.input = (unsigned char*)delta;
	tuple.inputBitLen = LWE_N;
	TupleHash256(&tuple, 1, (unsigned char*)hash, ((LAMBDA / 32) + (LWE_N / 64)) * 8 * 8, S, strlen(S) * 8);
	
	// m = c1 xor G(delta)
	for (i = 0; i < LAMBDA / 32; ++i) {
		c1[i] = ((uint64_t)c[i * 8] & 0xff) << 56;
		c1[i] += ((uint64_t)c[i * 8 + 1] & 0xff) << 48;
		c1[i] += ((uint64_t)c[i * 8 + 2] & 0xff) << 40;
		c1[i] += ((uint64_t)c[i * 8 + 3] & 0xff) << 32;
		c1[i] += ((uint64_t)c[i * 8 + 4] & 0xff) << 24;
		c1[i] += ((uint64_t)c[i * 8 + 5] & 0xff) << 16;
		c1[i] += ((uint64_t)c[i * 8 + 6] & 0xff) << 8;
		c1[i] += ((uint64_t)c[i * 8 + 7] & 0xff);
	}
	for (i = 0; i < LAMBDA / 32; ++i) {
		m[i * 8] = (unsigned char)((c1[i] ^ hash[i]) >> 56);
		m[i * 8 + 1] = (unsigned char)((c1[i] ^ hash[i]) >> 48);
		m[i * 8 + 2] = (unsigned char)((c1[i] ^ hash[i]) >> 40);
		m[i * 8 + 3] = (unsigned char)((c1[i] ^ hash[i]) >> 32);
		m[i * 8 + 4] = (unsigned char)((c1[i] ^ hash[i]) >> 24);
		m[i * 8 + 5] = (unsigned char)((c1[i] ^ hash[i]) >> 16);
		m[i * 8 + 6] = (unsigned char)((c1[i] ^ hash[i]) >> 8);
		m[i * 8 + 7] = (unsigned char)((c1[i] ^ hash[i]));
	}
	
	*mlen = sizeof(c1);
	
	free(hash);

	finish = clock();
	elapsed2 += (finish - start);

	return res;
}
