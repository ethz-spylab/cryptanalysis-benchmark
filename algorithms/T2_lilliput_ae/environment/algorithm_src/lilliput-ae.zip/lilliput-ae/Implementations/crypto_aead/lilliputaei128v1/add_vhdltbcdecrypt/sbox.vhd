-- Implementation of the Lilliput-TBC tweakable block cipher by the
-- Lilliput-AE team, hereby denoted as "the implementer".
--
-- For more information, feedback or questions, refer to our website:
-- https://paclido.fr/lilliput-ae
--
-- To the extent possible under law, the implementer has waived all copyright
-- and related or neighboring rights to the source code in this file.
-- http://creativecommons.org/publicdomain/zero/1.0/

library IEEE;
library work;
use IEEE.std_logic_1164.all;
use work.crypt_pack.all;

entity sbox is
  port(
    sbox_i  : in  bit8;
    sbox_o : out bit8
    );
end sbox;



architecture sbox_arch of sbox is

component inner_sbox_a
	port (
    sbox_i  : in  std_logic_vector(3 downto 0);
    sbox_o 	: out std_logic_vector(3 downto 0)
	);
end component;

component inner_sbox_b
	port (
    sbox_i  : in  std_logic_vector(3 downto 0);
    sbox_o 	: out std_logic_vector(3 downto 0)
	);
end component;

component inner_sbox_c
	port (
    sbox_i  : in  std_logic_vector(3 downto 0);
    sbox_o 	: out std_logic_vector(3 downto 0)
	);
end component;

signal a,a1,b,b1,c : std_logic_vector(3 downto 0);

begin

inner_sbox_a_t : inner_sbox_a
port map( 
    sbox_i => sbox_i(3 downto 0),
    sbox_o =>  a
);

a1 <= a xor sbox_i(7 downto 4);

inner_sbox_b_t : inner_sbox_b
port map( 
    sbox_i => a1,
    sbox_o => b
);

b1 <= b xor sbox_i(3 downto 0);

inner_sbox_c_t : inner_sbox_c
port map( 
    sbox_i => b1,
    sbox_o => c
);
          
sbox_o(7 downto 4) <= c xor a1;
sbox_o (3 downto 0) <= b1;
			 
end sbox_arch;

configuration sbox_conf of sbox is 
	for sbox_arch
		for  inner_sbox_a_t : inner_sbox_a
			use entity work.inner_sbox_a( inner_sbox_a_arch );
		end for;
		for  inner_sbox_b_t : inner_sbox_b
			use entity work.inner_sbox_b( inner_sbox_b_arch );
		end for;
		for  inner_sbox_c_t : inner_sbox_c
			use entity work.inner_sbox_c( inner_sbox_c_arch );
		end for;
	end for;
end configuration sbox_conf ;

