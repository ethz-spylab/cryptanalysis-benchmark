-- Implementation of the Lilliput-TBC tweakable block cipher by the
-- Lilliput-AE team, hereby denoted as "the implementer".
--
-- For more information, feedback or questions, refer to our website:
-- https://paclido.fr/lilliput-ae
--
-- To the extent possible under law, the implementer has waived all copyright
-- and related or neighboring rights to the source code in this file.
-- http://creativecommons.org/publicdomain/zero/1.0/

library IEEE;
library work;
use IEEE.STD_LOGIC_1164.ALL;


package const_pack is
    constant ROUND_NB : integer;
    constant TWEAK_LEN : integer;
    constant KEY_LEN : integer;
end const_pack;


package body const_pack is 
    constant ROUND_NB : integer := 42; 
    constant TWEAK_LEN : integer := 192;
    constant KEY_LEN : integer := 256;
end const_pack;   