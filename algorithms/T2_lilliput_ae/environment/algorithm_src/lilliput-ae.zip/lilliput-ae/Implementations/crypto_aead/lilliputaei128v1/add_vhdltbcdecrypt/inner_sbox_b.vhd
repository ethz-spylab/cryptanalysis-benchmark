-- Implementation of the Lilliput-TBC tweakable block cipher by the
-- Lilliput-AE team, hereby denoted as "the implementer".
--
-- For more information, feedback or questions, refer to our website:
-- https://paclido.fr/lilliput-ae
--
-- To the extent possible under law, the implementer has waived all copyright
-- and related or neighboring rights to the source code in this file.
-- http://creativecommons.org/publicdomain/zero/1.0/

library IEEE;
library work;
use IEEE.std_logic_1164.all;

entity inner_sbox_b is
  port(
    sbox_i  : in  std_logic_vector(3 downto 0);
    sbox_o : out std_logic_vector(3 downto 0)
    );
end inner_sbox_b;


architecture inner_sbox_b_arch of inner_sbox_b is

signal a,b,c,d,x,y,z,t 	:std_logic;
signal c1,d1				:std_logic;

begin

a <= sbox_i(3);
b <= sbox_i(2);
c <= sbox_i(1);
d <= sbox_i(0);


c1 <= c xor (a and d);
d1 <= b xor (d and c);


x <= d xor (a and d1);
y <= d1;
z <= a xor (c1 and d1);
t <= c1;

sbox_o(3) <= x;
sbox_o(2) <= y;
sbox_o(1) <= z;
sbox_o(0) <= t;
                              
end;

