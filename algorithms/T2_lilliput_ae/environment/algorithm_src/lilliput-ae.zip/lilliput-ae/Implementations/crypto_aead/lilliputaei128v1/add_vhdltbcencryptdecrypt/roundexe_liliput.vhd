-- Implementation of the Lilliput-TBC tweakable block cipher by the
-- Lilliput-AE team, hereby denoted as "the implementer".
--
-- For more information, feedback or questions, refer to our website:
-- https://paclido.fr/lilliput-ae
--
-- To the extent possible under law, the implementer has waived all copyright
-- and related or neighboring rights to the source code in this file.
-- http://creativecommons.org/publicdomain/zero/1.0/

library IEEE;
library work;
use IEEE.numeric_std.ALL;
use IEEE.STD_LOGIC_1164.ALL;
use work.crypt_pack.ALL;

entity roundexe_liliput is port (
    clock_i          : in std_logic;
    reset_i          : in std_logic;
    data_i           : in bit_data; --donn�e d'entr�e lors du premier Round
    keyb_i           : in bit_key;
    tweak_i          : in bit_tweak;
	 invert_i		 : in std_logic;
    round_number_i   : in std_logic_vector(7 downto 0);
    permut_valid_i   : in std_logic; --permet de savoir si on fait la permutation � la fin 
    muxsel_i         : in std_logic; --En lien avec data_i permet la selection des donn�es d'entr�e au cours d'un Round
    data_out_valid_i : in std_logic;
    decrypt_i 		 : in std_logic;
	 data_o          : out bit_data
    );
end roundexe_liliput;

architecture roundexe_liliput_arch of roundexe_liliput is

component key_schedule_liliput port (
    key_i           	: in type_tweak_key_array;
    round_number    	: in std_logic_vector(7 downto 0);
	 invert_i			: in std_logic;
    key_o           	: out type_tweak_key_array;
    round_key_o     	: out type_key
    );
end component;

component state_key_register port(
    state_key_i : in type_tweak_key_array; -- Etat d'entr�e
    state_key_o : out type_tweak_key_array; -- Etat de sortie 
    clock_i     : in std_logic; -- Permet de g�rer la clock 
    reset_i     : in std_logic
    );
end component;

component chiffrement port(
    chiffrement_i   	: in type_state;
    permutation_i   	: in std_logic;
    round_key_i     	: in  type_key;
    chiffrement_o   	: out type_state;
    data_out_valid_i	: in std_logic;
	 decrypt_i 		   	: in std_logic;
    data_o          	: out bit_data
    );
end component;

component state_register port(
    state_i : in type_state; -- Etat d'entr�e
    state_o : out type_state; -- Etatde sortie 
    clock_i : in std_logic; -- Permet de g�rer la clock 
    reset_i : in std_logic
    );
end component;

signal data_i_s         : type_state; 
signal chiffrement_o_s  : type_state;
signal mux_1_s          : type_state; --Pour prendre en compte data_i ou le retour de state_register
signal mux_2_s          : type_tweak_key_array; --R�cup�ration de la clef pour le round 0
signal state_o_s        : type_state;
signal state_tk_o_s     : type_tweak_key_array;
signal round_key_s      : type_key;
signal tweak_key_i      : bit_tweak_key := (others=>'0');
signal tk_s             : type_tweak_key_array;
signal tk_o_s           : type_tweak_key_array;


begin

convertion_ligne : for i in 0 to 3 generate
	convertion_colonne : for j in 0 to 3 generate 
		 data_i_s(i)(j) <= data_i((7+(8*(4*i+j)))downto((8*(4*i+j))));
	end generate;
end generate;

--Tweak_key concatenation
tweak_key_i (TWEAK_KEY_LEN downto 0)<= keyb_i & tweak_i;

--formatting tweak_key in type_tweak_key_array
convertion_ligne_key : for i in 0 to LANE_NB-1 generate
	convertion_colonne_key : for j in 0 to 7 generate 
		 tk_s(i)(j) <= tweak_key_i(((64*i)+(8*j)+7)downto((64*i)+(8*j)));
	end generate;
end generate;

--Avantage on utilise le m�me mux donc pas de changement dans la machine d'�tat
mux_1_s <= data_i_s	when muxsel_i = '1'
				else state_o_s;
    
mux_2_s <= tk_s 				when muxsel_i = '1' and invert_i = '0' else 
			  state_tk_o_s;

key_schedule_t : key_schedule_liliput port map(
    key_i     		=> mux_2_s,
    round_number  	=> round_number_i,
	 invert_i   	=> invert_i,
    key_o         	=> tk_o_s,
    round_key_o  	=> round_key_s);
       
state_tk_register_t : state_key_register port map(
    state_key_i 	=> tk_o_s,
    state_key_o 	=> state_tk_o_s,	 
    clock_i 		=> clock_i,
    reset_i 		=> reset_i);    

chiffrement_t : chiffrement port map(
    chiffrement_i 		=> mux_1_s, 
    permutation_i 		=> permut_valid_i,
    round_key_i 		=> round_key_s,
    chiffrement_o 		=> chiffrement_o_s,
    data_out_valid_i 	=> data_out_valid_i,
	 decrypt_i 			=> decrypt_i,
    data_o 				=> data_o);

state_register_t : state_register port map(
    state_i => chiffrement_o_s,
    state_o => state_o_s,     
    clock_i => clock_i,
    reset_i => reset_i);
    
    
end roundexe_liliput_arch;

configuration roundexe_liliput_conf of roundexe_liliput is 
    for roundexe_liliput_arch
        for key_schedule_t : key_schedule_liliput
            use entity work.key_schedule_liliput(key_schedule_liliputr_arch);
        end for;  
        for state_tk_register_t : state_key_register
            use entity work.state_key_register(state_key_register_arch);
        end for;		  
        for chiffrement_t : chiffrement
            use entity work.chiffrement(chiffrement_arch);
        end for;
        for state_register_t : state_register
            use entity work.state_register(state_register_arch);
        end for;
    end for;
end configuration roundexe_liliput_conf;