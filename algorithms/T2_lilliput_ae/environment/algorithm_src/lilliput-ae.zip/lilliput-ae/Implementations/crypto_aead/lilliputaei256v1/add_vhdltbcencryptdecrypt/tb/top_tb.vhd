-- Implementation of the Lilliput-TBC tweakable block cipher by the
-- Lilliput-AE team, hereby denoted as "the implementer".
--
-- For more information, feedback or questions, refer to our website:
-- https://paclido.fr/lilliput-ae
--
-- To the extent possible under law, the implementer has waived all copyright
-- and related or neighboring rights to the source code in this file.
-- http://creativecommons.org/publicdomain/zero/1.0/

library IEEE;
library work;
use IEEE.numeric_std.all;
use IEEE.std_logic_1164.all;
use work.crypt_pack.all;


entity top_tb is
end top_tb;

architecture top_tb_arch of top_tb is

component top is port (
    start_i : in std_logic;
    clock_i : in std_logic;
    reset_i : in std_logic; 
    data_i : in bit128;
    key_i : in bit_key;
    data_o : out bit128;
    tweak_i : in bit_tweak;
	 decrypt_i : in std_logic;
    liliput_on_out : out std_logic
    );
end component;

signal start_i_s, clock_i_s, reset_i_s : std_logic := '0';
signal data_i_s 		: bit128;
signal key_i_s 		: bit_key;
signal tweak_i_s 		: bit_tweak;
signal data_o_s 		: bit128;
signal liliput_on_o_s: std_logic;
signal decrypt_s		: std_logic;
begin
DUT : top
port map( 
    start_i 		=> start_i_s,
    clock_i 		=> clock_i_s,
    reset_i 		=> reset_i_s,
    data_i 			=> data_i_s,
    key_i 			=> key_i_s,
    tweak_i 		=> tweak_i_s,
    data_o 			=> data_o_s,
	 decrypt_i 		=> decrypt_s,
    liliput_on_out=> liliput_on_o_s
);

clock_i_s <= not(clock_i_s) after 100 ns;
start_i_s <= '1';
reset_i_s <= '0' , '1' after 100 ns;
--------- ENCRYPT--------------------
-----------KEY128 TWEAK128----------
--decrypt_s <= '0';
--data_i_s <= X"0F0E0D0C0B0A09080706050403020100";
--key_i_s <= X"0F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"0F0E0D0C0B0A09080706050403020100";
-----RESULT X"ddb2ef63ab68a803679590e8c85888ca";

-----------KEY128 TWEAK192----------
--decrypt_s <= '0';
--data_i_s <= X"0F0E0D0C0B0A09080706050403020100";
--key_i_s <= X"0F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"17161514131211100F0E0D0C0B0A09080706050403020100";
----RESULT X"e5ce0026af060b52c2ceb2e610a2958d"; 

-----------KEY192 TWEAK128----------
--decrypt_s <= '0';
--data_i_s <= X"0F0E0D0C0B0A09080706050403020100";
--key_i_s <= X"17161514131211100F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"0F0E0D0C0B0A09080706050403020100";
----RESULT X"31a0db08b76a1f7c646cbe506860b103";

-----------KEY192 TWEAK192----------
--decrypt_s <= '0';
--data_i_s <= X"0F0E0D0C0B0A09080706050403020100";
--key_i_s <= X"17161514131211100F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"17161514131211100F0E0D0C0B0A09080706050403020100";
----RESULT X"75f7fe11677769882102d57daac1464d";

-----------KEY256 TWEAK128----------
--decrypt_s <= '0';
--data_i_s <= X"0F0E0D0C0B0A09080706050403020100";
--key_i_s <= X"1f1e1d1c1b1a191817161514131211100F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"0F0E0D0C0B0A09080706050403020100";
----RESULT X"4ecbf0236fbf05cefff41d9900efab8a";

-----------KEY256 TWEAK192----------
decrypt_s <= '0';
data_i_s <= X"0F0E0D0C0B0A09080706050403020100";
key_i_s <= X"1f1e1d1c1b1a191817161514131211100F0E0D0C0B0A09080706050403020100";
tweak_i_s <= X"17161514131211100F0E0D0C0B0A09080706050403020100";
----RESULT X"3084f49f1927b4c090f9612718ff35d3";

-----------DECRYPT---------------
-----------KEY128 TWEAK128----------
--decrypt_s <= '1';
--data_i_s <= X"ddb2ef63ab68a803679590e8c85888ca";
--key_i_s <= X"0F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"0F0E0D0C0B0A09080706050403020100";
----RESULT X"0F0E0D0C0B0A09080706050403020100";

-------------KEY128 TWEAK192----------
--decrypt_s <= '1';
--data_i_s <= X"e5ce0026af060b52c2ceb2e610a2958d";
--key_i_s <= X"0F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"17161514131211100F0E0D0C0B0A09080706050403020100";
----RESULT X"0F0E0D0C0B0A09080706050403020100"; 

-----------KEY192 TWEAK128----------
--decrypt_s <= '1';
--data_i_s <= X"31a0db08b76a1f7c646cbe506860b103";
--key_i_s <= X"17161514131211100F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"0F0E0D0C0B0A09080706050403020100";
----RESULT X"0F0E0D0C0B0A09080706050403020100";

-----------KEY192 TWEAK192----------
--decrypt_s <= '1';
--data_i_s <= X"75f7fe11677769882102d57daac1464d";
--key_i_s <= X"17161514131211100F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"17161514131211100F0E0D0C0B0A09080706050403020100";
----RESULT X"0F0E0D0C0B0A09080706050403020100";

-----------KEY256 TWEAK128----------
--decrypt_s <= '1';
--data_i_s <= X"4ecbf0236fbf05cefff41d9900efab8a";
--key_i_s <= X"1f1e1d1c1b1a191817161514131211100F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"0F0E0D0C0B0A09080706050403020100";
----RESULT X"0F0E0D0C0B0A09080706050403020100";

-----------KEY256 TWEAK192----------
--decrypt_s <= '1';
--data_i_s <= X"3084f49f1927b4c090f9612718ff35d3";
--key_i_s <= X"1f1e1d1c1b1a191817161514131211100F0E0D0C0B0A09080706050403020100";
--tweak_i_s <= X"17161514131211100F0E0D0C0B0A09080706050403020100";
----RESULT X"0F0E0D0C0B0A09080706050403020100";


end top_tb_arch;

configuration top_tb_conf of top_tb is
	for top_tb_arch
		for DUT : top
			use entity work.top(top_arch);
		end for;
	end for;
end configuration top_tb_conf;
