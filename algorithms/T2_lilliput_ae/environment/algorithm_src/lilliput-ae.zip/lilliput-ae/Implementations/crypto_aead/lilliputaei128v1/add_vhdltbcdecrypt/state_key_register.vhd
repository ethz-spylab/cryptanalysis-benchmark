-- Implementation of the Lilliput-TBC tweakable block cipher by the
-- Lilliput-AE team, hereby denoted as "the implementer".
--
-- For more information, feedback or questions, refer to our website:
-- https://paclido.fr/lilliput-ae
--
-- To the extent possible under law, the implementer has waived all copyright
-- and related or neighboring rights to the source code in this file.
-- http://creativecommons.org/publicdomain/zero/1.0/

library IEEE;
library work;
use IEEE.numeric_std.ALL;
use IEEE.STD_LOGIC_1164.ALL;
use work.crypt_pack.ALL;

entity state_key_register is
	port(
		state_key_i : in type_tweak_key_array; -- Etat d'entr�e
		state_key_o : out type_tweak_key_array; -- Etat de sortie 
		clock_i : in std_logic; -- Permet de g�rer la clock 
		reset_i : in std_logic);
end state_key_register;

architecture state_key_register_arch of state_key_register is
begin 
	process(reset_i, clock_i) -- On d�finit ici un process car les fonctions ne doivent pas se faire en m�me temps 
	begin 
		if(reset_i = '0') then 
				state_key_o <= (others => (others => (others => '0'))); --si rest_i est nul c'est que les valeurs de state_o sont nuls 
    		elsif(clock_i'event and clock_i = '1') then -- Dans le cas d'un front descendant d'horloge state_o prend la valeur de state_i. On utilise un front descendant d'horloge pour un soucis de synchronisation avec sbox
    			state_key_o <= state_key_i;
    		end if;
    	end process;
    	
    end state_key_register_arch;
