#ifndef API_H
#define API_H
#include "cca_encrypt.h"

#define CRYPTO_ALGNAME         "uround2_pke_n1_fn0_l5"
#define CRYPTO_SECRETKEYBYTES  11755
#define CRYPTO_PUBLICKEYBYTES  10053
#define CRYPTO_BYTES           10128
#endif
