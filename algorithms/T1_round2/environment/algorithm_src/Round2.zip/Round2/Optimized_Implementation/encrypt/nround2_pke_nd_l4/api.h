#ifndef API_H
#define API_H
#include "cca_encrypt.h"

#define CRYPTO_ALGNAME         "nround2_pke_nd_l4"
#define CRYPTO_SECRETKEYBYTES  1071
#define CRYPTO_PUBLICKEYBYTES  846
#define CRYPTO_BYTES           1113
#endif
