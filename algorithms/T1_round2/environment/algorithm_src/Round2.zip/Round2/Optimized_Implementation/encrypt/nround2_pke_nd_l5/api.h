#ifndef API_H
#define API_H
#include "cca_encrypt.h"

#define CRYPTO_ALGNAME         "nround2_pke_nd_l5"
#define CRYPTO_SECRETKEYBYTES  1039
#define CRYPTO_PUBLICKEYBYTES  830
#define CRYPTO_BYTES           1017
#endif
