#ifndef API_H
#define API_H
#include "cca_encrypt.h"

#define CRYPTO_ALGNAME         "uround2_pke_n1_fn1_l2"
#define CRYPTO_SECRETKEYBYTES  7670
#define CRYPTO_PUBLICKEYBYTES  6468
#define CRYPTO_BYTES           6567
#endif
