#ifndef API_H
#define API_H
#include "cca_encrypt.h"

#define CRYPTO_ALGNAME         "nround2_pke_nd_l1"
#define CRYPTO_SECRETKEYBYTES  642
#define CRYPTO_PUBLICKEYBYTES  515
#define CRYPTO_BYTES           622
#endif
