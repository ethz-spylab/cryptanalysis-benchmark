#ifndef API_H
#define API_H
#include "cca_encrypt.h"

#define CRYPTO_ALGNAME         "nround2_pke_nd_l3"
#define CRYPTO_SECRETKEYBYTES  841
#define CRYPTO_PUBLICKEYBYTES  673
#define CRYPTO_BYTES           820
#endif
