#ifndef API_H
#define API_H
#include "cca_encrypt.h"

#define CRYPTO_ALGNAME         "uround2_pke_n1_fn1_l3"
#define CRYPTO_SECRETKEYBYTES  6319
#define CRYPTO_PUBLICKEYBYTES  5330
#define CRYPTO_BYTES           7185
#endif
