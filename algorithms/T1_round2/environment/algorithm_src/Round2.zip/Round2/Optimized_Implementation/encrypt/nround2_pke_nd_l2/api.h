#ifndef API_H
#define API_H
#include "cca_encrypt.h"

#define CRYPTO_ALGNAME         "nround2_pke_nd_l2"
#define CRYPTO_SECRETKEYBYTES  830
#define CRYPTO_PUBLICKEYBYTES  659
#define CRYPTO_BYTES           846
#endif
