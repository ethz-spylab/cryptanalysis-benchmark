#ifndef API_H
#define API_H
#include "cca_encrypt.h"

#define CRYPTO_ALGNAME         "uround2_pke_n1_fn0_l1"
#define CRYPTO_SECRETKEYBYTES  4096
#define CRYPTO_PUBLICKEYBYTES  3455
#define CRYPTO_BYTES           4881
#endif
