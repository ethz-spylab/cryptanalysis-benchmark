#ifndef API_H
#define API_H
#include "cca_encrypt.h"

#define CRYPTO_ALGNAME         "uround2_pke_n1_fn0_l4"
#define CRYPTO_SECRETKEYBYTES  14710
#define CRYPTO_PUBLICKEYBYTES  12574
#define CRYPTO_BYTES           12673
#endif
