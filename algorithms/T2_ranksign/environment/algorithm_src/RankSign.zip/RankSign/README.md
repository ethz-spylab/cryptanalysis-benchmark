+=============================================================================+
|                                                                             |
|               ***********************************************               |
|               *     POST-QUANTUM CRYPTO STANDARDIZATION     *               |
|               ***********************************************               |
|                                                                             |
|=============================================================================|
|                                                                             |
|        Proposal: RankSign                                                   |
|        Principal Submitters (alphabetical order):                           |
|                  - Nicolas ARAGON                                           |
| [main contact]   - Philippe GABORIT                                         |
| [backup contact] - Adrien HAUTEVILLE                                        |
|                  - Olivier RUATTA                                           |
|                  - Gilles ZÉMOR                                             |
|                                                                             |
|        Inventors: Same as submitters                                        |
|                                                                             |
|        Developers: Same as submitters                                       |
|                                                                             |
|        Owners: Same as submitters                                           |
|                                                                             |
+=============================================================================+

This archive is a proposal in response to NIST's call for proposal for standar-
dization of quantum-resistant public-key cryptographic algorithms.

RankSign provides POST-QUANTUM CODE-BASED SIGNATURE and targets NIST
security levels 1, 3, and 5.

This archive is organized as follows:

===============================================================================

.
├── KATs
│   ├── Optimized_Implementation
│   │   ├── RankSign-I
│   │   │   ├── PQCsignKAT_23864.req : Request KAT file for RankSignI
│   │   │   ├── PQCsignKAT_23864.rsp : Response KAT file for RankSignI
│   │   │   └── ranksignI-verbose.txt : Verbose output for RankSignI
│   │   ├── RankSign-II
│   │   │   ├── PQCsignKAT_28092.req : Request KAT file for RankSignII
│   │   │   ├── PQCsignKAT_28092.rsp : Response KAT file for RankSignII
│   │   │   └── ranksignII-verbose.txt : Verbose output for RankSignII
│   │   ├── RankSign-III
│   │   │   ├── PQCsignKAT_44316.req : Request KAT file for RankSignIII
│   │   │   ├── PQCsignKAT_44316.rsp : Response KAT file for RankSignIII
│   │   │   └── ranksignIII-verbose.txt : Verbose output for RankSignIII
│   │   └── Ranksign-IV
│   │       ├── PQCsignKAT_64340.req : Request KAT file for RankSignIV
│   │       ├── PQCsignKAT_64340.rsp : Response KAT file for RankSignIV
│   │       └── ranksignIV-verbose.txt : Verbose output for RankSignIV
│   └── Reference_Implementation
│       ├── RankSign-I
│       │   ├── PQCsignKAT_23864.req : Request KAT file for RankSignI
│       │   ├── PQCsignKAT_23864.rsp : Response KAT file for RankSignI
│       │   └── ranksignI-verbose.txt : Verbose output for RankSignI
│       ├── RankSign-II
│       │   ├── PQCsignKAT_28092.req : Request KAT file for RankSignII
│       │   ├── PQCsignKAT_28092.rsp : Response KAT file for RankSignII
│       │   └── ranksignII-verbose.txt : Verbose output for RankSignII
│       ├── RankSign-III
│       │   ├── PQCsignKAT_44316.req : Request KAT file for RankSignIII
│       │   ├── PQCsignKAT_44316.rsp : Response KAT file for RankSignIII
│       │   └── ranksignIII-verbose.txt : Verbose output for RankSignIII
│       └── Ranksign-IV
│           ├── PQCsignKAT_64340.req : Request KAT file for RankSignIV
│           ├── PQCsignKAT_64340.rsp : Response KAT file for RankSignIV
│           └── ranksignIV-verbose.txt : Verbose output for RankSignIV
├── Optimized_Implementation
│   ├── RankSign-I
│   │   ├── configure : configure file to build MPFQ
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash : SHA512
│   │   │   ├── mpfq : MPFQ library
│   │   │   └── rng : NIST randomness
│   │   ├── Makefile : Makefile to compile our code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── ffi : Finite field implementation
│   │       ├── main_kat.c : NIST KAT file
│   │       ├── main_ranksign.c : Main for normal and verbose modes
│   │       ├── parameters.h : Parameters for the scheme
│   │       ├── parsing.c : Implementation of parsing.h
│   │       ├── parsing.h : Functions to parse Ranksign types to/from string
│   │       ├── ranksign.c : Implementation of api.h
│   │       ├── VS.c : Implementation of VS.h
│   │       └── VS.h : Vector spaces over GF(q^m)
│   ├── RankSign-II
│   │   ├── configure : configure file to build MPFQ
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash : SHA512
│   │   │   ├── mpfq : MPFQ library
│   │   │   └── rng : NIST randomness
│   │   ├── Makefile : Makefile to compile our code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── ffi : Finite field implementation
│   │       ├── main_kat.c : NIST KAT file
│   │       ├── main_ranksign.c : Main for normal and verbose modes
│   │       ├── parameters.h : Parameters for the scheme
│   │       ├── parsing.c : Implementation of parsing.h
│   │       ├── parsing.h : Functions to parse Ranksign types to/from string
│   │       ├── ranksign.c : Implementation of api.h
│   │       ├── VS.c : Implementation of VS.h
│   │       └── VS.h : Vector spaces over GF(q^m)
│   ├── RankSign-III
│   │   ├── configure : configure file to build MPFQ
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash : SHA512
│   │   │   ├── mpfq : MPFQ library
│   │   │   └── rng : NIST randomness
│   │   ├── Makefile : Makefile to compile our code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── ffi : Finite field implementation
│   │       ├── main_kat.c : NIST KAT file
│   │       ├── main_ranksign.c : Main for normal and verbose modes
│   │       ├── parameters.h : Parameters for the scheme
│   │       ├── parsing.c : Implementation of parsing.h
│   │       ├── parsing.h : Functions to parse Ranksign types to/from string
│   │       ├── ranksign.c : Implementation of api.h
│   │       ├── VS.c : Implementation of VS.h
│   │       └── VS.h : Vector spaces over GF(q^m)
│   ├── RankSign-IV
│   │   ├── configure : configure file to build MPFQ
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash : SHA512
│   │   │   ├── mpfq : MPFQ library
│   │   │   └── rng : NIST randomness
│   │   ├── Makefile : Makefile to compile our code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── ffi : Finite field implementation
│   │       ├── main_kat.c : NIST KAT file
│   │       ├── main_ranksign.c : Main for normal and verbose modes
│   │       ├── parameters.h : Parameters for the scheme
│   │       ├── parsing.c : Implementation of parsing.h
│   │       ├── parsing.h : Functions to parse Ranksign types to/from string
│   │       ├── ranksign.c : Implementation of api.h
│   │       ├── VS.c : Implementation of VS.h
│   │       └── VS.h : Vector spaces over GF(q^m)
│   └── README.md : Implementation README
├── README.md : This file
├── Reference_Implementation
│   ├── RankSign-I
│   │   ├── configure : configure file to build MPFQ
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash : SHA512
│   │   │   ├── mpfq : MPFQ library
│   │   │   └── rng : NIST randomness
│   │   ├── Makefile : Makefile to compile our code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── ffi : Finite field implementation
│   │       ├── main_kat.c : NIST KAT file
│   │       ├── main_ranksign.c : Main for normal and verbose modes
│   │       ├── parameters.h : Parameters for the scheme
│   │       ├── parsing.c : Implementation of parsing.h
│   │       ├── parsing.h : Functions to parse Ranksign types to/from string
│   │       ├── ranksign.c : Implementation of api.h
│   │       ├── VS.c : Implementation of VS.h
│   │       └── VS.h : Vector spaces over GF(q^m)
│   ├── RankSign-II
│   │   ├── configure : configure file to build MPFQ
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash : SHA512
│   │   │   ├── mpfq : MPFQ library
│   │   │   └── rng : NIST randomness
│   │   ├── Makefile : Makefile to compile our code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── ffi : Finite field implementation
│   │       ├── main_kat.c : NIST KAT file
│   │       ├── main_ranksign.c : Main for normal and verbose modes
│   │       ├── parameters.h : Parameters for the scheme
│   │       ├── parsing.c : Implementation of parsing.h
│   │       ├── parsing.h : Functions to parse Ranksign types to/from string
│   │       ├── ranksign.c : Implementation of api.h
│   │       ├── VS.c : Implementation of VS.h
│   │       └── VS.h : Vector spaces over GF(q^m)
│   ├── RankSign-III
│   │   ├── configure : configure file to build MPFQ
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash : SHA512
│   │   │   ├── mpfq : MPFQ library
│   │   │   └── rng : NIST randomness
│   │   ├── Makefile : Makefile to compile our code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── ffi : Finite field implementation
│   │       ├── main_kat.c : NIST KAT file
│   │       ├── main_ranksign.c : Main for normal and verbose modes
│   │       ├── parameters.h : Parameters for the scheme
│   │       ├── parsing.c : Implementation of parsing.h
│   │       ├── parsing.h : Functions to parse Ranksign types to/from string
│   │       ├── ranksign.c : Implementation of api.h
│   │       ├── VS.c : Implementation of VS.h
│   │       └── VS.h : Vector spaces over GF(q^m)
│   ├── RankSign-IV
│   │   ├── configure : configure file to build MPFQ
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash : SHA512
│   │   │   ├── mpfq : MPFQ library
│   │   │   └── rng : NIST randomness
│   │   ├── Makefile : Makefile to compile our code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── ffi : Finite field implementation
│   │       ├── main_kat.c : NIST KAT file
│   │       ├── main_ranksign.c : Main for normal and verbose modes
│   │       ├── parameters.h : Parameters for the scheme
│   │       ├── parsing.c : Implementation of parsing.h
│   │       ├── parsing.h : Functions to parse Ranksign types to/from string
│   │       ├── ranksign.c : Implementation of api.h
│   │       ├── VS.c : Implementation of VS.h
│   │       └── VS.h : Vector spaces over GF(q^m)
│   └── README.md
└── Supporting_Documentation
    └── Supporting_Documentation.pdf : Full specifications of our proposal

===============================================================================

The authors did their best to make this archive complete and proper.
    
-------------------------------------------------------------------------------

Important note regarding Intellectual Property.

As requested by the NIST, the statements will be sent to Dustin MOODY at the 
address provided by the NIST (see below) *and/or* given to NIST at the first 
PQC Standardization Conference 

Dustin MOODY
Information Technology Laboratory
Attention: Post-Quantum Cryptographic Algorithm Submissions
100 Bureau Drive – Stop 8930
National Institute of Standards and Technology
Gaithersburg, MD 20899-8930

Please note that in the meantime, electronic copies of these statements have
been included in appendix to the supporting documentation.

