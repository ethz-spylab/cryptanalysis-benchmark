  1. SUBMISSION OVERVIEW
  ----------------------

  <b>RankSign</b> is a quantum resistant signature based on rank metric. Both reference implementation and optimized implementation provided for this submission are the same. Four parameters sets denoted respectively RankSign-I, RankSign-II, RankSign-III and RankSign-IV are provided as explained in the supporting documentation. Each parameter set folder is organized as follows:
 
  - <b>bin/</b>: Files generated during compilation
  - <b>doc/</b>: Technical documentation of the scheme
  - <b>lib/</b>: Third party libraries used 
  - <b>src/</b>: Source code of the scheme  
  - <b>configure</b>: File used to compile the MPFQ library before compiling ranksign
  - <b>doxygen.conf</b>: Documentation configuration file
  - <b>Makefile</b>: Makefile
  
  <br />
  
  2. INSTALLATION INSTRUCTIONS
  ----------------------------
  
  <h3>2.1 Requirements</h3>
 Before running Ranksign, you will need to build the included <b>mpfq</b> libraries in-place. This can be done by running > ./configure in the Third_Party_Library subdirectory (at the top-level of the submission).

  The following softwares and libraries are required: <b>make</b>, <b>gcc</b>, <b>openssl</b>, <b>cmake</b> and <b>gmp</b>.

  <h3>2.2 Compilation Step</h3>

  Let <b>X</b> denotes <b>I</b>, <b>II</b>, <b>III</b> or <b>IV</b> depending on the parameter set considered. Ranksign can be compiled in three differents ways: 
  - Execute <b>make ranksignX</b> to compile a working example of the scheme. Run <b>bin/ranksignX</b> to execute the scheme and display its performances.
  - Execute <b>make ranksignX-kat</b> to compile the NIST KAT generator. Run <b>bin/ranksignX-kat</b> to generate KAT files.
  - Execute <b>make ranksignX-verbose</b> to compile a working example of the scheme in verbose mode. Run <b>bin/ranksignX-verbose</b> to generate intermediate values.

  During compilation, the following files are created inside the <b>bin/build</b> folder:
  - <b>hash.o</b>: A wrapper around openssl SHA512 implementation
  - <b>rng.o</b>: NIST rng
  - <b>ffi_field.o</b>: Functions to manipulate finite fields.
  - <b>ffi_elt.o</b>: Functions to manipulate finite fields elements.
  - <b>ffi_vecmat.o</b>: Functions to manipulate vectors and matrices over GF(q^m).
  - <b>ffi_basevecmat.o</b>: Functions to manipulate vectors and matrices over GF(q).
  - <b>parsing.o</b>: Functions to parse public key, secret key and signature of the scheme.
  - <b>ranksign.o</b>: The Ranksign scheme (either in normal mode or verbose mode).

 <br />

  3. DOCUMENTATION GENERATION
  ---------------------------

  <h3>3.1 Requirements</h3>

  The following softwares are required: <b>doxygen</b> and <b>bibtex</b>.

  <h3>3.2 Generation Step</h3>
 
  - Run <b>doxygen doxygen.conf</b> to generate the code documentation
  - Browse <b>doc/html/index.html</b> to read the documentation

 <br />

  4. ADDITIONAL INFORMATIONS
  --------------------------

  <h3>4.1 Implementation overview</h3>

  The <b>Ranksign</b> scheme is defined in the api.h and parameters.h files and implemented in ranksign.c.
  The files ffi.h, ffi_field.h, ffi_elt.h, ffi_vecmat.h, ffi_basevecmat.h, VS.h, ffi_field.c, ffi_elt.c and ffi_vec.c provide the functions performing the various operations over finite fields required by the scheme.
  Finally, the files hash.h, rng.h, <b>hash.c</b> and <b>rng.c</b> (inside the <b>lib/</b> folder) contain respectively a wrapper around OpenSSL SHA512 implementation and the NIST random functions.  

  <h3>4.2 Finite field interface</h3>

  Ranksign is a rank-based scheme and as such heavily relies on finite field arithmetic. 
  We have provided an interface for finite fields (through files ffi.h, ffi_field.h, ffi_elt.h, ffi_vecmat.h and ffi_basevecmat.h) describing the various operations required by the scheme. 
  In this submission, the <b>f</b>inite <b>f</b>ield <b>i</b>nterface (<b>ffi</b>) is implemented using the MPFQ library but one should note that Ranksign can work with any implementation of our finite field interface as long as its API is respected. 
  
  In addition, the <b>ffi_baseElt</b> and <b>ffi_elt</b> types are respectively implemented as MPFQ <b>mpfq_2_X_elt</b> and <b>mpfq_2_X_poly</b> types.

  <h3>4.3 Implementation testing</h3>

  Testing our implementation with Valgrind showed problems in the use of some MPFQ functions (conditional jumps based on non initialized values). However, running 500 000 signatures led to no verification error.