/**
 * \file ffi_field.h
 * \brief Initialisation of MPFQ fields
 */

#ifndef FFI_FIELD_H
#define FFI_FIELD_H

#include "mpfq_2_24.h"

#define MPFQ_TAG(x) mpfq_2_24_##x
#define MPFQ_FIELD MPFQ_TAG(field)
//log(2)q "1" bits
#define MPFQ_MASK 0xffffffUL

void init_field(MPFQ_FIELD field);
void clear_field(MPFQ_FIELD field);

#endif