#ifndef RANKSIGN
#define RANKSIGN

#include <stdlib.h>
#include "ffi_elt.h"
#include "ffi_vecmat.h"
#include "VS.h"

//Handle malloc errors
#define MALLOC_ERROR()                                                  \
        do {                                                            \
                fprintf(stderr, "Malloc failed\n");                     \
                abort();                                                \
        } while (0)

#define PARAM_M 27

#define PARAM_D 2
#define PARAM_T 3
#define PARAM_R 10
#define PARAM_R2 9
#define PARAM_T2 1

#define PARAM_N 24
#define PARAM_K 12

#define FFI_BASEELT_BYTES 4
#define FFI_ELT_BYTES PARAM_M * FFI_BASEELT_BYTES

#define PUBLICKEY_BYTES (PARAM_T + PARAM_K) * (PARAM_N - PARAM_K) * FFI_ELT_BYTES

//Secret key
#define F_BYTES PARAM_D * FFI_ELT_BYTES
#define DH_BYTES PARAM_N * PARAM_N * FFI_BASEELT_BYTES
#define INVP_BYTES (PARAM_N + PARAM_T) * (PARAM_N + PARAM_T) * FFI_BASEELT_BYTES
#define INVA_BYTES (PARAM_N - PARAM_K) * (PARAM_N - PARAM_K) * FFI_ELT_BYTES
#define R_BYTES (PARAM_N - PARAM_K) * PARAM_T * FFI_ELT_BYTES
#define SECRETKEY_BYTES F_BYTES + DH_BYTES + INVP_BYTES + INVA_BYTES + R_BYTES + PUBLICKEY_BYTES

#define SIGNATURE_BYTES PARAM_R * FFI_ELT_BYTES + (PARAM_N + PARAM_T) * PARAM_R * FFI_BASEELT_BYTES + 1

#define TEST_MESSAGE_LENGTH 100
#define SHA512_BYTES 64

typedef struct {
	VS F;
	ffi_basemat DH;
	ffi_basemat invQ;
	ffi_mat invP;
	ffi_mat R;
	ffi_mat H;
} SK;

typedef struct {
	ffi_mat Hpub;
} PK;

typedef SK* secretKey;
typedef PK* publicKey;

#endif