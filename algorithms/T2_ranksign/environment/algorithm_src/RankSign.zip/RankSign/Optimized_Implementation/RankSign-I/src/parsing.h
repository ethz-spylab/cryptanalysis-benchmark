/**
 * \file parsing.h
 * \brief Parsing functions for Ranksign
 */

#ifndef PARSING_H
#define PARSING_H

#include "ffi_field.h"
#include "parameters.h"
#include "ffi_elt.h"
#include "ffi_vecmat.h"
#include "ffi_basevecmat.h"

void publicKeyToString(MPFQ_FIELD field, const publicKey pk, unsigned char* pkString);
void publicKeyFromString(MPFQ_FIELD field, publicKey pk, const unsigned char* pkString);

void secretKeyToString(MPFQ_FIELD field, const secretKey sk, unsigned char* skString);
void secretKeyFromString(MPFQ_FIELD field, secretKey sk, const unsigned char* skString);

void signatureToString(MPFQ_FIELD field, VS ET, ffi_basevec signature, unsigned char* signatureString, unsigned char seed);
void signatureFromString(MPFQ_FIELD field, ffi_vec signature, const unsigned char* signatureString, unsigned char *seed);

void syndromFromHash(MPFQ_FIELD field, ffi_vec syndrom, int len, const unsigned char* hash);

#endif