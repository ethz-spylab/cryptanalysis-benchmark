/**
 * \file ranksign.c
 * \brief Implementation of api.h
 */

#include "api.h"
#include "parameters.h"

#include <stdio.h>
#include "rng.h"
#include "ffi_field.h"
#include "hash.h"
#include "VS.h"
#include "ffi_vecmat.h"
#include "ffi_basevecmat.h"
#include "parsing.h"

/**
 * @brief      Keygen for the Ranksign scheme
 *
 * @param      pk    The public key
 * @param      sk    The private key
 *
 * @return     0 if keygen was successfull
 */
int crypto_sign_keypair(unsigned char *pk, unsigned char *sk) {
	#ifdef VERBOSE
	printf("################\n");
	printf("#### KEYGEN ####\n");
	printf("################\n\n");
	int try = 1;
	#endif

	MPFQ_FIELD field;
	init_field(field);
	generateExtension(field);

	publicKey pkTmp;
	secretKey skTmp;

	pkTmp = (publicKey)malloc(sizeof(PK));
	skTmp = (secretKey)malloc(sizeof(SK));

	if(pkTmp == NULL || skTmp == NULL) MALLOC_ERROR();

	int ret, i, j, k;

	ffi_basemat Q;
	ffi_basemat AH;
	ffi_mat H;
	ffi_mat RH;

	int status;

	do {
		#ifdef VERBOSE
		printf("Try n.%d\n", try);
		try = try + 1;
		#endif

		//First choose Q[n+t][n+t] random in GF(q) and store its inverse in sk
		skTmp->invQ = NULL;
		Q = ffi_basemat_init(field, PARAM_N + PARAM_T, PARAM_N + PARAM_T);
		do {
			if(skTmp->invQ != NULL) ffi_basemat_clear(field, skTmp->invQ, PARAM_N + PARAM_T, PARAM_N + PARAM_T); //In case we need to invert more than once
			skTmp->invQ = ffi_basemat_init(field, PARAM_N + PARAM_T, PARAM_N + PARAM_T);
			ffi_basemat_set_random(field, Q, PARAM_N + PARAM_T, PARAM_N + PARAM_T);
			ret = ffi_basemat_inv(field, skTmp->invQ, Q, PARAM_N + PARAM_T, PARAM_N + PARAM_T);
		} while(ret < 0);

		//Generate AH[n][n] invertible in GF(q) and store its inverse DH, the decoding matrix of the LRPC code
		skTmp->DH = NULL;
		AH = ffi_basemat_init(field, PARAM_N, PARAM_N);
		do {
			if(skTmp->DH != NULL) ffi_basemat_clear(field, skTmp->DH, PARAM_N, PARAM_N); //In case we need to invert more than once
			skTmp->DH = ffi_basemat_init(field, PARAM_N, PARAM_N);
			ffi_basemat_set_random(field, AH, PARAM_N, PARAM_N);
			ret = ffi_basemat_inv(field, skTmp->DH, AH, PARAM_N, PARAM_N);
		} while(ret < 0);

		//Generate R, random in Fq^m, and then derive H (the LRPC matrix) from AH by choosing F a random vector space of dimension d
		skTmp->R = ffi_mat_init(field, PARAM_N - PARAM_K, PARAM_T);
		H = ffi_mat_init(field, PARAM_N - PARAM_K, PARAM_N);
		skTmp->F = initVS(field, PARAM_D);

		ffi_mat_set_random(field, skTmp->R, PARAM_N - PARAM_K, PARAM_T);
		randomVSFullRank(field, skTmp->F);

		//Derive H from AH
		ffi_elt tmp;
		ffi_elt_init(field, tmp);
		for(i=0 ; i<PARAM_N - PARAM_K ; i++) { //Lines
			for(j=0 ; j<PARAM_N ; j++) { //Columns
				for(k=0 ; k<PARAM_D ; k++) {
					ffi_elt_mul_base(field, tmp, skTmp->F->vectors[k], AH[i * PARAM_D + k][j]);
					ffi_elt_add(field, H[i][j], H[i][j], tmp);
				}
			}
		}
		ffi_elt_clear(field, tmp);

		//Public key computation
		//Concatenate R and H, then compute (RH)Q, then transform it into systematic form, P is the matrix such that P * (RH)Q = (RH)Q in systematic form
		RH = ffi_mat_concat(field, skTmp->R, H, PARAM_N - PARAM_K, PARAM_T, PARAM_N - PARAM_K, PARAM_N);
		skTmp->invP = ffi_mat_init(field, PARAM_N - PARAM_K, PARAM_N - PARAM_K);

		pkTmp->Hpub = ffi_mat_init(field, PARAM_N - PARAM_K, PARAM_N + PARAM_T);
		ffi_mat_prod_base(field, pkTmp->Hpub, RH, Q, PARAM_N - PARAM_K, PARAM_N + PARAM_T, PARAM_N + PARAM_T, PARAM_N + PARAM_T);
		//Computes P, stores its inverse in skTmp->invP
		status = ffi_mat_compute_pk(field, pkTmp->Hpub, skTmp->invP, PARAM_N - PARAM_K, PARAM_N + PARAM_T);
		//Hpub is now in systematic form

		//If Hpub can't be echelonized, we need to restart the process, so we clear the allocated memory
		if(status != 0) {
			ffi_basemat_clear(field, Q, PARAM_N + PARAM_T, PARAM_N + PARAM_T);
			ffi_basemat_clear(field, AH, PARAM_N, PARAM_N);
			ffi_mat_clear(field, H, PARAM_N - PARAM_K, PARAM_N);
			ffi_mat_clear(field, RH, PARAM_N - PARAM_K, PARAM_N + PARAM_T);
			//pk
			ffi_mat_clear(field, pkTmp->Hpub, PARAM_N - PARAM_K, PARAM_N + PARAM_T);
			//sk
			clearVS(field, skTmp->F);
			ffi_basemat_clear(field, skTmp->DH, PARAM_N, PARAM_N);
			ffi_basemat_clear(field, skTmp->invQ, (PARAM_N + PARAM_T), (PARAM_N + PARAM_T));
			ffi_mat_clear(field, skTmp->invP, (PARAM_N - PARAM_K), (PARAM_N - PARAM_K));
			ffi_mat_clear(field, skTmp->R, (PARAM_N - PARAM_K), PARAM_T);
		}

		#ifdef VERBOSE
		printf("Q =\n"); ffi_basemat_print(field, Q, PARAM_N + PARAM_T, PARAM_N + PARAM_T);
		printf("R =\n"), ffi_mat_print(field, skTmp->R, PARAM_N - PARAM_K, PARAM_T);
		printVS(field, skTmp->F, "F");
		printf("AH =\n"); ffi_basemat_print(field, AH, PARAM_N, PARAM_N);
		printf("P^-1 =\n"); ffi_mat_print(field, skTmp->invP, PARAM_N - PARAM_K, PARAM_N - PARAM_K);
		#endif
	} while(status != 0);

	//Clear all variables
	ffi_basemat_clear(field, Q, PARAM_N + PARAM_T, PARAM_N + PARAM_T);
	ffi_basemat_clear(field, AH, PARAM_N, PARAM_N);

	ffi_mat_clear(field, H, PARAM_N - PARAM_K, PARAM_N);
	ffi_mat_clear(field, RH, PARAM_N - PARAM_K, PARAM_N + PARAM_T);

	publicKeyToString(field, pkTmp, pk);
	secretKeyToString(field, skTmp, sk);
	//Concatenate pk to sk
	publicKeyToString(field, pkTmp, sk + CRYPTO_SECRETKEYBYTES - CRYPTO_PUBLICKEYBYTES);

	#ifdef VERBOSE
	printf("pk = "); for(i=0 ; i<CRYPTO_PUBLICKEYBYTES ; i++) printf("%02x", pk[i]);
	printf("\n");
	printf("sk = "); for(i=0 ; i<CRYPTO_SECRETKEYBYTES ; i++) printf("%02x", sk[i]);
	printf("\n");
	#endif

	//PK clear
	ffi_mat_clear(field, pkTmp->Hpub, PARAM_N - PARAM_K, PARAM_N + PARAM_T);
	free(pkTmp);

	//SK clear
	clearVS(field, skTmp->F);
	ffi_basemat_clear(field, skTmp->DH, PARAM_N, PARAM_N);
	ffi_basemat_clear(field, skTmp->invQ, (PARAM_N + PARAM_T), (PARAM_N + PARAM_T));
	ffi_mat_clear(field, skTmp->invP, (PARAM_N - PARAM_K), (PARAM_N - PARAM_K));
	ffi_mat_clear(field, skTmp->R, (PARAM_N - PARAM_K), PARAM_T);
	free(skTmp);

	clear_field(field);

	return 0;
}

/**
 * @brief      Signature of message with a private key
 *
 * @param      sk         The private key
 * @param      message    The message
 * @param      signature  The signature
 *
 * @return     0 if the signature was successful, -1 otherwise
 */
int crypto_sign(unsigned char *sm, unsigned long long *smlen, const unsigned char *m, unsigned long long mlen, const unsigned char *sk) {
	#ifdef VERBOSE
	printf("##############\n");
	printf("#### SIGN ####\n");
	printf("##############\n\n");
	#endif
	MPFQ_FIELD field;
	init_field(field);
	generateExtension(field);

	unsigned int i, j;

	publicKey pkTmp;

	pkTmp = (publicKey)malloc(sizeof(PK));
	if(pkTmp == NULL) MALLOC_ERROR();
	publicKeyFromString(field, pkTmp, sk + CRYPTO_SECRETKEYBYTES - CRYPTO_PUBLICKEYBYTES);

	//First choose T' at random, e' a vector of length n+t in T'
	VS T2;
	T2 = initVS(field, PARAM_T2);
	randomVSFullRank(field, T2);

	//e'.Hpub computation
	ffi_vec e2;
	e2 = ffi_vec_init(field, PARAM_N + PARAM_T);

	ffi_basevec e2Coords;
	e2Coords = ffi_basevec_init(field, (PARAM_N + PARAM_T) * PARAM_T2);

	//Choose coordinates in T' randomly
	ffi_basevec_set_random(field, e2Coords, (PARAM_N + PARAM_T) * PARAM_T2);

	//Derive e2 from these coordinates
	ffi_elt tmpElt;
	ffi_elt_init(field, tmpElt);
	for(i=0 ; i<(PARAM_N + PARAM_T) ; i++) {
		for(j=0 ; j<PARAM_T2 ; j++) {
			ffi_elt_mul_base(field, tmpElt, T2->vectors[j], e2Coords[i*PARAM_T2 + j]);
			ffi_elt_add(field, e2[i], e2[i], tmpElt);
		}
	}
	ffi_elt_clear(field, tmpElt);

	//Multiply by Hpub
	ffi_vec eH;
	eH = ffi_vec_init(field, PARAM_N - PARAM_K);
	ffi_vec_prod_mat(field, eH, e2, pkTmp->Hpub, PARAM_N + PARAM_T, PARAM_N - PARAM_K, PARAM_N + PARAM_T);

	#ifdef VERBOSE
	printf("Message = "); for(i=0 ; i<mlen ; i++) printf("%02x", m[i]);
	printf("\n");
	printf("e' = \n"); ffi_vec_print(field, e2, PARAM_N + PARAM_T);
	printf("e'.Hpub =\n"); ffi_vec_print(field, eH, PARAM_N - PARAM_K);
	int try = 1;
	#endif

	ffi_basevec_clear(field, e2Coords, (PARAM_N + PARAM_T) * PARAM_T2);

	//End of e'.Hpub computation

	secretKey skTmp;
	skTmp = (secretKey)malloc(sizeof(SK));
	if(skTmp == NULL) MALLOC_ERROR();
	secretKeyFromString(field, skTmp, sk);

	unsigned char seed = 0;
	ffi_vec s;
	VS T;
	ffi_vec erasure_space;
	ffi_vec As;
	ffi_vec Re;
	ffi_vec s2;
	VS Ssyndrom, FT, S, S1, S2, E;
	ffi_elt F1, F2;
	VS syndromBasis;
	ffi_basevec equations;
	int sigOK;
	ffi_basevec e;

	do {
		//First compute the message hash, with a seed that is a counter
		unsigned char hash[SHA512_BYTES];
		unsigned char messageToHash[mlen + 1];
		memcpy(messageToHash, m, mlen);
		memcpy(messageToHash + mlen, &seed, 1);
		sha512(hash, messageToHash, mlen + 1);
		
		//s is the hash
		s = ffi_vec_init(field, PARAM_N - PARAM_K);
		syndromFromHash(field, s, PARAM_N - PARAM_K, hash);

		#ifdef VERBOSE
		printf("s =\n"); ffi_vec_print(field, s, PARAM_N - PARAM_K);
		printf("\n");
		#endif

		//Substracts e'.Hpub from the syndrom
		ffi_vec_sub(field, s, s, eH, PARAM_N - PARAM_K);

		//Substracts e'.Hpub from s

		//Choose <e_1, ..., e_t> and call that erasure_space
		T = initVS(field, PARAM_T);
		randomVSFullRank(field, T);

		erasure_space = ffi_vec_init(field, PARAM_T);

		for(i=0 ; i<PARAM_T ; i++) {
			ffi_elt_set(field, erasure_space[i], T->vectors[i]);
		}

		//Compute the syndrom to invert
		//First A^-1 . s
		As = ffi_vec_init(field, PARAM_N - PARAM_K);

		ffi_mat_vec_prod(field, As, skTmp->invP, s, PARAM_N - PARAM_K, PARAM_N - PARAM_K);

		//Then R.erasureSpace
		Re = ffi_vec_init(field, PARAM_N - PARAM_K);

		ffi_mat_vec_prod(field, Re, skTmp->R, erasure_space, PARAM_N - PARAM_K, PARAM_T);

		//The syndrom is As - Re
		s2 = ffi_vec_init(field, PARAM_N - PARAM_K);

		ffi_vec_sub(field, s2, As, Re, PARAM_N - PARAM_K);

		//Generalized erasure decoding algorithm
		//Compute the vector space S generated by this syndrom, and then add FT to it
		Ssyndrom = initVS(field, PARAM_N - PARAM_K);
		for(i=0 ; i<PARAM_N - PARAM_K ; i++) {
			ffi_elt_set(field, Ssyndrom->vectors[i], s2[i]);
		}

		FT = mulVS(field, skTmp->F, T);
		S = directsumVS(field, FT, Ssyndrom);

		//Compute F1^-1.S inter F2^-1.S (needs to be adapted if d>2)
		ffi_elt_init(field, F1);
		ffi_elt_init(field, F2);
		ffi_elt_inv(field, F1, skTmp->F->vectors[0]);
		ffi_elt_inv(field, F2, skTmp->F->vectors[1]);

		S1 = mulVSByElt(field, S, F1);
		S2 = mulVSByElt(field, S, F2);
		E = interVS(field, S1, S2);

		int rankSupport = rankVS(field, E);

		sigOK = 1;

		equations = ffi_basevec_init(field, (PARAM_N - PARAM_K) * PARAM_R2 * PARAM_D);
		e = ffi_basevec_init(field, (PARAM_N - PARAM_K) * PARAM_R2 * PARAM_D);

		#ifdef VERBOSE
		printf("Try n.%d\n", try);
		try = try + 1;
		printf("G(m||seed) = "); for(i=0 ; i<SHA512_BYTES ; i++) printf("%02x", hash[i]);
		printf("\n");
		printf("s' =\n"); ffi_vec_print(field, s, PARAM_N - PARAM_K);
		printVS(field, T, "T");
		printf("s'' =\n"); ffi_vec_print(field, s2, PARAM_N - PARAM_K);
		#endif

		//Check if the generalized erasure algorithm worked by checking the dimension of E
		if(rankSupport != PARAM_R2) {
			sigOK = 0;
		}
		else {
			//Now we compute the basis <F1E1, F1E2, ..., FdEr>
			syndromBasis = mulVS(field, skTmp->F, E);

			//We need to rewrite the syndrom to invert in this basis to get the equations of the linear system
			if(ffi_basevec_from_support(field, s2, PARAM_N - PARAM_K, syndromBasis, PARAM_R2 * PARAM_D, equations) == 1) {
				//If not all the coordinates can be rewritten in the basis <F1E1, F1E2, ..., FdEr> then there was a problem during decoding
				clearVS(field, syndromBasis);
				sigOK = 0;
			}
			else {
				//Then multiply DH by this to solve the LRPC
				//Note that DH is n*n so it is more compact, so the product isn't trivial
				ffi_baseElt tmp;
				ffi_baseElt_init(field, tmp);
				for(i=0 ; i<(PARAM_N - PARAM_K) * PARAM_R2 * PARAM_D ; i++) {
					ffi_baseElt_set_zero(field, e[i]);
					for(j=0 ; j<PARAM_N; j++) {
						ffi_baseElt_mul(field, tmp, skTmp->DH[i / PARAM_R2][j], equations[j * PARAM_R2 + (i % PARAM_R2)]);
						ffi_baseElt_add(field, e[i], e[i], tmp);
					}
				}
				ffi_baseElt_clear(field, tmp);
			}
		}

		//If there was a failure, we need to retry with another value for the seed
		if(sigOK == 0) {
			seed = seed + 1;
			ffi_vec_clear(field, s, PARAM_N - PARAM_K);
			ffi_vec_clear(field, As, PARAM_N - PARAM_K);
			ffi_vec_clear(field, Re, PARAM_N - PARAM_K);
			ffi_vec_clear(field, s2, PARAM_N - PARAM_K);
			ffi_vec_clear(field, erasure_space, PARAM_T);

			ffi_basevec_clear(field, equations, (PARAM_N - PARAM_K) * PARAM_R2 * PARAM_D);
			ffi_basevec_clear(field, e, (PARAM_N - PARAM_K) * PARAM_R2 * PARAM_D);

			clearVS(field, T);
			clearVS(field, Ssyndrom);
			clearVS(field, FT);
			clearVS(field, S);
			clearVS(field, S1);
			clearVS(field, S2);
			clearVS(field, E);

			ffi_elt_clear(field, F1);
			ffi_elt_clear(field, F2);
		}
	} while(sigOK == 0);

	//Once we have e, we need to convert it to a word of Fq^m
	ffi_vec e_qm, sigTmp;
	e_qm = ffi_vec_from_basevec(field, e, (PARAM_N - PARAM_K) * PARAM_R2 * PARAM_D, E, PARAM_R2);

	//Concatenates the erasure space and e_qm
	sigTmp = ffi_vec_concat(field, erasure_space, e_qm, PARAM_T, PARAM_N);

	//Then multiplies by Q^-1
	ffi_vec signatureTmp;
	signatureTmp = ffi_vec_init(field, PARAM_N + PARAM_T);
	ffi_vec_prod_basemat(field, signatureTmp, sigTmp, skTmp->invQ, PARAM_T + PARAM_N, PARAM_T + PARAM_N, PARAM_T + PARAM_N);
	//Add e' and convert the signature to a string
	ffi_vec_add(field, signatureTmp, signatureTmp, e2, PARAM_N + PARAM_T);

	*smlen = mlen + CRYPTO_BYTES;

	//Copy the message into the signed message and then concatenate with the signature
	memcpy(sm, m, mlen);
	//Rewrite the signature in a basis of E + T2
	VS ET = directsumVS(field, E, T2);
	ffi_basevec signatureCoords;
	signatureCoords = ffi_basevec_init(field, (PARAM_N + PARAM_T) * PARAM_R);
	ffi_basevec_from_support(field, signatureTmp, PARAM_N + PARAM_T, ET, PARAM_R, signatureCoords);
	signatureToString(field, ET, signatureCoords, sm + mlen, seed);

	#ifdef VERBOSE
	printf("<e_t, ..., e_n+t> =\n"); ffi_vec_print(field, e_qm, PARAM_N);
	printf("signatureTmp =\n"); ffi_vec_print(field, signatureTmp, PARAM_N + PARAM_T);
	printf("Signature = \n"); for(i=0 ; i<*smlen ; i++) printf("%02x", sm[i]);
	printf("\n");
	#endif

	//Clear all variables
	ffi_vec_clear(field, As, PARAM_N - PARAM_K);
	ffi_vec_clear(field, Re, PARAM_N - PARAM_K);
	ffi_vec_clear(field, s2, PARAM_N - PARAM_K);
	ffi_vec_clear(field, s, PARAM_N - PARAM_K);
	ffi_vec_clear(field, e_qm, PARAM_N);
	ffi_vec_clear(field, sigTmp, PARAM_N + PARAM_T);
	ffi_vec_clear(field, signatureTmp, PARAM_N + PARAM_T);
	ffi_vec_clear(field, erasure_space, PARAM_T);
	ffi_vec_clear(field, eH, PARAM_N - PARAM_K);
	ffi_vec_clear(field, e2, PARAM_N + PARAM_T);

	ffi_basevec_clear(field, equations, (PARAM_N - PARAM_K) * PARAM_R2 * PARAM_D);
	ffi_basevec_clear(field, e, (PARAM_N - PARAM_K) * PARAM_R2 * PARAM_D);
	ffi_basevec_clear(field, signatureCoords, (PARAM_N + PARAM_T) * PARAM_R);

	clearVS(field, T);
	clearVS(field, Ssyndrom);
	clearVS(field, FT);
	clearVS(field, S);
	clearVS(field, S1);
	clearVS(field, S2);
	clearVS(field, E);
	clearVS(field, syndromBasis);
	clearVS(field, T2);
	clearVS(field, ET);

	ffi_elt_clear(field, F1);
	ffi_elt_clear(field, F2);

	//PK clear
	ffi_mat_clear(field, pkTmp->Hpub, PARAM_N - PARAM_K, PARAM_N + PARAM_T);
	free(pkTmp);

	//SK clear
	clearVS(field, skTmp->F);
	ffi_basemat_clear(field, skTmp->DH, PARAM_N, PARAM_N);
	ffi_basemat_clear(field, skTmp->invQ, (PARAM_N + PARAM_T), (PARAM_N + PARAM_T));
	ffi_mat_clear(field, skTmp->invP, (PARAM_N - PARAM_K), (PARAM_N - PARAM_K));
	ffi_mat_clear(field, skTmp->R, (PARAM_N - PARAM_K), PARAM_T);
	free(skTmp);

	clear_field(field);

	return 0;
}

/**
 * @brief      Verification of the signature of message with a public key
 *
 * @param      pk         The public key
 * @param      message    The message
 * @param      signature  The signature
 *
 * @return     0 if the signature is valid, -1 if the signature is invalid
 */
int crypto_sign_open(unsigned char *m, unsigned long long *mlen, const unsigned char *sm, unsigned long long smlen, const unsigned char *pk) {
	#ifdef VERBOSE
	printf("################\n");
	printf("#### VERIFY ####\n");
	printf("################\n\n");
	#endif

	MPFQ_FIELD field;
	init_field(field);
	generateExtension(field);

	unsigned char seed = 0;
	int i;

	int messageLength = smlen - CRYPTO_BYTES;

	//Get the signature and the seed
	ffi_vec signatureTmp;
	signatureTmp = ffi_vec_init(field, PARAM_N + PARAM_T);
	signatureFromString(field, signatureTmp, sm + smlen - CRYPTO_BYTES, &seed);

	//Compute message hash
	unsigned char hash[SHA512_BYTES];
	unsigned char messageToHash[messageLength + 1];
	memcpy(messageToHash, sm, messageLength);
	memcpy(messageToHash + messageLength, &seed, 1);
	sha512(hash, messageToHash, messageLength + 1);

	//Get the syndrom from the hash
	ffi_vec syndrom;
	syndrom = ffi_vec_init(field, PARAM_N - PARAM_K);
	syndromFromHash(field, syndrom, PARAM_N - PARAM_K, hash);

	publicKey pkTmp;

	pkTmp = (publicKey)malloc(sizeof(PK));
	if(pkTmp == NULL) MALLOC_ERROR();
	publicKeyFromString(field, pkTmp, pk);

	//Compute sig.Hpub
	ffi_vec verif = ffi_vec_init(field, PARAM_N - PARAM_K);
	ffi_mat_vec_prod(field, verif, pkTmp->Hpub, signatureTmp, PARAM_N - PARAM_K, PARAM_N + PARAM_T);

	#ifdef VERBOSE
	printf("G(m||seed) = "); for(i=0 ; i<SHA512_BYTES ; i++) printf("%02x", hash[i]);
	printf("\n");
	printf("s =\n"); ffi_vec_print(field, syndrom, PARAM_N - PARAM_K);
	printf("signature*Hpub =\n"); ffi_vec_print(field, verif, PARAM_N - PARAM_K);
	#endif

	//Check if verif = hash(m||seed)
	int sigOK = 1;
	for(i=0 ; i<PARAM_N - PARAM_K ; i++) {
		if(ffi_elt_cmp(field, syndrom[i], verif[i]) != 0) {
			sigOK = 0;
			break;
		}
	}

	//If verif = hash(m||seed) check the rank of the signature
	if(sigOK == 1) {
		int rank;
		VS signatureSpace;
		signatureSpace = initVS(field, PARAM_N + PARAM_T);

		for(i=0 ; i<PARAM_N + PARAM_T ; i++) {
			ffi_elt_set(field, signatureSpace->vectors[i], signatureTmp[i]);
		}

		rank = rankVS(field, signatureSpace);

		if(rank > PARAM_R) sigOK = 0;

		clearVS(field, signatureSpace);

		#ifdef VERBOSE
		printf("Rank of the signature : %d\n", rank);
		#endif
	}

	*mlen = messageLength;
	memcpy(m, sm, messageLength);

	ffi_vec_clear(field, signatureTmp, PARAM_N + PARAM_T);
	ffi_vec_clear(field, syndrom, PARAM_N - PARAM_K);
	ffi_vec_clear(field, verif, PARAM_N - PARAM_K);

	//PK clear
	ffi_mat_clear(field, pkTmp->Hpub, PARAM_N - PARAM_K, PARAM_N + PARAM_T);
	free(pkTmp);

	clear_field(field);

	if(sigOK) return 0;
	else return -1;
}