/*
 * \file ffi_elt.c
 * \brief Implementation of ffi_elt.h
 */

#include "ffi_elt.h"
#include "../parameters.h"

#include <stdio.h>
#include <stdlib.h>
#include "rng.h"
#include "ffi_field.h"

ffi_elt IRR;
int extensionGenerated = 0;

/**
 * @brief      Initializes an element of GF(q)
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q) element
 */
void ffi_baseElt_init(MPFQ_FIELD field, ffi_baseElt res) {
	MPFQ_TAG(init)(field, res);
}

/**
 * @brief      Clears an element of GF(q)
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q) element
 */
void ffi_baseElt_clear(MPFQ_FIELD field, ffi_baseElt res) {
	MPFQ_TAG(clear)(field, res);
}

/**
 * @brief      Prints an element of GF(q)
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q) element
 */
void ffi_baseElt_print(MPFQ_FIELD field, ffi_baseElt res) {
	MPFQ_TAG(print)(field, res);
}

/**
 * @brief      Sets an element of GF(q) to a random value using NIST randombytes
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q) element
 */
void ffi_baseElt_set_random(MPFQ_FIELD field, ffi_baseElt res) {
	int bytes = PARAM_M / 8 + 1;
	unsigned char random[bytes];
	randombytes(random, bytes);

	memcpy((unsigned long*) res, random, bytes);
	res[0] &= MPFQ_MASK;
}

/**
 * @brief      Copies an element of GF(q) to another one
 *
 * @param[in]  field  The field
 * @param[in]  dest   Destination GF(q) element
 * @param[in]  src    Source GF(q) element
 */
void ffi_baseElt_set(MPFQ_FIELD field, ffi_baseElt dest, ffi_baseElt src) {
	MPFQ_TAG(set)(field, dest, src);
}

/**
 * @brief      Sets an element of GF(q) to zero
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q) element
 */
void ffi_baseElt_set_zero(MPFQ_FIELD field, ffi_baseElt res) {
	MPFQ_TAG(set_ui)(field, res, 0);
}

/**
 * @brief      Sets an element of GF(q) to one
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q) element
 */
void ffi_baseElt_set_one(MPFQ_FIELD field, ffi_baseElt res) {
	MPFQ_TAG(set_ui)(field, res, 1);
}

/**
 * @brief      Adds two elements of GF(q)
 *
 * @param[in]  field  The field
 * @param[in]  res    Result of the addition
 * @param[in]  elt1   First GF(q) element
 * @param[in]  elt2   Second GF(q) element
 */
void ffi_baseElt_add(MPFQ_FIELD field, ffi_baseElt res, ffi_baseElt elt1, ffi_baseElt elt2) {
	MPFQ_TAG(add)(field, res, elt1, elt2);
}

/**
 * @brief      Substracts elt2 to elt1 (in GF(q))
 *
 * @param[in]  field  The field
 * @param[in]  res    Result of elt1 - elt2
 * @param[in]  elt1   The element 1
 * @param[in]  elt2   The element 2
 */
void ffi_baseElt_sub(MPFQ_FIELD field, ffi_baseElt res, ffi_baseElt elt1, ffi_baseElt elt2) {
	MPFQ_TAG(sub)(field, res, elt1, elt2);
}

/**
 * @brief      Multiplies two elements of GF(q)
 *
 * @param[in]  field  The field
 * @param[in]  res    Result of the multiplication
 * @param[in]  elt1   The element 1
 * @param[in]  elt2   The element 2
 */
void ffi_baseElt_mul(MPFQ_FIELD field, ffi_baseElt res, ffi_baseElt elt1, ffi_baseElt elt2) {
	MPFQ_TAG(mul)(field, res, elt1, elt2);
}

/**
 * @brief      Inverts an element of GF(q)
 *
 * @param[in]  field  The field
 * @param[in]  res    Inverse of source element
 * @param[in]  src    Source GF(q) element
 */
void ffi_baseElt_inv(MPFQ_FIELD field, ffi_baseElt res, ffi_baseElt src) {
	MPFQ_TAG(inv)(field, res, src);
}

/**
 * @brief      Checks if an element of GF(q) is zero
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q) element
 *
 * @return     1 if the element equals zero, 0 otherwise
 */
int ffi_baseElt_is_zero(MPFQ_FIELD field, ffi_baseElt res) {
	return MPFQ_TAG(is_zero)(field, res);
}

/**
 * @brief      Converts an element of GF(q) to a string
 *
 * @param[in]  field   The field
 * @param[in]  elt     The element
 * @param      string  The string
 */
void ffi_baseElt_to_string(MPFQ_FIELD field, ffi_baseElt elt, unsigned char* string) {
	memcpy(string, (unsigned char*)elt, FFI_BASEELT_BYTES);
}

/**
 * @brief      Converts an element of GF(q^m) to a string
 *
 * @param[in]  field   The field
 * @param[in]  elt     The element
 * @param      string  The string
 */
void ffi_elt_to_string(MPFQ_FIELD field, ffi_elt elt, unsigned char* string) {
	int i;
	ffi_baseElt coeff;
	ffi_baseElt_init(field, coeff);

	int degree = MPFQ_TAG(poly_deg)(field, elt);

	for(i=0 ; i<=degree ; i++) {
		MPFQ_TAG(poly_getcoef)(field, coeff, elt, i);
		ffi_baseElt_to_string(field, coeff, string + i*FFI_BASEELT_BYTES);
	}

	ffi_baseElt_set_zero(field, coeff);

	for(i=degree+1 ; i<PARAM_M ; i++) {
		ffi_baseElt_to_string(field, coeff, string + i*FFI_BASEELT_BYTES);
	}

	ffi_baseElt_clear(field, coeff);
}

/**
 * @brief      Converts a string to an element of GF(q)
 *
 * @param[in]  field   The field
 * @param[in]  elt     The element
 * @param      string  The string
 */
void ffi_baseElt_from_string(MPFQ_FIELD field, ffi_baseElt elt, const unsigned char* string) {
	ffi_baseElt_set_zero(field, elt);
	memcpy((unsigned char*)elt, string, FFI_BASEELT_BYTES);
}

/**
 * @brief      Converts a string to an element of GF(q^m)
 *
 * @param[in]  field   The field
 * @param[in]  elt     The element
 * @param      string  The string
 */
void ffi_elt_from_string(MPFQ_FIELD field, ffi_elt elt, const unsigned char* string) {
	int i;
	ffi_baseElt coeff;
	ffi_baseElt_init(field, coeff);

	for(i=0 ; i<PARAM_M ; i++) {
		ffi_baseElt_from_string(field, coeff, string + i*FFI_BASEELT_BYTES);
		MPFQ_TAG(poly_setcoef)(field, elt, coeff, i);
	}

	ffi_baseElt_clear(field, coeff);
}

/**
 * @brief      Initializes an element of GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q^m) element
 */
void ffi_elt_init(MPFQ_FIELD field, ffi_elt res) {
	MPFQ_TAG(poly_init)(field, res, PARAM_M - 1);
}

/**
 * @brief      Sets an element of GF(q^m) to one
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q^m) element
 */
void ffi_elt_set_one(MPFQ_FIELD field, ffi_elt res) {
	MPFQ_TAG(poly_setcoef_ui)(field, res, 1, 0);
}

/**
 * @brief      Sets an element of GF(q^m) to a random value using NIST randombytes
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q^m) element
 */
void ffi_elt_set_random(MPFQ_FIELD field, ffi_elt res) {
	int bytes = PARAM_M / 8 + 1;
	unsigned char random[bytes * PARAM_M];
	randombytes(random, bytes * PARAM_M);
	ffi_baseElt rand;
	int i;
	for(i=0 ; i<PARAM_M ; i++) {
		memcpy((unsigned long*) rand, random + i * bytes, bytes);
		rand[0] &= MPFQ_MASK;
		MPFQ_TAG(poly_setcoef)(field, res, rand, i);
	}
	ffi_baseElt_clear(field, rand);
}

/**
 * @brief      Sets an element of GF(q^m) to zero
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q^m) element
 */
void ffi_elt_set_zero(MPFQ_FIELD field, ffi_elt res) {
	int i;
	ffi_baseElt zero;
	ffi_baseElt_init(field, zero);
	ffi_baseElt_set_zero(field, zero);

	for(i=0 ; i<PARAM_M ; i++) {
		MPFQ_TAG(poly_setcoef)(field, res, zero, i);
	}

	ffi_baseElt_clear(field, zero);
}

/**
 * @brief      Initializes the polynomial used to define GF(q^m) over GF(q)
 *
 * @param[in]  field  The field
 */
void generateExtension(MPFQ_FIELD field) {
	if(!extensionGenerated) {
		ffi_baseElt coeff;
		MPFQ_TAG(init)(field, coeff);
		MPFQ_TAG(poly_init)(field, IRR, PARAM_M);

		int index = 0;

		*coeff = 0;

		for(index=0 ; index<=PARAM_M ; index++) {
			MPFQ_TAG(poly_setcoef)(field, IRR, coeff, index);
		}

		*coeff = 520681505;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 0);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 1);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 2);
		*coeff = 3685715064;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 3);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 4);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 5);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 6);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 7);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 8);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 9);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 10);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 11);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 12);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 13);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 14);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 15);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 16);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 17);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 18);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 19);
		*coeff = 0;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 20);
		*coeff = 1;
		MPFQ_TAG(poly_setcoef)(field, IRR, coeff, 21);

		MPFQ_TAG(clear)(field, coeff);

		extensionGenerated = 1;
	}
}

/**
 * @brief      Copies an element of GF(q^m) to another one
 *
 * @param[in]  field  The field
 * @param[in]  dest   Destination GF(q^m) element
 * @param[in]  src    Source GF(q^m) element
 */
void ffi_elt_set(MPFQ_FIELD field, ffi_elt dest, ffi_elt src) {
	MPFQ_TAG(poly_set)(field, dest, src);
}

/**
 * @brief      Retrieves a coefficient of the polynomial representing an element of GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  res    GF(q) element (the coefficient)
 * @param[in]  src    GF(q^m) element
 * @param[in]  index  Degree of the coefficient
 */
void ffi_elt_get_coeff(MPFQ_FIELD field, ffi_baseElt res, ffi_elt src, int index) {
	if(index <= ffi_elt_degree(field, src)) {
		MPFQ_TAG(poly_getcoef)(field, res, src, index);
	} else ffi_baseElt_set_zero(field, res);
}

/**
 * @brief      Compares two elements of GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  elt1   First GF(q^m) element
 * @param[in]  elt2   Second GF(q^m) element
 *
 * @return     0 if the elements are equal, 1 if elt1 > elt2, -1 otherwise
 */
int ffi_elt_cmp(MPFQ_FIELD field, ffi_elt elt1, ffi_elt elt2) {
	return MPFQ_TAG(poly_cmp)(field, elt1, elt2);
}

/**
 * @brief      Gets the degree of the polynomial representing an element of GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  elt    GF(q^m) element
 *
 * @return     Degree of the polynomial
 */
int ffi_elt_degree(MPFQ_FIELD field, ffi_elt elt) {
	return MPFQ_TAG(poly_deg)(field, elt);
}

/**
 * @brief      Sets the polynomial representing an element of GF(q^m) to a monic polynomial
 *
 * @param[in]  field  The field
 * @param[in]  dest   Destination GF(q^m) element
 * @param[in]  src    Source GF(q^m) element
 */
void ffi_elt_set_monic(MPFQ_FIELD field, ffi_elt dest, ffi_elt src) {
	MPFQ_TAG(poly_setmonic)(field, dest, src);
}

/**
 * @brief      Multiplies two elements of GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  res    Result of the multiplication
 * @param[in]  elt1   First GF(q^m) element
 * @param[in]  elt2   Second GF(q^m) element
 */
void ffi_elt_mul(MPFQ_FIELD field, ffi_elt res, ffi_elt elt1, ffi_elt elt2) {
	MPFQ_TAG(poly) prod, quotient;
	MPFQ_TAG(poly_init)(field, prod, 1);
	MPFQ_TAG(poly_init)(field, quotient, 1);
	MPFQ_TAG(poly_mul)(field, prod, elt1, elt2);
	if(MPFQ_TAG(poly_deg)(field, prod) > PARAM_M) {
		MPFQ_TAG(poly_divmod)(field, quotient, res, prod, IRR);
	}
	else {
		MPFQ_TAG(poly_set)(field, res, prod);
	}
	MPFQ_TAG(poly_clear)(field, prod);
	MPFQ_TAG(poly_clear)(field, quotient);
}

/**
 * @brief      Multiplies an element of GF(q^m) by an element of GF(q)
 *
 * @param[in]  field    The field
 * @param[in]  res      Result of the multiplication
 * @param[in]  elt      GF(q^m) element
 * @param[in]  baseElt  GF(q) element
 */
void ffi_elt_mul_base(MPFQ_FIELD field, ffi_elt res, ffi_elt elt, ffi_baseElt baseElt) {
	//Peut etre à améliorer
	MPFQ_TAG(poly) basePoly;
	MPFQ_TAG(poly_init)(field, basePoly, 1);
	MPFQ_TAG(poly_setcoef)(field, basePoly, baseElt, 0);
	MPFQ_TAG(poly_mul)(field, res, elt, basePoly);
	MPFQ_TAG(poly_clear)(field, basePoly);
}

/**
 * @brief      Adds two elements of GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  res    Result of the addition
 * @param[in]  elt1   First GF(q^m) element
 * @param[in]  elt2   Second GF(q^m) element
 */
void ffi_elt_add(MPFQ_FIELD field, ffi_elt res, ffi_elt elt1, ffi_elt elt2) {
	MPFQ_TAG(poly_add)(field, res, elt1, elt2);
}

/**
 * @brief      Substracts elt2 to elt1 (in GF(q^m))
 *
 * @param[in]  field  The field
 * @param[in]  res    Result of elt1 - elt2
 * @param[in]  elt1   The element 1
 * @param[in]  elt2   The element 2
 */
void ffi_elt_sub(MPFQ_FIELD field, ffi_elt res, ffi_elt elt1, ffi_elt elt2) {
	MPFQ_TAG(poly_sub)(field, res, elt1, elt2);
}

/**
 * @brief      Inverts an element of GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  res    Inverse of elt
 * @param[in]  elt    GF(q^m) element
 */
void ffi_elt_inv(MPFQ_FIELD field, ffi_elt res, ffi_elt elt) {
	if(ffi_elt_degree(field, elt) == -1) return;
	ffi_elt quotient, r, r2, u, u2, tmp, us, qu;

	MPFQ_TAG(poly_init)(field, quotient, 1);
	MPFQ_TAG(poly_init)(field, r, 1);
	MPFQ_TAG(poly_init)(field, r2, 1);
	MPFQ_TAG(poly_init)(field, u, 1);
	MPFQ_TAG(poly_init)(field, u2, 1);
	MPFQ_TAG(poly_init)(field, tmp, 1);
	MPFQ_TAG(poly_init)(field, us, 1);
	MPFQ_TAG(poly_init)(field, qu, 1);

	MPFQ_TAG(poly_set)(field, r, IRR);
	MPFQ_TAG(poly_set)(field, r2, elt);
	MPFQ_TAG(poly_setcoef_ui)(field, u, 0, 0);
	MPFQ_TAG(poly_setcoef_ui)(field, u2, 1, 0);

	while(MPFQ_TAG(poly_deg)(field, r2) > 0) {
		MPFQ_TAG(poly_divmod)(field, quotient, tmp, r, r2);
		MPFQ_TAG(poly_set)(field, us, u);

		MPFQ_TAG(poly_set)(field, r, r2);
		MPFQ_TAG(poly_set)(field, u, u2);

		MPFQ_TAG(poly_set)(field, r2, tmp);
		MPFQ_TAG(poly_mul)(field, qu, quotient, u2);
		MPFQ_TAG(poly_sub)(field, u2, us, qu);
	}
	MPFQ_TAG(poly_divmod)(field, res, tmp, u2, r2);

	MPFQ_TAG(poly_clear)(field, quotient);
	MPFQ_TAG(poly_clear)(field, r);
	MPFQ_TAG(poly_clear)(field, r2);
	MPFQ_TAG(poly_clear)(field, u);
	MPFQ_TAG(poly_clear)(field, u2);
	MPFQ_TAG(poly_clear)(field, tmp);
	MPFQ_TAG(poly_clear)(field, us);
	MPFQ_TAG(poly_clear)(field, qu);
}

/**
 * @brief      Prints an element of GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  elt    GF(q^m) element
 */
void ffi_elt_print(MPFQ_FIELD field, ffi_elt elt) {
	MPFQ_TAG(poly_print)(field, elt);
}

/**
 * @brief      Clears an element of GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  elt    GF(q^m) element
 */
void ffi_elt_clear(MPFQ_FIELD field, ffi_elt elt) {
	MPFQ_TAG(poly_clear)(field, elt);
}