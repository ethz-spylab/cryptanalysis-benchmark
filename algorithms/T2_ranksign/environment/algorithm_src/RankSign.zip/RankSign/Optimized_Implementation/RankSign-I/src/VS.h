/**
 * \file VS.h
 * \brief Interface for vector spaces over GF(q^m)
 */

#ifndef UTILS_VS
#define UTILS_VS

#include "ffi_field.h"
#include "ffi_elt.h"

typedef struct {
	ffi_elt *vectors;
	int size;
	int alloc_size;
} vectorSpace;

typedef vectorSpace *VS;

VS initVS(MPFQ_FIELD field, int size);
void clearVS(MPFQ_FIELD field, VS space);
void randomVS(MPFQ_FIELD field, VS space);
void randomVSFullRank(MPFQ_FIELD field, VS space);
void printVS(MPFQ_FIELD field, VS space, const char* name);
void swapEltsVS(MPFQ_FIELD field, VS space, int i1, int i2);
VS mulVSByElt(MPFQ_FIELD field, VS space, ffi_elt val);
VS copyVS(MPFQ_FIELD field, VS space);
VS mulVS(MPFQ_FIELD field, VS space1, VS space2);
int rankVS(MPFQ_FIELD field, VS space);
VS directsumVS(MPFQ_FIELD field, VS space1, VS space2);
void gaussVS(MPFQ_FIELD field, VS space);
VS interVS(MPFQ_FIELD field, VS space1, VS space2);

#endif