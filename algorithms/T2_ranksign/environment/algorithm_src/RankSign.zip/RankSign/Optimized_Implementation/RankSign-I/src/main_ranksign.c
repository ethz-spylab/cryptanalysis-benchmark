#include <stdio.h>
#include <stdlib.h>
#include "api.h"
#include "rng.h"
#include "parameters.h"
#include "ffi_vecmat.h"

int main() {
	unsigned long long mlen;
	unsigned long long smlen;

	#ifndef VERBOSE
	unsigned char pk[PUBLICKEY_BYTES];
	unsigned char sk[SECRETKEY_BYTES];
	unsigned char signedMessage[TEST_MESSAGE_LENGTH + SIGNATURE_BYTES];
	unsigned char message[TEST_MESSAGE_LENGTH];
	randombytes(message, TEST_MESSAGE_LENGTH);
	crypto_sign_keypair(pk, sk);
	crypto_sign(signedMessage, &smlen, message, mlen, sk);
	if(crypto_sign_open(message, &mlen, signedMessage, smlen, pk) == 0) printf("Valid signature\n");
	else printf("Invalid signature\n");

	#endif

	#ifdef VERBOSE
	unsigned char pk[PUBLICKEY_BYTES];
	unsigned char sk[SECRETKEY_BYTES];
	unsigned char signedMessage[TEST_MESSAGE_LENGTH + SIGNATURE_BYTES];
	unsigned char message[TEST_MESSAGE_LENGTH];
	randombytes(message, TEST_MESSAGE_LENGTH);
	crypto_sign_keypair(pk, sk);
	crypto_sign(signedMessage, &smlen, message, mlen, sk);
	if(crypto_sign_open(message, &mlen, signedMessage, smlen, pk) == 0) printf("Valid signature\n");
	else printf("Invalid signature\n");
	#endif

	return 0;
}