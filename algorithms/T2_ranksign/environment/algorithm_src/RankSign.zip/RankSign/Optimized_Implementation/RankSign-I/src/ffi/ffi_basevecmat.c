/**
 * \file ffi_basevecmat.c
 * \brief Implementation of ffi_basevecmat.h
 */

#include "ffi_basevecmat.h"
#include "../parameters.h"

/**
 * @brief      Initializes a vector over GF(q)
 *
 * @param[in]  field  The field
 * @param[in]  len    Length of the vector
 *
 * @return     The vector
 */
ffi_basevec ffi_basevec_init(MPFQ_FIELD field, int len) {
	ffi_basevec res = (ffi_basevec)malloc(len * sizeof(ffi_baseElt));
	if(res == NULL) MALLOC_ERROR();
	//Init every ffi_elt
	int i;
	for(i=0 ; i<len ; i++) {
		ffi_baseElt_init(field, res[i]);
	}

	return res;
}

/**
 * @brief      Clears a vector over GF(q)
 *
 * @param[in]  field  The field
 * @param[in]  res    The vector
 * @param[in]  len    The length
 */
void ffi_basevec_clear(MPFQ_FIELD field, ffi_basevec res, int len) {
	int i;
	for(i=0 ; i<len ; i++) {
		ffi_baseElt_clear(field, res[i]);
	}

	free(res);
}

/**
 * @brief      Prints a vector over GF(q)
 *
 * @param[in]  field  The field
 * @param[in]  res    The vector
 * @param[in]  len    The length
 */
void ffi_basevec_print(MPFQ_FIELD field, ffi_basevec res, int len) {
	int i;
	printf("[");
	for(i=0 ; i<len ; i++) {
		ffi_baseElt_print(field, res[i]);
		printf(" ");
	}
	printf("]\n");
}

/**
 * @brief      Sets a vector over GF(q) to random values using NIST randombytes
 *
 * @param[in]  field  The field
 * @param[in]  res    The vector
 * @param[in]  len    The length
 */
void ffi_basevec_set_random(MPFQ_FIELD field, ffi_basevec res, int len) {
	int i;
	for(i=0 ; i<len ; i++) {
		ffi_baseElt_set_random(field, res[i]);
	}
}

/**
 * @brief      Initializes a matrix over GF(q)
 *
 * @param[in]  field    The field
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 *
 * @return     The matrix
 */
ffi_basemat ffi_basemat_init(MPFQ_FIELD field, int rows, int columns) {
	ffi_basemat res = (ffi_basemat)malloc(rows * sizeof(ffi_basevec));
	if(res == NULL) MALLOC_ERROR();
	//Init every ffi_basevec
	int i;
	for(i=0 ; i<rows ; i++) {
		res[i] = ffi_basevec_init(field, columns);
	}

	return res;
}

/**
 * @brief      Clears a matrix over GF(q)
 *
 * @param[in]  field    The field
 * @param[in]  res      The matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_basemat_clear(MPFQ_FIELD field, ffi_basemat res, int rows, int columns) {
	int i;
	for(i=0 ; i<rows ; i++) {
		ffi_basevec_clear(field, res[i], columns);
	}

	free(res);
}

/**
 * @brief      Print a matrix over GF(q)
 *
 * @param[in]  field    The field
 * @param[in]  res      The matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_basemat_print(MPFQ_FIELD field, ffi_basemat res, int rows, int columns) {
	int i;
	printf("[\n");
	for(i=0 ; i<rows ; i++) {
		ffi_basevec_print(field, res[i], columns);
	}
	printf("]\n");
}

/**
 * @brief      Copies a vector over GF(q) into another one
 *
 * @param[in]  field  The field
 * @param[in]  src    The source vector
 * @param[in]  len    The length
 *
 * @return     A copy of src
 */
ffi_basevec ffi_basevec_copy(MPFQ_FIELD field, ffi_basevec src, int len) {
	ffi_basevec res = ffi_basevec_init(field, len);

	int i;
	for(i=0 ; i<len ; i++) {
		ffi_baseElt_set(field, res[i], src[i]);
	}

	return res;
}

/**
 * @brief      Copies a matrix over GF(q) into another one
 *
 * @param[in]  field    The field
 * @param[in]  src      The source matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 *
 * @return     A copy of src
 */
ffi_basemat ffi_basemat_copy(MPFQ_FIELD field, ffi_basemat src, int rows, int columns) {
	ffi_basemat res = (ffi_basemat)malloc(rows * sizeof(ffi_basevec));
	if(res == NULL) MALLOC_ERROR();
	int i;
	for(i=0 ; i<rows ; i++) {
		res[i] = ffi_basevec_copy(field, src[i], columns);
	}

	return res;
}

/**
 * @brief      Sets a matrix over GF(q) to random values
 *
 * @param[in]  field    The field
 * @param[in]  res      The matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_basemat_set_random(MPFQ_FIELD field, ffi_basemat res, int rows, int columns) {
	int i;
	for(i=0 ; i<rows ; i++) {
		ffi_basevec_set_random(field, res[i], columns);
	}
}

/**
 * @brief      Multiplies two matrices over GF(q)
 *
 * @param[in]  field     The field
 * @param[in]  res       The resource
 * @param[in]  A1        First matrix
 * @param[in]  A2        Second matrix
 * @param[in]  rows1     Rows of A1
 * @param[in]  columns1  Columns of A1
 * @param[in]  rows2     Rows of A2
 * @param[in]  columns2  Columns of A2
 */
void ffi_basemat_prod(MPFQ_FIELD field, ffi_basemat res, ffi_basemat A1, ffi_basemat A2, int rows1, int columns1, int rows2, int columns2) {
	if(columns1 != rows2) return;

	int i, j, k;
	ffi_baseElt tmp;
	ffi_baseElt_init(field, tmp);

	for(i=0 ; i<rows1 ; i++) {
		for(j=0 ; j<columns2 ; j++) {
			ffi_baseElt_set_zero(field, res[i][j]);
			for(k=0 ; k<columns1 ; k++) {
				ffi_baseElt_mul(field, tmp, A1[i][k], A2[k][j]);
				ffi_baseElt_add(field, res[i][j], res[i][j], tmp);
			}
		}
	}

	ffi_baseElt_clear(field, tmp);
}

/**
 * @brief      Multiplies a matrix and a vector over GF(q)
 *
 * @param[in]  field    The field
 * @param[in]  res      Vector = A.V^t
 * @param[in]  A        The matrix
 * @param[in]  V        The vector
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_basemat_basevec_prod(MPFQ_FIELD field, ffi_basevec res, ffi_basemat A, ffi_basevec V, int rows, int columns) {
	int i, j;
	ffi_baseElt tmp;
	ffi_baseElt_init(field, tmp);

	for(i=0 ; i<rows ; i++) {
		ffi_baseElt_set_zero(field, res[i]);
		for(j=0 ; j<columns ; j++) {
			ffi_baseElt_mul(field, tmp, A[i][j], V[j]);
			ffi_baseElt_add(field, res[i], res[i], tmp);
		}
	}

	ffi_baseElt_clear(field, tmp);
}

/**
 * @brief      Inverts a matrix over GF(q)
 *
 * @param[in]  field    The field
 * @param[in]  dest     Inverse of src
 * @param[in]  src      The source matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 *
 * @return     -1 if src is not invertible, 0 otherwise
 */
int ffi_basemat_inv(MPFQ_FIELD field, ffi_basemat dest, ffi_basemat src, int rows, int columns) {
	if(rows != columns) return -1;

	int i, j;
	ffi_baseElt tmp;
	ffi_baseElt_init(field, tmp);
	ffi_basemat tmpMatrix = ffi_basemat_copy(field, src, rows, columns);

	//Write identity in dest. Must be initialized with zeros
	for(i=0 ; i<rows ; i++) {
		for(j=0 ; j<columns ; j++) {
			if(i==j) ffi_baseElt_set_one(field, dest[i][j]);
			else ffi_baseElt_set_zero(field, dest[i][j]);
		}
	}

	//Inverse with Gauss
	//Echelon form
	for(i=0 ; i<rows ; i++) {
		int pivot = -1;
		for(j=i ; j<rows ; j++) {
			if(!(ffi_baseElt_is_zero(field, tmpMatrix[j][i]))) {
				pivot = j;
				break;
			}
		}
		//If we don't find a pivot on column j, then the matrix isn't invertible
		if(pivot == -1) {
			ffi_baseElt_clear(field, tmp);
			ffi_basemat_clear(field, tmpMatrix, rows, columns);
			return -1;
		}

		//Swap rows
		if(pivot != i) {
			ffi_basemat_swap_rows(field, tmpMatrix, i, pivot);
			ffi_basemat_swap_rows(field, dest, i, pivot);
		}

		//Invert so we have "1" at the beginning of the line
		ffi_baseElt_inv(field, tmp, tmpMatrix[i][i]);
		ffi_basemat_mul_row_const(field, tmpMatrix, i, tmp, columns);
		ffi_basemat_mul_row_const(field, dest, i, tmp, columns);

		//Modify other lines
		for(j=i+1 ; j<rows ; j++) {
			ffi_baseElt_set(field, tmp, tmpMatrix[j][i]);
			ffi_basemat_row_sub(field, tmpMatrix, i, j, tmp, columns);
			ffi_basemat_row_sub(field, dest, i, j, tmp, columns);
		}
	}

	//Reduced Echelon form
	for(i=columns-1 ; i>0 ; i--) {
		for(j=i-1 ; j>=0 ; j--) {
			ffi_basemat_row_sub(field, dest, i, j, tmpMatrix[j][i], columns);
			ffi_basemat_row_sub(field, tmpMatrix, i, j, tmpMatrix[j][i], columns);
		}
	}

	ffi_basemat_clear(field, tmpMatrix, rows, columns);
	ffi_baseElt_clear(field, tmp);

	return 0;
}

/**
 * @brief      Swaps two rows of a matrix over GF(q)
 *
 * @param[in]  field  The field
 * @param[in]  res    The matrix
 * @param[in]  row1   The row 1
 * @param[in]  row2   The row 2
 */
void ffi_basemat_swap_rows(MPFQ_FIELD field, ffi_basemat res, int row1, int row2) {
	ffi_basevec tmp = res[row1];
	res[row1] = res[row2];
	res[row2] = tmp;
}

/**
 * @brief      Multiplies a row of a matrix by an element of GF(q)
 *
 * @param[in]  field    The field
 * @param[in]  res      The matrix
 * @param[in]  row      The row
 * @param[in]  c        GF(q) element
 * @param[in]  columns  The columns
 */
void ffi_basemat_mul_row_const(MPFQ_FIELD field, ffi_basemat res, int row, ffi_baseElt c, int columns) {
	int i;
	for(i=0 ; i<columns ; i++) {
		ffi_baseElt_mul(field, res[row][i], res[row][i], c);
	}
}

/**
 * @brief      Substracts c * row1 to row2
 *
 * @param[in]  field    The field
 * @param[in]  res      The matrix
 * @param[in]  row1     The row 1
 * @param[in]  row2     The row 2
 * @param[in]  c        GF(q) element
 * @param[in]  columns  The columns
 */
void ffi_basemat_row_sub(MPFQ_FIELD field, ffi_basemat res, int row1, int row2, ffi_baseElt c, int columns) {
	int i;
	ffi_baseElt tmp;
	ffi_baseElt_init(field, tmp);
	for(i=0 ; i<columns ; i++) {
		ffi_baseElt_mul(field, tmp, res[row1][i], c);
		ffi_baseElt_sub(field, res[row2][i], res[row2][i], tmp);
	}
	ffi_baseElt_clear(field, tmp);
}

/**
 * @brief      Parses a matrix over GF(q) into a string
 *
 * @param[in]  field    The field
 * @param[in]  A        The matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 * @param      string   The string
 */
void ffi_basemat_to_string(MPFQ_FIELD field, ffi_basemat A, int rows, int columns, unsigned char* string) {
	int i, j;

	for(i=0 ; i<rows ; i++) {
		for(j=0 ; j<columns ; j++) {
			ffi_baseElt_to_string(field, A[i][j], string + FFI_BASEELT_BYTES * (i * columns + j));
		}
	}
}

/**
 * @brief      Parses a string into a matrix over GF(q)
 *
 * @param[in]  field    The field
 * @param[in]  A        The matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 * @param      string   The string
 */
void ffi_basemat_from_string(MPFQ_FIELD field, ffi_basemat A, int rows, int columns, const unsigned char* string) {
	int i, j;

	for(i=0 ; i<rows ; i++) {
		for(j=0 ; j<columns ; j++) {
			ffi_baseElt_from_string(field, A[i][j], string + FFI_BASEELT_BYTES * (i * columns + j));
		}
	}
}