/**
 * \file ffi_basevecmat.h
 * \brief Interface for vectors and matrices over GF(q)
 */

#ifndef BASEVECMAT_H
#define BASEVECMAT_H

#include "ffi_elt.h"
#include "ffi_field.h"

typedef ffi_baseElt* ffi_basevec;
typedef ffi_basevec* ffi_basemat;

ffi_basevec ffi_basevec_init(MPFQ_FIELD field, int len);
void ffi_basevec_clear(MPFQ_FIELD field, ffi_basevec res, int len);
void ffi_basevec_print(MPFQ_FIELD field, ffi_basevec res, int len);
ffi_basevec ffi_basevec_copy(MPFQ_FIELD field, ffi_basevec src, int len);

void ffi_basevec_set_random(MPFQ_FIELD field, ffi_basevec res, int len);

ffi_basemat ffi_basemat_init(MPFQ_FIELD field, int rows, int columns);
void ffi_basemat_clear(MPFQ_FIELD field, ffi_basemat res, int rows, int columns);
void ffi_basemat_print(MPFQ_FIELD field, ffi_basemat res, int rows, int columns);
ffi_basemat ffi_basemat_copy(MPFQ_FIELD field, ffi_basemat src, int rows, int columns);

void ffi_basemat_set_random(MPFQ_FIELD field, ffi_basemat res, int rows, int columns);
void ffi_basemat_prod(MPFQ_FIELD field, ffi_basemat res, ffi_basemat A1, ffi_basemat A2, int rows1, int columns1, int rows2, int columns2);
void ffi_basemat_basevec_prod(MPFQ_FIELD field, ffi_basevec res, ffi_basemat A, ffi_basevec V, int rows, int columns);
int ffi_basemat_inv(MPFQ_FIELD field, ffi_basemat dest, ffi_basemat src, int rows, int columns);

//Utility for Gauss
void ffi_basemat_swap_rows(MPFQ_FIELD field, ffi_basemat res, int row1, int row2);
void ffi_basemat_mul_row_const(MPFQ_FIELD field, ffi_basemat res, int row, ffi_baseElt c, int columns);
void ffi_basemat_row_sub(MPFQ_FIELD field, ffi_basemat res, int row1, int row2, ffi_baseElt c, int columns);

//Parsing
void ffi_basemat_to_string(MPFQ_FIELD field, ffi_basemat A, int rows, int columns, unsigned char* string);
void ffi_basemat_from_string(MPFQ_FIELD field, ffi_basemat A, int rows, int columns, const unsigned char* string);

#endif