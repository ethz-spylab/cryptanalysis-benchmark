/**
 * \file VS.c
 * \brief Implementation of VS.h
 */

#include <stdio.h>
#include <stdlib.h>
#include "VS.h"
#include "parameters.h"


/**
 * @brief      Allocates memory for a vector space of dimension size
 *
 * @param[in]  field   The field
 * @param[in]  size  The size
 *
 * @return     Vector space
 */
VS initVS(MPFQ_FIELD field, int size) {
	int i;
	VS space;
	space = malloc(sizeof(vectorSpace));
	if(space==NULL) MALLOC_ERROR();
	space->vectors = (ffi_elt *)malloc(sizeof(ffi_elt) * size);
	if(space->vectors == NULL) MALLOC_ERROR();
	for(i=0 ; i<size ; i++) {
		ffi_elt_init(field, space->vectors[i]);
	}
	space->size = size;
	space->alloc_size = size;

	return space;
}

/**
 * @brief      Clears memory for a vector space
 *
 * @param[in]  field  The field
 * @param[in]  space  The vector space
 */
void clearVS(MPFQ_FIELD field, VS space) {
	int i;
	if (space == NULL) return;
	for(i=0 ; i<space->alloc_size ; i++) {
		ffi_elt_clear(field, space->vectors[i]);
	}
	free(space->vectors);
	free(space);
}

/**
 * @brief      Sets a vector space to random values
 *
 * @param[in]  field  The field
 * @param[in]  space  The vector space
 */
void randomVS(MPFQ_FIELD field, VS space) {
	int i;
	for(i=0 ; i<space->size ; i++) {
		ffi_elt_set_random(field, space->vectors[i]);
	}
}

/**
 * @brief      Sets a vector space to a random vector space of rank space->size
 *
 * @param[in]  field  The field
 * @param[in]  space  The vector space
 */
void randomVSFullRank(MPFQ_FIELD field, VS space) {
	do {
		randomVS(field, space);
	} while(rankVS(field, space) < space->size);
}

/**
 * @brief      Prints a vector space
 *
 * @param[in]  field  The field
 * @param[in]  space  The vector space
 * @param[in]  name   The name
 */
void printVS(MPFQ_FIELD field, VS space, const char* name) {
	int i;
	if(space == NULL) {
		printf("VS %s : NULL\n", name);
		return;
	}
	printf("VS %s : [\n", name);
	for(i=0 ; i<space->size ; i++) {
		printf("    ");
		ffi_elt_print(field, space->vectors[i]);
		printf("\n");
	}
	printf("]\n\n");
}

/**
 * @brief      Swaps two elements of a vector space (useful in Gauss)
 *
 * @param[in]  field  The field
 * @param[in]  space  The vector space
 * @param[in]  i1     Index of first element
 * @param[in]  i2     Index of second element
 */
void swapEltsVS(MPFQ_FIELD field, VS space, int i1, int i2) {
	ffi_elt tmp;
	ffi_elt_init(field, tmp);

	ffi_elt_set(field, tmp, space->vectors[i1]);
	ffi_elt_set(field, space->vectors[i1], space->vectors[i2]);
	ffi_elt_set(field, space->vectors[i2], tmp);

	ffi_elt_clear(field, tmp);
}

/**
 * @brief      Multiplies each element of a vector space by an element of GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  space  The vector space
 * @param[in]  val    The element of GF(q^m)
 *
 * @return     Vector space multiplied by val
 */
VS mulVSByElt(MPFQ_FIELD field, VS space, ffi_elt val) {
	if(space == NULL) return NULL;
	VS resultat = initVS(field, space->size);

	int i;
	for(i=0 ; i<space->size ; i++) {
		ffi_elt_mul(field, resultat->vectors[i], val, space->vectors[i]);
	}

	return resultat;
}

/**
 * @brief      Copies a vector space
 *
 * @param[in]  field  The field
 * @param[in]  space  The vector space
 *
 * @return     Copy of space
 */
VS copyVS(MPFQ_FIELD field, VS space) {
	VS resultat = initVS(field, space->size);
	int i;
	for(i=0 ; i<resultat->size ; i++) {
		ffi_elt_set(field, resultat->vectors[i], space->vectors[i]);
	}

	return resultat;
}

/**
 * @brief      Performs the tensor product of two vector spaces
 *
 * @param[in]  field   The field
 * @param[in]  space1  The first vector space
 * @param[in]  space2  The second vector space
 *
 * @return     Tensor product of space1 and space2
 */
VS mulVS(MPFQ_FIELD field, VS space1, VS space2) {
	if(space1 == NULL || space2 == NULL) return NULL;
	int i, j;
	VS resultat = initVS(field, space1->size * space2->size);
	for(i=0 ; i<space1->size ; i++) {
		for(j=0 ; j<space2->size ; j++) {
			ffi_elt_mul(field, resultat->vectors[i*space2->size+j], space1->vectors[i], space2->vectors[j]);
		}
	}

	return resultat;
}

/**
 * @brief      Computes the rank of a vector space
 *
 * @param[in]  field  The field
 * @param[in]  space  The vector space
 *
 * @return     Rank of space
 */
int rankVS(MPFQ_FIELD field, VS space) {
	if(space == NULL) return 0;
	gaussVS(field, space);

	return space->size;
}

/**
 * @brief      Computes the direct sum of VS1 and VS2
 *
 * @param[in]  field   The field
 * @param[in]  space1  The first vector space
 * @param[in]  space2  The second vector space
 *
 * @return     Direct sum of space1 and space2
 */
VS directsumVS(MPFQ_FIELD field, VS space1, VS space2) {
	if (space1 == NULL && space2 == NULL) return NULL;
	if (space1 == NULL) return copyVS(field, space2);
	if (space2 == NULL) return copyVS(field, space1);
	VS resultat = initVS(field, space1->size + space2->size);

	int i;
	for(i=0 ; i<space1->size ; i++) {
		ffi_elt_set(field, resultat->vectors[i], space1->vectors[i]);
	}
	for(i=0 ; i<space2->size ; i++) {
		ffi_elt_set(field, resultat->vectors[space1->size + i], space2->vectors[i]);
	}

	return resultat;
}

void gaussVS(MPFQ_FIELD field, VS space) {
	if (space == NULL) return;
	int i, j;

	ffi_baseElt coeff;
	ffi_elt difference;
	int degre;

	ffi_baseElt_init(field, coeff);
	ffi_elt_init(field, difference);

	for(i=0 ; i<space->size ; i++) {
		//Pivot computation
		int pivot = i;
		for(j=pivot + 1 ; j<space->size ; j++) {
			if(ffi_elt_cmp(field, space->vectors[j], space->vectors[pivot]) > 0) {
				pivot = j;
			}
		}

		//End if only empty lines
		if(ffi_elt_degree(field, space->vectors[pivot]) == -1) {
			//Update VS size
			space->size = pivot;
			ffi_baseElt_clear(field, coeff);
			ffi_elt_clear(field, difference);
			return;
		}

		//Swap rows
		swapEltsVS(field, space, i, pivot);
		ffi_elt tmp;
		ffi_elt_init(field, tmp);
		ffi_elt_set(field, tmp, space->vectors[i]);
		ffi_elt_set_monic(field, space->vectors[i], space->vectors[i]);
		degre = ffi_elt_degree(field, space->vectors[i]);

		ffi_elt_get_coeff(field, coeff, space->vectors[i], degre);
		ffi_baseElt_inv(field, coeff, coeff);

		ffi_elt_clear(field, tmp);

		//Update other lines
		for(j=i+1 ; j<space->size ; j++) {
			if(ffi_elt_degree(field, space->vectors[j]) < degre) continue;
			ffi_elt_get_coeff(field, coeff, space->vectors[j], degre);
			ffi_elt_mul_base(field, difference, space->vectors[i], coeff);
			ffi_elt_sub(field, space->vectors[j], space->vectors[j], difference);
		}
	}

	ffi_baseElt_clear(field, coeff);
	ffi_elt_clear(field, difference);
}

/**
 * @brief      Computes the intersection of two vector spaces
 *
 * @param[in]  field   The field
 * @param[in]  space1  The first vector space
 * @param[in]  space2  The second vector space
 *
 * @return     Intersection of space1 and space2
 */
VS interVS(MPFQ_FIELD field, VS space1, VS space2) {
	if(space1 == NULL || space2 == NULL) return NULL;
	VS sommeDirecte = directsumVS(field, space1, space2);
	VS resultat = initVS(field, space1->size + space2->size);

	ffi_baseElt coeff;
	ffi_elt difference;
	int degre;

	ffi_baseElt_init(field, coeff);
	ffi_elt_init(field, difference);
	//space1 | 0
	int i, j;
	for(i=0 ; i<space1->size ; i++) {
		ffi_elt_set(field, resultat->vectors[i], space1->vectors[i]);
	}

	for(i=0 ; i<sommeDirecte->size ; i++) {
		int pivot = i;
		for(j=pivot + 1 ; j<sommeDirecte->size ; j++) {
			if(ffi_elt_cmp(field, sommeDirecte->vectors[j], sommeDirecte->vectors[pivot]) > 0) {
				pivot = j;
			}
		}
		if(ffi_elt_degree(field, sommeDirecte->vectors[pivot]) == -1) break;

		swapEltsVS(field, sommeDirecte, i, pivot);
		swapEltsVS(field, resultat, i, pivot);

		degre = ffi_elt_degree(field, sommeDirecte->vectors[i]);
		ffi_elt_get_coeff(field, coeff, sommeDirecte->vectors[i], degre);
		ffi_baseElt_inv(field, coeff, coeff);
		ffi_elt_mul_base(field, sommeDirecte->vectors[i], sommeDirecte->vectors[i], coeff);
		ffi_elt_mul_base(field, resultat->vectors[i], resultat->vectors[i], coeff);
		for(j=i+1 ; j<sommeDirecte->size ; j++) {
			if(ffi_elt_degree(field, sommeDirecte->vectors[j]) >= degre) {
				ffi_elt_get_coeff(field, coeff, sommeDirecte->vectors[j], degre);
				ffi_elt_mul_base(field, difference, sommeDirecte->vectors[i], coeff);
				ffi_elt_sub(field, sommeDirecte->vectors[j], sommeDirecte->vectors[j], difference);

				ffi_elt_mul_base(field, difference, resultat->vectors[i], coeff);
				ffi_elt_sub(field, resultat->vectors[j], resultat->vectors[j], difference);
			}
		}
	}

	int index = -1;
	for(i=0 ; i<sommeDirecte->size ; i++) {
		if(ffi_elt_degree(field, sommeDirecte->vectors[i]) == -1) {
			index = i;
			break;
		}
	}
	if(index == -1) {
		ffi_baseElt_clear(field, coeff);
		ffi_elt_clear(field, difference);
		clearVS(field, sommeDirecte);
		clearVS(field, resultat);
		return NULL;
	}

	int index2 = resultat->size;

	int dimInter = index2 - index;

	VS intersection = initVS(field, dimInter);
	for(i=0 ; i<dimInter ; i++) {
		ffi_elt_set(field, intersection->vectors[i], resultat->vectors[index + i]);
	}

	ffi_baseElt_clear(field, coeff);
	ffi_elt_clear(field, difference);
	clearVS(field, sommeDirecte);
	clearVS(field, resultat);

	return intersection;
}