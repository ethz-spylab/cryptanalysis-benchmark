/**
 * \file ffi_vecmat.c
 * \brief Implementation of ffi_vecmat.h
 */

#include "ffi_vecmat.h"
#include "../parameters.h"

/**
 * @brief      Initializes a vector over GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  len    Length of the vector
 *
 * @return     The vector
 */
ffi_vec ffi_vec_init(MPFQ_FIELD field, int len) {
	ffi_vec res = (ffi_vec)malloc(len * sizeof(ffi_elt));
	if(res==NULL) MALLOC_ERROR();
	//Init every ffi_elt
	int i;
	for(i=0 ; i<len ; i++) {
		ffi_elt_init(field, res[i]);
	}

	return res;
}

/**
 * @brief      Clears a vector over GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  res    The vector
 * @param[in]  len    The length
 */
void ffi_vec_clear(MPFQ_FIELD field, ffi_vec res, int len) {
	int i;
	for(i=0 ; i<len ; i++) {
		ffi_elt_clear(field, res[i]);
	}

	free(res);
}

/**
 * @brief      Prints a vector over GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  res    The vector
 * @param[in]  len    The length
 */
void ffi_vec_print(MPFQ_FIELD field, ffi_vec res, int len) {
	int i;
	printf("[");
	for(i=0 ; i<len ; i++) {
		ffi_elt_print(field, res[i]);
		printf(" ");
	}
	printf("]\n");
}


/**
 * @brief      Adds two vectors over GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  res    Result of V1 + V2
 * @param[in]  V1     The first vector
 * @param[in]  V2     The second vector
 * @param[in]  len    The length
 */
void ffi_vec_add(MPFQ_FIELD field, ffi_vec res, ffi_vec V1, ffi_vec V2, int len) {
	int i;
	for(i=0 ; i<len ; i++) {
		ffi_elt_add(field, res[i], V1[i], V2[i]);
	}
}

/**
 * @brief      Substracts two vector over GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  res    Result of V1 - V2
 * @param[in]  V1     The first vector
 * @param[in]  V2     The second vector
 * @param[in]  len    The length
 */
void ffi_vec_sub(MPFQ_FIELD field, ffi_vec res, ffi_vec V1, ffi_vec V2, int len) {
	int i;
	for(i=0 ; i<len ; i++) {
		ffi_elt_sub(field, res[i], V1[i], V2[i]);
	}
}

/**
 * @brief      Multiplies a vector over GF(q^m) by a matrix over GF(q^m), transposed
 *
 * @param[in]  field    The field
 * @param[in]  res      Result of V.A^t
 * @param[in]  V        Vector over GF(q^m)
 * @param[in]  A        Matrix over GF(q^m)
 * @param[in]  len      The length
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_vec_prod_mat(MPFQ_FIELD field, ffi_vec res, ffi_vec V, ffi_mat A, int len, int rows, int columns) {
	if(len != columns) return;
	int i, j;

	ffi_elt tmp;
	ffi_elt_init(field, tmp);

	for(i=0 ; i<rows ; i++) {
		for(j=columns-1 ; j>=0 ; j--) {
			ffi_elt_mul(field, tmp, V[j], A[i][j]);
			ffi_elt_add(field, res[i], res[i], tmp);
		}
	}

	ffi_elt_clear(field, tmp);
}

/**
 * @brief      Multiplies a vector over GF(q^m) by a matrix over GF(q), transposed
 *
 * @param[in]  field    The field
 * @param[in]  res      Result of V.A^t
 * @param[in]  V        Vector over GF(q^m)
 * @param[in]  A        Matrix over GF(q)
 * @param[in]  len      The length
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_vec_prod_basemat(MPFQ_FIELD field, ffi_vec res, ffi_vec V, ffi_basemat A, int len, int rows, int columns) {
	if(len != columns) return;
	int i, j;

	ffi_elt tmp;
	ffi_elt_init(field, tmp);

	for(i=0 ; i<rows ; i++) {
		for(j=columns-1 ; j>=0 ; j--) {
			ffi_elt_mul_base(field, tmp, V[j], A[i][j]);
			ffi_elt_add(field, res[i], res[i], tmp);
		}
	}

	ffi_elt_clear(field, tmp);
}

/**
 * @brief      Multiplies a matrix over GF(q) by a vector over GF(q^m)
 *
 * @param[in]  field    The field
 * @param[in]  res      The resource
 * @param[in]  A        Matrix over GF(q)
 * @param[in]  V        Vector over GF(q^m)
 * @param[in]  len      The length
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_basemat_vec_prod(MPFQ_FIELD field, ffi_vec res, ffi_basemat A, ffi_vec V, int len, int rows, int columns) {
	if(len != columns) return;
	int i, j;

	ffi_elt tmp;
	ffi_elt_init(field, tmp);

	for(i=0 ; i<rows ; i++) {
		for(j=0 ; j<columns ; j++) {
			printf("%d:%d\n", i, j);
			ffi_elt_mul_base(field, tmp, V[j], A[i][j]);
			ffi_elt_add(field, res[i], res[i], tmp);
		}
	}

	ffi_elt_clear(field, tmp);
}

/**
 * @brief      Sets a vector over GF(q^m) to random values using NIST randombytes
 *
 * @param[in]  field  The field
 * @param[in]  res    The vector
 * @param[in]  len    The length
 */
void ffi_vec_set_random(MPFQ_FIELD field, ffi_vec res, int len) {
	int i;
	for(i=0 ; i<len ; i++) {
		ffi_elt_set_random(field, res[i]);
	}
}

/**
 * @brief      Computes the coordinates of src in the basis support, and puts them in res
 *
 * @param[in]  field      The field
 * @param[in]  src        The source vector
 * @param[in]  len        The length of source
 * @param[in]  support    The support
 * @param[in]  dimension  The dimension of support
 * @param[in]  res        The coordinates
 *
 * @return     0 if every element of src was in support, 1 otherwise
 */
int ffi_basevec_from_support(MPFQ_FIELD field, ffi_vec src, int len, VS support, int dimension, ffi_basevec res) {
	ffi_baseElt tmp;
	ffi_baseElt_init(field, tmp);

	ffi_basemat system, invSystem;
	ffi_basevec equations;
	ffi_basevec solution;
	system = ffi_basemat_init(field, PARAM_M, dimension);
	invSystem = ffi_basemat_init(field, PARAM_M, PARAM_M);
	equations = ffi_basevec_init(field, PARAM_M);
	solution = ffi_basevec_init(field, PARAM_M);

	int i,j;

	//Build the system matrix
	for(i=0 ; i<PARAM_M ; i++) { //Rows
		for(j=0 ; j<dimension ; j++) { //Columns
			ffi_elt_get_coeff(field, tmp, support->vectors[j], i);
			ffi_baseElt_set(field, system[i][j], tmp);
		}
	}

	/*** First compute the matrix invSystem s.t invSystem * system = identity ***/
	//Write identity in invSystem. Must be initialized with zeros
	for(i=0 ; i<PARAM_M ; i++) {
		for(j=0 ; j<PARAM_M ; j++) {
			if(i==j) ffi_baseElt_set_one(field, invSystem[i][j]);
			else ffi_baseElt_set_zero(field, invSystem[i][j]);
		}
	}

	//Echelon form
	for(i=0 ; i<dimension ; i++) {
		int pivot = -1;
		for(j=i ; j<PARAM_M ; j++) {
			if(!(ffi_baseElt_is_zero(field, system[j][i]))) {
				pivot = j;
				break;
			}
		}
		//If we don't find a pivot on column j, then the matrix isn't invertible
		if(pivot == -1) {
			ffi_basemat_clear(field, system, PARAM_M, dimension);
			ffi_basemat_clear(field, invSystem, PARAM_M, PARAM_M);
			ffi_basevec_clear(field, equations, PARAM_M);
			ffi_basevec_clear(field, solution, dimension);

			ffi_baseElt_clear(field, tmp);
			return 1;
		}

		//Swap rows
		if(pivot != i) {
			ffi_basemat_swap_rows(field, system, i, pivot);
			ffi_basemat_swap_rows(field, invSystem, i, pivot);
		}

		//Invert so we have "1" at the beginning of the line
		ffi_baseElt_inv(field, tmp, system[i][i]);
		ffi_basemat_mul_row_const(field, system, i, tmp, dimension);
		ffi_basemat_mul_row_const(field, invSystem, i, tmp, dimension);

		//Modify other lines
		for(j=i+1 ; j<PARAM_M ; j++) {
			ffi_baseElt_set(field, tmp, system[j][i]);
			ffi_basemat_row_sub(field, system, i, j, tmp, dimension);
			ffi_basemat_row_sub(field, invSystem, i, j, tmp, dimension);
		}
	}

	//Reduced Echelon form
	for(i=dimension-1 ; i>0 ; i--) {
		for(j=i-1 ; j>=0 ; j--) {
			ffi_basemat_row_sub(field, invSystem, i, j, system[j][i], dimension);
			ffi_basemat_row_sub(field, system, i, j, system[j][i], dimension);
		}
	}

	/****************************************************************************/

	//For each coordinates of src, we need to multiply invSystem by this vector
	for(i=0 ; i<len ; i++) {
		//Build equations
		for(j=0 ; j<PARAM_M ; j++) {
		    ffi_elt_get_coeff(field, tmp, src[i], j);
		    ffi_baseElt_set(field, equations[j], tmp);
		}

		//Solve for solution
		ffi_basemat_basevec_prod(field, solution, invSystem, equations, PARAM_M, PARAM_M);

		//If every position >= dimension in solution equals 0 then src[i] is in support
		for(j=dimension ; j<PARAM_M ; j++) {
			if(!ffi_baseElt_is_zero(field, solution[j])) {
				ffi_basemat_clear(field, system, PARAM_M, dimension);
				ffi_basemat_clear(field, invSystem, PARAM_M, PARAM_M);
				ffi_basevec_clear(field, equations, PARAM_M);
				ffi_basevec_clear(field, solution, PARAM_M);

				ffi_baseElt_clear(field, tmp);

				return 1;
			}
		}

		for(j=0 ; j<dimension ; j++) {
			ffi_baseElt_set(field, res[i * dimension + j], solution[j]);
		}
	}

	ffi_basemat_clear(field, system, PARAM_M, dimension);
	ffi_basemat_clear(field, invSystem, PARAM_M, PARAM_M);
	ffi_basevec_clear(field, equations, PARAM_M);
	ffi_basevec_clear(field, solution, PARAM_M);

	ffi_baseElt_clear(field, tmp);

	return 0;
}

/**
 * @brief      Computes a vector over GF(q^m) from a support and the coordinates of the vector in the basis of this support
 *
 * @param[in]  field      The field
 * @param[in]  src        The coordinates
 * @param[in]  len        The length
 * @param[in]  support    The support
 * @param[in]  dimension  The dimension of the support
 *
 * @return     The vector over GF(q^m)
 */
ffi_vec ffi_vec_from_basevec(MPFQ_FIELD field, ffi_basevec src, int len, VS support, int dimension) {
	ffi_vec res;
	res = ffi_vec_init(field, len / dimension);

	ffi_elt tmp;
	ffi_elt_init(field, tmp);

	int i, j;
	for(i=0 ; i<len/dimension ; i++) {
		for(j=0 ; j<dimension ; j++) {
			ffi_elt_mul_base(field, tmp, support->vectors[j], src[i * dimension + j]);
			ffi_elt_add(field, res[i], res[i], tmp);
		}
	}

	ffi_elt_clear(field, tmp);

	return res;
}

/**
 * @brief      Initializes a matrix over GF(q^m)
 *
 * @param[in]  field    The field
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 *
 * @return     The matrix
 */
ffi_mat ffi_mat_init(MPFQ_FIELD field, int rows, int columns) {
	ffi_mat res = (ffi_mat)malloc(rows * sizeof(ffi_vec));
	if(res == NULL) MALLOC_ERROR();
	//Init every ffi_vec
	int i;
	for(i=0 ; i<rows ; i++) {
		res[i] = ffi_vec_init(field, columns);
	}

	return res;
}

/**
 * @brief      Clears a matrix over GF(q^m)
 *
 * @param[in]  field    The field
 * @param[in]  res      The matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_mat_clear(MPFQ_FIELD field, ffi_mat res, int rows, int columns) {
	int i;
	for(i=0 ; i<rows ; i++) {
		ffi_vec_clear(field, res[i], columns);
	}

	free(res);
}

/**
 * @brief      Print a matrix over GF(q^m)
 *
 * @param[in]  field    The field
 * @param[in]  res      The matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_mat_print(MPFQ_FIELD field, ffi_mat res, int rows, int columns) {
	int i;
	printf("[\n");
	for(i=0 ; i<rows ; i++) {
		ffi_vec_print(field, res[i], columns);
	}
	printf("]\n");
}

/**
 * @brief      Copies a vector over GF(q^m) into another one
 *
 * @param[in]  field  The field
 * @param[in]  src    The source vector
 * @param[in]  len    The length
 *
 * @return     A copy of src
 */
ffi_vec ffi_vec_copy(MPFQ_FIELD field, ffi_vec src, int len) {
	ffi_vec res = ffi_vec_init(field, len);

	int i;
	for(i=0 ; i<len ; i++) {
		ffi_elt_set(field, res[i], src[i]);
	}

	return res;
}

/**
 * @brief      Concatenates two vectors over GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  V1     The first vector
 * @param[in]  V2     The second vector
 * @param[in]  len1   The length of V1
 * @param[in]  len2   The length of V2
 *
 * @return     Concatenation of V1 and V2
 */
ffi_vec ffi_vec_concat(MPFQ_FIELD field, ffi_vec V1, ffi_vec V2, int len1, int len2) {
	ffi_vec res = ffi_vec_init(field, len1 + len2);	

	int i;

	for(i=0 ; i<len1 ; i++) {
		ffi_elt_set(field, res[i], V1[i]);
	}

	for(i=0 ; i<len2 ; i++) {
		ffi_elt_set(field, res[i + len1], V2[i]);
	}

	return res;
}

/**
 * @brief      Concatenates two matrices over GF(q^m) (side by side)
 *
 * @param[in]  field     The field
 * @param[in]  A1        The first matrix
 * @param[in]  A2        The second matrix
 * @param[in]  rows1     The rows of A1
 * @param[in]  columns1  The columns of A1
 * @param[in]  rows2     The rows of A2
 * @param[in]  columns2  The columns of A2
 *
 * @return     Concatenation of A1 and A2
 */
ffi_mat ffi_mat_concat(MPFQ_FIELD field, ffi_mat A1, ffi_mat A2, int rows1, int columns1, int rows2, int columns2) {
	if(rows1 != rows2) return NULL;

	ffi_mat res = ffi_mat_init(field, rows1, columns1 + columns2);
	int i, j;

	for(i=0 ; i<rows1 ; i++) {
		for(j=0 ; j<columns1 ; j++) {
			ffi_elt_set(field, res[i][j], A1[i][j]);
		}
	}

	for(i=0 ; i<rows1 ; i++) {
		for(j=0 ; j<columns2 ; j++) {
			ffi_elt_set(field, res[i][j + columns1], A2[i][j]);
		}
	}

	return res;
}

/**
 * @brief      Copies a matrix over GF(q^m) into another one
 *
 * @param[in]  field    The field
 * @param[in]  src      The source matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 *
 * @return     A copy of src
 */
ffi_mat ffi_mat_copy(MPFQ_FIELD field, ffi_mat src, int rows, int columns) {
	ffi_mat res = (ffi_mat)malloc(rows * sizeof(ffi_vec));
	if(res == NULL) MALLOC_ERROR();
	int i;
	for(i=0 ; i<rows ; i++) {
		res[i] = ffi_vec_copy(field, src[i], columns);
	}

	return res;
}

/**
 * @brief      Sets a matrix over GF(q) to random values
 *
 * @param[in]  field    The field
 * @param[in]  res      The matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_mat_set_random(MPFQ_FIELD field, ffi_mat res, int rows, int columns) {
	int i;
	for(i=0 ; i<rows ; i++) {
		ffi_vec_set_random(field, res[i], columns);
	}
}

/**
 * @brief      Multiplies two matrices over GF(q^m)
 *
 * @param[in]  field     The field
 * @param[in]  res       The resource
 * @param[in]  A1        First matrix
 * @param[in]  A2        Second matrix
 * @param[in]  rows1     Rows of A1
 * @param[in]  columns1  Columns of A1
 * @param[in]  rows2     Rows of A2
 * @param[in]  columns2  Columns of A2
 */
void ffi_mat_prod(MPFQ_FIELD field, ffi_mat res, ffi_mat A1, ffi_mat A2, int rows1, int columns1, int rows2, int columns2) {
	if(columns1 != rows2) return;

	int i, j, k;
	ffi_elt tmp;
	ffi_elt_init(field, tmp);

	for(i=0 ; i<rows1 ; i++) {
		for(j=0 ; j<columns2 ; j++) {
			ffi_elt_set_zero(field, res[i][j]);
			for(k=0 ; k<columns1 ; k++) {
				ffi_elt_mul(field, tmp, A1[i][k], A2[k][j]);
				ffi_elt_add(field, res[i][j], res[i][j], tmp);
			}
		}
	}

	ffi_elt_clear(field, tmp);
}

/**
 * @brief      Multiplies a matrix and a vector over GF(q)
 *
 * @param[in]  field    The field
 * @param[in]  res      Vector = A.V^t
 * @param[in]  A        The matrix
 * @param[in]  V        The vector
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 */
void ffi_mat_vec_prod(MPFQ_FIELD field, ffi_vec res, ffi_mat A, ffi_vec V, int rows, int columns) {
	int i, j;
	ffi_elt tmp;
	ffi_elt_init(field, tmp);

	for(i=0 ; i<rows ; i++) {
		for(j=0 ; j<columns ; j++) {
			ffi_elt_mul(field, tmp, A[i][j], V[j]);
			ffi_elt_add(field, res[i], res[i], tmp);
		}
	}

	ffi_elt_clear(field, tmp);
}

/**
 * @brief      Multiplies a matrix over GF(q^m) by a matrix over GF(q)
 *
 * @param[in]  field     The field
 * @param[in]  res       The resource
 * @param[in]  A1        The matrix over GF(q^m)
 * @param[in]  A2        The matrix over GF(q)
 * @param[in]  rows1     The rows of A1
 * @param[in]  columns1  The columns of A1
 * @param[in]  rows2     The rows of A2
 * @param[in]  columns2  The columns of A2
 */
void ffi_mat_prod_base(MPFQ_FIELD field, ffi_mat res, ffi_mat A1, ffi_basemat A2, int rows1, int columns1, int rows2, int columns2) {
	if(columns1 != rows2) return;

	int i, j, k;
	ffi_elt tmp;
	ffi_elt_init(field, tmp);

	for(i=0 ; i<rows1 ; i++) {
		for(j=0 ; j<columns2 ; j++) {
			ffi_elt_set_zero(field, res[i][j]);
			for(k=0 ; k<columns1 ; k++) {
				ffi_elt_mul_base(field, tmp, A1[i][k], A2[k][j]);
				ffi_elt_add(field, res[i][j], res[i][j], tmp);
			}
		}
	}

	ffi_elt_clear(field, tmp);
}

/**
 * @brief      Inverts a matrix over GF(q)
 *
 * @param[in]  field    The field
 * @param[in]  dest     Inverse of src
 * @param[in]  src      The source matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 *
 * @return     -1 if src is not invertible, 0 otherwise
 */
int ffi_mat_inv(MPFQ_FIELD field, ffi_mat dest, ffi_mat src, int rows, int columns) {
	if(rows != columns) return -1;

	int i, j;
	ffi_elt tmp;
	ffi_elt_init(field, tmp);
	ffi_mat tmpMatrix = ffi_mat_copy(field, src, rows, columns);

	//Write identity in dest. Must be initialized with zeros
	for(i=0 ; i<rows ; i++) {
			ffi_elt_set_one(field, dest[i][i]);
	}

	//Inverse with Gauss
	//Echelon form
	for(i=0 ; i<rows ; i++) {
		int pivot = -1;
		for(j=i ; j<rows ; j++) {
			if(!(ffi_elt_degree(field, tmpMatrix[j][i]) == -1)) {
				pivot = j;
				break;
			}
		}
		//If we don't find a pivot on column j, then the matrix isn't invertible
		if(pivot == -1) {
			ffi_elt_clear(field, tmp);
			ffi_mat_clear(field, tmpMatrix, rows, columns);
			return -1;
		}

		//Swap rows
		if(pivot != i) {
			ffi_mat_swap_rows(field, tmpMatrix, i, pivot);
			ffi_mat_swap_rows(field, dest, i, pivot);
		}

		//Invert so we have "1" at the beginning of the line
		ffi_elt_inv(field, tmp, tmpMatrix[i][i]);
		ffi_mat_mul_row_const(field, tmpMatrix, i, tmp, columns);
		ffi_mat_mul_row_const(field, dest, i, tmp, columns);

		//Moify other lines
		for(j=i+1 ; j<rows ; j++) {
			ffi_elt_set(field, tmp, tmpMatrix[j][i]);
			ffi_mat_row_sub(field, tmpMatrix, i, j, tmp, columns);
			ffi_mat_row_sub(field, dest, i, j, tmp, columns);
		}
	}
	
	//Reduced Echelon form
	for(i=columns-1 ; i>0 ; i--) {
		for(j=i-1 ; j>=0 ; j--) {
			ffi_mat_row_sub(field, dest, i, j, tmpMatrix[j][i], columns);
		}
	}

	ffi_mat_clear(field, tmpMatrix, rows, columns);
	ffi_elt_clear(field, tmp);

	return 0;
}

/**
 * @brief      Computes pk from (R|H)P, and saves invA
 *
 * @param[in]  field    The field
 * @param[in]  pk       Public key matrix
 * @param[in]  invA     The inverse of the matrix A
 * @param[in]  rows     The rows of pk
 * @param[in]  columns  The columns of pk
 *
 * @return     0 if it worked, -1 otherwise
 */
int ffi_mat_compute_pk(MPFQ_FIELD field, ffi_mat pk, ffi_mat invA, int rows, int columns) {
	//First save invA as the first rows columns of pk
	
	int i,j;

	ffi_elt tmp;
	ffi_elt_init(field, tmp);

	for(i=0 ; i<rows ; i++) {
		for(j=0 ; j<rows ; j++) {
			ffi_elt_set_zero(field, invA[i][j]);
			ffi_elt_set(field, invA[i][j], pk[i][j]);
		}
	}

	ffi_mat A;
	A = ffi_mat_init(field, rows, rows);
	ffi_mat copyPK = ffi_mat_copy(field, pk, rows, columns);

	int status = ffi_mat_inv(field, A, invA, rows, rows);

	if(status == 0) {
		ffi_mat_prod(field, pk, A, copyPK, rows, rows, rows, columns);
	}

	ffi_elt_clear(field, tmp);
	ffi_mat_clear(field, A, rows, rows);
	ffi_mat_clear(field, copyPK, rows, columns);

	return status;
}

/**
 * @brief      Swaps two rows of a matrix over GF(q^m)
 *
 * @param[in]  field  The field
 * @param[in]  res    The matrix
 * @param[in]  row1   The row 1
 * @param[in]  row2   The row 2
 */
void ffi_mat_swap_rows(MPFQ_FIELD field, ffi_mat res, int row1, int row2) {
	ffi_vec tmp = res[row1];
	res[row1] = res[row2];
	res[row2] = tmp;
}

/**
 * @brief      Multiplies a row of a matrix by an element of GF(q^m)
 *
 * @param[in]  field    The field
 * @param[in]  res      The matrix
 * @param[in]  row      The row
 * @param[in]  c        GF(q^m) element
 * @param[in]  columns  The columns
 */
void ffi_mat_mul_row_const(MPFQ_FIELD field, ffi_mat res, int row, ffi_elt c, int columns) {
	int i;
	for(i=0 ; i<columns ; i++) {
		ffi_elt_mul(field, res[row][i], res[row][i], c);
	}
}

/**
 * @brief      Substracts c * row1 to row2
 *
 * @param[in]  field    The field
 * @param[in]  res      The matrix
 * @param[in]  row1     The row 1
 * @param[in]  row2     The row 2
 * @param[in]  c        GF(q^m) element
 * @param[in]  columns  The columns
 */
void ffi_mat_row_sub(MPFQ_FIELD field, ffi_mat res, int row1, int row2, ffi_elt c, int columns) {
	int i;
	ffi_elt tmp;
	ffi_elt_init(field, tmp);
	for(i=0 ; i<columns ; i++) {
		ffi_elt_mul(field, tmp, res[row1][i], c);
		ffi_elt_sub(field, res[row2][i], res[row2][i], tmp);
	}
	ffi_elt_clear(field, tmp);
}

/**
 * @brief      Parses a matrix over GF(q^m) into a string
 *
 * @param[in]  field    The field
 * @param[in]  A        The matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 * @param      string   The string
 */
void ffi_mat_to_string(MPFQ_FIELD field, ffi_mat A, int rows, int columns, unsigned char* string) {
	int i, j;

	for(i=0 ; i<rows ; i++) {
		for(j=0 ; j<columns ; j++) {
			ffi_elt_to_string(field, A[i][j], string + FFI_ELT_BYTES * (i * columns + j));
		}
	}
}

/**
 * @brief      Parses a string into a matrix over GF(q^m)
 *
 * @param[in]  field    The field
 * @param[in]  A        The matrix
 * @param[in]  rows     The rows
 * @param[in]  columns  The columns
 * @param      string   The string
 */
void ffi_mat_from_string(MPFQ_FIELD field, ffi_mat A, int rows, int columns, const unsigned char* string) {
	int i, j;

	for(i=0 ; i<rows ; i++) {
		for(j=0 ; j<columns ; j++) {
			ffi_elt_from_string(field, A[i][j], string + FFI_ELT_BYTES * (i * columns + j));
		}
	}
}