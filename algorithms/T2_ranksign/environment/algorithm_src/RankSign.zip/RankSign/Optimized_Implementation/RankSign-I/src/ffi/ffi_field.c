/**
 * \file ffi_field.c
 * \brief Implementation of ffi_field.h
 */

#include "ffi_field.h"

/**
 * @brief      Inits a MPFQ_FIELD
 *
 * @param[in]  field  The field
 */
void init_field(MPFQ_FIELD field) {
	MPFQ_TAG(field_init)(field);
}

/**
 * @brief      Clears a MPFQ_FIELD
 *
 * @param[in]  field  The field
 */
void clear_field(MPFQ_FIELD field) {
	MPFQ_TAG(field_clear)(field);
}