/**
 * \file parsing.c
 * \brief Implementation of parsing.h
 */

#include "parsing.h"
#include "hash.h"
#include "VS.h"

/**
 * @brief      Parses a Ranksign public key into a string
 *
 * @param[in]  field     The field
 * @param[in]  pk        The public key
 * @param      pkString  The string
 */
void publicKeyToString(MPFQ_FIELD field, const publicKey pk, unsigned char* pkString) {
	int i,j;
	for(i=0;i<PARAM_N - PARAM_K;i++) {
		for(j=PARAM_N - PARAM_K;j<PARAM_N + PARAM_T ; j++) {
			ffi_elt_to_string(field, pk->Hpub[i][j], pkString + FFI_ELT_BYTES * (i * (PARAM_K + PARAM_T) + j - (PARAM_N - PARAM_K)));
		}
	}
}

/**
 * @brief      Parses a string into a Ranksign public key
 *
 * @param[in]  field     The field
 * @param[in]  pk        The public key
 * @param[in]  pkString  The string
 */
void publicKeyFromString(MPFQ_FIELD field, publicKey pk, const unsigned char* pkString) {
	pk->Hpub = ffi_mat_init(field, PARAM_N - PARAM_K, PARAM_N + PARAM_T);
	int i,j;
	for(i=0;i<PARAM_N - PARAM_K;i++) {
		ffi_elt_set_one(field, pk->Hpub[i][i]);
		for(j=PARAM_N - PARAM_K;j<PARAM_N + PARAM_T ; j++) {
			ffi_elt_from_string(field, pk->Hpub[i][j], pkString + FFI_ELT_BYTES * (i * (PARAM_K + PARAM_T) + j - (PARAM_N - PARAM_K)));
		}
	}
}

/**
 * @brief      Parses a Ranksign secret key into a string
 *
 * @param[in]  field     The field
 * @param[in]  sk        The secret key
 * @param      skString  The string
 */
void secretKeyToString(MPFQ_FIELD field, const secretKey sk, unsigned char* skString) {
	//F
	int i;
	for(i=0 ; i<PARAM_D ; i++) {
		ffi_elt_to_string(field, sk->F->vectors[i], skString + FFI_ELT_BYTES * i);
	}

	//Matrices
	ffi_basemat_to_string(field, sk->DH, PARAM_N, PARAM_N, skString + F_BYTES);
	ffi_basemat_to_string(field, sk->invQ, (PARAM_N + PARAM_T), (PARAM_N + PARAM_T), skString + F_BYTES + DH_BYTES);
	ffi_mat_to_string(field, sk->invP, (PARAM_N - PARAM_K), (PARAM_N - PARAM_K), skString + F_BYTES + DH_BYTES + INVP_BYTES);
	ffi_mat_to_string(field, sk->R, (PARAM_N - PARAM_K), PARAM_T, skString + F_BYTES + DH_BYTES + INVP_BYTES + INVA_BYTES);
}

/**
 * @brief      Parses a string into a Ranksign secret key
 *
 * @param[in]  field     The field
 * @param[in]  sk        The secret key
 * @param[in]  skString  The string
 */
void secretKeyFromString(MPFQ_FIELD field, secretKey sk, const unsigned char* skString) {
	//Init each element of the struct and then parse
	sk->F = initVS(field, PARAM_D);
	int i;
	for(i=0 ; i<PARAM_D ; i++) {
		ffi_elt_from_string(field, sk->F->vectors[i], skString + FFI_ELT_BYTES * i);
	}

	//Matrices
	sk->DH = ffi_basemat_init(field, PARAM_N, PARAM_N);
	ffi_basemat_from_string(field, sk->DH, PARAM_N, PARAM_N, skString + F_BYTES);
	sk->invQ = ffi_basemat_init(field, (PARAM_N + PARAM_T), (PARAM_N + PARAM_T));
	ffi_basemat_from_string(field, sk->invQ, (PARAM_N + PARAM_T), (PARAM_N + PARAM_T), skString + F_BYTES + DH_BYTES);
	sk->invP = ffi_mat_init(field, (PARAM_N - PARAM_K), (PARAM_N - PARAM_K));
	ffi_mat_from_string(field, sk->invP, (PARAM_N - PARAM_K), (PARAM_N - PARAM_K), skString + F_BYTES + DH_BYTES + INVP_BYTES);
	sk->R = ffi_mat_init(field, (PARAM_N - PARAM_K), PARAM_T);
	ffi_mat_from_string(field, sk->R, (PARAM_N - PARAM_K), PARAM_T, skString + F_BYTES + DH_BYTES + INVP_BYTES + INVA_BYTES);
}

/**
 * @brief      Parses a Ranksign signature into a string
 *
 * @param[in]  field            The field
 * @param[in]  ET               Support of the signature
 * @param[in]  signature        Coordinates of the signature in this support
 * @param      signatureString  The string
 * @param[in]  seed             The seed
 */
void signatureToString(MPFQ_FIELD field, VS ET, ffi_basevec signature, unsigned char* signatureString, unsigned char seed) {
	int i;
	for(i=0 ; i<PARAM_R ; i++) {
		ffi_elt_to_string(field, ET->vectors[i], signatureString + FFI_ELT_BYTES * i);
	}

	for(i=0 ; i<(PARAM_N + PARAM_T) * PARAM_R ; i++) {
		ffi_baseElt_to_string(field, signature[i], signatureString + FFI_ELT_BYTES * PARAM_R + i * FFI_BASEELT_BYTES);
	}

	memcpy(signatureString + SIGNATURE_BYTES - 1, &seed, 1);
}

/**
 * @brief      Parses a string into a Ranksign signature
 *
 * @param[in]  field            The field
 * @param[in]  signature        The signature
 * @param[in]  signatureString  The string
 * @param      seed             The seed
 */
void signatureFromString(MPFQ_FIELD field, ffi_vec signature, const unsigned char* signatureString, unsigned char *seed) {
	int i, j;
	VS ET;
	ET = initVS(field, PARAM_R);
	for(i=0 ; i<PARAM_R ; i++) {
		ffi_elt_from_string(field, ET->vectors[i], signatureString + FFI_ELT_BYTES * i);
	}

	ffi_basevec coords;
	coords = ffi_basevec_init(field, (PARAM_N + PARAM_T) * PARAM_R);
	ffi_elt tmp;
	ffi_elt_init(field, tmp);

	for(i=0 ; i<(PARAM_N + PARAM_T) * PARAM_R ; i++) {
		ffi_baseElt_from_string(field, coords[i], signatureString + FFI_ELT_BYTES * PARAM_R + i * FFI_BASEELT_BYTES);
	}

	for(i=0 ; i<PARAM_N + PARAM_T ; i++) {
		ffi_elt_set_zero(field, signature[i]);
		for(j=0 ; j<PARAM_R ; j++) {
			ffi_elt_mul_base(field, tmp, ET->vectors[j], coords[i * PARAM_R + j]);
			ffi_elt_add(field, signature[i], signature[i], tmp);
		}
	}

	memcpy(seed, signatureString + SIGNATURE_BYTES - 1, 1);
	clearVS(field, ET);
	ffi_basevec_clear(field, coords, (PARAM_N + PARAM_T) * PARAM_R);
	ffi_elt_clear(field, tmp);
}

/**
 * @brief      Computes a syndrom from a hash
 *
 * @param[in]  field    The field
 * @param[in]  syndrom  The syndrom
 * @param[in]  len      The length of the syndrom
 * @param[in]  hash     The hash
 */
void syndromFromHash(MPFQ_FIELD field, ffi_vec syndrom, int len, const unsigned char* hash) {
	int neededLength = len * FFI_ELT_BYTES;

	unsigned char syndromStr[(neededLength / SHA512_BYTES + 1) * SHA512_BYTES];

	int i;

	memcpy(syndromStr, hash, SHA512_BYTES);

	for(i=SHA512_BYTES ; i<neededLength ; i+=SHA512_BYTES) {
		sha512(syndromStr + i, syndromStr + i - SHA512_BYTES, SHA512_BYTES);
	}

	for(i=0 ; i<len ; i++) {
		ffi_elt_from_string(field, syndrom[i], syndromStr + FFI_ELT_BYTES * i);
	}
}