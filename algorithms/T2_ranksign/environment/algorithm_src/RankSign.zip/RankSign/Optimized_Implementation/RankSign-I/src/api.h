/**
 * \file api.h
 * \brief NIST Signature API used by the Ranksign scheme
 */


#ifndef API_H
#define API_H


#define CRYPTO_ALGNAME "Ranksign-I"

#define CRYPTO_SECRETKEYBYTES 23864
#define CRYPTO_PUBLICKEYBYTES 10080
#define CRYPTO_BYTES 1377

int crypto_sign_keypair(unsigned char *pk, unsigned char *sk);
int crypto_sign(unsigned char *sm, unsigned long long *smlen, const unsigned char *m, unsigned long long mlen, const unsigned char *sk);
int crypto_sign_open(unsigned char *m, unsigned long long *mlen, const unsigned char *sm, unsigned long long smlen, const unsigned char *pk); 

#endif