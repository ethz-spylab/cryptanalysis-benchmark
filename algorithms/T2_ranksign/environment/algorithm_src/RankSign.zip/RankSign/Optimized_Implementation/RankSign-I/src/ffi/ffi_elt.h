/**
 * \file extension.h
 * \brief Interface for finite fields elements
 */

#ifndef EXTENSION
#define EXTENSION

#include "ffi_field.h"

typedef MPFQ_TAG(elt) ffi_baseElt;
typedef MPFQ_TAG(poly) ffi_elt;

void ffi_baseElt_init(MPFQ_TAG(field) field, ffi_baseElt res);
void ffi_baseElt_print(MPFQ_TAG(field) field, ffi_baseElt res);
void ffi_baseElt_clear(MPFQ_TAG(field) field, ffi_baseElt res);
void ffi_baseElt_set_random(MPFQ_TAG(field) field, ffi_baseElt res);
void ffi_baseElt_inv(MPFQ_TAG(field) field, ffi_baseElt res, ffi_baseElt src);

void ffi_baseElt_set(MPFQ_TAG(field) field, ffi_baseElt dest, ffi_baseElt src);
void ffi_baseElt_set_zero(MPFQ_TAG(field) field, ffi_baseElt res);
void ffi_baseElt_set_one(MPFQ_TAG(field) field, ffi_baseElt res);
void ffi_baseElt_add(MPFQ_TAG(field) field, ffi_baseElt res, ffi_baseElt elt1, ffi_baseElt elt2);
void ffi_baseElt_sub(MPFQ_TAG(field) field, ffi_baseElt res, ffi_baseElt elt1, ffi_baseElt elt2);
void ffi_baseElt_mul(MPFQ_TAG(field) field, ffi_baseElt res, ffi_baseElt elt1, ffi_baseElt elt2);

int ffi_baseElt_is_zero(MPFQ_TAG(field) field, ffi_baseElt res);

void ffi_baseElt_to_string(MPFQ_TAG(field) field, ffi_baseElt elt, unsigned char* string);
void ffi_elt_to_string(MPFQ_TAG(field) field, ffi_elt elt, unsigned char* string);

void ffi_baseElt_from_string(MPFQ_TAG(field) field, ffi_baseElt elt, const unsigned char* string);
void ffi_elt_from_string(MPFQ_TAG(field) field, ffi_elt elt, const unsigned char* string);

void ffi_elt_init(MPFQ_TAG(field) field, ffi_elt res);
void ffi_elt_set_one(MPFQ_TAG(field) field, ffi_elt res);
void ffi_elt_set_random(MPFQ_TAG(field) field, ffi_elt res);
void ffi_elt_set_zero(MPFQ_TAG(field) field, ffi_elt res);

void generateExtension(MPFQ_TAG(field) field);
void ffi_elt_set(MPFQ_TAG(field) field, ffi_elt dest, ffi_elt src);
void ffi_elt_get_coeff(MPFQ_TAG(field) field, ffi_baseElt res, ffi_elt src, int index);
int ffi_elt_cmp(MPFQ_TAG(field) field, ffi_elt elt1, ffi_elt elt2);
int ffi_elt_degree(MPFQ_TAG(field) field, ffi_elt elt);
void ffi_elt_set_monic(MPFQ_TAG(field) field, ffi_elt dest, ffi_elt src);

void ffi_elt_mul(MPFQ_TAG(field) field, ffi_elt res, ffi_elt elt1, ffi_elt elt2);
void ffi_elt_mul_base(MPFQ_TAG(field) field, ffi_elt res, ffi_elt elt, ffi_baseElt baseElt);
void ffi_elt_add(MPFQ_TAG(field) field, ffi_elt res, ffi_elt elt1, ffi_elt elt2);
void ffi_elt_sub(MPFQ_TAG(field) field, ffi_elt res, ffi_elt elt1, ffi_elt elt2);
void ffi_elt_inv(MPFQ_TAG(field) field, ffi_elt res, ffi_elt elt);

void ffi_elt_print(MPFQ_TAG(field) field, ffi_elt elt);
void ffi_elt_clear(MPFQ_TAG(field) field, ffi_elt elt);

#endif