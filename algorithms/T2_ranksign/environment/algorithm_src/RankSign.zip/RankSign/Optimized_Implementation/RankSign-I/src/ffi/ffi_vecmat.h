/**
 * \file ffi_basevecmat.h
 * \brief Interface for vectors and matrices over GF(q^m)
 */

#ifndef VECMAT_H
#define VECMAT_H

#include "ffi_elt.h"
#include "ffi_basevecmat.h"
#include "../VS.h"
#include "ffi_field.h"

typedef ffi_elt* ffi_vec;
typedef ffi_vec* ffi_mat;

ffi_vec ffi_vec_init(MPFQ_FIELD field, int len);
void ffi_vec_clear(MPFQ_FIELD field, ffi_vec res, int len);
void ffi_vec_print(MPFQ_FIELD field, ffi_vec res, int len);
void ffi_vec_add(MPFQ_FIELD field, ffi_vec res, ffi_vec V1, ffi_vec V2, int len);
void ffi_vec_sub(MPFQ_FIELD field, ffi_vec res, ffi_vec V1, ffi_vec V2, int len);
void ffi_vec_prod_mat(MPFQ_FIELD field, ffi_vec res, ffi_vec V, ffi_mat A, int len, int rows, int columns);
void ffi_vec_prod_basemat(MPFQ_FIELD field, ffi_vec res, ffi_vec V, ffi_basemat A, int len, int rows, int columns);
void ffi_basemat_vecGC_prod(MPFQ_FIELD field, ffi_vec res, ffi_basemat A, ffi_vec V, int len, int rows, int columns);
ffi_vec ffi_vec_copy(MPFQ_FIELD field, ffi_vec src, int len);
ffi_vec ffi_vec_concat(MPFQ_FIELD field, ffi_vec V1, ffi_vec V2, int len1, int len2);
int ffi_basevec_from_support(MPFQ_FIELD field, ffi_vec src, int len, VS support, int dimension, ffi_basevec res) ;
ffi_vec ffi_vec_from_basevec(MPFQ_FIELD field, ffi_basevec src, int len, VS support, int dimension);

void ffi_vec_set_random(MPFQ_FIELD field, ffi_vec res, int len);

ffi_mat ffi_mat_init(MPFQ_FIELD field, int rows, int columns);
void ffi_mat_clear(MPFQ_FIELD field, ffi_mat res, int rows, int columns);
void ffi_mat_print(MPFQ_FIELD field, ffi_mat res, int rows, int columns);
ffi_mat ffi_mat_copy(MPFQ_FIELD field, ffi_mat src, int rows, int columns);
ffi_mat ffi_mat_concat(MPFQ_FIELD field, ffi_mat A1, ffi_mat A2, int rows1, int columns1, int rows2, int columns2);

void ffi_mat_set_random(MPFQ_FIELD field, ffi_mat res, int rows, int columns);
void ffi_mat_prod(MPFQ_FIELD field, ffi_mat res, ffi_mat A1, ffi_mat A2, int rows1, int columns1, int rows2, int columns2);
void ffi_mat_vec_prod(MPFQ_FIELD field, ffi_vec res, ffi_mat A, ffi_vec V, int rows, int columns);
void ffi_mat_prod_base(MPFQ_FIELD field, ffi_mat res, ffi_mat A1, ffi_basemat A2, int rows1, int columns1, int rows2, int columns2);
int ffi_mat_inv(MPFQ_FIELD field, ffi_mat dest, ffi_mat src, int rows, int columns);

int ffi_mat_compute_pk(MPFQ_FIELD field, ffi_mat pk, ffi_mat RHP, int rows, int columns);

//Utility for Gauss
void ffi_mat_swap_rows(MPFQ_FIELD field, ffi_mat res, int row1, int row2);
void ffi_mat_mul_row_const(MPFQ_FIELD field, ffi_mat res, int row, ffi_elt c, int columns);
void ffi_mat_row_sub(MPFQ_FIELD field, ffi_mat res, int row1, int row2, ffi_elt c, int columns);

//Parsing
void ffi_mat_to_string(MPFQ_FIELD field, ffi_mat A, int rows, int columns, unsigned char* string);
void ffi_mat_from_string(MPFQ_FIELD field, ffi_mat A, int rows, int columns, const unsigned char* string);
#endif