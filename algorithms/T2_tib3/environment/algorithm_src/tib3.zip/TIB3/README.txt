Algorithm TIB3
Principal Submitter: Daniel Penazzi
Auxiliary Submitter: Miguel Montes

Disk structure
\README
	This file
\Reference_Implementation\
	*Directory containing the reference implementation
	encrypt256.c 	C source code. Implementation of the Encrypt256 function
	encrypt512.c 	C source code. Implementation of the Encrypt512 function
	global.h	C header. Global declarations
	inupfin.c	C source code. Implementation of the required API.
	nupfin.h	C header. Declarations for the API
	inupfin256.c	C source code. Implementation of the 224 and 256 bits versions.
	inupfin512.c	C source code. Implementation of the 384 and 512 bits versions.
\Optimized_32bit\
	*Directory containing the 32 bit optimized implementation
	global.h	C header. Global declarations
	inupfin.c	C source code. Implementation of the required API.
	inupfin.h	C header. Declarations for the API
	inupfin256.c	C source code. Implementation of the 224 and 256 bits versions.
	inupfin512.c	C source code. Implementation of the 384 and 512 bits versions.
\Optimized_64bit\
	*Directory containing the 64 bit optimized implementation
	global.h	C header. Global declarations
	inupfin.c	C source code. Implementation of the required API.
	inupfin.h	C header. Declarations for the API
	inupfin256.c	C source code. Implementation of the 224 and 256 bits versions.
	inupfin512.c	C source code. Implementation of the 384 and 512 bits versions.
\KAT_MCT\
	*Directory containing the output of the genKat program.
	ExtremelyLongMsgKAT.txt
	ExtremelyLongMsgKAT_224.txt
	ExtremelyLongMsgKAT_256.txt
	ExtremelyLongMsgKAT_384.txt
	ExtremelyLongMsgKAT_512.txt	
	LongMsgKAT.txt
	LongMsgKAT_224.txt
	LongMsgKAT_256.txt
	LongMsgKAT_384.txt
	LongMsgKAT_512.txt
	MonteCarlo.txt
	MonteCarlo_224.txt
	MonteCarlo_256.txt
	MonteCarlo_384.txt
	MonteCarlo_512.txt
	ShortMsgKAT.txt
	ShortMsgKAT_224.txt
	ShortMsgKAT_256.txt
	ShortMsgKAT_384.txt
	ShortMsgKAT_512.txt
	*Plus the source files used to generate the test results, based on the reference implementation
	encrypt256.c
	encrypt512.c
	genKAT.c
	global.h
	inupfin.c
	inupfin.h
	inupfin256.c
	inupfin512.c

	IntermediateKAT\
		*Directory containing the intermediate states for the hashing of a 1-block messag and a 2-block message
		IntermediateValuesKATInput_224.txt Input file for the 224 bit version
		IntermediateValuesKATInput_256.txt Input file for the 256 bit version
		IntermediateValuesKATInput_384.txt Input file for the 384 bit version
		IntermediateValuesKATInput_512.txt Input file for the 512 bit version
		IntermediateValuesKAT_224.txt Output of the test for the 224 bit version
		IntermediateValuesKAT_256.txt Output of the test for the 256 bit version
		IntermediateValuesKAT_384.txt Output of the test for the 384 bit version
		IntermediateValuesKAT_512.txt Output of the test for the 512 bit version
		encrypt256.c
		encrypt512.c
		genIntermediateKAT.c	Intermediate Values Kat generator
		global.h
		inupfin.c
		inupfin.h
		inupfin256.c
		inupfin512.c
		README.txt	Description of the tests.
	\src\
		*Directory containing the code for generating the KAT and MCT files
		Optimized_32bit\
			*Directory with the 32 bit version, plus genKat.c
		Optimized_64bit\
			*Directory with the 64 bit version, plus genKat.c
		Reference_implementation\
			*Directory with the reference version, plus genKat.c
\Supporting_Documentation
		TIB3_Algorithm_Specification.pdf Algorithm specification
