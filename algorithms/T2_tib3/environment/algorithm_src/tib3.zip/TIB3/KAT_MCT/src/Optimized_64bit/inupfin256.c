/*
 * inupfin256.c
 *
 *		Implements the 224 and 256 bit versions of Init(), Update(), Final() and Hash()
 *		Optimized for 64 bits
 *		Authors: Penazzi - Montes
 */

#include <string.h>
#include "inupfin.h"

/* Sizes used across all the functions */
#define STATE_DWORDS STATE_DWORDS_256
#define STATE_BYTES STATE_BYTES_256
#define BLOCK_DWORDS BLOCK_DWORDS_256
#define BLOCK_BYTES BLOCK_BYTES_256
#define HASH_BYTES HASH_BYTES_256
#define BLOCK_BITS 512

/* Updates the bits processed before calling Transform. 
 * The increment is BLOCK_BITS in all the blocks except the last.
 */
#define UPDATEBITS   state->bits_processed += BLOCK_BITS;


 /* Expansion */


/* Processes 4 64 bits words, and returns one.
 * Used by the key expansion
 * Input words:
 *	di10, di8, di3, di2
 * Output word:
 *	di
 */
#define PSI(di,di10,di8,di3,di2) \
	di=(di3+(di2<<32))^di10^di8^(di2>>32);\
	di+=(di<<32)+(di<<43);\
	di^=(di>>39);


/* Macros used in the round function */
#define F(X,Y,Z) ((~X)^(Y&(~Z)))
#define G(X,Y,Z) (Z^((~X)&(~Y)))
#define H(X,Y,Z) (Y^(X&Z))

/*bitsliced Sbox */
#define Sbox(m0,m1,m2)    \
{ register uint64_t temp0, temp1;\
        temp0=F(m0,m1,m2);         \
        temp1=G(m0,m1,m2);         \
        m2=H(m0,m1,m2);         \
        m0=temp0;                  \
	    m1=temp1; }

#define PHTX(D)  \
       D+=(D<<32)+(D<<47);\
       D^=(D>>32)^(D>>43);

#define DIFFUSION(A,C,E,G) \
	A=((A&0xffffffff00000000)+(G&0xffffffff00000000))|((A+G)&0xffffffff);\
	PHTX(C);\
	G=((G&0xffffffff00000000)+(E&0xffffffff00000000))|((G+E)&0xffffffff);


/* Round function
 * Input:
 *	A,C,E,G: state, as 4 64 bit words
 *	k0,k2,k4: round key, as 3 64 bit words.
 * Output:
 *	A,C,E,G: state, modified by the S-Box
 */
#define ROUND(A,C,E,G,k0,k2,k4) \
    A^=k0;\
	C^=k2;\
	E^=k4;\
	G^=C;\
	PHTX(G);\
    Sbox(A,C,E) ;\
    DIFFUSION(A,C,E,G);


void Encrypt256(uint64_t hsh[STATE_DWORDS], uint64_t k[BLOCK_DWORDS],uint64_t pk[BLOCK_DWORDS],uint64_t bits);
void Transform256(hashState256* state);

/* Bitmask for zeroing the unused bits of the last byte of the message */
const static unsigned char BITMASK[] = {0x00, 0x80, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc, 0xfe};
/* Bitmask for adding a 1 after the last bit of the message */
const static unsigned char BITPADDING[] = { 0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01 };

/* IV for the 256 bit version */
const uint64_t i256[STATE_DWORDS] =
{
    0x6a09e667f3bcc908ull, 0xbb67ae8584caa73bull,
    0x3c6ef372fe94f82bull, 0xa54ff53a5f1d36f1ull
};

/* IV for the 224 bit version */
const uint64_t  i224[STATE_DWORDS] =
{
    0x510e527fade682d1ull, 0x9b05688c2b3e6c1full,
    0x1f83d9abfb41bd6bull, 0x5be0cd19137e2179ull,
};



/* Initializes a hashState256 with the appropriate values for the 256 bit hash.
 * Parameters:
 *	state: a structure that holds the hashState256 information
 * Returns:
 *	SUCCESS - on success
 */
HashReturn Init256(hashState256 *state){
	state->previous_block = state->buffer; /* previous_block points to the first half of the buffer */
	state->data_block = state->buffer+BLOCK_DWORDS; /* data_block points to the second half of the buffer */
	state->bits_processed = 0; /* No bits, yet */
	state->bits_waiting_for_process = 0; /* No bits waiting */
	memcpy(state->state, i256, STATE_BYTES); /* Copying the IV */
	memcpy(state->previous_block, i224, STATE_BYTES); /* Initial state of the previous block. We copy the 224 bit IV, twice */
	memcpy(state->previous_block+STATE_DWORDS, i224, STATE_BYTES);
	return SUCCESS;
}

/* Initializes a hashState224 with the appropriate values for the 224 bit hash.
 * Parameters:
 *	state: a structure that holds the hashState224 information
 * Returns:
 *	SUCCESS - on success
 */
HashReturn Init224(hashState256 *state){
	state->previous_block = state->buffer; /* previous_block points to the first half of the buffer */
	state->data_block = state->buffer+BLOCK_DWORDS; /* data_block points to the second half of the buffer */
	state->bits_processed = 0; /* No bits, yet */
	state->bits_waiting_for_process = 0;  /* No bits waiting */
	memcpy(state->state, i224, STATE_BYTES); /* Copying the IV */
	memcpy(state->previous_block, i256, STATE_BYTES);/* Initial state of the previous block. We copy the 256 bit IV, twice */
	memcpy(state->previous_block+STATE_DWORDS, i256, STATE_BYTES);
	return SUCCESS;
}




/* Process the supplied data.
 * Parameters:
 *	state: a structure that holds the hashState256 information
 *	data: the data to be hashed
 *	databitlen: the length, in bits, of the data to be hashed. 
 *	It must be a multiple of 8, except, possibly, in the last call
 * Returns:
 *	SUCCESS - on success
 */
HashReturn Update256(hashState256 *state, const BitSequence *data,
		DataLength databitlen) {
	DataLength offset, databytes;
	unsigned int remaining, index;
	BitSequence* byte_buffer;
	databytes = (databitlen >> 3); /* number of bytes to process */

	/*bytes waiting to be processed
	 * According to specifications, except for the last time, update will never be called with
	 * a number of bits not multiple of 8. Therefore, the number of bits that have been
	 * fed into the buffer but not processed after the last call of update must be
	 * a multiple of 8. Also, this number should be less than BLOCK_BYTES
	 */
	index = (state->bits_waiting_for_process >> 3);

	remaining = BLOCK_BYTES - index; /* space available in the buffer */
	offset = 0;

	/* If we have bytes waiting from a previous call, and there are enough
	 * to fill a block, we copy them and call to Transform
	 */
	if ((index != 0) && (databytes >= remaining)) {
		byte_buffer = (BitSequence*) state->data_block; /* buffer as an array of char */
		memcpy(byte_buffer + index, data, remaining); /* We fill the buffer */
		UPDATEBITS;
		Transform256(state);
		offset += remaining; /* We consumed 'remaining' bytes from data */
		index = 0; /* There are not bytes waiting for process */
		state->bits_waiting_for_process = 0; /* Therefore, no bits */
	}

	/* We process as many blocks as we can */
	while (offset + BLOCK_BYTES <= databytes) {
		memcpy(state->data_block, data + offset, BLOCK_BYTES);
		UPDATEBITS;
		Transform256(state);
		offset += BLOCK_BYTES;
	}
	if (databitlen & 7)
		databytes++; /* The number of bits is not a multiple of 8. This can only happen in the last call to update */
	byte_buffer = (BitSequence*) state->data_block;

	/* If there are still bytes in data, we copy them to the buffer */
	memcpy(byte_buffer + index, data + offset,(size_t) (databytes - offset));
	state->bits_waiting_for_process += (uint32_t) (databitlen - 8 * offset);;
	return SUCCESS;
}


/* Process the block stored in the buffer. 
 * Parameters:
 *	state: a structure that holds the hashState256 information
 * This optimized version also implements the functionality of the 
 * function Encrypt256() used in the Reference Implementation.
 */
void Transform256(hashState256* state){
	uint64_t *k, *p; /* Pointers for storing the block and the previous block */
	uint64_t H0,H2,H4,H6; /* 64 bit words, for storing the state */
	uint64_t D[32]; /* Array for the expanded key */

	/* First, we copy the hash state to the 4 words H0,H2,H4,H6 */
	H0=state->state[0]; H2=state->state[1];H4=state->state[2];H6=state->state[3];
	k = state->data_block; p = state->previous_block;

	/* In this version, we don't expand first. We call the round function 
	 * shortly after we have enough key material
	 */
	D[0]=p[0]^k[0];  D[1]=p[1]^k[1];	ROUND( H0,H2,H4,H6, D[ 0],k[ 0],D[ 1] );
	D[2]=p[2]^k[2];  D[3]=p[3]^k[3];
	D[4]=p[4]^k[4];  D[5]=p[5]^k[5];	ROUND( H2,H4,H6,H0, D[ 2],k[ 1],D[ 3] );
	D[6]=p[6]^k[6];  D[7]=p[7]^k[7];
	PSI(D[8],(D[3]^p[0]),(D[4]^p[1]),(D[5]^p[2]),(D[1]^p[3]));	ROUND( H4,H6,H0,H2, D[ 4],k[ 2],D[ 5] );
 	PSI(D[9],(D[2]^0x428a2f98d728ae22ull^p[4]),(D[7]^state->bits_processed^p[5]),(D[6]^p[7]),(D[0]^p[6]));

	PSI(D[10],D[ 0],D[ 2],D[ 7],D[ 8]);	ROUND( H6,H0,H2,H4, D[ 6],k[ 3],D[ 7] );
	PSI(D[11],D[ 1],D[ 3],D[ 8],D[ 9]);
	PSI(D[12],D[ 2],D[ 4],D[ 9],D[10]); ROUND( H0,H2,H4,H6, D[ 8],k[ 4],D[ 9] );
	PSI(D[13],D[ 3],D[ 5],D[10],D[11]);
	PSI(D[14],D[ 4],D[ 6],D[11],D[12]);	ROUND( H2,H4,H6,H0, D[10],k[ 5],D[11] );
	PSI(D[15],D[ 5],D[ 7],D[12],D[13]);
	PSI(D[16],D[ 6],D[ 8],D[13],D[14]);	ROUND( H4,H6,H0,H2, D[12],k[ 6],D[13] );
	PSI(D[17],D[ 7],D[ 9],D[14],D[15]);
	PSI(D[18],D[ 8],D[10],D[15],D[16]);	ROUND( H6,H0,H2,H4, D[14],k[ 7],D[15] );
	PSI(D[19],D[ 9],D[11],D[16],D[17]);
	PSI(D[20],D[10],D[12],D[17],D[18]);	ROUND( H0,H2,H4,H6, p[ 0],D[16],p[ 1] );
	PSI(D[21],D[11],D[13],D[18],D[19]);
	PSI(D[22],D[12],D[14],D[19],D[20]);	ROUND( H2,H4,H6,H0, p[ 2],D[17],p[ 3] );
	PSI(D[23],D[13],D[15],D[20],D[21]);
	PSI(D[24],D[14],D[16],D[21],D[22]);	ROUND( H4,H6,H0,H2, p[ 4],D[18],p[ 5] );
	PSI(D[25],D[15],D[17],D[22],D[23]);
	PSI(D[26],D[16],D[18],D[23],D[24]);	ROUND( H6,H0,H2,H4, p[ 6],D[19],p[ 7] );
	PSI(D[27],D[17],D[19],D[24],D[25]);
	PSI(D[28],D[18],D[20],D[25],D[26]);	ROUND( H0,H2,H4,H6, D[20],D[21],D[22] );
	PSI(D[29],D[19],D[21],D[26],D[27]);	ROUND( H2,H4,H6,H0, D[23],D[24],D[25] );
	PSI(D[30],D[20],D[22],D[27],D[28]);	ROUND( H4,H6,H0,H2, D[26],D[27],D[28] );
	PSI(D[31],D[21],D[23],D[28],D[29]);	ROUND( H6,H0,H2,H4, D[29],D[30],D[31] );

	/* Now, we xor the encrypted state with the original state */
	state->state[0] ^= H0;
	state->state[1] ^= H2;
	state->state[2] ^= H4;
	state->state[3] ^= H6;

	/* Finally, we swap pointers */
	state->data_block = p;
	state->previous_block = k; /* now previous_block points to the block just processed */
}




/* Perform post processing and output filtering and return the final hash value.
 * This function is called from Final256() or Final224()
 * Parameters:
 *	state: a structure that holds the hashState256 information
 *	hashval: the storage for the final hash value to be returned
 *	hashbytes: the number of bytes to store in hashval
 *		(28 for the 224 bit hash, 32 for the 256 bit hash)
 * Returns:
 *	SUCCESS - on success
 */
HashReturn _Final256 (hashState256 *state, BitSequence *hashval, int hashbytes){
	int j;
	BitSequence* byte_buffer;
	unsigned int index, bits;

	/* if there is any data to be processed, we need to pad and process, 
	 * otherwise we	go to the last block*/
	if(state->bits_waiting_for_process){
		/* If bits_waiting_for_process is not a multiple of 8, index will be the last byte,
		 * and bits will be the number of valid bits in that byte.
		 */
		index = state->bits_waiting_for_process >> 3;
		bits =  state->bits_waiting_for_process & 7;
		byte_buffer = (BitSequence*) state->data_block;

		/* We zero the unused bits of the last byte, and set the fist unused bit to 1 */
		byte_buffer[index] = (byte_buffer[index] & BITMASK[bits]) | BITPADDING[bits];
		index++;
		memset(byte_buffer+index, 0, BLOCK_BYTES - index); /* We fill the rest of the block with zeros */

		/*the usual update of bits processed cannot be used here, since
		 *less than a full block of DATA has been processed
		 */
		state->bits_processed += state->bits_waiting_for_process; 

		Transform256(state);
	}/*endif(bits_waiting_for_process)*/
   
	/* All data (plus any padding) has been processed. A last call, so that the last block
	 * of data is treated like all the others (i.e., twice) is made. The new block is simply the number of
	 * bits processed, xor the last state. 
	 */
	state->data_block[0]=state->bits_processed;
	for(j=1;j < STATE_DWORDS;j++) state->data_block[j]=0; /* The size of the block is twice the size of the state */
	memcpy(state->data_block + STATE_DWORDS, state->state, STATE_BYTES);
	state->bits_processed = 0; /* This ensures that the final transform is the same regardless of the bits processed */
	
	Transform256(state);
	
	/* We output the appropriate number of bytes, truncating the state if necessary */
	for (j = 0; j < hashbytes; j++)
		hashval[j] = ((BitSequence*)state->state)[j];
	return SUCCESS;
}

/* Perform post processing and output filtering and return the final 256 bit hash value.
 * Parameters:
 *	state: a structure that holds the hashState256 information
 *	hashval: the storage for the final hash value to be returned
 * Returns:
 *	SUCCESS - on success
 */
HashReturn Final256(hashState256 *state, BitSequence *hashval){
	return _Final256(state,hashval,HASH_BYTES_256);
}

/* Perform post processing and output filtering and return the final 224 bit hash value.
 * Parameters:
 *	state: a structure that holds the hashState256 information
 *	hashval: the storage for the final hash value to be returned
 * Returns:
 *	SUCCESS - on success
 */
HashReturn Final224(hashState256 *state, BitSequence *hashval){
	return _Final256(state,hashval,HASH_BYTES_224);
}



/* Hash the supplied data and provide the resulting hash value. Set return code as
 * appropriate. 256 bit version.
 * Parameters:
 *	data: the data to be hashed
 *	databitlen: the length, in bits, of the data to be hashed
 *	hashval: the resulting hash value of the provided data
 * Returns:
 *	SUCCESS - on success
*/

HashReturn Hash256(const BitSequence *data, DataLength databitlen, BitSequence *hashval){
	hashState256 state;
	HashReturn status;
	status = Init256(&state);
	if (status != SUCCESS) return status;
	status = Update256(&state, data, databitlen);
	if (status != SUCCESS) return status;
	return _Final256(&state, hashval,HASH_BYTES_256);
}

/* Hash the supplied data and provide the resulting hash value. Set return code as
 * appropriate. 224 bit version
 * Parameters:
 *	data: the data to be hashed
 *	databitlen: the length, in bits, of the data to be hashed
 *	hashval: the resulting hash value of the provided data
 * Returns:
 *	SUCCESS - on success
*/
HashReturn Hash224(const BitSequence *data, DataLength databitlen, BitSequence *hashval){
	hashState256 state;
	HashReturn status;
	status = Init224(&state);
	if (status != SUCCESS) return status;
	status = Update256(&state, data, databitlen);
	if (status != SUCCESS) return status;
	return _Final256(&state, hashval,HASH_BYTES_224);
}

