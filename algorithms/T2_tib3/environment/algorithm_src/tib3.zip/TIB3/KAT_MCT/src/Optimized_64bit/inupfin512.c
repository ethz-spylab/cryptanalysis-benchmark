/*
 * inupfin512.c
 *
 *		Implements the 384 and 512 bit versions of Init(), Update(), Final() and Hash()
 *		Optimized for 64 bits
 *		Authors: Penazzi - Montes
 */



#include <string.h>
#include "inupfin.h"

/* Sizes used across all the functions */
#define STATE_DWORDS STATE_DWORDS_512
#define STATE_BYTES STATE_BYTES_512
#define BLOCK_DWORDS BLOCK_DWORDS_512
#define BLOCK_BYTES BLOCK_BYTES_512
#define HASH_BYTES HASH_BYTES_512
#define BLOCK_BITS 1024

/* Updates the bits processed before calling Transform. 
 * The increment is BLOCK_BITS in all the blocks except the last.
 */
#define UPDATEBITS   state->bits_processed += BLOCK_BITS;


/* Expansion */

/* Processes 8 64 bits words, and returns 2.
 * Used by EXPANSION
 * Input words:
 *	wi20,wi19,wi16,wi15,wi6,wi5,wi4,wi3
 * Output words:
 *	wi,wim1
 */
#define PHI(wi,wim1,wi20,wi19,wi16,wi15,wi6,wi5,wi4,wi3) \
      wi=wi20^wi16^wi6^wi3;\
      wim1=((wi5+wi4)^wi19^wi15)+wi+(wi<<23);\
      wi^=(wim1>>15);


/* Macros for the round function */

#define F(X,Y,Z) ((~X)^(Y&(~Z)))
#define G(X,Y,Z) (Z^((~X)&(~Y)))
#define H(X,Y,Z) (Y^(X&Z))

/*Sbox in bitslice mode */
#define Sbox(m0,m1,m2) \
  { register uint64_t temp0, temp1;\
		temp0=F(m0,m1,m2);\
        temp1=G(m0,m1,m2);\
        m2=H(m0,m1,m2);\
        m0=temp0;\
		m1=temp1; }

#define PHTX(D)  \
       D+=(D<<32)+(D<<47);\
       D^=(D>>32)^(D>>43);

#define PHTXD(L,H)  \
	H^=L;\
	PHTX(H);\
	L^=H;\
	PHTX(L);

#define DIFFUSION(A,B,C,D,E,F,G,H) \
	A+=G;\
	B+=H;\
	PHTXD(C,D);\
	G+=E;\
	H+=F;

/* Round function
 * Input:
 *	A,B,C,D,E,F,G,H: state, as 8 64 bit words
 *	k0,k1,k2,k3,k4,k5: round key, as 6 64 bit words.
 * Output:
 *	A,B,C,D,E,F,G,H: state, modified by the S-Box
 */
#define ROUND(A,B,C,D,E,F,G,H,k0,k1,k2,k3,k4,k5) \
    A^=k0;\
	B^=k1;\
	C^=k2;\
	D^=k3;\
	E^=k4;\
    F^=k5;\
	G^=C;\
	H^=D;\
	PHTXD(G,H);\
    Sbox(A,C,E) ;\
	Sbox(B,D,F) ;\
    DIFFUSION(A,B,C,D,E,F,G,H);


void Transform512(hashState512* state);

/* Bitmask for zeroing the unused bits of the last byte of the message */
const static unsigned char BITMASK[] = {0x00, 0x80, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc, 0xfe};
/* Bitmask for adding a 1 after the last bit of the message */
const static unsigned char BITPADDING[] = { 0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01 };

/* IV for the 512 bit version */
const uint64_t  i512[STATE_DWORDS] = 
{
    0x6a09e667f3bcc908ull, 0xbb67ae8584caa73bull,
    0x3c6ef372fe94f82bull, 0xa54ff53a5f1d36f1ull,
    0x510e527fade682d1ull, 0x9b05688c2b3e6c1full,
    0x1f83d9abfb41bd6bull, 0x5be0cd19137e2179ull
};

/* IV for the 384 bit version */
const uint64_t  i384[STATE_DWORDS] =
{
    0x510e527fade682d1ull, 0x9b05688c2b3e6c1full,
    0x1f83d9abfb41bd6bull, 0x5be0cd19137e2179ull,
    0x6a09e667f3bcc908ull, 0xbb67ae8584caa73bull,
    0x3c6ef372fe94f82bull, 0xa54ff53a5f1d36f1ull
};


/* Initializes a hashState512 with the appropriate values for the 512 bit hash.
 * Parameters:
 *	state: a structure that holds the hashState512 information
 * Returns:
 *	SUCCESS - on success
 */
HashReturn Init512(hashState512 *state){
	state->previous_block = state->buffer; /* previous_block points to the first half of the buffer */
	state->data_block = state->buffer+BLOCK_DWORDS; /* data_block points to the second half of the buffer */
	state->bits_processed = 0; /* No bits, yet */
	state->bits_waiting_for_process = 0; /* No bits waiting */
	memcpy(state->state, i512, STATE_BYTES); /* Copying the IV */
	memcpy(state->previous_block, i384, STATE_BYTES); /* Initial state of the previous block. We copy the 384 bit IV, twice */
	memcpy(state->previous_block+STATE_DWORDS, i384, STATE_BYTES);
	return SUCCESS;
}

/* Initializes a hashState512 with the appropriate values for the 384 bit hash.
 * Parameters:
 *	state: a structure that holds the hashState512 information
 * Returns:
 *	SUCCESS - on success
 */
HashReturn Init384(hashState512 *state){
	state->previous_block = state->buffer; /* previous_block points to the first half of the buffer */
	state->data_block = state->buffer+BLOCK_DWORDS; /* data_block points to the second half of the buffer */
	state->bits_processed = 0; /* No bits, yet */
	state->bits_waiting_for_process = 0; /* No bits waiting */
	memcpy(state->state, i384, STATE_BYTES); /* Copying the IV */
	memcpy(state->previous_block, i512, STATE_BYTES); /* Initial state of the previous block. We copy the 512 bit IV, twice */
	memcpy(state->previous_block+STATE_DWORDS, i512, STATE_BYTES);
	return SUCCESS;
}


/* Process the supplied data.
 * Parameters:
 *	state: a structure that holds the hashState512 information
 *	data: the data to be hashed
 *	databitlen: the length, in bits, of the data to be hashed. 
 *	It must be a multiple of 8, except, possibly, in the last call
 * Returns:
 *	SUCCESS - on success
 */
HashReturn Update512(hashState512 *state, const BitSequence *data,
		DataLength databitlen) {
	DataLength offset, databytes;
	unsigned int remaining, index;
	BitSequence* byte_buffer;
	databytes = (databitlen >> 3); /* number of bytes to process */

	/*bytes waiting to be processed
	 * According to specifications, except for the last time, update will never be called with
	 * a number of bits not multiple of 8. Therefore, the number of bits that have been
	 * fed into the buffer but not processed after the last call of update must be
	 * a multiple of 8. Also, this number should be less than BLOCK_BYTES
	 */
	index = (state->bits_waiting_for_process >> 3);

	remaining = BLOCK_BYTES - index; /* space available in the buffer */
	offset = 0;

	/* If we have bytes waiting from a previous call, and there are enough
	 * to fill a block, we copy them and call to Transform
	 */
	if ((index != 0) && (databytes >= remaining)) {
		byte_buffer = (BitSequence*) state->data_block; /* buffer as an array of char */
		memcpy(byte_buffer + index, data, remaining); /* We fill the buffer */
		UPDATEBITS;
		Transform512(state);
		offset += remaining; /* We consumed 'remaining' bytes from data */
		index = 0; /* There are not bytes waiting for process */
		state->bits_waiting_for_process = 0; /* Therefore, no bits */
	}

	/* We process as many blocks as we can */
	while (offset + BLOCK_BYTES <= databytes) {
		memcpy(state->data_block, data + offset, BLOCK_BYTES);
		UPDATEBITS;
		Transform512(state);
		offset += BLOCK_BYTES;
	}
	if (databitlen & 7)
		databytes++; /* The number of bits is not a multiple of 8. This can only happen in the last call to update */
	byte_buffer = (BitSequence*) state->data_block;

	/* If there are still bytes in data, we copy them to the buffer */
	memcpy(byte_buffer + index, data + offset,(size_t) (databytes - offset));
	state->bits_waiting_for_process += (uint32_t) (databitlen - 8 * offset);;
	return SUCCESS;
}


/* Process the block stored in the buffer. 
 * Parameters:
 *	state: a structure that holds the hashState512 information
 * This optimized version also implements the functionality of the 
 * function Encrypt256() used in the Reference Implementation.
 */
void Transform512(hashState512* state) {
	uint64_t *k, *pk; /* Pointers for storing the block and the previous block */
	uint64_t H0, H1, H2, H3, H4, H5, H6, H7; /* 64 bit words, for storing the state */
	uint64_t W[64]; /* Array for the expanded key */

	/* First, we copy the hash state to the 8 words H0, H1, H2, H3, H4, H5, H6, H7 */	
	H0 = state->state[0];
	H1 = state->state[1];
	H2 = state->state[2];
	H3 = state->state[3];
	H4 = state->state[4];
	H5 = state->state[5];
	H6 = state->state[6];
	H7 = state->state[7];
	k = state->data_block;
	pk = state->previous_block;
	/*expansion*/
	W[0] = pk[0] ^ k[0];
	W[1] = pk[1] ^ k[1];
	W[2] = pk[2] ^ k[2];
	W[3] = pk[3] ^ k[3];	ROUND (H0, H1, H2, H3, H4, H5, H6, H7, W[0], W[1], k[0], k[1], W[2], W[3]);

	W[4] = pk[4] ^ k[4];
	W[5] = pk[5] ^ k[5];
	W[6] = pk[6] ^ k[6];
	W[7] = pk[7] ^ k[7];	ROUND (H2, H3, H4, H5, H6, H7, H0, H1, W[4], W[5], k[2], k[3], W[6], W[7]);

	W[8] = pk[8] ^ k[8];
	W[9] = pk[9] ^ k[9];
	W[10] = pk[10] ^ k[10];
	W[11] = pk[11] ^ k[11];	ROUND (H4, H5, H6, H7, H0, H1, H2, H3, W[8], W[9], k[4], k[5], W[10], W[11]);

	W[12] = pk[12] ^ k[12];
	W[13] = pk[13] ^ k[13];
	W[14] = pk[14] ^ k[14];
	W[15] = pk[15] ^ k[15];	ROUND (H6, H7, H0, H1, H2, H3, H4, H5, W[12], W[13], k[6], k[7], W[14], W[15]);


    PHI(W[16],W[17],(W[6]^pk[0]),(W[7]^pk[1]),(W[8]^pk[2]),(W[9]^pk[3]),(W[10]^pk[4]),(W[11]^pk[5]),(W[2]^pk[6]),(W[3]^pk[7]));
	PHI(W[18],W[19],(W[4]^0x428a2f98d728ae22ull^pk[8]),(W[5]^pk[9]),(W[14]^state->bits_processed^pk[10]),(W[15]^pk[11]),(W[12]^pk[14]),(W[13]^pk[15]),(W[0]^pk[12]),(W[1]^pk[13]));
	ROUND (H0, H1, H2, H3, H4, H5, H6, H7, W[16], W[17], k[8], k[9], W[18], W[19]);

    PHI(W[20],W[21],W[0],W[1],W[4],W[5],W[14],W[15],W[16],W[17]);
    PHI(W[22],W[23],W[2],W[3],W[6],W[7],W[16],W[17],W[18],W[19]);	ROUND (H2, H3, H4, H5, H6, H7, H0, H1, W[20], W[21], k[10], k[11], W[22], W[23]);

    PHI(W[24],W[25],W[4],W[5],W[8],W[9],W[18],W[19],W[20],W[21]);
    PHI(W[26],W[27],W[6],W[7],W[10],W[11],W[20],W[21],W[22],W[23]);	ROUND (H4, H5, H6, H7, H0, H1, H2, H3, W[24], W[25], k[12], k[13], W[26], W[27]);

    PHI(W[28],W[29],W[8],W[9],W[12],W[13],W[22],W[23],W[24],W[25]);
    PHI(W[30],W[31],W[10],W[11],W[14],W[15],W[24],W[25],W[26],W[27]);	ROUND (H6, H7, H0, H1, H2, H3, H4, H5, W[28], W[29], k[14], k[15], W[30], W[31]);

    PHI(W[32],W[33],W[12],W[13],W[16],W[17],W[26],W[27],W[28],W[29]);	ROUND (H0, H1, H2, H3, H4, H5, H6, H7, pk[0], pk[1], W[32], W[33], pk[2], pk[3]);

    PHI(W[34],W[35],W[14],W[15],W[18],W[19],W[28],W[29],W[30],W[31]);	ROUND (H2, H3, H4, H5, H6, H7, H0, H1, pk[4], pk[5], W[34], W[35], pk[6], pk[7]);

    PHI(W[36],W[37],W[16],W[17],W[20],W[21],W[30],W[31],W[32],W[33]);	ROUND (H4, H5, H6, H7, H0, H1, H2, H3, pk[8], pk[9], W[36], W[37], pk[10], pk[11]);

    PHI(W[38],W[39],W[18],W[19],W[22],W[23],W[32],W[33],W[34],W[35]);	ROUND (H6, H7, H0, H1, H2, H3, H4, H5, pk[12], pk[13], W[38], W[39], pk[14], pk[15]);

    PHI(W[40],W[41],W[20],W[21],W[24],W[25],W[34],W[35],W[36],W[37]);
    PHI(W[42],W[43],W[22],W[23],W[26],W[27],W[36],W[37],W[38],W[39]);
    PHI(W[44],W[45],W[24],W[25],W[28],W[29],W[38],W[39],W[40],W[41]);	ROUND (H0, H1, H2, H3, H4, H5, H6, H7, W[40], W[41], W[42], W[43], W[44], W[45]);

    PHI(W[46],W[47],W[26],W[27],W[30],W[31],W[40],W[41],W[42],W[43]);
    PHI(W[48],W[49],W[28],W[29],W[32],W[33],W[42],W[43],W[44],W[45]);
    PHI(W[50],W[51],W[30],W[31],W[34],W[35],W[44],W[45],W[46],W[47]);	ROUND (H2, H3, H4, H5, H6, H7, H0, H1, W[46], W[47], W[48], W[49], W[50], W[51]);

    PHI(W[52],W[53],W[32],W[33],W[36],W[37],W[46],W[47],W[48],W[49]);
    PHI(W[54],W[55],W[34],W[35],W[38],W[39],W[48],W[49],W[50],W[51]);
    PHI(W[56],W[57],W[36],W[37],W[40],W[41],W[50],W[51],W[52],W[53]);	ROUND (H4, H5, H6, H7, H0, H1, H2, H3, W[52], W[53], W[54], W[55], W[56], W[57]);

    PHI(W[58],W[59],W[38],W[39],W[42],W[43],W[52],W[53],W[54],W[55]);
    PHI(W[60],W[61],W[40],W[41],W[44],W[45],W[54],W[55],W[56],W[57]);
    PHI(W[62],W[63],W[42],W[43],W[46],W[47],W[56],W[57],W[58],W[59]);	ROUND (H6, H7, H0, H1, H2, H3, H4, H5, W[58], W[59], W[60], W[61], W[62], W[63]);

	/* Now, we xor the encrypted state with the original state */	
	state->state[0] ^= H0;
	state->state[1] ^= H1;
	state->state[2] ^= H2;
	state->state[3] ^= H3;
	state->state[4] ^= H4;
	state->state[5] ^= H5;
	state->state[6] ^= H6;
	state->state[7] ^= H7;

	/* Finally, we swap pointers */
	state->data_block = pk;
	state->previous_block = k; /* now previous_block points to the block just processed */
}



/* Perform post processing and output filtering and return the final hash value.
 * This function is called from Final512() or Final384()
 * Parameters:
 *	state: a structure that holds the hashState512 information
 *	hashval: the storage for the final hash value to be returned
 *	hashbytes: the number of bytes to store in hashval
 *		(48 for the 384 bit hash, 64 for the 512 bit hash)
 * Returns:
 *	SUCCESS - on success
 */
HashReturn _Final512 (hashState512 *state, BitSequence *hashval, int hashbytes){
	int j;
	BitSequence* byte_buffer;
	unsigned int index, bits;

	/* if there is any data to be processed, we need to pad and process, 
	 * otherwise we	go to the last block*/
	if(state->bits_waiting_for_process){
		/* If bits_waiting_for_process is not a multiple of 8, index will be the last byte,
		 * and bits will be the number of valid bits in that byte.
		 */
		index = state->bits_waiting_for_process >> 3;
		bits =  state->bits_waiting_for_process & 7;

		/* We zero the unused bits of the last byte, and set the fist unused bit to 1 */
		byte_buffer = (BitSequence*) state->data_block;
		byte_buffer[index] = (byte_buffer[index] & BITMASK[bits]) | BITPADDING[bits];
		index++;
		memset(byte_buffer+index, 0, BLOCK_BYTES - index); /* We fill the rest of the block with zeros */

		/*the usual update of bits processed cannot be used here, since
		 *less than a full block of DATA has been processed
		 */	
		state->bits_processed += state->bits_waiting_for_process; 

		Transform512(state);
	}/*endif(bits_waiting_for_process)*/
   
	/* All data (plus any padding) has been processed. A last call, so that the last block
	 * of data is treated like all the others (i.e., twice) is made. The new block is simply the number of
	 * bits processed, xor the last state. 
	 */
	state->data_block[0]=state->bits_processed;
	for(j=1;j < STATE_DWORDS;j++) state->data_block[j]=0; /* The size of the block is twice the size of the state */
	memcpy(state->data_block + STATE_DWORDS, state->state, STATE_BYTES);
	state->bits_processed = 0; /* This ensures that the final transform is the same regardless of the bits processed */
	Transform512(state);
	
	/* We output the appropriate number of bytes, truncating the state if necessary */
	for (j = 0; j < hashbytes; j++)
		hashval[j] = ((BitSequence*)state->state)[j];
	return SUCCESS;
}

/* Perform post processing and output filtering and return the final 512 bit hash value.
 * Parameters:
 *	state: a structure that holds the hashState512 information
 *	hashval: the storage for the final hash value to be returned
 * Returns:
 *	SUCCESS - on success
 */
HashReturn Final512(hashState512 *state, BitSequence *hashval){
	return _Final512(state,hashval,HASH_BYTES_512);
}

/* Perform post processing and output filtering and return the final 384 bit hash value.
 * Parameters:
 *	state: a structure that holds the hashState512 information
 *	hashval: the storage for the final hash value to be returned
 * Returns:
 *	SUCCESS - on success
 */
HashReturn Final384(hashState512 *state, BitSequence *hashval){
	return _Final512(state,hashval,HASH_BYTES_384);
}


/* Hash the supplied data and provide the resulting hash value. Set return code as
 * appropriate. 512 bit version.
 * Parameters:
 *	data: the data to be hashed
 *	databitlen: the length, in bits, of the data to be hashed
 *	hashval: the resulting hash value of the provided data
 * Returns:
 *	SUCCESS - on success
*/
HashReturn Hash512(const BitSequence *data, DataLength databitlen, BitSequence *hashval){
	hashState512 state;
	HashReturn status;
	status = Init512(&state);
	if (status != SUCCESS) return status;
	status = Update512(&state, data, databitlen);
	if (status != SUCCESS) return status;
	return _Final512(&state, hashval,HASH_BYTES_512);
}

/* Hash the supplied data and provide the resulting hash value. Set return code as
 * appropriate. 384 bit version.
 * Parameters:
 *	data: the data to be hashed
 *	databitlen: the length, in bits, of the data to be hashed
 *	hashval: the resulting hash value of the provided data
 * Returns:
 *	SUCCESS - on success
*/
HashReturn Hash384(const BitSequence *data, DataLength databitlen, BitSequence *hashval){
	hashState512 state;
	HashReturn status;
	status = Init384(&state);
	if (status != SUCCESS) return status;
	status = Update512(&state, data, databitlen);
	if (status != SUCCESS) return status;
	return _Final512(&state, hashval,HASH_BYTES_384);
}

