/*
 * encrypt512.c
 *
 */
#include "global.h"
#include <stdio.h>

extern FILE *fp_out;

#define PHI(wi,wim1,wi20,wi19,wi16,wi15,wi6,wi5,wi4,wi3) \
      wi=wi20^wi16^wi6^wi3;\
      wim1=((wi5+wi4)^wi19^wi15)+wi+(wi<<23);\
      wi^=(wim1>>15);

#define EXPANSION(W) \
	PHI(W[16],W[17],(W[6]^pk[0]),(W[7]^pk[1]),(W[8]^pk[2]),(W[9]^pk[3]),(W[10]^pk[4]),(W[11]^pk[5]),(W[2]^pk[6]),(W[3]^pk[7]));\
    PHI(W[18],W[19],(W[4]^0x428a2f98d728ae22ull^pk[8]),(W[5]^pk[9]),(W[14]^bits^pk[10]),(W[15]^pk[11]),(W[12]^pk[14]),(W[13]^pk[15]),(W[0]^pk[12]),(W[1]^pk[13]));\
    for( i = 20; i!=64; i=i+2) {\
        PHI(W[i],W[i+1],W[i-20],W[i-19],W[i-16],W[i-15],W[i-6],W[i-5],W[i-4],W[i-3]);\
    }

#define F(X,Y,Z) ((~X)^(Y&(~Z)))
#define G(X,Y,Z) (Z^((~X)&(~Y)))
#define H(X,Y,Z) (Y^(X&Z))

/*Sbox in bitslice mode */
#define Sbox(m0,m1,m2) \
  { register uint64_t temp0, temp1;\
		temp0=F(m0,m1,m2);\
        temp1=G(m0,m1,m2);\
        m2=H(m0,m1,m2);\
        m0=temp0;\
		m1=temp1; }

#define PHD(D)  \
       D+=(D<<32)+(D<<47);\
       D^=(D>>32)^(D>>43);

#define PHTX(L,H)  \
	H^=L;\
	PHD(H);\
	L^=H;\
	PHD(L);

#define DIFUSION(A,B,C,D,E,F,G,H) \
	A+=G;\
	B+=H;\
	PHTX(C,D);\
	G+=E;\
	H+=F;


/*photograph the state*/

#define ROUND(A,B,C,D,E,F,G,H,k0,k1,k2,k3,k4,k5) \
	rndcounter++;\
	fprintf(fp_out,"Round # %2i:\n",rndcounter);\
	fprintf(fp_out,"Start      : 0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",A,B,C,D);\
	fprintf(fp_out,"             0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",E,F,G,H);\
    	A^=k0;\
	B^=k1;\
	C^=k2;\
	D^=k3;\
	E^=k4;\
    	F^=k5;\
	G^=C;\
	H^=D;\
	fprintf(fp_out,"kymx+CDxorGH:0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",A,B,C,D);\
	fprintf(fp_out,"             0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",E,F,G,H);\
	PHTX(G,H);\
    	Sbox(A,C,E) ;\
	Sbox(B,D,F) ;\
	fprintf(fp_out,"sbx+phtx(GH):0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",A,B,C,D);\
	fprintf(fp_out,"             0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",E,F,G,H);\
    	DIFUSION(A,B,C,D,E,F,G,H);\
	fprintf(fp_out,"end wout rot:0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",A,B,C,D);\
	fprintf(fp_out,"             0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",E,F,G,H);



#define FOURROUNDSBOX(k0,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10,k11,k12,k13,k14,k15,k16,k17,k18,k19,k20,k21,k22,k23,h0,h1,h2,h3,h4,h5,h6,h7)\
    ROUND(h0,h1,h2,h3,h4,h5,h6,h7,k0,k1,k2,k3,k4,k5);\
    ROUND(h2,h3,h4,h5,h6,h7,h0,h1,k6,k7,k8,k9,k10,k11);\
	ROUND(h4,h5,h6,h7,h0,h1,h2,h3,k12,k13,k14,k15,k16,k17);\
	ROUND(h6,h7,h0,h1,h2,h3,h4,h5,k18,k19,k20,k21,k22,k23);\


#define INPUTONE(F) F(W[0],W[1],k[0],k[1],W[2],W[3],W[4],W[5],k[2],k[3],W[6],W[7],W[8],W[9],k[4],k[5],W[10],W[11],W[12],W[13],k[6],k[7],W[14],W[15],hsh[0],hsh[1],hsh[2],hsh[3],hsh[4],hsh[5],hsh[6],hsh[7]);

#define INPUTTWO(F) F(W[16],W[17],k[8],k[9],W[18],W[19],W[20],W[21],k[10],k[11],W[22],W[23],W[24],W[25],k[12],k[13],W[26],W[27],W[28],W[29],k[14],k[15],W[30],W[31],hsh[0],hsh[1],hsh[2],hsh[3],hsh[4],hsh[5],hsh[6],hsh[7]);

#define INPUTTHREE(F) F(pk[0],pk[1],W[32],W[33],pk[2],pk[3],pk[4],pk[5],W[34],W[35],pk[6],pk[7],pk[8],pk[9],W[36],W[37],pk[10],pk[11],pk[12],pk[13],W[38],W[39],pk[14],pk[15],hsh[0],hsh[1],hsh[2],hsh[3],hsh[4],hsh[5],hsh[6],hsh[7]);

#define INPUTFOUR(F)  F(W[40],W[41],W[42],W[43],W[44],W[45],W[46],W[47],W[48],W[49],W[50],W[51],W[52],W[53],W[54],W[55],W[56],W[57],W[58],W[59],W[60],W[61],W[62],W[63],hsh[0],hsh[1],hsh[2],hsh[3],hsh[4],hsh[5],hsh[6],hsh[7]);


void Encrypt512(uint64_t hsh[8], uint64_t k[16], uint64_t pk[16],
		uint64_t bits) {
	/* Start  */

	uint64_t W[64];
	int i;
	int rndcounter; /*added as aid in taking photographs*/
	fprintf(fp_out,"Start Encrypt:");
	fprintf(fp_out,"   LEFT KEY            RIGHT KEY   \n");
	for (i = 0; i<16; i++) fprintf(fp_out,"              0x%016llx 0x%016llx\n",k[i],pk[i]);

	/*expansion*/
	W[0] = pk[0] ^ k[0];
	for (i = 15; i; i--)
		W[i] = pk[i] ^ k[i];

	EXPANSION(W);
	rndcounter=0;
	fprintf(fp_out,"State       :        A/E                B/F              C/G                 D/H\n");
	INPUTONE(FOURROUNDSBOX);
	INPUTTWO(FOURROUNDSBOX);
	INPUTTHREE(FOURROUNDSBOX);
	INPUTFOUR(FOURROUNDSBOX);
	fprintf(fp_out,"End Encrypt: 0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",hsh[0],hsh[1],hsh[2],hsh[3]);
	fprintf(fp_out,"             0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",hsh[4],hsh[5],hsh[6],hsh[7]);
}
