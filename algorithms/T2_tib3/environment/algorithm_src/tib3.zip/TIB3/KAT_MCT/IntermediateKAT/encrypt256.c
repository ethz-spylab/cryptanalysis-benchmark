/*
 * encrypt256.c
 with photographs of the state
 */

#include "global.h"
#include <stdio.h>

extern FILE *fp_out;

 /* Expansion */
#define PSI(di,di10,di8,di3,di2) \
	di=(di3+(di2<<32))^di10^di8^(di2>>32);\
	di+=(di<<32)+(di<<43);\
	di^=(di>>39);

#define EXPANSION(D) \
   PSI(D[8],(D[3]^pk[0]),(D[4]^pk[1]),(D[5]^pk[2]),(D[1]^pk[3]));\
   PSI(D[9],(D[2]^0x428a2f98d728ae22ull^pk[4]),(D[7]^bits^pk[5]),(D[6]^pk[7]),(D[0]^pk[6]));\
   for( i = 10; i!=32;i++) {\
     PSI(D[i],D[i-10],D[i-8],D[i-3],D[i-2]);\
   }

/* Macros used in the round function */
#define F(X,Y,Z) ((~X)^(Y&(~Z)))
#define G(X,Y,Z) (Z^((~X)&(~Y)))
#define H(X,Y,Z) (Y^(X&Z))

/*bitsliced Sbox */
#define Sbox(m0,m1,m2)    \
{ register uint64_t temp0, temp1;\
        temp0=F(m0,m1,m2);         \
        temp1=G(m0,m1,m2);         \
        m2=H(m0,m1,m2);         \
        m0=temp0;                  \
	    m1=temp1; }

#define PHTX(D)  \
       D+=(D<<32)+(D<<47);\
       D^=(D>>32)^(D>>43);

#define DIFUSION(A,C,E,G) \
	A=((A&0xffffffff00000000)+(G&0xffffffff00000000))|((A+G)&0xffffffff);\
	PHTX(C);\
	G=((G&0xffffffff00000000)+(E&0xffffffff00000000))|((G+E)&0xffffffff);


/*In the usual round macro we add at the beggining a printf of the state.
*/




#define ROUND(A,C,E,G,k0,k2,k4) \
	rndcounter++;\
	fprintf(fp_out,"Round # %2i:\n",rndcounter);\
	fprintf(fp_out,"Start      : 0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",A,C,E,G);\
    A^=k0;\
	C^=k2;\
	E^=k4;\
	G^=C;\
fprintf(fp_out,"keymix+CxorG:0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",A,C,E,G);\
	PHTX(G);\
    Sbox(A,C,E) ;\
fprintf(fp_out,"sbox+phtx(G):0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",A,C,E,G);\
    DIFUSION(A,C,E,G);\
fprintf(fp_out,"end wout rot:0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",A,C,E,G);\

#define FOURROUNDSBOX(k0,k2,k4,k6,k8,k10,k12,k14,k16,k18,k20,k22,h0,h2,h4,h6)\
    ROUND(h0,h2,h4,h6,k0,k2,k4);\
    ROUND(h2,h4,h6,h0,k6,k8,k10);\
	ROUND(h4,h6,h0,h2,k12,k14,k16);\
	ROUND(h6,h0,h2,h4,k18,k20,k22);

#define INPUTONE(F) F(D[0],k[0],D[1],D[2],k[1],D[3],D[4],k[2],D[5],D[6],k[3],D[7],hsh[0],hsh[1],hsh[2],hsh[3]);

#define INPUTTWO(F) F(D[8],k[4],D[9],D[10],k[5],D[11],D[12],k[6],D[13],D[14],k[7],D[15],hsh[0],hsh[1],hsh[2],hsh[3]);

#define INPUTTHREE(F) F(pk[0],D[16],pk[1],pk[2],D[17],pk[3],pk[4],D[18],pk[5],pk[6],D[19],pk[7],hsh[0],hsh[1],hsh[2],hsh[3]);

#define INPUTFOUR(F) F(D[20],D[21],D[22],D[23],D[24],D[25],D[26],D[27],D[28],D[29],D[30],D[31],hsh[0],hsh[1],hsh[2],hsh[3]);







#define FOURROUNDSBOX(k0,k2,k4,k6,k8,k10,k12,k14,k16,k18,k20,k22,h0,h2,h4,h6)\
    ROUND(h0,h2,h4,h6,k0,k2,k4);\
    ROUND(h2,h4,h6,h0,k6,k8,k10);\
	ROUND(h4,h6,h0,h2,k12,k14,k16);\
	ROUND(h6,h0,h2,h4,k18,k20,k22);



void Encrypt256(uint64_t hsh[4], uint64_t k[8], uint64_t pk[8],
		uint64_t bits) {
	uint64_t D[32];
	int i;
	int rndcounter;/*added to get photogrphs*/
	/* Start  */
	fprintf(fp_out,"Start Encrypt:");
	fprintf(fp_out,"   LEFT KEY            RIGHT KEY   \n");
	for (i = 0; i<8; i++) fprintf(fp_out,"              0x%016llx 0x%016llx\n",k[i],pk[i]);
	/*expansion*/
	D[0] = pk[0] ^ k[0];
	for (i = 7; i; i--)
		D[i] = pk[i] ^ k[i];

	EXPANSION(D);
	rndcounter=0;
	fprintf(fp_out,"State       :        A                  C                E                    G\n");
	INPUTONE(FOURROUNDSBOX);
	INPUTTWO(FOURROUNDSBOX);
	INPUTTHREE(FOURROUNDSBOX);
	INPUTFOUR(FOURROUNDSBOX);
	fprintf(fp_out,"End Encrypt: 0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",hsh[0],hsh[1],hsh[2],hsh[3]);

}

