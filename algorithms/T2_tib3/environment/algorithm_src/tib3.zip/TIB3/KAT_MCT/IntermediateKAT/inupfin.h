#ifndef INUPFIN_H_
#define INUPFIN_H_

#include "global.h"
/* 256 bits */
#define STATE_DWORDS_256 4 /* a DWORD is 64 bits */
#define STATE_BYTES_256 32 // in bytes
#define BLOCK_DWORDS_256 8
#define BLOCK_BYTES_256 64 // in bytes
#define HASH_BYTES_256  32 // in bytes
#define HASH_BITLEN_256 256

/* 224 bits */
#define STATE_DWORDS_224 STATE_DWORDS_256
#define STATE_BYTES_224 STATE_BYTES_256 // in bytes
#define BLOCK_DWORDS_224 BLOCK_DWORDS_256
#define BLOCK_BYTES_224 BLOCK_BYTES_256 // in bytes
#define HASH_BYTES_224  28 // in bytes
#define HASH_BITLEN_224 224

/* 512 bits */
#define STATE_DWORDS_512 8
#define STATE_BYTES_512 64 // in bytes
#define BLOCK_DWORDS_512 16
#define BLOCK_BYTES_512 128 // in bytes
#define HASH_BYTES_512  64// in bytes
#define HASH_BITLEN_512 512

/* 512 bits */
#define STATE_DWORDS_384 STATE_DWORDS_512
#define STATE_BYTES_384 STATE_BYTES_512 // in bytes
#define BLOCK_DWORDS_384 BLOCK_DWORDS_512
#define BLOCK_BYTES_384 BLOCK_BYTES_512 // in bytes
#define HASH_BYTES_384  48 // in bytes
#define HASH_BITLEN_384 384


typedef struct {
  	uint64_t state[STATE_DWORDS_256];
  	uint64_t bits_processed;
  	uint64_t buffer[2*BLOCK_DWORDS_256];     /* input buffer */
  	uint64_t *previous_block;
  	uint64_t *data_block;
	uint32_t bits_waiting_for_process;
} hashState256;

typedef struct {
  	uint64_t state[STATE_DWORDS_512];
  	uint64_t bits_processed;
  	uint64_t buffer[2*BLOCK_DWORDS_512];     /* input buffer */
  	uint64_t *previous_block;
  	uint64_t *data_block;
	uint32_t bits_waiting_for_process;
} hashState512;

typedef struct {
	int hashbitlen;
	union {
		hashState256 state256[1];
		hashState512 state512[1];
	} uu[1];
} hashState;

HashReturn Init (hashState *state, int hashbitlen);
HashReturn Update (hashState *state , const BitSequence *data, DataLength databitlen);
HashReturn Final (hashState *state, BitSequence *hashval);
HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen, BitSequence *hashval);

HashReturn Init256 (hashState256 *state);
HashReturn Update256 (hashState256 *state , const BitSequence *data, DataLength databitlen);
HashReturn Final256 (hashState256 *state, BitSequence *hashval);
HashReturn Hash256(const BitSequence *data, DataLength databitlen, BitSequence *hashval);

HashReturn Init224 (hashState256 *state);
HashReturn Update256 (hashState256 *state , const BitSequence *data, DataLength databitlen);
HashReturn Final224 (hashState256 *state, BitSequence *hashval);
HashReturn Hash224(const BitSequence *data, DataLength databitlen, BitSequence *hashval);

HashReturn Init512 (hashState512 *state);
HashReturn Update512 (hashState512 *state , const BitSequence *data, DataLength databitlen);
HashReturn Final512 (hashState512 *state, BitSequence *hashval);
HashReturn Hash512(const BitSequence *data, DataLength databitlen, BitSequence *hashval);

HashReturn Init384 (hashState512 *state);
HashReturn Update384 (hashState512 *state , const BitSequence *data, DataLength databitlen);
HashReturn Final384 (hashState512 *state, BitSequence *hashval);
HashReturn Hash384(const BitSequence *data, DataLength databitlen, BitSequence *hashval);



#endif /*INUPFIN_H_*/
