#ifndef GLOBAL_H_
#define GLOBAL_H_

typedef unsigned char BitSequence;
typedef enum { SUCCESS = 0, FAIL = 1, BAD_HASHLEN = 2 } HashReturn;
typedef unsigned long long DataLength;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;

#endif /*GLOBAL_H_*/
