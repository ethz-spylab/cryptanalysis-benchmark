#include <string.h>
#include <stdio.h>
#include "inupfin.h"

#define STATE_DWORDS STATE_DWORDS_512
#define STATE_BYTES STATE_BYTES_512
#define BLOCK_DWORDS BLOCK_DWORDS_512
#define BLOCK_BYTES BLOCK_BYTES_512
#define HASH_BYTES HASH_BYTES_512
#define BLOCK_BITS 1024

#define UPDATEBITS   state->bits_processed += BLOCK_BITS;

extern FILE *fp_out;

void Encrypt512(uint64_t hsh[STATE_DWORDS], uint64_t k[BLOCK_DWORDS],uint64_t pk[BLOCK_DWORDS],uint64_t bits);
void Transform512(hashState512* state);

const static unsigned char BITMASK[] = {0x00, 0x80, 0xc0, 0xe0, 0xf0, 0xf8, 0xfc, 0xfe};
const static unsigned char BITPADDING[] = { 0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01 };


const uint64_t  i512[8] =  /* STATE DWORDS */
{
    0x6a09e667f3bcc908ull, 0xbb67ae8584caa73bull,
    0x3c6ef372fe94f82bull, 0xa54ff53a5f1d36f1ull,
    0x510e527fade682d1ull, 0x9b05688c2b3e6c1full,
    0x1f83d9abfb41bd6bull, 0x5be0cd19137e2179ull
};

const uint64_t  i384[8] =
{
    0x510e527fade682d1ull, 0x9b05688c2b3e6c1full,
    0x1f83d9abfb41bd6bull, 0x5be0cd19137e2179ull,
    0x6a09e667f3bcc908ull, 0xbb67ae8584caa73bull,
    0x3c6ef372fe94f82bull, 0xa54ff53a5f1d36f1ull
};



HashReturn Init512(hashState512 *state){
	state->previous_block = state->buffer;
	state->data_block = state->buffer+BLOCK_DWORDS;
	state->bits_processed = 0;
	state->bits_waiting_for_process = 0;
	memcpy(state->state, i512, STATE_BYTES);
	memcpy(state->previous_block, i384, STATE_BYTES);
	memcpy(state->previous_block+(BLOCK_DWORDS >> 1), i384, STATE_BYTES);
	return SUCCESS;
}

HashReturn Init384(hashState512 *state){
	state->previous_block = state->buffer;
	state->data_block = state->buffer+BLOCK_DWORDS;
	state->bits_processed = 0;
	state->bits_waiting_for_process = 0;
	memcpy(state->state, i384, STATE_BYTES);
	memcpy(state->previous_block, i512, STATE_BYTES);
	memcpy(state->previous_block+(BLOCK_DWORDS >> 1), i512, STATE_BYTES);
	return SUCCESS;
}



HashReturn Update512(hashState512 *state, const BitSequence *data,
		DataLength databitlen) {
	DataLength offset, databytes;
	unsigned int remaining, index;
	BitSequence* byte_buffer;
	databytes = (databitlen >> 3); /* number of bytes to process */
	index = (state->bits_waiting_for_process >> 3);/*bytes waiting to be processed
	 According to specifications, except for the last time, update will never be called with
	 a number of bits not multiple of 8. Therefore, the number of bits that have been
	 fed into the buffer but not processed after the last call of update must be
	 a multiple of 8. Also, this number should be less than BLOCK_BYTES*/
	remaining = BLOCK_BYTES - index;
	offset = 0;
	if ((index != 0) && (databytes >= remaining)) {
		byte_buffer = (BitSequence*) state->data_block; /* buffer as an array of char */
		memcpy(byte_buffer + index, data, remaining);
		UPDATEBITS;
		Transform512(state);
		offset += remaining;
		index = 0;
		state->bits_waiting_for_process = 0;
	}
	while (offset + BLOCK_BYTES <= databytes) {
		memcpy(state->data_block, data + offset, BLOCK_BYTES);
		UPDATEBITS;
		Transform512(state);
		offset += BLOCK_BYTES;
	}
	if (databitlen & 7)
		databytes++; /* The number of bits is not a multiple of 8. This can only happen in the last call to update */
	byte_buffer = (BitSequence*) state->data_block;
	memcpy(byte_buffer + index, data + offset, databytes - offset);
	state->bits_waiting_for_process += (uint32_t) (databitlen - 8 * offset);;
	return SUCCESS;
}


void Transform512(hashState512* state){
	uint64_t temp[STATE_DWORDS];
	uint64_t* swap_aux;
	int i;
	memcpy(temp,state->state,STATE_BYTES);
	Encrypt512(temp, state->data_block, state->previous_block,state->bits_processed);
	for (i = 0; i < STATE_DWORDS; i++)
		state->state[i] ^= temp[i];
	swap_aux = state->data_block;
	state->data_block = state->previous_block;
	state->previous_block = swap_aux; /* now previous_block points to the block just processed */
	fprintf(fp_out, "\n########################################################################################\n\n");
	fprintf(fp_out,"Davies-Meyer:0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",state->state[0],state->state[1],state->state[2],state->state[3]);
	fprintf(fp_out,"             0x%016llx 0x%016llx 0x%016llx 0x%016llx\n",state->state[4],state->state[5],state->state[6],state->state[7]);
	fprintf(fp_out, "\n########################################################################################\n\n");
}




HashReturn _Final512 (hashState512 *state, BitSequence *hashval, int hashbytes){
	int j;
	BitSequence* byte_buffer;
	unsigned int index, bits;
	if(state->bits_waiting_for_process){/*if there is any data to be processed,
				 	we need to padd and process, otherwise we
					go to the last block*/

		index = state->bits_waiting_for_process >> 3;
		bits =  state->bits_waiting_for_process & 7;
		byte_buffer = (BitSequence*) state->data_block;
		byte_buffer[index] = (byte_buffer[index] & BITMASK[bits]) | BITPADDING[bits];
		index++;
		memset(byte_buffer+index, 0, BLOCK_BYTES - index);
		state->bits_processed += state->bits_waiting_for_process; /*the usual update of bits processed cannot be used here, since
		less than a full block of DATA has been processed*/

		Transform512(state);
	}/*endif(bits_waiting_for_process)*/
   /*all data (plus any padding) has been processed. A last call, so that the last block
   of data is treated like all the others (i.e., twice) is made. The new block is simply the number of
   bits processed. */
	state->data_block[0]=state->bits_processed;
	for(j=1;j < STATE_DWORDS;j++) state->data_block[j]=0; /* The size of the block is twice the size of the state */
	memcpy(state->data_block + STATE_DWORDS, state->state, STATE_BYTES);
	state->bits_processed = 0; /* This ensures that the final transform is the same regardless of the bits processed */
	Transform512(state);
	for (j = 0; j < hashbytes; j++)
		hashval[j] = ((BitSequence*)state->state)[j];
	return SUCCESS;
}


HashReturn Final512(hashState512 *state, BitSequence *hashval){
	return _Final512(state,hashval,HASH_BYTES_512);
}

HashReturn Final384(hashState512 *state, BitSequence *hashval){
	return _Final512(state,hashval,HASH_BYTES_384);
}






/* Hash the supplied data and provide the resulting hash value. Set return code as
 * appropriate. 512 bit version.
 * Parameters:
 *	data: the data to be hashed
 *	databitlen: the length, in bits, of the data to be hashed
 *	hashval: the resulting hash value of the provided data
 * Returns:
 *	SUCCESS - on success
*/
HashReturn Hash512(const BitSequence *data, DataLength databitlen, BitSequence *hashval){
	hashState512 state;
	HashReturn status;
	status = Init512(&state);
	if (status != SUCCESS) return status;
	status = Update512(&state, data, databitlen);
	if (status != SUCCESS) return status;
	return _Final512(&state, hashval,HASH_BYTES_512);
}

/* Hash the supplied data and provide the resulting hash value. Set return code as
 * appropriate. 384 bit version.
 * Parameters:
 *	data: the data to be hashed
 *	databitlen: the length, in bits, of the data to be hashed
 *	hashval: the resulting hash value of the provided data
 * Returns:
 *	SUCCESS - on success
*/
HashReturn Hash384(const BitSequence *data, DataLength databitlen, BitSequence *hashval){
	hashState512 state;
	HashReturn status;
	status = Init384(&state);
	if (status != SUCCESS) return status;
	status = Update512(&state, data, databitlen);
	if (status != SUCCESS) return status;
	return _Final512(&state, hashval,HASH_BYTES_384);
}





