
#include "inupfin.h"



HashReturn Init(hashState *state, int hashbitlen){
	switch (hashbitlen){
	case 256: 	state->hashbitlen = 256;
				return Init256(state->uu->state256);
	case 224: 	state->hashbitlen = 224;
				return Init224(state->uu->state256);
	case 512: 	state->hashbitlen = 512;
				return Init512(state->uu->state512);
	case 384: 	state->hashbitlen = 384;
				return Init384(state->uu->state512);
	default: return BAD_HASHLEN;
	}
}


HashReturn Update (hashState *state ,const BitSequence *data, DataLength databitlen){
	switch (state->hashbitlen){
	case 224:
	case 256: return Update256(state->uu->state256, data, databitlen);
	case 384:
	case 512: return Update512(state->uu->state512, data, databitlen);
	default: return BAD_HASHLEN;
	}
}


HashReturn Final (hashState *state, BitSequence *hashval){
	switch (state->hashbitlen){
	case 256: return Final256(state->uu->state256, hashval);
	case 224: return Final224(state->uu->state256, hashval);
	case 512: return Final512(state->uu->state512, hashval);
	case 384: return Final384(state->uu->state512, hashval);
	default: return BAD_HASHLEN;
	}
}


/* Hash the supplied data and provide the resulting hash value. Set return code as
 * appropriate.
 * Parameters:
 *	hashbitlen: the length in bits of the desired hash value
 *	data: the data to be hashed
 *	databitlen: the length, in bits, of the data to be hashed
 *	hashval: the resulting hash value of the provided data
 * Returns:
 *	SUCCESS - on success
 *	BAD_HASHBITLEN � unknown hashbitlen requested
*/
HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen, BitSequence *hashval){
	hashState state;
	HashReturn status;
	status = Init(&state, hashbitlen);
	if (status != SUCCESS) return status;
	status = Update(&state, data, databitlen);
	if (status != SUCCESS) return status;
	return Final(&state, hashval);
}





