README.txt � Packing List

IP statements:
* Statement by the submitter, Rich Schroeppel
* Signed statement by the patent and patent application owner, Rich Schroeppel
* Signed statement by reference/optimized implementation owner, Rich Schroeppel

Hardcopy Documentation:
Printed copy of The Sandstorm Hash Algorithm document.
Printed copy of the reference & optimized implementations 
Printed copy of the README file for the CDs

Electronic Media:
Electronic copies of the software and documentation on two separate CDs with 
the following directorites.

README
* README.txt

Reference_Implementation
* Sha3api_ref.c
* Sha3api_ref.h
* Sha3_ref.h

Optimized_32bit
* Sha3api_opt.c
* Sha3api_ref.h
* Sha3_ref.h
* DoBlockModMix.h

Optimized_64bit (identical to Optimized_32bit)
* Sha3api_opt.c
* Sha3api_ref.h
* Sha3_ref.h
* DoBlockModMix.h

Alternate Implementations
* SANDstormAlt subfolder holding an alternate implementation of SANDstorm 
  and an associated genKAT file
  * Sandstormalt.c - alternate implementation of SANDstorm
  * genKATalt.c
* IntermediateVals.c � File for printing intermediate values

KAT_MCT
* NIST KAT-files for normal SANDstorm
* Subfolder TSP:  NIST KAT-files for SANDstorm with additional security
* Subfolder IntermediateValues:  
  * IntermediateVals.txt: 
    File with test messages for intermediate values 
  * IntermediateValues.txt:
    File with intermediate values for multiple test messages and all 
    message digest sizes (224, 256, 384, and 512)

Supporting_Documentation
* SANDstorm.doc
* SANDstorm.pdf

