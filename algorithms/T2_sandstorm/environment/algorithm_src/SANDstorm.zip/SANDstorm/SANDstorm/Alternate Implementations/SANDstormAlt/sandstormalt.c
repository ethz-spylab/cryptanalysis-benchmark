// SANDstorm
//
// Rich Schroeppel
// email: rschroe at sandia.gov
// October 30, 2008
// This program computes the SANDstorm hash function, producing hashes of
// lengths 224/256/384/512 bit.
// This is research code: use at your own risk, blah blah blah.

// compile standalone with MAIN=1,  cc -o htest sandstormalt.c
// or inserted from genKATalt.c and MAIN=0,  cc -o htest genKATalt.c

// 224/256 bit hash function uses arithmetic on 64-bit quantities
// 384/512 bit hash function uses arithmetic on 128-bit quantities

// tunable security parameter
// should be an even number betwenn 0 and 20
#define TUNABLE_SECURITY_PARAMETER	0

typedef unsigned char BitSequence;
typedef unsigned long long DataLength; //typical 64 bit value
typedef enum { 
	SUCCESS = 0, 
	FAIL = 1, 
	BAD_HASHBITLEN = 2 
} HashReturn;


#define MAIN 0
#define sandwstate hashState

typedef unsigned long u32;
typedef unsigned long long u64;

typedef struct { u64 hi; u64 lo; } u128;

// make a 128 bit constant from two 64 bit constants
u128 k128(u64 hi, u64 lo) { u128 hl; hl.hi = hi; hl.lo = lo; return hl; }

// add two 128 bit numbers, dropping any carry
u128 a128(u128 x, u128 y)
{ u128 sum;  sum.hi = x.hi + y.hi; sum.lo = x.lo + y.lo;
 if (sum.lo<x.lo) sum.hi++; return sum; }

// xor two 128 bit numbers
u128 x128(u128 x, u128 y)
{ u128 xor; xor.hi = x.hi ^ y.hi; xor.lo = x.lo ^ y.lo; return xor; }

// complement a 128 bit number
u128 c128(u128 x)
{ u128 comp; comp.hi = ~ x.hi; comp.lo = ~ x.lo; return comp; }

// and two 128 bit numbers
u128 b128(u128 x, u128 y)
{ u128 and; and.hi = x.hi & y.hi; and.lo = x.lo & y.lo; return and; }

// rotate left a 128 bit number
u128 r128(u128 x, int sh)
{ u128 rot; sh &= 127;
 if (sh==0)       { rot.hi = x.hi;
                    rot.lo = x.lo; }
 else if (sh<64)  { rot.hi = (x.hi << sh) | (x.lo >> (64-sh));
                    rot.lo = (x.lo << sh) | (x.hi >> (64-sh)); }
 else if (sh==64) { rot.hi = x.lo;
                    rot.lo = x.hi; }
 else             { rot.hi = (x.lo << (sh-64)) | (x.hi >> (128-sh));
                    rot.lo = (x.hi << (sh-64)) | (x.lo >> (128-sh)); };
 return rot; }

// rotate left a 64 bit number
u64 r64(u64 x, int sh)
{ sh &= 63; return sh ? ((x<<sh) | (x>>(64-sh))) : x ; }


#define msk32 0xFFFFFFFFul
#define b32 0x100000000ull

// multiply two 64 bit numbers, producing a 128 bit product
u128 m128(u64 x, u64 y)
{ u128 prod;
  u64 xhi = x>>32, xlo = x&msk32, yhi = y>>32, ylo = y&msk32;
  u64 tmp,tmp2;
  prod.hi = xhi*yhi; prod.lo = xlo*ylo; tmp = xlo*yhi; tmp2 = xhi*ylo;
  tmp += tmp2; if (tmp<tmp2) prod.hi += b32;
  prod.hi += tmp>>32;
  tmp <<= 32;
  prod.lo += tmp; if (prod.lo<tmp) prod.hi++;
  return prod; }

u128 sandwf(u128 x)
{ return a128(m128(x.hi,x.hi),m128(x.lo,x.lo)); }

u64 sandnf(u64 x)
     // { u32 xhi = x>>32, xlo = x&msk32; return ((u64)xhi)*xhi+((u64)xlo)*xlo; }
{ u32 xhi = x>>32, xlo = x&msk32; return ((u64)xhi)*xhi+((u64)xlo)*xlo; }

// was wrong: u64 sandwga = 0xb123456789abcdedull, sandwgb = 0xa21436587a9cbeddull;
u64 sandwga = 0xa611186bae67496bull, sandwgb = 0xbee8390d43955aedull;
u32 sandnga = 0xa611186bul, sandngb = 0xbee8390dul;

u128 sandwg(u128 x)
{ return a128(m128(x.hi,x.hi),
              a128(m128(x.lo,x.lo),r128(m128(x.hi+sandwga,x.lo+sandwgb),64))); }

u64 sandng(u64 x)
{ u32 xhi = x>>32, xlo = x&msk32;
   return ((u64)xhi)*xhi+((u64)xlo)*xlo+r64(((u64)((u32)(xhi+sandnga)))*((u32)(xlo+sandngb)),32); }



/* SB(x) = x ^ AES_sbox[x] */
static const unsigned char fsbox[256] =
{ 99, 125, 117, 120, 246, 110, 105, 194, 56, 8, 109, 32, 242, 218, 165, 121,
  218, 147, 219, 110, 238, 76, 81, 231, 181, 205, 184, 180, 128, 185, 108, 223,
  151, 220, 177, 5, 18, 26, 209, 235, 28, 140, 207, 218, 93, 245, 31, 58,
  52, 246, 17, 240, 44, 163, 51, 173, 63, 43, 186, 217, 215, 26, 140, 74,
  73, 194, 110, 89, 95, 43, 28, 231, 26, 114, 156, 248, 101, 174, 97, 203,
  3, 128, 82, 190, 116, 169, 231, 12, 50, 146, 228, 98, 22, 17, 6, 144,
  176, 142, 200, 152, 39, 40, 85, 226, 45, 144, 104, 20, 60, 81, 241, 199,
  33, 210, 50, 252, 230, 232, 78, 130, 196, 207, 160, 90, 108, 130, 141, 173,
  77, 141, 145, 111, 219, 18, 194, 144, 76, 46, 244, 182, 232, 208, 151, 252,
  240, 16, 221, 79, 182, 191, 6, 31, 222, 119, 34, 143, 66, 195, 149, 68,
  64, 147, 152, 169, 237, 163, 130, 251, 106, 122, 6, 201, 61, 56, 74, 214,
  87, 121, 133, 222, 57, 96, 248, 30, 212, 239, 78, 81, 217, 199, 16, 183,
  122, 185, 231, 237, 216, 99, 114, 1, 32, 20, 190, 212, 135, 112, 69, 69,
  160, 239, 103, 181, 156, 214, 32, 217, 185, 236, 141, 98, 90, 28, 195, 65,
  1, 25, 122, 242, 141, 60, 104, 115, 115, 247, 109, 2, 34, 184, 198, 48,
  124, 80, 123, 254, 75, 19, 180, 159, 185, 96, 215, 244, 76, 169, 69, 233};


// apply the AES sbox to the low byte of X
u128 sb128(u128 x)
{ u128 val; val.hi = x.hi; val.lo = x.lo ^ fsbox[x.lo & 255]; return val; }

u64 sb64(u64 x)
{ return x ^ fsbox[x&255]; }

// constants for message schedule & round constants
// these are a subset of the SHA2 round constants for SHA-512
// fractional part (in hex) of the cube roots of the first fifty primes
// the leading digits aren't completely random, but it's good enough
u128 sandwmsc[] = {
  0x428a2f98d728ae22ull, 0x7137449123ef65cdull, 0xb5c0fbcfec4d3b2full, 0xe9b5dba58189dbbcull,
  0x3956c25bf348b538ull, 0x59f111f1b605d019ull, 0x923f82a4af194f9bull, 0xab1c5ed5da6d8118ull,
  0xd807aa98a3030242ull, 0x12835b0145706fbeull, 0x243185be4ee4b28cull, 0x550c7dc3d5ffb4e2ull,
  0x72be5d74f27b896full, 0x80deb1fe3b1696b1ull, 0x9bdc06a725c71235ull, 0xc19bf174cf692694ull,
  0xe49b69c19ef14ad2ull, 0xefbe4786384f25e3ull, 0x0fc19dc68b8cd5b5ull, 0x240ca1cc77ac9c65ull,
  0x2de92c6f592b0275ull, 0x4a7484aa6ea6e483ull, 0x5cb0a9dcbd41fbd4ull, 0x76f988da831153b5ull,
  0x983e5152ee66dfabull, 0xa831c66d2db43210ull, 0xb00327c898fb213full, 0xbf597fc7beef0ee4ull,
  0xc6e00bf33da88fc2ull, 0xd5a79147930aa725ull, 0x06ca6351e003826full, 0x142929670a0e6e70ull,
  0x27b70a8546d22ffcull, 0x2e1b21385c26c926ull, 0x4d2c6dfc5ac42aedull, 0x53380d139d95b3dfull,
  0x650a73548baf63deull, 0x766a0abb3c77b2a8ull, 0x81c2c92e47edaee6ull, 0x92722c851482353bull,
  0xa2bfe8a14cf10364ull, 0xa81a664bbc423001ull, 0xc24b8b70d0f89791ull, 0xc76c51a30654be30ull,
  0xd192e819d6ef5218ull, 0xd69906245565a910ull, 0xf40e35855771202aull, 0x106aa07032bbd1b8ull,
  0x19a4c116b8d2d0c8ull, 0x1e376c085141ab53ull };

u64 sandnmsc[] = {
  0x428a2f9871374491ull, 0xb5c0fbcfe9b5dba5ull, 0x3956c25b59f111f1ull, 0x923f82a4ab1c5ed5ull,
  0xd807aa9812835b01ull, 0x243185be550c7dc3ull, 0x72be5d7480deb1feull, 0x9bdc06a7c19bf174ull,
  0xe49b69c1efbe4786ull, 0x0fc19dc6240ca1ccull, 0x2de92c6f4a7484aaull, 0x5cb0a9dc76f988daull,
  0x983e5152a831c66dull, 0xb00327c8bf597fc7ull, 0xc6e00bf3d5a79147ull, 0x06ca635114292967ull,
  0x27b70a852e1b2138ull, 0x4d2c6dfc53380d13ull, 0x650a7354766a0abbull, 0x81c2c92e92722c85ull,
  0xa2bfe8a1a81a664bull, 0xc24b8b70c76c51a3ull, 0xd192e819d6990624ull, 0xf40e3585106aa070ull,
  0x19a4c1161e376c08ull };

const u128 ym8 = { 0x8888888888888888ull, 0x8888888888888888ull};
const u128 ym4 = { 0x4444444444444444ull, 0x4444444444444444ull};
const u128 ym2 = { 0x2222222222222222ull, 0x2222222222222222ull};
const u128 ym1 = { 0x1111111111111111ull, 0x1111111111111111ull};


// where to start picking in Message Schedule
int sandwmspick[] = { 4, 14, 19, 24, 29 };

// print a message schedule
void mscpr(u128 *ms)
{ int i; printf("ms ");
   for (i=0;i<33;i++) { printf(" %016llx %016llx",ms[i].hi,ms[i].lo);
   if (i&1) printf("\n   "); } printf("\n"); }

void mscnpr(u64 *ms)
{ int i; printf("ms ");
   for (i=0;i<33;i++) { printf(" %016llx",ms[i]);
   if (i%5==4) printf("\n   "); } printf("\n"); }

// Compute the message schedule.
// Assumes the message is present in the first 8 words (128 bits each)
// Apply the mixing function to compute words after the first 8.
// Finish xoring the first 4 words (rotated) into the second 4 words,
// and then using BitMix to move the bits between words.
void sandwmsgsch(u128 *MS)
{ int i;  u128 ym[4];  // bitmix
 for (i=8;i<33;i++)
  MS[i] = r128(sb128(a128(    MS[i-8],
                      a128(   sandwmsc[i-8],
                       a128(  sandwg(MS[i-1]),
			a128( x128(b128(MS[i-1],MS[i-2]),   // Ch(i-1,i-2,i-3)
                                   b128(c128(MS[i-1]),MS[i-3])),
                              MS[i-4]))))),
               59 );
 for (i=0;i<4;i++) MS[i+4] = x128(r128(MS[i],37),MS[i+4]);
 // bitmix
 for (i=0;i<4;i++) ym[i] = MS[i+4];
 for (i=0;i<4;i++) MS[i+4] = x128(b128(ym[i],ym8),
				x128(b128(ym[(i+1)&3],ym4),
				     x128(b128(ym[i^2],ym2),
					  b128(ym[(i+3)&3],ym1))));
   // mscpr(MS);
 }

void sandnmsgsch(u64 *MS)
{ int i;  u64 ym[4];  // bitmix
 for (i=8;i<33;i++)
   MS[i] = r64(sb64(MS[i-8] + sandnmsc[i-8] + sandng(MS[i-1]) + 
		    (MS[i-3]^(MS[i-1]&(MS[i-2]^MS[i-3]))) + MS[i-4]), 27);
 for (i=0;i<4;i++) MS[i+4] ^= r64(MS[i],19);
 // bitmix
 for (i=0;i<4;i++) ym[i] = MS[i+4];
 for (i=0;i<4;i++) MS[i+4] = (ym[i]&0x8888888888888888ull) ^
		       (ym[(i+1)&3]&0x4444444444444444ull) ^
		           (ym[i^2]&0x2222222222222222ull) ^
		       (ym[(i+3)&3]&0x1111111111111111ull);
 // mscnpr(MS);
 }

// Run the compression function
// message (in *msg) is 8 128-bit words;
// prior block output is in prev[20*level+4*round+word]; result goes here too.
// inner state is w[0-3], 4 128-bit words
void sandwcmprs(u128 msg[], u128 prev[], int level, int xrnds)
{ int i,j,rnd; u128 MS[33], w[4];  u128 ym[4];  // bitmix
 for (i=0;i<8;i++) MS[i] = msg[i]; sandwmsgsch(MS);
 for (i=0;i<4;i++) w[i] = prev[20*level+i];
 for (rnd=0;rnd<=4;rnd++)
 { for (i=0;i<4;i++) w[i] = x128(w[i],MS[sandwmspick[rnd]+i]);
   for (j=0;j<=((rnd<4)?0:xrnds);j++)
   {for (i=0;i<4;i++)
    w[i] = r128(sb128(a128(   w[i],
                       a128(  sandwf(w[(i+3)&3]),
                        a128( x128(b128(w[(i+3)&3],w[i^2]),
				   b128(c128(w[(i+3)&3]),w[(i+1)&3])),
			      sandwmsc[24-i-(rnd<<2)])))),
		57);
    // bitmix
    for (i=0;i<4;i++) ym[i] = x128(b128(w[i],ym8),
				  x128(b128(w[(i+1)&3],ym4),
                                       x128(b128(w[i^2],ym2),
                                            b128(w[(i+3)&3],ym1))));
    for (i=0;i<4;i++) w[i] = ym[i]; }
   if (rnd<4) for (i=0;i<4;i++) w[i] = x128(w[i],prev[20*level+4*rnd+4+i]);
   if (rnd) for (i=0;i<4;i++) prev[20*level+4*rnd+i] = w[i]; };
 }

void prcmpn(u64 msg[], u64 prev[], int level, int xrnds, u64 w[])
{ int i;
 printf("compress entry  level %d  xrnds %d\n", level, xrnds);
 printf("message\n");
 for (i=0;i<8;i++) { printf(" %016llx", msg[i]); if ((i&3)==3) printf("\n"); }
 printf("prevn\n");
 for (i=0;i<100;i++)
 { printf(" %016llx", prev[i]); if ((i&3)==3) printf("\n"); if (i%20==19) printf("\n"); }
 printf("w  %016llx %016llx %016llx %016llx\n", w[0], w[1], w[2], w[3]); }

void sandncmprs(u64 msg[], u64 prev[], int level, int xrnds)
{ int i,j,rnd; u64 MS[33], w[4];  u64 ym[4];  // bitmix
 for (i=0;i<8;i++) MS[i] = msg[i]; sandnmsgsch(MS);
 for (i=0;i<4;i++) w[i] = prev[20*level+i];
 // if (level>=3) { prcmpn(msg,prev,level,xrnds,w); mscnpr(MS); }
 for (rnd=0;rnd<=4;rnd++)
 { for (i=0;i<4;i++) w[i] ^= MS[sandwmspick[rnd]+i];
   for (j=0;j<=((rnd<4)?0:xrnds);j++)
   {for (i=0;i<4;i++)
    w[i] = r64(sb64(w[i] + sandnf(w[(i+3)&3]) +
		    (w[(i+1)&3]^(w[(i+3)&3]&(w[i^2]^w[(i+1)&3]))) + sandnmsc[24-i-(rnd<<2)]), 25);
    // bitmix
    for (i=0;i<4;i++) ym[i] =  (w[i]&0x8888888888888888ull) ^
		         (w[(i+1)&3]&0x4444444444444444ull) ^
		             (w[i^2]&0x2222222222222222ull) ^
		         (w[(i+3)&3]&0x1111111111111111ull);
    for (i=0;i<4;i++) w[i] = ym[i]; }
   if (rnd<4) for (i=0;i<4;i++) w[i] ^= prev[20*level+4*rnd+4+i];
   if (rnd) for (i=0;i<4;i++) prev[20*level+4*rnd+i] = w[i]; };
 // if (level>=3) printf("w  %016llx %016llx %016llx %016llx\n", w[0], w[1], w[2], w[3]);
 }

typedef struct
{ unsigned char msgbytes[128];  // data bytes of the message
                                // only 64 are used for outsize <= 256.
  int mbcnt;                    // number of message bytes in the buffer
  u128 msg[8];                  // message repacked into 8 words of 128 bits
  u64 msgn[8];                  // message repacked into 8 words of 64 bits
  u128 msglen;                  // message length in bits
  u128 blkn1, blkn2;            // superblock numbers for level 1 and 2
  int lvl0flag;                 // level 0 has been processed;
  int lvl1cnt, lvl2cnt;         // number of blocks in current level 1 & 2 superblocks
  int lvl3flag;                 // level 3 has been used
  u128 prev[5*5*4];             // result of hash round function at each level
                                // 5 levels, 5 rounds, 4 128-bit words
  u64 prevn[5*5*4];
  int hashBitLen;
  int outsize;                  // output size in bits; must be 384 or 512 or 224 or 256
  int wide;                     // use 128 bit stuff -- outsize > 256
  u128 *lvlc;                   // pointer to level starting constants
  u64 *lvlcn;
 } sandwstate;

// print out a hash state
void hstpr(sandwstate *hst)
{ int i;
 printf("\nsandstate %x:\n", hst);
 printf("mbcnt %d\n", hst->mbcnt);
 for (i=0;i<128;i++) { if (!i) printf("msgbytes ");
 printf(" %02x",hst->msgbytes[i]); if (i%20==16 || i==127) printf("\n"); };
 printf("msg ");
 for(i=0;i<8;i++) { printf(" %016llx %016llx",hst->msg[i].hi,hst->msg[i].lo);
                    if (i&1 && i<7) printf("\n    "); if (i==7) printf("\n"); }
 printf("msgn");
 for(i=0;i<8;i++) { printf(" %016llx",hst->msgn[i]);
                    if (((i&3) == 3) && i<7) printf("\n    "); if (i==7) printf("\n"); }
 printf("msglen %lld %lld  blkn1 %lld %lld  blkn2 %lld %lld\n",
	hst->msglen.hi, hst->msglen.lo, hst->blkn1.hi,
	hst->blkn1.lo, hst->blkn2.hi, hst->blkn2.lo);
 printf("lvl0flag %d  lvl1cnt %d  lvl2cnt %d  lvl3flag %d\n",
	hst->lvl0flag, hst->lvl1cnt, hst->lvl2cnt, hst->lvl3flag);
 printf("prev:\n");
 for (i=0;i<100;i++) { printf(" %16llx %16llx",hst->prev[i].hi,hst->prev[i].lo);
                       if (i&1)printf("\n"); if (i%20==19)printf("\n"); };
 printf("prevn:\n");
 for (i=0;i<100;i++) { printf(" %16llx",hst->prevn[i]);
                       if ((i&3) == 3)printf("\n"); if (i%20==19)printf("\n"); };
 printf("outsize %d  wide %d  lvlc %x  lvlcn %x\n\n",
	hst->outsize, hst->wide, hst->lvlc, hst->lvlcn); }

int xtrnds=TUNABLE_SECURITY_PARAMETER;     // number of extra times to do round 4


// constants for initializing (super)blocks at various levels
// based on the SHA-384/512 initial-value constants, which are
// derived from the fractional part (in hex) of the square roots
// of the primes 2-19 (for SHA-512) and 23-53 (for SHA-384).

u128 sandwlvlc384[20] =
{ 0xcbbb9d5dc1059ed8ull, 0x629a292a367cd507ull,
  0x9159015a3070dd17ull, 0x152fecd8f70e5939ull,
  0x67332667ffc00b31ull, 0x8eb44a8768581511ull,
  0xdb0c2e0d64f98fa7ull, 0x47b5481dbefa4fa4ull,

                         0x629a292a367cd507ull,
  0x9159015a3070dd17ull, 0x152fecd8f70e5939ull,
  0x67332667ffc00b31ull, 0x8eb44a8768581511ull,
  0xdb0c2e0d64f98fa7ull, 0x47b5481dbefa4fa4ull,
  0xcbbb9d5dc1059ed8ull,

  0x9159015a3070dd17ull, 0x152fecd8f70e5939ull,
  0x67332667ffc00b31ull, 0x8eb44a8768581511ull,
  0xdb0c2e0d64f98fa7ull, 0x47b5481dbefa4fa4ull,
  0xcbbb9d5dc1059ed8ull, 0x629a292a367cd507ull,

                         0x152fecd8f70e5939ull,
  0x67332667ffc00b31ull, 0x8eb44a8768581511ull,
  0xdb0c2e0d64f98fa7ull, 0x47b5481dbefa4fa4ull,
  0xcbbb9d5dc1059ed8ull, 0x629a292a367cd507ull,
  0x9159015a3070dd17ull,

  0x67332667ffc00b31ull, 0x8eb44a8768581511ull,
  0xdb0c2e0d64f98fa7ull, 0x47b5481dbefa4fa4ull,
  0xcbbb9d5dc1059ed8ull, 0x629a292a367cd507ull,
  0x9159015a3070dd17ull, 0x152fecd8f70e5939ull };

u128 sandwlvlc512[20] =
{ 0x6a09e667f3bcc908ull, 0xbb67ae8584caa73bull,
  0x3c6ef372fe94f82bull, 0xa54ff53a5f1d36f1ull,
  0x510e527fade682d1ull, 0x9b05688c2b3e6c1full,
  0x1f83d9abfb41bd6bull, 0x5be0cd19137e2179ull,

                         0xbb67ae8584caa73bull,
  0x3c6ef372fe94f82bull, 0xa54ff53a5f1d36f1ull,
  0x510e527fade682d1ull, 0x9b05688c2b3e6c1full,
  0x1f83d9abfb41bd6bull, 0x5be0cd19137e2179ull,
  0x6a09e667f3bcc908ull,

  0x3c6ef372fe94f82bull, 0xa54ff53a5f1d36f1ull,
  0x510e527fade682d1ull, 0x9b05688c2b3e6c1full,
  0x1f83d9abfb41bd6bull, 0x5be0cd19137e2179ull,
  0x6a09e667f3bcc908ull, 0xbb67ae8584caa73bull,

                         0xa54ff53a5f1d36f1ull,
  0x510e527fade682d1ull, 0x9b05688c2b3e6c1full,
  0x1f83d9abfb41bd6bull, 0x5be0cd19137e2179ull,
  0x6a09e667f3bcc908ull, 0xbb67ae8584caa73bull,
  0x3c6ef372fe94f82bull,

  0x510e527fade682d1ull, 0x9b05688c2b3e6c1full,
  0x1f83d9abfb41bd6bull, 0x5be0cd19137e2179ull,
  0x6a09e667f3bcc908ull, 0xbb67ae8584caa73bull,
  0x3c6ef372fe94f82bull, 0xa54ff53a5f1d36f1ull };

u64 sandnlvlc224[20] =
{ 0xc1059ed8367cd507ull, 0x3070dd17f70e5939ull, 0xffc00b3168581511ull, 0x64f98fa7befa4fa4ull,
  0x367cd5073070dd17ull, 0xf70e5939ffc00b31ull, 0x6858151164f98fa7ull, 0xbefa4fa4c1059ed8ull,
  0x3070dd17f70e5939ull, 0xffc00b3168581511ull, 0x64f98fa7befa4fa4ull, 0xc1059ed8367cd507ull,
  0xf70e5939ffc00b31ull, 0x6858151164f98fa7ull, 0xbefa4fa4c1059ed8ull, 0x367cd5073070dd17ull,
  0xffc00b3168581511ull, 0x64f98fa7befa4fa4ull, 0xc1059ed8367cd507ull, 0x3070dd17f70e5939ull };

u64 sandnlvlc256[20] =
{ 0x6a09e667bb67ae85ull, 0x3c6ef372a54ff53aull, 0x510e527f9b05688cull, 0x1f83d9ab5be0cd19ull,
  0xbb67ae853c6ef372ull, 0xa54ff53a510e527full, 0x9b05688c1f83d9abull, 0x5be0cd196a09e667ull,
  0x3c6ef372a54ff53aull, 0x510e527f9b05688cull, 0x1f83d9ab5be0cd19ull, 0x6a09e667bb67ae85ull,
  0xa54ff53a510e527full, 0x9b05688c1f83d9abull, 0x5be0cd196a09e667ull, 0xbb67ae853c6ef372ull,
  0x510e527f9b05688cull, 0x1f83d9ab5be0cd19ull, 0x6a09e667bb67ae85ull, 0x3c6ef372a54ff53aull };


u128 sandwblkc = { 0x6135f68d4c0cbb6full, 0xb43b47a245778989ull };
u128 sandwblkd = { 0x79cc45195cf5b7a4ull, 0xaec4e7496801dbb9ull };

u64 sandnblkc = 0x6135f68d4c0cbb6full;
u64 sandnblkd = 0x79cc45195cf5b7a4ull;

// general philosophy is lazy evaluation
// we postpone all use of the compression function until absolutely needed

// process a block of message
// may trigger processing of higher levels if necessary
void sandwdoit( sandwstate *hstate )
{ int i; u128 ww; u64 w;
 if (hstate->wide)
 { // check if there's higher level work to do
  if (hstate->lvl1cnt==10)
  { if (hstate->lvl2cnt==100)
    { for (i=0;i<8;i++) hstate->msg[i] = x128(hstate->prev[44+i],hstate->prev[52+i]);
      if (!hstate->lvl3flag)  // setup level 3 starting round constants
      { for (i=0;i<20;i++) hstate->prev[60+i] = x128((hstate->lvlc)[i],hstate->prev[(i<4)?i+16:i]);
        for (i=0;i<20;i+=4) hstate->prev[63+i] = x128(hstate->prev[63+i],sandwblkd); }
      sandwcmprs(hstate->msg,hstate->prev,3,xtrnds);
      hstate->lvl2cnt=0; hstate->blkn2 = a128(hstate->blkn2,k128(0,1));
      hstate->lvl3flag=1; }
    if (!hstate->lvl2cnt)  // setup level2 superblock starting round constants
    { for (i=0;i<20;i++) hstate->prev[40+i] = x128((hstate->lvlc)[i],hstate->prev[(i<4)?i+16:i]);
      for (i=0;i<20;i+=4) hstate->prev[43+i] = x128(hstate->prev[43+i],sandwblkc);
      for (i=0;i<20;i+=2) hstate->prev[41+i] = x128(hstate->prev[41+i], hstate->blkn2); }
    for (i=0;i<8;i++) hstate->msg[i] = x128(hstate->prev[24+i],hstate->prev[32+i]);
    sandwcmprs(hstate->msg,hstate->prev,2,xtrnds);
    hstate->lvl1cnt=0; hstate->blkn1 = a128(hstate->blkn1,k128(0,1));
    hstate->lvl2cnt++; }
  for (i=0;i<8;i++) hstate->msg[i] = k128(0,0);
  for (i=0;i<128;i++)   // pack 128 message bytes into eight 128-bit words
  { ww = k128(0,hstate->msgbytes[i]);
    hstate->msg[i>>4] = x128(hstate->msg[i>>4], r128(ww,120-((i&15)<<3))); }
  hstate->mbcnt = 0;   // reset byte count to 0.
  // if lvl0flag = 0, we're doing level 0
  if (hstate->lvl0flag==0)
  { sandwcmprs(hstate->msg,hstate->prev,0,xtrnds); hstate->lvl0flag = 1; }
  else
  { if (!hstate->lvl1cnt)  // setup level1 superblock starting round constants
    { for (i=0;i<20;i++) hstate->prev[20+i] = x128((hstate->lvlc)[i],hstate->prev[(i<4)?i+16:i]);
      for (i=0;i<20;i+=2) hstate->prev[21+i] = x128(hstate->prev[21+i], hstate->blkn1); }
    sandwcmprs(hstate->msg,hstate->prev,1,xtrnds); hstate->lvl1cnt++; };
 }
 else // narrow
 { // check if there's higher level work to do
  if (hstate->lvl1cnt==10)
  { if (hstate->lvl2cnt==100)
    { for (i=0;i<8;i++) hstate->msgn[i] = hstate->prevn[44+i]^hstate->prevn[52+i];
      if (!hstate->lvl3flag)  // setup level 3 starting round constants
      { for (i=0;i<20;i++) hstate->prevn[60+i] = (hstate->lvlcn)[i] ^ hstate->prevn[(i<4)?i+16:i];
        for (i=0;i<20;i+=4) hstate->prevn[63+i] ^= sandnblkd; }
      sandncmprs(hstate->msgn,hstate->prevn,3,xtrnds);
      hstate->lvl2cnt=0; hstate->blkn2 = a128(hstate->blkn2,k128(0,1));
      hstate->lvl3flag=1; }
    if (!hstate->lvl2cnt)  // setup level2 superblock starting round constants
    { for (i=0;i<20;i++) hstate->prevn[40+i] = (hstate->lvlcn)[i] ^ hstate->prevn[(i<4)?i+16:i];
      for (i=0;i<20;i+=4) hstate->prevn[43+i] ^= sandnblkc;
      for (i=0;i<20;i+=2) { hstate->prevn[40+i] ^= hstate->blkn2.hi;
                            hstate->prevn[41+i] ^= hstate->blkn2.lo; }; }
    for (i=0;i<8;i++) hstate->msgn[i] = hstate->prevn[24+i]^hstate->prevn[32+i];
    sandncmprs(hstate->msgn,hstate->prevn,2,xtrnds);
    hstate->lvl1cnt=0; hstate->blkn1 = a128(hstate->blkn1,k128(0,1));
    hstate->lvl2cnt++; }
  for (i=0;i<8;i++) hstate->msgn[i] = 0;
  for (i=0;i<64;i++)   // pack 64 message bytes into eight 64-bit words
  { w = hstate->msgbytes[i]; hstate->msgn[i>>3] ^= r64(w,56-((i&7)<<3)); }
  hstate->mbcnt = 0;   // reset byte count to 0.
  // if lvl0flag = 0, we're doing level 0
  if (hstate->lvl0flag==0)
  { sandncmprs(hstate->msgn,hstate->prevn,0,xtrnds); hstate->lvl0flag = 1; }
  else
  { if (!hstate->lvl1cnt)  // setup level1 superblock starting round constants
    { for (i=0;i<20;i++) hstate->prevn[20+i] = (hstate->lvlcn)[i] ^ hstate->prevn[(i<4)?i+16:i];
      for (i=0;i<20;i+=2) { hstate->prevn[20+i] ^= hstate->blkn1.hi;
                            hstate->prevn[21+i] ^= hstate->blkn1.lo; }; }
    sandncmprs(hstate->msgn,hstate->prevn,1,xtrnds); hstate->lvl1cnt++; };
 }; }

// hashsize must be either 384 or 512 or 224 or 256
void sandwinit( sandwstate *hstate, int hashsize )
{ int i; u128 *rndc;
  if (!(hashsize==224 || hashsize==256 || hashsize==384 || hashsize==512))
    { printf("\nbad hash output size: %d\n", hashsize); return; }
  //  for (i=0;i<128;i++) hstate->msgbytes[i] = 0;  // not actually needed
  hstate->mbcnt = 0;
  //  for (i=0;i<8;i++) hstate->msg[i] = k128(0,0);  // not actually needed
  hstate->msglen = k128(0,0);
  hstate->blkn1 = k128(0,1); hstate->blkn2 = k128(0,1);
  hstate->lvl0flag = 0;
  hstate->lvl1cnt = 0; hstate->lvl2cnt = 0;
  hstate->lvl3flag = 0;
  hstate->hashBitLen = hashsize;
  hstate->outsize = hashsize;
  hstate->wide = (hashsize>256);
  if (hashsize==384) hstate->lvlc = sandwlvlc384; else hstate->lvlc = sandwlvlc512;
  if (hashsize==224) hstate->lvlcn = sandnlvlc224; else hstate->lvlcn = sandnlvlc256;
  // setup level 0 constants
  if (hstate->wide) for (i=0;i<20;i++) hstate->prev[i] = (hstate->lvlc)[i];
  else for (i=0;i<20;i++) hstate->prevn[i] = (hstate->lvlcn)[i]; }


// bits of data must be a multiple of 8, except for last partial byte
// update is responsible for zeroing unused low order bits in last byte
// mbcnt points to first unused byte, including after any partial byte
void sandwupdate( sandwstate *hstate, int bitsofdata, unsigned char *data )
{ int j, hbytes = hstate->wide ? 128 : 64;
  for (j=0;j<bitsofdata;)
  { if (hstate->mbcnt>=hbytes) sandwdoit(hstate); // we've got a full message block to process
    hstate->msgbytes[hstate->mbcnt] = *data; data++; j+=8;
    if (j>bitsofdata) // handle partial byte
      hstate->msgbytes[hstate->mbcnt] &= 0xFF<<(j-bitsofdata);
    hstate->mbcnt++; }
  hstate->msglen = a128(hstate->msglen,k128(0,bitsofdata)); }

// do padding, process any partial block, propagate up levels
void sandwfinish( sandwstate *hstate )
{ int i, padbitpos, hbytes = hstate->wide ? 128 : 64, wd = hstate->wide;
  // process message buffer if full
  if (hstate->mbcnt>=hbytes && !(hstate->msglen.lo & 7)) sandwdoit(hstate);
  for (i=hstate->mbcnt;i<hbytes;i++) hstate->msgbytes[i]=0; // zero out unused message bytes
  padbitpos = hstate->msglen.lo & 7;
  if (!padbitpos) hstate->mbcnt++;
  hstate->msgbytes[hstate->mbcnt-1] |= 0x80 >> padbitpos;
  sandwdoit(hstate);

  // at this point, the message buffer is emptied out.
  // we've just completed either a level 0 block, or a level 1 block.
  // if a level 0 block, we can push on with impunity.
  // if a level 1 block, we need to ask about the situation with levels 2 and 3.
  // if we've never started level 2, we can just use the level 1 results, for
  // input to level 4, as we do below.  but if we've started level 2, and
  // there's a level 1 residue, we need to move that level 1 block up to level 2.
  // we might need to vacate the present level 2 occupant, moving him up to level 3.
  // and we might need to terminate level 2 and go directly to level 4;
  // or to push out any level 2 partial superblock into level 3.

  // if we've ever used level 2, we might need to cleanup partial blocks
  //  from levels 1-3.
  if (!(hstate->lvl2cnt==0 && hstate->blkn2.hi==0 && hstate->blkn2.lo==1))
  { // unless level 1 is empty, send partial superblock to level 2
    if (hstate->lvl1cnt)
    { // make sure there's room at level 2
      if (hstate->lvl2cnt==100)
      { if (wd)
	{ for (i=0;i<8;i++) hstate->msg[i] = x128(hstate->prev[44+i],hstate->prev[52+i]);
          if (!hstate->lvl3flag)  // setup level 3 starting round constants
          { for (i=0;i<20;i++) hstate->prev[60+i] = x128((hstate->lvlc)[i],hstate->prev[(i<4)?i+16:i]);
            for (i=0;i<20;i+=4) hstate->prev[63+i] = x128(hstate->prev[63+i],sandwblkd); }
	  sandwcmprs(hstate->msg,hstate->prev,3,xtrnds); }
        else
	{ for (i=0;i<8;i++) hstate->msgn[i] = hstate->prevn[44+i] ^ hstate->prevn[52+i];
          if (!hstate->lvl3flag)  // setup level 3 starting round constants
          { for (i=0;i<20;i++) hstate->prevn[60+i] = (hstate->lvlcn)[i] ^ hstate->prevn[(i<4)?i+16:i];
            for (i=0;i<20;i+=4) hstate->prevn[63+i] ^= sandnblkd; }
	  sandncmprs(hstate->msgn,hstate->prevn,3,xtrnds); }
	hstate->lvl2cnt=0; hstate->blkn2 = a128(hstate->blkn2,k128(0,1));
	hstate->lvl3flag=1; }
      if (wd)
      { if (!hstate->lvl2cnt)  // setup level2 superblock starting round constants
        { for (i=0;i<20;i++) hstate->prev[40+i] = x128((hstate->lvlc)[i],hstate->prev[(i<4)?i+16:i]);
          for (i=0;i<20;i+=4) hstate->prev[43+i] = x128(hstate->prev[43+i],sandwblkc);
	  for (i=0;i<20;i+=2) hstate->prev[41+i] = x128(hstate->prev[41+i], hstate->blkn2); }
        for (i=0;i<8;i++) hstate->msg[i] = x128(hstate->prev[24+i],hstate->prev[32+i]);
        sandwcmprs(hstate->msg,hstate->prev,2,xtrnds); }
      else
      { if (!hstate->lvl2cnt)  // setup level2 superblock starting round constants
        { for (i=0;i<20;i++) hstate->prevn[40+i] = (hstate->lvlcn)[i] ^ hstate->prevn[(i<4)?i+16:i];
          for (i=0;i<20;i+=4) hstate->prevn[43+i] ^= sandnblkc;
	  for (i=0;i<20;i+=2) { hstate->prevn[40+i] ^= hstate->blkn2.hi;
	                        hstate->prevn[41+i] ^= hstate->blkn2.lo; }; }
        for (i=0;i<8;i++) hstate->msgn[i] = hstate->prevn[24+i]^hstate->prevn[32+i];
	sandncmprs(hstate->msgn,hstate->prevn,2,xtrnds); }
      hstate->lvl1cnt=0; hstate->blkn1 = a128(hstate->blkn1,k128(0,1));
      hstate->lvl2cnt++; }
    // we've forwarded any partial superblock from level 1 to level 2
    // if we've ever used level 3, we need to forward any partial level 2 superblock
    if (hstate->lvl3flag && hstate->lvl2cnt)
    { if (wd) { for (i=0;i<8;i++) hstate->msg[i] = x128(hstate->prev[44+i],hstate->prev[52+i]);
                sandwcmprs(hstate->msg,hstate->prev,3,xtrnds); }
      else { for (i=0;i<8;i++) hstate->msgn[i] = hstate->prevn[44+i] ^ hstate->prevn[52+i];
             sandncmprs(hstate->msgn,hstate->prevn,3,xtrnds); }
      hstate->lvl2cnt=0; hstate->blkn2 = a128(hstate->blkn2,k128(0,1)); }; };

  // any partial superblocks have been forwarded up the tree, unless they
  // are the first superblock at their level.

  // ready for level 4.  input might come from level 0, 1, 2, or 3.

  if (wd)
  { // setup level4 round constants
    for (i=0;i<20;i++) hstate->prev[80+i] = (hstate->lvlc)[i];
    for (i=0;i<20;i+=4) hstate->prev[83+i] = x128(hstate->prev[83+i],sandwblkd);
    for (i=0;i<20;i+=2) hstate->prev[81+i] = x128(hstate->prev[81+i], hstate->msglen);
    for (i=0;i<20;i++) if (!(i&2)) hstate->prev[80+i] = c128(hstate->prev[80+i]);
    // see if we've only used level 0
    if (hstate->lvl1cnt==0 && hstate->blkn1.hi==0 && hstate->blkn1.lo==1)
     for (i=0;i<8;i++) hstate->msg[i] = x128(hstate->prev[4+i],hstate->prev[12+i]);
    // or if we've only used levels 0 & 1
    else if (hstate->lvl2cnt==0 && hstate->blkn2.hi==0 && hstate->blkn2.lo==1)
     for (i=0;i<8;i++) hstate->msg[i] = x128(hstate->prev[24+i],hstate->prev[32+i]);
    // or if we've only used level 0, 1, & 2
    else if (hstate->lvl3flag==0)
     for (i=0;i<8;i++) hstate->msg[i] = x128(hstate->prev[44+i],hstate->prev[52+i]);
    else  // we've used level 3
     for (i=0;i<8;i++) hstate->msg[i] = x128(hstate->prev[64+i],hstate->prev[72+i]);
    sandwcmprs(hstate->msg,hstate->prev,4,xtrnds);
    // xor round values from rounds 1-4 to create final hash value
    for (i=0;i<4;i++)
      hstate->prev[96+i] = x128(hstate->prev[84+i],
			    x128(hstate->prev[88+i],
			     x128(hstate->prev[92+i],hstate->prev[96+i]))); }
    // final hash in prev[96-99]
  else
  { // setup level4 round constants
    for (i=0;i<20;i++) hstate->prevn[80+i] = (hstate->lvlcn)[i];
    for (i=0;i<20;i+=4) hstate->prevn[83+i] = hstate->prevn[83+i] ^ sandnblkd;
    for (i=0;i<20;i+=2) { hstate->prevn[80+i] ^= hstate->msglen.hi;
                          hstate->prevn[81+i] ^= hstate->msglen.lo; }
    for (i=0;i<20;i++) if (!(i&2)) hstate->prevn[80+i] = ~hstate->prevn[80+i];
    // see if we've only used level 0
    if (hstate->lvl1cnt==0 && hstate->blkn1.hi==0 && hstate->blkn1.lo==1)
     for (i=0;i<8;i++) hstate->msgn[i] = hstate->prevn[4+i] ^ hstate->prevn[12+i];
    // or if we've only used levels 0 & 1
    else if (hstate->lvl2cnt==0 && hstate->blkn2.hi==0 && hstate->blkn2.lo==1)
     for (i=0;i<8;i++) hstate->msgn[i] = hstate->prevn[24+i] ^ hstate->prevn[32+i];
    // or if we've only used level 0, 1, & 2
    else if (hstate->lvl3flag==0)
     for (i=0;i<8;i++) hstate->msgn[i] = hstate->prevn[44+i] ^ hstate->prevn[52+i];
    else  // we've used level 3
     for (i=0;i<8;i++) hstate->msgn[i] = hstate->prevn[64+i] ^ hstate->prevn[72+i];
    sandncmprs(hstate->msgn,hstate->prevn,4,xtrnds);
    // xor round values from rounds 1-4 to create final hash value
    for (i=0;i<4;i++)
      hstate->prevn[96+i] = hstate->prevn[84+i] ^ hstate->prevn[88+i] ^
	                    hstate->prevn[92+i] ^ hstate->prevn[96+i];   }
    // final hash in prevn[96-99]
 }

// print hash value
void sandwprint( sandwstate *hstate, char *line2prefix )
{ if (hstate->outsize==224)    // omit prevn[99]
    printf(" %016llx %016llx %016llx %08lx\n",
      hstate->prevn[96], hstate->prevn[97], hstate->prevn[98], (u32)(hstate->prevn[99]>>32));
  else if (hstate->outsize==256)
    printf(" %016llx %016llx %016llx %016llx\n",
      hstate->prevn[96], hstate->prevn[97], hstate->prevn[98], hstate->prevn[99]);
  else if (hstate->outsize==384)    // omit prev[99]
    printf(" %016llx %016llx %016llx\n%s %016llx %016llx %016llx\n",
	   hstate->prev[96].hi, hstate->prev[96].lo, hstate->prev[97].hi, line2prefix,
	   hstate->prev[97].lo, hstate->prev[98].hi, hstate->prev[98].lo);
  else
    printf(" %016llx %016llx %016llx %016llx\n%s %016llx %016llx %016llx %016llx\n",
      hstate->prev[96].hi, hstate->prev[96].lo, hstate->prev[97].hi, hstate->prev[97].lo, line2prefix,
      hstate->prev[98].hi, hstate->prev[98].lo, hstate->prev[99].hi, hstate->prev[99].lo);
 }

void sandtest4( sandwstate *hstate, int msglen, unsigned char* msg, int count)
{  int i, j; int sizearr[4] = { 224,256,384,512 };
   for (i=0;i<4;i++)
   { sandwinit(hstate, sizearr[i]);
     for (j=0;j<count;j++) sandwupdate(hstate,msglen,msg);
     sandwfinish(hstate);
     printf("%d:", sizearr[i]); sandwprint(hstate,"    "); }
}

// print a bunch of test values
void sandtest( sandwstate *hstate )
{ int i; int sizearr[4] = { 224,256,384,512 };
  unsigned char* msg; unsigned char msg2[8];
 printf("SANDstorm samples\n\n");
 if (xtrnds) printf("TunableSecurityParameter = %d\n\n",xtrnds);
 printf("message = %s\n", "abc"); sandtest4(hstate,24,"abc",1);
 msg = "abcdefghijklmnopqrstuvwxyz";
 printf("\nmessage = %s\n", msg); sandtest4(hstate,208,msg,1);
 printf("\nmessage = 100 alphabets\n"); sandtest4(hstate,208,msg,100);
 msg = "a";
 printf("\nmessage = %s, one million times\n", msg); sandtest4(hstate,8,msg,1000000);
 printf("\nmessage is null\n"); sandtest4(hstate,8,msg,0);
 msg2[0] = (unsigned char) 0x200; msg2[1] = 0;
 printf("\nmessage is a single 1 bit\n"); sandtest4(hstate,1,msg2,1);
 xtrnds = 2;
 printf("\nTunableSecurityParameter = %d\n\n",xtrnds);
 printf("message = %s\n", "abc"); sandtest4(hstate,24,"abc",1);
}


#if MAIN
int main()
{ sandwstate hst; int i;
  //  sandwinit(&hst,256); // hstpr(&hst);
  // for (i=0;i<100000;i++) { sandwupdate(&hst,208,"abcdefghijklmnopqrstuvwxyz"); } // hstpr(&hst);
  //  sandwfinish(&hst); // hstpr(&hst);
  // sandwprint(&hst,0);
  sandtest(&hst);
  return 0; }
#endif

HashReturn Init(hashState *state, int hashBitLen)
{ sandwinit(state, hashBitLen); return SUCCESS; }

HashReturn Update(hashState *state, const BitSequence *data, DataLength databitlen)
{ sandwupdate(state, databitlen, data); return SUCCESS; }

HashReturn Final(hashState *state, BitSequence *hashval)
{ u128 tmp; int i;
  sandwfinish(state);
  if (state->wide)
  { for (i=0;i<state->outsize/8;i++)
    { tmp = r128(state->prev[96+i/16],8*i+8); hashval[i] = (unsigned char) (tmp.lo & 0xFF); }; }
  else
  { for (i=0;i<state->outsize/8;i++)
       hashval[i] = (unsigned char) ((state->prevn[96+i/8]>>(56-(i&7)*8)) & 0xFF); }
  return SUCCESS; }

HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen, BitSequence *hashval)
{	hashState state;
	HashReturn ercode;
	// Initialize Hash Algorithm
	ercode = Init(&state,hashbitlen);
	// Hash the data
	if (ercode == SUCCESS)	ercode = Update (&state, data, databitlen);
	// Finalize the hashing, passing the var hashval to hold the data
	if (ercode == SUCCESS)  ercode = Final(&state,hashval);
	// return status code
	return ercode;  }


