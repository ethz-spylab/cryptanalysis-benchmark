
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "SHA3api_ref.h"

#define	MAX_MARKER_LEN		50
#define	ALGORITHM_INFO_LEN	128
#define	SUBMITTER_INFO_LEN	128

typedef enum { KAT_SUCCESS = 0, KAT_FILE_OPEN_ERROR = 1, KAT_HEADER_ERROR = 2, KAT_DATA_ERROR = 3, KAT_HASH_ERROR = 4 } STATUS_CODES;

char Text [] = "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmno";

STATUS_CODES	genIntermediateValues(int hashbitlen, FILE *fp_in);
int		FindMarker(FILE *infile, const char *marker);
int		ReadHex(FILE *infile, BitSequence *A, int Length, char *str);
void	fprintBstr(char *S, BitSequence *A, int L);

STATUS_CODES
main()
{
	int		i, ret_val,  bitlens[4] = { 224, 256, 384, 512 };
	FILE	*fp_in;
	char	fn[32], aline[ALGORITHM_INFO_LEN], sline[SUBMITTER_INFO_LEN];
	
	for ( i=0; i<4; i++ ) {
		if ( (fp_in = fopen("IntermediateVals.txt", "r")) == NULL ) {
			printf("Couldn't open <IntermediateVals.txt> for read\n");
			return KAT_FILE_OPEN_ERROR;
		}
		if ( FindMarker(fp_in, "# Algorithm Name:") )
			fscanf(fp_in, "%[^\n]\n", aline);
		else {
			printf("genIntermediateValues: Couldn't read Algorithm Name\n");
			return KAT_HEADER_ERROR;
		}
		if ( FindMarker(fp_in, "# Principal Submitter:") )
			fscanf(fp_in, "%[^\n]\n", sline);
		else {
			printf("genIntermediateValues: Couldn't read Principal Submitter\n");
			return KAT_HEADER_ERROR;
		}
		printf("%s\n", fn);
		printf("Algorithm Name:%s\n", aline);
		printf("Principal Submitter:%s\n", sline);
		if ( (ret_val = genIntermediateValues(bitlens[i], fp_in)) != KAT_SUCCESS )
			return ret_val;
		fclose(fp_in);
	}
	
	return KAT_SUCCESS;
}

STATUS_CODES
genIntermediateValues(int hashbitlen, FILE *fp_in)
{
	int			msglen, msgbytelen, done, repeat, i;
	HashReturn	retval;
	hashState	state;
	BitSequence	Msg[4288], MD[64];

	done = 0;
	do {
		if ( FindMarker(fp_in, "Len = ") )
			fscanf(fp_in, "%d", &msglen);
		else {
			done = 1;
			break;
		}
		msgbytelen = (msglen+7)/8;

		if ( !ReadHex(fp_in, Msg, msgbytelen, "Msg = ") ) {
			printf("ERROR: unable to read 'Msg' from <IntermediateVals.txt>\n");
			return KAT_DATA_ERROR;
		}
		printf("\nNIST KAT Msg, Len = %d bits\n", msglen);
		printf("\n");
		Hash(hashbitlen, Msg, msglen, MD);
		fprintBstr("MD = ", MD, hashbitlen/8);
		printf("\n=============================================================================\n");
	} while ( !done );

	if (hashbitlen <= 256)
		repeat = 1001;
	else
		repeat = 2001;
	printf("%d-byte message:\n", repeat*strlen(Text));
	printf(" \"%s\"\n", Text);
	printf(" repeated %d times\n\n", repeat);
	if ( (retval = Init(&state, hashbitlen)) != KAT_SUCCESS ) {
		printf("Init returned <%d> in genExtremelyLongMsg\n", retval);
		return KAT_HASH_ERROR;
	}
	for ( i=0; i<repeat; i++ )
		if ( (retval = Update(&state, (BitSequence *)Text, (DataLength)(8*strlen(Text)))) != KAT_SUCCESS ) {
			printf("Update returned <%d> in genExtremelyLongMsg\n", retval);
			return KAT_HASH_ERROR;
		}
	if ( (retval = Final(&state, MD)) != KAT_SUCCESS ) {
		printf("Final returned <%d> in genExtremelyLongMsg\n", retval);
		return KAT_HASH_ERROR;
	}
	fprintBstr("MD = ", MD, hashbitlen/8);

	printf("Finished intermediate values for SANDstorm-%d\n", hashbitlen);
	
	return KAT_SUCCESS;
}

//
// ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
//
int
FindMarker(FILE *infile, const char *marker)
{
	char	line[MAX_MARKER_LEN];
	int		i, len;

	len = (int)strlen(marker);
	if ( len > MAX_MARKER_LEN-1 )
		len = MAX_MARKER_LEN-1;

	for ( i=0; i<len; i++ )
		if ( (line[i] = fgetc(infile)) == EOF )
			return 0;
	line[len] = '\0';

	while ( 1 ) {
		if ( !strncmp(line, marker, len) )
			return 1;

		for ( i=0; i<len-1; i++ )
			line[i] = line[i+1];
		if ( (line[len-1] = fgetc(infile)) == EOF )
			return 0;
		line[len] = '\0';
	}

	// shouldn't get here
	return 0;
}

//
// ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
//
int
ReadHex(FILE *infile, BitSequence *A, int Length, char *str)
{
	int			i, ch, started;
	BitSequence	ich;

	if ( Length == 0 ) {
		A[0] = 0x00;
		return 1;
	}
	memset(A, 0x00, Length);
	started = 0;
	if ( FindMarker(infile, str) )
		while ( (ch = fgetc(infile)) != EOF ) {
			if ( !isxdigit(ch) ) {
				if ( !started ) {
					if ( ch == '\n' )
						break;
					else
						continue;
				}
				else
					break;
			}
			started = 1;
			if ( (ch >= '0') && (ch <= '9') )
				ich = ch - '0';
			else if ( (ch >= 'A') && (ch <= 'F') )
				ich = ch - 'A' + 10;
			else if ( (ch >= 'a') && (ch <= 'f') )
				ich = ch - 'a' + 10;
			
			for ( i=0; i<Length-1; i++ )
				A[i] = (A[i] << 4) | (A[i+1] >> 4);
			A[Length-1] = (A[Length-1] << 4) | ich;
		}
	else
		return 0;

	return 1;
}

void
fprintBstr(char *S, BitSequence *A, int L)
{
	int		i;

	printf("%s", S);

	for ( i=0; i<L; i++ )
		printf("%02X", A[i]);

	if ( L == 0 )
		printf("00");

	printf("\n");
}
