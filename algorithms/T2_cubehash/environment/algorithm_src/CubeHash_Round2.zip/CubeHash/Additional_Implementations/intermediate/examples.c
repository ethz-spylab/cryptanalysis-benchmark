#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#include "cubehash.h"

BitSequence m[16] = {
  0x52,0xA6,0x08,0xAB,0x21,0xCC,0xDD,0x8A,0x44,0x57,0xA5,0x7E,0xDE,0x78,0x21,0x76
} ;

void doit(int hashbitlen)
{
  BitSequence MD[64];
  int msglen;

  for (msglen = 0;msglen <= 128;++msglen) {
    if ((msglen > 32) && (msglen % 8)) continue;
    printf("Intermediate values for %d-bit hash of %d-bit message:\n",hashbitlen,msglen);
    Hash(hashbitlen, m, msglen, MD);
    printf("\n");
  }
}

int main()
{
  doit(224);
  doit(256);
  doit(384);
  doit(512);
  return 0;
}
