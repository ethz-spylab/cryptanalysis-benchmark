+=============================================================================+
|                                                                             |
|               ***********************************************               |
|               *     POST-QUANTUM CRYPTO STANDARDIZATION     *               |
|               ***********************************************               |
|                                                                             |
|=============================================================================|
|                                                                             |
|        Proposal: Ouroboros-R                                                |
|        Principal Submitters (by alphabetical order):                        |
|                  - Carlos AGUILAR MELCHOR                                   |
|                  - Nicolas ARAGON                                           |
|                  - Slim BETTAIEB                                            |
|                  - Loïc BIDOUX                                              |
|                  - Olivier BLAZY                                            |
| [backup contact] - Jean-Christophe DENEUVILLE                               |
| [main contact]   - Philippe GABORIT                                         |
|                  - Adrien HAUTEVILLE                                        |
|                  - Gilles ZÉMOR                                             |
|                                                                             |
|        Inventors: Same as submitters                                        |
|                                                                             |
|        Developers: Same as submitters                                       |
|                                                                             |
|        Owners: Same as submitters                                           |
|                                                                             |
+=============================================================================+

This archive is a proposal in response to NIST's call for proposal for standar-
dization of quantum-resistant public-key cryptographic algorithms.

Ouroboros-R provides POST-QUANTUM CODE-BASED KEY EXCHANGE and targets NIST's 
security levels 1, 3, and 5.

This archive is organized as follows:

===============================================================================

.
├── KATs: Known Answer Test values
│   ├── Optimized_Implementation: This folder is a copy of KATs/Reference_Implementation
│       ├── ouroboros-r-128: KATs for Ouroboros-R-128 (security level 1)
│       │   ├── ouroboros-r-128_intermediate_values: Intermediate values for Ouroboros-R-128
│       │   ├── ouroboros-r-128_kat.req: Req file for Ouroboros-R-128
│       │   └── ouroboros-r-128_kat.rsp: Rsp file for Ouroboros-R-128
│       ├── ouroboros-r-192: KATs for Ouroboros-R-192 (security level 3)
│       │   ├── ouroboros-r-192_intermediate_values: Intermediate values for Ouroboros-R-192
│       │   ├── ouroboros-r-192_kat.req: Req file for Ouroboros-R-192
│       │   └── ouroboros-r-192_kat.rsp: Rsp file for Ouroboros-R-192
│       └── ouroboros-r-256: KATs for Ouroboros-R-256 (security level 5)
│           ├── ouroboros-r-256_intermediate_values: Intermediate values for Ouroboros-R-256
│           ├── ouroboros-r-256_kat.req: Req file for Ouroboros-R-256
│           └── ouroboros-r-256_kat.rsp: Rsp file for Ouroboros-R-256
│   └── Reference_Implementation: KATs for reference implementation
│       ├── ouroboros-r-128: KATs for Ouroboros-R-128 (security level 1)
│       │   ├── ouroboros-r-128_intermediate_values: Intermediate values for Ouroboros-R-128
│       │   ├── ouroboros-r-128_kat.req: Req file for Ouroboros-R-128
│       │   └── ouroboros-r-128_kat.rsp: Rsp file for Ouroboros-R-128
│       ├── ouroboros-r-192: KATs for Ouroboros-R-192 (security level 3)
│       │   ├── ouroboros-r-192_intermediate_values: Intermediate values for Ouroboros-R-192
│       │   ├── ouroboros-r-192_kat.req: Req file for Ouroboros-R-192
│       │   └── ouroboros-r-192_kat.rsp: Rsp file for Ouroboros-R-192
│       └── ouroboros-r-256: KATs for Ouroboros-R-256 (security level 5)
│           ├── ouroboros-r-256_intermediate_values: Intermediate values for Ouroboros-R-256
│           ├── ouroboros-r-256_kat.req: Req file for Ouroboros-R-256
│           └── ouroboros-r-256_kat.rsp: Rsp file for Ouroboros-R-256
├── Optimized_Implementation: This folder is a copy of Reference_Implementation
│   ├── ouroboros-r-128: Implementation of Ouroboros-R-128 (security level 1)
│   │   ├── doc: Technical documentation folder
│   │   │   ├── main_page.txt: Main page of the technical documentation
│   │   │   └── refs.bib: References for the technical documentation
│   │   ├── doxygen.conf: Doxygen configuration file for the documentation
│   │   ├── lib: Third party librairies folder
│   │   │   ├── hash: Wrapper around SHA512 implementation
│   │   │   │   ├── hash.c: Implementation of hash.h
│   │   │   │   └── hash.h: Wrapper around OpenSSL SHA512 implementation
│   │   │   └── rng: NIST rng files
│   │   │       ├── rng.c: Implementation of rng.h
│   │   │       └── rng.h: NIST functions for randomness generation
│   │   ├── Makefile: Makefile to compile the provided code
│   │   └── src: Ouroboros-R source folder
│   │       ├── api.h: API file for the Ouroboros-R scheme
│   │       ├── ffi: Finite field interface folder
│   │       │   ├── ffi_elt.cpp: Implementation of ffi_elt.h using the NTL library
│   │       │   ├── ffi_elt.h: Interface for finite field elements
│   │       │   ├── ffi_field.cpp: Implementation of ffi_field.h using the NTL library
│   │       │   ├── ffi_field.h: Interface for finite field elements
│   │       │   ├── ffi.h: Constants to define the finite field used
│   │       │   ├── ffi_vec.cpp: Implementation of ffi_vec.h using the NRL library
│   │       │   └── ffi_vec.h: Interface for vectors over finite fields
│   │       ├── kem.cpp: Implementation of api.h
│   │       ├── main_kat.c: NIST KAT generator
│   │       ├── main_ouroboros_r.cpp: Ouroboros-R working example
│   │       ├── parameters.h: Parameters of the Ouroboros-R scheme
│   │       ├── parsing.cpp: Implementation of parsing.h
│   │       ├── parsing.h: Functions to parse public key, secret key and ciphertext
│   │       ├── qcrs_recoverer.cpp: Implementation of qcrs_recoverer.h
│   │       └── qcrs_recoverer.h: Functions to solve the qcrs recovery problem
│   ├── ouroboros-r-192: Implementation of Ouroboros-R-192 (security level 3)
│   │   ├── doc: Technical documentation folder
│   │   │   ├── main_page.txt: Main page of the technical documentation
│   │   │   └── refs.bib: References for the technical documentation
│   │   ├── doxygen.conf: Doxygen configuration file for the documentation
│   │   ├── lib: Third party librairies folder
│   │   │   ├── hash: Wrapper around SHA512 implementation
│   │   │   │   ├── hash.c: Implementation of hash.h
│   │   │   │   └── hash.h: Wrapper around OpenSSL SHA512 implementation
│   │   │   └── rng: NIST rng files
│   │   │       ├── rng.c: Implementation of rng.h
│   │   │       └── rng.h: NIST functions for randomness generation
│   │   ├── Makefile: Makefile to compile the provided code
│   │   └── src: Ouroboros-R source folder
│   │       ├── api.h: API file for the Ouroboros-R scheme
│   │       ├── ffi: Finite field interface folder
│   │       │   ├── ffi_elt.cpp: Implementation of ffi_elt.h using the NTL library
│   │       │   ├── ffi_elt.h: Interface for finite field elements
│   │       │   ├── ffi_field.cpp: Implementation of ffi_field.h using the NTL library
│   │       │   ├── ffi_field.h: Interface for finite field elements
│   │       │   ├── ffi.h: Constants to define the finite field used
│   │       │   ├── ffi_vec.cpp: Implementation of ffi_vec.h using the NRL library
│   │       │   └── ffi_vec.h: Interface for vectors over finite fields
│   │       ├── kem.cpp: Implementation of api.h
│   │       ├── main_kat.c: NIST KAT generator
│   │       ├── main_ouroboros_r.cpp: Ouroboros-R working example
│   │       ├── parameters.h: Parameters of the Ouroboros-R scheme
│   │       ├── parsing.cpp: Implementation of parsing.h
│   │       ├── parsing.h: Functions to parse public key, secret key and ciphertext
│   │       ├── qcrs_recoverer.cpp: Implementation of qcrs_recoverer.h
│   │       └── qcrs_recoverer.h: Functions to solve the qcrs recovery problem
│   ├── ouroboros-r-256: Implementation of Ouroboros-R-256 (security level 5)
│   │   ├── doc: Technical documentation folder
│   │   │   ├── main_page.txt: Main page of the technical documentation
│   │   │   └── refs.bib: References for the technical documentation
│   │   ├── doxygen.conf: Doxygen configuration file for the documentation
│   │   ├── lib: Third party librairies folder
│   │   │   ├── hash: Wrapper around SHA512 implementation
│   │   │   │   ├── hash.c: Implementation of hash.h
│   │   │   │   └── hash.h: Wrapper around OpenSSL SHA512 implementation
│   │   │   └── rng: NIST rng files
│   │   │       ├── rng.c: Implementation of rng.h
│   │   │       └── rng.h: NIST functions for randomness generation
│   │   ├── Makefile: Makefile to compile the provided code
│   │   └── src: Ouroboros-R source folder
│   │       ├── api.h: API file for the Ouroboros-R scheme
│   │       ├── ffi: Finite field interface folder
│   │       │   ├── ffi_elt.cpp: Implementation of ffi_elt.h using the NTL library
│   │       │   ├── ffi_elt.h: Interface for finite field elements
│   │       │   ├── ffi_field.cpp: Implementation of ffi_field.h using the NTL library
│   │       │   ├── ffi_field.h: Interface for finite field elements
│   │       │   ├── ffi.h: Constants to define the finite field used
│   │       │   ├── ffi_vec.cpp: Implementation of ffi_vec.h using the NRL library
│   │       │   └── ffi_vec.h: Interface for vectors over finite fields
│   │       ├── kem.cpp: Implementation of api.h
│   │       ├── main_kat.c: NIST KAT generator
│   │       ├── main_ouroboros_r.cpp: Ouroboros-R working example
│   │       ├── parameters.h: Parameters of the Ouroboros-R scheme
│   │       ├── parsing.cpp: Implementation of parsing.h
│   │       ├── parsing.h: Functions to parse public key, secret key and ciphertext
│   │       ├── qcrs_recoverer.cpp: Implementation of qcrs_recoverer.h
│   │       └── qcrs_recoverer.h: Functions to solve the qcrs recovery problem
│   └── README: Readme file with compilation instructions
├── README.md: This file
├── Reference_Implementation: Ouroboros-R reference implementation
│   ├── ouroboros-r-128: Implementation of Ouroboros-R-128 (security level 1)
│   │   ├── doc: Technical documentation folder
│   │   │   ├── main_page.txt: Main page of the technical documentation
│   │   │   └── refs.bib: References for the technical documentation
│   │   ├── doxygen.conf: Doxygen configuration file for the documentation
│   │   ├── lib: Third party librairies folder
│   │   │   ├── hash: Wrapper around SHA512 implementation
│   │   │   │   ├── hash.c: Implementation of hash.h
│   │   │   │   └── hash.h: Wrapper around OpenSSL SHA512 implementation
│   │   │   └── rng: NIST rng files
│   │   │       ├── rng.c: Implementation of rng.h
│   │   │       └── rng.h: NIST functions for randomness generation
│   │   ├── Makefile: Makefile to compile the provided code
│   │   └── src: Ouroboros-R source folder
│   │       ├── api.h: API file for the Ouroboros-R scheme
│   │       ├── ffi: Finite field interface folder
│   │       │   ├── ffi_elt.cpp: Implementation of ffi_elt.h using the NTL library
│   │       │   ├── ffi_elt.h: Interface for finite field elements
│   │       │   ├── ffi_field.cpp: Implementation of ffi_field.h using the NTL library
│   │       │   ├── ffi_field.h: Interface for finite field elements
│   │       │   ├── ffi.h: Constants to define the finite field used
│   │       │   ├── ffi_vec.cpp: Implementation of ffi_vec.h using the NRL library
│   │       │   └── ffi_vec.h: Interface for vectors over finite fields
│   │       ├── kem.cpp: Implementation of api.h
│   │       ├── main_kat.c: NIST KAT generator
│   │       ├── main_ouroboros_r.cpp: Ouroboros-R working example
│   │       ├── parameters.h: Parameters of the Ouroboros-R scheme
│   │       ├── parsing.cpp: Implementation of parsing.h
│   │       ├── parsing.h: Functions to parse public key, secret key and ciphertext
│   │       ├── qcrs_recoverer.cpp: Implementation of qcrs_recoverer.h
│   │       └── qcrs_recoverer.h: Functions to solve the qcrs recovery problem
│   ├── ouroboros-r-192: Implementation of Ouroboros-R-192 (security level 3)
│   │   ├── doc: Technical documentation folder
│   │   │   ├── main_page.txt: Main page of the technical documentation
│   │   │   └── refs.bib: References for the technical documentation
│   │   ├── doxygen.conf: Doxygen configuration file for the documentation
│   │   ├── lib: Third party librairies folder
│   │   │   ├── hash: Wrapper around SHA512 implementation
│   │   │   │   ├── hash.c: Implementation of hash.h
│   │   │   │   └── hash.h: Wrapper around OpenSSL SHA512 implementation
│   │   │   └── rng: NIST rng files
│   │   │       ├── rng.c: Implementation of rng.h
│   │   │       └── rng.h: NIST functions for randomness generation
│   │   ├── Makefile: Makefile to compile the provided code
│   │   └── src: Ouroboros-R source folder
│   │       ├── api.h: API file for the Ouroboros-R scheme
│   │       ├── ffi: Finite field interface folder
│   │       │   ├── ffi_elt.cpp: Implementation of ffi_elt.h using the NTL library
│   │       │   ├── ffi_elt.h: Interface for finite field elements
│   │       │   ├── ffi_field.cpp: Implementation of ffi_field.h using the NTL library
│   │       │   ├── ffi_field.h: Interface for finite field elements
│   │       │   ├── ffi.h: Constants to define the finite field used
│   │       │   ├── ffi_vec.cpp: Implementation of ffi_vec.h using the NRL library
│   │       │   └── ffi_vec.h: Interface for vectors over finite fields
│   │       ├── kem.cpp: Implementation of api.h
│   │       ├── main_kat.c: NIST KAT generator
│   │       ├── main_ouroboros_r.cpp: Ouroboros-R working example
│   │       ├── parameters.h: Parameters of the Ouroboros-R scheme
│   │       ├── parsing.cpp: Implementation of parsing.h
│   │       ├── parsing.h: Functions to parse public key, secret key and ciphertext
│   │       ├── qcrs_recoverer.cpp: Implementation of qcrs_recoverer.h
│   │       └── qcrs_recoverer.h: Functions to solve the qcrs recovery problem
│   ├── ouroboros-r-256: Implementation of Ouroboros-R-256 (security level 5)
│   │   ├── doc: Technical documentation folder
│   │   │   ├── main_page.txt: Main page of the technical documentation
│   │   │   └── refs.bib: References for the technical documentation
│   │   ├── doxygen.conf: Doxygen configuration file for the documentation
│   │   ├── lib: Third party librairies folder
│   │   │   ├── hash: Wrapper around SHA512 implementation
│   │   │   │   ├── hash.c: Implementation of hash.h
│   │   │   │   └── hash.h: Wrapper around OpenSSL SHA512 implementation
│   │   │   └── rng: NIST rng files
│   │   │       ├── rng.c: Implementation of rng.h
│   │   │       └── rng.h: NIST functions for randomness generation
│   │   ├── Makefile: Makefile to compile the provided code
│   │   └── src: Ouroboros-R source folder
│   │       ├── api.h: API file for the Ouroboros-R scheme
│   │       ├── ffi: Finite field interface folder
│   │       │   ├── ffi_elt.cpp: Implementation of ffi_elt.h using the NTL library
│   │       │   ├── ffi_elt.h: Interface for finite field elements
│   │       │   ├── ffi_field.cpp: Implementation of ffi_field.h using the NTL library
│   │       │   ├── ffi_field.h: Interface for finite field elements
│   │       │   ├── ffi.h: Constants to define the finite field used
│   │       │   ├── ffi_vec.cpp: Implementation of ffi_vec.h using the NRL library
│   │       │   └── ffi_vec.h: Interface for vectors over finite fields
│   │       ├── kem.cpp: Implementation of api.h
│   │       ├── main_kat.c: NIST KAT generator
│   │       ├── main_ouroboros_r.cpp: Ouroboros-R working example
│   │       ├── parameters.h: Parameters of the Ouroboros-R scheme
│   │       ├── parsing.cpp: Implementation of parsing.h
│   │       ├── parsing.h: Functions to parse public key, secret key and ciphertext
│   │       ├── qcrs_recoverer.cpp: Implementation of qcrs_recoverer.h
│   │       └── qcrs_recoverer.h: Functions to solve the qcrs recovery problem
│   └── README: Readme file with compilation instructions
└── Supporting_Documentation
    └── Ouroboros-R_Submission.pdf: Complete specification for our proposal

===============================================================================

The authors did their best to make this archive complete and proper.
    
-------------------------------------------------------------------------------

Important note regarding Intellectual Property.

As requested by the NIST, the statements will be sent to Dustin MOODY at the 
address provided by the NIST (see below) *and/or* given to NIST at the first 
PQC Standardization Conference 

Dustin MOODY
Information Technology Laboratory
Attention: Post-Quantum Cryptographic Algorithm Submissions
100 Bureau Drive – Stop 8930
National Institute of Standards and Technology
Gaithersburg, MD 20899-8930

Please note that in the meantime, electronic copies of these statements have
been included in appendix to the supporting documentation.

