The Files on this CD-ROM Are listed below:
__________________________________________


\Readme\Readme.txt  -  The current file. It lists all files on this CD-ROM.


\Supporting Documentation\Abacus.pdf  -  An Adobe acrobat file which describes the Abacus Hash Function in great detail.


\Optimized_32 bit\Abacus_Optim32.c  - The C source code file for the optimized 32-bit version of the Abacus hash function
\Optimized_32 bit\Abacus_Optim32.h  - The header file for the optimized 32-bit version of the Abacus hash function


\Optimized_64 bit\Abacus_Optim64.c  - The C source code file for the optimized 64-bit version of the Abacus hash function
\Optimized_64 bit\Abacus_Optim64.h  - The header file for the optimized 64-bit version of the Abacus hash function


\Reference Implementation\Abacus_reference.c  - The C source code for the reference version of the Abacus hash function
\Reference Implementation\Abacus_reference.h  - The header file for the reference version of the Abacus hash function


\KAT_MCT\Kat_TheQuick_256.txt  -  A KAT that shows how Abacus's internal state evolves as it digests a message. All of the data-dependent arrays are written to the file during each round of processing.

\KAT_MCT\ExtremelyLongMsgKat_224.txt - Extremely Long Message KAT w/ 224 bit hash
\KAT_MCT\ExtremelyLongMsgKat_256.txt - Extremely Long Message KAT w/ 256 bit hash
\KAT_MCT\ExtremelyLongMsgKat_384.txt - Extremely Long Message KAT w/ 384 bit hash
\KAT_MCT\ExtremelyLongMsgKat_512.txt - Extremely Long Message KAT w/ 512 bit hash

\KAT_MCT\LongmsgKat_224.txt - Long Message KAT w/ 224 bit hash
\KAT_MCT\LongmsgKat_256.txt - Long Message KAT w/ 256 bit hash
\KAT_MCT\LongmsgKat_384.txt - Long Message KAT w/ 384 bit hash
\KAT_MCT\LongmsgKat_512.txt - Long Message KAT w/ 512 bit hash

\KAT_MCT\ShortMsgKat_224.txt - Short Message KAT w/ 224 bit hash
\KAT_MCT\ShortMsgKat_256.txt - Short Message KAT w/ 256 bit hash
\KAT_MCT\ShortMsgKat_384.txt - Short Message KAT w/ 384 bit hash
\KAT_MCT\ShortMsgKat_512.txt - Short Message KAT w/ 512 bit hash

\KAT_MCT\MonteCarlo_224.txt - MonteCarlo test w/ 224 bit hash
\KAT_MCT\MonteCarlo_256.txt - MonteCarlo test w/ 256 bit hash
\KAT_MCT\MonteCarlo_384.txt - MonteCarlo test w/ 384 bit hash
\KAT_MCT\MonteCarlo_512.txt - MonteCarlo test w/ 512 bit hash



