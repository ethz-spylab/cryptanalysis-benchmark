/*
	Giophantus public key cryptosystem

	Copyright(C) 2017 by Toshiba Corporation. All rights reserved.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#ifdef _WIN64
#include <intrin.h>
#endif

#include "api.h"
#include "rng.h"


inline uint64_t getclock(void)
{
#ifdef _WIN64
	uint32_t param;

	return __rdtscp(&param);
#else
	uint32_t hi, lo;

	asm volatile ("rdtsc\n\t" : "=a" (lo), "=d"(hi));
	return ((uint64_t)lo) | (((uint64_t)hi) << 32);
#endif
}


void dump(uint8_t *x, int size, char *label)
{
	int i;

	if(label != NULL) printf("%s = ", label);
	printf("(%d)", size);
	for(i = 0; i < size; i++) printf("%02x", x[i]);
	putchar('\n');
}



#define LOOP 10

int main()
{
	uint8_t entropy_input[48] = {
		0x06,0x15,0x50,0x23,0x4d,0x15,0x8c,0x5e,0xc9,0x55,0x95,0xfe,0x04,0xef,0x7a,0x25,
		0x76,0x7f,0x2e,0x24,0xcc,0x2b,0xc4,0x79,0xd0,0x9d,0x86,0xdc,0x9a,0xbc,0xfd,0xe7,
		0x05,0x6a,0x8c,0x26,0x6f,0x9e,0xf9,0x7e,0xd0,0x85,0x41,0xdb,0xd2,0xe1,0xff,0xa1,
	};
	uint8_t m[MLEN];
	uint8_t m2[MLEN];
	uint8_t sk[SK_SIZE];
	uint8_t pk[PK_SIZE];
	uint8_t c[C_SIZE];
	unsigned long long len;
	uint64_t t, total;
	int rc;
	int i;

	printf("IEC%d benchmark\n", SK_SIZE);

	// initialize random number generator
	randombytes_init(entropy_input, NULL, 256);

	// generate random key pair
	total = 0;
	for(i = 0; i < LOOP; i++){
		t = getclock();
		rc = crypto_encrypt_keypair(pk, sk);
		total += getclock() - t;
	}
	printf("keygen  %lu cycle\n", total / LOOP);

	// encrypt
	randombytes(m, MLEN);

	total = 0;
	for(i = 0; i < LOOP; i++){
		t = getclock();
		rc = crypto_encrypt(c, &len, m, MLEN, pk);
		total += getclock() - t;
	}
	printf("encrypt %lu cycle\n", total / LOOP);

	// decrypt
	total = 0;
	for(i = 0; i < LOOP; i++){
		t = getclock();
		rc = crypto_encrypt_open(m2, &len, c, C_SIZE, sk); // modify
		total += getclock() - t;
	}
	printf("decrypt %lu cycle\n", total / LOOP);
}

