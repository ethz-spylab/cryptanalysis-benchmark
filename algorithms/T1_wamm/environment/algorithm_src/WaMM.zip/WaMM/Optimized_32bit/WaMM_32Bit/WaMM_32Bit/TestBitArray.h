/*
 * TestBitArray.h
 *
 * Defines an array fo bits of arbirary length.
 *
 * Copyright 2008 John Washburn.  All rights reserved until I win the SHA3 contest.
 */
/*
 * ***************************************************************************************************
 * TestBitArray.h ($RCSfile: TestBitArray.h,v $)
 *
 * Header file for the test harness used to verify the correct operations on BitArrays
 *
 * Copyright 2008 John Washburn.  All rights reserved until I win the SHA3 contest.
 *
 *
 * ***************************************************************************************************

$Header: D:\\RCSArchive\\D\\Programming\\WaMM\\ReferenceImplementation\\WaMM\\WaMM\\TestBitArray.h,v 1.3 2008-10-13 18:13:56-05 johnwashburn Exp johnwashburn $

$Revision: 1.3 $

$Log: TestBitArray.h,v $
Revision 1.3  2008-10-13 18:13:56-05  johnwashburn
Daily Check Point


 *
 */
#ifndef TestBitArray_h_C4CF4DF7_3FA7_442a_9590_2E525DE6C2B8
#define TestBitArray_h_C4CF4DF7_3FA7_442a_9590_2E525DE6C2B8 1

/* TODO: Change GUID*/

#include <stdlib.h>
#include <stdio.h>
#include "BitArray.h"

BOOL TestBitArrays(void);

#endif /* #ifndef TestBitArray_h_C4CF4DF7_3FA7_442a_9590_2E525DE6C2B8 */