/*
 * main.c ($RCSfile: main.c,v $)
 *
 * Entry point for the reference implementation of the WaMM Hashing algorithm.
 *
 * Copyright 2008 John Washburn.  All rights reserved until I win the SHA3 contest.

$Header: D:\\RCSArchive\\D\\Programming\\WaMM\\ReferenceImplementation\\WaMM\\WaMM\\main.c,v 1.7 2008-10-19 08:25:49-05 johnwashburn Exp johnwashburn $
$Revision: 1.7 $

$Log: main.c,v $
Revision 1.7  2008-10-19 08:25:49-05  johnwashburn
Daily Checkpointing

Revision 1.6  2008-10-13 18:13:54-05  johnwashburn
Daily Check Point

Revision 1.2  2008-10-08 02:25:52-05  johnwashburn
proved comment header block to better use RCS keywords

Revision 1.1  2008-10-08 02:08:03-05  johnwashburn
Added RCS Header Comment block using RCS Keywords.


 */
#include "WaMM.h"
#include "TestBitArray.h"
#include "TestHashing.h"
#include "genKAT.h"

BOOL RunTestHarness(void);
BOOL TestHashing(void);

int main()
{
	InitWaMMEnvironment();

	// RunTestHarness();

	GenerateKAT_MCT();
}

BOOL RunTestHarness(void)
{
	BOOL bStatus = TRUE;

//	bStatus = TestBitArrays();
	printf("TestBitArrays() %s.\n", (bStatus? "passed" : "FAILED"));

	bStatus = TestHashing();
	printf("TestHashing() %s.\n", (bStatus? "passed" : "FAILED"));

	return bStatus;
}

