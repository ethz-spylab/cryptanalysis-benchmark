/*
 * ***************************************************************************************************
 * TestHashing.h ($RCSfile: CommentHeaderTemplate.txt,v $)
 *
 * Defineds function used in the test harness for testing hashing
 *
 * Copyright 2008 John Washburn.  All rights reserved until I win the SHA3 contest.
 *
 *
 * ***************************************************************************************************

$Header: $

$Revision: $

$Log: $

 *
 */
#ifndef TestHashing_h_B334BFE1_3330_4850_8DC6_85CA3FA33CC9
#define TestHashing_h_B334BFE1_3330_4850_8DC6_85CA3FA33CC9 1

#include "WaMM.H"

BOOL TestHashing(void);

#endif /* #ifndef TestHashing_h_B334BFE1_3330_4850_8DC6_85CA3FA33CC9 */

