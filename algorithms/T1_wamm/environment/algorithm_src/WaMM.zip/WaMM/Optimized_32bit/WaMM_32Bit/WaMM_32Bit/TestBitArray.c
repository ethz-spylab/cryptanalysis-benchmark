
/*
 * ***************************************************************************************************
 * TestBitArray.c ($RCSfile: TestBitArray.c,v $)
 *
 * Test harness for verifying the operation of the simplified BitArray library.
 *
 * Copyright 2008 John Washburn.  All rights reserved until I win the SHA3 contest.
 *
 *
 * ***************************************************************************************************

$Header: D:\\RCSArchive\\D\\Programming\\WaMM\\ReferenceImplementation\\WaMM\\WaMM\\TestBitArray.c,v 1.4 2008-10-19 08:25:49-05 johnwashburn Exp johnwashburn $

$Revision: 1.4 $

$Log: TestBitArray.c,v $
Revision 1.4  2008-10-19 08:25:49-05  johnwashburn
Daily Checkpointing

Revision 1.3  2008-10-13 18:13:55-05  johnwashburn
Daily Check Point


 *
 */
#include "TestBitArray.h"
#include "WaMMErrorMessage.h"

BOOL TestBitArrayConcatenation(void);
BOOL TestBitArrayCreate(void);
BOOL TestBitArrayFromBitArray(void);
BOOL TestConcatenateTwoBitSequences(void);
BOOL TestBitArrayShiftLeft(void);
BOOL TestBitArrayShiftRight(void);
BOOL TestPopWholeVectorFromBitArray(void);

BOOL TestBitArrays(void)
{
	BOOL bStatus = TRUE;

//	bStatus = (SUCCESS == EnableBitArrays());
	printf("EnableBitArrays() %s.\n\f", (bStatus? "passed" : "FAILED"));

//	bStatus = TestBitArrayCreate();
	printf("TestBitArrayCreate() %s.\n\f", (bStatus? "passed" : "FAILED"));

//	bStatus = TestBitArrayConcatenation();
	printf("TestBitArrayConcatenation() %s.\n\f", (bStatus? "passed" : "FAILED"));

//	bStatus = TestBitArrayFromBitArray();
	printf("TestCloneBitArray() %s.\n\f", (bStatus? "passed" : "FAILED"));

//	bStatus = TestConcatenateTwoBitSequences();
	printf("TestConcatenateTwoBitSequences() %s.\n\f", (bStatus? "passed" : "FAILED"));

//	bStatus = TestBitArrayShiftLeft();
	printf("TestBitArrayShiftLeft() %s.\n\f", (bStatus? "passed" : "FAILED"));

//	bStatus = TestBitArrayShiftRight();
	printf("TestBitArrayShiftRight() %s.\n\f", (bStatus? "passed" : "FAILED"));

//	bStatus = TestPopWholeVectorFromBitArray();
	printf("TestPopWholeVectorFromBitArray() %s.\n\f", (bStatus? "passed" : "FAILED"));

	return bStatus;
}



BOOL TestBitArrayCreate(void)
{
	BOOL bPassed = FALSE;

	int iBitlen;
	int iNumBytes = 8;
	int iMaxBits = iNumBytes * WaMM_BitsPerBitSequence;
	BitSequence TestSequence[8] = {0xC1, 0xF5, 0x69, 0xBD, 0x37, 0x20, 0xE4, 0x8A};
	BitArray *pDestinationBitArray = NULL;

	pDestinationBitArray = NewBitArray(0);
	if (NULL != pDestinationBitArray)
	{
		FreeBitArray(pDestinationBitArray);
		pDestinationBitArray = NewBitArray(1);
		if (NULL != pDestinationBitArray)
		{
			FreeBitArray(pDestinationBitArray);
			pDestinationBitArray = NewBitArray(100);
			if (NULL != pDestinationBitArray)
			{
				FreeBitArray(pDestinationBitArray);
				pDestinationBitArray = NewBitArray(256);
				if (NULL != pDestinationBitArray)
				{
					BitArrayToSring(pDestinationBitArray, _WaMM_ErrorMesssage);
					printf("Empty BitArray with %d bits = %s.\n", pDestinationBitArray->lNumBits, _WaMM_ErrorMesssage);

					FreeBitArray(pDestinationBitArray);
					pDestinationBitArray = NULL;

					bPassed = TRUE;
				}
			}
		}
	}

	/* Create small bit arrays from the test sequence */
	if (bPassed)
	{
		printf("BitSequence TestSequence[8] = {0xC1, 0xF5, 0x69, 0xBD, 0x37, 0x20, 0xE4, 0x8A};\n");
		for (iBitlen = 0; iBitlen <= iMaxBits; ++iBitlen)
		{
			pDestinationBitArray = BitArrayFromBitSequence(iBitlen, TestSequence);
			if (NULL != pDestinationBitArray)
			{
				BitArrayToSring(pDestinationBitArray, _WaMM_ErrorMesssage);
				printf("BitArray from test sequence of length %d bits = %s.\n", pDestinationBitArray->lNumBits, _WaMM_ErrorMesssage);

				FreeBitArray(pDestinationBitArray);
				pDestinationBitArray = NULL;
			}
			else
			{
				bPassed = FALSE;
			}
		}
	}

	return bPassed;
}

BOOL TestBitArrayConcatenation(void)
{
	BOOL bPassed = FALSE;

	int iNumBytes = 8;
	int iMaxBits = iNumBytes * WaMM_BitsPerBitSequence;
	BitSequence TestSequence[8] = {0xF5, 0x61, 0xBD, 0x79, 0x3C, 0x20, 0xE4, 0x8A};
	BitArray *pDestinationBitArray = NULL;
	BitArray *pSourceBitArray = NULL;
	int iAddedBitLen;
	int iOrgBitLen;
	int i;

	printf("Test Sequence = [ ");
	for (i = 0; i < iNumBytes;++i)
	{
		printf("0x%2.2X ", TestSequence[i]);
	}
	printf("]\n");

	bPassed = TRUE;
	for (iOrgBitLen = 1; bPassed && (iOrgBitLen <= iMaxBits); ++iOrgBitLen)
	{
		for (iAddedBitLen = 31; bPassed && (iAddedBitLen <= iMaxBits); ++iAddedBitLen)
		{
			bPassed = FALSE;
			pDestinationBitArray = BitArrayFromBitSequence(iOrgBitLen, TestSequence);
			if (NULL != pDestinationBitArray)
			{
				BitArrayToSring(pDestinationBitArray, _WaMM_ErrorMesssage);
				printf("BitArray %s concatenated with ", _WaMM_ErrorMesssage);

				pSourceBitArray = BitArrayFromBitSequence(iAddedBitLen, TestSequence);
				if (NULL != pSourceBitArray)
				{
					BitArrayToSring(pSourceBitArray, _WaMM_ErrorMesssage);
					printf("%s ", _WaMM_ErrorMesssage);
					if (SUCCESS == ConcatenateBitArray(pDestinationBitArray, pSourceBitArray))
					{
						BitArrayToSring(pDestinationBitArray, _WaMM_ErrorMesssage);
						printf("Yields: %s.\n", _WaMM_ErrorMesssage);
						bPassed = TRUE;
					}

					FreeBitArray(pSourceBitArray);
					pSourceBitArray = NULL;
				}

				FreeBitArray(pDestinationBitArray);
				pDestinationBitArray = NULL;
			}
		}
	}

	return bPassed;
}

BOOL TestBitArrayFromBitArray()
{
	BOOL bPassed = TRUE;

	int iNumBytes = 8;
	int iMaxBits = iNumBytes * WaMM_BitsPerBitSequence;
	BitSequence TestSequence[8] = {0xF5, 0x61, 0xBD, 0x79, 0x3C, 0x20, 0xE4, 0x8A};
	BitArray *pClonedBitArray = NULL;
	BitArray *pSourceBitArray = NULL;
	int iBitLen;

	for (iBitLen = 0; bPassed && (iBitLen <= iMaxBits); ++iBitLen)
	{
		bPassed = FALSE;
		pSourceBitArray = BitArrayFromBitSequence(iBitLen, TestSequence);
		if (NULL != pSourceBitArray)
		{
			pClonedBitArray = BitArrayFromBitArray(pSourceBitArray);
			if (NULL != pClonedBitArray)
			{
				BitArrayToSring(pSourceBitArray, _WaMM_ErrorMesssage);
				printf("BitArray\n%s cloned to ", _WaMM_ErrorMesssage);
				BitArrayToSring(pClonedBitArray, _WaMM_ErrorMesssage);
				printf(" %s.\n", _WaMM_ErrorMesssage);

				bPassed = TRUE;

				FreeBitArray(pClonedBitArray);
				pClonedBitArray = NULL;
			}

			FreeBitArray(pSourceBitArray);
			pSourceBitArray = NULL;
		}
	}

	return bPassed;
}

BOOL TestConcatenateTwoBitSequences()
{
	BOOL bPassed = FALSE;

	int iNumTestBytes = 8;
	int iMaxTestBits = iNumTestBytes * WaMM_BitsPerBitSequence;
	BitSequence TestSequence[2][8] = {
			{0xF5, 0x61, 0xBD, 0x79, 0x3C, 0x20, 0xE4, 0x8A},
			{0xC1, 0xF5, 0x69, 0xBD, 0x37, 0x20, 0xE4, 0x8A}
	};
	BitSequence *pResultSequence;
	int iBitLen[3];
	int iByteLength[3];
	int j, i;
	div_t DivResults;

	for (j = 0; j < 2; ++j)
	{
		printf("Test Sequence[%d] = [ ", j);
		for (i = 0; i < iNumTestBytes; ++i)
		{
			printf("0x%2.2X ", TestSequence[j][i]);
		}
		printf("]\n");
	}
	printf("]\n");

	bPassed = TRUE;
	for (iBitLen[0] = 0; bPassed && (iBitLen[0] <= iMaxTestBits); ++iBitLen[0])
	{
		DivResults = div(iBitLen[0], WaMM_BitsPerBitSequence);
		iByteLength[0]  = DivResults.quot;
		iByteLength[0] += DivResults.rem ? 1 : 0;

		for (iBitLen[1] = 0; bPassed && (iBitLen[1] <= iMaxTestBits); ++iBitLen[1])
		{
			bPassed = FALSE;

			DivResults = div(iBitLen[1], WaMM_BitsPerBitSequence);
			iByteLength[1]  = DivResults.quot;
			iByteLength[1] += DivResults.rem ? 1 : 0;

			pResultSequence = ConcatenateTwoBitSequences(iBitLen[0], TestSequence[0], iBitLen[1], TestSequence[1]);
			if (NULL != pResultSequence)
			{
				iBitLen[2] = iBitLen[0] + iBitLen[1];
				DivResults = div(iBitLen[2], WaMM_BitsPerBitSequence);
				iByteLength[2]  = DivResults.quot;
				iByteLength[2] += DivResults.rem ? 1 : 0;

				printf("%d-[", iBitLen[0]);
				for (i = 0; i < iByteLength[0];++i)
				{
					printf("%2.2X", TestSequence[0][i]);
				}
				printf("] + %d-[", iBitLen[1]);
				for (i = 0; i < iByteLength[1];++i)
				{
					printf("%2.2X", TestSequence[1][i]);
				}
				printf("] = %d-[", iBitLen[2]);
				for (i = 0; i < iByteLength[2];++i)
				{
					printf("%2.2X", pResultSequence[i]);
				}
				printf("].\n");
				
				bPassed = TRUE;

				free(pResultSequence);
				pResultSequence = NULL;
			}
		}
	}

	return bPassed;
}

BOOL TestBitArrayShiftLeft()
{
	BOOL bPassed = FALSE;
	HashReturn retVal = FAIL;
	int iNegShift;

	int iNumTestBytes = 8;
	int iMaxTestBits = iNumTestBytes * WaMM_BitsPerBitSequence;
	BitSequence TestSequence[8] = {0xF5, 0x61, 0xBD, 0x79, 0x3C, 0x20, 0xE4, 0x8A};
	BitArray *pSourceBitArray = BitArrayFromBitSequence(iMaxTestBits, TestSequence);
	BitArray *pClonedBitArray = NULL;
	int iSourceBitLen;
	int iShiftLen;

	if (NULL != pSourceBitArray)
	{
		bPassed = TRUE;
		for (iSourceBitLen = 0; bPassed && (iSourceBitLen <= iMaxTestBits); ++iSourceBitLen)
		{
			if (8 < iSourceBitLen)
			{
				iNegShift = -9;
			}
			else
			{
				iNegShift = -iSourceBitLen-1;
			}
			pSourceBitArray->lNumBits = iSourceBitLen;
			for(iShiftLen = iNegShift; bPassed && (iShiftLen <= iSourceBitLen + 1); ++iShiftLen)
			{
				bPassed = FALSE;

				pClonedBitArray = BitArrayFromBitArray(pSourceBitArray);
				if (NULL != pClonedBitArray)
				{
					BitArrayToSring(pClonedBitArray, _WaMM_ErrorMesssage);
					printf("BitArray\n%s shifted left %d bits = \n", _WaMM_ErrorMesssage, iShiftLen);

					retVal = BitArrayShiftLeft(pClonedBitArray, iShiftLen);

					BitArrayToSring(pClonedBitArray, _WaMM_ErrorMesssage);
					printf("%s\n", _WaMM_ErrorMesssage);

					bPassed = (SUCCESS == retVal);
				}
			}
		}
	}

	if (!bPassed)
	{
		printf("ErrorCode = %d\n\n", retVal);
	}

	return bPassed;
}
BOOL TestBitArrayShiftRight()
{
	BOOL bPassed = FALSE;
	HashReturn retVal = FAIL;
	int iNegShift;

	int iNumTestBytes = 8;
	int iMaxTestBits = iNumTestBytes * WaMM_BitsPerBitSequence;
	BitSequence TestSequence[8] = {0xF5, 0x61, 0xBD, 0x79, 0x3C, 0x20, 0xE4, 0x8A};
	BitArray *pSourceBitArray = BitArrayFromBitSequence(iMaxTestBits, TestSequence);
	BitArray *pClonedBitArray = NULL;
	int iSourceBitLen;
	int iShiftLen;

	if (NULL != pSourceBitArray)
	{
		bPassed = TRUE;
		for (iSourceBitLen = 0; bPassed && (iSourceBitLen <= iMaxTestBits); ++iSourceBitLen)
		{
			if (8 < iSourceBitLen)
			{
				iNegShift = -9;
			}
			else
			{
				iNegShift = -iSourceBitLen-1;
			}
			pSourceBitArray->lNumBits = iSourceBitLen;
			for(iShiftLen = iNegShift; bPassed && (iShiftLen <= iSourceBitLen + 1); ++iShiftLen)
			{
				bPassed = FALSE;

				pClonedBitArray = BitArrayFromBitArray(pSourceBitArray);
				if (NULL != pClonedBitArray)
				{
					BitArrayToSring(pClonedBitArray, _WaMM_ErrorMesssage);
					printf("BitArray\n%s shifted right %d bits = \n", _WaMM_ErrorMesssage, iShiftLen);

					retVal = BitArrayShiftRight(pClonedBitArray, iShiftLen);

					BitArrayToSring(pClonedBitArray, _WaMM_ErrorMesssage);
					printf("%s\n", _WaMM_ErrorMesssage);

					bPassed = (SUCCESS == retVal);
				}
			}
		}
	}

	if (!bPassed)
	{
		printf("ErrorCode = %d\n\n", retVal);
	}

	return bPassed;
}

BOOL TestPopWholeVectorFromBitArray()
{
	BOOL bPassed = FALSE;

	return bPassed;
}

