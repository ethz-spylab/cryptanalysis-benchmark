/*
 * GenerateKAT_MCT.H ($RCSfile: $)
 *
 * Generate Know Answers Test results and Mante Carlo Test Results.
 *
 * Copyright 2008 John Washburn.  All rights reserved until I win the SHA3 contest.

$Header: $
$Revision: $

$Log: $
 */

#ifndef GenerateKAT_MCT_h_4D2DF387_53E7_4231_8F6A_20EF4A08E8F7
#define GenerateKAT_MCT_h_4D2DF387_53E7_4231_8F6A_20EF4A08E8F7 1

#include "WaMM.h"

#define	MAX_MARKER_LEN		50
#define	SUBMITTER_INFO_LEN	128

typedef enum { KAT_SUCCESS = 0, KAT_FILE_OPEN_ERROR = 1, KAT_HEADER_ERROR = 2, KAT_DATA_ERROR = 3, KAT_HASH_ERROR = 4 } STATUS_CODES;

STATUS_CODES GenerateKAT_MCT(void);

#endif /*#ifndef GenerateKAT_MCT_h_4D2DF387_53E7_4231_8F6A_20EF4A08E8F7 */