
$root$\
    Cover Sheet.docx
    
$root$\Additional_Implementations\
    
$root$\Intelectual Property Statements\
    Statement by Reference Implementation Owner.doc
    Statement bySubmitter John Washburn.doc
    
$root$\KAT_MCT\
    ExtremelyLongMsgKAT_224.txt
    ExtremelyLongMsgKAT_256.txt
    ExtremelyLongMsgKAT_384.txt
    ExtremelyLongMsgKAT_512.txt
    LongMsgKAT_224.txt
    LongMsgKAT_256.txt
    LongMsgKAT_384.txt
    LongMsgKAT_512.txt
    MonteCarlo_224.txt
    MonteCarlo_256.txt
    
$root$\KAT_MCT\With Intermediate Values\
    With Intermediate Values.zip
    
$root$\Optimized_32bit\
    
$root$\Optimized_32bit\WaMM_32Bit\
    WaMM_32Bit.ncb
    WaMM_32Bit.sln
    WaMM_32Bit.suo
    WaMM_Ref.ncb
    WaMM_Ref.suo
    
$root$\Optimized_32bit\WaMM_32Bit\Debug\
    WaMM_32Bit.exe
    WaMM_32Bit.ilk
    WaMM_32Bit.pdb
    WaMM_Ref.exe
    WaMM_Ref.ilk
    WaMM_Ref.pdb
    
$root$\Optimized_32bit\WaMM_32Bit\Release\
    WaMM_32Bit.exe
    WaMM_32Bit.pdb
    WaMM_Ref.exe
    WaMM_Ref.pdb
    
$root$\Optimized_32bit\WaMM_32Bit\WaMM_32Bit\
    BitArray.c
    BitArray.h
    genKAT.c
    genKAT.h
    main.c
    ReverseBits.c
    ReverseBits.h
    SHA3API.c
    SHA3API.h
    TestBitArray.c
    
$root$\Optimized_32bit\WaMM_32Bit\WaMM_32Bit\Debug\
    BitArray.obj
    BuildLog.htm
    genKAT.obj
    main.obj
    mt.dep
    ReverseBits.obj
    SHA3API.obj
    TestBitArray.obj
    TestHashing.obj
    vc90.idb
    
$root$\Optimized_32bit\WaMM_32Bit\WaMM_32Bit\Release\
    BitArray.obj
    BuildLog.htm
    genKAT.obj
    main.obj
    mt.dep
    ReverseBits.obj
    SHA3API.obj
    TestBitArray.obj
    TestHashing.obj
    vc90.idb
    
$root$\Optimized_64bit\
    
$root$\Optimized_64bit\WaMM_64Bit\
    WaMM_64Bit.ncb
    WaMM_64Bit.sln
    WaMM_64Bit.suo
    
$root$\Optimized_64bit\WaMM_64Bit\Debug\
    WaMM_64Bit.exe
    WaMM_64Bit.ilk
    WaMM_64Bit.pdb
    
$root$\Optimized_64bit\WaMM_64Bit\Release\
    WaMM_64Bit.exe
    WaMM_64Bit.pdb
    
$root$\Optimized_64bit\WaMM_64Bit\WaMM_64Bit\
    BitArray.c
    BitArray.h
    genKAT.c
    genKAT.h
    main.c
    ReverseBits.c
    ReverseBits.h
    SHA3API.c
    SHA3API.h
    TestBitArray.c
    
$root$\Optimized_64bit\WaMM_64Bit\WaMM_64Bit\Debug\
    BitArray.obj
    BuildLog.htm
    genKAT.obj
    main.obj
    mt.dep
    ReverseBits.obj
    SHA3API.obj
    TestBitArray.obj
    TestHashing.obj
    vc90.idb
    
$root$\Optimized_64bit\WaMM_64Bit\WaMM_64Bit\Release\
    BitArray.obj
    BuildLog.htm
    genKAT.obj
    main.obj
    mt.dep
    ReverseBits.obj
    SHA3API.obj
    TestBitArray.obj
    TestHashing.obj
    vc90.idb
    
$root$\README\
    
$root$\Reference_Implementation\
    
$root$\Reference_Implementation\WaMM_Ref\
    WaMM_Ref.ncb
    WaMM_Ref.sln
    WaMM_Ref.suo
    
$root$\Reference_Implementation\WaMM_Ref\Debug\
    WaMM_Ref.exe
    WaMM_Ref.ilk
    WaMM_Ref.pdb
    
$root$\Reference_Implementation\WaMM_Ref\Release\
    WaMM_Ref.exe
    WaMM_Ref.pdb
    
$root$\Reference_Implementation\WaMM_Ref\WaMM_Ref\
    BitArray.c
    BitArray.h
    genKAT.c
    genKAT.c.bak
    genKAT.h
    genKAT.h.bak
    main.c
    main.c.bak
    ReverseBits.c
    ReverseBits.h
    
$root$\Reference_Implementation\WaMM_Ref\WaMM_Ref\Debug\
    BitArray.obj
    BuildLog.htm
    genKAT.obj
    main.obj
    mt.dep
    ReverseBits.obj
    SHA3API.obj
    TestBitArray.obj
    TestHashing.obj
    vc90.idb
    
$root$\Reference_Implementation\WaMM_Ref\WaMM_Ref\Release\
    BitArray.obj
    BuildLog.htm
    genKAT.obj
    main.obj
    mt.dep
    ReverseBits.obj
    SHA3API.obj
    TestBitArray.obj
    TestHashing.obj
    vc90.idb
    
$root$\Supplemental Material\
    
$root$\Supplemental Material\SearchMatrix\
    SearchMatrix.sln
    SearchMatrix.suo
    
$root$\Supplemental Material\SearchMatrix\debug\
    SearchMatrix.exe
    SearchMatrix.ilk
    SearchMatrix.pdb
    
$root$\Supplemental Material\SearchMatrix\release\
    SearchMatrix.exe
    SearchMatrix.pdb
    
$root$\Supplemental Material\SearchMatrix\SearchMatrix\
    CFlatMatrixOperatorFFT.cpp
    CFlatMatrixOperatorFFT.cpp.bak
    CMatrixOperator.cpp
    CMatrixOperator.h
    FlatOperatorFFT-Flat000.dat
    FlatOperatorRaw-Flat000.dat
    MersenneTwister.cpp
    MersenneTwister.h
    ReadMe.txt
    resource.h
    
$root$\Supplemental Material\SearchMatrix\SearchMatrix\Debug\
    BuildLog.htm
    CMatrixOperator.obj
    MersenneTwister.obj
    mt.dep
    SearchMatrix.exe.embed.manifest
    SearchMatrix.exe.embed.manifest.res
    SearchMatrix.exe.intermediate.manifest
    SearchMatrix.obj
    SearchMatrix.pch
    SearchMatrix.res
    
$root$\Supplemental Material\SearchMatrix\SearchMatrix\Release\
    BuildLog.htm
    CMatrixOperator.asm
    CMatrixOperator.obj
    MersenneTwister.asm
    MersenneTwister.obj
    mt.dep
    SearchMatrix.asm
    SearchMatrix.exe.intermediate.manifest
    SearchMatrix.obj
    SearchMatrix.pch
    
$root$\Supplemental Material\SearchMatrix\SearchMatrix\res\
    SearchMatrix.ico
    SearchMatrix.rc2
    
$root$\Supporting_Documentation\
    Appendix-A.pdf
    WaMM-SHA3.pdf
