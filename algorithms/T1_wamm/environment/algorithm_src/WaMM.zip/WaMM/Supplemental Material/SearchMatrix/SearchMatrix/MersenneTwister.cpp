// MersenneTwister.cpp : Defines the class behaviors for the rand number generator.
//

#include "stdafx.h"
#include "MersenneTwister.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// module-scoped variables
MTRand g_mtrRandom;

