// SearchMatrixDlg.h : header file
//

#include "CMatrixOperator.h"
#pragma once


// CSearchMatrixDlg dialog
class CSearchMatrixDlg : public CDialog
{
// Construction
public:
	CSearchMatrixDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_SEARCHMATRIX_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	void SpawnSearch(void);

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
public:
	afx_msg void OnBnClickedCancel();

private:
	ANNEAL_PARAMS annealingParams;
	int iMode;
	afx_msg void OnLbnSelchangeList1();
};
