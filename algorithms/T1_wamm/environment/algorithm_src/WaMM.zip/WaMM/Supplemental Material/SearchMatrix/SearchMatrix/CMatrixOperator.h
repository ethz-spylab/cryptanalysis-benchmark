// CMatrixOperator.h : header file
//

#pragma once

typedef long int FFT_VAL;
typedef long long MATRIX_WEIGHT;

// forward Reference is need for the Params block
class CMatrixOperator;
typedef struct AnnealingParameters {
	int* piMode;
	int iNumMaxHillClimbingSteps;
	int iNumStepsClimbed;
	CString strFilenameBestMatrix;
	CMatrixOperator* pBestMatrix;
	CListBox* pListBoxOfResults;
	CWnd* pwndSearchStatus;
} ANNEAL_PARAMS;

// CSearchMatrixDlg dialog
class CMatrixOperator : public CObject
{
	// Static constants
	public:
		static int const NUM_BITS = 8;
		static int const NUM_VALUES = 1 << NUM_BITS;
		static MATRIX_WEIGHT const MAX_MATRIX_WEIGHT = (~(((MATRIX_WEIGHT) 1) << 31)) * (~(((MATRIX_WEIGHT) 1) << 31));
		static MATRIX_WEIGHT const MIN_MATRIX_WEIGHT = -MAX_MATRIX_WEIGHT;
		static CString const DEFAULT_FILENAME_BASE;

	private: 
		static int const NORMALIZATION_CONST = 1 << (NUM_BITS / 2);
		static int const m_gciNumFlatOperators = 1;
		static CMatrixOperator gc_matrixFlatOperatorsFFT_2D[m_gciNumFlatOperators];
		static bool m_bFlatsAreInitialized;
		static bool InitializeFlatOperators(void);
		static int const m_gciNumMatrixWeights = 4;

	// Construction
	public:
		 CMatrixOperator();
		~CMatrixOperator();
		 CMatrixOperator(const FFT_VAL piMaxtrix[CMatrixOperator::NUM_VALUES][CMatrixOperator::NUM_VALUES]);
		 CMatrixOperator(const CMatrixOperator& orgMatrix);
		 void ResetMatrix();
		 bool IsBijectiveOperator(void) const;

	public:
		CMatrixOperator& operator  = (const CMatrixOperator& opRHS);
		CMatrixOperator& operator += (const CMatrixOperator& opRHS);
		CMatrixOperator& operator += (int iScalar);
		CMatrixOperator& operator -= (const CMatrixOperator& opRHS);
		CMatrixOperator& operator -= (int iScalar);
		CMatrixOperator& operator *= (const CMatrixOperator& opRHS);
		CMatrixOperator& operator *= (int iScalar);

		bool operator == (CMatrixOperator& opRHS);
		bool operator != (CMatrixOperator& opRHS);
		bool operator <  (CMatrixOperator& opRHS);
		bool operator <= (CMatrixOperator& opRHS);
		bool operator >  (CMatrixOperator& opRHS);
		bool operator >= (CMatrixOperator& opRHS);

		MATRIX_WEIGHT SumMatrix(bool bAbsolute = true) const;
		MATRIX_WEIGHT MatrixSumOfSquares(void) const;
		MATRIX_WEIGHT Min() const;
		MATRIX_WEIGHT Max() const;
		static CMatrixOperator& GetFlatOperator_FFT(int iOperatorNumber);
		static CString GetTimeNow(void);
		bool ClimbHill(AnnealingParameters* pParamBlock);
		static void CMatrixOperator::RandomizeVector(int iVector[], int iNumElements);

	public:
		CMatrixOperator& FFT_2D(const CMatrixOperator& opRHS);
		CMatrixOperator& CMatrixOperator::FFT_2D();
		CMatrixOperator& InverseFFT_2D();
		CMatrixOperator& InverseFFT_2D(const CMatrixOperator& opRHS);
		static void InPlaceFFT(FFT_VAL iVector[NUM_VALUES], bool bNormalize = true);

		FFT_VAL GetMatrixCell(int i, int j, bool bCircular = true) const;
		FFT_VAL SetMatrixCell(int i, int j, FFT_VAL iNewVal, bool bCircular = true);
		bool RandomizeMatrix();
		bool SwapRows(int iRow1, int iRow2);
		bool SwapColumns(int iRow1, int iRow2);
		void FormatWeights(CString& strOutputLine) const;
		bool WriteMatrixToFile(CString strFileName) const;
		bool ReadMatrixFromFile(CString strFileName);

	private:
		void InitializeMatrix(void);
		void InitializeNonMatrix(void);
		void CopyIn(const CMatrixOperator& opRHS);
		void WeighMatrix(void);
		int Compare(CMatrixOperator& opRHS);

	private:
		FFT_VAL m_iMaxtrix[NUM_VALUES][NUM_VALUES];
		MATRIX_WEIGHT m_llMatrixWeight[m_gciNumMatrixWeights];
		bool m_bWeightDirty;
};


