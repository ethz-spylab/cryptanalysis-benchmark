// SearchMatrixDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SearchMatrix.h"
#include "SearchMatrixDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

UINT AnnealMatrixOperator( LPVOID pParam );
CString strMatrixDirectory = "C:\\Personal\\WaSP\\SearchMatrix\\BestMatrices\\";


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CSearchMatrixDlg dialog




CSearchMatrixDlg::CSearchMatrixDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSearchMatrixDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSearchMatrixDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSearchMatrixDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CSearchMatrixDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CSearchMatrixDlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// CSearchMatrixDlg message handlers

BOOL CSearchMatrixDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	iMode = 0;
	annealingParams.iNumMaxHillClimbingSteps = 0;
	annealingParams.iNumStepsClimbed = 0;
	annealingParams.pBestMatrix = NULL;
	annealingParams.piMode = NULL;
	annealingParams.pListBoxOfResults = NULL;
	annealingParams.pwndSearchStatus = NULL;
	annealingParams.strFilenameBestMatrix.Empty();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSearchMatrixDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSearchMatrixDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSearchMatrixDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CSearchMatrixDlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	OnCancel();
}

void CSearchMatrixDlg::SpawnSearch()
{
	if (NULL == annealingParams.pBestMatrix)
	{
		annealingParams.pBestMatrix = new CMatrixOperator();
	}
	annealingParams.piMode = &iMode;

	bool bStatus;
	CString strFileName;
	CString strNow;

	ASSERT(NULL != annealingParams.pBestMatrix);
	if (NULL != annealingParams.pBestMatrix)
	{
		// Read Current Best from Disk
		strFileName.Format(_T("%s%s.dat"), strMatrixDirectory, CMatrixOperator::DEFAULT_FILENAME_BASE);
		bStatus = annealingParams.pBestMatrix->ReadMatrixFromFile(strFileName);

		// Use Random matrix if there is not current best
		if (bStatus)
		{
			bStatus = (*(annealingParams.pBestMatrix) == *(annealingParams.pBestMatrix));	// Force a weighing
		}
		else
		{
			annealingParams.pBestMatrix->RandomizeMatrix();
			bStatus = (*(annealingParams.pBestMatrix) == *(annealingParams.pBestMatrix));	// Force a weighing
			annealingParams.pBestMatrix->WriteMatrixToFile(strFileName);
		}
		// Save Backup
		strNow = CMatrixOperator::GetTimeNow();
		strFileName.Format(_T("%s%s-%s.dat"), strMatrixDirectory, CMatrixOperator::DEFAULT_FILENAME_BASE, strNow);
		annealingParams.pBestMatrix->WriteMatrixToFile(strFileName);

		strFileName.Format(_T("%s%s.dat"), strMatrixDirectory, CMatrixOperator::DEFAULT_FILENAME_BASE);
		annealingParams.strFilenameBestMatrix.Empty();
		annealingParams.strFilenameBestMatrix.Format(_T("%s"), strFileName);

		annealingParams.iNumMaxHillClimbingSteps = 32000;
		annealingParams.iNumStepsClimbed = 0;
		annealingParams.pListBoxOfResults = (CListBox*) GetDlgItem(IDC_BestMatrixHistory);
		annealingParams.pwndSearchStatus = GetDlgItem(IDC_SearchStatus);

		AfxBeginThread( AnnealMatrixOperator, &annealingParams);
	}
}

void CSearchMatrixDlg::OnBnClickedOk()
{
	CWnd* pOKButton = GetDlgItem(IDOK);
	CWnd* pCancelButton = GetDlgItem(IDCANCEL);

	ASSERT( NULL != pOKButton);
	ASSERT( NULL != pCancelButton);
	if (( NULL != pOKButton) &&
		( NULL != pCancelButton))
	{
		iMode ^= 0x01;
		switch (iMode)
		{
			case 0:
				pOKButton->SetWindowText("Start");
				pCancelButton->EnableWindow(true);
			break;

			case 1:
				pOKButton->SetWindowText("Stop");
				pCancelButton->EnableWindow(false);
				SpawnSearch();
			break;

			default:
				ASSERT(false);
				OnOK();
			break;
		}
	}
	else
	{
		iMode = 0;
		OnOK();
	}
}

UINT AnnealMatrixOperator( LPVOID pParam )
{
	ASSERT(NULL != pParam);
	CString strFileName;
	CString strNow;
	CString strValue;

	ANNEAL_PARAMS* pAnnealingParameters = (ANNEAL_PARAMS*) pParam;
	if (NULL != pAnnealingParameters)
	{
		ASSERT(NULL != pAnnealingParameters->piMode);
		ASSERT(NULL != pAnnealingParameters->pBestMatrix);
		ASSERT(NULL != pAnnealingParameters->pListBoxOfResults);
		ASSERT(NULL != pAnnealingParameters->pwndSearchStatus);

		strNow = CMatrixOperator::GetTimeNow();
		pAnnealingParameters->pListBoxOfResults->ResetContent();
		pAnnealingParameters->pBestMatrix->FormatWeights(strValue);
		strFileName.Format(_T("%s %s (%d)"), strNow, strValue, pAnnealingParameters->iNumStepsClimbed);
		pAnnealingParameters->pListBoxOfResults->AddString(strFileName);

		while (0 < *(pAnnealingParameters->piMode))
		{
			if (pAnnealingParameters->pBestMatrix->ClimbHill(pAnnealingParameters))
			{
				strNow = CMatrixOperator::GetTimeNow();
				strFileName.Format(_T("%s%s-Optimum-%s.dat"), strMatrixDirectory, CMatrixOperator::DEFAULT_FILENAME_BASE, strNow);
				pAnnealingParameters->pBestMatrix->WriteMatrixToFile(strFileName);

				pAnnealingParameters->pBestMatrix->FormatWeights(strValue);
				strFileName.Format(_T("%s %s (%d)"), strNow, strValue, pAnnealingParameters->iNumStepsClimbed);
				pAnnealingParameters->pListBoxOfResults->AddString(strFileName);

				pAnnealingParameters->pBestMatrix->RandomizeMatrix();

				pAnnealingParameters->pwndSearchStatus->SetWindowText("");
			}
		}
		pAnnealingParameters->pBestMatrix->WriteMatrixToFile(pAnnealingParameters->strFilenameBestMatrix);
	}

	return 0;
}
