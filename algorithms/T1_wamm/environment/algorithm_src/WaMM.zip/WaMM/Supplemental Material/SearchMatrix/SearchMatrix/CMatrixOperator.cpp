// CMatrixOperator.cpp : implementation file
//

#include "stdafx.h"
#include "CMatrixOperator.h"
#include "MersenneTwister.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

MTRand gc_rand;
bool CMatrixOperator::m_bFlatsAreInitialized = false;
CMatrixOperator CMatrixOperator::gc_matrixFlatOperatorsFFT_2D[m_gciNumFlatOperators];
CString const CMatrixOperator::DEFAULT_FILENAME_BASE = "BestMatrixOperator";

void CMatrixOperator::ResetMatrix()
{
	InitializeMatrix();
	InitializeNonMatrix();
}
CMatrixOperator::CMatrixOperator(const CMatrixOperator& orgMatrix)
{
	CopyIn(orgMatrix);
}
CMatrixOperator::CMatrixOperator()
{
	ResetMatrix();
}
CMatrixOperator::CMatrixOperator(const FFT_VAL iMaxtrix[CMatrixOperator::NUM_VALUES][CMatrixOperator::NUM_VALUES])
{
	memcpy(m_iMaxtrix, iMaxtrix, sizeof(m_iMaxtrix));
	InitializeNonMatrix();
}

CMatrixOperator::~CMatrixOperator()
{
}

void CMatrixOperator::InitializeNonMatrix()
{
	int i;

	m_bWeightDirty = true;

	for (i = 0; i < CMatrixOperator::m_gciNumMatrixWeights; ++i)
	{
		m_llMatrixWeight[i] = MAX_MATRIX_WEIGHT;
	}
}
void CMatrixOperator::InitializeMatrix()
{
	int i, j, k;
	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			k  = i+j;
			k %= CMatrixOperator::NUM_VALUES;
			m_iMaxtrix[i][j] = (FFT_VAL) k;
		}
	}
}

bool CMatrixOperator::InitializeFlatOperators(void)
{
	int iOperator;
	CString strOperatorNumber;
	CString strFileName;

	if (!CMatrixOperator::m_bFlatsAreInitialized)
	{
		gc_matrixFlatOperatorsFFT_2D[0].ResetMatrix();
		iOperator = 1;

		ASSERT( iOperator == m_gciNumFlatOperators);
		for (iOperator = 0; iOperator < CMatrixOperator::m_gciNumFlatOperators; ++iOperator)
		{
			gc_matrixFlatOperatorsFFT_2D[iOperator].FFT_2D();
			gc_matrixFlatOperatorsFFT_2D[iOperator] *= -1;
		}

		CMatrixOperator::m_bFlatsAreInitialized = true;
	}

	ASSERT(CMatrixOperator::m_bFlatsAreInitialized);
	return CMatrixOperator::m_bFlatsAreInitialized;
}

void CMatrixOperator::CopyIn(const CMatrixOperator& opRHS)
{
	int i;
	memcpy(m_iMaxtrix, opRHS.m_iMaxtrix, sizeof(m_iMaxtrix));

	m_bWeightDirty = opRHS.m_bWeightDirty;
	for(i = 0; i < CMatrixOperator::m_gciNumMatrixWeights; ++i)
	{
		m_llMatrixWeight[i] = opRHS.m_llMatrixWeight[i];
	}
}

bool CMatrixOperator::IsBijectiveOperator() const
{
	bool bIsBijective = true;
	int iRow, iCol, k;
	int iCount[CMatrixOperator::NUM_VALUES];

	// Test Bijection by row
	for(iRow=0; bIsBijective && (iRow < CMatrixOperator::NUM_VALUES); ++iRow)
	{
		memset(iCount, 0, sizeof(iCount));
		for(iCol=0; bIsBijective && (iCol < CMatrixOperator::NUM_VALUES); ++iCol)
		{
			k = m_iMaxtrix[iRow][iCol];
			++iCount[k];
		}
		for(k=0; bIsBijective && (k < CMatrixOperator::NUM_VALUES); ++k)
		{
			bIsBijective = (1 == iCount[k]);
		}
	}

	// Test Bijection by Column
	for(iCol=0; bIsBijective && (iCol < CMatrixOperator::NUM_VALUES); ++iCol)
	{
		memset(iCount, 0, sizeof(iCount));
		for(iRow=0; bIsBijective && (iRow < CMatrixOperator::NUM_VALUES); ++iRow)
		{
			k = m_iMaxtrix[iRow][iCol];
			++iCount[k];
		}
		for(k=0; bIsBijective && (k < CMatrixOperator::NUM_VALUES); ++k)
		{
			bIsBijective = (1 == iCount[k]);
		}
	}

	return bIsBijective;
}

int CMatrixOperator::Compare(CMatrixOperator& opRHS)
{
	int iCompareValue = 0;
	int i;
	MATRIX_WEIGHT llDiff;

	if (m_bWeightDirty)
	{
		WeighMatrix();
	}
	if (opRHS.m_bWeightDirty)
	{
		opRHS.WeighMatrix();
	}

	for(i = 0; (0 == iCompareValue) && (i < CMatrixOperator::m_gciNumMatrixWeights); ++i)
	{
		llDiff = m_llMatrixWeight[i] - opRHS.m_llMatrixWeight[i];
		if (llDiff < 0)
		{
			iCompareValue = -1;
		}
		else if (llDiff > 0)
		{
			iCompareValue = +1;
		}
	}

	return iCompareValue;
}

void CMatrixOperator::WeighMatrix()
{
	int i;
	MATRIX_WEIGHT iMax;
	MATRIX_WEIGHT iSoS;

	ASSERT(CMatrixOperator::IsBijectiveOperator());

	CMatrixOperator matrixTempMatrix;
	for(i = 0; i < CMatrixOperator::m_gciNumMatrixWeights; ++i)
	{
		m_llMatrixWeight[i] = CMatrixOperator::MIN_MATRIX_WEIGHT;
	}

	for(i = 0; i < CMatrixOperator::m_gciNumFlatOperators; ++i)
	{
		matrixTempMatrix = *this;
		matrixTempMatrix.FFT_2D();
		matrixTempMatrix *= CMatrixOperator::GetFlatOperator_FFT(i);
		matrixTempMatrix.InverseFFT_2D();

		iMax = matrixTempMatrix.Max();
		if (m_llMatrixWeight[1] < iMax)
		{
			m_llMatrixWeight[1] = iMax;
		}
		iSoS = matrixTempMatrix.MatrixSumOfSquares();
		if (m_llMatrixWeight[0] < iSoS)
		{
			m_llMatrixWeight[0] = iSoS;
		}

		matrixTempMatrix = *this;
		matrixTempMatrix.FFT_2D();
		matrixTempMatrix *= matrixTempMatrix;
		matrixTempMatrix.InverseFFT_2D();

		iMax = matrixTempMatrix.Max();
		if (m_llMatrixWeight[3] < iMax)
		{
			m_llMatrixWeight[3] = iMax;
		}
		iSoS = matrixTempMatrix.MatrixSumOfSquares();
		if (m_llMatrixWeight[2] < iSoS)
		{
			m_llMatrixWeight[2] = iSoS;
		}
	}

	m_bWeightDirty = false;
}

bool CMatrixOperator::operator == (CMatrixOperator& opRHS)
{
	return (0 == Compare(opRHS));
}

bool CMatrixOperator::operator != (CMatrixOperator& opRHS)
{
	return (0 != Compare(opRHS));
}

bool CMatrixOperator::operator <  (CMatrixOperator& opRHS)
{
	return (0 > Compare(opRHS));
}

bool CMatrixOperator::operator <= (CMatrixOperator& opRHS)
{
	return (0 >= Compare(opRHS));
}

bool CMatrixOperator::operator >  (CMatrixOperator& opRHS)
{
	return (0 < Compare(opRHS));
}

bool CMatrixOperator::operator >= (CMatrixOperator& opRHS)
{
	return (0 <= Compare(opRHS));
}

CMatrixOperator& CMatrixOperator::operator = (const CMatrixOperator& opRHS)
{
	CopyIn(opRHS);
	return *this;
}

CMatrixOperator& CMatrixOperator::operator *= (const CMatrixOperator& opRHS)
{
	int i, j;
	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			m_iMaxtrix[i][j] *= opRHS.m_iMaxtrix[i][j];
		}
	}
	return *this;
}
CMatrixOperator& CMatrixOperator::operator *= (int iScalar)
{
	int i, j;
	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			m_iMaxtrix[i][j] *= (FFT_VAL) iScalar;
		}
	}
	return *this;
}

CMatrixOperator& CMatrixOperator::operator += (const CMatrixOperator& opRHS)
{
	int i, j;
	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			m_iMaxtrix[i][j] += opRHS.m_iMaxtrix[i][j];
		}
	}
	return *this;
}
CMatrixOperator& CMatrixOperator::operator += (int iScalar)
{
	int i, j;
	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			m_iMaxtrix[i][j] += (FFT_VAL) iScalar;
		}
	}
	return *this;
}

CMatrixOperator& CMatrixOperator::operator -= (const CMatrixOperator& opRHS)
{
	int i, j;
	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			m_iMaxtrix[i][j] -= opRHS.m_iMaxtrix[i][j];
		}
	}
	return *this;
}
CMatrixOperator& CMatrixOperator::operator -= (int iScalar)
{
	int i, j;
	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			m_iMaxtrix[i][j] -= (FFT_VAL) iScalar;
		}
	}
	return *this;
}

MATRIX_WEIGHT CMatrixOperator::SumMatrix(bool bAbsolute) const
{
	MATRIX_WEIGHT wtMatrixWeight = CMatrixOperator::MAX_MATRIX_WEIGHT;
	FFT_VAL iTemp;
	int i, j;

	wtMatrixWeight = 0;
	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			iTemp = (bAbsolute && (0 > m_iMaxtrix[i][j])) ? -m_iMaxtrix[i][j] : m_iMaxtrix[i][j];
			wtMatrixWeight += iTemp;
		}
	}
	return wtMatrixWeight;
}

MATRIX_WEIGHT CMatrixOperator::MatrixSumOfSquares(void) const 
{
	MATRIX_WEIGHT wtSoS = 0;
	MATRIX_WEIGHT llTemp;
	int i, j;

	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			llTemp  = m_iMaxtrix[i][j];
			llTemp *= llTemp;
			wtSoS  += llTemp;
		}
	}

	return wtSoS;
}

MATRIX_WEIGHT CMatrixOperator::Min() const
{
	MATRIX_WEIGHT wtMin = MAX_MATRIX_WEIGHT;
	MATRIX_WEIGHT llTemp;
	int i, j;

	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			llTemp  = m_iMaxtrix[i][j];
			llTemp *= llTemp;
			if (llTemp < wtMin)
			{
				wtMin = llTemp;
			}
		}
	}

	return wtMin;
}

MATRIX_WEIGHT CMatrixOperator::Max() const
{
	MATRIX_WEIGHT wtMax = -MAX_MATRIX_WEIGHT;
	MATRIX_WEIGHT llTemp;
	int i, j;

	for(i=0; i < CMatrixOperator::NUM_VALUES; ++i)
	{
		for(j=0; j < CMatrixOperator::NUM_VALUES; ++j)
		{
			llTemp  = m_iMaxtrix[i][j];
			llTemp *= llTemp;
			if (llTemp > wtMax)
			{
				wtMax = llTemp;
			}
		}
	}

	return wtMax;
}

FFT_VAL CMatrixOperator::GetMatrixCell(int i, int j, bool bCircular) const
{
	FFT_VAL iRetval = -1;
	if (bCircular)
	{
		while (0 > i)
		{
			i += CMatrixOperator::NUM_VALUES;
		}
		while (CMatrixOperator::NUM_VALUES < i)
		{
			i -= CMatrixOperator::NUM_VALUES;
		}
		while (0 > j)
		{
			j += CMatrixOperator::NUM_VALUES;
		}
		while (CMatrixOperator::NUM_VALUES < j)
		{
			j -= CMatrixOperator::NUM_VALUES;
		}
	}

	ASSERT( 0 <= i);
	ASSERT( i  < CMatrixOperator::NUM_VALUES);
	ASSERT( 0 <= j);
	ASSERT( j  < CMatrixOperator::NUM_VALUES);
	if (( 0 <= i) &&
		( 0 <= j) &&
		( i  < CMatrixOperator::NUM_VALUES) &&
		( j  < CMatrixOperator::NUM_VALUES))
	{
		iRetval = m_iMaxtrix[i][j];
	}

	return iRetval;
}

FFT_VAL CMatrixOperator::SetMatrixCell(int i, int j, FFT_VAL iNewVal, bool bCircular)
{
	FFT_VAL iOldVal = -1;
	if (bCircular)
	{
		while (0 > i)
		{
			i += CMatrixOperator::NUM_VALUES;
		}
		while (CMatrixOperator::NUM_VALUES < i)
		{
			i -= CMatrixOperator::NUM_VALUES;
		}
		while (0 > j)
		{
			j += CMatrixOperator::NUM_VALUES;
		}
		while (CMatrixOperator::NUM_VALUES < j)
		{
			j -= CMatrixOperator::NUM_VALUES;
		}
	}

	ASSERT( 0 <= i);
	ASSERT( i  < CMatrixOperator::NUM_VALUES);
	ASSERT( 0 <= j);
	ASSERT( j  < CMatrixOperator::NUM_VALUES);
	if (( 0 <= i) &&
		( 0 <= j) &&
		( i  < CMatrixOperator::NUM_VALUES) &&
		( j  < CMatrixOperator::NUM_VALUES))
	{
		m_iMaxtrix[i][j] = iNewVal;
		m_bWeightDirty = true;
	}
	return iOldVal;
}


CMatrixOperator& CMatrixOperator::GetFlatOperator_FFT(int iOperatorNumber)
{
	ASSERT(0 <= iOperatorNumber);
	ASSERT(iOperatorNumber < CMatrixOperator::m_gciNumFlatOperators);
	if ((0 > iOperatorNumber) ||
		(iOperatorNumber >= CMatrixOperator::m_gciNumFlatOperators))
	{
		iOperatorNumber = 0;
	}

	// initialze flat operators if not already done
	InitializeFlatOperators();

	return gc_matrixFlatOperatorsFFT_2D[iOperatorNumber];
}

void CMatrixOperator::InPlaceFFT(FFT_VAL iVector[NUM_VALUES], bool bNormalize)
{
	FFT_VAL A, B;
	int x, y;
	int iBlockSize;
	int iOffsetSize;
	int iBlockBase;
	int i;

	for (iBlockSize = 2; iBlockSize <= NUM_VALUES; iBlockSize <<= 1)
	{
		iOffsetSize = iBlockSize/2;
		for( iBlockBase = 0; iBlockBase < NUM_VALUES; iBlockBase += iBlockSize)
		{
			for( i = 0; i < iOffsetSize; ++i)
			{
				x = iBlockBase + i;
				y = x+iOffsetSize;
				A = iVector[x]+iVector[y];
				B = iVector[x]-iVector[y];
				iVector[x] = A;
				iVector[y] = B;
			}
		}
	}

	// normalize values
	if (bNormalize)
	{
		for( i = 0; i < CMatrixOperator::NUM_VALUES; ++i)
		{
			iVector[i] /= (FFT_VAL) CMatrixOperator::NORMALIZATION_CONST;
		}
	}

}

CMatrixOperator& CMatrixOperator::FFT_2D()
{
	return FFT_2D(*this);
}

CMatrixOperator& CMatrixOperator::FFT_2D(const CMatrixOperator& opRHS)
{
	FFT_VAL iVector[NUM_VALUES];
	int iRow, iCol;

	*this = opRHS;

	// FFT by Row
	for (iRow = 0; iRow < NUM_VALUES; ++iRow)
	{
		for (iCol = 0; iCol < NUM_VALUES; ++iCol)
		{
			iVector[iCol] = m_iMaxtrix[iRow][iCol];
		}
		InPlaceFFT(iVector);
		for (iCol = 0; iCol < NUM_VALUES; ++iCol)
		{
			m_iMaxtrix[iRow][iCol] = iVector[iCol];
		}
	}

	// FFT by Column
	for (iCol = 0; iCol < NUM_VALUES; ++iCol)
	{
		for (iRow = 0; iRow < NUM_VALUES; ++iRow)
		{
			iVector[iRow] = m_iMaxtrix[iRow][iCol];
		}
		InPlaceFFT(iVector);
		for (iRow = 0; iRow < NUM_VALUES; ++iRow)
		{
			m_iMaxtrix[iRow][iCol] = iVector[iRow];
		}
	}
	m_iMaxtrix[0][0] = 0;

	return *this;
}

CMatrixOperator& CMatrixOperator::InverseFFT_2D()
{
	return InverseFFT_2D(*this);
}

CMatrixOperator& CMatrixOperator::InverseFFT_2D(const CMatrixOperator& opRHS)
{
	FFT_VAL iVector[NUM_VALUES];
	int iRow, iCol;

	*this = opRHS;

// FFT by Column
	for (iCol = 0; iCol < NUM_VALUES; ++iCol)
	{
		for (iRow = 0; iRow < NUM_VALUES; ++iRow)
		{
			iVector[iRow] = m_iMaxtrix[iRow][iCol];
		}
		InPlaceFFT(iVector);
		for (iRow = 0; iRow < NUM_VALUES; ++iRow)
		{
			m_iMaxtrix[iRow][iCol] = iVector[iRow];
		}
	}

	// FFT by Row
	for (iRow = 0; iRow < NUM_VALUES; ++iRow)
	{
		for (iCol = 0; iCol < NUM_VALUES; ++iCol)
		{
			iVector[iCol] = m_iMaxtrix[iRow][iCol];
		}
		InPlaceFFT(iVector);
		for (iCol = 0; iCol < NUM_VALUES; ++iCol)
		{
			m_iMaxtrix[iRow][iCol] = iVector[iCol];
		}
	}

	return *this;
}

bool CMatrixOperator::RandomizeMatrix()
{
	bool bSuccess = true;
	int iNumRemain, iSelected;

	iNumRemain = CMatrixOperator::NUM_VALUES;
	while (bSuccess && ( 1 < iNumRemain))
	{
		iSelected = gc_rand.randInt(iNumRemain);
		--iNumRemain;
		if (iSelected != iNumRemain)
		{
			bSuccess = SwapRows(iSelected, iNumRemain);
		}
	}

	iNumRemain = CMatrixOperator::NUM_VALUES;
	while (bSuccess && ( 1 < iNumRemain))
	{
		iSelected = gc_rand.randInt(iNumRemain);
		--iNumRemain;
		if (iSelected != iNumRemain)
		{
			bSuccess = SwapColumns(iSelected, iNumRemain);
		}
	}

	return bSuccess;
}
bool CMatrixOperator::SwapRows(int iRow1, int iRow2)
{
	bool bSuccess = false;
	int i;
	FFT_VAL iTempVal;

	ASSERT(0 <= iRow1);
	ASSERT(0 <= iRow2);
	ASSERT(iRow1 < CMatrixOperator::NUM_VALUES);
	ASSERT(iRow2 < CMatrixOperator::NUM_VALUES);
	if ((0 <= iRow1) &&
		(0 <= iRow2) &&
		(iRow1 < CMatrixOperator::NUM_VALUES) &&
		(iRow2 < CMatrixOperator::NUM_VALUES))
	{
		bSuccess = true;
		if (iRow1 != iRow2)
		{
			for (i = 0; i < CMatrixOperator::NUM_VALUES; ++i)
			{
				iTempVal = m_iMaxtrix[iRow1][i];
				m_iMaxtrix[iRow1][i] = m_iMaxtrix[iRow2][i];
				m_iMaxtrix[iRow2][i] = iTempVal;
			}
		}
	}
	m_bWeightDirty = true;

	return bSuccess;
}
bool CMatrixOperator::SwapColumns(int iCol1, int iCol2)
{
	bool bSuccess = false;
	int i;
	FFT_VAL iTempVal;

	ASSERT(0 <= iCol1);
	ASSERT(0 <= iCol2);
	ASSERT(iCol1 < CMatrixOperator::NUM_VALUES);
	ASSERT(iCol2 < CMatrixOperator::NUM_VALUES);
	if ((0 <= iCol1) &&
		(0 <= iCol2) &&
		(iCol1 < CMatrixOperator::NUM_VALUES) &&
		(iCol2 < CMatrixOperator::NUM_VALUES))
	{
		bSuccess = true;
		if (iCol1 != iCol2)
		{
			for (i = 0; i < CMatrixOperator::NUM_VALUES; ++i)
			{
				iTempVal = m_iMaxtrix[i][iCol1];
				m_iMaxtrix[i][iCol1] = m_iMaxtrix[i][iCol2];
				m_iMaxtrix[i][iCol2] = iTempVal;
			}
		}
	}
	m_bWeightDirty = true;

	return bSuccess;
}
CString CMatrixOperator::GetTimeNow(void)
{
	CTime timeNow = CTime::GetCurrentTime();
	return timeNow.Format(_T("%Y%m%d-%H%M%S"));
}
void CMatrixOperator::FormatWeights(CString& strWeight) const
{
	CString strValue;
	int i;

	strWeight.Empty();

	strWeight.Append(_T("("));
	for( i = 0; i < CMatrixOperator::m_gciNumMatrixWeights; ++i)
	{
		if ( 0 < i)
		{
			strWeight.Append(_T(", "));
		}
		if (m_bWeightDirty)
		{
			strValue.Format(_T("?? ?? ?? ??"), m_llMatrixWeight[i]);
		}
		else
		{
			strValue.Format(_T("%16.16I64X"), m_llMatrixWeight[i]);
		}
		strWeight.Append(strValue);
	}
	strWeight.Append(_T(")"));
}
bool CMatrixOperator::WriteMatrixToFile(CString strFileName) const
{
	bool bSuccess = false;
	int i, j;
	FILE *OutFile;
	CString strValue;
	CString strOutputLine;

	fopen_s(&OutFile, strFileName, "wb");
	if (NULL != OutFile)
	{
		bSuccess = true;
		for( i = 0; i < CMatrixOperator::NUM_VALUES; ++i)
		{
			strOutputLine.Empty();
			for( j = 0; j < CMatrixOperator::NUM_VALUES; ++j)
			{
				strValue.Format(_T("%3d\t"), GetMatrixCell(i,j));
				strOutputLine.Append(strValue);
			}
			strOutputLine.Append(_T("\n"));
			fprintf(OutFile, "%s", strOutputLine);
		}
		strOutputLine.Empty();
		strOutputLine.Append(_T("\n"));

		FormatWeights(strValue);
		strOutputLine.Append(strValue);

		strOutputLine.Append(_T("\n"));

		fprintf(OutFile, "%s", strOutputLine);

		fclose(OutFile);
	}
	return bSuccess;
}

bool CMatrixOperator::ReadMatrixFromFile(CString strFileName)
{
	bool bSuccess = false;
	FILE *InFile;
	int iRecordLen = -1;
	int iFileLocation;
	int iSeekError;
	int i,j;
	const int iBufferSize = 8188;
	char chBuffer[iBufferSize+4];
	char *pchToken;
	FFT_VAL iCellVal;

	m_bWeightDirty = true;

	fopen_s(&InFile, strFileName, "rb");
	if (NULL != InFile)
	{
		// find Record Length
		memset(chBuffer, 0, sizeof(chBuffer));
		if (1 == fread(chBuffer, iBufferSize, 1, InFile))
		{
			pchToken = strtok(chBuffer, "\n");
			if ((NULL != pchToken) &&
				(0 < strlen(pchToken)))
			{
				iRecordLen = strlen(pchToken)+1;
			}
		}

		if (0 < iRecordLen)
		{
			bSuccess = true;
			for( i = 0; bSuccess && (i < CMatrixOperator::NUM_VALUES); ++i)
			{
				bSuccess = false;
				iFileLocation = i*iRecordLen;
				iSeekError = fseek(InFile, iFileLocation, SEEK_SET);
				if (0 == iSeekError)
				{
					memset(chBuffer, 0, sizeof(chBuffer));
					if (1 == fread(chBuffer, iRecordLen, 1, InFile))
					{
						bSuccess = true;
						for( j = 0; bSuccess && (j < CMatrixOperator::NUM_VALUES); ++j)
						{
							bSuccess = false;
							if (0 < j)
							{
								pchToken = strtok(NULL, "\t");
							}
							else
							{
								pchToken = strtok(chBuffer, "\t");
							}
							if ((NULL != pchToken) &&
								(0 < strlen(pchToken)))
							{
								if (1 == sscanf(pchToken, "%d", &iCellVal))
								{
									bSuccess = true;
									SetMatrixCell(i, j, iCellVal);
								}
							}
						}
					}
				}
			}
		}
		fclose(InFile);
	}

	if (!IsBijectiveOperator())
	{
		bSuccess = false;
	}

	if (!bSuccess)
	{
		ResetMatrix();
	}

	ASSERT(IsBijectiveOperator());

	return bSuccess;
}

void CMatrixOperator::RandomizeVector(int iVector[], int iNumElements)
{
	int iSelected;
	int iTemp;
	while (1 < iNumElements)
	{
		iSelected = gc_rand.randInt(iNumElements);
		--iNumElements;
		if (iSelected != iNumElements)
		{
			iTemp = iVector[iSelected];
			iVector[iSelected] = iVector[iNumElements];
			iVector[iNumElements] = iTemp;
		}
	}
}

bool CMatrixOperator::ClimbHill(AnnealingParameters* pParamBlock)
{
	bool bImproved = false;
	bool bOptimum = false;
	CMatrixOperator matrixCurrent;
	int iIndex[CMatrixOperator::NUM_VALUES];
	int i, j, n, m;
	CString strNow;
	CString strValue;
	CString strStatus;

	ASSERT(NULL != pParamBlock);
	if (NULL != pParamBlock)
	{
		for(i = 0; i < CMatrixOperator::NUM_VALUES; ++i)
		{
			iIndex[i] = i;
		}

		pParamBlock->iNumStepsClimbed = 0;
		i = j = 0;
		bImproved = true;
		{
			strNow = this->GetTimeNow();
			this->FormatWeights(strValue);
			strStatus.Format(_T("Step %5d of %5d (%3d,%3d) at %s\r\n%s"), pParamBlock->iNumStepsClimbed
									,pParamBlock->iNumMaxHillClimbingSteps
									,i,j
									,strNow
									,strValue);
			pParamBlock->pwndSearchStatus->SetWindowText(strStatus);
		}
		while(bImproved &&
				(0 < *(pParamBlock->piMode)) &&
				(pParamBlock->iNumStepsClimbed < pParamBlock->iNumMaxHillClimbingSteps))
		{
			bImproved = false;
			++(pParamBlock->iNumStepsClimbed);
			RandomizeVector(iIndex, CMatrixOperator::NUM_VALUES);

			for(i = 0; !bImproved && (0 < *(pParamBlock->piMode)) && (i < CMatrixOperator::NUM_VALUES); ++i)
			{
				n = iIndex[i];
				for(j = 0; !bImproved && (0 < *(pParamBlock->piMode)) && (j < CMatrixOperator::NUM_VALUES); ++j)
				{
					m = iIndex[j];
					if (n < m)
					{
						// Improve by Swaping Rows
						matrixCurrent = *this;
						matrixCurrent.SwapRows(n,m);
						if (matrixCurrent < *this)
						{
							*this = matrixCurrent;
							bImproved = true;
						}

						// Improve by Swaping Columns
						matrixCurrent = *this;
						matrixCurrent.SwapColumns(n,m);
						if (matrixCurrent < *this)
						{
							*this = matrixCurrent;
							bImproved = true;
						}
					}
				}
			}

			if (bImproved)
			{
				WriteMatrixToFile(pParamBlock->strFilenameBestMatrix);
				strNow = this->GetTimeNow();
				this->FormatWeights(strValue);
				strStatus.Format(_T("Step %5d of %5d (%3d,%3d) at %s\r\n%s"), pParamBlock->iNumStepsClimbed
										,pParamBlock->iNumMaxHillClimbingSteps
										,i,j
										,strNow
										,strValue);
				pParamBlock->pwndSearchStatus->SetWindowText(strStatus);
			}
		}
	}

	// check to see if optimum.
	bOptimum = (!bImproved &&
				(0 < *(pParamBlock->piMode)) &&
				(pParamBlock->iNumStepsClimbed < pParamBlock->iNumMaxHillClimbingSteps));

	return bOptimum;
}
