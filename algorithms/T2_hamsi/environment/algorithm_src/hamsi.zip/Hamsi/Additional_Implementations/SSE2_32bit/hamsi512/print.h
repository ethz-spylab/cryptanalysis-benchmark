#ifndef __PRINT_H__
#define __PRINT_H__

#include <stdio.h>

#define print_bytes(x, n, s) _print_bytes(x, n, s)
#define print_word(x, s) _print_word(x, s)
#define print_state(s) _print_state(s0, s1, s2, s3, s4, s5, s6, s7, s)
#define print_cv(s) _print_cv(c0, c1, c2, c3, s)

void _print_bytes(const uint8_t* x, int n, const char* s)
{
  int i;

  printf("%8s:", s);

  for (i = 0; i < n; ++i)
    {
      if ((i > 0) && ((i % 16) == 0))
        printf("\n%8s ", "");

      printf(" %02X", (int)(x[i]));
    }

  printf("\n\n");
}

void _print_word(__m128i x, const char* s)
{
  uint32_t w[4] __attribute__ ((aligned (32)));

  _mm_store_si128((__m128i*)w, x);
  printf("%8s: %08X %08X %08X %08X\n", s, w[0], w[1], w[2], w[3]);
}

void _print_state(
  __m128i s0, __m128i s1, __m128i s2, __m128i s3, 
  __m128i s4, __m128i s5, __m128i s6, __m128i s7, const char* s)
{
  int i;
  uint32_t x[2][4][4];

  _mm_store_si128((__m128i*)(x[0][0]), s0);
  _mm_store_si128((__m128i*)(x[1][0]), s1);
  _mm_store_si128((__m128i*)(x[0][1]), s2);
  _mm_store_si128((__m128i*)(x[1][1]), s3);
  _mm_store_si128((__m128i*)(x[0][2]), s4);
  _mm_store_si128((__m128i*)(x[1][2]), s5);
  _mm_store_si128((__m128i*)(x[0][3]), s6);
  _mm_store_si128((__m128i*)(x[1][3]), s7);

  printf("--- %s ---\n", s);

  for (i = 0; i < 4; ++i)
    printf("  s%d: %08X %08X %08X %08X | %08X %08X %08X %08X\n", i,
	   x[0][i][0], x[0][i][1], x[0][i][2], x[0][i][3], 
	   x[1][i][0], x[1][i][1], x[1][i][2], x[1][i][3]);

  printf("\n");
}

void _print_cv(__m128i c0, __m128i c1, __m128i c2, __m128i c3, const char* s)
{
  printf("--- %s ---\n", s);

  print_word(c0, "c0");
  print_word(c1, "c1");
  print_word(c2, "c2");
  print_word(c3, "c3");

  printf("\n");
}

#endif
