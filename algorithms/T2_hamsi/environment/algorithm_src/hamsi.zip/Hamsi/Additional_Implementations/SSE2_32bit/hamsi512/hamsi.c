#include <emmintrin.h>

#include "hamsi.h"
#include "hamsi-tables.h"

/* -------------------------------------------------------------------------- */

#ifdef PRINT_INTERNALS

#include "print.h"

#else

#define print_bytes(x, n, s)
#define print_word(x, s)
#define print_state(s)
#define print_cv(s)

#endif

/* -------------------------------------------------------------------------- */

#define shl(x, c) do { x = _mm_slli_epi32(x, c); } while (0)
#define shr(x, c) do { x = _mm_srli_epi32(x, c); } while (0)

#define rol(x, c) do {                                   \
    t = x; shl(x, c); shr(t, 32 - c); x |= t;            \
  } while (0)

#define ONES _mm_set1_epi32(-1)

#define sub(s0, s1, s2, s3) do {                         \
    __m128i t;                                           \
                                                         \
    t   = s0; s0 &= s2;                                  \
    s0 ^= s3; s2 ^= s1;                                  \
    s2 ^= s0; s3 |= t;                                   \
    s3 ^= s1; t  ^= s2;                                  \
    s1  = s3; s3 |= t;                                   \
    s3 ^= s0; s0 &= s1;                                  \
    t  ^= s0; s1 ^= s3;                                  \
    s1 ^=  t; t  ^= ONES;                                \
                                                         \
    s0 = s2;                                             \
    s2 = s1;                                             \
    s1 = s3;                                             \
    s3 = t;                                              \
  } while (0)

#define mix(s0, s1, s2, s3) do {                         \
    __m128i t;                                           \
                                                         \
    rol(s0, 13);                                         \
    rol(s2, 3);                                          \
                                                         \
    s1 ^= s0; s1 ^= s2;                                  \
    t   = s0; shl(t, 3);                                 \
    s3 ^= s2; s3 ^= t;                                   \
                                                         \
    rol(s1, 1);                                          \
    rol(s3, 7);                                          \
                                                         \
    s0 ^= s1; s0 ^= s3;                                  \
    t   = s1; shl(t, 7);                                 \
    s2 ^= s3; s2 ^= t;                                   \
                                                         \
    rol(s0,  5);                                         \
    rol(s2, 22);                                         \
  } while (0)

#define shuffle(x, w0, w1, w2, w3)		         \
  x = _mm_shuffle_epi32(x, _MM_SHUFFLE(w3, w2, w1, w0))

#define shiftrows(s0, s1, s2, s3) do {                   \
    shuffle(s1, 1, 2, 3, 0);				 \
    shuffle(s2, 2, 3, 0, 1);				 \
    shuffle(s3, 3, 0, 1, 2);				 \
  } while (0)

#define swortfihs(s0, s1, s2, s3) do {                   \
    shuffle(s1, 3, 0, 1, 2);				 \
    shuffle(s2, 2, 3, 0, 1);				 \
    shuffle(s3, 1, 2, 3, 0);				 \
  } while (0)

#define t0(m, i) _mm_load_si128((__m128i*)(t512[i][(m)[i]] +  0))
#define t1(m, i) _mm_load_si128((__m128i*)(t512[i][(m)[i]] +  4))
#define t2(m, i) _mm_load_si128((__m128i*)(t512[i][(m)[i]] +  8))
#define t3(m, i) _mm_load_si128((__m128i*)(t512[i][(m)[i]] + 12))

#define m0(m) (						 \
  t0(m, 0) ^ t0(m, 1) ^ t0(m, 2) ^ t0(m, 3) ^            \
  t0(m, 4) ^ t0(m, 5) ^ t0(m, 6) ^ t0(m, 7))
#define m1(m) (						 \
  t1(m, 0) ^ t1(m, 1) ^ t1(m, 2) ^ t1(m, 3) ^            \
  t1(m, 4) ^ t1(m, 5) ^ t1(m, 6) ^ t1(m, 7))
#define m2(m) (						 \
  t2(m, 0) ^ t2(m, 1) ^ t2(m, 2) ^ t2(m, 3) ^            \
  t2(m, 4) ^ t2(m, 5) ^ t2(m, 6) ^ t2(m, 7))
#define m3(m) (						 \
  t3(m, 0) ^ t3(m, 1) ^ t3(m, 2) ^ t3(m, 3) ^            \
  t3(m, 4) ^ t3(m, 5) ^ t3(m, 6) ^ t3(m, 7))

#define addconst(s0, s1, s2, s3, j, k) do {		     \
    s0 ^= _mm_load_si128((__m128i*)(alpha[j][0] + k * 4));   \
    s1 ^= _mm_load_si128((__m128i*)(alpha[j][1] + k * 4));   \
    s2 ^= _mm_load_si128((__m128i*)(alpha[j][2] + k * 4));   \
    s3 ^= _mm_load_si128((__m128i*)(alpha[j][3] + k * 4));   \
  } while (0)

#define addcount(s0, i) do {				 \
    s0 ^= _mm_set_epi32(0, 0, i, 0);			 \
  } while (0)

#define reorder(a, b) do {                               \
    const __m128i s = _mm_unpacklo_epi64(a, b);          \
    const __m128i t = _mm_unpackhi_epi64(a, b);          \
    a = s;                                               \
    b = t;                                               \
  } while(0)

#define swap_words(a, b, w0, w1, w2, w3) do {				\
    const __m128i t = (a ^ b) & _mm_set_epi32(-w3, -w2, -w1, -w0);	\
    a ^= t;								\
    b ^= t;								\
  } while (0)

#define round(i, j) do {				 \
    addconst(s0, s2, s4, s6, j, 0);			 \
    addconst(s1, s3, s5, s7, j, 1);			 \
    addcount(s0, i);					 \
    print_state("after addconst");			 \
    							 \
    sub(s0, s2, s4, s6);				 \
    sub(s1, s3, s5, s7);				 \
    print_state("after sub");				 \
							 \
    shiftrows(s0, s2, s4, s6);				 \
    shiftrows(s1, s3, s5, s7);				 \
    swap_words(s2, s3, 0, 0, 0, 1);			 \
    swap_words(s4, s5, 0, 0, 1, 1);			 \
    swap_words(s6, s7, 0, 1, 1, 1);			 \
    print_state("after shiftrows");			 \
							 \
    mix(s0, s2, s4, s6);                                 \
    mix(s1, s3, s5, s7);                                 \
    print_state("after mix (part 1)");			 \
							 \
    swap_words(s2, s3, 0, 0, 0, 1);			 \
    swap_words(s4, s5, 0, 0, 1, 1);			 \
    swap_words(s6, s7, 0, 1, 1, 1);			 \
    swortfihs(s0, s2, s4, s6);				 \
    swortfihs(s1, s3, s5, s7);				 \
    print_state("after swortfihs");			 \
    							 \
    swap_words(s0, s2, 0, 1, 0, 1);			 \
    swap_words(s4, s6, 0, 1, 1, 0);			 \
    reorder(s0, s4);					 \
    shuffle(s4, 0, 1, 3, 2);				 \
    swap_words(s1, s3, 1, 0, 1, 0);			 \
    swap_words(s5, s7, 1, 0, 0, 1);			 \
    reorder(s1, s5);					 \
    shuffle(s1, 1, 0, 3, 2);				 \
    shuffle(s5, 1, 0, 2, 3);				 \
    print_state("after shuffling");			 \
    							 \
    mix(s0, s4, s1, s5);                                 \
    print_state("after mix (part 2)");			 \
    							 \
    shuffle(s5, 1, 0, 2, 3);				 \
    shuffle(s1, 1, 0, 3, 2);				 \
    reorder(s1, s5);					 \
    swap_words(s5, s7, 1, 0, 0, 1);			 \
    swap_words(s1, s3, 1, 0, 1, 0);			 \
    shuffle(s4, 0, 1, 3, 2);				 \
    reorder(s0, s4);					 \
    swap_words(s4, s6, 0, 1, 1, 0);			 \
    swap_words(s0, s2, 0, 1, 0, 1);			 \
    print_state("after reshuffling");			 \
  } while (0)

#define plain_round(i) round(i, 0)
#define final_round(i) round(i, 1)

#define load_cv(cv) do {                                 \
    c0 = _mm_load_si128((__m128i*)(cv +  0));	         \
    c1 = _mm_load_si128((__m128i*)(cv +  4));		 \
    c2 = _mm_load_si128((__m128i*)(cv +  8));		 \
    c3 = _mm_load_si128((__m128i*)(cv + 12));	         \
  } while (0)

#define plain_iteration(m) do {                          \
    __m128i s0, s1, s2, s3, s4, s5, s6, s7;		 \
                                                         \
    print_cv("input");					 \
    print_bytes(m, 8, "m");                              \
                                                         \
    s0 = m0(m);						 \
    s1 = c0;						 \
    s2 = c1;						 \
    s3 = m1(m);						 \
    s4 = m2(m);						 \
    s5 = c2;						 \
    s6 = c3;						 \
    s7 = m3(m);						 \
							 \
    reorder(s0, s1);                                     \
    reorder(s2, s3);                                     \
    reorder(s4, s5);                                     \
    reorder(s6, s7);                                     \
							 \
    print_state("after concat");			 \
							 \
    plain_round(0);					 \
    plain_round(1);					 \
    plain_round(2);					 \
    plain_round(3);					 \
    plain_round(4);					 \
    plain_round(5);					 \
                                                         \
    c0 ^= s0;						 \
    c1 ^= s1;						 \
    c2 ^= s4;						 \
    c3 ^= s5;						 \
                                                         \
    print_cv("output");					 \
  } while (0)

#define final_iteration(m) do {                          \
    __m128i s0, s1, s2, s3, s4, s5, s6, s7;		 \
                                                         \
    print_cv("input");					 \
    print_bytes(m, 8, "m");                              \
                                                         \
    s0 = m0(m);						 \
    s1 = c0;						 \
    s2 = c1;						 \
    s3 = m1(m);						 \
    s4 = m2(m);						 \
    s5 = c2;						 \
    s6 = c3;						 \
    s7 = m3(m);						 \
							 \
    reorder(s0, s1);                                     \
    reorder(s2, s3);                                     \
    reorder(s4, s5);                                     \
    reorder(s6, s7);                                     \
							 \
    print_state("after concat");			 \
							 \
    final_round(0);					 \
    final_round(1);					 \
    final_round(2);					 \
    final_round(3);					 \
    final_round(4);					 \
    final_round(5);					 \
    final_round(6);					 \
    final_round(7);					 \
    final_round(8);					 \
    final_round(9);					 \
    final_round(10);					 \
    final_round(11);					 \
                                                         \
    c0 ^= s0;						 \
    c1 ^= s1;						 \
    c2 ^= s4;						 \
    c3 ^= s5;						 \
                                                         \
    print_cv("output");					 \
  } while (0)   

#define save_cv(cv) do {				 \
    _mm_store_si128((__m128i*)(cv +  0), c0);            \
    _mm_store_si128((__m128i*)(cv +  4), c1);            \
    _mm_store_si128((__m128i*)(cv +  8), c2);            \
    _mm_store_si128((__m128i*)(cv + 12), c3);            \
  } while (0)  

/* -------------------------------------------------------------------------- */

HashReturn Init
  (hashState* const state, const int hashbitlen)
{
  __m128i c0, c1, c2, c3;

  if (hashbitlen != 512)
    return BAD_HASHBITLEN;

  state->databitlen = 0;
  state->hashbitlen = 512;

  load_cv(iv512);
  save_cv(state->cv);

  return SUCCESS;
}

/* -------------------------------------------------------------------------- */

HashReturn Update
  (hashState* const state, const BitSequence* data, DataLength databitlen)
{
  int i;

  const int bufferbytes = (state->databitlen % 64) / 8;
  state->databitlen += databitlen;

  if (8 * bufferbytes + databitlen < 64)
    for (i = 0; i < (databitlen + 7) / 8; ++i)
      state->buffer[bufferbytes + i] = data[i];
  else
    {    
      __m128i c0, c1, c2, c3;
 
      load_cv(state->cv);

      if (bufferbytes > 0)
        {
          const int bytes = 8 - bufferbytes;

          for (i = 0; i < bytes; ++i)
            state->buffer[bufferbytes + i] = data[i];

          plain_iteration(state->buffer);
          data += bytes;
          databitlen -= 8 * bytes;
        }

      while (databitlen >= 64) 
        {
          plain_iteration(data);
          data += 8;
          databitlen -= 64;
        }

      save_cv(state->cv);

      for (i = 0; i < (databitlen + 7) / 8; ++i)
        state->buffer[i] = data[i];
    }

  return SUCCESS;       
}

/* -------------------------------------------------------------------------- */

HashReturn Final
  (hashState* const state, BitSequence* const hashval)
{
  const int bufferbytes = (state->databitlen % 64) / 8;
  const int bits = state->databitlen % 8;

  __m128i c0, c1, c2, c3;
  uint8_t length[8];

  int i;

  state->buffer[bufferbytes] &= 0xFF << (8 - bits);
  state->buffer[bufferbytes] |= 1 << (7 - bits);

  for (i = bufferbytes + 1; i < 8; ++i)
    state->buffer[i] = 0;

  for (i = 0; i < 8; ++i)
    length[i] = (state->databitlen >> (8 * (7 - i))) & 0xFF;

  load_cv(state->cv);

  plain_iteration(state->buffer);
  final_iteration(length);

  save_cv(state->cv);

  for (i = 0; i < 16; ++i)
    {
      const uint32_t t = state->cv[i];

      hashval[i * 4 + 0] = (t >> 24) & 0xFF;
      hashval[i * 4 + 1] = (t >> 16) & 0xFF;
      hashval[i * 4 + 2] = (t >>  8) & 0xFF;
      hashval[i * 4 + 3] = (t >>  0) & 0xFF;
    }

  return SUCCESS;
}

/* -------------------------------------------------------------------------- */

HashReturn Hash
  (int hashbitlen, const BitSequence* data, DataLength databitlen,
   BitSequence *hashval)
{
    hashState state;
    HashReturn ret = Init(&state, hashbitlen);

    if (ret == SUCCESS)
      {
        Update(&state, data, databitlen);
        Final(&state, hashval);
      }

    return ret;
}

/* -------------------------------------------------------------------------- */

#ifdef PRINT_INTERNALS

int main()
{
  uint8_t data[8] = {0x85, 0x69, 0xDF, 0x97, 0x1E, 0x67, 0x4E, 0x00};
  uint8_t hashval[64];

  Hash(512, data, 57, hashval);

  print_bytes(hashval, 64, "hash");

  return 0;
}

#endif

/* -------------------------------------------------------------------------- */
