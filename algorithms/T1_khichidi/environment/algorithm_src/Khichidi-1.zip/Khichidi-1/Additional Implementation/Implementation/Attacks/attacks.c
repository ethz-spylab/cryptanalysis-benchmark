#include <stdio.h>
#include <string.h>

#include "khichidi.h"
typedef enum { KAT_SUCCESS = 0, KAT_FILE_OPEN_ERROR = 1, KAT_HEADER_ERROR = 2, KAT_DATA_ERROR = 3, KAT_HASH_ERROR = 4 } STATUS_CODES;


int main ()
{
        int             i, ret_val,  bitlens[4] = { 224, 256, 384, 512 };

        for ( i=0; i<4; i++ ) {
                if ( (ret_val = padding(bitlens[i])) != KAT_SUCCESS )
                        return ret_val;
                if ( (ret_val = hearding(bitlens[i])) != KAT_SUCCESS )
                        return ret_val;
                if ( (ret_val = differential(bitlens[i])) != KAT_SUCCESS )
                        return ret_val;
                if ( (ret_val = message_expansion(bitlens[i])) != KAT_SUCCESS )
                        return ret_val;
        }
}

int padding(int hash_length)
{
        FILE            *fp_in, *fp_out;

	char padding_data[2]="0";

	char            fn[32];
	char hex[129] = "";

	// hash
	BitSequence result[64];
	hashState state;

        sprintf(fn, "padding_attack_%d.txt", hash_length);
        if ( (fp_out = fopen(fn, "w")) == NULL ) {
                printf("Couldn't open <%s> for write\n", fn);
                return KAT_FILE_OPEN_ERROR;
        }

	fprintf(fp_out,"/*\n");
	fprintf(fp_out,"* Algorithm Name - Khichidi-1\n");
	fprintf(fp_out,"* Test Name - Analysis of Attacks \n");
	fprintf(fp_out,"* Description of Test - Analysis of Padding attack \n");
	fprintf(fp_out,"* Message Digest being tested - Message digest length %d bits\n",hash_length);
	fprintf(fp_out,"*/\n");
	fprintf(fp_out,"\n\n");


	fprintf(fp_out,"Len = %d\n",6);
	fprintf(fp_out,"Msg = %s\n",padding_data);

	Init(&state, hash_length);
	Update(&state, padding_data,6);
	Final(&state, result);
	hexify(result, hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif
	fprintf(fp_out,"MD = %s\n",hex);

	fprintf(fp_out,"\n\n");

	fprintf(fp_out,"Len = %d\n",7);
	fprintf(fp_out,"Msg = %s\n",padding_data);

	Init(&state, hash_length);
	Update(&state, padding_data,7);
	Final(&state, result);
	hexify(result,hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif

	fprintf(fp_out,"MD = %s\n",hex);

	return KAT_SUCCESS;

}


int hearding(int hash_length)
{
        FILE            *fp_in, *fp_out;

	char hearding_data[2] ="0";
	char hearding_data_1[2] ="1";

	char            fn[32];
	char hex[129] = "";

	// hash
	BitSequence result[64];
	hashState state;

        sprintf(fn, "hearding_attack_%d.txt", hash_length);
        if ( (fp_out = fopen(fn, "w")) == NULL ) {
                printf("Couldn't open <%s> for write\n", fn);
                return KAT_FILE_OPEN_ERROR;
        }

	fprintf(fp_out,"/*\n");
	fprintf(fp_out,"* Algorithm Name - Khichidi-1\n");
	fprintf(fp_out,"* Test Name - Analysis of Attacks \n");
	fprintf(fp_out,"* Description of Test - Analysis of Hearding attack \n");
	fprintf(fp_out,"* Message Digest being tested - Message digest length %d bits\n",hash_length);
	fprintf(fp_out,"*/\n");
	fprintf(fp_out,"\n\n");


	fprintf(fp_out,"Len = %d\n",8);
	fprintf(fp_out,"Msg = %s\n",hearding_data);

	Init(&state, hash_length);
	Update(&state, hearding_data,8);
	Final(&state, result);
	hexify(result, hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif
	fprintf(fp_out,"MD = %s\n",hex);

	fprintf(fp_out,"\n\n");

	fprintf(fp_out,"Len = %d\n",8);
	fprintf(fp_out,"Msg = %s\n",hearding_data_1);

	Init(&state, hash_length);
	Update(&state, hearding_data_1,8);
	Final(&state, result);
	hexify(result,hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif

	fprintf(fp_out,"MD = %s\n",hex);
	return KAT_SUCCESS;

}


int differential(int hash_length)
{
        FILE            *fp_in, *fp_out;

	char differential_data[4] ="fox";
	char differential_data_1[4] ="box";

	char            fn[32];
	char hex[129] = "";

	// hash
	BitSequence result[64];
	hashState state;

        sprintf(fn, "differential_attack_%d.txt", hash_length);
        if ( (fp_out = fopen(fn, "w")) == NULL ) {
                printf("Couldn't open <%s> for write\n", fn);
                return KAT_FILE_OPEN_ERROR;
        }

	fprintf(fp_out,"/*\n");
	fprintf(fp_out,"* Algorithm Name - Khichidi-1\n");
	fprintf(fp_out,"* Test Name - Analysis of Attacks \n");
	fprintf(fp_out,"* Description of Test - Analysis of Differential attack \n");
	fprintf(fp_out,"* Message Digest being tested - Message digest length %d bits\n",hash_length);
	fprintf(fp_out,"*/\n");
	fprintf(fp_out,"\n\n");


	fprintf(fp_out,"Len = %d\n",24);
	fprintf(fp_out,"Msg = %s\n",differential_data);

	Init(&state, hash_length);
	Update(&state, differential_data,24);
	Final(&state, result);
	hexify(result, hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif
	fprintf(fp_out,"MD = %s\n",hex);

	fprintf(fp_out,"\n\n");

	fprintf(fp_out,"Len = %d\n",24);
	fprintf(fp_out,"Msg = %s\n",differential_data_1);

	Init(&state, hash_length);
	Update(&state, differential_data_1,24);
	Final(&state, result);
	hexify(result,hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif
	fprintf(fp_out,"MD = %s\n",hex);
	return KAT_SUCCESS;

}

int message_expansion(int hash_length)
{
        FILE            *fp_in, *fp_out;
	char data_224[29]="AaBbCcDdEeFfGgHhIiJjKkLlMmNn";
	char data_224_1[30]="AaBbCcDdEeFfGgHhIiJjKkLlMmNnO";
	char data_256[33] = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPp";
	char data_256_1[34] = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQ";
	char data_384[49] = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXx";
	char data_384_1[50] = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxY";
	char data_512[65] = "(AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789)";
	char data_512_1[66] = "(AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789)=";

	char            fn[32];
	char hex[129] = "";

	// hash
	BitSequence result[64];
	hashState state;

        sprintf(fn, "message_expansion_%d.txt", hash_length);
        if ( (fp_out = fopen(fn, "w")) == NULL ) {
                printf("Couldn't open <%s> for write\n", fn);
                return KAT_FILE_OPEN_ERROR;
        }

	fprintf(fp_out,"/*\n");
	fprintf(fp_out,"* Algorithm Name - Khichidi-1\n");
	fprintf(fp_out,"* Test Name - Analysis of Attacks \n");
	fprintf(fp_out,"* Description of Test - Analysis of Differential attack \n");
	fprintf(fp_out,"* Message Digest being tested - Message digest length %d bits\n",hash_length);
	fprintf(fp_out,"*/\n");
	fprintf(fp_out,"\n\n");

	switch (hash_length)
	{
		case 224:
			fprintf(fp_out,"Len = %d\n",224);
			fprintf(fp_out,"Msg = %s\n",data_224);

			Init(&state, hash_length);
			Update(&state, data_224,224);
			Final(&state, result);
			hexify(result, hash_length/8, hex);

		#ifdef DEBUG
			fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
			fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
			fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
			fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
			fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
			fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
		#endif
			fprintf(fp_out,"MD = %s\n",hex);

			fprintf(fp_out,"\n\n");

			fprintf(fp_out,"Len = %d\n",232);
			fprintf(fp_out,"Msg = %s\n",data_224_1);

			Init(&state, hash_length);
			Update(&state, data_224_1,232);
			Final(&state, result);
			hexify(result,hash_length/8, hex);

		#ifdef DEBUG
			fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
			fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
			fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
			fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
			fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
			fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
		#endif
			fprintf(fp_out,"MD = %s\n",hex);
			break;
		case 256:
			fprintf(fp_out,"Len = %d\n",256);
			fprintf(fp_out,"Msg = %s\n",data_256);

			Init(&state, hash_length);
			Update(&state, data_256,256);
			Final(&state, result);
			hexify(result, hash_length/8, hex);

		#ifdef DEBUG
			fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
			fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
			fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
			fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
			fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
			fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
		#endif
			fprintf(fp_out,"MD = %s\n",hex);

			fprintf(fp_out,"\n\n");

			fprintf(fp_out,"Len = %d\n",264);
			fprintf(fp_out,"Msg = %s\n",data_256_1);

			Init(&state, hash_length);
			Update(&state, data_256_1,264);
			Final(&state, result);
			hexify(result,hash_length/8, hex);

		#ifdef DEBUG
			fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
			fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
			fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
			fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
			fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
			fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
		#endif
			fprintf(fp_out,"MD = %s\n",hex);
			break;
		case 384:
			fprintf(fp_out,"Len = %d\n",384);
			fprintf(fp_out,"Msg = %s\n",data_384);

			Init(&state, hash_length);
			Update(&state, data_384,384);
			Final(&state, result);
			hexify(result, hash_length/8, hex);

		#ifdef DEBUG
			fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
			fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
			fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
			fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
			fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
			fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
		#endif
			fprintf(fp_out,"MD = %s\n",hex);

			fprintf(fp_out,"\n\n");

			fprintf(fp_out,"Len = %d\n",392);
			fprintf(fp_out,"Msg = %s\n",data_384_1);

			Init(&state, hash_length);
			Update(&state, data_224_1,392);
			Final(&state, result);
			hexify(result,hash_length/8, hex);

		#ifdef DEBUG
			fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
			fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
			fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
			fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
			fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
			fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
		#endif
			fprintf(fp_out,"MD = %s\n",hex);
			break;
		case 512:
			fprintf(fp_out,"Len = %d\n",512);
			fprintf(fp_out,"Msg = %s\n",data_512);

			Init(&state, hash_length);
			Update(&state, data_512,512);
			Final(&state, result);
			hexify(result, hash_length/8, hex);

		#ifdef DEBUG
			fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
			fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
			fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
			fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
			fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
			fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
		#endif
			fprintf(fp_out,"MD = %s\n",hex);

			fprintf(fp_out,"\n\n");

			fprintf(fp_out,"Len = %d\n",520);
			fprintf(fp_out,"Msg = %s\n",data_512_1);

			Init(&state, hash_length);
			Update(&state, data_512_1,520);
			Final(&state, result);
			hexify(result,hash_length/8, hex);

		#ifdef DEBUG
			fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
			fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
			fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
			fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
			fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
			fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
		#endif
			fprintf(fp_out,"MD = %s\n",hex);
			break;

	}
	return KAT_SUCCESS;
}

#if 0
int main()
{
	char padding_data[2]="0";
	char message_expansion_data_224[29]="AaBbCcDdEeFfGgHhIiJjKkLlMmNn";
	char message_expansion_data_224_1[30]="AaBbCcDdEeFfGgHhIiJjKkLlMmNnO";
	char message_expansion_data_256[33] = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPp";
	char message_expansion_data_256_1[34] = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQ";
	char message_expansion_data_384[49] = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXx";
	char message_expansion_data_384_1[50] = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxY";
	char message_expansion_data_512[65] = "(AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789)";
	char message_expansion_data_512_1[66] = "(AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789)=";

	char hearding_data[2] ="0";
	char hearding_data_1[2] ="1";

	char differential_data[4] ="fox";
	char differential_data_1[4] ="box";
	// hash in hex
	char hex[129] = "";

	// hash
	BitSequence result[64];
	hashState state;




	//char data_224[29]   = "ABCDEFGHIJKLMNOPQRSTUVWXYZ01";	
	//char data_224_1[30] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ012";	
	//char data_224[] = "5c5d5e5f58595a5b54555657505152534c4d4e4f48494a4b44454647404142437c7d7e7f78797a7b74757677707172736c6d6e6f68696a6b64656667606162632BD9E2A060159E83F818B479F73B21E4BACB1728ACA566E393181DB5";
/*
	char data_224[29]   = "ABCDEFGHIJKLMNOPQRSTUVWXYZ01";	
	char data_224_1[30] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ012";	

	char data_256[33] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ012345";	
	char data_256_1[34] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456";	

	char data_384[49] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789123456789012";	
	char data_384_1[50] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ01234567891234567890123";	

	char data_512[65] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ01234567891234567890123456789ABCDEFGHI";	
	char data_512_1[66] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ01234567891234567890123456789ABCDEFGHIJ";	
*/


	printf("/*");
	printf("* Algorithm Name - Khichidi-1");
	printf("* Test Name - Analysis of Attacks ");
	printf("* Description of Test - Analysis of Padding attack, Message Expansion attack, Hearding attack and Differential attacks ");
	printf("* Message Digest being tested - All the message digest are tested 224,256,384 and 512 */");


	Init(&state, 224);
	Update(&state, padding_data,6);
	Final(&state, result);
	hexify(result, 28, hex);

	Init(&state, 224);
	Update(&state, padding_data,7);
	Final(&state, result);
	hexify(result, 28, hex);


	Init(&state, 224);
	Update(&state, message_expansion_data_224,224);
	Final(&state, result);
	hexify(result, 28, hex);


	Init(&state, 224);
	Update(&state, message_expansion_data_224_1,232);
	Final(&state, result);
	hexify(result, 28, hex);

	Init(&state, 224);
	Update(&state, hearding_data,8);
	Final(&state, result);
	hexify(result, 28, hex);

	Init(&state, 224);
	Update(&state, hearding_data_1,8);
	Final(&state, result);
	hexify(result, 28, hex);

	Init(&state, 224);
	Update(&state, differential_data,24);
	Final(&state, result);
	hexify(result, 28, hex);

	Init(&state, 224);
	Update(&state, differential_data_1,24);
	Final(&state, result);
	hexify(result, 28, hex);

	printf("For 224 bits-------\n");
	// No of bits 1
	
	Init(&state, 224);
	//Update(&state, data, 184*8);
	Update(&state, data_224_1, 232);
	Final(&state, result);
	hexify(result, 28, hex);
	printf("Data= %s\n", data_224_1);
	printf("Hash= %s\n",hex);

#if 0
	// No of bits 1
	Init(&state, 224);
	Update(&state, data, 1);
	Final(&state, result);
	hexify(result, 28, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 3
	Init(&state, 224);
	Update(&state, data, 3);
	Final(&state, result);
	hexify(result, 28, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 7
	Init(&state, 224);
	Update(&state, data, 7);
	Final(&state, result);
	hexify(result, 28, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 8 (1byte)
	Init(&state, 224);
	Update(&state, data, strlen(data)*8);
	Final(&state, result);
	hexify(result, 28, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits exact 224 bits
	Init(&state, 224);
	Update(&state, data_224, strlen(data_224)*8);
	Final(&state, result);
	hexify(result, 28, hex);
	printf("Data= %s\n", data_224);
	printf("Hash= %s\n",hex);

	// no of bits 225 bits
	Init(&state, 224);
	Update(&state, data_224_1, 225);
	Final(&state, result);
	hexify(result, 28, hex);
	printf("Data= %s\n", data_224_1);
	printf("Hash= %s\n",hex);

	printf("For 256 bits-------\n");

	// No of bits 1
	Init(&state, 256);
	Update(&state, data, 1);
	Final(&state, result);
	hexify(result, 32, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 3
	Init(&state, 256);
	Update(&state, data, 3);
	Final(&state, result);
	hexify(result, 32, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 7
	Init(&state, 256);
	Update(&state, data, 7);
	Final(&state, result);
	hexify(result, 32, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 8 (1byte)
	Init(&state, 256);
	Update(&state, data, strlen(data)*8); // in bits
	Final(&state, result);
	hexify(result, 32, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits exact 256 bits
	Init(&state, 256);
	Update(&state, data_256, strlen(data_256)*8);
	Final(&state, result);
	hexify(result, 32, hex);
	printf("Data= %s\n", data_256);
	printf("Hash= %s\n",hex);

	// no of bits 257 bits
	Init(&state, 256);
	Update(&state, data_256_1, 257);
	Final(&state, result);
	hexify(result, 32, hex);
	printf("Data= %s\n", data_256_1);
	printf("Hash= %s\n",hex);


	printf("For 384 bits-------\n");

	// No of bits 1
	Init(&state, 384);
	Update(&state, data, 1);
	Final(&state, result);
	hexify(result, 48, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 3
	Init(&state, 384);
	Update(&state, data, 3);
	Final(&state, result);
	hexify(result, 48, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 7
	Init(&state, 384);
	Update(&state, data, 7);
	Final(&state, result);
	hexify(result, 48, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 8 (1byte)
	Init(&state, 384);
	Update(&state, data, strlen(data)*8); // in bits
	Final(&state, result);
	hexify(result, 48, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits exact 384 bits
	Init(&state, 384);
	Update(&state, data_384, strlen(data_384)*8);
	Final(&state, result);
	hexify(result, 48, hex);
	printf("Data= %s\n", data_384);
	printf("Hash= %s\n",hex);

	// no of bits 385 bits
	Init(&state, 384);
	Update(&state, data_384_1, 385);
	Final(&state, result);
	hexify(result, 48, hex);
	printf("Data= %s\n", data_384_1);
	printf("Hash= %s\n",hex);

	printf("For 512 bits-------\n");

	// No of bits 1
	Init(&state, 512);
	Update(&state, data, 1);
	Final(&state, result);
	hexify(result, 64, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 3
	Init(&state, 512);
	Update(&state, data, 3);
	Final(&state, result);
	hexify(result, 64, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 7
	Init(&state, 512);
	Update(&state, data, 7);
	Final(&state, result);
	hexify(result, 64, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits 8 (1byte)
	Init(&state, 512);
	Update(&state, data, strlen(data)*8); // in bits
	Final(&state, result);
	hexify(result, 64, hex);
	printf("Data= %s\n", data);
	printf("Hash= %s\n",hex);

	// no of bits exact 512 bits
	Init(&state, 512);
	Update(&state, data_512, strlen(data_512)*8);
	Final(&state, result);
	hexify(result, 64, hex);
	printf("Data= %s\n", data_512);
	printf("Hash= %s\n",hex);

	// no of bits 513 bits
	Init(&state, 512);
	Update(&state, data_512_1, 513);
	Final(&state, result);
	hexify(result, 64, hex);
	printf("Data= %s\n", data_512_1);
	printf("Hash= %s\n",hex);

#endif
}


#endif
