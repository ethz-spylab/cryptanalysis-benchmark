#include <stdio.h>
#include <string.h>

#include "khichidi.h"
typedef enum { KAT_SUCCESS = 0, KAT_FILE_OPEN_ERROR = 1, KAT_HEADER_ERROR = 2, KAT_DATA_ERROR = 3, KAT_HASH_ERROR = 4 } STATUS_CODES;


int main ()
{
        int             i, ret_val,  bitlens[4] = { 224, 256, 384, 512 };

        for ( i=0; i<4; i++ ) {
                if ( (ret_val = khichidi(bitlens[i])) != KAT_SUCCESS )
                        return ret_val;
        }
}

int khichidi(int hash_length)
{
        FILE            *fp_in, *fp_out;

	char data[2]="0";
	char data_1[3]="00";

	char data_2[4]="abc";
	char data_3[113]="abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnopqrstu";

	char data_4[44] = "The quick brown fox jumps over the lazy dog";
	char data_5[44] = "The quick brown fox jumps over the lazy cog";

	char            fn[32];
	char hex[129] = "";

	// hash
	BitSequence result[64];
	hashState state;

        sprintf(fn, "khichidi_%d.txt", hash_length);
        if ( (fp_out = fopen(fn, "w")) == NULL ) {
                printf("Couldn't open <%s> for write\n", fn);
                return KAT_FILE_OPEN_ERROR;
        }

	fprintf(fp_out,"/*\n");
	fprintf(fp_out,"* Algorithm Name - Khichidi-1\n");
	fprintf(fp_out,"* Test Name - Khichidi Hash test \n");
	fprintf(fp_out,"* Description of Test - This test is done to compare the outputs of SHA-2 and Khichidi-1\n");
	fprintf(fp_out,"* Message Digest being tested - Message digest length %d bits\n",hash_length);
	fprintf(fp_out,"*/\n");
	fprintf(fp_out,"\n\n");


	fprintf(fp_out,"Len = %d\n",8);
	fprintf(fp_out,"Msg = %s\n",data);

	Init(&state, hash_length);
	Update(&state, data,8);
	Final(&state, result);
	hexify(result, hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif
	fprintf(fp_out,"MD = %s\n",hex);

	fprintf(fp_out,"\n\n");

	fprintf(fp_out,"Len = %d\n",16);
	fprintf(fp_out,"Msg = %s\n",data_1);

	Init(&state, hash_length);
	Update(&state, data_1,16);
	Final(&state, result);
	hexify(result,hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif

	fprintf(fp_out,"MD = %s\n",hex);

	fprintf(fp_out,"\n\n");

	fprintf(fp_out,"Len = %d\n",24);
	fprintf(fp_out,"Msg = %s\n",data_2);

	Init(&state, hash_length);
	Update(&state, data_2,24);
	Final(&state, result);
	hexify(result,hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif
	fprintf(fp_out,"MD = %s\n",hex);
	fprintf(fp_out,"\n\n");

	fprintf(fp_out,"Len = %d\n",896);
	fprintf(fp_out,"Msg = %s\n",data_3);

	Init(&state, hash_length);
	Update(&state, data_3,896);
	Final(&state, result);
	hexify(result,hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif
	fprintf(fp_out,"MD = %s\n",hex);
	fprintf(fp_out,"\n\n");

	fprintf(fp_out,"Len = %d\n",344);
	fprintf(fp_out,"Msg = %s\n",data_4);

	Init(&state, hash_length);
	Update(&state, data_4,344);
	Final(&state, result);
	hexify(result,hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif
	fprintf(fp_out,"MD = %s\n",hex);
	fprintf(fp_out,"\n\n");

	fprintf(fp_out,"Len = %d\n",344);
	fprintf(fp_out,"Msg = %s\n",data_5);

	Init(&state, hash_length);
	Update(&state, data_5,344);
	Final(&state, result);
	hexify(result,hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif
	fprintf(fp_out,"MD = %s\n",hex);
	fprintf(fp_out,"\n\n");

	fprintf(fp_out,"Len = %d\n",0);
	fprintf(fp_out,"Msg = %s\n",data);

	Init(&state, hash_length);
	Update(&state, data,0);
	Final(&state, result);
	hexify(result,hash_length/8, hex);

#ifdef DEBUG
	fprintf(fp_out,"Round 1 = %s\n",state.Round[0]);
	fprintf(fp_out,"Round 2 = %s\n",state.Round[1]);
	fprintf(fp_out,"Round 3 = %s\n",state.Round[2]);
	fprintf(fp_out,"Round 4 = %s\n",state.Round[3]);
	fprintf(fp_out,"Round 5 = %s\n",state.Round[4]);
	fprintf(fp_out,"Round 6 = %s\n",state.Round[5]);
#endif
	fprintf(fp_out,"MD = %s\n",hex);
	fprintf(fp_out,"\n\n");

	return KAT_SUCCESS;

}

