Khichidi-1 - This directory consists of Khichidi hash algorithm  Implementation. (Usage Khichidi-1.exe <bitlength> <filename> )

Code is complied using Visual Studio 2005

Release - This directory consists of Khichidi-1.exe



