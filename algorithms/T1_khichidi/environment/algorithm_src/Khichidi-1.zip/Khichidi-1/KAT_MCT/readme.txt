Implementation - This directory consists of KAT and MCT generation implementation
KAT - This directory consists of test data of KAT for 224,256,384 and 512 bits
MCT - This directory consists of test data of MCT for 224,256,384 and 512 bits