/*
 * Copyright (c) Innovation Labs, Tata Consultancy Services (TCS), Hyderabad. All Rights
 * reserved.
 *
 * This software is the confidential and proprietary information of TCS.
 * ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with
 * the terms of the license agreement you entered into with TCS.
 *
 * TCS MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT.  TCS SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */


#include <stdio.h>
#include <stdlib.h>
#include "khichidi.h"


int main(int argc, char** argv)
{
	int i,ret = 0;
	hashState *state;
	BitSequence *digest=0, buffer[1024];
	int bitlength=0;
	FILE* file;
	long total = 0;


	if (argc != 3) 
	{
	        printf("Khichidi-1 implementation for SHA-3 hash competition\n");
	        printf("Produces hash of a file.\nUsage Khichidi-1.exe <bitlength> <filename>\n");
	        return -1;
	}
    if (!(file = fopen(argv[2], "rb"))) 
	{
        printf("Unable to open file %s \n", argv[2]);
        return -1;
    }
	bitlength = atoi(argv[1]);
	state = (hashState*) malloc(sizeof(hashState));
	ret = Init (state,bitlength);
	digest = (BitSequence*) malloc(bitlength/8);

	if(ret == SUCCESS)
	{
	    	while (!feof(file)) 
			{  /* note: what if ferror(file) */
        		i = fread(buffer, 1, 1024, file);
			total = total + i*8;
		        ret = Update(state, buffer, i*8);
				if(ret != SUCCESS)
					break;
			}
		if(ret == SUCCESS)
		{
		    ret = Final(state, digest);
			if(ret == SUCCESS)
			{
				printf("Hash Value = ");
				for(i=0;i<bitlength/8;i++)
				{
					printf("%02X",digest[i]);
				}
				printf("\n");
			}
		}
	}
	if(ret != SUCCESS)
	{
		printf("Hash Failed - Return value - %d\n",ret);
	}
	free(digest);
	free(state);
	fclose(file);
	return ret;
}
