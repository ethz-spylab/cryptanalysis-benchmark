Reference Implementation - This directory consists of Khichidi algorithm implementation. Code is compiled using Visual Studio 2205
Optimized_32bit - This directory consists of Khichidi implementation that was compiled and tested for 32 bit OS
Optimized_64bit - This directory consists of Khichidi implementation that was compiled and tested for 64 bit OS
KAT_MCT - This directory consists of Known Answer Test and Monte Carlo Tests results and the Implementation
Supporting Documentation - This directory consists of complete written specification of the Khichidi - 1 algorithm
Additional Implementation - This  directory consists of KAT results along with intermediate values. It also consists of Implementation