#ifndef _MYTYPES_
#define _MYTYPES_

#include <time.h>

typedef short  crypto_uint8;
typedef  unsigned int crypto_uint32;
typedef  unsigned  long crypto_uint64;

long long  crypto_hash(
       unsigned char *out,
       const unsigned char *in,
       unsigned long  inlen
		);

#endif
