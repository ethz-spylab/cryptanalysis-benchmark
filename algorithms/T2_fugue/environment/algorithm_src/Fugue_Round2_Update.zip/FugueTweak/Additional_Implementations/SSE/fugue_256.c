/*********************************************************
 *
 * Filename     : fugue.c
 *
 * Originator   : Charanjit S. Jutla
 *
 * Purpose      : Optimized Implementation of Fugue for
 *                224 and 256 bit hash sizes
 *
 *********************************************************/

#include <time.h>
#include "fugue_t.h"
#include "aestab.h"
#include <tmmintrin.h>


#define IMPL_TYPE  _NON_SSE
#define EXTRA_ROUND_IMPL_TYPE  _NON_SSE

#define FUGUE_SIZE 30
#define FUGUE_FAR 24


#define column(i) col[i]
#define row(i) row[i]


#define vector2words(rc,i) \
bytes2word(bval(rc[0],i),  bval(rc[1],i),   bval(rc[2],i),   bval(rc[3],i))

#define off(p,n) ((n+p+FUGUE_SIZE) % FUGUE_SIZE)

#define tix(p,j,in)							\
  state[off(p,10)] ^= state[off(p,0)];  state[off(p,0)] = ((uint_32t *)in)[j];  \
  state[off(p,8)]  ^= state[off(p,0)];  state[off(p,1)] ^= state[off(p,FUGUE_FAR)]

#define column_mix(p)\
  state[off(p,0)] ^= state[off(p,4)];  state[off(p,1)] ^= state[off(p,5)];  state[off(p,2)] ^= state[off(p,6)];\
  state[off(p,15)] ^= state[off(p,4)];  state[off(p,16)] ^= state[off(p,5)];  state[off(p,17)] ^= state[off(p,6)]


//------------------------------------------------------------------------------------------------------------------

#define table_index_OPT(p,i,k) col##i = _mm_cvtsi32_si128(aes_style_table[k][bval(state[off(p,i)],k)])
#define xor_col_OPT(k,i) ct##i = _mm_xor_si128(ct##i,col##i);
#define set_col_OPT(k,i) ct##i = col##i;
#define xor_row_xor_col_OPT(k,i)  row##k = _mm_xor_si128(row##k,col##i); ct##i = _mm_xor_si128(ct##i,col##i);
#define xor_row_set_col_OPT(k,i)  row##k = _mm_xor_si128(row##k,col##i);ct##i = col##i;
#define set_row_xor_col_OPT(k,i)  row##k = col##i;		; ct##i = _mm_xor_si128(ct##i,col##i);
#define set_row_set_col_OPT(k,i)  row##k = col##i;		;  ct##i = col##i;

#define xor_short_form_i_eq_k(p,i,k,type)       \
table_index##type(p,i,k); xor_col##type(k,i)

#define xor_short_form_i_eq_k_col_first(p,i,k,type)     \
table_index##type(p,i,k);  set_col##type(k,i)

#define xor_short_form_i_neq_k(p,i,k,type)  \
table_index##type(p,i,k);   xor_row_xor_col##type(k,i)

#define xor_short_form_i_neq_k_col_first(p,i,k,type)  \
table_index##type(p,i,k); xor_row_set_col##type(k,i)

#define xor_short_form_i_neq_k_row_first(p,i,k,type)  \
table_index##type(p,i,k);  set_row_xor_col##type(k,i)

#define xor_short_form_i_neq_k_row_and_col_first(p,i,k,type)  \
table_index##type(p,i,k);   set_row_set_col##type(k,i)

//--------
#define xor_rc_3_0(p,i,k,type)  xor_short_form_i_neq_k_row_and_col_first(p,i,k,type); 
#define xor_rc_3_1(p,i,k,type)  xor_short_form_i_neq_k_row_first(p,i,k,type)
#define xor_rc_3_2(p,i,k,type)  xor_short_form_i_neq_k_row_first(p,i,k,type)
#define xor_rc_3_3(p,i,k,type)  xor_short_form_i_eq_k(p,i,k,type)

//Note col 3 is being done first

#define xor_rc_0_0(p,i,k,type)  xor_short_form_i_eq_k_col_first(p,i,k,type)
#define xor_rc_0_1(p,i,k,type)  xor_short_form_i_neq_k(p,i,k,type)
#define xor_rc_0_2(p,i,k,type)  xor_short_form_i_neq_k(p,i,k,type)
#define xor_rc_0_3(p,i,k,type)  xor_short_form_i_neq_k_row_first(p,i,k,type)

#define xor_rc_1_0(p,i,k,type)  xor_short_form_i_neq_k_col_first(p,i,k,type)
#define xor_rc_1_1(p,i,k,type)  xor_short_form_i_eq_k(p,i,k,type)
#define xor_rc_1_2(p,i,k,type)  xor_short_form_i_neq_k(p,i,k,type)
#define xor_rc_1_3(p,i,k,type)  xor_short_form_i_neq_k(p,i,k,type)

#define xor_rc_2_0(p,i,k,type)  xor_short_form_i_neq_k_col_first(p,i,k,type)
#define xor_rc_2_1(p,i,k,type)  xor_short_form_i_neq_k(p,i,k,type)
#define xor_rc_2_2(p,i,k,type)  xor_short_form_i_eq_k(p,i,k,type)
#define xor_rc_2_3(p,i,k,type)  xor_short_form_i_neq_k(p,i,k,type)
//---------

#define xor_rc_outer(p,i,type)\
  xor_rc_##i##_0(p,i,0,type); xor_rc_##i##_1(p,i,1,type); xor_rc_##i##_2(p,i,2,type); xor_rc_##i##_3(p,i,3,type); \


#define xor_row_and_col(p,type) \
     xor_rc_outer(p,3,type);  ct3 = _mm_slli_si128(ct3,12); \
     xor_rc_outer(p,0,type);  col128 = _mm_xor_si128(ct0,ct3); \
     xor_rc_outer(p,1,type);  ct1 = _mm_slli_si128(ct1,4);\
     xor_rc_outer(p,2,type);  ct2 = _mm_slli_si128(ct2,8);   ct1 = _mm_xor_si128(ct1,ct2); 


#define rotate_regs_NON_SSE \
  t1 = _mm_srli_si128(t1, 4);\
  t2 = _mm_srli_si128(t2, 8);\
  t3 = _mm_srli_si128(t3,12);  \

#define write_back_to_state_listed_0_NON_SSE(p,i) \
  col128 = _mm_xor_si128(col128,ct1); \
  col128 = _mm_shuffle_epi8(col128, col_rotate_mask);		\
  row1 = _mm_slli_si128(row1,4);		  \
  row2 = _mm_slli_si128(row2,4*2);		  \
  row3 = _mm_slli_si128(row3,4*3);		  \
  row0 = _mm_xor_si128(row0,row1);                \
  row128 = _mm_xor_si128(row2,row3);                \
  row128 = _mm_xor_si128(row128,row0);               \
  row128= _mm_shuffle_epi8(row128, row_shuffle_col_mask);		\
  col128 = _mm_xor_si128(col128, row128); \
  t1=t2=t3 = col128; \
  state[off(p,i)] = _mm_cvtsi128_si32 (col128);  \
  rotate_regs_NON_SSE

#define write_back_to_state_listed_1_NON_SSE(p,i) \
  state[off(p,i)] = _mm_cvtsi128_si32 (t1);	\

#define write_back_to_state_listed_2_NON_SSE(p,i) \
  state[off(p,i)] = _mm_cvtsi128_si32 (t2);	\

#define write_back_to_state_listed_3_NON_SSE(p,i) \
  state[off(p,i)] = _mm_cvtsi128_si32 (t3);  

#define write_back_to_state_listed_0_OPT(p,i) \
    row128 = _mm_load_si128((__m128i const *) row);   \
    col128 = _mm_load_si128((__m128i const *) col);	\
    col128 = _mm_shuffle_epi8(row128,col_rotate_mask);   \
    row128 = _mm_shuffle_epi8(row128,row_shuffle_col_mask);	\
  col128 = _mm_xor_si128(col128,row128); \
 _mm_store_si128( (__m128i *) row, col128);	\
  state[off(p,i)] = row[i];


//  _mm_storeu_si128( (__m128i *) (&state[off(p,i)]), col128);	\

#define write_back_to_state_listed_1_OPT(p,i)   state[off(p,i)] = row[i];
#define write_back_to_state_listed_2_OPT(p,i)   state[off(p,i)] = row[i];
#define write_back_to_state_listed_3_OPT(p,i)   state[off(p,i)] = row[i];


#define write_back_to_state(p,type) \
  write_back_to_state_listed_0##type(p,0); \
  write_back_to_state_listed_1##type(p,1);\
  write_back_to_state_listed_2##type(p,2);\
  write_back_to_state_listed_3##type(p,3)


//------------------------------------------------------------------------------------------------------------------


#define super_mix(ptr,type)\
 xor_row_and_col(ptr,_OPT); \
 write_back_to_state(ptr,type);

#define sub_round(ptr,type) \
             column_mix(ptr);   super_mix(ptr,type)

#define super_mix_convert(p,type) super_mix(p,type)

#define ror(state,n) ptr = ((ptr-n+FUGUE_SIZE) % FUGUE_SIZE)

#define cross_mix(p,cross) \
       state[off(p,4)] ^=    state[off(p,0)]; \
       state[off(p,cross)] ^=state[off(p,0)]

#define final_sub_round(p,cross,n) \
        cross_mix(p,cross);\
       ror(state,n); super_mix_convert(p,EXTRA_ROUND_IMPL_TYPE)

#define final_round2(ptr,num,c)\
    for (j=0; j<c; j++)      \
         { final_sub_round(ptr, 15,15); \
            final_sub_round(ptr, 16,14);} \
             cross_mix(ptr,15);

#define final_round1(ptr,num,c) \
    for (j=0; j<c; j++)  \
      {sub_round(((-3)*(2*((num+j)%5)+1)),EXTRA_ROUND_IMPL_TYPE); \
        sub_round(((-3)*(2*((num+j)%5)+2)),EXTRA_ROUND_IMPL_TYPE);}

#define empty_pretty_print(s,a,b,c)


#define round(j,num,in,type)			     \
  tix(((-3)*2*num),j,in);			     \
           sub_round(((-3)*(2*num+1)),type); \
             sub_round(((-3)*(2*num+2)),type);

#define update(ptr) \
ptr = (ptr-3 + FUGUE_SIZE) %FUGUE_SIZE;



int fugue_update_256 (hashState *hs, const unsigned char *in, uint_64t len)
{
    uint_32t state[30];

    //    __attribute__((aligned(16)))     uint_32t row[4];
    //    __attribute__((aligned(16)))     uint_32t col[4];
    __m128i  /*row_shuffle_mask, */ row_shuffle_col_mask;
    __m128i  col_rotate_mask;
    __m128i  row128;
    __m128i row0, row1, row2, row3;
    //    __m128i rt0,rt1,rt2,rt3;
    __m128i ct0,ct1,ct2,ct3;
    __m128i col0,col1,col2,col3;
    __m128i col128,  t1,t2,t3;

    short len_mod;
    uint_64t len_div;
    uint_64t j,j1,j2;
    short ptr = hs->Base;



    row_shuffle_col_mask = _mm_set_epi8(14,9,4,3,
					13,8,7,2,
					12,11,6,1,
					15,10,5,0);

    col_rotate_mask = _mm_set_epi8(11,6,1,12,
				   7,2,13,8,
				   3,14,9,4,
				  15,10,5,0);



    j1 = (5-hs->Base/6)%5;  // this is the left over sliding window pointer (divided by 2*3)

    for (j=0; j < 30; j++) state[j] = hs->State[j].d;

    j=0;

    if (j1 && len)
    {
      if  (j1 <=1)         { round(j,1,in,IMPL_TYPE); j++; len--; ptr -=6; }
      if ((j1 <=2) && len) { round(j,2,in,IMPL_TYPE); j++; len--; ptr -=6; }
      if ((j1 <=3) && len) { round(j,3,in,IMPL_TYPE); j++; len--; ptr -=6; }
      if ((j1 <=4) && len) { round(j,4,in,IMPL_TYPE); j++; len--; ptr -=6; }
    }


    len_mod = (len)%5;
    len_div = (len)/5;

    for (j2=0; j2<len_div;j2++)
    {
      round(j,0,in,IMPL_TYPE); j++;
      round(j,1,in,IMPL_TYPE); j++;
      round(j,2,in,IMPL_TYPE); j++;
      round(j,3,in,IMPL_TYPE); j++;
      round(j,4,in,IMPL_TYPE); j++;
    }

    if (len_mod >=1)
    {
      round(j,0,in,IMPL_TYPE); j++;
        if (len_mod >=2)
        {
	  round(j,1,in,IMPL_TYPE); j++;
            if (len_mod >=3)
            {
	      round(j,2,in,IMPL_TYPE); j++;
                if (len_mod >=4)
                {
		  round(j,3,in,IMPL_TYPE); j++;
                }
            }
        }
    }

    for (j=0; j < 30; j++) hs->State[j].d = state[j];
    hs->Base = (ptr-6*len_mod + 2*FUGUE_SIZE) % FUGUE_SIZE;

    return 0;
}

int fugue_final_256 (hashState *hs, char *out)
{
  //                                  uint_32t row[4];
  //    __attribute__((aligned(16)))     uint_32t col[4];
    __m128i /* row_shuffle_mask,*/ row_shuffle_col_mask;
    __m128i  col_rotate_mask;
    __m128i  row128;
    __m128i row0, row1, row2, row3;
    //    __m128i rt0,rt1,rt2,rt3;
    __m128i ct0,ct1,ct2,ct3;
    __m128i col0,col1,col2,col3;
    __m128i col128,    t1,t2,t3 ;
    
    uint_32t *state = (uint_32t *)hs->State;
    uint_64t j,j1 = (5-hs->Base/6)%5;
    short ptr = hs->Base;


    row_shuffle_col_mask = _mm_set_epi8(14,9,4,3,
					13,8,7,2,
					12,11,6,1,
					15,10,5,0);


    col_rotate_mask = _mm_set_epi8(11,6,1,12,
				   7,2,13,8,
				   3,14,9,4,
				  15,10,5,0);

    final_round1(ptr,j1,5);
    final_round2(ptr,j1,13);

    for (j=0; j<4; j++)
    {
        ((uint_32t *)out)[j]   = state[off(ptr,1+j)];
        ((uint_32t *)out)[4+j] = state[off(ptr,15+j)];
    }

    return 0;
}
