# -- Machine type EFI2
# mark_description "Intel(R) C++ Compiler for applications running on Intel(R) 64, Version 11.1    Build 20090827 %s";
# mark_description "-S -O3 -fomit-frame-pointer -m64 -xP";
	.file "fugue_256.c"
	.text
..TXTST0:
# -- Begin  fugue_update_256
# mark_begin;
       .align    16,0x90
	.globl fugue_update_256
fugue_update_256:
# parameter 1: %rdi
# parameter 2: %rsi
# parameter 3: %rdx
..B1.1:                         # Preds ..B1.0
..___tag_value_fugue_update_256.1:                              #214.1
        pushq     %r15                                          #214.1
..___tag_value_fugue_update_256.2:                              #
        pushq     %r14                                          #214.1
..___tag_value_fugue_update_256.4:                              #
        pushq     %r13                                          #214.1
..___tag_value_fugue_update_256.6:                              #
        pushq     %r12                                          #214.1
..___tag_value_fugue_update_256.8:                              #
        pushq     %rbp                                          #214.1
..___tag_value_fugue_update_256.10:                             #
        pushq     %rbx                                          #214.1
..___tag_value_fugue_update_256.12:                             #
        subq      $472, %rsp                                    #214.1
..___tag_value_fugue_update_256.14:                             #
        movq      %rdx, %rbx                                    #214.1
        movq      %rsi, 168(%rsp)                               #214.1
        movl      $715827883, %eax                              #248.22
        movq      %rdi, %r12                                    #214.1
        movl      16(%r12), %ecx                                #232.17
        imull     %ecx                                          #248.22
        movl      %ecx, 176(%rsp)                               #232.17
        movl      $1717986919, %eax                             #248.25
        lea       192(%rsp), %r11                               #250.28
        movl      %edx, %r10d                                   #248.22
        sarl      $31, %ecx                                     #248.22
        subl      %ecx, %r10d                                   #248.22
        negl      %r10d                                         #248.11
        addl      $5, %r10d                                     #248.11
        imull     %r10d                                         #248.25
        movl      %r10d, %r8d                                   #248.25
        sarl      $31, %r8d                                     #248.25
        sarl      $1, %edx                                      #248.25
        subl      %r8d, %edx                                    #248.25
        lea       (%rdx,%rdx,4), %r9d                           #248.25
        subl      %r9d, %r10d                                   #248.25
        movslq    %r10d, %rdx                                   #248.25
        movq      %r11, %rax                                    #250.5
        subq      %r12, %rax                                    #250.5
        addq      $-20, %rax                                    #250.5
        negq      %r11                                          #250.5
        lea       20(%r12,%r11), %r11                           #250.5
        movl      $1, %ecx                                      #250.5
        xorl      %esi, %esi                                    #250.5
        cmpq      $120, %r11                                    #250.5
        cmovg     %ecx, %esi                                    #250.5
        xorl      %ebp, %ebp                                    #250.5
        cmpq      $120, %rax                                    #250.5
        cmovg     %ecx, %ebp                                    #250.5
        orl       %ebp, %esi                                    #250.5
        movl      %esi, (%rsp)                                  #250.5
        je        ..B1.39       # Prob 10%                      #250.5
                                # LOE rdx rbx r12
..B1.2:                         # Preds ..B1.1
        movl      $120, %r8d                                    #250.28
                                # LOE rdx rbx r8 r12
..B1.44:                        # Preds ..B1.44 ..B1.2
        movq      12(%r12,%r8), %rax                            #250.28
        movq      %rax, 184(%rsp,%r8)                           #250.28
        movq      4(%r12,%r8), %rcx                             #250.28
        movq      %rcx, 176(%rsp,%r8)                           #250.28
        movq      -4(%r12,%r8), %rbp                            #250.28
        movq      %rbp, 168(%rsp,%r8)                           #250.28
        movq      -12(%r12,%r8), %rsi                           #250.28
        movq      %rsi, 160(%rsp,%r8)                           #250.28
        movq      -20(%r12,%r8), %rdi                           #250.28
        movq      %rdi, 152(%rsp,%r8)                           #250.28
        subq      $40, %r8                                      #250.28
        jne       ..B1.44       # Prob 66%                      #250.28
                                # LOE rdx rbx r8 r12
..B1.3:                         # Preds ..B1.44 ..B1.41
        xorl      %ebp, %ebp                                    #252.5
        testq     %rdx, %rdx                                    #254.9
        je        ..B1.19       # Prob 50%                      #254.9
                                # LOE rdx rbx rbp r12
..B1.4:                         # Preds ..B1.3
        testq     %rbx, %rbx                                    #254.15
        je        ..B1.19       # Prob 50%                      #254.15
                                # LOE rdx rbx rbp r12
..B1.5:                         # Preds ..B1.4
        cmpq      $1, %rdx                                      #256.17
        ja        ..B1.8        # Prob 50%                      #256.17
                                # LOE rdx rbx rbp r12
..B1.6:                         # Preds ..B1.5
        movl      208(%rsp), %r14d                              #256.30
        xorl      288(%rsp), %r14d                              #256.30
        movq      168(%rsp), %rdx                               #256.30
        movl      264(%rsp), %r13d                              #256.30
        movl      292(%rsp), %r15d                              #256.30
        movl      276(%rsp), %r11d                              #256.30
        movl      296(%rsp), %r8d                               #256.30
        movl      (%rdx), %r9d                                  #256.30
        movl      200(%rsp), %edx                               #256.30
        movl      280(%rsp), %edi                               #256.30
        movl      300(%rsp), %esi                               #256.30
        movl      284(%rsp), %r10d                              #256.30
        xorl      %r9d, %edx                                    #256.30
        xorl      %r13d, %r15d                                  #256.30
        movl      %r15d, 292(%rsp)                              #256.30
        xorl      %r15d, 216(%rsp)                              #256.30
        xorl      %r15d, %r11d                                  #256.30
        xorl      %r8d, %edi                                    #256.30
        xorl      %r8d, 220(%rsp)                               #256.30
        xorl      %esi, %r10d                                   #256.30
        movzbl    %r9b, %ebp                                    #256.30
        movd      aes_style_table(,%rbp,4), %xmm6               #256.30
        movdqa    %xmm6, %xmm13                                 #256.30
        xorl      %esi, 224(%rsp)                               #256.30
        movl      %r9d, %ecx                                    #256.30
        shrl      $8, %ecx                                      #256.30
        movzbl    %cl, %eax                                     #256.30
        movd      1024+aes_style_table(,%rax,4), %xmm7          #256.30
        pxor      %xmm7, %xmm13                                 #256.30
        movl      %r9d, %ebp                                    #256.30
        shrl      $16, %ebp                                     #256.30
        movzbl    %bpl, %r15d                                   #256.30
        movd      2048+aes_style_table(,%r15,4), %xmm9          #256.30
        pxor      %xmm9, %xmm13                                 #256.30
        shrl      $24, %r9d                                     #256.30
        movd      3072+aes_style_table(,%r9,4), %xmm10          #256.30
        pxor      %xmm10, %xmm13                                #256.30
        pslldq    $12, %xmm13                                   #256.30
        movzbl    %r11b, %ebp                                   #256.30
        movd      aes_style_table(,%rbp,4), %xmm8               #256.30
        movl      %r11d, %ecx                                   #256.30
        shrl      $8, %ecx                                      #256.30
        movzbl    %cl, %eax                                     #256.30
        movd      1024+aes_style_table(,%rax,4), %xmm11         #256.30
        pxor      %xmm11, %xmm7                                 #256.30
        pxor      %xmm11, %xmm8                                 #256.30
        movl      %r11d, %ebp                                   #256.30
        shrl      $16, %ebp                                     #256.30
        movzbl    %bpl, %r15d                                   #256.30
        movd      2048+aes_style_table(,%r15,4), %xmm12         #256.30
        pxor      %xmm12, %xmm9                                 #256.30
        pxor      %xmm12, %xmm8                                 #256.30
        shrl      $24, %r11d                                    #256.30
        movd      3072+aes_style_table(,%r11,4), %xmm10         #256.30
        pxor      %xmm10, %xmm8                                 #256.30
        pxor      %xmm13, %xmm8                                 #256.30
        movzbl    %dil, %r9d                                    #256.30
        movd      aes_style_table(,%r9,4), %xmm2                #256.30
        pxor      %xmm2, %xmm6                                  #256.30
        movl      %edi, %ebp                                    #256.30
        shrl      $8, %ebp                                      #256.30
        movzbl    %bpl, %ecx                                    #256.30
        movd      1024+aes_style_table(,%rcx,4), %xmm14         #256.30
        pxor      %xmm14, %xmm2                                 #256.30
        movl      %edi, %eax                                    #256.30
        shrl      $16, %eax                                     #256.30
        movzbl    %al, %r9d                                     #256.30
        movd      2048+aes_style_table(,%r9,4), %xmm15          #256.30
        pxor      %xmm15, %xmm9                                 #256.30
        pxor      %xmm15, %xmm2                                 #256.30
        shrl      $24, %edi                                     #256.30
        movd      3072+aes_style_table(,%rdi,4), %xmm0          #256.30
        pxor      %xmm0, %xmm10                                 #256.30
        pxor      %xmm0, %xmm2                                  #256.30
        pslldq    $4, %xmm2                                     #256.30
        movzbl    %r10b, %r11d                                  #256.30
        movd      aes_style_table(,%r11,4), %xmm1               #256.30
        pxor      %xmm1, %xmm6                                  #256.30
        movl      %r10d, %r15d                                  #256.30
        shrl      $8, %r15d                                     #256.30
        movzbl    %r15b, %ebp                                   #256.30
        movd      1024+aes_style_table(,%rbp,4), %xmm5          #256.30
        movl      272(%rsp), %ebp                               #256.30
        pxor      %xmm5, %xmm7                                  #256.30
        pxor      %xmm5, %xmm1                                  #256.30
        movl      %r10d, %ecx                                   #256.30
        movdqa    _2il0floatpacket.4(%rip), %xmm5               #256.30
        shrl      $16, %ecx                                     #256.30
        movzbl    %cl, %eax                                     #256.30
        movd      2048+aes_style_table(,%rax,4), %xmm4          #256.30
        pxor      %xmm4, %xmm1                                  #256.30
        shrl      $24, %r10d                                    #256.30
        movdqa    _2il0floatpacket.3(%rip), %xmm4               #256.30
        movl      268(%rsp), %ecx                               #256.30
        movd      3072+aes_style_table(,%r10,4), %xmm3          #256.30
        pxor      %xmm3, %xmm1                                  #256.30
        pslldq    $8, %xmm1                                     #256.30
        pxor      %xmm1, %xmm2                                  #256.30
        pxor      %xmm2, %xmm8                                  #256.30
        pshufb    %xmm5, %xmm8                                  #256.30
        pslldq    $8, %xmm9                                     #256.30
        pxor      %xmm3, %xmm10                                 #256.30
        pslldq    $12, %xmm10                                   #256.30
        pxor      %xmm10, %xmm9                                 #256.30
        pslldq    $4, %xmm7                                     #256.30
        pxor      %xmm7, %xmm6                                  #256.30
        pxor      %xmm6, %xmm9                                  #256.30
        pshufb    %xmm4, %xmm9                                  #256.30
        pxor      %xmm9, %xmm8                                  #256.30
        movdqa    %xmm8, %xmm6                                  #256.30
        movdqa    %xmm8, %xmm7                                  #256.30
        psrldq    $4, %xmm6                                     #256.30
        psrldq    $8, %xmm7                                     #256.30
        movd      %xmm8, %eax                                   #256.30
        psrldq    $12, %xmm8                                    #256.30
        movd      %xmm6, %r9d                                   #256.30
        movd      %xmm7, %edi                                   #256.30
        movd      %xmm8, %r11d                                  #256.30
        xorl      %r9d, %r13d                                   #256.30
        movl      %r9d, 280(%rsp)                               #256.30
        movl      %edi, 284(%rsp)                               #256.30
        movl      %r11d, 288(%rsp)                              #256.30
        xorl      %r9d, 204(%rsp)                               #256.30
        xorl      %edi, %ecx                                    #256.30
        xorl      %r11d, 212(%rsp)                              #256.30
        xorl      %r11d, %ebp                                   #256.30
        xorl      %edi, %r14d                                   #256.30
        movl      %r14d, 208(%rsp)                              #256.30
        movzbl    %al, %r14d                                    #256.30
        movd      aes_style_table(,%r14,4), %xmm1               #256.30
        movdqa    %xmm1, %xmm12                                 #256.30
        movl      %eax, %r9d                                    #256.30
        shrl      $8, %r9d                                      #256.30
        movzbl    %r9b, %r11d                                   #256.30
        movd      1024+aes_style_table(,%r11,4), %xmm2          #256.30
        pxor      %xmm2, %xmm12                                 #256.30
        movl      %eax, %edi                                    #256.30
        shrl      $16, %edi                                     #256.30
        movzbl    %dil, %r10d                                   #256.30
        movd      2048+aes_style_table(,%r10,4), %xmm3          #256.30
        pxor      %xmm3, %xmm12                                 #256.30
        shrl      $24, %eax                                     #256.30
        movd      3072+aes_style_table(,%rax,4), %xmm8          #256.30
        pxor      %xmm8, %xmm12                                 #256.30
        pslldq    $12, %xmm12                                   #256.30
        movzbl    %r13b, %r14d                                  #256.30
        movd      aes_style_table(,%r14,4), %xmm0               #256.30
        movl      %r13d, %r15d                                  #256.30
        shrl      $8, %r15d                                     #256.30
        movzbl    %r15b, %eax                                   #256.30
        movd      1024+aes_style_table(,%rax,4), %xmm9          #256.30
        pxor      %xmm9, %xmm2                                  #256.30
        pxor      %xmm9, %xmm0                                  #256.30
        movl      %r13d, %r9d                                   #256.30
        shrl      $16, %r9d                                     #256.30
        movzbl    %r9b, %r11d                                   #256.30
        movd      2048+aes_style_table(,%r11,4), %xmm11         #256.30
        pxor      %xmm11, %xmm3                                 #256.30
        pxor      %xmm11, %xmm0                                 #256.30
        shrl      $24, %r13d                                    #256.30
        movd      3072+aes_style_table(,%r13,4), %xmm7          #256.30
        pxor      %xmm7, %xmm0                                  #256.30
        pxor      %xmm12, %xmm0                                 #256.30
        movzbl    %cl, %edi                                     #256.30
        movd      aes_style_table(,%rdi,4), %xmm6               #256.30
        pxor      %xmm6, %xmm1                                  #256.30
        movl      %ecx, %r10d                                   #256.30
        shrl      $8, %r10d                                     #256.30
        movzbl    %r10b, %eax                                   #256.30
        movd      1024+aes_style_table(,%rax,4), %xmm13         #256.30
        pxor      %xmm13, %xmm6                                 #256.30
        movl      %ecx, %r9d                                    #256.30
        shrl      $16, %r9d                                     #256.30
        movzbl    %r9b, %r11d                                   #256.30
        movd      2048+aes_style_table(,%r11,4), %xmm14         #256.30
        pxor      %xmm14, %xmm3                                 #256.30
        pxor      %xmm14, %xmm6                                 #256.30
        shrl      $24, %ecx                                     #256.30
        movd      3072+aes_style_table(,%rcx,4), %xmm15         #256.30
        pxor      %xmm15, %xmm7                                 #256.30
        pxor      %xmm15, %xmm6                                 #256.30
        pslldq    $4, %xmm6                                     #256.30
        movzbl    %bpl, %edi                                    #256.30
        movd      aes_style_table(,%rdi,4), %xmm12              #256.30
        movl      176(%rsp), %edi                               #256.67
        pxor      %xmm12, %xmm1                                 #256.30
        movl      %ebp, %r13d                                   #256.30
        shrl      $8, %r13d                                     #256.30
        movzbl    %r13b, %r14d                                  #256.30
        movd      1024+aes_style_table(,%r14,4), %xmm13         #256.30
        pxor      %xmm13, %xmm2                                 #256.30
        pxor      %xmm13, %xmm12                                #256.30
        movl      %ebp, %r15d                                   #256.30
        shrl      $16, %r15d                                    #256.30
        movzbl    %r15b, %eax                                   #256.30
        movd      2048+aes_style_table(,%rax,4), %xmm14         #256.30
        pxor      %xmm14, %xmm12                                #256.30
        shrl      $24, %ebp                                     #256.30
        movd      3072+aes_style_table(,%rbp,4), %xmm15         #256.30
        pxor      %xmm15, %xmm12                                #256.30
        pslldq    $8, %xmm12                                    #256.30
        pxor      %xmm12, %xmm6                                 #256.30
        pxor      %xmm6, %xmm0                                  #256.30
        pslldq    $8, %xmm3                                     #256.30
        pxor      %xmm15, %xmm7                                 #256.30
        pshufb    %xmm5, %xmm0                                  #256.30
        pslldq    $12, %xmm7                                    #256.30
        pxor      %xmm7, %xmm3                                  #256.30
        pslldq    $4, %xmm2                                     #256.30
        pxor      %xmm2, %xmm1                                  #256.30
        pxor      %xmm1, %xmm3                                  #256.30
        movl      $1, %ebp                                      #256.55
        addl      $-6, %edi                                     #256.67
        decq      %rbx                                          #256.60
        movl      %edi, 176(%rsp)                               #256.67
        pshufb    %xmm4, %xmm3                                  #256.30
        pxor      %xmm3, %xmm0                                  #256.30
        movdqa    %xmm0, %xmm1                                  #256.30
        movdqa    %xmm0, %xmm2                                  #256.30
        psrldq    $4, %xmm1                                     #256.30
        psrldq    $8, %xmm2                                     #256.30
        movd      %xmm0, %ecx                                   #256.30
        psrldq    $12, %xmm0                                    #256.30
        movd      %xmm1, %r11d                                  #256.30
        movd      %xmm2, %eax                                   #256.30
        movd      %xmm0, %r9d                                   #256.30
        movl      %eax, 272(%rsp)                               #256.30
        movl      %r9d, 276(%rsp)                               #256.30
        jne       ..B1.10       # Prob 62%                      #257.23
                                # LOE rbx rbp r12 eax edx ecx esi r8d r9d r11d
..B1.7:                         # Preds ..B1.6
        movl      %r11d, 268(%rsp)                              #286.8
        movl      %ecx, 264(%rsp)                               #286.8
        movl      %edx, 200(%rsp)                               #286.8
        jmp       ..B1.19       # Prob 100%                     #286.8
                                # LOE rbx rbp r12
..B1.8:                         # Preds ..B1.5
        cmpq      $2, %rdx                                      #257.17
        ja        ..B1.12       # Prob 50%                      #257.17
                                # LOE rdx rbx rbp r12
..B1.9:                         # Preds ..B1.8
        movl      300(%rsp), %esi                               #257.30
        movl      200(%rsp), %edx                               #257.30
        movl      296(%rsp), %r8d                               #257.30
        movl      264(%rsp), %ecx                               #257.30
        movl      276(%rsp), %r9d                               #257.30
        movl      268(%rsp), %r11d                              #257.30
        movl      272(%rsp), %eax                               #257.30
                                # LOE rbx rbp r12 eax edx ecx esi r8d r9d r11d
..B1.10:                        # Preds ..B1.9 ..B1.6
        xorl      304(%rsp), %ecx                               #257.30
        movq      168(%rsp), %rdi                               #257.30
        movl      (%rdi,%rbp,4), %r13d                          #257.30
        movl      240(%rsp), %edi                               #257.30
        movl      252(%rsp), %r10d                              #257.30
        movl      256(%rsp), %r14d                              #257.30
        movl      260(%rsp), %r15d                              #257.30
        xorl      %r13d, %r8d                                   #257.30
        xorl      %edi, %r11d                                   #257.30
        movl      %r11d, 268(%rsp)                              #257.30
        xorl      %r11d, 192(%rsp)                              #257.30
        xorl      %r11d, %r10d                                  #257.30
        xorl      %eax, %r14d                                   #257.30
        xorl      %eax, 196(%rsp)                               #257.30
        xorl      %r9d, %r15d                                   #257.30
        xorl      %r9d, %edx                                    #257.30
        movl      %edx, 200(%rsp)                               #257.30
        movzbl    %r13b, %edx                                   #257.30
        movd      aes_style_table(,%rdx,4), %xmm6               #257.30
        movdqa    %xmm6, %xmm13                                 #257.30
        movl      %r13d, %r11d                                  #257.30
        shrl      $8, %r11d                                     #257.30
        movzbl    %r11b, %edx                                   #257.30
        movd      1024+aes_style_table(,%rdx,4), %xmm7          #257.30
        pxor      %xmm7, %xmm13                                 #257.30
        movl      %r13d, %r11d                                  #257.30
        shrl      $16, %r11d                                    #257.30
        movzbl    %r11b, %edx                                   #257.30
        movd      2048+aes_style_table(,%rdx,4), %xmm9          #257.30
        pxor      %xmm9, %xmm13                                 #257.30
        shrl      $24, %r13d                                    #257.30
        movd      3072+aes_style_table(,%r13,4), %xmm10         #257.30
        pxor      %xmm10, %xmm13                                #257.30
        pslldq    $12, %xmm13                                   #257.30
        movzbl    %r10b, %edx                                   #257.30
        movd      aes_style_table(,%rdx,4), %xmm8               #257.30
        movl      %r10d, %r11d                                  #257.30
        shrl      $8, %r11d                                     #257.30
        movzbl    %r11b, %r13d                                  #257.30
        movd      1024+aes_style_table(,%r13,4), %xmm11         #257.30
        pxor      %xmm11, %xmm7                                 #257.30
        pxor      %xmm11, %xmm8                                 #257.30
        movl      %r10d, %edx                                   #257.30
        shrl      $16, %edx                                     #257.30
        movzbl    %dl, %r11d                                    #257.30
        movd      2048+aes_style_table(,%r11,4), %xmm12         #257.30
        pxor      %xmm12, %xmm9                                 #257.30
        pxor      %xmm12, %xmm8                                 #257.30
        shrl      $24, %r10d                                    #257.30
        movd      3072+aes_style_table(,%r10,4), %xmm10         #257.30
        pxor      %xmm10, %xmm8                                 #257.30
        pxor      %xmm13, %xmm8                                 #257.30
        movzbl    %r14b, %r10d                                  #257.30
        movd      aes_style_table(,%r10,4), %xmm2               #257.30
        pxor      %xmm2, %xmm6                                  #257.30
        movl      %r14d, %edx                                   #257.30
        shrl      $8, %edx                                      #257.30
        movzbl    %dl, %r11d                                    #257.30
        movd      1024+aes_style_table(,%r11,4), %xmm14         #257.30
        pxor      %xmm14, %xmm2                                 #257.30
        movl      %r14d, %r13d                                  #257.30
        shrl      $16, %r13d                                    #257.30
        movzbl    %r13b, %r10d                                  #257.30
        movd      2048+aes_style_table(,%r10,4), %xmm15         #257.30
        pxor      %xmm15, %xmm9                                 #257.30
        pxor      %xmm15, %xmm2                                 #257.30
        shrl      $24, %r14d                                    #257.30
        movd      3072+aes_style_table(,%r14,4), %xmm0          #257.30
        pxor      %xmm0, %xmm10                                 #257.30
        pxor      %xmm0, %xmm2                                  #257.30
        pslldq    $4, %xmm2                                     #257.30
        movzbl    %r15b, %r10d                                  #257.30
        movd      aes_style_table(,%r10,4), %xmm1               #257.30
        pxor      %xmm1, %xmm6                                  #257.30
        movl      %r15d, %edx                                   #257.30
        shrl      $8, %edx                                      #257.30
        movzbl    %dl, %r11d                                    #257.30
        movd      1024+aes_style_table(,%r11,4), %xmm5          #257.30
        movl      248(%rsp), %r11d                              #257.30
        pxor      %xmm5, %xmm7                                  #257.30
        pxor      %xmm5, %xmm1                                  #257.30
        movl      %r15d, %r10d                                  #257.30
        movdqa    _2il0floatpacket.4(%rip), %xmm5               #257.30
        shrl      $16, %r10d                                    #257.30
        movzbl    %r10b, %r13d                                  #257.30
        movd      2048+aes_style_table(,%r13,4), %xmm4          #257.30
        pxor      %xmm4, %xmm1                                  #257.30
        shrl      $24, %r15d                                    #257.30
        movdqa    _2il0floatpacket.3(%rip), %xmm4               #257.30
        movl      244(%rsp), %r10d                              #257.30
        movd      3072+aes_style_table(,%r15,4), %xmm3          #257.30
        pxor      %xmm3, %xmm1                                  #257.30
        pslldq    $8, %xmm1                                     #257.30
        pxor      %xmm1, %xmm2                                  #257.30
        pxor      %xmm2, %xmm8                                  #257.30
        pshufb    %xmm5, %xmm8                                  #257.30
        pslldq    $8, %xmm9                                     #257.30
        pxor      %xmm3, %xmm10                                 #257.30
        pslldq    $12, %xmm10                                   #257.30
        pxor      %xmm10, %xmm9                                 #257.30
        pslldq    $4, %xmm7                                     #257.30
        pxor      %xmm7, %xmm6                                  #257.30
        pxor      %xmm6, %xmm9                                  #257.30
        pshufb    %xmm4, %xmm9                                  #257.30
        pxor      %xmm9, %xmm8                                  #257.30
        movdqa    %xmm8, %xmm6                                  #257.30
        movdqa    %xmm8, %xmm7                                  #257.30
        incq      %rbp                                          #257.55
        psrldq    $4, %xmm6                                     #257.30
        psrldq    $8, %xmm7                                     #257.30
        movd      %xmm8, %edx                                   #257.30
        psrldq    $12, %xmm8                                    #257.30
        movd      %xmm6, %r14d                                  #257.30
        movd      %xmm7, %r13d                                  #257.30
        movd      %xmm8, %r15d                                  #257.30
        xorl      %r14d, %edi                                   #257.30
        movl      %r14d, 256(%rsp)                              #257.30
        movl      %r13d, 260(%rsp)                              #257.30
        movl      %r15d, 264(%rsp)                              #257.30
        xorl      %r15d, 308(%rsp)                              #257.30
        xorl      %r13d, %r10d                                  #257.30
        xorl      %r15d, %r11d                                  #257.30
        xorl      %esi, %r14d                                   #257.30
        movl      %r14d, 300(%rsp)                              #257.30
        xorl      %r13d, %ecx                                   #257.30
        movl      %ecx, 304(%rsp)                               #257.30
        movzbl    %dl, %esi                                     #257.30
        movd      aes_style_table(,%rsi,4), %xmm1               #257.30
        movdqa    %xmm1, %xmm12                                 #257.30
        movl      %edx, %ecx                                    #257.30
        shrl      $8, %ecx                                      #257.30
        movzbl    %cl, %esi                                     #257.30
        movd      1024+aes_style_table(,%rsi,4), %xmm2          #257.30
        pxor      %xmm2, %xmm12                                 #257.30
        movl      %edx, %r13d                                   #257.30
        shrl      $16, %r13d                                    #257.30
        movzbl    %r13b, %r14d                                  #257.30
        movd      2048+aes_style_table(,%r14,4), %xmm3          #257.30
        pxor      %xmm3, %xmm12                                 #257.30
        shrl      $24, %edx                                     #257.30
        movd      3072+aes_style_table(,%rdx,4), %xmm8          #257.30
        pxor      %xmm8, %xmm12                                 #257.30
        pslldq    $12, %xmm12                                   #257.30
        movzbl    %dil, %r15d                                   #257.30
        movd      aes_style_table(,%r15,4), %xmm0               #257.30
        movl      %edi, %edx                                    #257.30
        shrl      $8, %edx                                      #257.30
        movzbl    %dl, %esi                                     #257.30
        movd      1024+aes_style_table(,%rsi,4), %xmm9          #257.30
        pxor      %xmm9, %xmm2                                  #257.30
        pxor      %xmm9, %xmm0                                  #257.30
        movl      %edi, %ecx                                    #257.30
        shrl      $16, %ecx                                     #257.30
        movzbl    %cl, %r13d                                    #257.30
        movd      2048+aes_style_table(,%r13,4), %xmm11         #257.30
        pxor      %xmm11, %xmm3                                 #257.30
        pxor      %xmm11, %xmm0                                 #257.30
        shrl      $24, %edi                                     #257.30
        movd      3072+aes_style_table(,%rdi,4), %xmm7          #257.30
        pxor      %xmm7, %xmm0                                  #257.30
        pxor      %xmm12, %xmm0                                 #257.30
        movzbl    %r10b, %r14d                                  #257.30
        movd      aes_style_table(,%r14,4), %xmm6               #257.30
        movl      176(%rsp), %r14d                              #257.67
        pxor      %xmm6, %xmm1                                  #257.30
        movl      %r10d, %edx                                   #257.30
        shrl      $8, %edx                                      #257.30
        movzbl    %dl, %r15d                                    #257.30
        movd      1024+aes_style_table(,%r15,4), %xmm13         #257.30
        pxor      %xmm13, %xmm6                                 #257.30
        movl      %r10d, %esi                                   #257.30
        shrl      $16, %esi                                     #257.30
        movzbl    %sil, %edx                                    #257.30
        movd      2048+aes_style_table(,%rdx,4), %xmm14         #257.30
        pxor      %xmm14, %xmm3                                 #257.30
        pxor      %xmm14, %xmm6                                 #257.30
        shrl      $24, %r10d                                    #257.30
        movd      3072+aes_style_table(,%r10,4), %xmm15         #257.30
        pxor      %xmm15, %xmm7                                 #257.30
        pxor      %xmm15, %xmm6                                 #257.30
        pslldq    $4, %xmm6                                     #257.30
        movzbl    %r11b, %edi                                   #257.30
        movd      aes_style_table(,%rdi,4), %xmm12              #257.30
        pxor      %xmm12, %xmm1                                 #257.30
        movl      %r11d, %ecx                                   #257.30
        shrl      $8, %ecx                                      #257.30
        movzbl    %cl, %r13d                                    #257.30
        movd      1024+aes_style_table(,%r13,4), %xmm13         #257.30
        pxor      %xmm13, %xmm2                                 #257.30
        pxor      %xmm13, %xmm12                                #257.30
        movl      %r11d, %edx                                   #257.30
        shrl      $16, %edx                                     #257.30
        movzbl    %dl, %esi                                     #257.30
        movd      2048+aes_style_table(,%rsi,4), %xmm14         #257.30
        pxor      %xmm14, %xmm12                                #257.30
        shrl      $24, %r11d                                    #257.30
        movd      3072+aes_style_table(,%r11,4), %xmm15         #257.30
        pxor      %xmm15, %xmm12                                #257.30
        pslldq    $8, %xmm12                                    #257.30
        pxor      %xmm12, %xmm6                                 #257.30
        pxor      %xmm6, %xmm0                                  #257.30
        pshufb    %xmm5, %xmm0                                  #257.30
        pslldq    $8, %xmm3                                     #257.30
        pxor      %xmm15, %xmm7                                 #257.30
        pslldq    $12, %xmm7                                    #257.30
        pxor      %xmm7, %xmm3                                  #257.30
        pslldq    $4, %xmm2                                     #257.30
        pxor      %xmm2, %xmm1                                  #257.30
        pxor      %xmm1, %xmm3                                  #257.30
        pshufb    %xmm4, %xmm3                                  #257.30
        pxor      %xmm3, %xmm0                                  #257.30
        movdqa    %xmm0, %xmm1                                  #257.30
        movdqa    %xmm0, %xmm2                                  #257.30
        addl      $-6, %r14d                                    #257.67
        movl      %r14d, 176(%rsp)                              #257.67
        psrldq    $4, %xmm1                                     #257.30
        psrldq    $8, %xmm2                                     #257.30
        movd      %xmm0, %edx                                   #257.30
        psrldq    $12, %xmm0                                    #257.30
        decq      %rbx                                          #257.60
        movd      %xmm1, %r10d                                  #257.30
        movd      %xmm2, %esi                                   #257.30
        movl      %esi, 248(%rsp)                               #257.30
        movd      %xmm0, %edi                                   #257.30
        movl      %edi, 252(%rsp)                               #257.30
        jne       ..B1.14       # Prob 62%                      #258.23
                                # LOE rbx rbp r12 eax edx esi edi r8d r9d r10d
..B1.11:                        # Preds ..B1.10
        movl      %r10d, 244(%rsp)                              #289.5
        movl      %edx, 240(%rsp)                               #289.5
        movl      %r8d, 296(%rsp)                               #289.5
        jmp       ..B1.19       # Prob 100%                     #289.5
                                # LOE rbx rbp r12
..B1.12:                        # Preds ..B1.8
        cmpq      $3, %rdx                                      #258.17
        ja        ..B1.16       # Prob 50%                      #258.17
                                # LOE rdx rbx rbp r12
..B1.13:                        # Preds ..B1.12
        movl      240(%rsp), %edx                               #258.30
        movl      244(%rsp), %r10d                              #258.30
        movl      248(%rsp), %esi                               #258.30
        movl      296(%rsp), %r8d                               #258.30
        movl      276(%rsp), %r9d                               #258.30
        movl      272(%rsp), %eax                               #258.30
        movl      252(%rsp), %edi                               #258.30
                                # LOE rbx rbp r12 eax edx esi edi r8d r9d r10d
..B1.14:                        # Preds ..B1.13 ..B1.10
        xorl      280(%rsp), %edx                               #258.30
        movq      168(%rsp), %rcx                               #258.30
        movl      (%rcx,%rbp,4), %r11d                          #258.30
        movl      216(%rsp), %ecx                               #258.30
        movl      228(%rsp), %r14d                              #258.30
        movl      232(%rsp), %r13d                              #258.30
        movl      236(%rsp), %r15d                              #258.30
        xorl      %r11d, %eax                                   #258.30
        xorl      %ecx, %r10d                                   #258.30
        movl      %r10d, 244(%rsp)                              #258.30
        xorl      %r10d, 288(%rsp)                              #258.30
        xorl      %r10d, %r14d                                  #258.30
        xorl      %esi, %r13d                                   #258.30
        xorl      %esi, 292(%rsp)                               #258.30
        xorl      %edi, %r15d                                   #258.30
        xorl      %edi, %r8d                                    #258.30
        movl      %r8d, 296(%rsp)                               #258.30
        movzbl    %r11b, %r8d                                   #258.30
        movd      aes_style_table(,%r8,4), %xmm6                #258.30
        movdqa    %xmm6, %xmm13                                 #258.30
        movl      %r11d, %r10d                                  #258.30
        shrl      $8, %r10d                                     #258.30
        movzbl    %r10b, %r8d                                   #258.30
        movd      1024+aes_style_table(,%r8,4), %xmm7           #258.30
        pxor      %xmm7, %xmm13                                 #258.30
        movl      %r11d, %r10d                                  #258.30
        shrl      $16, %r10d                                    #258.30
        movzbl    %r10b, %r8d                                   #258.30
        movd      2048+aes_style_table(,%r8,4), %xmm9           #258.30
        pxor      %xmm9, %xmm13                                 #258.30
        shrl      $24, %r11d                                    #258.30
        movd      3072+aes_style_table(,%r11,4), %xmm10         #258.30
        pxor      %xmm10, %xmm13                                #258.30
        pslldq    $12, %xmm13                                   #258.30
        movzbl    %r14b, %r8d                                   #258.30
        movd      aes_style_table(,%r8,4), %xmm8                #258.30
        movl      %r14d, %r10d                                  #258.30
        shrl      $8, %r10d                                     #258.30
        movzbl    %r10b, %r11d                                  #258.30
        movd      1024+aes_style_table(,%r11,4), %xmm11         #258.30
        pxor      %xmm11, %xmm7                                 #258.30
        pxor      %xmm11, %xmm8                                 #258.30
        movl      %r14d, %r8d                                   #258.30
        shrl      $16, %r8d                                     #258.30
        movzbl    %r8b, %r10d                                   #258.30
        movd      2048+aes_style_table(,%r10,4), %xmm12         #258.30
        pxor      %xmm12, %xmm9                                 #258.30
        pxor      %xmm12, %xmm8                                 #258.30
        shrl      $24, %r14d                                    #258.30
        movd      3072+aes_style_table(,%r14,4), %xmm10         #258.30
        pxor      %xmm10, %xmm8                                 #258.30
        pxor      %xmm13, %xmm8                                 #258.30
        movzbl    %r13b, %r14d                                  #258.30
        movd      aes_style_table(,%r14,4), %xmm2               #258.30
        pxor      %xmm2, %xmm6                                  #258.30
        movl      %r13d, %r8d                                   #258.30
        shrl      $8, %r8d                                      #258.30
        movzbl    %r8b, %r10d                                   #258.30
        movd      1024+aes_style_table(,%r10,4), %xmm14         #258.30
        pxor      %xmm14, %xmm2                                 #258.30
        movl      %r13d, %r11d                                  #258.30
        shrl      $16, %r11d                                    #258.30
        movzbl    %r11b, %r14d                                  #258.30
        movd      2048+aes_style_table(,%r14,4), %xmm15         #258.30
        pxor      %xmm15, %xmm9                                 #258.30
        pxor      %xmm15, %xmm2                                 #258.30
        shrl      $24, %r13d                                    #258.30
        movd      3072+aes_style_table(,%r13,4), %xmm0          #258.30
        pxor      %xmm0, %xmm10                                 #258.30
        pxor      %xmm0, %xmm2                                  #258.30
        pslldq    $4, %xmm2                                     #258.30
        movzbl    %r15b, %r14d                                  #258.30
        movd      aes_style_table(,%r14,4), %xmm1               #258.30
        pxor      %xmm1, %xmm6                                  #258.30
        movl      %r15d, %r8d                                   #258.30
        shrl      $8, %r8d                                      #258.30
        movzbl    %r8b, %r10d                                   #258.30
        movd      1024+aes_style_table(,%r10,4), %xmm5          #258.30
        movl      224(%rsp), %r10d                              #258.30
        pxor      %xmm5, %xmm7                                  #258.30
        pxor      %xmm5, %xmm1                                  #258.30
        movl      %r15d, %r14d                                  #258.30
        movdqa    _2il0floatpacket.4(%rip), %xmm5               #258.30
        shrl      $16, %r14d                                    #258.30
        movzbl    %r14b, %r11d                                  #258.30
        movd      2048+aes_style_table(,%r11,4), %xmm4          #258.30
        pxor      %xmm4, %xmm1                                  #258.30
        shrl      $24, %r15d                                    #258.30
        movdqa    _2il0floatpacket.3(%rip), %xmm4               #258.30
        movl      220(%rsp), %r14d                              #258.30
        movd      3072+aes_style_table(,%r15,4), %xmm3          #258.30
        pxor      %xmm3, %xmm1                                  #258.30
        pslldq    $8, %xmm1                                     #258.30
        pxor      %xmm1, %xmm2                                  #258.30
        pxor      %xmm2, %xmm8                                  #258.30
        pshufb    %xmm5, %xmm8                                  #258.30
        pslldq    $8, %xmm9                                     #258.30
        pxor      %xmm3, %xmm10                                 #258.30
        pslldq    $12, %xmm10                                   #258.30
        pxor      %xmm10, %xmm9                                 #258.30
        pslldq    $4, %xmm7                                     #258.30
        pxor      %xmm7, %xmm6                                  #258.30
        pxor      %xmm6, %xmm9                                  #258.30
        pshufb    %xmm4, %xmm9                                  #258.30
        pxor      %xmm9, %xmm8                                  #258.30
        movdqa    %xmm8, %xmm6                                  #258.30
        movdqa    %xmm8, %xmm7                                  #258.30
        incq      %rbp                                          #258.55
        psrldq    $4, %xmm6                                     #258.30
        psrldq    $8, %xmm7                                     #258.30
        movd      %xmm8, %r8d                                   #258.30
        psrldq    $12, %xmm8                                    #258.30
        movd      %xmm6, %r13d                                  #258.30
        movd      %xmm7, %r11d                                  #258.30
        movd      %xmm8, %r15d                                  #258.30
        xorl      %r13d, %ecx                                   #258.30
        movl      %r13d, 232(%rsp)                              #258.30
        movl      %r11d, 236(%rsp)                              #258.30
        movl      %r15d, 240(%rsp)                              #258.30
        xorl      %r15d, 284(%rsp)                              #258.30
        xorl      %r11d, %r14d                                  #258.30
        xorl      %r15d, %r10d                                  #258.30
        xorl      %r9d, %r13d                                   #258.30
        movl      %r13d, 276(%rsp)                              #258.30
        xorl      %r11d, %edx                                   #258.30
        movl      %edx, 280(%rsp)                               #258.30
        movzbl    %r8b, %edx                                    #258.30
        movd      aes_style_table(,%rdx,4), %xmm1               #258.30
        movdqa    %xmm1, %xmm12                                 #258.30
        movl      %r8d, %r9d                                    #258.30
        shrl      $8, %r9d                                      #258.30
        movzbl    %r9b, %edx                                    #258.30
        movd      1024+aes_style_table(,%rdx,4), %xmm2          #258.30
        pxor      %xmm2, %xmm12                                 #258.30
        movl      %r8d, %r11d                                   #258.30
        shrl      $16, %r11d                                    #258.30
        movzbl    %r11b, %r13d                                  #258.30
        movd      2048+aes_style_table(,%r13,4), %xmm3          #258.30
        pxor      %xmm3, %xmm12                                 #258.30
        shrl      $24, %r8d                                     #258.30
        movd      3072+aes_style_table(,%r8,4), %xmm8           #258.30
        pxor      %xmm8, %xmm12                                 #258.30
        pslldq    $12, %xmm12                                   #258.30
        movzbl    %cl, %r15d                                    #258.30
        movd      aes_style_table(,%r15,4), %xmm0               #258.30
        movl      %ecx, %edx                                    #258.30
        shrl      $8, %edx                                      #258.30
        movzbl    %dl, %r8d                                     #258.30
        movd      1024+aes_style_table(,%r8,4), %xmm9           #258.30
        pxor      %xmm9, %xmm2                                  #258.30
        pxor      %xmm9, %xmm0                                  #258.30
        movl      %ecx, %r9d                                    #258.30
        shrl      $16, %r9d                                     #258.30
        movzbl    %r9b, %r11d                                   #258.30
        movd      2048+aes_style_table(,%r11,4), %xmm11         #258.30
        pxor      %xmm11, %xmm3                                 #258.30
        pxor      %xmm11, %xmm0                                 #258.30
        shrl      $24, %ecx                                     #258.30
        movd      3072+aes_style_table(,%rcx,4), %xmm7          #258.30
        pxor      %xmm7, %xmm0                                  #258.30
        pxor      %xmm12, %xmm0                                 #258.30
        movzbl    %r14b, %r13d                                  #258.30
        movd      aes_style_table(,%r13,4), %xmm6               #258.30
        movl      176(%rsp), %r13d                              #258.67
        pxor      %xmm6, %xmm1                                  #258.30
        movl      %r14d, %edx                                   #258.30
        shrl      $8, %edx                                      #258.30
        movzbl    %dl, %r15d                                    #258.30
        movd      1024+aes_style_table(,%r15,4), %xmm13         #258.30
        pxor      %xmm13, %xmm6                                 #258.30
        movl      %r14d, %ecx                                   #258.30
        shrl      $16, %ecx                                     #258.30
        movzbl    %cl, %edx                                     #258.30
        movd      2048+aes_style_table(,%rdx,4), %xmm14         #258.30
        pxor      %xmm14, %xmm3                                 #258.30
        pxor      %xmm14, %xmm6                                 #258.30
        shrl      $24, %r14d                                    #258.30
        movd      3072+aes_style_table(,%r14,4), %xmm15         #258.30
        pxor      %xmm15, %xmm7                                 #258.30
        pxor      %xmm15, %xmm6                                 #258.30
        pslldq    $4, %xmm6                                     #258.30
        movzbl    %r10b, %r8d                                   #258.30
        movd      aes_style_table(,%r8,4), %xmm12               #258.30
        pxor      %xmm12, %xmm1                                 #258.30
        movl      %r10d, %r9d                                   #258.30
        shrl      $8, %r9d                                      #258.30
        movzbl    %r9b, %r11d                                   #258.30
        movd      1024+aes_style_table(,%r11,4), %xmm13         #258.30
        pxor      %xmm13, %xmm2                                 #258.30
        pxor      %xmm13, %xmm12                                #258.30
        movl      %r10d, %edx                                   #258.30
        shrl      $16, %edx                                     #258.30
        movzbl    %dl, %ecx                                     #258.30
        movd      2048+aes_style_table(,%rcx,4), %xmm14         #258.30
        pxor      %xmm14, %xmm12                                #258.30
        shrl      $24, %r10d                                    #258.30
        movd      3072+aes_style_table(,%r10,4), %xmm15         #258.30
        pxor      %xmm15, %xmm12                                #258.30
        pslldq    $8, %xmm12                                    #258.30
        pxor      %xmm12, %xmm6                                 #258.30
        pxor      %xmm6, %xmm0                                  #258.30
        pshufb    %xmm5, %xmm0                                  #258.30
        pslldq    $8, %xmm3                                     #258.30
        pxor      %xmm15, %xmm7                                 #258.30
        pslldq    $12, %xmm7                                    #258.30
        pxor      %xmm7, %xmm3                                  #258.30
        pslldq    $4, %xmm2                                     #258.30
        pxor      %xmm2, %xmm1                                  #258.30
        pxor      %xmm1, %xmm3                                  #258.30
        pshufb    %xmm4, %xmm3                                  #258.30
        pxor      %xmm3, %xmm0                                  #258.30
        movdqa    %xmm0, %xmm1                                  #258.30
        movdqa    %xmm0, %xmm2                                  #258.30
        addl      $-6, %r13d                                    #258.67
        movl      %r13d, 176(%rsp)                              #258.67
        psrldq    $4, %xmm1                                     #258.30
        psrldq    $8, %xmm2                                     #258.30
        movd      %xmm0, %edx                                   #258.30
        psrldq    $12, %xmm0                                    #258.30
        decq      %rbx                                          #258.60
        movd      %xmm1, %r14d                                  #258.30
        movd      %xmm2, %r8d                                   #258.30
        movl      %r8d, 224(%rsp)                               #258.30
        movd      %xmm0, %ecx                                   #258.30
        movl      %ecx, 228(%rsp)                               #258.30
        jne       ..B1.18       # Prob 62%                      #259.23
                                # LOE rbx rbp r12 eax edx ecx esi edi r8d r14d
..B1.15:                        # Preds ..B1.14
        movl      %eax, 272(%rsp)                               #289.5
        movl      %r14d, 220(%rsp)                              #289.5
        movl      %edx, 216(%rsp)                               #289.5
        jmp       ..B1.19       # Prob 100%                     #289.5
                                # LOE rbx rbp r12
..B1.16:                        # Preds ..B1.12
        cmpq      $4, %rdx                                      #259.17
        ja        ..B1.19       # Prob 50%                      #259.17
                                # LOE rbx rbp r12
..B1.17:                        # Preds ..B1.16
        movl      224(%rsp), %r8d                               #259.30
        movl      248(%rsp), %esi                               #259.30
        movl      228(%rsp), %ecx                               #259.30
        movl      216(%rsp), %edx                               #259.30
        movl      220(%rsp), %r14d                              #259.30
        movl      272(%rsp), %eax                               #259.30
        movl      252(%rsp), %edi                               #259.30
                                # LOE rbx rbp r12 eax edx ecx esi edi r8d r14d
..B1.18:                        # Preds ..B1.17 ..B1.14
        xorl      256(%rsp), %edx                               #259.30
        movq      168(%rsp), %r15                               #259.30
        movl      (%r15,%rbp,4), %r13d                          #259.30
        movl      204(%rsp), %r9d                               #259.30
        movl      208(%rsp), %r10d                              #259.30
        movl      212(%rsp), %r11d                              #259.30
        xorl      %r8d, 268(%rsp)                               #259.30
        xorl      %r13d, %esi                                   #259.30
        movl      %esi, 248(%rsp)                               #259.30
        movl      192(%rsp), %esi                               #259.30
        xorl      %esi, %r14d                                   #259.30
        movl      %r14d, 220(%rsp)                              #259.30
        xorl      %r14d, %r9d                                   #259.30
        xorl      %r14d, 264(%rsp)                              #259.30
        xorl      %r8d, %r10d                                   #259.30
        xorl      %ecx, %r11d                                   #259.30
        xorl      %ecx, %eax                                    #259.30
        movl      %eax, 272(%rsp)                               #259.30
        movzbl    %r13b, %r14d                                  #259.30
        movd      aes_style_table(,%r14,4), %xmm6               #259.30
        movdqa    %xmm6, %xmm13                                 #259.30
        movl      %r13d, %r8d                                   #259.30
        shrl      $8, %r8d                                      #259.30
        movzbl    %r8b, %ecx                                    #259.30
        movd      1024+aes_style_table(,%rcx,4), %xmm7          #259.30
        pxor      %xmm7, %xmm13                                 #259.30
        movl      %r13d, %eax                                   #259.30
        shrl      $16, %eax                                     #259.30
        movzbl    %al, %r14d                                    #259.30
        movd      2048+aes_style_table(,%r14,4), %xmm9          #259.30
        pxor      %xmm9, %xmm13                                 #259.30
        shrl      $24, %r13d                                    #259.30
        movd      3072+aes_style_table(,%r13,4), %xmm10         #259.30
        pxor      %xmm10, %xmm13                                #259.30
        pslldq    $12, %xmm13                                   #259.30
        movzbl    %r9b, %r15d                                   #259.30
        movd      aes_style_table(,%r15,4), %xmm8               #259.30
        movl      %r9d, %r8d                                    #259.30
        shrl      $8, %r8d                                      #259.30
        movzbl    %r8b, %ecx                                    #259.30
        movd      1024+aes_style_table(,%rcx,4), %xmm11         #259.30
        pxor      %xmm11, %xmm7                                 #259.30
        pxor      %xmm11, %xmm8                                 #259.30
        movl      %r9d, %eax                                    #259.30
        shrl      $16, %eax                                     #259.30
        movzbl    %al, %r13d                                    #259.30
        movd      2048+aes_style_table(,%r13,4), %xmm12         #259.30
        pxor      %xmm12, %xmm9                                 #259.30
        pxor      %xmm12, %xmm8                                 #259.30
        shrl      $24, %r9d                                     #259.30
        movd      3072+aes_style_table(,%r9,4), %xmm10          #259.30
        pxor      %xmm10, %xmm8                                 #259.30
        pxor      %xmm13, %xmm8                                 #259.30
        movzbl    %r10b, %r14d                                  #259.30
        movd      aes_style_table(,%r14,4), %xmm2               #259.30
        pxor      %xmm2, %xmm6                                  #259.30
        movl      %r10d, %r8d                                   #259.30
        shrl      $8, %r8d                                      #259.30
        movzbl    %r8b, %r15d                                   #259.30
        movd      1024+aes_style_table(,%r15,4), %xmm14         #259.30
        pxor      %xmm14, %xmm2                                 #259.30
        movl      %r10d, %ecx                                   #259.30
        shrl      $16, %ecx                                     #259.30
        movzbl    %cl, %r8d                                     #259.30
        movd      2048+aes_style_table(,%r8,4), %xmm15          #259.30
        pxor      %xmm15, %xmm9                                 #259.30
        pxor      %xmm15, %xmm2                                 #259.30
        shrl      $24, %r10d                                    #259.30
        movd      3072+aes_style_table(,%r10,4), %xmm0          #259.30
        pxor      %xmm0, %xmm10                                 #259.30
        pxor      %xmm0, %xmm2                                  #259.30
        pslldq    $4, %xmm2                                     #259.30
        movzbl    %r11b, %eax                                   #259.30
        movd      aes_style_table(,%rax,4), %xmm1               #259.30
        pxor      %xmm1, %xmm6                                  #259.30
        movl      %r11d, %r9d                                   #259.30
        shrl      $8, %r9d                                      #259.30
        movzbl    %r9b, %r13d                                   #259.30
        movd      1024+aes_style_table(,%r13,4), %xmm5          #259.30
        pxor      %xmm5, %xmm7                                  #259.30
        pxor      %xmm5, %xmm1                                  #259.30
        movdqa    _2il0floatpacket.4(%rip), %xmm5               #259.30
        movl      %r11d, %r8d                                   #259.30
        shrl      $16, %r8d                                     #259.30
        movzbl    %r8b, %ecx                                    #259.30
        movl      200(%rsp), %r8d                               #259.30
        movd      2048+aes_style_table(,%rcx,4), %xmm4          #259.30
        movl      196(%rsp), %ecx                               #259.30
        pxor      %xmm4, %xmm1                                  #259.30
        shrl      $24, %r11d                                    #259.30
        movdqa    _2il0floatpacket.3(%rip), %xmm4               #259.30
        movd      3072+aes_style_table(,%r11,4), %xmm3          #259.30
        pxor      %xmm3, %xmm1                                  #259.30
        pslldq    $8, %xmm1                                     #259.30
        pxor      %xmm1, %xmm2                                  #259.30
        pxor      %xmm2, %xmm8                                  #259.30
        pslldq    $8, %xmm9                                     #259.30
        pshufb    %xmm5, %xmm8                                  #259.30
        pxor      %xmm3, %xmm10                                 #259.30
        pslldq    $12, %xmm10                                   #259.30
        pxor      %xmm10, %xmm9                                 #259.30
        pslldq    $4, %xmm7                                     #259.30
        pxor      %xmm7, %xmm6                                  #259.30
        pxor      %xmm6, %xmm9                                  #259.30
        incq      %rbp                                          #259.55
        decq      %rbx                                          #259.60
        pshufb    %xmm4, %xmm9                                  #259.30
        pxor      %xmm9, %xmm8                                  #259.30
        movdqa    %xmm8, %xmm6                                  #259.30
        movdqa    %xmm8, %xmm7                                  #259.30
        psrldq    $4, %xmm6                                     #259.30
        psrldq    $8, %xmm7                                     #259.30
        movd      %xmm8, %eax                                   #259.30
        psrldq    $12, %xmm8                                    #259.30
        movd      %xmm6, %r10d                                  #259.30
        movd      %xmm7, %r14d                                  #259.30
        movd      %xmm8, %r15d                                  #259.30
        xorl      %r10d, %esi                                   #259.30
        movl      %r10d, 208(%rsp)                              #259.30
        movl      %r14d, 212(%rsp)                              #259.30
        movl      %r15d, 216(%rsp)                              #259.30
        xorl      %r15d, 260(%rsp)                              #259.30
        xorl      %r14d, %ecx                                   #259.30
        xorl      %r15d, %r8d                                   #259.30
        xorl      %edi, %r10d                                   #259.30
        movl      %r10d, 252(%rsp)                              #259.30
        xorl      %r14d, %edx                                   #259.30
        movl      %eax, %edi                                    #259.30
        movl      %edx, 256(%rsp)                               #259.30
        movzbl    %al, %edx                                     #259.30
        movd      aes_style_table(,%rdx,4), %xmm1               #259.30
        movdqa    %xmm1, %xmm12                                 #259.30
        shrl      $8, %edi                                      #259.30
        movzbl    %dil, %edx                                    #259.30
        movd      1024+aes_style_table(,%rdx,4), %xmm2          #259.30
        pxor      %xmm2, %xmm12                                 #259.30
        movl      %eax, %r9d                                    #259.30
        shrl      $16, %r9d                                     #259.30
        movzbl    %r9b, %r10d                                   #259.30
        movd      2048+aes_style_table(,%r10,4), %xmm3          #259.30
        pxor      %xmm3, %xmm12                                 #259.30
        shrl      $24, %eax                                     #259.30
        movd      3072+aes_style_table(,%rax,4), %xmm8          #259.30
        pxor      %xmm8, %xmm12                                 #259.30
        pslldq    $12, %xmm12                                   #259.30
        movzbl    %sil, %r11d                                   #259.30
        movd      aes_style_table(,%r11,4), %xmm0               #259.30
        movl      %esi, %r13d                                   #259.30
        shrl      $8, %r13d                                     #259.30
        movzbl    %r13b, %r14d                                  #259.30
        movd      1024+aes_style_table(,%r14,4), %xmm9          #259.30
        pxor      %xmm9, %xmm2                                  #259.30
        pxor      %xmm9, %xmm0                                  #259.30
        movl      %esi, %r15d                                   #259.30
        shrl      $16, %r15d                                    #259.30
        movzbl    %r15b, %eax                                   #259.30
        movd      2048+aes_style_table(,%rax,4), %xmm11         #259.30
        pxor      %xmm11, %xmm3                                 #259.30
        pxor      %xmm11, %xmm0                                 #259.30
        shrl      $24, %esi                                     #259.30
        movd      3072+aes_style_table(,%rsi,4), %xmm7          #259.30
        pxor      %xmm7, %xmm0                                  #259.30
        pxor      %xmm12, %xmm0                                 #259.30
        movzbl    %cl, %edx                                     #259.30
        movd      aes_style_table(,%rdx,4), %xmm6               #259.30
        movl      176(%rsp), %edx                               #259.67
        pxor      %xmm6, %xmm1                                  #259.30
        movl      %ecx, %edi                                    #259.30
        shrl      $8, %edi                                      #259.30
        movzbl    %dil, %r9d                                    #259.30
        movd      1024+aes_style_table(,%r9,4), %xmm13          #259.30
        pxor      %xmm13, %xmm6                                 #259.30
        movl      %ecx, %r10d                                   #259.30
        shrl      $16, %r10d                                    #259.30
        movzbl    %r10b, %r11d                                  #259.30
        movd      2048+aes_style_table(,%r11,4), %xmm14         #259.30
        pxor      %xmm14, %xmm3                                 #259.30
        pxor      %xmm14, %xmm6                                 #259.30
        shrl      $24, %ecx                                     #259.30
        movd      3072+aes_style_table(,%rcx,4), %xmm15         #259.30
        pxor      %xmm15, %xmm7                                 #259.30
        pxor      %xmm15, %xmm6                                 #259.30
        pslldq    $4, %xmm6                                     #259.30
        movzbl    %r8b, %eax                                    #259.30
        movd      aes_style_table(,%rax,4), %xmm12              #259.30
        pxor      %xmm12, %xmm1                                 #259.30
        movl      %r8d, %esi                                    #259.30
        shrl      $8, %esi                                      #259.30
        movzbl    %sil, %r13d                                   #259.30
        movd      1024+aes_style_table(,%r13,4), %xmm13         #259.30
        pxor      %xmm13, %xmm2                                 #259.30
        pxor      %xmm13, %xmm12                                #259.30
        movl      %r8d, %r14d                                   #259.30
        shrl      $16, %r14d                                    #259.30
        movzbl    %r14b, %r15d                                  #259.30
        movd      2048+aes_style_table(,%r15,4), %xmm14         #259.30
        pxor      %xmm14, %xmm12                                #259.30
        shrl      $24, %r8d                                     #259.30
        movd      3072+aes_style_table(,%r8,4), %xmm15          #259.30
        pxor      %xmm15, %xmm12                                #259.30
        pslldq    $8, %xmm12                                    #259.30
        pxor      %xmm12, %xmm6                                 #259.30
        pxor      %xmm6, %xmm0                                  #259.30
        pshufb    %xmm5, %xmm0                                  #259.30
        pslldq    $8, %xmm3                                     #259.30
        pxor      %xmm15, %xmm7                                 #259.30
        pslldq    $12, %xmm7                                    #259.30
        pxor      %xmm7, %xmm3                                  #259.30
        pslldq    $4, %xmm2                                     #259.30
        pxor      %xmm2, %xmm1                                  #259.30
        pxor      %xmm1, %xmm3                                  #259.30
        pshufb    %xmm4, %xmm3                                  #259.30
        pxor      %xmm3, %xmm0                                  #259.30
        movdqa    %xmm0, %xmm1                                  #259.30
        movdqa    %xmm0, %xmm2                                  #259.30
        movd      %xmm0, 192(%rsp)                              #259.30
        psrldq    $12, %xmm0                                    #259.30
        psrldq    $4, %xmm1                                     #259.30
        movd      %xmm1, 196(%rsp)                              #259.30
        movd      %xmm0, 204(%rsp)                              #259.30
        psrldq    $8, %xmm2                                     #259.30
        movd      %xmm2, 200(%rsp)                              #259.30
        addl      $-6, %edx                                     #259.67
        movl      %edx, 176(%rsp)                               #259.67
                                # LOE rbx rbp r12
..B1.19:                        # Preds ..B1.11 ..B1.7 ..B1.18 ..B1.15 ..B1.16
                                #       ..B1.4 ..B1.3
        movq      %rbp, 344(%rsp)                               #
        movq      %rbx, %rax                                    #263.21
        movq      $0xcccccccccccccccd, %rcx                     #263.5
        mulq      %rcx                                          #263.21
        shrq      $2, %rdx                                      #263.21
        movq      %rdx, 368(%rsp)                               #263.21
        lea       (%rdx,%rdx,4), %rsi                           #263.21
        negq      %rsi                                          #263.21
        addq      %rsi, %rbx                                    #263.15
        call      rdtsc                                         #266.15
                                # LOE rax rbx rbp r12 ebp bpl
..B1.20:                        # Preds ..B1.19
        movq      368(%rsp), %rcx                               #268.19
        movslq    %eax, %rax                                    #266.5
        movq      %rax, 40(%rsp)                                #266.5
        xorl      %edx, %edx                                    #268.5
        testq     %rcx, %rcx                                    #268.19
        movq      %rdx, 360(%rsp)                               #268.5
        movq      %rdx, 352(%rsp)                               #
        jbe       ..B1.24       # Prob 10%                      #268.19
                                # LOE rbx rbp r12 ebp bpl
..B1.21:                        # Preds ..B1.20
        movl      232(%rsp), %eax                               #270.7
        movl      192(%rsp), %edx                               #270.7
        movl      196(%rsp), %r14d                              #270.7
        movl      300(%rsp), %r13d                              #270.7
        movl      304(%rsp), %ecx                               #270.7
        movl      200(%rsp), %r10d                              #270.7
        movl      308(%rsp), %r11d                              #270.7
        movl      240(%rsp), %r9d                               #270.7
        movl      244(%rsp), %r8d                               #270.7
        movl      248(%rsp), %esi                               #270.7
        movl      296(%rsp), %edi                               #270.7
        movl      208(%rsp), %r15d                              #271.7
        movdqa    _2il0floatpacket.4(%rip), %xmm0               #
        movdqa    _2il0floatpacket.3(%rip), %xmm1               #
        movl      %edx, 56(%rsp)                                #270.7
        movl      224(%rsp), %edx                               #270.7
        movl      %r14d, 32(%rsp)                               #270.7
        movl      288(%rsp), %r14d                              #270.7
        movl      %r13d, 144(%rsp)                              #270.7
        movl      204(%rsp), %r13d                              #270.7
        movl      %ecx, 384(%rsp)                               #270.7
        movl      292(%rsp), %ecx                               #270.7
        movl      %r10d, 24(%rsp)                               #270.7
        movl      228(%rsp), %r10d                              #270.7
        movl      %r11d, 64(%rsp)                               #270.7
        movl      236(%rsp), %r11d                              #270.7
        movl      %r9d, 104(%rsp)                               #270.7
        movl      264(%rsp), %r9d                               #271.7
        movl      %r8d, 328(%rsp)                               #270.7
        movl      276(%rsp), %r8d                               #271.7
        movl      %esi, 392(%rsp)                               #270.7
        movl      280(%rsp), %esi                               #271.7
        movl      %edi, 376(%rsp)                               #270.7
        movl      284(%rsp), %edi                               #271.7
        movl      %r15d, 408(%rsp)                              #271.7
        movl      220(%rsp), %r15d                              #271.7
        movl      %r8d, 128(%rsp)                               #271.7
        movl      216(%rsp), %r8d                               #271.7
        movl      %esi, 336(%rsp)                               #271.7
        movl      272(%rsp), %esi                               #271.7
        movl      %edi, 72(%rsp)                                #271.7
        movl      268(%rsp), %edi                               #271.7
        movl      %r15d, 416(%rsp)                              #271.7
        movl      212(%rsp), %r15d                              #271.7
        movl      %r15d, 80(%rsp)                               #271.7
        movl      252(%rsp), %r15d                              #272.7
        movl      %r15d, 112(%rsp)                              #272.7
        movl      256(%rsp), %r15d                              #272.7
        movl      %r15d, 400(%rsp)                              #272.7
        movl      260(%rsp), %r15d                              #272.7
        movl      %r15d, 88(%rsp)                               #272.7
        movq      168(%rsp), %r15                               #
        movl      %r11d, 96(%rsp)                               #
        movl      376(%rsp), %r11d                              #
        lea       (%r15,%rbp,4), %rbp                           #
        movl      %r13d, 320(%rsp)                              #
        movl      416(%rsp), %r13d                              #
        movl      %r9d, 120(%rsp)                               #
        movl      384(%rsp), %r9d                               #
        movl      %r8d, 160(%rsp)                               #
        movl      392(%rsp), %r8d                               #
        movl      %r10d, 312(%rsp)                              #
        movl      24(%rsp), %r10d                               #
        movq      %rbp, 48(%rsp)                                #
        movl      32(%rsp), %ebp                                #
        movl      %r14d, 136(%rsp)                              #
        movq      %rbx, 8(%rsp)                                 #
        movl      400(%rsp), %ebx                               #
        movq      %r12, 16(%rsp)                                #
        movl      408(%rsp), %r12d                              #
                                # LOE eax edx ecx ebx ebp esi edi r8d r9d r10d r11d r12d r13d xmm0 xmm1
..B1.22:                        # Preds ..B1.49 ..B1.21
        xorl      56(%rsp), %eax                                #270.7
        movl      144(%rsp), %r15d                              #270.7
        movl      64(%rsp), %r14d                               #270.7
        xorl      %r10d, 328(%rsp)                              #270.7
        xorl      %r10d, %r9d                                   #270.7
        movl      %r13d, 416(%rsp)                              #
        movq      352(%rsp), %r13                               #270.7
        movl      %edi, 424(%rsp)                               #
        movq      48(%rsp), %rdi                                #270.7
        movl      %esi, 432(%rsp)                               #
        movl      (%rdi,%r13,4), %esi                           #270.7
        movl      %ebx, 400(%rsp)                               #
        movl      320(%rsp), %ebx                               #270.7
        xorl      %esi, %edx                                    #270.7
        movl      %edx, 440(%rsp)                               #270.7
        xorl      %ebx, %r14d                                   #270.7
        xorl      %ebx, %r8d                                    #270.7
        movl      136(%rsp), %edx                               #270.7
        movl      %r8d, 392(%rsp)                               #270.7
        xorl      %edx, %ebp                                    #270.7
        xorl      %ebp, 104(%rsp)                               #270.7
        xorl      %ebp, %r15d                                   #270.7
        movzbl    %sil, %r8d                                    #270.7
        movd      aes_style_table(,%r8,4), %xmm11               #270.7
        movdqa    %xmm11, %xmm3                                 #270.7
        movl      %esi, %r8d                                    #270.7
        shrl      $8, %r8d                                      #270.7
        movzbl    %r8b, %r8d                                    #270.7
        movd      1024+aes_style_table(,%r8,4), %xmm12          #270.7
        pxor      %xmm12, %xmm3                                 #270.7
        movl      %esi, %r8d                                    #270.7
        shrl      $16, %r8d                                     #270.7
        movzbl    %r8b, %r8d                                    #270.7
        movd      2048+aes_style_table(,%r8,4), %xmm13          #270.7
        pxor      %xmm13, %xmm3                                 #270.7
        shrl      $24, %esi                                     #270.7
        movd      3072+aes_style_table(,%rsi,4), %xmm14         #270.7
        pxor      %xmm14, %xmm3                                 #270.7
        pslldq    $12, %xmm3                                    #270.7
        movzbl    %r15b, %esi                                   #270.7
        movd      aes_style_table(,%rsi,4), %xmm10              #270.7
        movl      %r15d, %r8d                                   #270.7
        shrl      $8, %r8d                                      #270.7
        movzbl    %r8b, %esi                                    #270.7
        movd      1024+aes_style_table(,%rsi,4), %xmm15         #270.7
        pxor      %xmm15, %xmm12                                #270.7
        pxor      %xmm15, %xmm10                                #270.7
        movl      %r15d, %r8d                                   #270.7
        shrl      $16, %r8d                                     #270.7
        movzbl    %r8b, %esi                                    #270.7
        movd      2048+aes_style_table(,%rsi,4), %xmm2          #270.7
        pxor      %xmm2, %xmm13                                 #270.7
        pxor      %xmm2, %xmm10                                 #270.7
        shrl      $24, %r15d                                    #270.7
        movd      3072+aes_style_table(,%r15,4), %xmm2          #270.7
        pxor      %xmm2, %xmm10                                 #270.7
        pxor      %xmm3, %xmm10                                 #270.7
        movzbl    %r9b, %esi                                    #270.7
        movd      aes_style_table(,%rsi,4), %xmm14              #270.7
        pxor      %xmm14, %xmm11                                #270.7
        movl      %r9d, %r8d                                    #270.7
        shrl      $8, %r8d                                      #270.7
        movzbl    %r8b, %r15d                                   #270.7
        movd      1024+aes_style_table(,%r15,4), %xmm4          #270.7
        pxor      %xmm4, %xmm14                                 #270.7
        movl      %r9d, %esi                                    #270.7
        shrl      $16, %esi                                     #270.7
        movzbl    %sil, %r8d                                    #270.7
        movd      2048+aes_style_table(,%r8,4), %xmm5           #270.7
        pxor      %xmm5, %xmm13                                 #270.7
        pxor      %xmm5, %xmm14                                 #270.7
        shrl      $24, %r9d                                     #270.7
        movd      3072+aes_style_table(,%r9,4), %xmm6           #270.7
        pxor      %xmm6, %xmm2                                  #270.7
        pxor      %xmm6, %xmm14                                 #270.7
        pslldq    $4, %xmm14                                    #270.7
        movzbl    %r14b, %r9d                                   #270.7
        movd      aes_style_table(,%r9,4), %xmm9                #270.7
        pxor      %xmm9, %xmm11                                 #270.7
        movl      %r14d, %esi                                   #270.7
        shrl      $8, %esi                                      #270.7
        movzbl    %sil, %r8d                                    #270.7
        movd      1024+aes_style_table(,%r8,4), %xmm7           #270.7
        pxor      %xmm7, %xmm12                                 #270.7
        pxor      %xmm7, %xmm9                                  #270.7
        movl      %r14d, %r15d                                  #270.7
        shrl      $16, %r15d                                    #270.7
        movzbl    %r15b, %r9d                                   #270.7
        movd      2048+aes_style_table(,%r9,4), %xmm8           #270.7
        pxor      %xmm8, %xmm9                                  #270.7
        shrl      $24, %r14d                                    #270.7
        movd      3072+aes_style_table(,%r14,4), %xmm15         #270.7
        pxor      %xmm15, %xmm9                                 #270.7
        pslldq    $8, %xmm9                                     #270.7
        pxor      %xmm9, %xmm14                                 #270.7
        pxor      %xmm14, %xmm10                                #270.7
        pslldq    $8, %xmm13                                    #270.7
        pxor      %xmm15, %xmm2                                 #270.7
        pshufb    %xmm0, %xmm10                                 #270.7
        pslldq    $12, %xmm2                                    #270.7
        pxor      %xmm2, %xmm13                                 #270.7
        pslldq    $4, %xmm12                                    #270.7
        pxor      %xmm12, %xmm11                                #270.7
        pxor      %xmm11, %xmm13                                #270.7
        pshufb    %xmm1, %xmm13                                 #270.7
        pxor      %xmm13, %xmm10                                #270.7
        movdqa    %xmm10, %xmm11                                #270.7
        movdqa    %xmm10, %xmm12                                #270.7
        psrldq    $4, %xmm11                                    #270.7
        psrldq    $8, %xmm12                                    #270.7
        movd      %xmm10, %r8d                                  #270.7
        psrldq    $12, %xmm10                                   #270.7
        movd      %xmm11, %r9d                                  #270.7
        movd      %xmm12, %esi                                  #270.7
        movd      %xmm10, %r15d                                 #270.7
        xorl      %r9d, %edx                                    #270.7
        movl      %esi, 64(%rsp)                                #270.7
        movl      %r15d, 152(%rsp)                              #270.7
        xorl      %r9d, 312(%rsp)                               #270.7
        xorl      %esi, %ecx                                    #270.7
        xorl      %r15d, 96(%rsp)                               #270.7
        xorl      %r15d, %r11d                                  #270.7
        xorl      %esi, %eax                                    #270.7
        movzbl    %r8b, %r14d                                   #270.7
        movd      aes_style_table(,%r14,4), %xmm7               #270.7
        movdqa    %xmm7, %xmm3                                  #270.7
        movl      %r8d, %esi                                    #270.7
        shrl      $8, %esi                                      #270.7
        movzbl    %sil, %r15d                                   #270.7
        movd      1024+aes_style_table(,%r15,4), %xmm8          #270.7
        pxor      %xmm8, %xmm3                                  #270.7
        movl      %r8d, %esi                                    #270.7
        shrl      $16, %esi                                     #270.7
        movzbl    %sil, %r14d                                   #270.7
        movd      2048+aes_style_table(,%r14,4), %xmm9          #270.7
        pxor      %xmm9, %xmm3                                  #270.7
        shrl      $24, %r8d                                     #270.7
        movd      3072+aes_style_table(,%r8,4), %xmm10          #270.7
        pxor      %xmm10, %xmm3                                 #270.7
        pslldq    $12, %xmm3                                    #270.7
        movzbl    %dl, %esi                                     #270.7
        movd      aes_style_table(,%rsi,4), %xmm6               #270.7
        movl      %edx, %r15d                                   #270.7
        shrl      $8, %r15d                                     #270.7
        movzbl    %r15b, %r8d                                   #270.7
        movd      1024+aes_style_table(,%r8,4), %xmm13          #270.7
        pxor      %xmm13, %xmm8                                 #270.7
        pxor      %xmm13, %xmm6                                 #270.7
        movl      %edx, %r14d                                   #270.7
        shrl      $16, %r14d                                    #270.7
        movzbl    %r14b, %esi                                   #270.7
        movd      2048+aes_style_table(,%rsi,4), %xmm2          #270.7
        pxor      %xmm2, %xmm9                                  #270.7
        pxor      %xmm2, %xmm6                                  #270.7
        shrl      $24, %edx                                     #270.7
        movd      3072+aes_style_table(,%rdx,4), %xmm2          #270.7
        pxor      %xmm2, %xmm6                                  #270.7
        pxor      %xmm3, %xmm6                                  #270.7
        movzbl    %cl, %edx                                     #270.7
        movd      aes_style_table(,%rdx,4), %xmm15              #270.7
        pxor      %xmm15, %xmm7                                 #270.7
        movl      %ecx, %r8d                                    #270.7
        shrl      $8, %r8d                                      #270.7
        movzbl    %r8b, %esi                                    #270.7
        movd      1024+aes_style_table(,%rsi,4), %xmm4          #270.7
        pxor      %xmm4, %xmm15                                 #270.7
        movl      %ecx, %r15d                                   #270.7
        shrl      $16, %r15d                                    #270.7
        movzbl    %r15b, %r14d                                  #270.7
        movd      2048+aes_style_table(,%r14,4), %xmm5          #270.7
        pxor      %xmm5, %xmm9                                  #270.7
        pxor      %xmm5, %xmm15                                 #270.7
        shrl      $24, %ecx                                     #270.7
        movd      3072+aes_style_table(,%rcx,4), %xmm10         #270.7
        pxor      %xmm10, %xmm2                                 #270.7
        pxor      %xmm10, %xmm15                                #270.7
        pslldq    $4, %xmm15                                    #270.7
        movzbl    %r11b, %ecx                                   #270.7
        movd      aes_style_table(,%rcx,4), %xmm14              #270.7
        pxor      %xmm14, %xmm7                                 #270.7
        movl      %r11d, %edx                                   #270.7
        shrl      $8, %edx                                      #270.7
        movzbl    %dl, %esi                                     #270.7
        movd      1024+aes_style_table(,%rsi,4), %xmm11         #270.7
        movl      4(%rdi,%r13,4), %esi                          #271.7
        movl      336(%rsp), %r13d                              #271.7
        pxor      %xmm11, %xmm8                                 #270.7
        pxor      %xmm11, %xmm14                                #270.7
        movl      72(%rsp), %edi                                #271.7
        movl      %r11d, %r8d                                   #270.7
        shrl      $16, %r8d                                     #270.7
        movzbl    %r8b, %r15d                                   #270.7
        movd      2048+aes_style_table(,%r15,4), %xmm12         #270.7
        movl      120(%rsp), %r8d                               #271.7
        movl      128(%rsp), %r15d                              #271.7
        pxor      %xmm12, %xmm14                                #270.7
        shrl      $24, %r11d                                    #270.7
        movd      3072+aes_style_table(,%r11,4), %xmm13         #270.7
        pxor      %xmm13, %xmm14                                #270.7
        pslldq    $8, %xmm14                                    #270.7
        pxor      %xmm14, %xmm15                                #270.7
        pxor      %xmm15, %xmm6                                 #270.7
        pslldq    $8, %xmm9                                     #270.7
        pxor      %xmm13, %xmm2                                 #270.7
        pshufb    %xmm0, %xmm6                                  #270.7
        pslldq    $12, %xmm2                                    #270.7
        pxor      %xmm2, %xmm9                                  #270.7
        pslldq    $4, %xmm8                                     #270.7
        pxor      %xmm8, %xmm7                                  #270.7
        pxor      %xmm7, %xmm9                                  #270.7
        xorl      %esi, %r10d                                   #271.7
        pshufb    %xmm1, %xmm9                                  #270.7
        pxor      %xmm9, %xmm6                                  #270.7
        movdqa    %xmm6, %xmm7                                  #270.7
        movdqa    %xmm6, %xmm8                                  #270.7
        psrldq    $4, %xmm7                                     #270.7
        psrldq    $8, %xmm8                                     #270.7
        movd      %xmm6, %edx                                   #270.7
        psrldq    $12, %xmm6                                    #270.7
        xorl      %edx, %r12d                                   #271.7
        movd      %xmm7, %ecx                                   #270.7
        movd      %xmm8, %r11d                                  #270.7
        movl      440(%rsp), %edx                               #271.7
        xorl      %r11d, 416(%rsp)                              #271.7
        xorl      %r8d, %ecx                                    #271.7
        movd      %xmm6, %r14d                                  #270.7
        xorl      %ecx, %r15d                                   #271.7
        movl      %r14d, 144(%rsp)                              #270.7
        xorl      %ecx, 160(%rsp)                               #271.7
        xorl      %r11d, %r13d                                  #271.7
        xorl      %r14d, %edi                                   #271.7
        xorl      %r14d, %edx                                   #271.7
        movzbl    %sil, %r14d                                   #271.7
        movd      aes_style_table(,%r14,4), %xmm3               #271.7
        movdqa    %xmm3, %xmm7                                  #271.7
        movl      %esi, %r14d                                   #271.7
        shrl      $8, %r14d                                     #271.7
        movzbl    %r14b, %r14d                                  #271.7
        movd      1024+aes_style_table(,%r14,4), %xmm4          #271.7
        pxor      %xmm4, %xmm7                                  #271.7
        movl      %esi, %r14d                                   #271.7
        shrl      $16, %r14d                                    #271.7
        movzbl    %r14b, %r14d                                  #271.7
        movd      2048+aes_style_table(,%r14,4), %xmm5          #271.7
        pxor      %xmm5, %xmm7                                  #271.7
        shrl      $24, %esi                                     #271.7
        movd      3072+aes_style_table(,%rsi,4), %xmm6          #271.7
        pxor      %xmm6, %xmm7                                  #271.7
        pslldq    $12, %xmm7                                    #271.7
        movzbl    %r15b, %esi                                   #271.7
        movd      aes_style_table(,%rsi,4), %xmm2               #271.7
        movl      %r15d, %r14d                                  #271.7
        shrl      $8, %r14d                                     #271.7
        movzbl    %r14b, %esi                                   #271.7
        movd      1024+aes_style_table(,%rsi,4), %xmm9          #271.7
        pxor      %xmm9, %xmm4                                  #271.7
        pxor      %xmm9, %xmm2                                  #271.7
        movl      %r15d, %r14d                                  #271.7
        shrl      $16, %r14d                                    #271.7
        movzbl    %r14b, %esi                                   #271.7
        movd      2048+aes_style_table(,%rsi,4), %xmm6          #271.7
        pxor      %xmm6, %xmm5                                  #271.7
        pxor      %xmm6, %xmm2                                  #271.7
        shrl      $24, %r15d                                    #271.7
        movd      3072+aes_style_table(,%r15,4), %xmm6          #271.7
        pxor      %xmm6, %xmm2                                  #271.7
        pxor      %xmm7, %xmm2                                  #271.7
        movzbl    %r13b, %esi                                   #271.7
        movd      aes_style_table(,%rsi,4), %xmm14              #271.7
        pxor      %xmm14, %xmm3                                 #271.7
        movl      %r13d, %r14d                                  #271.7
        shrl      $8, %r14d                                     #271.7
        movzbl    %r14b, %r15d                                  #271.7
        movd      1024+aes_style_table(,%r15,4), %xmm8          #271.7
        pxor      %xmm8, %xmm14                                 #271.7
        movl      %r13d, %esi                                   #271.7
        shrl      $16, %esi                                     #271.7
        movzbl    %sil, %r15d                                   #271.7
        movd      2048+aes_style_table(,%r15,4), %xmm9          #271.7
        pxor      %xmm9, %xmm5                                  #271.7
        pxor      %xmm9, %xmm14                                 #271.7
        shrl      $24, %r13d                                    #271.7
        movd      3072+aes_style_table(,%r13,4), %xmm10         #271.7
        pxor      %xmm10, %xmm6                                 #271.7
        pxor      %xmm10, %xmm14                                #271.7
        pslldq    $4, %xmm14                                    #271.7
        movzbl    %dil, %esi                                    #271.7
        movd      aes_style_table(,%rsi,4), %xmm13              #271.7
        pxor      %xmm13, %xmm3                                 #271.7
        movl      %edi, %r14d                                   #271.7
        shrl      $8, %r14d                                     #271.7
        movzbl    %r14b, %r15d                                  #271.7
        movd      1024+aes_style_table(,%r15,4), %xmm11         #271.7
        pxor      %xmm11, %xmm4                                 #271.7
        pxor      %xmm11, %xmm13                                #271.7
        movl      %edi, %esi                                    #271.7
        shrl      $16, %esi                                     #271.7
        movzbl    %sil, %r13d                                   #271.7
        movl      432(%rsp), %esi                               #271.7
        movd      2048+aes_style_table(,%r13,4), %xmm12         #271.7
        pxor      %xmm12, %xmm13                                #271.7
        shrl      $24, %edi                                     #271.7
        movd      3072+aes_style_table(,%rdi,4), %xmm15         #271.7
        pxor      %xmm15, %xmm13                                #271.7
        pslldq    $8, %xmm13                                    #271.7
        pxor      %xmm13, %xmm14                                #271.7
        pxor      %xmm14, %xmm2                                 #271.7
        pslldq    $8, %xmm5                                     #271.7
        pxor      %xmm15, %xmm6                                 #271.7
        pshufb    %xmm0, %xmm2                                  #271.7
        pslldq    $12, %xmm6                                    #271.7
        pxor      %xmm6, %xmm5                                  #271.7
        pslldq    $4, %xmm4                                     #271.7
        pxor      %xmm4, %xmm3                                  #271.7
        pxor      %xmm3, %xmm5                                  #271.7
        pshufb    %xmm1, %xmm5                                  #271.7
        pxor      %xmm5, %xmm2                                  #271.7
        movdqa    %xmm2, %xmm3                                  #271.7
        movdqa    %xmm2, %xmm4                                  #271.7
        psrldq    $4, %xmm3                                     #271.7
        psrldq    $8, %xmm4                                     #271.7
        movd      %xmm2, %r15d                                  #271.7
        psrldq    $12, %xmm2                                    #271.7
        movd      %xmm3, %edi                                   #271.7
        movd      %xmm4, %r13d                                  #271.7
        movd      %xmm2, %r14d                                  #271.7
        xorl      %edi, %r8d                                    #271.7
        movl      %edi, 336(%rsp)                               #271.7
        movl      %r13d, 72(%rsp)                               #271.7
        movl      %r14d, 136(%rsp)                              #271.7
        movl      %r8d, 120(%rsp)                               #271.7
        xorl      %r14d, %esi                                   #271.7
        xorl      %edi, %ebx                                    #271.7
        movl      %ebx, 320(%rsp)                               #271.7
        xorl      %r13d, 424(%rsp)                              #271.7
        xorl      %r13d, %r12d                                  #271.7
        movzbl    %r15b, %ebx                                   #271.7
        movd      aes_style_table(,%rbx,4), %xmm2               #271.7
        movdqa    %xmm2, %xmm6                                  #271.7
        xorl      %r14d, 80(%rsp)                               #271.7
        movl      %r15d, %edi                                   #271.7
        shrl      $8, %edi                                      #271.7
        movzbl    %dil, %ebx                                    #271.7
        movl      424(%rsp), %edi                               #271.7
        movd      1024+aes_style_table(,%rbx,4), %xmm3          #271.7
        pxor      %xmm3, %xmm6                                  #271.7
        movl      %r15d, %r13d                                  #271.7
        shrl      $16, %r13d                                    #271.7
        movzbl    %r13b, %r14d                                  #271.7
        movl      416(%rsp), %r13d                              #271.7
        movd      2048+aes_style_table(,%r14,4), %xmm4          #271.7
        pxor      %xmm4, %xmm6                                  #271.7
        shrl      $24, %r15d                                    #271.7
        movd      3072+aes_style_table(,%r15,4), %xmm5          #271.7
        pxor      %xmm5, %xmm6                                  #271.7
        pslldq    $12, %xmm6                                    #271.7
        movzbl    %r8b, %ebx                                    #271.7
        movl      aes_style_table(,%rbx,4), %r14d               #271.7
        movl      400(%rsp), %ebx                               #271.7
        movl      392(%rsp), %r8d                               #271.7
                                # LOE rbx rdi r8 r13 eax edx ecx ebx ebp esi edi r8d r9d r10d r11d r12d r13d r14d bl dil r8b r13b bh xmm0 xmm1 xmm2 xmm3 xmm4 xmm6
..B1.47:                        # Preds ..B1.22
        movl      %eax, 448(%rsp)                               #
        movd      %r14d, %xmm10                                 #271.7
        movl      %ecx, 456(%rsp)                               #
        movl      %r13d, 416(%rsp)                              #
        movl      %edx, 440(%rsp)                               #
        movl      %edi, %edi                                    #271.7
        movl      %edi, %edx                                    #271.7
        movl      %r12d, 408(%rsp)                              #
        movl      120(%rsp), %r12d                              #271.7
        movl      %r12d, %ecx                                   #271.7
        shrl      $8, %ecx                                      #271.7
        movzbl    %cl, %eax                                     #271.7
        movd      1024+aes_style_table(,%rax,4), %xmm11         #271.7
        pxor      %xmm11, %xmm3                                 #271.7
        pxor      %xmm11, %xmm10                                #271.7
        movl      %r12d, %r14d                                  #271.7
        shrl      $16, %r14d                                    #271.7
        movzbl    %r14b, %ecx                                   #271.7
        movd      2048+aes_style_table(,%rcx,4), %xmm12         #271.7
        pxor      %xmm12, %xmm4                                 #271.7
        pxor      %xmm12, %xmm10                                #271.7
        shrl      $24, %r12d                                    #271.7
        movd      3072+aes_style_table(,%r12,4), %xmm11         #271.7
        pxor      %xmm11, %xmm10                                #271.7
        pxor      %xmm6, %xmm10                                 #271.7
        movzbl    %dil, %eax                                    #271.7
        movd      aes_style_table(,%rax,4), %xmm8               #271.7
        pxor      %xmm8, %xmm2                                  #271.7
        shrl      $8, %edx                                      #271.7
        movzbl    %dl, %r13d                                    #271.7
        movd      1024+aes_style_table(,%r13,4), %xmm13         #271.7
        pxor      %xmm13, %xmm8                                 #271.7
        movl      %edi, %r15d                                   #271.7
        shrl      $16, %r15d                                    #271.7
        movzbl    %r15b, %ecx                                   #271.7
        movd      2048+aes_style_table(,%rcx,4), %xmm14         #271.7
        pxor      %xmm14, %xmm4                                 #271.7
        pxor      %xmm14, %xmm8                                 #271.7
        shrl      $24, %edi                                     #271.7
        movd      3072+aes_style_table(,%rdi,4), %xmm15         #271.7
        pxor      %xmm15, %xmm11                                #271.7
        pxor      %xmm15, %xmm8                                 #271.7
        pslldq    $4, %xmm8                                     #271.7
        movl      %esi, %esi                                    #271.7
        movzbl    %sil, %r12d                                   #271.7
        movd      aes_style_table(,%r12,4), %xmm7               #271.7
        movl      88(%rsp), %r12d                               #272.7
        pxor      %xmm7, %xmm2                                  #271.7
        movl      %esi, %r14d                                   #271.7
        shrl      $8, %r14d                                     #271.7
        movzbl    %r14b, %edi                                   #271.7
        movd      1024+aes_style_table(,%rdi,4), %xmm5          #271.7
        pxor      %xmm5, %xmm3                                  #271.7
        pxor      %xmm5, %xmm7                                  #271.7
        movl      %esi, %ecx                                    #271.7
        shrl      $16, %ecx                                     #271.7
        movzbl    %cl, %eax                                     #271.7
        movq      352(%rsp), %rcx                               #272.7
        movd      2048+aes_style_table(,%rax,4), %xmm6          #271.7
        pxor      %xmm6, %xmm7                                  #271.7
        shrl      $24, %esi                                     #271.7
        movq      48(%rsp), %rax                                #272.7
        movl      8(%rax,%rcx,4), %r13d                         #272.7
        movd      3072+aes_style_table(,%rsi,4), %xmm9          #271.7
        pxor      %xmm9, %xmm7                                  #271.7
        pslldq    $8, %xmm7                                     #271.7
        pxor      %xmm7, %xmm8                                  #271.7
        pxor      %xmm8, %xmm10                                 #271.7
        pshufb    %xmm0, %xmm10                                 #271.7
        pslldq    $8, %xmm4                                     #271.7
        pxor      %xmm9, %xmm11                                 #271.7
        pslldq    $12, %xmm11                                   #271.7
        pxor      %xmm11, %xmm4                                 #271.7
        pslldq    $4, %xmm3                                     #271.7
        pxor      %xmm3, %xmm2                                  #271.7
        pxor      %xmm2, %xmm4                                  #271.7
        pshufb    %xmm1, %xmm4                                  #271.7
        pxor      %xmm4, %xmm10                                 #271.7
        movdqa    %xmm10, %xmm3                                 #271.7
        movdqa    %xmm10, %xmm4                                 #271.7
        xorl      %r13d, %r11d                                  #272.7
        movl      %r11d, 376(%rsp)                              #272.7
        movl      104(%rsp), %r11d                              #272.7
        psrldq    $4, %xmm3                                     #271.7
        movd      %xmm10, %edx                                  #271.7
        psrldq    $8, %xmm4                                     #271.7
        psrldq    $12, %xmm10                                   #271.7
        xorl      %edx, %r9d                                    #272.7
        movl      112(%rsp), %edx                               #272.7
        movl      %r13d, %r14d                                  #272.7
        movd      %xmm3, %edi                                   #271.7
        movd      %xmm4, %esi                                   #271.7
        movd      %xmm10, %r15d                                 #271.7
        xorl      %r11d, %edi                                   #272.7
        movl      %r15d, 128(%rsp)                              #271.7
        xorl      %edi, 152(%rsp)                               #272.7
        xorl      %edi, %edx                                    #272.7
        xorl      %esi, %ebx                                    #272.7
        xorl      %r15d, %r12d                                  #272.7
        xorl      %esi, %ebp                                    #272.7
        xorl      %r15d, %r10d                                  #272.7
        movzbl    %r13b, %r15d                                  #272.7
        movd      aes_style_table(,%r15,4), %xmm7               #272.7
        movdqa    %xmm7, %xmm13                                 #272.7
        shrl      $8, %r14d                                     #272.7
        movzbl    %r14b, %r15d                                  #272.7
        movd      1024+aes_style_table(,%r15,4), %xmm8          #272.7
        pxor      %xmm8, %xmm13                                 #272.7
        movl      %r13d, %r14d                                  #272.7
        shrl      $16, %r14d                                    #272.7
        movzbl    %r14b, %r15d                                  #272.7
        movd      2048+aes_style_table(,%r15,4), %xmm9          #272.7
        pxor      %xmm9, %xmm13                                 #272.7
        shrl      $24, %r13d                                    #272.7
        movd      3072+aes_style_table(,%r13,4), %xmm2          #272.7
        pxor      %xmm2, %xmm13                                 #272.7
        pslldq    $12, %xmm13                                   #272.7
        movzbl    %dl, %r13d                                    #272.7
        movd      aes_style_table(,%r13,4), %xmm6               #272.7
        movl      %edx, %r15d                                   #272.7
        shrl      $8, %r15d                                     #272.7
        movzbl    %r15b, %r14d                                  #272.7
        movd      1024+aes_style_table(,%r14,4), %xmm10         #272.7
        pxor      %xmm10, %xmm8                                 #272.7
        pxor      %xmm10, %xmm6                                 #272.7
        movl      %edx, %r13d                                   #272.7
        shrl      $16, %r13d                                    #272.7
        movzbl    %r13b, %r15d                                  #272.7
        movd      2048+aes_style_table(,%r15,4), %xmm12         #272.7
        pxor      %xmm12, %xmm9                                 #272.7
        pxor      %xmm12, %xmm6                                 #272.7
        shrl      $24, %edx                                     #272.7
        movd      3072+aes_style_table(,%rdx,4), %xmm10         #272.7
        pxor      %xmm10, %xmm6                                 #272.7
        pxor      %xmm13, %xmm6                                 #272.7
        movzbl    %bl, %edx                                     #272.7
        movd      aes_style_table(,%rdx,4), %xmm13              #272.7
        pxor      %xmm13, %xmm7                                 #272.7
        movl      %ebx, %r13d                                   #272.7
        shrl      $8, %r13d                                     #272.7
        movzbl    %r13b, %r15d                                  #272.7
        movd      1024+aes_style_table(,%r15,4), %xmm14         #272.7
        pxor      %xmm14, %xmm13                                #272.7
        movl      %ebx, %r14d                                   #272.7
        shrl      $16, %r14d                                    #272.7
        movzbl    %r14b, %edx                                   #272.7
        movd      2048+aes_style_table(,%rdx,4), %xmm15         #272.7
        pxor      %xmm15, %xmm9                                 #272.7
        pxor      %xmm15, %xmm13                                #272.7
        shrl      $24, %ebx                                     #272.7
        movd      3072+aes_style_table(,%rbx,4), %xmm3          #272.7
        pxor      %xmm3, %xmm10                                 #272.7
        pxor      %xmm3, %xmm13                                 #272.7
        pslldq    $4, %xmm13                                    #272.7
        movzbl    %r12b, %ebx                                   #272.7
        movd      aes_style_table(,%rbx,4), %xmm2               #272.7
        pxor      %xmm2, %xmm7                                  #272.7
        movl      %r12d, %r13d                                  #272.7
        shrl      $8, %r13d                                     #272.7
        movzbl    %r13b, %edx                                   #272.7
        movd      1024+aes_style_table(,%rdx,4), %xmm4          #272.7
        pxor      %xmm4, %xmm8                                  #272.7
        pxor      %xmm4, %xmm2                                  #272.7
        movl      %r12d, %r15d                                  #272.7
        shrl      $16, %r15d                                    #272.7
        movzbl    %r15b, %r14d                                  #272.7
        movl      328(%rsp), %r15d                              #272.7
        movd      2048+aes_style_table(,%r14,4), %xmm5          #272.7
        pxor      %xmm5, %xmm2                                  #272.7
        shrl      $24, %r12d                                    #272.7
        movd      3072+aes_style_table(,%r12,4), %xmm14         #272.7
        pxor      %xmm14, %xmm2                                 #272.7
        pslldq    $8, %xmm2                                     #272.7
        pxor      %xmm2, %xmm13                                 #272.7
        pxor      %xmm13, %xmm6                                 #272.7
        pslldq    $8, %xmm9                                     #272.7
        pxor      %xmm14, %xmm10                                #272.7
        pshufb    %xmm0, %xmm6                                  #272.7
        pslldq    $12, %xmm10                                   #272.7
        pxor      %xmm10, %xmm9                                 #272.7
        pslldq    $4, %xmm8                                     #272.7
        pxor      %xmm8, %xmm7                                  #272.7
        pxor      %xmm7, %xmm9                                  #272.7
        pshufb    %xmm1, %xmm9                                  #272.7
        pxor      %xmm9, %xmm6                                  #272.7
        movdqa    %xmm6, %xmm7                                  #272.7
        movdqa    %xmm6, %xmm8                                  #272.7
        psrldq    $4, %xmm7                                     #272.7
        psrldq    $8, %xmm8                                     #272.7
        movd      %xmm6, %r14d                                  #272.7
        psrldq    $12, %xmm6                                    #272.7
        movd      %xmm7, %ebx                                   #272.7
        movd      %xmm8, %r12d                                  #272.7
        movd      %xmm6, %edx                                   #272.7
        xorl      %ebx, %r11d                                   #272.7
        movl      %r12d, 88(%rsp)                               #272.7
        movl      %edx, 120(%rsp)                               #272.7
        xorl      %ebx, 144(%rsp)                               #272.7
        xorl      %r12d, %r15d                                  #272.7
        xorl      %edx, 64(%rsp)                                #272.7
        xorl      %edx, %r8d                                    #272.7
        xorl      %r12d, %r9d                                   #272.7
        movzbl    %r14b, %r13d                                  #272.7
        movd      aes_style_table(,%r13,4), %xmm4               #272.7
        movdqa    %xmm4, %xmm12                                 #272.7
        movl      %r14d, %r12d                                  #272.7
        shrl      $8, %r12d                                     #272.7
        movzbl    %r12b, %edx                                   #272.7
        movd      1024+aes_style_table(,%rdx,4), %xmm5          #272.7
        pxor      %xmm5, %xmm12                                 #272.7
        movl      %r14d, %r12d                                  #272.7
        shrl      $16, %r12d                                    #272.7
        movzbl    %r12b, %r13d                                  #272.7
        movd      2048+aes_style_table(,%r13,4), %xmm2          #272.7
        pxor      %xmm2, %xmm12                                 #272.7
        shrl      $24, %r14d                                    #272.7
        movd      3072+aes_style_table(,%r14,4), %xmm6          #272.7
        pxor      %xmm6, %xmm12                                 #272.7
        pslldq    $12, %xmm12                                   #272.7
        movzbl    %r11b, %r12d                                  #272.7
        movd      aes_style_table(,%r12,4), %xmm3               #272.7
        movl      %r11d, %edx                                   #272.7
        shrl      $8, %edx                                      #272.7
        movzbl    %dl, %r13d                                    #272.7
        movd      1024+aes_style_table(,%r13,4), %xmm9          #272.7
        pxor      %xmm9, %xmm5                                  #272.7
        pxor      %xmm9, %xmm3                                  #272.7
        movl      %r11d, %r12d                                  #272.7
        shrl      $16, %r12d                                    #272.7
        movzbl    %r12b, %r14d                                  #272.7
        movd      2048+aes_style_table(,%r14,4), %xmm11         #272.7
        pxor      %xmm11, %xmm2                                 #272.7
        pxor      %xmm11, %xmm3                                 #272.7
        shrl      $24, %r11d                                    #272.7
        movd      3072+aes_style_table(,%r11,4), %xmm11         #272.7
        pxor      %xmm11, %xmm3                                 #272.7
        pxor      %xmm12, %xmm3                                 #272.7
        movzbl    %r15b, %r11d                                  #272.7
        movd      aes_style_table(,%r11,4), %xmm9               #272.7
        pxor      %xmm9, %xmm4                                  #272.7
        movl      %r15d, %r12d                                  #272.7
        shrl      $8, %r12d                                     #272.7
        movzbl    %r12b, %edx                                   #272.7
        movd      1024+aes_style_table(,%rdx,4), %xmm15         #272.7
        pxor      %xmm15, %xmm9                                 #272.7
        movl      %r15d, %r13d                                  #272.7
        shrl      $16, %r13d                                    #272.7
        movzbl    %r13b, %r14d                                  #272.7
        movd      2048+aes_style_table(,%r14,4), %xmm15         #272.7
        pxor      %xmm15, %xmm2                                 #272.7
        pxor      %xmm15, %xmm9                                 #272.7
        shrl      $24, %r15d                                    #272.7
        movd      3072+aes_style_table(,%r15,4), %xmm12         #272.7
        pxor      %xmm12, %xmm11                                #272.7
        pxor      %xmm12, %xmm9                                 #272.7
        pslldq    $4, %xmm9                                     #272.7
        movzbl    %r8b, %r11d                                   #272.7
        movd      aes_style_table(,%r11,4), %xmm8               #272.7
        pxor      %xmm8, %xmm4                                  #272.7
        movl      %r8d, %r12d                                   #272.7
        shrl      $8, %r12d                                     #272.7
        movzbl    %r12b, %edx                                   #272.7
        movl      312(%rsp), %r12d                              #273.7
        movd      1024+aes_style_table(,%rdx,4), %xmm6          #272.7
        movl      12(%rax,%rcx,4), %edx                         #273.7
        pxor      %xmm6, %xmm5                                  #272.7
        pxor      %xmm6, %xmm8                                  #272.7
        movl      448(%rsp), %eax                               #273.7
        movl      456(%rsp), %ecx                               #273.7
        movl      %r8d, %r13d                                   #272.7
        shrl      $16, %r13d                                    #272.7
        movzbl    %r13b, %r14d                                  #272.7
        movd      2048+aes_style_table(,%r14,4), %xmm7          #272.7
        pxor      %xmm7, %xmm8                                  #272.7
        shrl      $24, %r8d                                     #272.7
        movd      3072+aes_style_table(,%r8,4), %xmm10          #272.7
        pxor      %xmm10, %xmm8                                 #272.7
        pslldq    $8, %xmm8                                     #272.7
        pxor      %xmm8, %xmm9                                  #272.7
        pxor      %xmm9, %xmm3                                  #272.7
        pshufb    %xmm0, %xmm3                                  #272.7
        pslldq    $8, %xmm2                                     #272.7
        pxor      %xmm10, %xmm11                                #272.7
        pslldq    $12, %xmm11                                   #272.7
        pxor      %xmm11, %xmm2                                 #272.7
        pslldq    $4, %xmm5                                     #272.7
        pxor      %xmm5, %xmm4                                  #272.7
        pxor      %xmm4, %xmm2                                  #272.7
        pshufb    %xmm1, %xmm2                                  #272.7
        pxor      %xmm2, %xmm3                                  #272.7
        movdqa    %xmm3, %xmm4                                  #272.7
        movdqa    %xmm3, %xmm5                                  #272.7
        xorl      %edx, %esi                                    #273.7
        psrldq    $4, %xmm4                                     #272.7
        psrldq    $8, %xmm5                                     #272.7
        movd      %xmm3, %r15d                                  #272.7
        psrldq    $12, %xmm3                                    #272.7
        xorl      %r15d, 336(%rsp)                              #273.7
        movl      %edx, %r14d                                   #273.7
        shrl      $8, %r14d                                     #273.7
        movd      %xmm4, %r11d                                  #272.7
        movd      %xmm5, %r8d                                   #272.7
        movd      %xmm3, %r13d                                  #272.7
        xorl      160(%rsp), %r11d                              #273.7
        xorl      %r11d, %r12d                                  #273.7
        movl      %r13d, 112(%rsp)                              #272.7
        movl      %r11d, 328(%rsp)                              #273.7
        xorl      %r8d, %eax                                    #273.7
        xorl      %r13d, 96(%rsp)                               #273.7
        xorl      %r8d, %ecx                                    #273.7
        xorl      %r11d, 136(%rsp)                              #273.7
        movl      376(%rsp), %r11d                              #273.7
        xorl      %r13d, %r11d                                  #273.7
        movzbl    %dl, %r13d                                    #273.7
        movd      aes_style_table(,%r13,4), %xmm3               #273.7
        movdqa    %xmm3, %xmm6                                  #273.7
        movzbl    %r14b, %r15d                                  #273.7
        movd      1024+aes_style_table(,%r15,4), %xmm4          #273.7
        movl      %edx, %r13d                                   #273.7
        pxor      %xmm4, %xmm6                                  #273.7
        shrl      $16, %r13d                                    #273.7
        movzbl    %r13b, %r14d                                  #273.7
        movd      2048+aes_style_table(,%r14,4), %xmm5          #273.7
        pxor      %xmm5, %xmm6                                  #273.7
        shrl      $24, %edx                                     #273.7
        movd      3072+aes_style_table(,%rdx,4), %xmm2          #273.7
        pxor      %xmm2, %xmm6                                  #273.7
        pslldq    $12, %xmm6                                    #273.7
        movzbl    %r12b, %r15d                                  #273.7
        movd      aes_style_table(,%r15,4), %xmm2               #273.7
        movl      %r12d, %r13d                                  #273.7
        shrl      $8, %r13d                                     #273.7
        movzbl    %r13b, %edx                                   #273.7
        movd      1024+aes_style_table(,%rdx,4), %xmm13         #273.7
        pxor      %xmm13, %xmm4                                 #273.7
        pxor      %xmm13, %xmm2                                 #273.7
        movl      %r12d, %r14d                                  #273.7
        shrl      $16, %r14d                                    #273.7
        movzbl    %r14b, %r15d                                  #273.7
        movd      2048+aes_style_table(,%r15,4), %xmm14         #273.7
        pxor      %xmm14, %xmm5                                 #273.7
        pxor      %xmm14, %xmm2                                 #273.7
        shrl      $24, %r12d                                    #273.7
        movd      3072+aes_style_table(,%r12,4), %xmm8          #273.7
        pxor      %xmm8, %xmm2                                  #273.7
        pxor      %xmm6, %xmm2                                  #273.7
        movzbl    %al, %edx                                     #273.7
        movd      aes_style_table(,%rdx,4), %xmm7               #273.7
        pxor      %xmm7, %xmm3                                  #273.7
        movl      %eax, %r13d                                   #273.7
        movl      440(%rsp), %edx                               #273.7
        shrl      $8, %r13d                                     #273.7
        movzbl    %r13b, %r12d                                  #273.7
        movd      1024+aes_style_table(,%r12,4), %xmm6          #273.7
        movl      408(%rsp), %r12d                              #273.7
        movl      416(%rsp), %r13d                              #273.7
                                # LOE rdx r12 r13 eax edx ecx ebx ebp esi edi r8d r9d r10d r11d r12d r13d dl r12b r13b dh xmm0 xmm1 xmm2 xmm3 xmm4 xmm5 xmm6 xmm7 xmm8
..B1.48:                        # Preds ..B1.47
        movl      %r9d, 384(%rsp)                               #
        pxor      %xmm6, %xmm7                                  #273.7
        movl      %ecx, 456(%rsp)                               #
        movl      %r11d, 376(%rsp)                              #
        movl      %eax, %r9d                                    #273.7
        shrl      $16, %r9d                                     #273.7
        movzbl    %r9b, %r11d                                   #273.7
        movd      2048+aes_style_table(,%r11,4), %xmm10         #273.7
        pxor      %xmm10, %xmm5                                 #273.7
        pxor      %xmm10, %xmm7                                 #273.7
        shrl      $24, %eax                                     #273.7
        movd      3072+aes_style_table(,%rax,4), %xmm11         #273.7
        movl      96(%rsp), %eax                                #273.7
        pxor      %xmm11, %xmm8                                 #273.7
        pxor      %xmm11, %xmm7                                 #273.7
        pslldq    $4, %xmm7                                     #273.7
        movzbl    %al, %r14d                                    #273.7
        movd      aes_style_table(,%r14,4), %xmm14              #273.7
        pxor      %xmm14, %xmm3                                 #273.7
        movl      %eax, %ecx                                    #273.7
        shrl      $8, %ecx                                      #273.7
        movzbl    %cl, %r15d                                    #273.7
        movd      1024+aes_style_table(,%r15,4), %xmm12         #273.7
        pxor      %xmm12, %xmm4                                 #273.7
        pxor      %xmm12, %xmm14                                #273.7
        movl      %eax, %r14d                                   #273.7
        shrl      $16, %r14d                                    #273.7
        movzbl    %r14b, %ecx                                   #273.7
        movd      2048+aes_style_table(,%rcx,4), %xmm13         #273.7
        movl      160(%rsp), %ecx                               #273.7
        pxor      %xmm13, %xmm14                                #273.7
        shrl      $24, %eax                                     #273.7
        movd      3072+aes_style_table(,%rax,4), %xmm15         #273.7
        pxor      %xmm15, %xmm14                                #273.7
        pslldq    $8, %xmm14                                    #273.7
        pxor      %xmm14, %xmm7                                 #273.7
        pxor      %xmm7, %xmm2                                  #273.7
        pslldq    $8, %xmm5                                     #273.7
        pxor      %xmm15, %xmm8                                 #273.7
        pslldq    $12, %xmm8                                    #273.7
        pxor      %xmm8, %xmm5                                  #273.7
        pshufb    %xmm0, %xmm2                                  #273.7
        pslldq    $4, %xmm4                                     #273.7
        pxor      %xmm4, %xmm3                                  #273.7
        pxor      %xmm3, %xmm5                                  #273.7
        pshufb    %xmm1, %xmm5                                  #273.7
        pxor      %xmm5, %xmm2                                  #273.7
        movdqa    %xmm2, %xmm3                                  #273.7
        movdqa    %xmm2, %xmm4                                  #273.7
        psrldq    $4, %xmm3                                     #273.7
        psrldq    $8, %xmm4                                     #273.7
        movd      %xmm2, %r14d                                  #273.7
        psrldq    $12, %xmm2                                    #273.7
        movd      %xmm3, %eax                                   #273.7
        movd      %xmm4, %r9d                                   #273.7
        movd      %xmm2, %r11d                                  #273.7
        xorl      %eax, %ecx                                    #273.7
        movl      %r9d, 96(%rsp)                                #273.7
        movl      %r11d, 104(%rsp)                              #273.7
        xorl      %eax, 128(%rsp)                               #273.7
        xorl      %r9d, %r13d                                   #273.7
        xorl      %r9d, 336(%rsp)                               #273.7
        xorl      %r11d, %edx                                   #273.7
        movzbl    %r14b, %r15d                                  #273.7
        movd      aes_style_table(,%r15,4), %xmm7               #273.7
        movdqa    %xmm7, %xmm11                                 #273.7
        xorl      %r11d, 72(%rsp)                               #273.7
        movl      %r14d, %r9d                                   #273.7
        shrl      $8, %r9d                                      #273.7
        movzbl    %r9b, %r11d                                   #273.7
        movd      1024+aes_style_table(,%r11,4), %xmm8          #273.7
        pxor      %xmm8, %xmm11                                 #273.7
        movl      %r14d, %r9d                                   #273.7
        shrl      $16, %r9d                                     #273.7
        movzbl    %r9b, %r15d                                   #273.7
        movd      2048+aes_style_table(,%r15,4), %xmm9          #273.7
        pxor      %xmm9, %xmm11                                 #273.7
        shrl      $24, %r14d                                    #273.7
        movd      3072+aes_style_table(,%r14,4), %xmm5          #273.7
        pxor      %xmm5, %xmm11                                 #273.7
        pslldq    $12, %xmm11                                   #273.7
        movzbl    %cl, %r14d                                    #273.7
        movd      aes_style_table(,%r14,4), %xmm6               #273.7
        movl      %ecx, %r9d                                    #273.7
        shrl      $8, %r9d                                      #273.7
        movzbl    %r9b, %r11d                                   #273.7
        movd      1024+aes_style_table(,%r11,4), %xmm2          #273.7
        pxor      %xmm2, %xmm8                                  #273.7
        pxor      %xmm2, %xmm6                                  #273.7
        movl      %ecx, %r15d                                   #273.7
        shrl      $16, %r15d                                    #273.7
        movzbl    %r15b, %r14d                                  #273.7
        movd      2048+aes_style_table(,%r14,4), %xmm10         #273.7
        pxor      %xmm10, %xmm9                                 #273.7
        pxor      %xmm10, %xmm6                                 #273.7
        shrl      $24, %ecx                                     #273.7
        movd      3072+aes_style_table(,%rcx,4), %xmm10         #273.7
        pxor      %xmm10, %xmm6                                 #273.7
        pxor      %xmm11, %xmm6                                 #273.7
        movzbl    %r13b, %r14d                                  #273.7
        movd      aes_style_table(,%r14,4), %xmm5               #273.7
        pxor      %xmm5, %xmm7                                  #273.7
        movl      %r13d, %r9d                                   #273.7
        shrl      $8, %r9d                                      #273.7
        movzbl    %r9b, %ecx                                    #273.7
        movd      1024+aes_style_table(,%rcx,4), %xmm12         #273.7
        pxor      %xmm12, %xmm5                                 #273.7
        movl      %r13d, %r11d                                  #273.7
        shrl      $16, %r11d                                    #273.7
        movzbl    %r11b, %r15d                                  #273.7
        movd      2048+aes_style_table(,%r15,4), %xmm13         #273.7
        pxor      %xmm13, %xmm9                                 #273.7
        pxor      %xmm13, %xmm5                                 #273.7
        shrl      $24, %r13d                                    #273.7
        movd      3072+aes_style_table(,%r13,4), %xmm14         #273.7
        pxor      %xmm14, %xmm10                                #273.7
        pxor      %xmm14, %xmm5                                 #273.7
        pslldq    $4, %xmm5                                     #273.7
        movzbl    %dl, %r13d                                    #273.7
        movd      aes_style_table(,%r13,4), %xmm4               #273.7
        pxor      %xmm4, %xmm7                                  #273.7
        movl      %edx, %r14d                                   #273.7
        shrl      $8, %r14d                                     #273.7
        movzbl    %r14b, %ecx                                   #273.7
        movd      1024+aes_style_table(,%rcx,4), %xmm15         #273.7
        movq      48(%rsp), %rcx                                #274.7
        pxor      %xmm15, %xmm8                                 #273.7
        pxor      %xmm15, %xmm4                                 #273.7
        movl      %edx, %r9d                                    #273.7
        shrl      $16, %r9d                                     #273.7
        movzbl    %r9b, %r11d                                   #273.7
        movl      320(%rsp), %r9d                               #274.7
        movd      2048+aes_style_table(,%r11,4), %xmm3          #273.7
        pxor      %xmm3, %xmm4                                  #273.7
        shrl      $24, %edx                                     #273.7
        movd      3072+aes_style_table(,%rdx,4), %xmm2          #273.7
        pxor      %xmm2, %xmm4                                  #273.7
        pslldq    $8, %xmm4                                     #273.7
        pxor      %xmm4, %xmm5                                  #273.7
        pxor      %xmm5, %xmm6                                  #273.7
        pslldq    $8, %xmm9                                     #273.7
        pshufb    %xmm0, %xmm6                                  #273.7
        pxor      %xmm2, %xmm10                                 #273.7
        pslldq    $12, %xmm10                                   #273.7
        pxor      %xmm10, %xmm9                                 #273.7
        pslldq    $4, %xmm8                                     #273.7
        pxor      %xmm8, %xmm7                                  #273.7
        pxor      %xmm7, %xmm9                                  #273.7
        pshufb    %xmm1, %xmm9                                  #273.7
        pxor      %xmm9, %xmm6                                  #273.7
        movdqa    %xmm6, %xmm7                                  #273.7
        movdqa    %xmm6, %xmm8                                  #273.7
        psrldq    $4, %xmm7                                     #273.7
        psrldq    $8, %xmm8                                     #273.7
        movd      %xmm6, %r14d                                  #273.7
        psrldq    $12, %xmm6                                    #273.7
        xorl      %r14d, %ebx                                   #274.7
        movd      %xmm7, %r13d                                  #273.7
        movd      %xmm8, %edx                                   #273.7
        movd      %xmm6, %r15d                                  #273.7
        movq      352(%rsp), %r14                               #274.7
        movl      16(%rcx,%r14,4), %r11d                        #274.7
        movl      152(%rsp), %r14d                              #274.7
        movl      80(%rsp), %ecx                                #274.7
        movl      %r15d, 312(%rsp)                              #273.7
        xorl      %r11d, %r8d                                   #274.7
        movl      %r8d, 392(%rsp)                               #274.7
        xorl      %r14d, %r13d                                  #274.7
        xorl      %r13d, 120(%rsp)                              #274.7
        xorl      %r13d, %r9d                                   #274.7
        xorl      %edx, %r12d                                   #274.7
        xorl      %r15d, %ecx                                   #274.7
        xorl      %edx, %edi                                    #274.7
        xorl      %r15d, %esi                                   #274.7
        movzbl    %r11b, %r8d                                   #274.7
        movd      aes_style_table(,%r8,4), %xmm4                #274.7
        movdqa    %xmm4, %xmm7                                  #274.7
        movl      %r11d, %r15d                                  #274.7
        shrl      $8, %r15d                                     #274.7
        movzbl    %r15b, %r8d                                   #274.7
        movd      1024+aes_style_table(,%r8,4), %xmm5           #274.7
        pxor      %xmm5, %xmm7                                  #274.7
        movl      %r11d, %r15d                                  #274.7
        shrl      $16, %r15d                                    #274.7
        movzbl    %r15b, %r8d                                   #274.7
        movd      2048+aes_style_table(,%r8,4), %xmm2           #274.7
        pxor      %xmm2, %xmm7                                  #274.7
        shrl      $24, %r11d                                    #274.7
        movd      3072+aes_style_table(,%r11,4), %xmm6          #274.7
        pxor      %xmm6, %xmm7                                  #274.7
        pslldq    $12, %xmm7                                    #274.7
        movzbl    %r9b, %r8d                                    #274.7
        movd      aes_style_table(,%r8,4), %xmm3                #274.7
        movl      %r9d, %r15d                                   #274.7
        shrl      $8, %r15d                                     #274.7
        movzbl    %r15b, %r11d                                  #274.7
        movd      1024+aes_style_table(,%r11,4), %xmm9          #274.7
        pxor      %xmm9, %xmm5                                  #274.7
        pxor      %xmm9, %xmm3                                  #274.7
        movl      %r9d, %r8d                                    #274.7
        shrl      $16, %r8d                                     #274.7
        movzbl    %r8b, %r11d                                   #274.7
        movd      2048+aes_style_table(,%r11,4), %xmm6          #274.7
        pxor      %xmm6, %xmm2                                  #274.7
        pxor      %xmm6, %xmm3                                  #274.7
        shrl      $24, %r9d                                     #274.7
        movd      3072+aes_style_table(,%r9,4), %xmm6           #274.7
        pxor      %xmm6, %xmm3                                  #274.7
        pxor      %xmm7, %xmm3                                  #274.7
        movzbl    %r12b, %r8d                                   #274.7
        movd      aes_style_table(,%r8,4), %xmm14               #274.7
        pxor      %xmm14, %xmm4                                 #274.7
        movl      %r12d, %r15d                                  #274.7
        shrl      $8, %r15d                                     #274.7
        movzbl    %r15b, %r9d                                   #274.7
        movd      1024+aes_style_table(,%r9,4), %xmm8           #274.7
        pxor      %xmm8, %xmm14                                 #274.7
        movl      %r12d, %r8d                                   #274.7
        shrl      $16, %r8d                                     #274.7
        movzbl    %r8b, %r11d                                   #274.7
        movd      2048+aes_style_table(,%r11,4), %xmm9          #274.7
        pxor      %xmm9, %xmm2                                  #274.7
        pxor      %xmm9, %xmm14                                 #274.7
        shrl      $24, %r12d                                    #274.7
        movd      3072+aes_style_table(,%r12,4), %xmm10         #274.7
        pxor      %xmm10, %xmm6                                 #274.7
        pxor      %xmm10, %xmm14                                #274.7
        pslldq    $4, %xmm14                                    #274.7
        movzbl    %cl, %r12d                                    #274.7
        movd      aes_style_table(,%r12,4), %xmm13              #274.7
        pxor      %xmm13, %xmm4                                 #274.7
        movl      %ecx, %r8d                                    #274.7
        shrl      $8, %r8d                                      #274.7
        movzbl    %r8b, %r9d                                    #274.7
        movd      1024+aes_style_table(,%r9,4), %xmm11          #274.7
        pxor      %xmm11, %xmm5                                 #274.7
        pxor      %xmm11, %xmm13                                #274.7
        movl      %ecx, %r15d                                   #274.7
        shrl      $16, %r15d                                    #274.7
        movzbl    %r15b, %r11d                                  #274.7
        movd      2048+aes_style_table(,%r11,4), %xmm12         #274.7
        pxor      %xmm12, %xmm13                                #274.7
        shrl      $24, %ecx                                     #274.7
        movd      3072+aes_style_table(,%rcx,4), %xmm15         #274.7
        pxor      %xmm15, %xmm13                                #274.7
        pslldq    $8, %xmm13                                    #274.7
        pxor      %xmm13, %xmm14                                #274.7
        pxor      %xmm14, %xmm3                                 #274.7
        pslldq    $8, %xmm2                                     #274.7
        pxor      %xmm15, %xmm6                                 #274.7
        pshufb    %xmm0, %xmm3                                  #274.7
        pslldq    $12, %xmm6                                    #274.7
        pxor      %xmm6, %xmm2                                  #274.7
        pslldq    $4, %xmm5                                     #274.7
        pxor      %xmm5, %xmm4                                  #274.7
        pxor      %xmm4, %xmm2                                  #274.7
        pshufb    %xmm1, %xmm2                                  #274.7
        pxor      %xmm2, %xmm3                                  #274.7
        movdqa    %xmm3, %xmm4                                  #274.7
        movdqa    %xmm3, %xmm5                                  #274.7
        psrldq    $4, %xmm4                                     #274.7
        psrldq    $8, %xmm5                                     #274.7
        movd      %xmm3, %r8d                                   #274.7
        psrldq    $12, %xmm3                                    #274.7
        movd      %xmm4, %r12d                                  #274.7
        movd      %xmm5, %ecx                                   #274.7
        movd      %xmm3, %r9d                                   #274.7
        xorl      %r12d, %r14d                                  #274.7
        movl      %ecx, 80(%rsp)                                #274.7
        movl      %r9d, 160(%rsp)                               #274.7
        xorl      %r12d, 112(%rsp)                              #274.7
        xorl      %ecx, %ebp                                    #274.7
        xorl      %r9d, 88(%rsp)                                #274.7
        xorl      %r9d, %r10d                                   #274.7
        xorl      %ecx, %ebx                                    #274.7
        movzbl    %r8b, %r11d                                   #274.7
        movd      aes_style_table(,%r11,4), %xmm3               #274.7
        movdqa    %xmm3, %xmm9                                  #274.7
        movl      %r8d, %r15d                                   #274.7
        shrl      $8, %r15d                                     #274.7
        movzbl    %r15b, %ecx                                   #274.7
        movd      1024+aes_style_table(,%rcx,4), %xmm4          #274.7
        pxor      %xmm4, %xmm9                                  #274.7
        movl      %r8d, %r9d                                    #274.7
        shrl      $16, %r9d                                     #274.7
        movzbl    %r9b, %r11d                                   #274.7
        movd      2048+aes_style_table(,%r11,4), %xmm5          #274.7
        pxor      %xmm5, %xmm9                                  #274.7
        shrl      $24, %r8d                                     #274.7
        movd      3072+aes_style_table(,%r8,4), %xmm2           #274.7
        pxor      %xmm2, %xmm9                                  #274.7
        pslldq    $12, %xmm9                                    #274.7
        movzbl    %r14b, %ecx                                   #274.7
        movd      aes_style_table(,%rcx,4), %xmm2               #274.7
        movl      %r14d, %r9d                                   #274.7
        shrl      $8, %r9d                                      #274.7
        movzbl    %r9b, %r8d                                    #274.7
        movd      1024+aes_style_table(,%r8,4), %xmm7           #274.7
        pxor      %xmm7, %xmm4                                  #274.7
        pxor      %xmm7, %xmm2                                  #274.7
        movl      %r14d, %r11d                                  #274.7
        shrl      $16, %r11d                                    #274.7
        movzbl    %r11b, %r15d                                  #274.7
        movd      2048+aes_style_table(,%r15,4), %xmm8          #274.7
        pxor      %xmm8, %xmm5                                  #274.7
        pxor      %xmm8, %xmm2                                  #274.7
        shrl      $24, %r14d                                    #274.7
        movd      3072+aes_style_table(,%r14,4), %xmm15         #274.7
        pxor      %xmm15, %xmm2                                 #274.7
        pxor      %xmm9, %xmm2                                  #274.7
        movzbl    %bpl, %ecx                                    #274.7
        movd      aes_style_table(,%rcx,4), %xmm7               #274.7
        pxor      %xmm7, %xmm3                                  #274.7
        movl      %ebp, %r8d                                    #274.7
        shrl      $8, %r8d                                      #274.7
        movzbl    %r8b, %r9d                                    #274.7
        movd      1024+aes_style_table(,%r9,4), %xmm10          #274.7
        pxor      %xmm10, %xmm7                                 #274.7
        movl      %ebp, %r11d                                   #274.7
        shrl      $16, %r11d                                    #274.7
        movzbl    %r11b, %r14d                                  #274.7
        movl      376(%rsp), %r11d                              #274.7
        movd      2048+aes_style_table(,%r14,4), %xmm11         #274.7
        pxor      %xmm11, %xmm5                                 #274.7
        pxor      %xmm11, %xmm7                                 #274.7
        shrl      $24, %ebp                                     #274.7
        movd      3072+aes_style_table(,%rbp,4), %xmm12         #274.7
        pxor      %xmm12, %xmm15                                #274.7
        pxor      %xmm12, %xmm7                                 #274.7
        pslldq    $4, %xmm7                                     #274.7
        movzbl    %r10b, %r15d                                  #274.7
        movd      aes_style_table(,%r15,4), %xmm6               #274.7
        pxor      %xmm6, %xmm3                                  #274.7
        movl      %r10d, %ecx                                   #274.7
        shrl      $8, %ecx                                      #274.7
        movzbl    %cl, %ebp                                     #274.7
        movd      1024+aes_style_table(,%rbp,4), %xmm13         #274.7
        movl      456(%rsp), %ecx                               #274.7
        pxor      %xmm13, %xmm4                                 #274.7
        pxor      %xmm13, %xmm6                                 #274.7
        movl      %r10d, %r8d                                   #274.7
        shrl      $16, %r8d                                     #274.7
        movzbl    %r8b, %r9d                                    #274.7
        movl      392(%rsp), %r8d                               #274.7
        movd      2048+aes_style_table(,%r9,4), %xmm14          #274.7
        movl      384(%rsp), %r9d                               #274.7
        pxor      %xmm14, %xmm6                                 #274.7
        shrl      $24, %r10d                                    #274.7
                                # LOE rcx r8 r9 r10 r11 eax edx ecx ebx esi edi r8d r9d r11d r12d r13d cl r8b r9b r11b ch xmm0 xmm1 xmm2 xmm3 xmm4 xmm5 xmm6 xmm7 xmm15
..B1.49:                        # Preds ..B1.48
        movq      344(%rsp), %r15                               #274.32
        movq      352(%rsp), %r14                               #274.32
        movd      3072+aes_style_table(,%r10,4), %xmm8          #274.7
        pxor      %xmm8, %xmm6                                  #274.7
        pslldq    $8, %xmm6                                     #274.7
        pxor      %xmm6, %xmm7                                  #274.7
        pxor      %xmm7, %xmm2                                  #274.7
        pshufb    %xmm0, %xmm2                                  #274.7
        pslldq    $8, %xmm5                                     #274.7
        pxor      %xmm8, %xmm15                                 #274.7
        pslldq    $12, %xmm15                                   #274.7
        pxor      %xmm15, %xmm5                                 #274.7
        pslldq    $4, %xmm4                                     #274.7
        pxor      %xmm4, %xmm3                                  #274.7
        pxor      %xmm3, %xmm5                                  #274.7
        lea       5(%r14,%r15), %r15                            #274.32
        pshufb    %xmm1, %xmm5                                  #274.7
        movq      %r15, 184(%rsp)                               #274.32
        movq      360(%rsp), %r15                               #268.5
        pxor      %xmm5, %xmm2                                  #274.7
        movdqa    %xmm2, %xmm3                                  #274.7
        movdqa    %xmm2, %xmm4                                  #274.7
        incq      %r15                                          #268.5
        movd      %xmm2, 56(%rsp)                               #274.7
        movq      %r15, 360(%rsp)                               #268.5
        psrldq    $4, %xmm3                                     #274.7
        psrldq    $8, %xmm4                                     #274.7
        psrldq    $12, %xmm2                                    #274.7
        movd      %xmm2, 320(%rsp)                              #274.7
        addq      $5, %r14                                      #268.5
        cmpq      368(%rsp), %r15                               #268.5
        movd      %xmm3, %ebp                                   #274.7
        movq      %r14, 352(%rsp)                               #268.5
        movd      %xmm4, %r10d                                  #274.7
        jb        ..B1.22       # Prob 82%                      #268.5
                                # LOE rcx r8 r9 r11 eax edx ecx ebx ebp esi edi r8d r9d r10d r11d r12d r13d cl r8b r9b r11b ch xmm0 xmm1
..B1.23:                        # Preds ..B1.49
        movl      136(%rsp), %r14d                              #
        movl      88(%rsp), %r15d                               #272.7
        movl      %r10d, 24(%rsp)                               #
        movl      312(%rsp), %r10d                              #
        movl      %ebp, 32(%rsp)                                #
        movq      184(%rsp), %rbp                               #
        movl      %ebx, 400(%rsp)                               #
        movq      8(%rsp), %rbx                                 #
        movl      %r12d, 408(%rsp)                              #
        movq      16(%rsp), %r12                                #
        movl      %r13d, 416(%rsp)                              #
        movl      320(%rsp), %r13d                              #
        movl      %r8d, 392(%rsp)                               #
        movl      160(%rsp), %r8d                               #
        movl      %r11d, 376(%rsp)                              #
        movl      96(%rsp), %r11d                               #
        movl      %r9d, 384(%rsp)                               #
        movl      120(%rsp), %r9d                               #
        movl      %r15d, 260(%rsp)                              #272.7
        movl      400(%rsp), %r15d                              #272.7
        movl      %r15d, 256(%rsp)                              #272.7
        movl      112(%rsp), %r15d                              #272.7
        movl      %r15d, 252(%rsp)                              #272.7
        movl      80(%rsp), %r15d                               #271.7
        movl      %r15d, 212(%rsp)                              #271.7
        movl      %r13d, 204(%rsp)                              #271.7
        movl      24(%rsp), %r13d                               #271.7
        movl      %esi, 272(%rsp)                               #271.7
        movl      416(%rsp), %esi                               #271.7
        movl      %edi, 268(%rsp)                               #271.7
        movl      72(%rsp), %edi                                #271.7
        movl      %r9d, 264(%rsp)                               #271.7
        movl      128(%rsp), %r9d                               #271.7
        movl      %esi, 220(%rsp)                               #271.7
        movl      408(%rsp), %esi                               #271.7
        movl      %r8d, 216(%rsp)                               #271.7
        movl      336(%rsp), %r8d                               #271.7
        movl      %edi, 284(%rsp)                               #271.7
        movl      144(%rsp), %edi                               #270.7
        movl      %r8d, 280(%rsp)                               #271.7
        movl      32(%rsp), %r8d                                #270.7
        movl      %r9d, 276(%rsp)                               #271.7
        movl      %r13d, 200(%rsp)                              #271.7
        movl      %esi, 208(%rsp)                               #271.7
        movl      384(%rsp), %esi                               #270.7
        movl      %r11d, 236(%rsp)                              #270.7
        movl      328(%rsp), %r11d                              #270.7
        movl      %r10d, 228(%rsp)                              #270.7
        movl      376(%rsp), %r10d                              #270.7
        movl      %r10d, 296(%rsp)                              #270.7
        movl      %ecx, 292(%rsp)                               #270.7
        movl      392(%rsp), %ecx                               #270.7
        movl      %r14d, 288(%rsp)                              #270.7
        movl      104(%rsp), %r14d                              #270.7
        movl      %ecx, 248(%rsp)                               #270.7
        movl      64(%rsp), %ecx                                #270.7
        movl      %r11d, 244(%rsp)                              #270.7
        movl      %r14d, 240(%rsp)                              #270.7
        movl      %ecx, 308(%rsp)                               #270.7
        movl      %esi, 304(%rsp)                               #270.7
        movl      %edi, 300(%rsp)                               #270.7
        movl      %r8d, 196(%rsp)                               #270.7
        movl      %edx, 224(%rsp)                               #270.7
        movl      56(%rsp), %edx                                #270.7
        movl      %edx, 192(%rsp)                               #270.7
        movl      %eax, 232(%rsp)                               #270.7
                                # LOE rbx rbp r12
..B1.24:                        # Preds ..B1.23 ..B1.20
        call      rdtsc                                         #277.15
                                # LOE rax rbx rbp r12
..B1.25:                        # Preds ..B1.24
        subq      40(%rsp), %rax                                #277.15
        movl      %eax, %ecx                                    #277.25
        movswq    %bx, %r13                                     #278.9
        testl     %r13d, %r13d                                  #278.19
        jle       ..B1.33       # Prob 50%                      #278.19
                                # LOE rbp r12 ecx r13d
..B1.26:                        # Preds ..B1.25
        movl      232(%rsp), %r15d                              #280.7
        xorl      192(%rsp), %r15d                              #280.7
        movq      168(%rsp), %r14                               #280.7
        movl      288(%rsp), %edx                               #280.7
        movl      196(%rsp), %r8d                               #280.7
        movl      300(%rsp), %r11d                              #280.7
        movl      200(%rsp), %ebx                               #280.7
        movl      (%r14,%rbp,4), %r10d                          #280.7
        movl      224(%rsp), %r14d                              #280.7
        movl      304(%rsp), %edi                               #280.7
        movl      204(%rsp), %r9d                               #280.7
        movl      308(%rsp), %esi                               #280.7
        movl      240(%rsp), %eax                               #280.7
        movl      %ebx, 144(%rsp)                               #280.7
        xorl      %r10d, %r14d                                  #280.7
        movl      %r9d, 16(%rsp)                                #280.7
        xorl      %edx, %r8d                                    #280.7
        movl      %r8d, 120(%rsp)                               #280.7
        xorl      %r8d, %r11d                                   #280.7
        xorl      %ebx, %edi                                    #280.7
        xorl      %r9d, %esi                                    #280.7
        xorl      %r8d, %eax                                    #280.7
        movl      244(%rsp), %r8d                               #280.7
        xorl      %ebx, %r8d                                    #280.7
        movl      248(%rsp), %ebx                               #280.7
        movl      %r8d, 152(%rsp)                               #280.7
        xorl      %r9d, %ebx                                    #280.7
        movzbl    %r10b, %r9d                                   #280.7
        movd      aes_style_table(,%r9,4), %xmm6                #280.7
        movdqa    %xmm6, %xmm13                                 #280.7
        movl      %ebx, 160(%rsp)                               #280.7
        movl      %r10d, %ebx                                   #280.7
        shrl      $8, %ebx                                      #280.7
        movzbl    %bl, %r8d                                     #280.7
        movd      1024+aes_style_table(,%r8,4), %xmm7           #280.7
        pxor      %xmm7, %xmm13                                 #280.7
        movl      %r10d, %ebx                                   #280.7
        shrl      $16, %ebx                                     #280.7
        movzbl    %bl, %r9d                                     #280.7
        movd      2048+aes_style_table(,%r9,4), %xmm9           #280.7
        pxor      %xmm9, %xmm13                                 #280.7
        shrl      $24, %r10d                                    #280.7
        movd      3072+aes_style_table(,%r10,4), %xmm10         #280.7
        pxor      %xmm10, %xmm13                                #280.7
        pslldq    $12, %xmm13                                   #280.7
        movzbl    %r11b, %ebx                                   #280.7
        movd      aes_style_table(,%rbx,4), %xmm8               #280.7
        movl      %r11d, %r8d                                   #280.7
        shrl      $8, %r8d                                      #280.7
        movzbl    %r8b, %r9d                                    #280.7
        movd      1024+aes_style_table(,%r9,4), %xmm11          #280.7
        pxor      %xmm11, %xmm7                                 #280.7
        pxor      %xmm11, %xmm8                                 #280.7
        movl      %r11d, %ebx                                   #280.7
        shrl      $16, %ebx                                     #280.7
        movzbl    %bl, %r10d                                    #280.7
        movd      2048+aes_style_table(,%r10,4), %xmm12         #280.7
        pxor      %xmm12, %xmm9                                 #280.7
        pxor      %xmm12, %xmm8                                 #280.7
        shrl      $24, %r11d                                    #280.7
        movd      3072+aes_style_table(,%r11,4), %xmm10         #280.7
        pxor      %xmm10, %xmm8                                 #280.7
        pxor      %xmm13, %xmm8                                 #280.7
        movzbl    %dil, %ebx                                    #280.7
        movd      aes_style_table(,%rbx,4), %xmm2               #280.7
        pxor      %xmm2, %xmm6                                  #280.7
        movl      %edi, %r8d                                    #280.7
        shrl      $8, %r8d                                      #280.7
        movzbl    %r8b, %r9d                                    #280.7
        movd      1024+aes_style_table(,%r9,4), %xmm14          #280.7
        pxor      %xmm14, %xmm2                                 #280.7
        movl      %edi, %ebx                                    #280.7
        shrl      $16, %ebx                                     #280.7
        movzbl    %bl, %r10d                                    #280.7
        movd      2048+aes_style_table(,%r10,4), %xmm15         #280.7
        pxor      %xmm15, %xmm9                                 #280.7
        pxor      %xmm15, %xmm2                                 #280.7
        shrl      $24, %edi                                     #280.7
        movd      3072+aes_style_table(,%rdi,4), %xmm0          #280.7
        pxor      %xmm0, %xmm10                                 #280.7
        pxor      %xmm0, %xmm2                                  #280.7
        pslldq    $4, %xmm2                                     #280.7
        movzbl    %sil, %r11d                                   #280.7
        movd      aes_style_table(,%r11,4), %xmm1               #280.7
        pxor      %xmm1, %xmm6                                  #280.7
        movl      %esi, %edi                                    #280.7
        shrl      $8, %edi                                      #280.7
        movzbl    %dil, %ebx                                    #280.7
        movl      296(%rsp), %edi                               #280.7
        movd      1024+aes_style_table(,%rbx,4), %xmm5          #280.7
        pxor      %xmm5, %xmm7                                  #280.7
        pxor      %xmm5, %xmm1                                  #280.7
        movl      %esi, %r8d                                    #280.7
        movdqa    _2il0floatpacket.4(%rip), %xmm5               #280.7
        shrl      $16, %r8d                                     #280.7
        movzbl    %r8b, %r9d                                    #280.7
        movd      2048+aes_style_table(,%r9,4), %xmm4           #280.7
        pxor      %xmm4, %xmm1                                  #280.7
        shrl      $24, %esi                                     #280.7
        movdqa    _2il0floatpacket.3(%rip), %xmm4               #280.7
        movl      228(%rsp), %r9d                               #280.7
        movd      3072+aes_style_table(,%rsi,4), %xmm3          #280.7
        movl      292(%rsp), %esi                               #280.7
        pxor      %xmm3, %xmm1                                  #280.7
        pslldq    $8, %xmm1                                     #280.7
        pxor      %xmm1, %xmm2                                  #280.7
        pxor      %xmm2, %xmm8                                  #280.7
        pslldq    $8, %xmm9                                     #280.7
        pxor      %xmm3, %xmm10                                 #280.7
        pslldq    $12, %xmm10                                   #280.7
        pxor      %xmm10, %xmm9                                 #280.7
        pshufb    %xmm5, %xmm8                                  #280.7
        pslldq    $4, %xmm7                                     #280.7
        pxor      %xmm7, %xmm6                                  #280.7
        pxor      %xmm6, %xmm9                                  #280.7
        pshufb    %xmm4, %xmm9                                  #280.7
        pxor      %xmm9, %xmm8                                  #280.7
        movdqa    %xmm8, %xmm6                                  #280.7
        movdqa    %xmm8, %xmm7                                  #280.7
        psrldq    $4, %xmm6                                     #280.7
        psrldq    $8, %xmm7                                     #280.7
        movd      %xmm8, %ebx                                   #280.7
        psrldq    $12, %xmm8                                    #280.7
        movd      %xmm6, %r10d                                  #280.7
        movd      %xmm7, %r11d                                  #280.7
        movd      %xmm8, %r8d                                   #280.7
        xorl      %r10d, %edx                                   #280.7
        movl      %r10d, 136(%rsp)                              #280.7
        movl      %r11d, 112(%rsp)                              #280.7
        movl      %r8d, 128(%rsp)                               #280.7
        xorl      %r11d, %esi                                   #280.7
        xorl      %r8d, %edi                                    #280.7
        xorl      %r10d, %r9d                                   #280.7
        movl      %r9d, 104(%rsp)                               #280.7
        movl      236(%rsp), %r9d                               #280.7
        xorl      %r11d, %r15d                                  #280.7
        xorl      %r8d, %r9d                                    #280.7
        movzbl    %bl, %r8d                                     #280.7
        movd      aes_style_table(,%r8,4), %xmm1                #280.7
        movdqa    %xmm1, %xmm12                                 #280.7
        movl      %r9d, 96(%rsp)                                #280.7
        movl      %ebx, %r10d                                   #280.7
        shrl      $8, %r10d                                     #280.7
        movzbl    %r10b, %r11d                                  #280.7
        movd      1024+aes_style_table(,%r11,4), %xmm2          #280.7
        pxor      %xmm2, %xmm12                                 #280.7
        movl      %ebx, %r8d                                    #280.7
        shrl      $16, %r8d                                     #280.7
        movzbl    %r8b, %r9d                                    #280.7
        movd      2048+aes_style_table(,%r9,4), %xmm3           #280.7
        pxor      %xmm3, %xmm12                                 #280.7
        shrl      $24, %ebx                                     #280.7
        movd      3072+aes_style_table(,%rbx,4), %xmm8          #280.7
        pxor      %xmm8, %xmm12                                 #280.7
        pslldq    $12, %xmm12                                   #280.7
        movzbl    %dl, %r10d                                    #280.7
        movd      aes_style_table(,%r10,4), %xmm0               #280.7
        movl      %edx, %r8d                                    #280.7
        shrl      $8, %r8d                                      #280.7
        movzbl    %r8b, %r11d                                   #280.7
        movd      1024+aes_style_table(,%r11,4), %xmm9          #280.7
        pxor      %xmm9, %xmm2                                  #280.7
        pxor      %xmm9, %xmm0                                  #280.7
        movl      %edx, %ebx                                    #280.7
        shrl      $16, %ebx                                     #280.7
        movzbl    %bl, %r8d                                     #280.7
        movd      2048+aes_style_table(,%r8,4), %xmm11          #280.7
        pxor      %xmm11, %xmm3                                 #280.7
        pxor      %xmm11, %xmm0                                 #280.7
        shrl      $24, %edx                                     #280.7
        movd      3072+aes_style_table(,%rdx,4), %xmm7          #280.7
        pxor      %xmm7, %xmm0                                  #280.7
        pxor      %xmm12, %xmm0                                 #280.7
        movzbl    %sil, %r9d                                    #280.7
        movd      aes_style_table(,%r9,4), %xmm6                #280.7
        pxor      %xmm6, %xmm1                                  #280.7
        movl      %esi, %edx                                    #280.7
        shrl      $8, %edx                                      #280.7
        movzbl    %dl, %ebx                                     #280.7
        movd      1024+aes_style_table(,%rbx,4), %xmm13         #280.7
        pxor      %xmm13, %xmm6                                 #280.7
        movl      %esi, %r8d                                    #280.7
        shrl      $16, %r8d                                     #280.7
        movzbl    %r8b, %r9d                                    #280.7
        movl      160(%rsp), %r8d                               #281.23
        movd      2048+aes_style_table(,%r9,4), %xmm14          #280.7
        pxor      %xmm14, %xmm3                                 #280.7
        pxor      %xmm14, %xmm6                                 #280.7
        shrl      $24, %esi                                     #280.7
        movd      3072+aes_style_table(,%rsi,4), %xmm15         #280.7
        pxor      %xmm15, %xmm7                                 #280.7
        pxor      %xmm15, %xmm6                                 #280.7
        pslldq    $4, %xmm6                                     #280.7
        movzbl    %dil, %r10d                                   #280.7
        movd      aes_style_table(,%r10,4), %xmm12              #280.7
        pxor      %xmm12, %xmm1                                 #280.7
        movl      %edi, %r11d                                   #280.7
        shrl      $8, %r11d                                     #280.7
        movzbl    %r11b, %edx                                   #280.7
        movd      1024+aes_style_table(,%rdx,4), %xmm13         #280.7
        pxor      %xmm13, %xmm2                                 #280.7
        pxor      %xmm13, %xmm12                                #280.7
        movl      %edi, %ebx                                    #280.7
        shrl      $16, %ebx                                     #280.7
        movzbl    %bl, %esi                                     #280.7
        movd      2048+aes_style_table(,%rsi,4), %xmm14         #280.7
        pxor      %xmm14, %xmm12                                #280.7
        shrl      $24, %edi                                     #280.7
        movd      3072+aes_style_table(,%rdi,4), %xmm15         #280.7
        movl      152(%rsp), %edi                               #281.23
        pxor      %xmm15, %xmm12                                #280.7
        pslldq    $8, %xmm12                                    #280.7
        pxor      %xmm12, %xmm6                                 #280.7
        pxor      %xmm6, %xmm0                                  #280.7
        pslldq    $8, %xmm3                                     #280.7
        pxor      %xmm15, %xmm7                                 #280.7
        pslldq    $12, %xmm7                                    #280.7
        pxor      %xmm7, %xmm3                                  #280.7
        pshufb    %xmm5, %xmm0                                  #280.7
        pslldq    $4, %xmm2                                     #280.7
        pxor      %xmm2, %xmm1                                  #280.7
        pxor      %xmm1, %xmm3                                  #280.7
        pshufb    %xmm4, %xmm3                                  #280.7
        pxor      %xmm3, %xmm0                                  #280.7
        movdqa    %xmm0, %xmm1                                  #280.7
        movdqa    %xmm0, %xmm2                                  #280.7
        cmpl      $2, %r13d                                     #281.23
        psrldq    $4, %xmm1                                     #280.7
        psrldq    $8, %xmm2                                     #280.7
        movd      %xmm0, %edx                                   #280.7
        psrldq    $12, %xmm0                                    #280.7
        movd      %xmm1, %r11d                                  #280.7
        movd      %xmm2, %r10d                                  #280.7
        movd      %xmm0, %r9d                                   #280.7
        jl        ..B1.32       # Prob 50%                      #281.23
                                # LOE rbp rdi r8 r12 eax edx ecx edi r8d r9d r10d r11d r13d r14d r15d dil r8b
..B1.27:                        # Preds ..B1.26
        movl      208(%rsp), %ebx                               #283.4
        movl      284(%rsp), %esi                               #283.4
        movl      %eax, 8(%rsp)                                 #
        movl      216(%rsp), %eax                               #283.4
        movl      %edi, 152(%rsp)                               #
        xorl      %edx, %ebx                                    #283.4
        movq      168(%rsp), %rdx                               #283.4
        movl      4(%rdx,%rbp,4), %edi                          #283.4
        movl      264(%rsp), %edx                               #283.4
        xorl      %edi, 144(%rsp)                               #283.4
        xorl      %edx, %r11d                                   #283.4
        movl      %r8d, 160(%rsp)                               #
        movl      276(%rsp), %r8d                               #283.4
        movl      %r15d, 72(%rsp)                               #
        movl      280(%rsp), %r15d                              #283.4
        movl      %r11d, 80(%rsp)                               #283.4
        xorl      %r11d, %r8d                                   #283.4
        xorl      %r10d, %r15d                                  #283.4
        xorl      %r9d, %esi                                    #283.4
        xorl      %r11d, %eax                                   #283.4
        movl      220(%rsp), %r11d                              #283.4
        movl      %eax, 48(%rsp)                                #283.4
        xorl      %r10d, %r11d                                  #283.4
        movl      %r11d, 32(%rsp)                               #283.4
        xorl      %r9d, %r14d                                   #283.4
        movl      %r14d, 88(%rsp)                               #283.4
        movzbl    %dil, %r14d                                   #283.4
        movd      aes_style_table(,%r14,4), %xmm6               #283.4
        movdqa    %xmm6, %xmm13                                 #283.4
        movl      %edi, %r11d                                   #283.4
        shrl      $8, %r11d                                     #283.4
        movzbl    %r11b, %r11d                                  #283.4
        movd      1024+aes_style_table(,%r11,4), %xmm7          #283.4
        pxor      %xmm7, %xmm13                                 #283.4
        movl      %edi, %r11d                                   #283.4
        shrl      $16, %r11d                                    #283.4
        movzbl    %r11b, %r11d                                  #283.4
        movd      2048+aes_style_table(,%r11,4), %xmm9          #283.4
        pxor      %xmm9, %xmm13                                 #283.4
        shrl      $24, %edi                                     #283.4
        movd      3072+aes_style_table(,%rdi,4), %xmm10         #283.4
        pxor      %xmm10, %xmm13                                #283.4
        pslldq    $12, %xmm13                                   #283.4
        movzbl    %r8b, %edi                                    #283.4
        movd      aes_style_table(,%rdi,4), %xmm8               #283.4
        movl      %r8d, %edi                                    #283.4
        shrl      $8, %edi                                      #283.4
        movzbl    %dil, %edi                                    #283.4
        movd      1024+aes_style_table(,%rdi,4), %xmm11         #283.4
        pxor      %xmm11, %xmm7                                 #283.4
        pxor      %xmm11, %xmm8                                 #283.4
        movl      %r8d, %edi                                    #283.4
        shrl      $16, %edi                                     #283.4
        movzbl    %dil, %edi                                    #283.4
        movd      2048+aes_style_table(,%rdi,4), %xmm12         #283.4
        pxor      %xmm12, %xmm9                                 #283.4
        pxor      %xmm12, %xmm8                                 #283.4
        shrl      $24, %r8d                                     #283.4
        movd      3072+aes_style_table(,%r8,4), %xmm10          #283.4
        pxor      %xmm10, %xmm8                                 #283.4
        pxor      %xmm13, %xmm8                                 #283.4
        movzbl    %r15b, %edi                                   #283.4
        movd      aes_style_table(,%rdi,4), %xmm2               #283.4
        pxor      %xmm2, %xmm6                                  #283.4
        movl      %r15d, %r11d                                  #283.4
        shrl      $8, %r11d                                     #283.4
        movzbl    %r11b, %edi                                   #283.4
        movl      268(%rsp), %r11d                              #283.4
        movd      1024+aes_style_table(,%rdi,4), %xmm14         #283.4
        pxor      %xmm14, %xmm2                                 #283.4
        movl      %r15d, %r14d                                  #283.4
        shrl      $16, %r14d                                    #283.4
        movzbl    %r14b, %edi                                   #283.4
        movd      2048+aes_style_table(,%rdi,4), %xmm15         #283.4
        pxor      %xmm15, %xmm9                                 #283.4
        pxor      %xmm15, %xmm2                                 #283.4
        shrl      $24, %r15d                                    #283.4
        movd      3072+aes_style_table(,%r15,4), %xmm0          #283.4
        pxor      %xmm0, %xmm10                                 #283.4
        pxor      %xmm0, %xmm2                                  #283.4
        pslldq    $4, %xmm2                                     #283.4
        movzbl    %sil, %edi                                    #283.4
        movd      aes_style_table(,%rdi,4), %xmm1               #283.4
        pxor      %xmm1, %xmm6                                  #283.4
        movl      %esi, %r8d                                    #283.4
        shrl      $8, %r8d                                      #283.4
        movzbl    %r8b, %edi                                    #283.4
        movd      1024+aes_style_table(,%rdi,4), %xmm5          #283.4
        movl      16(%rsp), %r8d                                #283.4
        pxor      %xmm5, %xmm7                                  #283.4
        pxor      %xmm5, %xmm1                                  #283.4
        movdqa    _2il0floatpacket.4(%rip), %xmm5               #283.4
        movl      %esi, %edi                                    #283.4
        shrl      $16, %edi                                     #283.4
        movzbl    %dil, %edi                                    #283.4
        movd      2048+aes_style_table(,%rdi,4), %xmm4          #283.4
        pxor      %xmm4, %xmm1                                  #283.4
        movdqa    _2il0floatpacket.3(%rip), %xmm4               #283.4
        shrl      $24, %esi                                     #283.4
        movd      3072+aes_style_table(,%rsi,4), %xmm3          #283.4
        movl      272(%rsp), %esi                               #283.4
        pxor      %xmm3, %xmm1                                  #283.4
        pslldq    $8, %xmm1                                     #283.4
        pxor      %xmm1, %xmm2                                  #283.4
        pxor      %xmm2, %xmm8                                  #283.4
        pslldq    $8, %xmm9                                     #283.4
        pshufb    %xmm5, %xmm8                                  #283.4
        pxor      %xmm3, %xmm10                                 #283.4
        pslldq    $12, %xmm10                                   #283.4
        pxor      %xmm10, %xmm9                                 #283.4
        pslldq    $4, %xmm7                                     #283.4
        pxor      %xmm7, %xmm6                                  #283.4
        pxor      %xmm6, %xmm9                                  #283.4
        pshufb    %xmm4, %xmm9                                  #283.4
        pxor      %xmm9, %xmm8                                  #283.4
        movdqa    %xmm8, %xmm6                                  #283.4
        movdqa    %xmm8, %xmm7                                  #283.4
        psrldq    $4, %xmm6                                     #283.4
        psrldq    $8, %xmm7                                     #283.4
        movd      %xmm8, %r14d                                  #283.4
        psrldq    $12, %xmm8                                    #283.4
        movd      %xmm6, %edi                                   #283.4
        movd      %xmm7, %r15d                                  #283.4
        movd      %xmm8, %eax                                   #283.4
        xorl      %edi, %edx                                    #283.4
        movl      %edi, 40(%rsp)                                #283.4
        movl      %r15d, 24(%rsp)                               #283.4
        movl      %eax, 56(%rsp)                                #283.4
        xorl      %eax, 212(%rsp)                               #283.4
        xorl      %r15d, %r11d                                  #283.4
        xorl      %eax, %esi                                    #283.4
        movl      8(%rsp), %eax                                 #284.27
        xorl      %edi, %r8d                                    #283.4
        movl      %r8d, 204(%rsp)                               #283.4
        xorl      %r15d, %ebx                                   #283.4
        movl      %ebx, 208(%rsp)                               #283.4
        movzbl    %r14b, %ebx                                   #283.4
        movd      aes_style_table(,%rbx,4), %xmm1               #283.4
        movdqa    %xmm1, %xmm12                                 #283.4
        movl      %r14d, %edi                                   #283.4
        shrl      $8, %edi                                      #283.4
        movzbl    %dil, %ebx                                    #283.4
        movd      1024+aes_style_table(,%rbx,4), %xmm2          #283.4
        pxor      %xmm2, %xmm12                                 #283.4
        movl      %r14d, %r8d                                   #283.4
        shrl      $16, %r8d                                     #283.4
        movzbl    %r8b, %r15d                                   #283.4
        movd      2048+aes_style_table(,%r15,4), %xmm3          #283.4
        pxor      %xmm3, %xmm12                                 #283.4
        shrl      $24, %r14d                                    #283.4
        movd      3072+aes_style_table(,%r14,4), %xmm8          #283.4
        pxor      %xmm8, %xmm12                                 #283.4
        pslldq    $12, %xmm12                                   #283.4
        movzbl    %dl, %ebx                                     #283.4
        movd      aes_style_table(,%rbx,4), %xmm0               #283.4
        movl      %edx, %ebx                                    #283.4
        shrl      $8, %ebx                                      #283.4
        movzbl    %bl, %ebx                                     #283.4
        movd      1024+aes_style_table(,%rbx,4), %xmm9          #283.4
        pxor      %xmm9, %xmm2                                  #283.4
        pxor      %xmm9, %xmm0                                  #283.4
        movl      %edx, %ebx                                    #283.4
        shrl      $16, %ebx                                     #283.4
        movzbl    %bl, %ebx                                     #283.4
        movd      2048+aes_style_table(,%rbx,4), %xmm11         #283.4
        pxor      %xmm11, %xmm3                                 #283.4
        pxor      %xmm11, %xmm0                                 #283.4
        shrl      $24, %edx                                     #283.4
        movd      3072+aes_style_table(,%rdx,4), %xmm7          #283.4
        pxor      %xmm7, %xmm0                                  #283.4
        pxor      %xmm12, %xmm0                                 #283.4
        movzbl    %r11b, %edi                                   #283.4
        movd      aes_style_table(,%rdi,4), %xmm6               #283.4
        movl      152(%rsp), %edi                               #284.27
        pxor      %xmm6, %xmm1                                  #283.4
        movl      %r11d, %r8d                                   #283.4
        shrl      $8, %r8d                                      #283.4
        movzbl    %r8b, %r14d                                   #283.4
        movl      160(%rsp), %r8d                               #284.27
        movd      1024+aes_style_table(,%r14,4), %xmm13         #283.4
        movl      88(%rsp), %r14d                               #284.27
        pxor      %xmm13, %xmm6                                 #283.4
        movl      %r11d, %r15d                                  #283.4
        shrl      $16, %r15d                                    #283.4
        movzbl    %r15b, %edx                                   #283.4
        movl      72(%rsp), %r15d                               #284.27
        movd      2048+aes_style_table(,%rdx,4), %xmm14         #283.4
        pxor      %xmm14, %xmm3                                 #283.4
        pxor      %xmm14, %xmm6                                 #283.4
        shrl      $24, %r11d                                    #283.4
        movd      3072+aes_style_table(,%r11,4), %xmm15         #283.4
        movl      80(%rsp), %r11d                               #284.27
        pxor      %xmm15, %xmm7                                 #283.4
        pxor      %xmm15, %xmm6                                 #283.4
        pslldq    $4, %xmm6                                     #283.4
        movzbl    %sil, %edx                                    #283.4
        movd      aes_style_table(,%rdx,4), %xmm12              #283.4
        pxor      %xmm12, %xmm1                                 #283.4
        movl      %esi, %edx                                    #283.4
        shrl      $8, %edx                                      #283.4
        movzbl    %dl, %edx                                     #283.4
        movd      1024+aes_style_table(,%rdx,4), %xmm13         #283.4
        pxor      %xmm13, %xmm2                                 #283.4
        pxor      %xmm13, %xmm12                                #283.4
        movl      %esi, %edx                                    #283.4
        shrl      $16, %edx                                     #283.4
        movzbl    %dl, %edx                                     #283.4
        movd      2048+aes_style_table(,%rdx,4), %xmm14         #283.4
        pxor      %xmm14, %xmm12                                #283.4
        shrl      $24, %esi                                     #283.4
        movd      3072+aes_style_table(,%rsi,4), %xmm15         #283.4
        pxor      %xmm15, %xmm12                                #283.4
        pslldq    $8, %xmm12                                    #283.4
        pxor      %xmm12, %xmm6                                 #283.4
        pxor      %xmm6, %xmm0                                  #283.4
        pslldq    $8, %xmm3                                     #283.4
        pxor      %xmm15, %xmm7                                 #283.4
        pslldq    $12, %xmm7                                    #283.4
        pxor      %xmm7, %xmm3                                  #283.4
        pshufb    %xmm5, %xmm0                                  #283.4
        pslldq    $4, %xmm2                                     #283.4
        pxor      %xmm2, %xmm1                                  #283.4
        pxor      %xmm1, %xmm3                                  #283.4
        pshufb    %xmm4, %xmm3                                  #283.4
        pxor      %xmm3, %xmm0                                  #283.4
        movdqa    %xmm0, %xmm1                                  #283.4
        movdqa    %xmm0, %xmm2                                  #283.4
        cmpl      $3, %r13d                                     #284.27
        psrldq    $4, %xmm1                                     #283.4
        psrldq    $8, %xmm2                                     #283.4
        movd      %xmm0, %ebx                                   #283.4
        psrldq    $12, %xmm0                                    #283.4
        movd      %xmm2, 64(%rsp)                               #283.4
        movd      %xmm1, %esi                                   #283.4
        movd      %xmm0, %edx                                   #283.4
        jl        ..B1.31       # Prob 50%                      #284.27
                                # LOE rax rbp rdi r8 r11 r12 r14 r15 eax edx ecx ebx esi edi r8d r9d r10d r11d r13d r14d r15d al dil r8b r11b r14b r15b ah
..B1.28:                        # Preds ..B1.27
        movq      %rbp, 184(%rsp)                               #
        xorl      %eax, %esi                                    #286.8
        movl      %ecx, 8(%rsp)                                 #
        movl      136(%rsp), %ecx                               #286.8
        movl      %r15d, 72(%rsp)                               #
        movq      168(%rsp), %r15                               #286.8
        movl      %r11d, 80(%rsp)                               #
        movl      64(%rsp), %r11d                               #286.8
        movl      %r14d, 88(%rsp)                               #
        movl      8(%r15,%rbp,4), %r14d                         #286.8
        movl      256(%rsp), %ebp                               #286.8
        movl      128(%rsp), %r15d                              #286.8
        movl      %esi, 268(%rsp)                               #286.8
        xorl      %ebx, %ecx                                    #286.8
        movl      260(%rsp), %ebx                               #286.8
        xorl      %r14d, %r10d                                  #286.8
        movl      %r10d, 16(%rsp)                               #286.8
        movl      252(%rsp), %r10d                              #286.8
        xorl      %esi, %r10d                                   #286.8
        xorl      %r11d, %ebp                                   #286.8
        xorl      %edx, %ebx                                    #286.8
        xorl      %esi, %r15d                                   #286.8
        movl      120(%rsp), %esi                               #286.8
        movl      %r15d, 192(%rsp)                              #286.8
        xorl      %r11d, %esi                                   #286.8
        movl      144(%rsp), %r11d                              #286.8
        movl      %esi, 196(%rsp)                               #286.8
        xorl      %edx, %r11d                                   #286.8
        movl      %r11d, 200(%rsp)                              #286.8
        movzbl    %r14b, %esi                                   #286.8
        movd      aes_style_table(,%rsi,4), %xmm6               #286.8
        movdqa    %xmm6, %xmm13                                 #286.8
        movl      %r14d, %r15d                                  #286.8
        shrl      $8, %r15d                                     #286.8
        movzbl    %r15b, %r11d                                  #286.8
        movd      1024+aes_style_table(,%r11,4), %xmm7          #286.8
        pxor      %xmm7, %xmm13                                 #286.8
        movl      %r14d, %esi                                   #286.8
        shrl      $16, %esi                                     #286.8
        movzbl    %sil, %r11d                                   #286.8
        movd      2048+aes_style_table(,%r11,4), %xmm9          #286.8
        pxor      %xmm9, %xmm13                                 #286.8
        shrl      $24, %r14d                                    #286.8
        movd      3072+aes_style_table(,%r14,4), %xmm10         #286.8
        pxor      %xmm10, %xmm13                                #286.8
        pslldq    $12, %xmm13                                   #286.8
        movzbl    %r10b, %esi                                   #286.8
        movd      aes_style_table(,%rsi,4), %xmm8               #286.8
        movl      %r10d, %r15d                                  #286.8
        shrl      $8, %r15d                                     #286.8
        movzbl    %r15b, %r11d                                  #286.8
        movd      1024+aes_style_table(,%r11,4), %xmm11         #286.8
        pxor      %xmm11, %xmm7                                 #286.8
        pxor      %xmm11, %xmm8                                 #286.8
        movl      %r10d, %esi                                   #286.8
        shrl      $16, %esi                                     #286.8
        movzbl    %sil, %r14d                                   #286.8
        movd      2048+aes_style_table(,%r14,4), %xmm12         #286.8
        pxor      %xmm12, %xmm9                                 #286.8
        pxor      %xmm12, %xmm8                                 #286.8
        shrl      $24, %r10d                                    #286.8
        movd      3072+aes_style_table(,%r10,4), %xmm10         #286.8
        pxor      %xmm10, %xmm8                                 #286.8
        pxor      %xmm13, %xmm8                                 #286.8
        movzbl    %bpl, %esi                                    #286.8
        movd      aes_style_table(,%rsi,4), %xmm2               #286.8
        pxor      %xmm2, %xmm6                                  #286.8
        movl      %ebp, %r11d                                   #286.8
        shrl      $8, %r11d                                     #286.8
        movzbl    %r11b, %r10d                                  #286.8
        movd      1024+aes_style_table(,%r10,4), %xmm14         #286.8
        pxor      %xmm14, %xmm2                                 #286.8
        movl      %ebp, %r15d                                   #286.8
        shrl      $16, %r15d                                    #286.8
        movzbl    %r15b, %r14d                                  #286.8
        movd      2048+aes_style_table(,%r14,4), %xmm15         #286.8
        pxor      %xmm15, %xmm9                                 #286.8
        pxor      %xmm15, %xmm2                                 #286.8
        shrl      $24, %ebp                                     #286.8
        movd      3072+aes_style_table(,%rbp,4), %xmm0          #286.8
        pxor      %xmm0, %xmm10                                 #286.8
        pxor      %xmm0, %xmm2                                  #286.8
        pslldq    $4, %xmm2                                     #286.8
        movzbl    %bl, %esi                                     #286.8
        movd      aes_style_table(,%rsi,4), %xmm1               #286.8
        pxor      %xmm1, %xmm6                                  #286.8
        movl      %ebx, %r10d                                   #286.8
        shrl      $8, %r10d                                     #286.8
        movzbl    %r10b, %ebp                                   #286.8
        movd      1024+aes_style_table(,%rbp,4), %xmm5          #286.8
        pxor      %xmm5, %xmm7                                  #286.8
        pxor      %xmm5, %xmm1                                  #286.8
        movdqa    _2il0floatpacket.4(%rip), %xmm5               #286.8
        movl      %ebx, %r11d                                   #286.8
        shrl      $16, %r11d                                    #286.8
        movzbl    %r11b, %r14d                                  #286.8
        movd      2048+aes_style_table(,%r14,4), %xmm4          #286.8
        pxor      %xmm4, %xmm1                                  #286.8
        movdqa    _2il0floatpacket.3(%rip), %xmm4               #286.8
        shrl      $24, %ebx                                     #286.8
        movd      3072+aes_style_table(,%rbx,4), %xmm3          #286.8
        pxor      %xmm3, %xmm1                                  #286.8
        pslldq    $8, %xmm1                                     #286.8
        pxor      %xmm1, %xmm2                                  #286.8
        pxor      %xmm2, %xmm8                                  #286.8
        pslldq    $8, %xmm9                                     #286.8
        pxor      %xmm3, %xmm10                                 #286.8
        pshufb    %xmm5, %xmm8                                  #286.8
        pslldq    $12, %xmm10                                   #286.8
        pxor      %xmm10, %xmm9                                 #286.8
        pslldq    $4, %xmm7                                     #286.8
        pxor      %xmm7, %xmm6                                  #286.8
        pxor      %xmm6, %xmm9                                  #286.8
        pshufb    %xmm4, %xmm9                                  #286.8
        pxor      %xmm9, %xmm8                                  #286.8
        movdqa    %xmm8, %xmm6                                  #286.8
        movdqa    %xmm8, %xmm7                                  #286.8
        psrldq    $4, %xmm6                                     #286.8
        psrldq    $8, %xmm7                                     #286.8
        movd      %xmm8, %esi                                   #286.8
        psrldq    $12, %xmm8                                    #286.8
        movd      %xmm6, %r15d                                  #286.8
        movd      %xmm7, %ebx                                   #286.8
        movd      %xmm8, %ebp                                   #286.8
        xorl      %r15d, %eax                                   #286.8
        movl      %r15d, 256(%rsp)                              #286.8
        movl      %ebx, 260(%rsp)                               #286.8
        movl      %ebp, 264(%rsp)                               #286.8
        xorl      %ebx, %edi                                    #286.8
        xorl      %ebp, %r8d                                    #286.8
        xorl      %r15d, %r9d                                   #286.8
        movl      %r9d, 300(%rsp)                               #286.8
        movl      112(%rsp), %r9d                               #286.8
        xorl      %ecx, %ebx                                    #286.8
        movl      %ebx, 304(%rsp)                               #286.8
        xorl      %ebp, %r9d                                    #286.8
        movzbl    %sil, %ecx                                    #286.8
        movd      aes_style_table(,%rcx,4), %xmm1               #286.8
        movdqa    %xmm1, %xmm12                                 #286.8
        movl      %r9d, 308(%rsp)                               #286.8
        movl      %esi, %ebx                                    #286.8
        shrl      $8, %ebx                                      #286.8
        movzbl    %bl, %ebp                                     #286.8
        movd      1024+aes_style_table(,%rbp,4), %xmm2          #286.8
        pxor      %xmm2, %xmm12                                 #286.8
        movl      %esi, %r10d                                   #286.8
        shrl      $16, %r10d                                    #286.8
        movzbl    %r10b, %r9d                                   #286.8
        movd      2048+aes_style_table(,%r9,4), %xmm3           #286.8
        pxor      %xmm3, %xmm12                                 #286.8
        shrl      $24, %esi                                     #286.8
        movd      3072+aes_style_table(,%rsi,4), %xmm8          #286.8
        pxor      %xmm8, %xmm12                                 #286.8
        pslldq    $12, %xmm12                                   #286.8
        movzbl    %al, %r11d                                    #286.8
        movd      aes_style_table(,%r11,4), %xmm0               #286.8
        movl      %eax, %r14d                                   #286.8
        shrl      $8, %r14d                                     #286.8
        movzbl    %r14b, %r15d                                  #286.8
        movd      1024+aes_style_table(,%r15,4), %xmm9          #286.8
        pxor      %xmm9, %xmm2                                  #286.8
        pxor      %xmm9, %xmm0                                  #286.8
        movl      %eax, %ecx                                    #286.8
        shrl      $16, %ecx                                     #286.8
        movzbl    %cl, %ebx                                     #286.8
        movd      2048+aes_style_table(,%rbx,4), %xmm11         #286.8
        pxor      %xmm11, %xmm3                                 #286.8
        pxor      %xmm11, %xmm0                                 #286.8
        shrl      $24, %eax                                     #286.8
        movd      3072+aes_style_table(,%rax,4), %xmm7          #286.8
        pxor      %xmm7, %xmm0                                  #286.8
        pxor      %xmm12, %xmm0                                 #286.8
        movzbl    %dil, %ebp                                    #286.8
        movd      aes_style_table(,%rbp,4), %xmm6               #286.8
        movq      184(%rsp), %rbp                               #287.31
        pxor      %xmm6, %xmm1                                  #286.8
        movl      %edi, %esi                                    #286.8
        shrl      $8, %esi                                      #286.8
        movzbl    %sil, %r9d                                    #286.8
        movd      1024+aes_style_table(,%r9,4), %xmm13          #286.8
        pxor      %xmm13, %xmm6                                 #286.8
        movl      %edi, %r10d                                   #286.8
        shrl      $16, %r10d                                    #286.8
        movzbl    %r10b, %eax                                   #286.8
        movl      16(%rsp), %r10d                               #287.31
        movd      2048+aes_style_table(,%rax,4), %xmm14         #286.8
        pxor      %xmm14, %xmm3                                 #286.8
        pxor      %xmm14, %xmm6                                 #286.8
        shrl      $24, %edi                                     #286.8
        movd      3072+aes_style_table(,%rdi,4), %xmm15         #286.8
        pxor      %xmm15, %xmm7                                 #286.8
        pxor      %xmm15, %xmm6                                 #286.8
        pslldq    $4, %xmm6                                     #286.8
        movzbl    %r8b, %ecx                                    #286.8
        movd      aes_style_table(,%rcx,4), %xmm12              #286.8
        movl      8(%rsp), %ecx                                 #287.31
        pxor      %xmm12, %xmm1                                 #286.8
        movl      %r8d, %ebx                                    #286.8
        shrl      $8, %ebx                                      #286.8
        movzbl    %bl, %r11d                                    #286.8
        movd      1024+aes_style_table(,%r11,4), %xmm13         #286.8
        movl      80(%rsp), %r11d                               #287.31
        pxor      %xmm13, %xmm2                                 #286.8
        pxor      %xmm13, %xmm12                                #286.8
        movl      %r8d, %r14d                                   #286.8
        shrl      $16, %r14d                                    #286.8
        movzbl    %r14b, %r15d                                  #286.8
        movl      88(%rsp), %r14d                               #287.31
        movd      2048+aes_style_table(,%r15,4), %xmm14         #286.8
        movl      72(%rsp), %r15d                               #287.31
        pxor      %xmm14, %xmm12                                #286.8
        shrl      $24, %r8d                                     #286.8
        movd      3072+aes_style_table(,%r8,4), %xmm15          #286.8
        pxor      %xmm15, %xmm12                                #286.8
        pslldq    $8, %xmm12                                    #286.8
        pxor      %xmm12, %xmm6                                 #286.8
        pxor      %xmm6, %xmm0                                  #286.8
        pslldq    $8, %xmm3                                     #286.8
        pxor      %xmm15, %xmm7                                 #286.8
        pshufb    %xmm5, %xmm0                                  #286.8
        pslldq    $12, %xmm7                                    #286.8
        pxor      %xmm7, %xmm3                                  #286.8
        pslldq    $4, %xmm2                                     #286.8
        pxor      %xmm2, %xmm1                                  #286.8
        pxor      %xmm1, %xmm3                                  #286.8
        cmpl      $4, %r13d                                     #287.31
        pshufb    %xmm4, %xmm3                                  #286.8
        pxor      %xmm3, %xmm0                                  #286.8
        movdqa    %xmm0, %xmm1                                  #286.8
        movdqa    %xmm0, %xmm2                                  #286.8
        psrldq    $4, %xmm1                                     #286.8
        psrldq    $8, %xmm2                                     #286.8
        movd      %xmm0, %r9d                                   #286.8
        psrldq    $12, %xmm0                                    #286.8
        movd      %xmm1, %ebx                                   #286.8
        movd      %xmm2, %esi                                   #286.8
        movl      %esi, 248(%rsp)                               #286.8
        movd      %xmm0, %edi                                   #286.8
        movl      %edi, 252(%rsp)                               #286.8
        jl        ..B1.30       # Prob 50%                      #287.31
                                # LOE rcx rbp r10 r11 r12 r14 r15 edx ecx ebx esi edi r9d r10d r11d r13d r14d r15d cl r10b r11b r14b r15b ch
..B1.29:                        # Preds ..B1.28
        movl      40(%rsp), %r8d                                #289.5
        movl      %r13d, 8(%rsp)                                #
        movl      104(%rsp), %r13d                              #289.5
        xorl      %r9d, %r8d                                    #289.5
        xorl      %esi, %r15d                                   #289.5
        movq      168(%rsp), %r9                                #289.5
        movl      12(%r9,%rbp,4), %eax                          #289.5
        movl      64(%rsp), %ebp                                #289.5
        movl      96(%rsp), %r9d                                #289.5
        xorl      %eax, %ebp                                    #289.5
        xorl      %edi, %r9d                                    #289.5
        movl      %ebp, 272(%rsp)                               #289.5
        movl      48(%rsp), %ebp                                #289.5
        xorl      %ebp, %ebx                                    #289.5
        movl      %ebx, 244(%rsp)                               #289.5
        xorl      %ebx, %r13d                                   #289.5
        xorl      %r11d, %esi                                   #289.5
        xorl      56(%rsp), %ebx                                #289.5
        xorl      %r10d, %edi                                   #289.5
        movl      %ebx, 288(%rsp)                               #289.5
        movl      %eax, %r11d                                   #289.5
        movl      %esi, 292(%rsp)                               #289.5
        movl      %edi, 296(%rsp)                               #289.5
        movzbl    %al, %esi                                     #289.5
        movd      aes_style_table(,%rsi,4), %xmm6               #289.5
        movdqa    %xmm6, %xmm13                                 #289.5
        movl      %eax, %edi                                    #289.5
        shrl      $8, %edi                                      #289.5
        movzbl    %dil, %r10d                                   #289.5
        movd      1024+aes_style_table(,%r10,4), %xmm7          #289.5
        pxor      %xmm7, %xmm13                                 #289.5
        shrl      $16, %r11d                                    #289.5
        movzbl    %r11b, %ebx                                   #289.5
        movd      2048+aes_style_table(,%rbx,4), %xmm9          #289.5
        pxor      %xmm9, %xmm13                                 #289.5
        shrl      $24, %eax                                     #289.5
        movd      3072+aes_style_table(,%rax,4), %xmm10         #289.5
        pxor      %xmm10, %xmm13                                #289.5
        pslldq    $12, %xmm13                                   #289.5
        movzbl    %r13b, %esi                                   #289.5
        movd      aes_style_table(,%rsi,4), %xmm8               #289.5
        movl      %r13d, %edi                                   #289.5
        shrl      $8, %edi                                      #289.5
        movzbl    %dil, %r10d                                   #289.5
        movd      1024+aes_style_table(,%r10,4), %xmm11         #289.5
        pxor      %xmm11, %xmm7                                 #289.5
        pxor      %xmm11, %xmm8                                 #289.5
        movl      %r13d, %ebx                                   #289.5
        shrl      $16, %ebx                                     #289.5
        movzbl    %bl, %esi                                     #289.5
        movd      2048+aes_style_table(,%rsi,4), %xmm12         #289.5
        pxor      %xmm12, %xmm9                                 #289.5
        pxor      %xmm12, %xmm8                                 #289.5
        shrl      $24, %r13d                                    #289.5
        movd      3072+aes_style_table(,%r13,4), %xmm10         #289.5
        pxor      %xmm10, %xmm8                                 #289.5
        pxor      %xmm13, %xmm8                                 #289.5
        movzbl    %r15b, %edi                                   #289.5
        movd      aes_style_table(,%rdi,4), %xmm2               #289.5
        pxor      %xmm2, %xmm6                                  #289.5
        movl      %r15d, %r11d                                  #289.5
        shrl      $8, %r11d                                     #289.5
        movzbl    %r11b, %r10d                                  #289.5
        movd      1024+aes_style_table(,%r10,4), %xmm14         #289.5
        pxor      %xmm14, %xmm2                                 #289.5
        movl      %r15d, %ebx                                   #289.5
        shrl      $16, %ebx                                     #289.5
        movzbl    %bl, %ebx                                     #289.5
        movd      2048+aes_style_table(,%rbx,4), %xmm15         #289.5
        pxor      %xmm15, %xmm9                                 #289.5
        pxor      %xmm15, %xmm2                                 #289.5
        shrl      $24, %r15d                                    #289.5
        movd      3072+aes_style_table(,%r15,4), %xmm0          #289.5
        pxor      %xmm0, %xmm10                                 #289.5
        pxor      %xmm0, %xmm2                                  #289.5
        pslldq    $4, %xmm2                                     #289.5
        movzbl    %r9b, %esi                                    #289.5
        movd      aes_style_table(,%rsi,4), %xmm1               #289.5
        pxor      %xmm1, %xmm6                                  #289.5
        movl      %r9d, %r13d                                   #289.5
        shrl      $8, %r13d                                     #289.5
        movzbl    %r13b, %ebx                                   #289.5
        movd      1024+aes_style_table(,%rbx,4), %xmm5          #289.5
        pxor      %xmm5, %xmm7                                  #289.5
        pxor      %xmm5, %xmm1                                  #289.5
        movl      %r9d, %ebx                                    #289.5
        shrl      $16, %ebx                                     #289.5
        movdqa    _2il0floatpacket.4(%rip), %xmm5               #289.5
        movzbl    %bl, %ebx                                     #289.5
        movd      2048+aes_style_table(,%rbx,4), %xmm4          #289.5
        movl      32(%rsp), %ebx                                #289.5
        pxor      %xmm4, %xmm1                                  #289.5
        shrl      $24, %r9d                                     #289.5
        movdqa    _2il0floatpacket.3(%rip), %xmm4               #289.5
        movd      3072+aes_style_table(,%r9,4), %xmm3           #289.5
        pxor      %xmm3, %xmm1                                  #289.5
        pslldq    $8, %xmm1                                     #289.5
        pxor      %xmm1, %xmm2                                  #289.5
        pxor      %xmm2, %xmm8                                  #289.5
        pshufb    %xmm5, %xmm8                                  #289.5
        pslldq    $8, %xmm9                                     #289.5
        pxor      %xmm3, %xmm10                                 #289.5
        pslldq    $12, %xmm10                                   #289.5
        pxor      %xmm10, %xmm9                                 #289.5
        pslldq    $4, %xmm7                                     #289.5
        pxor      %xmm7, %xmm6                                  #289.5
        pxor      %xmm6, %xmm9                                  #289.5
        pshufb    %xmm4, %xmm9                                  #289.5
        pxor      %xmm9, %xmm8                                  #289.5
        movdqa    %xmm8, %xmm6                                  #289.5
        movdqa    %xmm8, %xmm7                                  #289.5
        psrldq    $4, %xmm6                                     #289.5
        psrldq    $8, %xmm7                                     #289.5
        movd      %xmm8, %r15d                                  #289.5
        psrldq    $12, %xmm8                                    #289.5
        movd      %xmm6, %edi                                   #289.5
        movd      %xmm7, %r10d                                  #289.5
        movd      %xmm8, %r11d                                  #289.5
        xorl      %edi, %ebp                                    #289.5
        movl      %edi, 232(%rsp)                               #289.5
        movl      %r10d, 236(%rsp)                              #289.5
        movl      %r11d, 240(%rsp)                              #289.5
        xorl      %r10d, %ebx                                   #289.5
        xorl      %r11d, %r14d                                  #289.5
        xorl      %edi, %edx                                    #289.5
        movl      %edx, 276(%rsp)                               #289.5
        movl      24(%rsp), %edx                                #289.5
        xorl      %r8d, %r10d                                   #289.5
        movl      %r10d, 280(%rsp)                              #289.5
        xorl      %r11d, %edx                                   #289.5
        movl      %r15d, %esi                                   #289.5
        movl      %edx, 284(%rsp)                               #289.5
        movzbl    %r15b, %edx                                   #289.5
        movd      aes_style_table(,%rdx,4), %xmm1               #289.5
        movdqa    %xmm1, %xmm12                                 #289.5
        shrl      $8, %esi                                      #289.5
        movzbl    %sil, %edi                                    #289.5
        movd      1024+aes_style_table(,%rdi,4), %xmm2          #289.5
        pxor      %xmm2, %xmm12                                 #289.5
        movl      %r15d, %r8d                                   #289.5
        shrl      $16, %r8d                                     #289.5
        movzbl    %r8b, %r9d                                    #289.5
        movd      2048+aes_style_table(,%r9,4), %xmm3           #289.5
        pxor      %xmm3, %xmm12                                 #289.5
        shrl      $24, %r15d                                    #289.5
        movd      3072+aes_style_table(,%r15,4), %xmm8          #289.5
        pxor      %xmm8, %xmm12                                 #289.5
        pslldq    $12, %xmm12                                   #289.5
        movzbl    %bpl, %r10d                                   #289.5
        movd      aes_style_table(,%r10,4), %xmm0               #289.5
        movl      %ebp, %r11d                                   #289.5
        shrl      $8, %r11d                                     #289.5
        movzbl    %r11b, %r13d                                  #289.5
        movd      1024+aes_style_table(,%r13,4), %xmm9          #289.5
        movl      8(%rsp), %r13d                                #289.5
        pxor      %xmm9, %xmm2                                  #289.5
        pxor      %xmm9, %xmm0                                  #289.5
        movl      %ebp, %edx                                    #289.5
        shrl      $16, %edx                                     #289.5
        movzbl    %dl, %edx                                     #289.5
        movd      2048+aes_style_table(,%rdx,4), %xmm11         #289.5
        pxor      %xmm11, %xmm3                                 #289.5
        pxor      %xmm11, %xmm0                                 #289.5
        shrl      $24, %ebp                                     #289.5
        movd      3072+aes_style_table(,%rbp,4), %xmm7          #289.5
        pxor      %xmm7, %xmm0                                  #289.5
        pxor      %xmm12, %xmm0                                 #289.5
        movzbl    %bl, %edx                                     #289.5
        movd      aes_style_table(,%rdx,4), %xmm6               #289.5
        pxor      %xmm6, %xmm1                                  #289.5
        movl      %ebx, %edx                                    #289.5
        shrl      $8, %edx                                      #289.5
        movzbl    %dl, %edx                                     #289.5
        movd      1024+aes_style_table(,%rdx,4), %xmm13         #289.5
        pxor      %xmm13, %xmm6                                 #289.5
        movl      %ebx, %edx                                    #289.5
        shrl      $16, %edx                                     #289.5
        movzbl    %dl, %edx                                     #289.5
        movd      2048+aes_style_table(,%rdx,4), %xmm14         #289.5
        pxor      %xmm14, %xmm3                                 #289.5
        pxor      %xmm14, %xmm6                                 #289.5
        shrl      $24, %ebx                                     #289.5
        movd      3072+aes_style_table(,%rbx,4), %xmm15         #289.5
        pxor      %xmm15, %xmm7                                 #289.5
        pxor      %xmm15, %xmm6                                 #289.5
        pslldq    $4, %xmm6                                     #289.5
        movzbl    %r14b, %edx                                   #289.5
        movd      aes_style_table(,%rdx,4), %xmm12              #289.5
        pxor      %xmm12, %xmm1                                 #289.5
        movl      %r14d, %edx                                   #289.5
        shrl      $8, %edx                                      #289.5
        movzbl    %dl, %edx                                     #289.5
        movd      1024+aes_style_table(,%rdx,4), %xmm13         #289.5
        pxor      %xmm13, %xmm2                                 #289.5
        pxor      %xmm13, %xmm12                                #289.5
        movl      %r14d, %edx                                   #289.5
        shrl      $16, %edx                                     #289.5
        movzbl    %dl, %edx                                     #289.5
        movd      2048+aes_style_table(,%rdx,4), %xmm14         #289.5
        pxor      %xmm14, %xmm12                                #289.5
        shrl      $24, %r14d                                    #289.5
        movd      3072+aes_style_table(,%r14,4), %xmm15         #289.5
        pxor      %xmm15, %xmm12                                #289.5
        pslldq    $8, %xmm12                                    #289.5
        pxor      %xmm12, %xmm6                                 #289.5
        pxor      %xmm6, %xmm0                                  #289.5
        pshufb    %xmm5, %xmm0                                  #289.5
        pslldq    $8, %xmm3                                     #289.5
        pxor      %xmm15, %xmm7                                 #289.5
        pslldq    $12, %xmm7                                    #289.5
        pxor      %xmm7, %xmm3                                  #289.5
        pslldq    $4, %xmm2                                     #289.5
        pxor      %xmm2, %xmm1                                  #289.5
        pxor      %xmm1, %xmm3                                  #289.5
        pshufb    %xmm4, %xmm3                                  #289.5
        pxor      %xmm3, %xmm0                                  #289.5
        movdqa    %xmm0, %xmm1                                  #289.5
        movdqa    %xmm0, %xmm2                                  #289.5
        movd      %xmm0, 216(%rsp)                              #289.5
        psrldq    $12, %xmm0                                    #289.5
        psrldq    $4, %xmm1                                     #289.5
        movd      %xmm1, 220(%rsp)                              #289.5
        movd      %xmm0, 228(%rsp)                              #289.5
        psrldq    $8, %xmm2                                     #289.5
        movd      %xmm2, 224(%rsp)                              #289.5
        jmp       ..B1.33       # Prob 100%                     #289.5
                                # LOE r12 ecx r13d
..B1.30:                        # Preds ..B1.28
        movl      96(%rsp), %ebp                                #289.5
        movl      104(%rsp), %esi                               #289.5
        movl      32(%rsp), %edi                                #289.5
        movl      48(%rsp), %r8d                                #289.5
        movl      %ebp, 236(%rsp)                               #289.5
        movl      %r15d, 232(%rsp)                              #289.5
        movl      %esi, 228(%rsp)                               #289.5
        movl      %ebx, 244(%rsp)                               #289.5
        movl      64(%rsp), %ebx                                #289.5
        movl      %r9d, 240(%rsp)                               #289.5
        movl      24(%rsp), %r9d                                #289.5
        movl      %r10d, 296(%rsp)                              #289.5
        movl      40(%rsp), %r10d                               #289.5
        movl      %ebx, 272(%rsp)                               #289.5
        movl      %r14d, 224(%rsp)                              #289.5
        movl      %edi, 220(%rsp)                               #289.5
        movl      %r8d, 216(%rsp)                               #289.5
        movl      %r9d, 284(%rsp)                               #289.5
        movl      %r10d, 280(%rsp)                              #289.5
        movl      %edx, 276(%rsp)                               #289.5
        movl      56(%rsp), %edx                                #289.5
        movl      %r11d, 292(%rsp)                              #289.5
        movl      %edx, 288(%rsp)                               #289.5
        jmp       ..B1.33       # Prob 100%                     #289.5
                                # LOE r12 ecx r13d
..B1.31:                        # Preds ..B1.27
        movl      96(%rsp), %ebp                                #289.5
        movl      %ebp, 236(%rsp)                               #289.5
        movl      %r15d, 232(%rsp)                              #289.5
        movl      104(%rsp), %r15d                              #289.5
        movl      %r15d, 228(%rsp)                              #289.5
        movl      %r9d, 300(%rsp)                               #286.8
        movl      64(%rsp), %r9d                                #289.5
        movl      %r8d, 248(%rsp)                               #286.8
        movl      128(%rsp), %r8d                               #286.8
        movl      %edi, 244(%rsp)                               #289.5
        movl      120(%rsp), %edi                               #286.8
        movl      %eax, 240(%rsp)                               #289.5
        movl      %edi, 196(%rsp)                               #286.8
        movl      %r8d, 192(%rsp)                               #286.8
        movl      %r10d, 296(%rsp)                              #289.5
        movl      24(%rsp), %r10d                               #289.5
        movl      %r9d, 272(%rsp)                               #289.5
        movl      %esi, 268(%rsp)                               #286.8
        movl      48(%rsp), %esi                                #289.5
        movl      %ebx, 264(%rsp)                               #286.8
        movl      32(%rsp), %ebx                                #289.5
        movl      %r14d, 224(%rsp)                              #289.5
        movl      40(%rsp), %r14d                               #289.5
        movl      %ebx, 220(%rsp)                               #289.5
        movl      %esi, 216(%rsp)                               #289.5
        movl      %r10d, 284(%rsp)                              #289.5
        movl      %r14d, 280(%rsp)                              #289.5
        movl      %edx, 276(%rsp)                               #289.5
        movl      144(%rsp), %edx                               #286.8
        movl      %r11d, 292(%rsp)                              #289.5
        movl      56(%rsp), %r11d                               #289.5
        movl      %edx, 200(%rsp)                               #286.8
        movl      112(%rsp), %edx                               #286.8
        movl      %r11d, 288(%rsp)                              #289.5
        movl      %edx, 308(%rsp)                               #286.8
        movl      136(%rsp), %edx                               #286.8
        movl      %edx, 304(%rsp)                               #286.8
        jmp       ..B1.33       # Prob 100%                     #286.8
                                # LOE r12 ecx r13d
..B1.32:                        # Preds ..B1.26
        movl      96(%rsp), %ebx                                #289.5
        movl      104(%rsp), %ebp                               #289.5
        movl      120(%rsp), %esi                               #286.8
        movl      %ebx, 236(%rsp)                               #289.5
        movl      %r15d, 232(%rsp)                              #289.5
        movl      %ebp, 228(%rsp)                               #289.5
        movl      %r9d, 300(%rsp)                               #286.8
        movl      %r8d, 248(%rsp)                               #286.8
        movl      136(%rsp), %r8d                               #286.8
        movl      %edi, 244(%rsp)                               #289.5
        movl      128(%rsp), %edi                               #286.8
        movl      %eax, 240(%rsp)                               #289.5
        movl      %esi, 196(%rsp)                               #286.8
        movl      %edi, 192(%rsp)                               #286.8
        movl      %r10d, 296(%rsp)                              #289.5
        movl      %r14d, 224(%rsp)                              #289.5
        movl      %r11d, 292(%rsp)                              #289.5
        movl      %edx, 288(%rsp)                               #289.5
        movl      112(%rsp), %edx                               #286.8
        movl      %edx, 308(%rsp)                               #286.8
        movl      %r8d, 304(%rsp)                               #286.8
                                # LOE r12 ecx r13d
..B1.33:                        # Preds ..B1.25 ..B1.29 ..B1.30 ..B1.31 ..B1.32
                                #      
        cmpl      $0, (%rsp)                                    #295.5
        je        ..B1.36       # Prob 10%                      #295.5
                                # LOE r12 ecx r13d
..B1.34:                        # Preds ..B1.33
        movl      $120, %r8d                                    #295.28
                                # LOE r8 r12 ecx r13d
..B1.45:                        # Preds ..B1.45 ..B1.34
        movq      184(%rsp,%r8), %rdx                           #295.28
        movq      %rdx, 12(%r12,%r8)                            #295.28
        movq      176(%rsp,%r8), %rbx                           #295.28
        movq      %rbx, 4(%r12,%r8)                             #295.28
        movq      168(%rsp,%r8), %rbp                           #295.28
        movq      %rbp, -4(%r12,%r8)                            #295.28
        movq      160(%rsp,%r8), %rsi                           #295.28
        movq      %rsi, -12(%r12,%r8)                           #295.28
        movq      152(%rsp,%r8), %rdi                           #295.28
        movq      %rdi, -20(%r12,%r8)                           #295.28
        subq      $40, %r8                                      #295.28
        jne       ..B1.45       # Prob 66%                      #295.28
                                # LOE r8 r12 ecx r13d
..B1.35:                        # Preds ..B1.37 ..B1.45
        movswq    176(%rsp), %rsi                               #296.17
        lea       (%r13,%r13,4), %edi                           #296.23
        addl      %r13d, %edi                                   #296.23
        negl      %edi                                          #296.23
        lea       60(%rsi,%rdi), %r10d                          #296.33
        movl      $-2004318071, %eax                            #296.49
        imull     %r10d                                         #296.49
        movl      %r10d, %r8d                                   #296.49
        sarl      $31, %r8d                                     #296.49
        addl      %r10d, %edx                                   #296.49
        sarl      $4, %edx                                      #296.49
        subl      %r8d, %edx                                    #296.49
        movl      %edx, %r9d                                    #296.49
        shll      $5, %r9d                                      #296.49
        subl      %edx, %r9d                                    #296.49
        subl      %edx, %r9d                                    #296.49
        subl      %r9d, %r10d                                   #296.49
        movl      %r10d, 16(%r12)                               #296.5
        movl      %ecx, %eax                                    #298.12
        addq      $472, %rsp                                    #298.12
..___tag_value_fugue_update_256.15:                             #
        popq      %rbx                                          #298.12
..___tag_value_fugue_update_256.17:                             #
        popq      %rbp                                          #298.12
..___tag_value_fugue_update_256.19:                             #
        popq      %r12                                          #298.12
..___tag_value_fugue_update_256.21:                             #
        popq      %r13                                          #298.12
..___tag_value_fugue_update_256.23:                             #
        popq      %r14                                          #298.12
..___tag_value_fugue_update_256.25:                             #
        popq      %r15                                          #298.12
..___tag_value_fugue_update_256.27:                             #
        ret                                                     #298.12
..___tag_value_fugue_update_256.28:                             #
                                # LOE
..B1.36:                        # Preds ..B1.33                 # Infreq
        xorl      %edx, %edx                                    #295.5
                                # LOE rdx r12 ecx r13d
..B1.37:                        # Preds ..B1.37 ..B1.36         # Infreq
        movl      192(%rsp,%rdx,8), %ebx                        #295.45
        movl      196(%rsp,%rdx,8), %ebp                        #295.45
        movl      %ebx, 20(%r12,%rdx,8)                         #295.28
        movl      %ebp, 24(%r12,%rdx,8)                         #295.28
        incq      %rdx                                          #295.5
        cmpq      $15, %rdx                                     #295.5
        jb        ..B1.37       # Prob 93%                      #295.5
        jmp       ..B1.35       # Prob 100%                     #295.5
                                # LOE rdx r12 ecx r13d
..B1.39:                        # Preds ..B1.1                  # Infreq
        xorl      %eax, %eax                                    #250.5
                                # LOE rax rdx rbx r12
..B1.40:                        # Preds ..B1.40 ..B1.39         # Infreq
        movdqu    20(%r12,%rax,4), %xmm0                        #250.39
        movdqa    %xmm0, 192(%rsp,%rax,4)                       #250.28
        addq      $4, %rax                                      #250.5
        cmpq      $28, %rax                                     #250.5
        jb        ..B1.40       # Prob 96%                      #250.5
                                # LOE rax rdx rbx r12
..B1.41:                        # Preds ..B1.40                 # Infreq
        movl      132(%r12), %eax                               #250.39
        movl      136(%r12), %ecx                               #250.39
        movl      %eax, 304(%rsp)                               #250.28
        movl      %ecx, 308(%rsp)                               #250.28
        jmp       ..B1.3        # Prob 100%                     #250.28
        .align    16,0x90
..___tag_value_fugue_update_256.35:                             #
                                # LOE rdx rbx r12
# mark_end;
	.type	fugue_update_256,@function
	.size	fugue_update_256,.-fugue_update_256
	.data
# -- End  fugue_update_256
	.text
# -- Begin  rdtsc
# mark_begin;
       .align    16,0x90
rdtsc:
..B2.1:                         # Preds ..B2.0
..___tag_value_rdtsc.36:                                        #205.2
        .byte     15                                            #207.0
        .byte     49                                            #207.0
        ret                                                     #209.8
        .align    16,0x90
..___tag_value_rdtsc.37:                                        #
                                # LOE
# mark_end;
	.type	rdtsc,@function
	.size	rdtsc,.-rdtsc
	.data
# -- End  rdtsc
	.text
# -- Begin  fugue_final_256
# mark_begin;
       .align    16,0x90
	.globl fugue_final_256
fugue_final_256:
# parameter 1: %rdi
# parameter 2: %rsi
..B3.1:                         # Preds ..B3.0
..___tag_value_fugue_final_256.38:                              #302.1
        pushq     %r15                                          #302.1
..___tag_value_fugue_final_256.39:                              #
        pushq     %r14                                          #302.1
..___tag_value_fugue_final_256.41:                              #
        pushq     %r13                                          #302.1
..___tag_value_fugue_final_256.43:                              #
        pushq     %r12                                          #302.1
..___tag_value_fugue_final_256.45:                              #
        pushq     %rbp                                          #302.1
..___tag_value_fugue_final_256.47:                              #
        pushq     %rbx                                          #302.1
..___tag_value_fugue_final_256.49:                              #
        movdqa    _2il0floatpacket.8(%rip), %xmm1               #315.28
        movdqa    _2il0floatpacket.9(%rip), %xmm0               #321.23
        movl      16(%rdi), %r10d                               #328.24
        movl      $715827883, %eax                              #328.33
        imull     %r10d                                         #328.33
        movl      $1717986919, %eax                             #328.36
        movl      %r10d, %ecx                                   #328.33
        movl      %r10d, -24(%rsp)                              #331.5
        movq      %rsi, -16(%rsp)                               #331.5
        movl      %edx, %r9d                                    #328.33
        sarl      $31, %ecx                                     #328.33
        subl      %ecx, %r9d                                    #328.33
        movq      $0x8888888888888889, %rcx                     #331.5
        negl      %r9d                                          #328.22
        addl      $5, %r9d                                      #328.22
        imull     %r9d                                          #328.36
        movl      %r9d, %r8d                                    #328.36
        sarl      $1, %edx                                      #328.36
        sarl      $31, %r8d                                     #328.36
        subl      %r8d, %edx                                    #328.36
        lea       (%rdx,%rdx,4), %r11d                          #328.36
        subl      %r11d, %r9d                                   #328.36
        movslq    %r9d, %r9                                     #328.36
        xorl      %r8d, %r8d                                    #331.5
                                # LOE rcx rdi r8 r9 xmm0 xmm1
..B3.2:                         # Preds ..B3.8 ..B3.1
        movq      $0xcccccccccccccccd, %r14                     #331.5
        lea       (%r9,%r8), %rax                               #331.5
        mulq      %r14                                          #331.5
        shrq      $2, %rdx                                      #331.5
        lea       (%rdx,%rdx,4), %r13                           #331.5
        negq      %r13                                          #331.5
        addq      %r8, %r13                                     #331.5
        addq      %r13, %r13                                    #331.5
        lea       (%r13,%r9,2), %r14                            #331.5
        lea       (%r14,%r14,2), %rsi                           #331.5
        negq      %rsi                                          #331.5
        lea       31(%rsi), %rax                                #331.5
        mulq      %rcx                                          #331.5
        lea       20(%rdi,%rsi,4), %r14                         #331.5
        shrq      $4, %rdx                                      #331.5
        imulq     $-120, %rdx, %r10                             #331.5
        movl      124(%r10,%r14), %ebp                          #331.5
        lea       27(%rsi), %rax                                #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        imulq     $-120, %rdx, %r13                             #331.5
        lea       32(%rsi), %rax                                #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        imulq     $-120, %rdx, %r12                             #331.5
        lea       28(%rsi), %rax                                #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        imulq     $-120, %rdx, %rbx                             #331.5
        lea       33(%rsi), %rax                                #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        imulq     $-120, %rdx, %r11                             #331.5
        lea       29(%rsi), %rax                                #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        xorl      %ebp, 108(%r13,%r14)                          #331.5
        imulq     $-120, %rdx, %rbp                             #331.5
        movl      128(%r12,%r14), %r15d                         #331.5
        lea       42(%rsi), %rax                                #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        xorl      %r15d, 112(%rbx,%r14)                         #331.5
        movl      132(%r11,%r14), %r15d                         #331.5
        lea       43(%rsi), %rax                                #331.5
        xorl      %r15d, 116(%rbp,%r14)                         #331.5
        imulq     $-120, %rdx, %r15                             #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        movl      124(%r10,%r14), %r10d                         #331.5
        xorl      %r10d, 168(%r15,%r14)                         #331.5
        imulq     $-120, %rdx, %r10                             #331.5
        movl      128(%r12,%r14), %r12d                         #331.5
        lea       44(%rsi), %rax                                #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        imulq     $-120, %rdx, %r15                             #331.5
        lea       30(%rsi), %rax                                #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        xorl      %r12d, 172(%r10,%r14)                         #331.5
        imulq     $-120, %rdx, %r10                             #331.5
        movl      132(%r11,%r14), %r11d                         #331.5
        lea       24(%rsi), %rax                                #331.5
        xorl      %r11d, 176(%r15,%r14)                         #331.5
        movl      120(%r10,%r14), %r15d                         #331.5
        movzbl    %r15b, %r11d                                  #331.5
        movd      aes_style_table(,%r11,4), %xmm4               #331.5
        movdqa    %xmm4, %xmm9                                  #331.5
        movl      %r15d, %r12d                                  #331.5
        shrl      $8, %r12d                                     #331.5
        movzbl    %r12b, %r11d                                  #331.5
        movd      1024+aes_style_table(,%r11,4), %xmm5          #331.5
        movl      108(%r13,%r14), %r12d                         #331.5
        movl      112(%rbx,%r14), %r11d                         #331.5
        pxor      %xmm5, %xmm9                                  #331.5
        movl      %r15d, %edx                                   #331.5
        shrl      $16, %edx                                     #331.5
        movzbl    %dl, %edx                                     #331.5
        movd      2048+aes_style_table(,%rdx,4), %xmm2          #331.5
        pxor      %xmm2, %xmm9                                  #331.5
        shrl      $24, %r15d                                    #331.5
        movd      3072+aes_style_table(,%r15,4), %xmm6          #331.5
        movl      116(%rbp,%r14), %r15d                         #331.5
        pxor      %xmm6, %xmm9                                  #331.5
        pslldq    $12, %xmm9                                    #331.5
        movzbl    %r12b, %edx                                   #331.5
        movd      aes_style_table(,%rdx,4), %xmm3               #331.5
        movl      %r12d, %edx                                   #331.5
        shrl      $8, %edx                                      #331.5
        movzbl    %dl, %edx                                     #331.5
        movd      1024+aes_style_table(,%rdx,4), %xmm7          #331.5
        pxor      %xmm7, %xmm5                                  #331.5
        pxor      %xmm7, %xmm3                                  #331.5
        movl      %r12d, %edx                                   #331.5
        shrl      $16, %edx                                     #331.5
        movzbl    %dl, %edx                                     #331.5
        movd      2048+aes_style_table(,%rdx,4), %xmm8          #331.5
        pxor      %xmm8, %xmm2                                  #331.5
        pxor      %xmm8, %xmm3                                  #331.5
        shrl      $24, %r12d                                    #331.5
        movd      3072+aes_style_table(,%r12,4), %xmm6          #331.5
        pxor      %xmm6, %xmm3                                  #331.5
        pxor      %xmm9, %xmm3                                  #331.5
        movzbl    %r11b, %edx                                   #331.5
        movd      aes_style_table(,%rdx,4), %xmm9               #331.5
        pxor      %xmm9, %xmm4                                  #331.5
        movl      %r11d, %edx                                   #331.5
        shrl      $8, %edx                                      #331.5
        movzbl    %dl, %edx                                     #331.5
        movd      1024+aes_style_table(,%rdx,4), %xmm10         #331.5
        pxor      %xmm10, %xmm9                                 #331.5
        movl      %r11d, %edx                                   #331.5
        shrl      $16, %edx                                     #331.5
        movzbl    %dl, %edx                                     #331.5
        .byte     15                                            #331.5
        .byte     31                                            #331.5
        .byte     64                                            #331.5
        .byte     0                                             #331.5
        movd      2048+aes_style_table(,%rdx,4), %xmm11         #331.5
        pxor      %xmm11, %xmm2                                 #331.5
        pxor      %xmm11, %xmm9                                 #331.5
        shrl      $24, %r11d                                    #331.5
        movd      3072+aes_style_table(,%r11,4), %xmm12         #331.5
        pxor      %xmm12, %xmm6                                 #331.5
        pxor      %xmm12, %xmm9                                 #331.5
        pslldq    $4, %xmm9                                     #331.5
        movzbl    %r15b, %edx                                   #331.5
        movd      aes_style_table(,%rdx,4), %xmm15              #331.5
        pxor      %xmm15, %xmm4                                 #331.5
        movl      %r15d, %edx                                   #331.5
        shrl      $8, %edx                                      #331.5
        movzbl    %dl, %edx                                     #331.5
        movd      1024+aes_style_table(,%rdx,4), %xmm13         #331.5
        pxor      %xmm13, %xmm5                                 #331.5
        pxor      %xmm13, %xmm15                                #331.5
        movl      %r15d, %edx                                   #331.5
        shrl      $16, %edx                                     #331.5
        movzbl    %dl, %edx                                     #331.5
        movd      2048+aes_style_table(,%rdx,4), %xmm14         #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        pxor      %xmm14, %xmm15                                #331.5
        shrl      $24, %r15d                                    #331.5
        movd      3072+aes_style_table(,%r15,4), %xmm10         #331.5
        imulq     $-120, %rdx, %r15                             #331.5
        pxor      %xmm10, %xmm15                                #331.5
        pslldq    $8, %xmm15                                    #331.5
        pxor      %xmm15, %xmm9                                 #331.5
        pxor      %xmm9, %xmm3                                  #331.5
        pslldq    $8, %xmm2                                     #331.5
        pxor      %xmm10, %xmm6                                 #331.5
        pslldq    $12, %xmm6                                    #331.5
        pxor      %xmm6, %xmm2                                  #331.5
        pshufb    %xmm0, %xmm3                                  #331.5
        pslldq    $4, %xmm5                                     #331.5
        pxor      %xmm5, %xmm4                                  #331.5
        pxor      %xmm4, %xmm2                                  #331.5
        pshufb    %xmm1, %xmm2                                  #331.5
        pxor      %xmm2, %xmm3                                  #331.5
        movdqa    %xmm3, %xmm4                                  #331.5
        movdqa    %xmm3, %xmm5                                  #331.5
        movd      %xmm3, 108(%r13,%r14)                         #331.5
        psrldq    $12, %xmm3                                    #331.5
        psrldq    $4, %xmm4                                     #331.5
        movd      %xmm4, 112(%rbx,%r14)                         #331.5
        psrldq    $8, %xmm5                                     #331.5
        movd      %xmm5, 116(%rbp,%r14)                         #331.5
        lea       25(%rsi), %rax                                #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        movd      %xmm3, 120(%r10,%r14)                         #331.5
        movl      112(%rbx,%r14), %r11d                         #331.5
        lea       26(%rsi), %rax                                #331.5
        xorl      %r11d, 96(%r15,%r14)                          #331.5
        imulq     $-120, %rdx, %r11                             #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        movl      116(%rbp,%r14), %r12d                         #331.5
        xorl      %r12d, 100(%r11,%r14)                         #331.5
        imulq     $-120, %rdx, %r12                             #331.5
        movl      120(%r10,%r14), %edx                          #331.5
        lea       39(%rsi), %rax                                #331.5
        xorl      %edx, 104(%r12,%r14)                          #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        imulq     $-120, %rdx, %rdx                             #331.5
        movl      112(%rbx,%r14), %ebx                          #331.5
        lea       40(%rsi), %rax                                #331.5
        .byte     15                                            #331.5
        .byte     31                                            #331.5
        .byte     0                                             #331.5
        xorl      %ebx, 156(%rdx,%r14)                          #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        imulq     $-120, %rdx, %rbx                             #331.5
        movl      116(%rbp,%r14), %ebp                          #331.5
        addq      $41, %rsi                                     #331.5
        xorl      %ebp, 160(%rbx,%r14)                          #331.5
        movl      120(%r10,%r14), %r10d                         #331.5
        movq      %rsi, %rax                                    #331.5
        mulq      %rcx                                          #331.5
        shrq      $4, %rdx                                      #331.5
        imulq     $-120, %rdx, %rsi                             #331.5
        xorl      %r10d, 164(%rsi,%r14)                         #331.5
        movl      108(%r13,%r14), %esi                          #331.5
        movzbl    %sil, %eax                                    #331.5
        movd      aes_style_table(,%rax,4), %xmm3               #331.5
        movdqa    %xmm3, %xmm11                                 #331.5
        movl      %esi, %edx                                    #331.5
        shrl      $8, %edx                                      #331.5
        movzbl    %dl, %r10d                                    #331.5
        movd      1024+aes_style_table(,%r10,4), %xmm4          #331.5
        movl      96(%r15,%r14), %r10d                          #331.5
        pxor      %xmm4, %xmm11                                 #331.5
        movl      %esi, %ebx                                    #331.5
        shrl      $16, %ebx                                     #331.5
        movzbl    %bl, %ebp                                     #331.5
        movd      2048+aes_style_table(,%rbp,4), %xmm5          #331.5
        pxor      %xmm5, %xmm11                                 #331.5
        shrl      $24, %esi                                     #331.5
        movd      3072+aes_style_table(,%rsi,4), %xmm2          #331.5
        pxor      %xmm2, %xmm11                                 #331.5
        pslldq    $12, %xmm11                                   #331.5
        movzbl    %r10b, %eax                                   #331.5
        movd      aes_style_table(,%rax,4), %xmm2               #331.5
        movl      %r10d, %edx                                   #331.5
        shrl      $8, %edx                                      #331.5
        movzbl    %dl, %ebx                                     #331.5
        movd      1024+aes_style_table(,%rbx,4), %xmm7          #331.5
        pxor      %xmm7, %xmm4                                  #331.5
        pxor      %xmm7, %xmm2                                  #331.5
        movl      %r10d, %eax                                   #331.5
        shrl      $16, %eax                                     #331.5
        movzbl    %al, %ebp                                     #331.5
        movd      2048+aes_style_table(,%rbp,4), %xmm8          #331.5
        movl      100(%r11,%r14), %eax                          #331.5
        pxor      %xmm8, %xmm5                                  #331.5
        pxor      %xmm8, %xmm2                                  #331.5
        shrl      $24, %r10d                                    #331.5
        movd      3072+aes_style_table(,%r10,4), %xmm10         #331.5
        pxor      %xmm10, %xmm2                                 #331.5
        pxor      %xmm11, %xmm2                                 #331.5
        movzbl    %al, %edx                                     #331.5
        movd      aes_style_table(,%rdx,4), %xmm8               #331.5
        pxor      %xmm8, %xmm3                                  #331.5
        movl      %eax, %esi                                    #331.5
        shrl      $8, %esi                                      #331.5
        movzbl    %sil, %ebx                                    #331.5
        .byte     102                                           #331.5
        .byte     144                                           #331.5
        movd      1024+aes_style_table(,%rbx,4), %xmm12         #331.5
        pxor      %xmm12, %xmm8                                 #331.5
        movl      %eax, %edx                                    #331.5
        shrl      $16, %edx                                     #331.5
        movzbl    %dl, %ebp                                     #331.5
        movd      2048+aes_style_table(,%rbp,4), %xmm13         #331.5
        pxor      %xmm13, %xmm5                                 #331.5
        pxor      %xmm13, %xmm8                                 #331.5
        shrl      $24, %eax                                     #331.5
        movd      3072+aes_style_table(,%rax,4), %xmm14         #331.5
        movl      104(%r12,%r14), %eax                          #331.5
        pxor      %xmm14, %xmm10                                #331.5
        pxor      %xmm14, %xmm8                                 #331.5
        pslldq    $4, %xmm8                                     #331.5
        movzbl    %al, %edx                                     #331.5
        movd      aes_style_table(,%rdx,4), %xmm7               #331.5
        pxor      %xmm7, %xmm3                                  #331.5
        movl      %eax, %r10d                                   #331.5
        shrl      $8, %r10d                                     #331.5
        movzbl    %r10b, %ebx                                   #331.5
        movd      1024+aes_style_table(,%rbx,4), %xmm6          #331.5
        pxor      %xmm6, %xmm4                                  #331.5
                                # LOE rcx rdi r8 r9 r11 r12 r13 r14 r15 eax xmm0 xmm1 xmm2 xmm3 xmm4 xmm5 xmm6 xmm7 xmm8 xmm10
..B3.8:                         # Preds ..B3.2
        pxor      %xmm6, %xmm7                                  #331.5
        movl      %eax, %edx                                    #331.5
        shrl      $16, %edx                                     #331.5
        movzbl    %dl, %ebx                                     #331.5
        movd      2048+aes_style_table(,%rbx,4), %xmm6          #331.5
        pxor      %xmm6, %xmm7                                  #331.5
        shrl      $24, %eax                                     #331.5
        movd      3072+aes_style_table(,%rax,4), %xmm9          #331.5
        pxor      %xmm9, %xmm7                                  #331.5
        pslldq    $8, %xmm7                                     #331.5
        pxor      %xmm7, %xmm8                                  #331.5
        pxor      %xmm8, %xmm2                                  #331.5
        pshufb    %xmm0, %xmm2                                  #331.5
        pslldq    $8, %xmm5                                     #331.5
        pxor      %xmm9, %xmm10                                 #331.5
        pslldq    $12, %xmm10                                   #331.5
        pxor      %xmm10, %xmm5                                 #331.5
        pslldq    $4, %xmm4                                     #331.5
        pxor      %xmm4, %xmm3                                  #331.5
        pxor      %xmm3, %xmm5                                  #331.5
        pshufb    %xmm1, %xmm5                                  #331.5
        pxor      %xmm5, %xmm2                                  #331.5
        movdqa    %xmm2, %xmm3                                  #331.5
        movdqa    %xmm2, %xmm4                                  #331.5
        movd      %xmm2, 96(%r15,%r14)                          #331.5
        psrldq    $12, %xmm2                                    #331.5
        psrldq    $4, %xmm3                                     #331.5
        psrldq    $8, %xmm4                                     #331.5
        movd      %xmm3, 100(%r11,%r14)                         #331.5
        movd      %xmm4, 104(%r12,%r14)                         #331.5
        incq      %r8                                           #331.5
        cmpq      $5, %r8                                       #331.5
        movd      %xmm2, 108(%r13,%r14)                         #331.5
        jb        ..B3.2        # Prob 80%                      #331.5
                                # LOE rcx rdi r8 r9 xmm0 xmm1
..B3.3:                         # Preds ..B3.8
        movl      -24(%rsp), %r10d                              #
        movq      -16(%rsp), %rsi                               #
        xorl      %r11d, %r11d                                  #332.5
        movswq    %r10w, %r9                                    #332.5
        lea       30(%r9), %r8d                                 #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r8d                                          #332.5
        movl      %r8d, %r10d                                   #332.5
        sarl      $31, %r10d                                    #332.5
        addl      %r8d, %edx                                    #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r10d, %edx                                   #332.5
        movl      %edx, %eax                                    #332.5
        shll      $5, %eax                                      #332.5
        subl      %edx, %eax                                    #332.5
        subl      %edx, %eax                                    #332.5
        subl      %eax, %r8d                                    #332.5
        movslq    %r8d, %r8                                     #332.5
        shlq      $2, %r8                                       #332.5
                                # LOE rcx rbx rsi rdi r8 r11 r12 r13 r9d xmm0 xmm1
..B3.4:                         # Preds ..B3.9 ..B3.3
        lea       34(%r9), %r15d                                #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r15d                                         #332.5
        movl      %r15d, %r10d                                  #332.5
        sarl      $31, %r10d                                    #332.5
        addl      %r15d, %edx                                   #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r10d, %edx                                   #332.5
        movl      20(%r8,%rdi), %r10d                           #332.5
        movl      %edx, %ebp                                    #332.5
        shll      $5, %ebp                                      #332.5
        subl      %edx, %ebp                                    #332.5
        subl      %edx, %ebp                                    #332.5
        subl      %ebp, %r15d                                   #332.5
        movslq    %r15d, %r15                                   #332.5
        xorl      %r10d, 20(%rdi,%r15,4)                        #332.5
        movl      20(%r8,%rdi), %r8d                            #332.5
        lea       45(%r9), %r10d                                #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r10d                                         #332.5
        movl      %r10d, %r14d                                  #332.5
        sarl      $31, %r14d                                    #332.5
        addl      %r10d, %edx                                   #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r14d, %edx                                   #332.5
        movl      %edx, %eax                                    #332.5
        shll      $5, %eax                                      #332.5
        subl      %edx, %eax                                    #332.5
        subl      %edx, %eax                                    #332.5
        subl      %eax, %r10d                                   #332.5
        movslq    %r10d, %r10                                   #332.5
        addl      $15, %r9d                                     #332.5
        xorl      %r8d, 20(%rdi,%r10,4)                         #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r9d                                          #332.5
        movl      %r9d, %r15d                                   #332.5
        sarl      $31, %r15d                                    #332.5
        addl      %r9d, %edx                                    #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r15d, %edx                                   #332.5
        movl      %edx, %r14d                                   #332.5
        shll      $5, %r14d                                     #332.5
        subl      %edx, %r14d                                   #332.5
        subl      %edx, %r14d                                   #332.5
        subl      %r14d, %r9d                                   #332.5
        movswq    %r9w, %rbp                                    #332.5
        lea       33(%rbp), %r10d                               #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r10d                                         #332.5
        movl      %r10d, %r9d                                   #332.5
        sarl      $31, %r9d                                     #332.5
        addl      %r10d, %edx                                   #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r9d, %edx                                    #332.5
        movl      %edx, %r15d                                   #332.5
        shll      $5, %r15d                                     #332.5
        subl      %edx, %r15d                                   #332.5
        subl      %edx, %r15d                                   #332.5
        subl      %r15d, %r10d                                  #332.5
        movslq    %r10d, %r10                                   #332.5
        movl      20(%rdi,%r10,4), %r8d                         #332.5
        movzbl    %r8b, %r9d                                    #332.5
        movd      aes_style_table(,%r9,4), %xmm4                #332.5
        movdqa    %xmm4, %xmm9                                  #332.5
        movl      %r8d, %r14d                                   #332.5
        shrl      $8, %r14d                                     #332.5
        movzbl    %r14b, %eax                                   #332.5
        movd      1024+aes_style_table(,%rax,4), %xmm5          #332.5
        pxor      %xmm5, %xmm9                                  #332.5
        movl      %r8d, %r9d                                    #332.5
        shrl      $16, %r9d                                     #332.5
        movzbl    %r9b, %r15d                                   #332.5
        movd      2048+aes_style_table(,%r15,4), %xmm2          #332.5
        pxor      %xmm2, %xmm9                                  #332.5
        shrl      $24, %r8d                                     #332.5
        movd      3072+aes_style_table(,%r8,4), %xmm6           #332.5
        pxor      %xmm6, %xmm9                                  #332.5
        pslldq    $12, %xmm9                                    #332.5
        lea       30(%rbp), %r8d                                #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r8d                                          #332.5
        movl      %r8d, %r14d                                   #332.5
        sarl      $31, %r14d                                    #332.5
        addl      %r8d, %edx                                    #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r14d, %edx                                   #332.5
        movl      %edx, %r9d                                    #332.5
        shll      $5, %r9d                                      #332.5
        subl      %edx, %r9d                                    #332.5
        subl      %edx, %r9d                                    #332.5
        subl      %r9d, %r8d                                    #332.5
        movslq    %r8d, %r8                                     #332.5
        movl      20(%rdi,%r8,4), %eax                          #332.5
        movzbl    %al, %r15d                                    #332.5
        movd      aes_style_table(,%r15,4), %xmm3               #332.5
        movl      %eax, %r14d                                   #332.5
        shrl      $8, %r14d                                     #332.5
        movzbl    %r14b, %edx                                   #332.5
        movd      1024+aes_style_table(,%rdx,4), %xmm7          #332.5
        pxor      %xmm7, %xmm5                                  #332.5
        pxor      %xmm7, %xmm3                                  #332.5
        movl      %eax, %r9d                                    #332.5
        shrl      $16, %r9d                                     #332.5
        movzbl    %r9b, %r15d                                   #332.5
        movd      2048+aes_style_table(,%r15,4), %xmm8          #332.5
        pxor      %xmm8, %xmm2                                  #332.5
        pxor      %xmm8, %xmm3                                  #332.5
        shrl      $24, %eax                                     #332.5
        movd      3072+aes_style_table(,%rax,4), %xmm6          #332.5
        pxor      %xmm6, %xmm3                                  #332.5
        pxor      %xmm9, %xmm3                                  #332.5
        lea       31(%rbp), %r9d                                #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r9d                                          #332.5
        movl      %r9d, %r15d                                   #332.5
        sarl      $31, %r15d                                    #332.5
        addl      %r9d, %edx                                    #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r15d, %edx                                   #332.5
        movl      %edx, %r14d                                   #332.5
        shll      $5, %r14d                                     #332.5
        subl      %edx, %r14d                                   #332.5
        subl      %edx, %r14d                                   #332.5
        subl      %r14d, %r9d                                   #332.5
        movslq    %r9d, %r9                                     #332.5
        movl      20(%rdi,%r9,4), %edx                          #332.5
        movzbl    %dl, %eax                                     #332.5
        movd      aes_style_table(,%rax,4), %xmm9               #332.5
        pxor      %xmm9, %xmm4                                  #332.5
        movl      %edx, %r15d                                   #332.5
        shrl      $8, %r15d                                     #332.5
        movzbl    %r15b, %r14d                                  #332.5
        movd      1024+aes_style_table(,%r14,4), %xmm10         #332.5
        pxor      %xmm10, %xmm9                                 #332.5
        movl      %edx, %eax                                    #332.5
        shrl      $16, %eax                                     #332.5
        movzbl    %al, %r15d                                    #332.5
        movd      2048+aes_style_table(,%r15,4), %xmm11         #332.5
        pxor      %xmm11, %xmm2                                 #332.5
        pxor      %xmm11, %xmm9                                 #332.5
        shrl      $24, %edx                                     #332.5
        movd      3072+aes_style_table(,%rdx,4), %xmm12         #332.5
        pxor      %xmm12, %xmm6                                 #332.5
        pxor      %xmm12, %xmm9                                 #332.5
        pslldq    $4, %xmm9                                     #332.5
        lea       32(%rbp), %r14d                               #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r14d                                         #332.5
        movl      %r14d, %r15d                                  #332.5
        sarl      $31, %r15d                                    #332.5
        addl      %r14d, %edx                                   #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r15d, %edx                                   #332.5
        movl      %edx, %eax                                    #332.5
        shll      $5, %eax                                      #332.5
        subl      %edx, %eax                                    #332.5
        subl      %edx, %eax                                    #332.5
        subl      %eax, %r14d                                   #332.5
        movslq    %r14d, %r14                                   #332.5
        movl      20(%rdi,%r14,4), %r15d                        #332.5
        movzbl    %r15b, %edx                                   #332.5
        movd      aes_style_table(,%rdx,4), %xmm15              #332.5
        pxor      %xmm15, %xmm4                                 #332.5
        movl      %r15d, %eax                                   #332.5
        shrl      $8, %eax                                      #332.5
        movzbl    %al, %edx                                     #332.5
        movd      1024+aes_style_table(,%rdx,4), %xmm13         #332.5
        pxor      %xmm13, %xmm5                                 #332.5
        pxor      %xmm13, %xmm15                                #332.5
        movl      %r15d, %eax                                   #332.5
        shrl      $16, %eax                                     #332.5
        movzbl    %al, %edx                                     #332.5
        movd      2048+aes_style_table(,%rdx,4), %xmm14         #332.5
        pxor      %xmm14, %xmm15                                #332.5
        shrl      $24, %r15d                                    #332.5
        movd      3072+aes_style_table(,%r15,4), %xmm10         #332.5
        pxor      %xmm10, %xmm15                                #332.5
        pslldq    $8, %xmm15                                    #332.5
        pxor      %xmm15, %xmm9                                 #332.5
        pxor      %xmm9, %xmm3                                  #332.5
        pshufb    %xmm0, %xmm3                                  #332.5
        pslldq    $8, %xmm2                                     #332.5
        pxor      %xmm10, %xmm6                                 #332.5
        pslldq    $12, %xmm6                                    #332.5
        pxor      %xmm6, %xmm2                                  #332.5
        pslldq    $4, %xmm5                                     #332.5
        pxor      %xmm5, %xmm4                                  #332.5
        pxor      %xmm4, %xmm2                                  #332.5
        pshufb    %xmm1, %xmm2                                  #332.5
        pxor      %xmm2, %xmm3                                  #332.5
        movdqa    %xmm3, %xmm4                                  #332.5
        movdqa    %xmm3, %xmm5                                  #332.5
        movd      %xmm3, 20(%rdi,%r8,4)                         #332.5
        psrldq    $12, %xmm3                                    #332.5
        psrldq    $4, %xmm4                                     #332.5
        psrldq    $8, %xmm5                                     #332.5
        movd      %xmm4, 20(%rdi,%r9,4)                         #332.5
        movd      %xmm5, 20(%rdi,%r14,4)                        #332.5
        lea       34(%rbp), %r15d                               #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r15d                                         #332.5
        movl      $-2004318071, %eax                            #332.5
        movd      %xmm3, 20(%rdi,%r10,4)                        #332.5
        addl      %r15d, %edx                                   #332.5
        sarl      $4, %edx                                      #332.5
        movl      %r15d, %r10d                                  #332.5
        sarl      $31, %r10d                                    #332.5
        subl      %r10d, %edx                                   #332.5
        movl      20(%rdi,%r8,4), %r10d                         #332.5
        movl      %edx, %r9d                                    #332.5
        shll      $5, %r9d                                      #332.5
        subl      %edx, %r9d                                    #332.5
        subl      %edx, %r9d                                    #332.5
        subl      %r9d, %r15d                                   #332.5
        movslq    %r15d, %r15                                   #332.5
        xorl      %r10d, 20(%rdi,%r15,4)                        #332.5
        movl      20(%rdi,%r8,4), %r8d                          #332.5
        lea       46(%rbp), %r9d                                #332.5
        imull     %r9d                                          #332.5
        movl      %r9d, %r14d                                   #332.5
        sarl      $31, %r14d                                    #332.5
        addl      %r9d, %edx                                    #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r14d, %edx                                   #332.5
        movl      %edx, %eax                                    #332.5
        shll      $5, %eax                                      #332.5
        subl      %edx, %eax                                    #332.5
        subl      %edx, %eax                                    #332.5
        subl      %eax, %r9d                                    #332.5
        movslq    %r9d, %r9                                     #332.5
        addl      $16, %ebp                                     #332.5
        xorl      %r8d, 20(%rdi,%r9,4)                          #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %ebp                                          #332.5
        movl      %ebp, %r10d                                   #332.5
        sarl      $31, %r10d                                    #332.5
        addl      %ebp, %edx                                    #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r10d, %edx                                   #332.5
        movl      %edx, %r15d                                   #332.5
        shll      $5, %r15d                                     #332.5
        subl      %edx, %r15d                                   #332.5
        subl      %edx, %r15d                                   #332.5
        subl      %r15d, %ebp                                   #332.5
        movswq    %bp, %r10                                     #332.5
        movl      %r10d, %r9d                                   #332.5
        lea       33(%r9), %r15d                                #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r15d                                         #332.5
        movl      %r15d, %ebp                                   #332.5
        sarl      $31, %ebp                                     #332.5
        addl      %r15d, %edx                                   #332.5
        sarl      $4, %edx                                      #332.5
        subl      %ebp, %edx                                    #332.5
        movl      %edx, %r8d                                    #332.5
        shll      $5, %r8d                                      #332.5
        subl      %edx, %r8d                                    #332.5
        subl      %edx, %r8d                                    #332.5
        subl      %r8d, %r15d                                   #332.5
        movslq    %r15d, %r15                                   #332.5
        movl      20(%rdi,%r15,4), %edx                         #332.5
        movzbl    %dl, %r14d                                    #332.5
        movd      aes_style_table(,%r14,4), %xmm3               #332.5
        movdqa    %xmm3, %xmm11                                 #332.5
        movl      %edx, %ebp                                    #332.5
        shrl      $8, %ebp                                      #332.5
        movzbl    %bpl, %ebp                                    #332.5
        movd      1024+aes_style_table(,%rbp,4), %xmm4          #332.5
        pxor      %xmm4, %xmm11                                 #332.5
        movl      %edx, %ebp                                    #332.5
        shrl      $16, %ebp                                     #332.5
        movzbl    %bpl, %ebp                                    #332.5
        movd      2048+aes_style_table(,%rbp,4), %xmm5          #332.5
        pxor      %xmm5, %xmm11                                 #332.5
        shrl      $24, %edx                                     #332.5
        .byte     144                                           #332.5
        movd      3072+aes_style_table(,%rdx,4), %xmm2          #332.5
        pxor      %xmm2, %xmm11                                 #332.5
        pslldq    $12, %xmm11                                   #332.5
        lea       30(%r9), %r8d                                 #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r8d                                          #332.5
        movl      %r8d, %ebp                                    #332.5
        sarl      $31, %ebp                                     #332.5
        addl      %r8d, %edx                                    #332.5
        sarl      $4, %edx                                      #332.5
        subl      %ebp, %edx                                    #332.5
        movl      %edx, %ebp                                    #332.5
        shll      $5, %ebp                                      #332.5
        subl      %edx, %ebp                                    #332.5
        subl      %edx, %ebp                                    #332.5
        subl      %ebp, %r8d                                    #332.5
        movslq    %r8d, %r8                                     #332.5
        shlq      $2, %r8                                       #332.5
        movl      $-2004318071, %eax                            #332.5
        movl      20(%rdi,%r8), %r14d                           #332.5
        movzbl    %r14b, %edx                                   #332.5
        movd      aes_style_table(,%rdx,4), %xmm2               #332.5
        movl      %r14d, %edx                                   #332.5
        shrl      $8, %edx                                      #332.5
        movzbl    %dl, %edx                                     #332.5
        movd      1024+aes_style_table(,%rdx,4), %xmm7          #332.5
        pxor      %xmm7, %xmm4                                  #332.5
        pxor      %xmm7, %xmm2                                  #332.5
        movl      %r14d, %edx                                   #332.5
        shrl      $16, %edx                                     #332.5
        movzbl    %dl, %edx                                     #332.5
        movd      2048+aes_style_table(,%rdx,4), %xmm8          #332.5
        pxor      %xmm8, %xmm5                                  #332.5
        pxor      %xmm8, %xmm2                                  #332.5
        shrl      $24, %r14d                                    #332.5
        movd      3072+aes_style_table(,%r14,4), %xmm14         #332.5
        pxor      %xmm14, %xmm2                                 #332.5
        pxor      %xmm11, %xmm2                                 #332.5
        lea       31(%r9), %r14d                                #332.5
        imull     %r14d                                         #332.5
                                # LOE rcx rbx rsi rdi r8 r10 r11 r12 r13 r15 edx r9d r14d xmm0 xmm1 xmm2 xmm3 xmm4 xmm5 xmm14
..B3.9:                         # Preds ..B3.4
        addl      %r14d, %edx                                   #332.5
        sarl      $4, %edx                                      #332.5
        movl      %r14d, %ebp                                   #332.5
        sarl      $31, %ebp                                     #332.5
        subl      %ebp, %edx                                    #332.5
        movl      %edx, %ebp                                    #332.5
        shll      $5, %ebp                                      #332.5
        subl      %edx, %ebp                                    #332.5
        subl      %edx, %ebp                                    #332.5
        subl      %ebp, %r14d                                   #332.5
        movslq    %r14d, %r14                                   #332.5
        .byte     144                                           #332.5
        movl      20(%rdi,%r14,4), %edx                         #332.5
        movzbl    %dl, %ebp                                     #332.5
        movd      aes_style_table(,%rbp,4), %xmm12              #332.5
        pxor      %xmm12, %xmm3                                 #332.5
        movl      %edx, %ebp                                    #332.5
        shrl      $8, %ebp                                      #332.5
        movzbl    %bpl, %ebp                                    #332.5
        movd      1024+aes_style_table(,%rbp,4), %xmm6          #332.5
        pxor      %xmm6, %xmm12                                 #332.5
        movl      %edx, %ebp                                    #332.5
        shrl      $16, %ebp                                     #332.5
        movzbl    %bpl, %ebp                                    #332.5
        movd      2048+aes_style_table(,%rbp,4), %xmm7          #332.5
        pxor      %xmm7, %xmm5                                  #332.5
        pxor      %xmm7, %xmm12                                 #332.5
        shrl      $24, %edx                                     #332.5
        movd      3072+aes_style_table(,%rdx,4), %xmm8          #332.5
        pxor      %xmm8, %xmm14                                 #332.5
        pxor      %xmm8, %xmm12                                 #332.5
        pslldq    $4, %xmm12                                    #332.5
        lea       32(%r9), %ebp                                 #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %ebp                                          #332.5
        movl      %ebp, %eax                                    #332.5
        sarl      $31, %eax                                     #332.5
        addl      %ebp, %edx                                    #332.5
        sarl      $4, %edx                                      #332.5
        subl      %eax, %edx                                    #332.5
        movl      %edx, %eax                                    #332.5
        shll      $5, %eax                                      #332.5
        subl      %edx, %eax                                    #332.5
        subl      %edx, %eax                                    #332.5
        subl      %eax, %ebp                                    #332.5
        movslq    %ebp, %rbp                                    #332.5
        .byte     15                                            #332.5
        .byte     31                                            #332.5
        .byte     64                                            #332.5
        .byte     0                                             #332.5
        movl      20(%rdi,%rbp,4), %edx                         #332.5
        movzbl    %dl, %eax                                     #332.5
        movd      aes_style_table(,%rax,4), %xmm11              #332.5
        pxor      %xmm11, %xmm3                                 #332.5
        movl      %edx, %eax                                    #332.5
        shrl      $8, %eax                                      #332.5
        movzbl    %al, %eax                                     #332.5
        movd      1024+aes_style_table(,%rax,4), %xmm9          #332.5
        pxor      %xmm9, %xmm4                                  #332.5
        pxor      %xmm9, %xmm11                                 #332.5
        movl      %edx, %eax                                    #332.5
        shrl      $16, %eax                                     #332.5
        movzbl    %al, %eax                                     #332.5
        movd      2048+aes_style_table(,%rax,4), %xmm10         #332.5
        pxor      %xmm10, %xmm11                                #332.5
        shrl      $24, %edx                                     #332.5
        movd      3072+aes_style_table(,%rdx,4), %xmm13         #332.5
        pxor      %xmm13, %xmm11                                #332.5
        pslldq    $8, %xmm11                                    #332.5
        pxor      %xmm11, %xmm12                                #332.5
        pxor      %xmm12, %xmm2                                 #332.5
        pshufb    %xmm0, %xmm2                                  #332.5
        pslldq    $8, %xmm5                                     #332.5
        pxor      %xmm13, %xmm14                                #332.5
        pslldq    $12, %xmm14                                   #332.5
        pxor      %xmm14, %xmm5                                 #332.5
        pslldq    $4, %xmm4                                     #332.5
        pxor      %xmm4, %xmm3                                  #332.5
        pxor      %xmm3, %xmm5                                  #332.5
        pshufb    %xmm1, %xmm5                                  #332.5
        pxor      %xmm5, %xmm2                                  #332.5
        movdqa    %xmm2, %xmm3                                  #332.5
        movdqa    %xmm2, %xmm4                                  #332.5
        movd      %xmm2, 20(%rdi,%r8)                           #332.5
        psrldq    $12, %xmm2                                    #332.5
        psrldq    $4, %xmm3                                     #332.5
        psrldq    $8, %xmm4                                     #332.5
        movd      %xmm3, 20(%rdi,%r14,4)                        #332.5
        movd      %xmm4, 20(%rdi,%rbp,4)                        #332.5
        incq      %r11                                          #332.5
        cmpq      $13, %r11                                     #332.5
        movd      %xmm2, 20(%rdi,%r15,4)                        #332.5
        jb        ..B3.4        # Prob 92%                      #332.5
                                # LOE rcx rbx rsi rdi r8 r10 r11 r12 r13 r9d xmm0 xmm1
..B3.5:                         # Preds ..B3.9
        lea       34(%r9), %r11d                                #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r11d                                         #332.5
        movl      %r11d, %eax                                   #332.5
        sarl      $31, %eax                                     #332.5
        addl      %r11d, %edx                                   #332.5
        sarl      $4, %edx                                      #332.5
        subl      %eax, %edx                                    #332.5
        movl      %edx, %eax                                    #332.5
        shll      $5, %eax                                      #332.5
        subl      %edx, %eax                                    #332.5
        subl      %edx, %eax                                    #332.5
        movl      20(%rdi,%r8), %edx                            #332.5
        subl      %eax, %r11d                                   #332.5
        movslq    %r11d, %r11                                   #332.5
        xorl      %edx, 20(%rdi,%r11,4)                         #332.5
        movl      20(%rdi,%r8), %r8d                            #332.5
        addl      $45, %r9d                                     #332.5
        movl      $-2004318071, %eax                            #332.5
        imull     %r9d                                          #332.5
        movl      %r9d, %r11d                                   #332.5
        sarl      $31, %r11d                                    #332.5
        addl      %r9d, %edx                                    #332.5
        sarl      $4, %edx                                      #332.5
        subl      %r11d, %edx                                   #332.5
        movl      %edx, %r11d                                   #332.5
        shll      $5, %r11d                                     #332.5
        subl      %edx, %r11d                                   #332.5
        subl      %edx, %r11d                                   #332.5
        subl      %r11d, %r9d                                   #332.5
        movslq    %r9d, %r9                                     #332.5
        lea       31(%r10), %rax                                #336.40
        mulq      %rcx                                          #336.40
        shrq      $4, %rdx                                      #336.40
        xorl      %r8d, 20(%rdi,%r9,4)                          #332.5
        imulq     $-120, %rdx, %r8                              #336.34
        lea       20(%rdi,%r10,4), %rdi                         #336.22
        lea       45(%r10), %rax                                #337.40
        mulq      %rcx                                          #337.40
        shrq      $4, %rdx                                      #337.40
        imulq     $-120, %rdx, %r11                             #337.34
        addq      %rdi, %r8                                     #336.34
        movl      124(%r8), %r9d                                #336.22
        movl      %r9d, (%rsi)                                  #336.22
        addq      %rdi, %r11                                    #337.34
        movl      180(%r11), %edx                               #337.22
        movl      %edx, 16(%rsi)                                #337.22
        lea       32(%r10), %rax                                #336.40
        mulq      %rcx                                          #336.40
        shrq      $4, %rdx                                      #336.40
        imulq     $-120, %rdx, %r8                              #336.34
        lea       46(%r10), %rax                                #337.40
        mulq      %rcx                                          #337.40
        shrq      $4, %rdx                                      #337.40
        addq      %rdi, %r8                                     #336.34
        movl      128(%r8), %r9d                                #336.22
        imulq     $-120, %rdx, %r8                              #337.34
        movl      %r9d, 4(%rsi)                                 #336.22
        lea       33(%r10), %rax                                #336.40
        mulq      %rcx                                          #336.40
        shrq      $4, %rdx                                      #336.40
        addq      %rdi, %r8                                     #337.34
        movl      184(%r8), %r11d                               #337.22
        imulq     $-120, %rdx, %r8                              #336.34
        movl      %r11d, 20(%rsi)                               #337.22
        lea       47(%r10), %rax                                #337.40
        mulq      %rcx                                          #337.40
        shrq      $4, %rdx                                      #337.40
        addq      %rdi, %r8                                     #336.34
        movl      132(%r8), %r9d                                #336.22
        imulq     $-120, %rdx, %r8                              #337.34
        movl      %r9d, 8(%rsi)                                 #336.22
        lea       34(%r10), %rax                                #336.40
        mulq      %rcx                                          #336.40
        shrq      $4, %rdx                                      #336.40
        addq      %rdi, %r8                                     #337.34
        movl      188(%r8), %r11d                               #337.22
        imulq     $-120, %rdx, %r8                              #336.34
        movl      %r11d, 24(%rsi)                               #337.22
        addq      $48, %r10                                     #337.40
        addq      %rdi, %r8                                     #336.34
        movl      136(%r8), %r9d                                #336.22
        movl      %r9d, 12(%rsi)                                #336.22
        movq      %r10, %rax                                    #337.40
        mulq      %rcx                                          #337.40
        shrq      $4, %rdx                                      #337.40
        imulq     $-120, %rdx, %rcx                             #337.34
        xorl      %eax, %eax                                    #340.12
        addq      %rcx, %rdi                                    #337.34
        movl      192(%rdi), %r10d                              #337.22
        movl      %r10d, 28(%rsi)                               #337.22
..___tag_value_fugue_final_256.51:                              #340.12
        popq      %rbx                                          #340.12
..___tag_value_fugue_final_256.52:                              #
        popq      %rbp                                          #340.12
..___tag_value_fugue_final_256.54:                              #
        popq      %r12                                          #340.12
..___tag_value_fugue_final_256.56:                              #
        popq      %r13                                          #340.12
..___tag_value_fugue_final_256.58:                              #
        popq      %r14                                          #340.12
..___tag_value_fugue_final_256.60:                              #
        popq      %r15                                          #340.12
..___tag_value_fugue_final_256.62:                              #
        ret                                                     #340.12
        .align    16,0x90
..___tag_value_fugue_final_256.63:                              #
                                # LOE
# mark_end;
	.type	fugue_final_256,@function
	.size	fugue_final_256,.-fugue_final_256
	.data
# -- End  fugue_final_256
	.section .rodata, "a"
	.align 32
	.align 32
aes_style_table:
	.long	2536661859
	.long	3949952124
	.long	3344856951
	.long	4151999355
	.long	3857249010
	.long	3070913387
	.long	2803265391
	.long	963495365
	.long	3230674992
	.long	67567873
	.long	2267965287
	.long	2899389227
	.long	3586981630
	.long	1897125847
	.long	2591861675
	.long	3277420150
	.long	88132298
	.long	1050903170
	.long	155830729
	.long	4016602493
	.long	3318807290
	.long	2140428633
	.long	130959175
	.long	3991335152
	.long	2188291501
	.long	2098910420
	.long	3192103586
	.long	2321592239
	.long	1190763676
	.long	2790368420
	.long	3544543858
	.long	762757312
	.long	3928537015
	.long	3653631485
	.long	2060751763
	.long	2566006310
	.long	3632412214
	.long	4240260927
	.long	4059297783
	.long	491965644
	.long	3498849332
	.long	2723587493
	.long	3113084389
	.long	3923898865
	.long	3746328945
	.long	1295964376
	.long	3298242865
	.long	1416303893
	.long	270271492
	.long	828622791
	.long	2364089123
	.long	562021315
	.long	1615337496
	.long	1859098262
	.long	337315077
	.long	1592498842
	.long	471140103
	.long	1216221714
	.long	917340288
	.long	2778260194
	.long	2175265771
	.long	2633312039
	.long	4264800946
	.long	3478156661
	.long	608110857
	.long	983860099
	.long	2965646380
	.long	1749424666
	.long	1816206107
	.long	2735828590
	.long	1939692122
	.long	3058540704
	.long	1403343442
	.long	3969989435
	.long	1964299990
	.long	4197757875
	.long	2766088489
	.long	2711610339
	.long	3167563567
	.long	649168004
	.long	1470255955
	.long	1761726929
	.long	0
	.long	2578836973
	.long	2162171936
	.long	3720543484
	.long	4063932849
	.long	2006604635
	.long	3004000874
	.long	21482443
	.long	3457662654
	.long	3836688697
	.long	871189066
	.long	738151500
	.long	2073253976
	.long	291229647
	.long	1829163216
	.long	2445012975
	.long	2658904746
	.long	3252157435
	.long	399655747
	.long	804801869
	.long	3432592179
	.long	582387077
	.long	264258885
	.long	3386505721
	.long	135135746
	.long	3882254207
	.long	1537953872
	.long	4038343740
	.long	1257283487
	.long	2524293288
	.long	1605128529
	.long	3125060515
	.long	467353664
	.long	176197519
	.long	2127794834
	.long	1123982749
	.long	3769120824
	.long	4194170357
	.long	3323575484
	.long	3996104374
	.long	1160829658
	.long	2229739809
	.long	1081085968
	.long	3519807487
	.long	3790599155
	.long	1695077074
	.long	425053645
	.long	807668748
	.long	1283003155
	.long	2645748972
	.long	1736859487
	.long	1791530903
	.long	197608516
	.long	1550128919
	.long	1030407364
	.long	2857936807
	.long	3814817406
	.long	4105387325
	.long	2334614628
	.long	1871207773
	.long	1682905369
	.long	3611456371
	.long	2604359776
	.long	850035073
	.long	670453583
	.long	1562565852
	.long	2297307682
	.long	2832607786
	.long	1994231952
	.long	378898568
	.long	63522374
	.long	2512187118
	.long	3590699192
	.long	1349260308
	.long	1429003998
	.long	1669422686
	.long	741411595
	.long	1094179803
	.long	2912346336
	.long	3365810738
	.long	3903207994
	.long	674630154
	.long	1071925577
	.long	403834374
	.long	2432443428
	.long	1804557404
	.long	628671170
	.long	1628427219
	.long	2255072428
	.long	2469749346
	.long	1926926737
	.long	1657181589
	.long	3179996388
	.long	4285823353
	.long	2978211815
	.long	223267016
	.long	3699717943
	.long	2937613677
	.long	42896781
	.long	2031998421
	.long	603016782
	.long	2456988073
	.long	2870963308
	.long	1136219734
	.long	4261082356
	.long	2241915626
	.long	2401264997
	.long	4085086842
	.long	2389159598
	.long	540542984
	.long	3725310650
	.long	4218648696
	.long	2499487013
	.long	3100257838
	.long	1884560412
	.long	2925504166
	.long	3860968628
	.long	895796934
	.long	2377050344
	.long	1495653853
	.long	3411506292
	.long	2086477599
	.long	938101579
	.long	3256794557
	.long	446466955
	.long	513510026
	.long	3679154288
	.long	4172955198
	.long	3794187701
	.long	2200528486
	.long	1004750920
	.long	201917187
	.long	4126471926
	.long	942280206
	.long	2671534433
	.long	3565892917
	.long	1203656535
	.long	3523393977
	.long	784303750
	.long	695321025
	.long	1951603997
	.long	1324850846
	.long	2844910049
	.long	3453942008
	.long	1457887384
	.long	1148653841
	.long	3204737385
	.long	1228528089
	.long	243764878
	.long	1723962516
	.long	1525455771
	.long	2019171870
	.long	716736391
	.long	2309614057
	.long	358403790
	.long	1336956245
	.long	2698520616
	.long	1361829855
	.long	109677708
	.long	2991235489
	.long	311593353
	.long	874712333
	.long	3390095295
	.long	3045385958
	.long	332743234
	.long	3137562728
	.long	534528321
	.long	1390582169
	.long	3032689965
	.long	1009585935
	.long	4131238064
	.long	1270305876
	.long	3658267579
	.long	1482823190
	.long	845374359
	.long	1870429419
	.long	1584887751
	.long	2054913015
	.long	3908236005
	.long	174812087
	.long	376401831
	.long	1841677625
	.long	2419077312
	.long	117506308
	.long	778528647
	.long	3509267372
	.long	3439263445
	.long	332912497
	.long	2091625370
	.long	1500935875
	.long	1087031813
	.long	2743239230
	.long	1237960969
	.long	1753054703
	.long	3506109125
	.long	2488883583
	.long	3460777735
	.long	3874549997
	.long	1856875906
	.long	450155645
	.long	1134731966
	.long	1622126474
	.long	4187790406
	.long	1369744550
	.long	1165128403
	.long	1992343597
	.long	683128810
	.long	3321757145
	.long	3566441338
	.long	4062586520
	.long	2184591064
	.long	3175038972
	.long	4093114353
	.long	1389153309
	.long	2352231632
	.long	1453696418
	.long	2380654009
	.long	3790729705
	.long	1282503135
	.long	1054398541
	.long	2536583620
	.long	1796543828
	.long	470025232
	.long	1674037041
	.long	3911394188
	.long	2143535905
	.long	1209538656
	.long	3482752622
	.long	453313812
	.long	3952777822
	.long	352782108
	.long	2115113544
	.long	2910879798
	.long	2565005989
	.long	2817256321
	.long	4112983964
	.long	867349246
	.long	1349875151
	.long	1057556772
	.long	2760082234
	.long	3291229360
	.long	1176115816
	.long	1092295532
	.long	292449955
	.long	2639944307
	.long	1302372534
	.long	2773635667
	.long	2705013740
	.long	349623925
	.long	884192250
	.long	3744016804
	.long	2682512289
	.long	3442421692
	.long	2978251814
	.long	2723369815
	.long	30527849
	.long	0
	.long	3052268953
	.long	3760201856
	.long	3271359709
	.long	984723954
	.long	2589678455
	.long	225077939
	.long	1204538113
	.long	398376654
	.long	2939763172
	.long	3981068851
	.long	4283190315
	.long	2472040571
	.long	1540345617
	.long	114348141
	.long	3153063825
	.long	2074782366
	.long	3623615425
	.long	3527623447
	.long	4165815599
	.long	2570269644
	.long	3062203682
	.long	3225765135
	.long	3657038281
	.long	235012616
	.long	1719631847
	.long	2874167387
	.long	3023846640
	.long	4036992842
	.long	1973987478
	.long	2891010399
	.long	1151574970
	.long	3678421019
	.long	2156891914
	.long	3549598334
	.long	4271742274
	.long	2822256864
	.long	4260754937
	.long	431799494
	.long	800503534
	.long	819649093
	.long	3877708164
	.long	1880100928
	.long	3422552017
	.long	4025742305
	.long	148034149
	.long	1439550745
	.long	604769328
	.long	2031293260
	.long	3001871517
	.long	2254397287
	.long	3365377898
	.long	3343139851
	.long	1696012124
	.long	1791280189
	.long	1487382442
	.long	1635679971
	.long	3007135220
	.long	660890763
	.long	2287820143
	.long	1327044964
	.long	1114862551
	.long	996171931
	.long	2860613938
	.long	4132392743
	.long	584899677
	.long	3995214472
	.long	3593087656
	.long	3717238902
	.long	2508752918
	.long	3376825859
	.long	3169775253
	.long	95992022
	.long	1813255248
	.long	752803413
	.long	2170445411
	.long	822807340
	.long	937155393
	.long	2531319981
	.long	2654089928
	.long	2788834024
	.long	906627624
	.long	3830008127
	.long	302384664
	.long	4230227088
	.long	2405194859
	.long	2026029605
	.long	265540449
	.long	1772924038
	.long	895640211
	.long	3666973042
	.long	3331691874
	.long	2330256573
	.long	1954118143
	.long	2213013425
	.long	1321781261
	.long	2234988508
	.long	409824687
	.long	2391641346
	.long	500553081
	.long	4048440867
	.long	1923721618
	.long	527199403
	.long	3109443139
	.long	4210357501
	.long	2699750021
	.long	543516047
	.long	2105178867
	.long	1739501198
	.long	940050464
	.long	196786910
	.long	1937275131
	.long	4213515668
	.long	3392024248
	.long	1411128432
	.long	1604757166
	.long	565490918
	.long	1690748469
	.long	2934499469
	.long	635297113
	.long	1467249867
	.long	1562320764
	.long	3930802999
	.long	515751362
	.long	2626390810
	.long	2609547806
	.long	1265660123
	.long	3124641528
	.long	649442786
	.long	694576771
	.long	3813165115
	.long	151192332
	.long	4109825781
	.long	705564216
	.long	1013014943
	.long	2335520212
	.long	3193395015
	.long	45726162
	.long	3213264430
	.long	1908523305
	.long	1394417012
	.long	4154367566
	.long	2447499689
	.long	3740858573
	.long	3851982934
	.long	1997607236
	.long	74017215
	.long	970578249
	.long	2274266638
	.long	3247740006
	.long	3969620826
	.long	1511923320
	.long	3095889706
	.long	2850679177
	.long	1557057045
	.long	2958382415
	.long	3626510496
	.long	736091985
	.long	2307689478
	.long	1252106674
	.long	2458487058
	.long	588057908
	.long	281001930
	.long	2229724853
	.long	3577889299
	.long	57174203
	.long	3695264031
	.long	3801717074
	.long	3274517940
	.long	755961660
	.long	1034989814
	.long	3075757131
	.long	213629914
	.long	1645614680
	.long	1667471154
	.long	2088561519
	.long	2004338526
	.long	2071721850
	.long	4076004840
	.long	1802221322
	.long	1869588246
	.long	3318036845
	.long	808501392
	.long	16843783
	.long	1734838062
	.long	724282577
	.long	4278113740
	.long	3621220627
	.long	2880150140
	.long	1987494745
	.long	3402237248
	.long	2189573795
	.long	3385395529
	.long	2105405288
	.long	4210738640
	.long	1499037588
	.long	1195837390
	.long	4042321382
	.long	2913829486
	.long	3570695450
	.long	2728574531
	.long	2947517024
	.long	2627487481
	.long	2762253905
	.long	1920127813
	.long	3233820022
	.long	3082283560
	.long	4261272005
	.long	2475915988
	.long	640063730
	.long	909564034
	.long	1061158077
	.long	4160221683
	.long	3435928914
	.long	875876492
	.long	2779095638
	.long	3857037709
	.long	4059163105
	.long	1903288140
	.long	3638054206
	.long	825345175
	.long	353719403
	.long	67375132
	.long	3351720291
	.long	589532393
	.long	3284345215
	.long	404250696
	.long	2526441167
	.long	84218907
	.long	2593808107
	.long	117906453
	.long	303188094
	.long	2155886253
	.long	3806504344
	.long	3958079911
	.long	656907509
	.long	2998074931
	.long	1970655056
	.long	151594047
	.long	2206415524
	.long	741126340
	.long	437938246
	.long	454782017
	.long	1852744465
	.long	1515877277
	.long	2694886989
	.long	1381127077
	.long	993782945
	.long	3604378900
	.long	3014916660
	.long	690595039
	.long	3823346079
	.long	791657677
	.long	2223253169
	.long	1397970850
	.long	3520162049
	.long	0
	.long	3991771573
	.long	539001056
	.long	4244430274
	.long	2981229114
	.long	1532721050
	.long	1785377549
	.long	3419078983
	.long	3200175639
	.long	960095407
	.long	1246376941
	.long	1280060415
	.long	1482193811
	.long	3486454107
	.long	3503320326
	.long	4025455035
	.long	2863308411
	.long	4227580375
	.long	1128470482
	.long	1296904184
	.long	859032729
	.long	2240094902
	.long	1162153920
	.long	4193896921
	.long	33687566
	.long	2139088742
	.long	1347443627
	.long	1010626740
	.long	2678016752
	.long	2829620853
	.long	1364287404
	.long	2745416260
	.long	1077943259
	.long	2408516224
	.long	2459074259
	.long	2644329214
	.long	943251624
	.long	4126538237
	.long	3166488089
	.long	3065441839
	.long	3671737648
	.long	555844839
	.long	269500528
	.long	4294955467
	.long	4092846575
	.long	3537003784
	.long	3452770645
	.long	202125348
	.long	320031865
	.long	3974929842
	.long	1600087942
	.long	2543282888
	.long	1145310151
	.long	387406949
	.long	3301195114
	.long	2812783192
	.long	2122244961
	.long	1027470515
	.long	1684310823
	.long	1566404488
	.long	421094479
	.long	1936971586
	.long	1616943931
	.long	2172727978
	.long	1330587638
	.long	3705429282
	.long	572688622
	.long	707438806
	.long	2425386717
	.long	2290620053
	.long	1178993609
	.long	4008613308
	.long	3099121157
	.long	336875628
	.long	3739112748
	.long	1583244161
	.long	185281585
	.long	3688579383
	.long	3772820886
	.long	842188958
	.long	976939174
	.long	168437814
	.long	1229537252
	.long	101062674
	.long	606376188
	.long	1549560719
	.long	3267503480
	.long	3553845519
	.long	2896987753
	.long	1650627381
	.long	2442228442
	.long	2509595334
	.long	3840195978
	.long	2038038388
	.long	3890721155
	.long	3368553806
	.long	926407813
	.long	1835904792
	.long	2374828686
	.long	3587537181
	.long	1313743857
	.long	2846462578
	.long	1819061023
	.long	1448494009
	.long	4109696506
	.long	3941238176
	.long	1701154592
	.long	2054878077
	.long	2930675303
	.long	134750264
	.long	3132808715
	.long	2021194611
	.long	623219963
	.long	774813898
	.long	471625812
	.long	2795941471
	.long	3031754273
	.long	3334878564
	.long	3907554734
	.long	3722271013
	.long	1953811287
	.long	522157149
	.long	1263220714
	.long	3183329822
	.long	2341149340
	.long	2324307611
	.long	1886444363
	.long	1044314298
	.long	3048596006
	.long	1717994281
	.long	1212693475
	.long	50531337
	.long	4143379956
	.long	235812906
	.long	1633787708
	.long	892720267
	.long	1465337790
	.long	3115962882
	.long	2256940735
	.long	3250661745
	.long	488469587
	.long	2661175031
	.long	3789662609
	.long	4177055198
	.long	2560120549
	.long	286344311
	.long	1768537860
	.long	3654895929
	.long	2391674503
	.long	2492753601
	.long	2610649836
	.long	505313370
	.long	2273782456
	.long	3924396457
	.long	3469612380
	.long	1431654320
	.long	673751256
	.long	3755954475
	.long	2357986953
	.long	2711728714
	.long	2307461778
	.long	218969123
	.long	3217017360
	.long	3873879428
	.long	1111626709
	.long	1751694083
	.long	1094787036
	.long	2576962274
	.long	757970115
	.long	252656685
	.long	2964387389
	.long	1414810551
	.long	3149650444
	.long	370563170
	.long	1670853219
	.long	2095804284
	.long	2009554551
	.long	2079816315
	.long	4075153650
	.long	1807157867
	.long	1873221231
	.long	3308875205
	.long	817926192
	.long	17041153
	.long	1736912487
	.long	732746027
	.long	4275424510
	.long	3614512087
	.long	2879028395
	.long	1992513910
	.long	3389341898
	.long	2185143170
	.long	3372829129
	.long	2112841853
	.long	4207268090
	.long	1501533273
	.long	1191693895
	.long	4042122992
	.long	2911006381
	.long	3564968660
	.long	2730378146
	.long	2945081519
	.long	2621897116
	.long	2762363300
	.long	1926448498
	.long	3224204992
	.long	3085576375
	.long	4258907645
	.long	2474300563
	.long	647557670
	.long	920158774
	.long	1073528127
	.long	4159828983
	.long	3424473804
	.long	886082612
	.long	2778879653
	.long	3854142949
	.long	4058636785
	.long	1910459505
	.long	3628941016
	.long	834967345
	.long	357853973
	.long	68164612
	.long	3341902791
	.long	596437283
	.long	3273752515
	.long	408963096
	.long	2523844502
	.long	85203717
	.long	2589911962
	.long	119280903
	.long	306740754
	.long	2151067008
	.long	3802503394
	.long	3951142891
	.long	664597799
	.long	3003003826
	.long	1976520821
	.long	153370377
	.long	2201658499
	.long	749782060
	.long	443041306
	.long	460079387
	.long	1856180590
	.long	1517526362
	.long	2696301984
	.long	1381213522
	.long	1005363515
	.long	3597997270
	.long	3019519155
	.long	698670889
	.long	3819020259
	.long	800902447
	.long	2217128324
	.long	1398252115
	.long	3513319889
	.long	0
	.long	3986273773
	.long	545316896
	.long	4242391804
	.long	2985441969
	.long	1534564955
	.long	1790119274
	.long	3405858763
	.long	3201177534
	.long	971288377
	.long	1244917066
	.long	1277951820
	.long	1484493656
	.long	3474021327
	.long	3496806096
	.long	4019305455
	.long	2862513066
	.long	4223784955
	.long	1125634627
	.long	1294989389
	.long	869046579
	.long	2233644677
	.long	1158660165
	.long	4190755321
	.long	34082306
	.long	2145871487
	.long	1348184912
	.long	1022407740
	.long	2672488607
	.long	2828432808
	.long	1365224529
	.long	2746893475
	.long	1075567424
	.long	2399830159
	.long	2457785234
	.long	2638413469
	.long	954247224
	.long	4126801397
	.long	3167099324
	.long	3069063094
	.long	3661967578
	.long	562358049
	.long	272658448
	.long	4291939327
	.long	4091670515
	.long	3529836754
	.long	3440989645
	.long	204481548
	.long	323778835
	.long	3969757932
	.long	1600620127
	.long	2540357783
	.long	1141622596
	.long	391931159
	.long	3292359364
	.long	2812958887
	.long	2128830846
	.long	1039446845
	.long	1686841188
	.long	1567590493
	.long	426004249
	.long	1943487091
	.long	1620786016
	.long	2167581313
	.long	1328019023
	.long	3697091292
	.long	579399202
	.long	715707946
	.long	2423709072
	.long	2283181448
	.long	1174653254
	.long	4002790638
	.long	3101033912
	.long	340814868
	.long	3730123998
	.long	1583579486
	.long	187445515
	.long	3678484443
	.long	3769472736
	.long	852008498
	.long	988325434
	.long	170407434
	.long	1228923977
	.long	102240774
	.long	613481508
	.long	1550552924
	.long	3257235650
	.long	3546353619
	.long	2894490028
	.long	1653814626
	.long	2440223377
	.long	2506278549
	.long	3837627108
	.long	2046784633
	.long	3887170535
	.long	3356315336
	.long	937198903
	.long	1840191597
	.long	2365755021
	.long	3581484501
	.long	1310978382
	.long	2844947113
	.long	1823154028
	.long	1447278934
	.long	4110285556
	.long	3934626026
	.long	1703878757
	.long	2062777722
	.long	2928568238
	.long	136329224
	.long	3135114170
	.long	2029745016
	.long	630520613
	.long	783862318
	.long	477123612
	.long	2796445606
	.long	3034980788
	.long	3325387974
	.long	3901599464
	.long	3713607133
	.long	1959483252
	.long	528243999
	.long	1261955659
	.long	3183615677
	.long	2333777035
	.long	2317261706
	.long	1893419888
	.long	1056487998
	.long	3051497141
	.long	1719871846
	.long	1211884360
	.long	51120387
	.long	4143314166
	.long	238561806
	.long	1637825633
	.long	903121717
	.long	1464319575
	.long	3117548217
	.long	2251210630
	.long	3240718785
	.long	494162717
	.long	2655975326
	.long	3785986529
	.long	4174241528
	.long	2555831704
	.long	289699601
	.long	1774126185
	.long	3645454809
	.long	2383316878
	.long	2489762196
	.long	2606427291
	.long	511203870
	.long	2267723911
	.long	3918113257
	.long	3457506510
	.long	1431285845
	.long	681629736
	.long	3746638815
	.long	2349238668
	.long	2712816289
	.long	2299695753
	.long	221520653
	.long	3217690815
	.long	3870655718
	.long	1108596034
	.long	1757086568
	.long	1092607041
	.long	2572346009
	.long	766821165
	.long	255601935
	.long	2968927664
	.long	1414248276
	.long	3151629499
	.long	374891030
	.type	aes_style_table,@object
	.size	aes_style_table,4096
	.space 512	# pad
	.align 16
_2il0floatpacket.3:
	.long	0x0f0a0500,0x0c0b0601,0x0d080702,0x0e090403
	.type	_2il0floatpacket.3,@object
	.size	_2il0floatpacket.3,16
	.align 16
_2il0floatpacket.4:
	.long	0x0f0a0500,0x030e0904,0x07020d08,0x0b06010c
	.type	_2il0floatpacket.4,@object
	.size	_2il0floatpacket.4,16
	.align 16
_2il0floatpacket.8:
	.long	0x0f0a0500,0x0c0b0601,0x0d080702,0x0e090403
	.type	_2il0floatpacket.8,@object
	.size	_2il0floatpacket.8,16
	.align 16
_2il0floatpacket.9:
	.long	0x0f0a0500,0x030e0904,0x07020d08,0x0b06010c
	.type	_2il0floatpacket.9,@object
	.size	_2il0floatpacket.9,16
	.data
	.section .note.GNU-stack, ""
// -- Begin DWARF2 SEGMENT .debug_line
	.section .debug_line
.debug_line_seg:
	.align 1
// -- Begin DWARF2 SEGMENT .eh_frame
	.section .eh_frame,"a",@progbits
.eh_frame_seg:
	.align 8
	.4byte 0x00000014
	.4byte 0x00000000
	.byte 0x01
	.byte 0x00
	.byte 0x01
	.byte 0x78
	.byte 0x10
	.4byte 0x9008070c
	.byte 0x01
	.4byte 0x00000000
	.2byte 0x0000
	.4byte 0x000000bc
	.4byte 0x0000001c
	.8byte ..___tag_value_fugue_update_256.1
	.8byte ..___tag_value_fugue_update_256.35-..___tag_value_fugue_update_256.1
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.2-..___tag_value_fugue_update_256.1
	.byte 0x8f
	.byte 0x02
	.byte 0x0c
	.2byte 0x1007
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.4-..___tag_value_fugue_update_256.2
	.byte 0x8e
	.byte 0x03
	.byte 0x0c
	.2byte 0x1807
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.6-..___tag_value_fugue_update_256.4
	.byte 0x8d
	.byte 0x04
	.byte 0x0c
	.2byte 0x2007
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.8-..___tag_value_fugue_update_256.6
	.byte 0x8c
	.byte 0x05
	.byte 0x0c
	.2byte 0x2807
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.10-..___tag_value_fugue_update_256.8
	.byte 0x86
	.byte 0x06
	.byte 0x0c
	.2byte 0x3007
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.12-..___tag_value_fugue_update_256.10
	.byte 0x83
	.byte 0x07
	.byte 0x0c
	.2byte 0x3807
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.14-..___tag_value_fugue_update_256.12
	.byte 0x0c
	.2byte 0x9007
	.byte 0x04
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.15-..___tag_value_fugue_update_256.14
	.byte 0x0c
	.2byte 0x3807
	.byte 0x09
	.2byte 0x0303
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.17-..___tag_value_fugue_update_256.15
	.byte 0x0c
	.2byte 0x3007
	.byte 0x09
	.2byte 0x0606
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.19-..___tag_value_fugue_update_256.17
	.byte 0x0c
	.2byte 0x2807
	.byte 0x09
	.2byte 0x0c0c
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.21-..___tag_value_fugue_update_256.19
	.byte 0x0c
	.2byte 0x2007
	.byte 0x09
	.2byte 0x0d0d
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.23-..___tag_value_fugue_update_256.21
	.byte 0x0c
	.2byte 0x1807
	.byte 0x09
	.2byte 0x0e0e
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.25-..___tag_value_fugue_update_256.23
	.byte 0x0c
	.2byte 0x1007
	.byte 0x09
	.2byte 0x0f0f
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.27-..___tag_value_fugue_update_256.25
	.byte 0x0c
	.2byte 0x0807
	.byte 0x04
	.4byte ..___tag_value_fugue_update_256.28-..___tag_value_fugue_update_256.27
	.byte 0x0c
	.2byte 0x9007
	.byte 0x04
	.byte 0x83
	.byte 0x07
	.byte 0x86
	.byte 0x06
	.byte 0x8c
	.byte 0x05
	.byte 0x8d
	.byte 0x04
	.byte 0x8e
	.byte 0x03
	.byte 0x8f
	.byte 0x02
	.4byte 0x00000000
	.4byte 0x00000014
	.4byte 0x000000dc
	.8byte ..___tag_value_rdtsc.36
	.8byte ..___tag_value_rdtsc.37-..___tag_value_rdtsc.36
	.4byte 0x0000009c
	.4byte 0x000000f4
	.8byte ..___tag_value_fugue_final_256.38
	.8byte ..___tag_value_fugue_final_256.63-..___tag_value_fugue_final_256.38
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.39-..___tag_value_fugue_final_256.38
	.byte 0x8f
	.byte 0x02
	.byte 0x0c
	.2byte 0x1007
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.41-..___tag_value_fugue_final_256.39
	.byte 0x8e
	.byte 0x03
	.byte 0x0c
	.2byte 0x1807
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.43-..___tag_value_fugue_final_256.41
	.byte 0x8d
	.byte 0x04
	.byte 0x0c
	.2byte 0x2007
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.45-..___tag_value_fugue_final_256.43
	.byte 0x8c
	.byte 0x05
	.byte 0x0c
	.2byte 0x2807
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.47-..___tag_value_fugue_final_256.45
	.byte 0x86
	.byte 0x06
	.byte 0x0c
	.2byte 0x3007
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.49-..___tag_value_fugue_final_256.47
	.byte 0x83
	.byte 0x07
	.byte 0x0c
	.2byte 0x3807
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.51-..___tag_value_fugue_final_256.49
	.byte 0x09
	.2byte 0x0303
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.52-..___tag_value_fugue_final_256.51
	.byte 0x0c
	.2byte 0x3007
	.byte 0x09
	.2byte 0x0606
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.54-..___tag_value_fugue_final_256.52
	.byte 0x0c
	.2byte 0x2807
	.byte 0x09
	.2byte 0x0c0c
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.56-..___tag_value_fugue_final_256.54
	.byte 0x0c
	.2byte 0x2007
	.byte 0x09
	.2byte 0x0d0d
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.58-..___tag_value_fugue_final_256.56
	.byte 0x0c
	.2byte 0x1807
	.byte 0x09
	.2byte 0x0e0e
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.60-..___tag_value_fugue_final_256.58
	.byte 0x0c
	.2byte 0x1007
	.byte 0x09
	.2byte 0x0f0f
	.byte 0x04
	.4byte ..___tag_value_fugue_final_256.62-..___tag_value_fugue_final_256.60
	.byte 0x0c
	.2byte 0x0807
	.4byte 0x00000000
	.byte 0x00
# End
