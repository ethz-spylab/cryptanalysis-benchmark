#ifndef crypto_sign_pqrsa30_H
#define crypto_sign_pqrsa30_H

#define crypto_sign_pqrsa30_ref_SECRETKEYBYTES 3221225472LL
#define crypto_sign_pqrsa30_ref_PUBLICKEYBYTES 1073741824LL
#define crypto_sign_pqrsa30_ref_BYTES 1073741856LL
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_sign_pqrsa30_ref(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_sign_pqrsa30_ref_open(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_sign_pqrsa30_ref_keypair(unsigned char *,unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_sign_pqrsa30 crypto_sign_pqrsa30_ref
#define crypto_sign_pqrsa30_open crypto_sign_pqrsa30_ref_open
#define crypto_sign_pqrsa30_keypair crypto_sign_pqrsa30_ref_keypair
#define crypto_sign_pqrsa30_BYTES crypto_sign_pqrsa30_ref_BYTES
#define crypto_sign_pqrsa30_SECRETKEYBYTES crypto_sign_pqrsa30_ref_SECRETKEYBYTES
#define crypto_sign_pqrsa30_PUBLICKEYBYTES crypto_sign_pqrsa30_ref_PUBLICKEYBYTES
#define crypto_sign_pqrsa30_DETERMINISTIC crypto_sign_pqrsa30_ref_DETERMINISTIC

#endif
