#ifndef crypto_sign_pqrsa15_H
#define crypto_sign_pqrsa15_H

#define crypto_sign_pqrsa15_ref_SECRETKEYBYTES 98304
#define crypto_sign_pqrsa15_ref_PUBLICKEYBYTES 32768
#define crypto_sign_pqrsa15_ref_BYTES 32800
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_sign_pqrsa15_ref(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_sign_pqrsa15_ref_open(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_sign_pqrsa15_ref_keypair(unsigned char *,unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_sign_pqrsa15 crypto_sign_pqrsa15_ref
#define crypto_sign_pqrsa15_open crypto_sign_pqrsa15_ref_open
#define crypto_sign_pqrsa15_keypair crypto_sign_pqrsa15_ref_keypair
#define crypto_sign_pqrsa15_BYTES crypto_sign_pqrsa15_ref_BYTES
#define crypto_sign_pqrsa15_SECRETKEYBYTES crypto_sign_pqrsa15_ref_SECRETKEYBYTES
#define crypto_sign_pqrsa15_PUBLICKEYBYTES crypto_sign_pqrsa15_ref_PUBLICKEYBYTES
#define crypto_sign_pqrsa15_DETERMINISTIC crypto_sign_pqrsa15_ref_DETERMINISTIC

#endif
