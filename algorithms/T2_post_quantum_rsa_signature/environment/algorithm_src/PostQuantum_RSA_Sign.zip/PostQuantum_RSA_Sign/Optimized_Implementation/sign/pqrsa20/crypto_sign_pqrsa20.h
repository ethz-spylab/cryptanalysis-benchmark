#ifndef crypto_sign_pqrsa20_H
#define crypto_sign_pqrsa20_H

#define crypto_sign_pqrsa20_ref_SECRETKEYBYTES 3145728LL
#define crypto_sign_pqrsa20_ref_PUBLICKEYBYTES 1048576LL
#define crypto_sign_pqrsa20_ref_BYTES 1048608LL
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_sign_pqrsa20_ref(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_sign_pqrsa20_ref_open(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_sign_pqrsa20_ref_keypair(unsigned char *,unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_sign_pqrsa20 crypto_sign_pqrsa20_ref
#define crypto_sign_pqrsa20_open crypto_sign_pqrsa20_ref_open
#define crypto_sign_pqrsa20_keypair crypto_sign_pqrsa20_ref_keypair
#define crypto_sign_pqrsa20_BYTES crypto_sign_pqrsa20_ref_BYTES
#define crypto_sign_pqrsa20_SECRETKEYBYTES crypto_sign_pqrsa20_ref_SECRETKEYBYTES
#define crypto_sign_pqrsa20_PUBLICKEYBYTES crypto_sign_pqrsa20_ref_PUBLICKEYBYTES
#define crypto_sign_pqrsa20_DETERMINISTIC crypto_sign_pqrsa20_ref_DETERMINISTIC

#endif
