/*
   PQCgenKAT_sign.c
   Created by Bassham, Lawrence E (Fed) on 8/29/17.
   Copyright © 2017 Bassham, Lawrence E (Fed). All rights reserved.
   + mods from djb: see KATNOTES
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "rng.h"
#include "crypto_sign.h"

#define KAT_SUCCESS          0
#define KAT_FILE_OPEN_ERROR -1
#define KAT_CRYPTO_FAILURE  -4

void	fprintBstr(FILE *fp, char *S, unsigned char *A, unsigned long long L);

#define MAXMLEN (33 * KATNUM)

unsigned char entropy_input[48];
unsigned char seed[KATNUM][48];
unsigned char msg[KATNUM][MAXMLEN];

int
main()
{
    FILE                *fp_req, *fp_rsp;
    unsigned long long  mlen, smlen, mlen1;
    int                 ret_val;
    int i;
    unsigned char *pk = 0;
    unsigned char *sk = 0;
    unsigned char *sm = 0;
    unsigned char *m1 = 0;

    for (i=0; i<48; i++)
        entropy_input[i] = i;
    randombytes_init(entropy_input, NULL, 256);

    for (i=0; i<KATNUM; i++) {
        randombytes(seed[i], 48);
        mlen = 33*(i+1);
        randombytes(msg[i], mlen);
    }

    fp_req = fdopen(8, "w");
    if (!fp_req)
        return KAT_FILE_OPEN_ERROR;

    for (i=0; i<KATNUM; i++) {
        fprintf(fp_req, "count = %d\n", i);
        fprintBstr(fp_req, "seed = ", seed[i], 48);
        mlen = 33*(i+1);
        assert(mlen <= MAXMLEN);
        fprintf(fp_req, "mlen = %lld\n", mlen);
        fprintBstr(fp_req, "msg = ", msg[i], mlen);
        fprintf(fp_req, "pk =\n");
        fprintf(fp_req, "sk =\n");
        fprintf(fp_req, "smlen =\n");
        fprintf(fp_req, "sm =\n\n");
    }

    fp_rsp = fdopen(9, "w");
    if (!fp_rsp)
        return KAT_FILE_OPEN_ERROR;

    fprintf(fp_rsp, "# sign/%s\n\n", crypto_sign_PRIMITIVE);

    for (i=0; i<KATNUM; i++) {
        if (!pk) pk = malloc(crypto_sign_PUBLICKEYBYTES); if (!pk) abort();
        if (!sk) sk = malloc(crypto_sign_SECRETKEYBYTES); if (!sk) abort();
        if (!sm) sm = malloc(MAXMLEN + crypto_sign_BYTES); if (!sm) abort();
        if (!m1) m1 = malloc(MAXMLEN + crypto_sign_BYTES); if (!m1) abort();

        randombytes_init(seed[i], NULL, 256);
        mlen = 33*(i+1);

        fprintf(fp_rsp, "count = %d\n", i);
        fprintBstr(fp_rsp, "seed = ", seed[i], 48);
        fprintf(fp_rsp, "mlen = %lld\n", mlen);
        fprintBstr(fp_rsp, "msg = ", msg[i], mlen);
        
        if ( (ret_val = crypto_sign_keypair(pk, sk)) != 0) {
            fprintf(stderr, "crypto_sign_keypair returned <%d>\n", ret_val);
            return KAT_CRYPTO_FAILURE;
        }
        fprintBstr(fp_rsp, "pk = ", pk, crypto_sign_PUBLICKEYBYTES);
        fprintBstr(fp_rsp, "sk = ", sk, crypto_sign_SECRETKEYBYTES);
        
        if ( (ret_val = crypto_sign(sm, &smlen, msg[i], mlen, sk)) != 0) {
            fprintf(stderr, "crypto_sign returned <%d>\n", ret_val);
            return KAT_CRYPTO_FAILURE;
        }
        fprintf(fp_rsp, "smlen = %lld\n", smlen);
        fprintBstr(fp_rsp, "sm = ", sm, smlen);
        fprintf(fp_rsp, "\n");
        
        if ( (ret_val = crypto_sign_open(m1, &mlen1, sm, smlen, pk)) != 0) {
            fprintf(stderr, "crypto_sign_open returned <%d>\n", ret_val);
            return KAT_CRYPTO_FAILURE;
        }
        
        if ( mlen != mlen1 ) {
            fprintf(stderr, "crypto_sign_open returned bad 'mlen': Got <%lld>, expected <%lld>\n", mlen1, mlen);
            return KAT_CRYPTO_FAILURE;
        }
        
        if ( memcmp(msg[i], m1, mlen) ) {
            fprintf(stderr, "crypto_sign_open returned bad 'm' value\n");
            return KAT_CRYPTO_FAILURE;
        }
    }

    return KAT_SUCCESS;
}

void
fprintBstr(FILE *fp, char *S, unsigned char *A, unsigned long long L)
{
	unsigned long long i;

	fprintf(fp, "%s", S);

	for ( i=0; i<L; i++ )
		fprintf(fp, "%02X", A[i]);

	if ( L == 0 )
		fprintf(fp, "00");

	fprintf(fp, "\n");
}
