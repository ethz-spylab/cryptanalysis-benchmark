/* streamhash_gcc_asm.c by Michal Trojnara 2007-2008 */

#include "streamhash_gcc_asm.h"
#include "sbox32.h"

HashReturn Init(hashState *state, int hashbitlen) {
    int i;

    switch(hashbitlen) {
        case 224: case 256: case 384: case 512: break;
        default: return BAD_HASHLEN;
    }
    state->hashbitlen=hashbitlen;
    state->tablen=hashbitlen/32;
    for(i=0; i<state->tablen; ++i)
        state->tabval[i]=0; /* initial state value */
    state->bitval=state->bitlen=0;
    return SUCCESS;
}

#if 0
#define process_word(i) state->tabval[i]^=sbox32[(state->tabval[i]^b^i)&0xff]
#endif
#define _QUOTEME(x) #x
#define QUOTEME(x) _QUOTEME(x)
#define process_word(i) \
    "mov " QUOTEME(4*i) "(%1), %%ebx\n\t" \
    "mov %%bl, %%al\n\t" \
    "xor %2, %%al\n\t" \
    "xor $" QUOTEME(i) ", %%al\n\t" \
    "xor sbox32(,%%eax,4), %%ebx\n\t" \
    "mov %%ebx, " QUOTEME(4*i) "(%1)\n\t"

HashReturn Update(hashState *state, const BitSequence *data,
        DataLength databitlen) {
    DataLength p, divlen=databitlen/8;
    BitSequence modlen=databitlen%8;

    /* "all calls to  update will contain data lengths that
       are divisible by 8, except, possibly, the last call" */
    if(state->bitlen) /* it was previously changed to a non-zero value */
        return FAIL;

    /* the main loop */
    for(p=0; p<divlen; ++p) { /* each input byte */
        __asm__(
            "xor %%eax, %%eax\n\t"
            process_word(0)
            process_word(1)
            process_word(2)
            process_word(3)
            process_word(4)
            process_word(5)
            process_word(6)
            "cmp $7, %0\n\t"
            "je 1f\n\t"
            process_word(7)
            "cmp $8, %0\n\t"
            "je 1f\n\t"
            process_word(8)
            process_word(9)
            process_word(10)
            process_word(11)
            "cmp $12, %0\n\t"
            "je 1f\n\t"
            process_word(12)
            process_word(13)
            process_word(14)
            process_word(15)
        "1:\n\t"
        : : "r"(state->tablen), "r"(state->tabval), "c"(data[p]): "eax", "ebx");
    }

    /* save the remaining bits if any */
    if(modlen) { /* data length is not divisible by 8 (last call) */
        state->bitval=(BitSequence)(data[p] & 0xff<<(8-modlen));
        state->bitlen=modlen;
    }
    return SUCCESS;
}

HashReturn Final(hashState *state, BitSequence *hashval) {
    int i;

    /* update the state vector with the remaining input bits */
    hashval[0]=state->bitval;
    hashval[1]=state->bitlen;
    state->bitlen=0; /* reset the number of remaining bits */
    Update(state, hashval, 16); /* two bytes */

    /* update with least significant bytes of the state vector */
    for(i=0; i<state->tablen; ++i) {
        hashval[2*i+1]=(BitSequence)(state->tabval[i]>>8);
        hashval[2*i]=(BitSequence)(state->tabval[i]); /* LSB */
    }
    Update(state, hashval, 16*state->tablen);

    /* diffuse the state vector  */
    switch(state->tablen) {
    case 7: /* 224 bits */
        for(i=0; i<3; ++i) { /* 3 interations per 32-bit word */
            state->tabval[1]+=state->tabval[0];
            state->tabval[2]+=state->tabval[1];
            state->tabval[3]+=state->tabval[2];
            state->tabval[4]+=state->tabval[3];
            state->tabval[5]+=state->tabval[4];
            state->tabval[6]+=state->tabval[5];
            state->tabval[0]+=state->tabval[6];
        }
        break;
    case 8: /* 256 bits */
        for(i=0; i<3; ++i) { /* 3 interations per 32-bit word */
            state->tabval[1]+=state->tabval[0];
            state->tabval[2]+=state->tabval[1];
            state->tabval[3]+=state->tabval[2];
            state->tabval[4]+=state->tabval[3];
            state->tabval[5]+=state->tabval[4];
            state->tabval[6]+=state->tabval[5];
            state->tabval[7]+=state->tabval[6];
            state->tabval[0]+=state->tabval[7];
        }
        break;
    case 12: /* 384 bits */
        for(i=0; i<3; ++i) { /* 3 interations per 32-bit word */
            state->tabval[1]+=state->tabval[0];
            state->tabval[2]+=state->tabval[1];
            state->tabval[3]+=state->tabval[2];
            state->tabval[4]+=state->tabval[3];
            state->tabval[5]+=state->tabval[4];
            state->tabval[6]+=state->tabval[5];
            state->tabval[7]+=state->tabval[6];
            state->tabval[8]+=state->tabval[7];
            state->tabval[9]+=state->tabval[8];
            state->tabval[10]+=state->tabval[9];
            state->tabval[11]+=state->tabval[10];
            state->tabval[0]+=state->tabval[11];
        }
        break;
    case 16: /* 512 bits */
        for(i=0; i<3; ++i) { /* 3 interations per 32-bit word */
            state->tabval[1]+=state->tabval[0];
            state->tabval[2]+=state->tabval[1];
            state->tabval[3]+=state->tabval[2];
            state->tabval[4]+=state->tabval[3];
            state->tabval[5]+=state->tabval[4];
            state->tabval[6]+=state->tabval[5];
            state->tabval[7]+=state->tabval[6];
            state->tabval[8]+=state->tabval[7];
            state->tabval[9]+=state->tabval[8];
            state->tabval[10]+=state->tabval[9];
            state->tabval[11]+=state->tabval[10];
            state->tabval[12]+=state->tabval[11];
            state->tabval[13]+=state->tabval[12];
            state->tabval[14]+=state->tabval[13];
            state->tabval[15]+=state->tabval[14];
            state->tabval[0]+=state->tabval[15];
        }
    }

    /* copy the state vector using high-endian byte order */
    /* and diffuse the result */
    hashval[0]=(BitSequence)(state->tabval[0]>>24);
    hashval[1]=hashval[0]+(BitSequence)(state->tabval[0]>>16);
    hashval[2]=hashval[1]+(BitSequence)(state->tabval[0]>>8);
    hashval[3]=hashval[2]+(BitSequence)(state->tabval[0]);

    hashval[4]=hashval[3]+(BitSequence)(state->tabval[1]>>24);
    hashval[5]=hashval[4]+(BitSequence)(state->tabval[1]>>16);
    hashval[6]=hashval[5]+(BitSequence)(state->tabval[1]>>8);
    hashval[7]=hashval[6]+(BitSequence)(state->tabval[1]);

    hashval[8]=hashval[7]+(BitSequence)(state->tabval[2]>>24);
    hashval[9]=hashval[8]+(BitSequence)(state->tabval[2]>>16);
    hashval[10]=hashval[9]+(BitSequence)(state->tabval[2]>>8);
    hashval[11]=hashval[10]+(BitSequence)(state->tabval[2]);

    hashval[12]=hashval[11]+(BitSequence)(state->tabval[3]>>24);
    hashval[13]=hashval[12]+(BitSequence)(state->tabval[3]>>16);
    hashval[14]=hashval[13]+(BitSequence)(state->tabval[3]>>8);
    hashval[15]=hashval[14]+(BitSequence)(state->tabval[3]);

    hashval[16]=hashval[15]+(BitSequence)(state->tabval[4]>>24);
    hashval[17]=hashval[16]+(BitSequence)(state->tabval[4]>>16);
    hashval[18]=hashval[17]+(BitSequence)(state->tabval[4]>>8);
    hashval[19]=hashval[18]+(BitSequence)(state->tabval[4]);

    hashval[20]=hashval[19]+(BitSequence)(state->tabval[5]>>24);
    hashval[21]=hashval[20]+(BitSequence)(state->tabval[5]>>16);
    hashval[22]=hashval[21]+(BitSequence)(state->tabval[5]>>8);
    hashval[23]=hashval[22]+(BitSequence)(state->tabval[5]);

    hashval[24]=hashval[23]+(BitSequence)(state->tabval[6]>>24);
    hashval[25]=hashval[24]+(BitSequence)(state->tabval[6]>>16);
    hashval[26]=hashval[25]+(BitSequence)(state->tabval[6]>>8);
    hashval[27]=hashval[26]+(BitSequence)(state->tabval[6]);

    if(state->tablen==7) {
        hashval[0]+=hashval[27];
        return SUCCESS;
    }

    hashval[28]=hashval[27]+(BitSequence)(state->tabval[7]>>24);
    hashval[29]=hashval[28]+(BitSequence)(state->tabval[7]>>16);
    hashval[30]=hashval[29]+(BitSequence)(state->tabval[7]>>8);
    hashval[31]=hashval[30]+(BitSequence)(state->tabval[7]);

    if(state->tablen==8) {
        hashval[0]+=hashval[31];
        return SUCCESS;
    }

    hashval[32]=hashval[31]+(BitSequence)(state->tabval[8]>>24);
    hashval[33]=hashval[32]+(BitSequence)(state->tabval[8]>>16);
    hashval[34]=hashval[33]+(BitSequence)(state->tabval[8]>>8);
    hashval[35]=hashval[34]+(BitSequence)(state->tabval[8]);

    hashval[36]=hashval[35]+(BitSequence)(state->tabval[9]>>24);
    hashval[37]=hashval[36]+(BitSequence)(state->tabval[9]>>16);
    hashval[38]=hashval[37]+(BitSequence)(state->tabval[9]>>8);
    hashval[39]=hashval[38]+(BitSequence)(state->tabval[9]);

    hashval[40]=hashval[39]+(BitSequence)(state->tabval[10]>>24);
    hashval[41]=hashval[40]+(BitSequence)(state->tabval[10]>>16);
    hashval[42]=hashval[41]+(BitSequence)(state->tabval[10]>>8);
    hashval[43]=hashval[42]+(BitSequence)(state->tabval[10]);

    hashval[44]=hashval[43]+(BitSequence)(state->tabval[11]>>24);
    hashval[45]=hashval[44]+(BitSequence)(state->tabval[11]>>16);
    hashval[46]=hashval[45]+(BitSequence)(state->tabval[11]>>8);
    hashval[47]=hashval[46]+(BitSequence)(state->tabval[11]);

    if(state->tablen==12) {
        hashval[0]+=hashval[47];
        return SUCCESS;
    }

    hashval[48]=hashval[47]+(BitSequence)(state->tabval[12]>>24);
    hashval[49]=hashval[48]+(BitSequence)(state->tabval[12]>>16);
    hashval[50]=hashval[49]+(BitSequence)(state->tabval[12]>>8);
    hashval[51]=hashval[50]+(BitSequence)(state->tabval[12]);

    hashval[52]=hashval[51]+(BitSequence)(state->tabval[13]>>24);
    hashval[53]=hashval[52]+(BitSequence)(state->tabval[13]>>16);
    hashval[54]=hashval[53]+(BitSequence)(state->tabval[13]>>8);
    hashval[55]=hashval[54]+(BitSequence)(state->tabval[13]);

    hashval[56]=hashval[55]+(BitSequence)(state->tabval[14]>>24);
    hashval[57]=hashval[56]+(BitSequence)(state->tabval[14]>>16);
    hashval[58]=hashval[57]+(BitSequence)(state->tabval[14]>>8);
    hashval[59]=hashval[58]+(BitSequence)(state->tabval[14]);

    hashval[60]=hashval[59]+(BitSequence)(state->tabval[15]>>24);
    hashval[61]=hashval[60]+(BitSequence)(state->tabval[15]>>16);
    hashval[62]=hashval[61]+(BitSequence)(state->tabval[15]>>8);
    hashval[63]=hashval[62]+(BitSequence)(state->tabval[15]);

    hashval[0]+=hashval[63];
    return SUCCESS;
}

HashReturn Hash(int hashbitlen, const BitSequence *data,
        DataLength databitlen, BitSequence *hashval) {
    hashState state;

    return (HashReturn)((int)Init(&state, hashbitlen) ||
        (int)Update(&state, data, databitlen) ||
        (int)Final(&state, hashval));
}

/* end of streamhash_gcc_asm.c */
