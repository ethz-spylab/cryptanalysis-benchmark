\KAT_MCT	
	ExtremelyLongMsgKAT.txt
	ExtremelyLongMsgKAT_224.txt
	ExtremelyLongMsgKAT_256.txt
	ExtremelyLongMsgKAT_384.txt
	ExtremelyLongMsgKAT_512.txt	
	LongMsgKAT.txt
	LongMsgKAT_224.txt
	LongMsgKAT_256.txt
	LongMsgKAT_384.txt
	LongMsgKAT_512.txt	
	MonteCarlo.txt
	MonteCarlo_224.txt
	MonteCarlo_256.txt
	MonteCarlo_384.txt
	MonteCarlo_512.txt	
	ShortMsgKAT.txt
	ShortMsgKAT_224.txt
	ShortMsgKAT_256.txt
	ShortMsgKAT_384.txt
	ShortMsgKAT_512.txt 

	\Intermediate Values
		inter256-1.txt
		inter256-2.txt
		inter512-1.txt
		inter512-2.txt

 \Optimized_32bit
	LUX.c
	LUX.h
	genKAT.c	

 \Optimized_64bit
	LUX.c
	LUX.h
	genKAT.c

 \README
	readme.txt

 \Reference_Implementation
	LUX.c
	LUX.h
	genKAT.c

 \Supporting_Documentation
	LUX.pdf