
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

/*
#include "SHA3api_ref.h"
*/
#include "aurora_compact.h"

#define	MAX_MARKER_LEN		50
#define	SUBMITTER_INFO_LEN	128

typedef enum { KAT_SUCCESS = 0, KAT_FILE_OPEN_ERROR = 1, KAT_HEADER_ERROR = 2, KAT_DATA_ERROR = 3, KAT_HASH_ERROR = 4, KAT_CMP_ERROR = 5 } STATUS_CODES;

STATUS_CODES	testShortMsg(int hashbitlen);
STATUS_CODES	testLongMsg(int hashbitlen);
STATUS_CODES	testExtremelyLongMsg(int hashbitlen);
STATUS_CODES	testMonteCarlo(int hashbitlen);
int		FindMarker(FILE *infile, const char *marker);
int		ReadHex(FILE *infile, BitSequence *A, int Length, char *str);

STATUS_CODES
main()
{
	int		i, ret_val,  bitlens[4] = { 224, 256, 384, 512 };

	for ( i=0; i<4; i++ ) {
		if ( (ret_val = testShortMsg(bitlens[i])) != KAT_SUCCESS )
			return ret_val;
		if ( (ret_val = testLongMsg(bitlens[i])) != KAT_SUCCESS )
			return ret_val;
		if ( (ret_val = testExtremelyLongMsg(bitlens[i])) != KAT_SUCCESS )
			return ret_val;
		if ( (ret_val = testMonteCarlo(bitlens[i])) != KAT_SUCCESS )
			return ret_val;
	}
	
	return KAT_SUCCESS;
}

STATUS_CODES
testShortMsg(int hashbitlen)
{
	char		fn[32], line[SUBMITTER_INFO_LEN];
	int			msglen, msgbytelen, done;
	BitSequence	Msg[256], MD[64], exp_MD[64];
	FILE		*fp_in;

	sprintf(fn, "ShortMsgKAT_%d.txt", hashbitlen);
	if ( (fp_in = fopen(fn, "r")) == NULL ) {
		printf("Couldn't open <%s> for read\n", fn);
		return KAT_FILE_OPEN_ERROR;
	}
	fprintf(stdout, "# %s\n", fn);
	if ( FindMarker(fp_in, "# Algorithm Name:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(stdout, "# Algorithm Name:%s\n", line);
	}
	else {
		printf("testShortMsg: Couldn't read Algorithm Name\n");
		return KAT_HEADER_ERROR;
	}
	if ( FindMarker(fp_in, "# Principal Submitter:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(stdout, "# Principal Submitter:%s\n", line);
	}
	else {
		printf("testShortMsg: Couldn't read Principal Submitter\n");
		return KAT_HEADER_ERROR;
	}
		
	done = 0;
	do {
		if ( FindMarker(fp_in, "Len = ") )
			fscanf(fp_in, "%d", &msglen);
		else {
			done = 1;
			break;
		}
		msgbytelen = (msglen+7)/8;

		if ( !ReadHex(fp_in, Msg, msgbytelen, "Msg = ") ) {
			printf("ERROR: unable to read 'Msg' from <%s>\n", fn);
			return KAT_DATA_ERROR;
		}
		if ( !ReadHex(fp_in, exp_MD, hashbitlen / 8, "MD = ") ) {
			printf("ERROR: unable to read 'MD' from <%s>\n", fn);
			return KAT_DATA_ERROR;
		}
		Hash(hashbitlen, Msg, msglen, MD);
		if(memcmp(MD, exp_MD, hashbitlen / 8)){
		  printf("FAILED: test failed <%s>\n", fn);
		  return KAT_CMP_ERROR;
		}
	} while ( !done );
	printf("finished ShortMsgKAT for <%d>\n\n", hashbitlen);
	
	fclose(fp_in);
	
	return KAT_SUCCESS;
}

STATUS_CODES
testLongMsg(int hashbitlen)
{
	char		fn[32], line[SUBMITTER_INFO_LEN];
	int			msglen, msgbytelen, done;
	BitSequence	Msg[4288], MD[64], exp_MD[64];
	FILE		*fp_in;
	
	sprintf(fn, "LongMsgKAT_%d.txt", hashbitlen);
	if ( (fp_in = fopen(fn, "r")) == NULL ) {
		printf("Couldn't open <%s> for read\n", fn);
		return KAT_FILE_OPEN_ERROR;
	}
	fprintf(stdout, "# %s\n", fn);
	if ( FindMarker(fp_in, "# Algorithm Name:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(stdout, "# Algorithm Name:%s\n", line);
	}
	else {
		printf("testLongMsg: Couldn't read Algorithm Name\n");
		return KAT_HEADER_ERROR;
	}
	if ( FindMarker(fp_in, "# Principal Submitter:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(stdout, "# Principal Submitter:%s\n", line);
	}
	else {
		printf("testLongMsg: Couldn't read Principal Submitter\n");
		return KAT_HEADER_ERROR;
	}
	
	done = 0;
	do {
		if ( FindMarker(fp_in, "Len = ") )
			fscanf(fp_in, "%d", &msglen);
		else
			break;
		msgbytelen = (msglen+7)/8;

		if ( !ReadHex(fp_in, Msg, msgbytelen, "Msg = ") ) {
			printf("ERROR: unable to read 'Msg' from <%s>\n", fn);
			return KAT_DATA_ERROR;
		}
		if ( !ReadHex(fp_in, exp_MD, hashbitlen / 8, "MD = ") ) {
			printf("ERROR: unable to read 'MD' from <%s>\n", fn);
			return KAT_DATA_ERROR;
		}
		Hash(hashbitlen, Msg, msglen, MD);
		if(memcmp(MD, exp_MD, hashbitlen / 8)){
		  printf("FAILED: test failed <%s>\n", fn);
		  return KAT_CMP_ERROR;
		}
	} while ( !done );
	printf("finished LongMsgKAT for <%d>\n\n", hashbitlen);
	
	fclose(fp_in);
	
	return KAT_SUCCESS;
}

STATUS_CODES
testExtremelyLongMsg(int hashbitlen)
{
	char		fn[32], line[SUBMITTER_INFO_LEN];
	BitSequence	Text[65], MD[64], exp_MD[64];
	int			i, repeat;
	FILE		*fp_in;
	hashState	state;
	HashReturn	retval;
	
	sprintf(fn, "ExtremelyLongMsgKAT_%d.txt", hashbitlen);
	if ( (fp_in = fopen(fn, "r")) == NULL ) {
		printf("Couldn't open <%s> for read\n", fn);
		return KAT_FILE_OPEN_ERROR;
	}
	fprintf(stdout, "# %s\n", fn);
	if ( FindMarker(fp_in, "# Algorithm Name:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(stdout, "# Algorithm Name:%s\n", line);
	}
	else {
		printf("testExtremelyLongMsg: Couldn't read Algorithm Name\n");
		return KAT_HEADER_ERROR;
	}
	if ( FindMarker(fp_in, "# Principal Submitter:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(stdout, "# Principal Submitter:%s\n", line);
	}
	else {
		printf("testExtremelyLongMsg: Couldn't read Principal Submitter\n");
		return KAT_HEADER_ERROR;
	}
	
	if ( FindMarker(fp_in, "Repeat = ") )
		fscanf(fp_in, "%d", &repeat);
	else {
		printf("ERROR: unable to read 'Repeat' from <%s>\n", fn);
		return KAT_DATA_ERROR;
	}
	
	if ( FindMarker(fp_in, "Text = ") )
		fscanf(fp_in, "%s", Text);
	else {
		printf("ERROR: unable to read 'Text' from <%s>\n", fn);
		return KAT_DATA_ERROR;
	}

	if ( !ReadHex(fp_in, exp_MD, hashbitlen / 8, "MD = ") ) {
	  printf("ERROR: unable to read 'MD' from <%s>\n", fn);
	  return KAT_DATA_ERROR;
	}
	
//	memcpy(Text, "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmno", 64);
	
	if ( (retval = Init(&state, hashbitlen)) != KAT_SUCCESS ) {
		printf("Init returned <%d> in testExtremelyLongMsg\n", retval);
		return KAT_HASH_ERROR;
	}
	for ( i=0; i<repeat; i++ )
		if ( (retval = Update(&state, Text, 512)) != KAT_SUCCESS ) {
			printf("Update returned <%d> in testExtremelyLongMsg\n", retval);
			return KAT_HASH_ERROR;
		}
	if ( (retval = Final(&state, MD)) != KAT_SUCCESS ) {
		printf("Final returned <%d> in testExtremelyLongMsg\n", retval);
		return KAT_HASH_ERROR;
	}
	fprintf(stdout, "%s\n", memcmp(MD, exp_MD, hashbitlen / 8) ? "failed!!" : "succeeded.");
	printf("finished ExtremelyLongMsgKAT for <%d>\n\n", hashbitlen);
	
	fclose(fp_in);
	
	return KAT_SUCCESS;
}

STATUS_CODES
testMonteCarlo(int hashbitlen)
{
	char		fn[32], line[SUBMITTER_INFO_LEN];
	BitSequence	Seed[128], Msg[128], MD[64], Temp[128], exp_MD[64];
	int			i, j, bytelen;
	FILE		*fp_in;
	
	sprintf(fn, "MonteCarlo_%d.txt", hashbitlen);
	if ( (fp_in = fopen(fn, "r")) == NULL ) {
		printf("Couldn't open <%s> for read\n", fn);
		return KAT_FILE_OPEN_ERROR;
	}
	fprintf(fp_in, "# %s\n", fn);
	if ( FindMarker(fp_in, "# Algorithm Name:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(stdout, "# Algorithm Name:%s\n", line);
	}
	else {
		printf("testMonteCarlo: Couldn't read Algorithm Name\n");
		return KAT_HEADER_ERROR;
	}
	if ( FindMarker(fp_in, "# Principal Submitter:") ) {
		fscanf(fp_in, "%[^\n]\n", line);
		fprintf(stdout, "# Principal Submitter:%s\n", line);
	}
	else {
		printf("testMonteCarlo: Couldn't read Principal Submitter\n");
		return KAT_HEADER_ERROR;
	}
	
	if ( !ReadHex(fp_in, Seed, 128, "Seed = ") ) {
		printf("ERROR: unable to read 'Seed' from <%s>\n", fn);
		return KAT_DATA_ERROR;
	}
	
	bytelen = hashbitlen / 8;
	memcpy(Msg, Seed, 128);
	for ( j=0; j<100; j++ ) {
		for ( i=0; i<1000; i++ ) {
			Hash(hashbitlen, Msg, 1024, MD);
			memcpy(Temp, Msg, 128-bytelen);
			memcpy(Msg, MD, bytelen);
			memcpy(Msg+bytelen, Temp, 128-bytelen);
		}
		if ( !ReadHex(fp_in, exp_MD, hashbitlen / 8, "MD = ") ) {
		  printf("ERROR: unable to read 'MD' from <%s>\n", fn);
		  return KAT_DATA_ERROR;
		}

		fprintf(stdout, "j = %d: %s\n", j, memcmp(MD, exp_MD, hashbitlen / 8) ? "failed!!" : "succeeded.");
	}
	printf("finished MonteCarloKAT for <%d>\n\n", hashbitlen);

	fclose(fp_in);
	
	return KAT_SUCCESS;
}

//
// ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
//
int
FindMarker(FILE *infile, const char *marker)
{
	char	line[MAX_MARKER_LEN];
	int		i, len;

	len = (int)strlen(marker);
	if ( len > MAX_MARKER_LEN-1 )
		len = MAX_MARKER_LEN-1;

	for ( i=0; i<len; i++ )
		if ( (line[i] = fgetc(infile)) == EOF )
			return 0;
	line[len] = '\0';

	while ( 1 ) {
		if ( !strncmp(line, marker, len) )
			return 1;

		for ( i=0; i<len-1; i++ )
			line[i] = line[i+1];
		if ( (line[len-1] = fgetc(infile)) == EOF )
			return 0;
		line[len] = '\0';
	}

	// shouldn't get here
	return 0;
}

//
// ALLOW TO READ HEXADECIMAL ENTRY (KEYS, DATA, TEXT, etc.)
//
int
ReadHex(FILE *infile, BitSequence *A, int Length, char *str)
{
	int			i, ch, started;
	BitSequence	ich;

	if ( Length == 0 ) {
		A[0] = 0x00;
		return 1;
	}
	memset(A, 0x00, Length);
	started = 0;
	if ( FindMarker(infile, str) )
		while ( (ch = fgetc(infile)) != EOF ) {
			if ( !isxdigit(ch) ) {
				if ( !started ) {
					if ( ch == '\n' )
						break;
					else
						continue;
				}
				else
					break;
			}
			started = 1;
			if ( (ch >= '0') && (ch <= '9') )
				ich = ch - '0';
			else if ( (ch >= 'A') && (ch <= 'F') )
				ich = ch - 'A' + 10;
			else if ( (ch >= 'a') && (ch <= 'f') )
				ich = ch - 'a' + 10;
			
			for ( i=0; i<Length-1; i++ )
				A[i] = (A[i] << 4) | (A[i+1] >> 4);
			A[Length-1] = (A[Length-1] << 4) | ich;
		}
	else
		return 0;

	return 1;
}

