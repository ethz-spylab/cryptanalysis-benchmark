/*
	gcc -o libgen.o -c libgen.c
	gcc -o libgen libgen.o encrypt.o rng.o
	./libgen 524288
*/
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include "api.h"

void main(int argc, char **argv) {
	int size = atoi(argv[1]);
	createLibrary(size);
}

