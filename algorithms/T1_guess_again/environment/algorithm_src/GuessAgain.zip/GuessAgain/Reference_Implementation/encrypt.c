
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include "rng.h"

#define INTERVAL 255
#define H_n 2000
#define G_n 2000
#define F_n 120000
#define ITERATIONS 2000
#define libSize 524288

#define CIPHERSIZEPERBIT ITERATIONS*sizeof(short)
#define CIPHERSIZEPERBYTE 8*CIPHERSIZEPERBIT
#define BITSPERBYTE 8 

// To get much more information define LOG variable
//#define LOG 0

typedef enum { false, true } bool;

int randombytes(unsigned char *x, unsigned long long xlen);

unsigned char *libFStart;
short *libFEnd; 
unsigned char *libGStart;
short *libGEnd;

short random_walk(int startPoint, int length){
	int endPoint = startPoint;
	int step = 0;
	int rand_bytes_len = length/BITSPERBYTE;
	int padding_steps = length%BITSPERBYTE;
	int i,j;
        unsigned char *randb = (unsigned char *) malloc(rand_bytes_len + 1);
	
	randombytes(randb, rand_bytes_len + 1);
 	
	for (i=0; i < rand_bytes_len; i++ ) {
		for (j=0; j < BITSPERBYTE; j++) {
			step = ((randb[i]>>j)&0x1 == 1) ? -1 : 1;
			endPoint += step;
		}
	}

	for (j=0; j < padding_steps; j++) {
		step = ((randb[rand_bytes_len]>>j)&0x1 == 1) ? -1 : 1;	
		endPoint += step;
	}

	free(randb);
    	return endPoint;
}


/*
 *	Alice pre-computes a (L entries) private
 *	library of random walks starting at integer points a i from the interval [0, n − 1]. 
 * 	More specifically, Alice builds two (sub)libraries, with L/2 entries in each: in one sublibrary, there are
 *	random walks with f (n) steps, while in the other one there are random walks with g(n) steps.
 *	To build either sublibrary, Alice selects, uniformly at random on integers from the interval
 *	[0, n − 1], a starting point a of her random walk. She then does a random walk starting at the
 *	point a with the number of steps corresponding to the sublibrary she is building. She creates 
 *	a library of L pairs (a_i , A_i ), where a_i is the starting point of a random walk,
 *	and A_i is the end point. Half of these walks correspond to random walks with f (n) steps, the
 *	other half to random walks with g(n) steps. 
 *	Finally, Alice moves each end point A = A i either 12 left or 12 right, with probability 12 . She
 *	then moves the corresponding a i 12 in the same direction. (This is needed to avoid situations
 *	where a = b or A = B.)
*/
	// Alice's start point (a) [0.5 ,..., 255.5] -> (in the code) [0, ... ,255]
	// Alice's end point (A) [0.5 ,..., 255.5] -> (in the code) [0, ... ,255]
int createLibrary(int size) {
	FILE *file;
	file = fopen("libraryF.bin","wb"); 
	int counter = 0;
        unsigned char a = 0;
        short A = 0;
        unsigned char *randb = (unsigned char *) malloc(1);
	while (counter < size) { 
		randombytes(randb, 1);    
		a = randb[0]%(INTERVAL+1);
                fwrite(&a, sizeof(a), 1, file);
                A = random_walk(a, F_n);
                fwrite(&A, sizeof(short), 1, file);
		counter++;
	}
	fclose(file);

	file = fopen("libraryG.bin","wb"); 
	counter = 0;
        a = 0;
        A = 0;
       
	while (counter < size) {     
		randombytes(randb, 1);    
		a = randb[0]%(INTERVAL+1);
                fwrite(&a, sizeof(a), 1, file);
                A = random_walk(a, G_n);
                fwrite(&A, sizeof(short), 1, file);
		counter++;
	}


	free(randb);
	fclose(file);
}



int basicProtocol(short publicKey, bool bit, unsigned char* output) {
    	unsigned int counter = 0;
    	int total = 0;
	int cntABF = 0, cntBAF = 0, cntABG = 0, cntBAG = 0;
    	int flag = 0;
	unsigned char start = 0;
	unsigned char label = 0;
	short end = 0;
	short item = 0;    	
	int counter_m = 0;
        unsigned char *randb = (unsigned char *) malloc(4);
	bool choiceF_G;
	bool choiceA_B;



init:
	randombytes(randb, 1); 

	/*	
	*	Alice chooses, with probability 1/2 , between f(n) and g(n) steps,
	*/   
	choiceF_G = randb[0]&0x1;   


	/*	Alice selects between the two conditions: (1) A < B and (2) B < A, with
	*	probability 1/2 . 
	*/	
	choiceA_B = (randb[0]>>1)&0x1;
    
	#ifdef LOG
        printf("\n			choiceA_B %d\n", choiceA_B);
        printf("			choiceF_G %d\n", choiceF_G);
	#endif	

        counter_m = 0;
	if ((choiceA_B == true) && (choiceF_G == true)) {
		while (true) {
			/*
			* Alice selects, from her pre-computed library of random walks, among all random
			* walks satisfying the conditions she chose at Step 1 and the condition a > B, one
			* random walk uniformly at random.
			*/
			randombytes(randb, 4);
			counter =(unsigned int)(randb[0] << 24) | (randb[1] << 16) | (randb[2] << 8) | randb[3];
			counter = counter%(libSize);
			start = libFStart[counter];
			end = libFEnd[counter];
			if ((publicKey <= start)&&(end < publicKey)) {
				output[0] = start;
				
				/*	If the random walk selected by Alice has f(n)
	 			*	steps and satisfies A < B, she chooses the interval  {x < a_0} */
				output[1] = ((1-bit)<<1)|bit;		// (bit, 1 - bit)
				break;
			}

			if (++counter_m > libSize)
				goto init; 
		}

		#ifdef LOG		
		printf("			rand choice cntABF %d, start. %d, end %d\n",counter, start, end);
		#endif			
	}

	else if ((choiceA_B == true) && (choiceF_G == false)) {

		while (true) {
			/*
			* Alice selects, from her pre-computed library of random walks, among all random
			* walks satisfying the conditions she chose at Step 1 and the condition a > B, one
			* random walk uniformly at random.
			*/
			randombytes(randb, 4);
			counter =(unsigned int)(randb[0] << 24) | (randb[1] << 16) | (randb[2] << 8) | randb[3];
			counter = counter%(libSize);
			start = libGStart[counter];
			end = libGEnd[counter];
			if ((publicKey <= start)&&(end < publicKey)) {
				output[0] = start;
	 			/*	If the random walk selected by Alice has g(n) steps and satisfies A < B, she chooses
	 			*	the interval {x > a_0} */
				output[1] = (bit<<1)|(1-bit);	// (1 - bit, bit)
				break;
			}

			if (++counter_m > libSize)
				goto init; 
			
		}

		#ifdef LOG		
		printf("			rand choice cntABG %d, start. %d, end %d\n",counter, start, end);
		#endif			

	}

	else if ((choiceA_B == false) && (choiceF_G == true)) {
		while (true) {
			/*
			* Alice selects, from her pre-computed library of random walks, among all random
			* walks satisfying the conditions she chose at Step 1 and the condition a > B, one
			* random walk uniformly at random.
			*/
			randombytes(randb, 4);
			counter =(unsigned int)(randb[0] << 24) | (randb[1] << 16) | (randb[2] << 8) | randb[3];
			counter = counter%(libSize);;
			start = libFStart[counter];
			end = libFEnd[counter];
			if ((publicKey <= start)&&(end >= publicKey)) {
				output[0] = start;
	 			/*	If the random walk selected by Alice f(n) steps and satisfies A > B, she chooses the interval  {x > a_0} */
				output[1] = (bit<<1)|(1-bit);		// (1 - bit, bit)
				break;
			}

			if (++counter_m > libSize)
				goto init; 
		}

		#ifdef LOG		
		printf("			rand choice cntBAF %d, start. %d, end %d\n",counter, start, end);
		#endif			
	}


	else if ((choiceA_B == false) && (choiceF_G == false)) {
		while (true) {
			/*
			* Alice selects, from her pre-computed library of random walks, among all random
			* walks satisfying the conditions she chose at Step 1 and the condition a > B, one
			* random walk uniformly at random.
			*/
			randombytes(randb, 4);
			counter =(unsigned int)(randb[0] << 24) | (randb[1] << 16) | (randb[2] << 8) | randb[3];
			counter = counter%(libSize);
			start = libGStart[counter];
			end = libGEnd[counter];
			if ((publicKey <= start)&&(end >= publicKey)) {
				output[0] = start;
				/*	If the random walk selected by Alice g(n) steps and satisfies A > B, she chooses the interval {x < a_0} */
				output[1] = ((1-bit)<<1)|bit;		// (bit, 1 - bit)
				break;
			}

			if (++counter_m > libSize)
				goto init; 
		}

		#ifdef LOG		
		printf("			rand choice cntBAG %d, start. %d, end %d\n",counter, start, end);
		#endif			
	}


	/*	Alice assumes that Bob's decryption key b corresponding
	*	to the current point B is in the interval she selected and encrypts her bit
	*	accordingly, i.e., by labeling the selected interval with her bit
	*	c and the other interval with the bit 1-c. She then keeps the
	*	label of the interval {x < a_0}, to send it to Bob 
	*/

	#ifdef LOG
        printf("			output {%d %d}\n", output[0], output[1]);
	#endif
	free(randb);
	return 0;
}


int encryptBit (unsigned char *c, unsigned long long *clen, const bool m, const unsigned char *pk) {

	short publicKey;
	unsigned long long cBitlen = 0;
        unsigned char *output = (unsigned char *) malloc(2);
	#ifdef LOG
	printf("\n	*********Encrypt bit: %d *****************", m);
	#endif


	/*
	*	Alice sends to Bob an ordered tuple of R points a_i (in the order corresponding to the
	*	ordered tuple of R points B_i ), together with the corresponding labels of the intervals {x < a_0}
	*	It is assumed that, for each particular a 0 , if the interval {x < a_0 } is labeled
	*	by a bit c, then the interval {x > a_0 } is labeled by the bit 1 − c. Thus, the ciphertext
	*	consists of an ordered tuple of R points a_i and labeling of each interval {x < a_i } by a
	*	bit
	*/
	for (int i=0; i < ITERATIONS; i++) {
		memcpy(&publicKey, pk + i*sizeof(short), sizeof(short));
	
		#ifdef LOG
		printf("\n		%d iteration. publicKey %d - pk {%d %d}", i, publicKey, pk[2*i], pk[2*i+1]);
		#endif

		basicProtocol(publicKey, m, output);
		memcpy(c + i*sizeof(short), output, sizeof(short));
		cBitlen += sizeof(short);
	}
	memcpy(clen, &cBitlen, sizeof(unsigned long long));

	#ifdef LOG
	printf("		CipherText size: %llu bytes, array: ", cBitlen);
	for (int i=0; i < ITERATIONS; i++)
		printf(" {%d %d},  ", c[2*i], c[2*i+1]);
	#endif

	free(output);
	return 0;
}


int encryptByte (unsigned char *c, unsigned long long *clen, const unsigned char m, const unsigned char *pk) {

	unsigned long long cbitlen = 0;
	unsigned long long cbytelen = 0;

	#ifdef LOG
	printf("\n*********Encrypt byte: %d *****************", m);
	#endif

	for (int i=0; i < 8*sizeof(unsigned char); i++) {
		#ifdef LOG
		printf("\n****%d Encrypt byte iteration. bit %d\n", i, (m>>i)&1);
		#endif
	
		encryptBit(c + i*cbitlen, &cbitlen, (m>>i)&1 , pk);
		cbytelen += cbitlen;
	}
	memcpy(clen, &cbytelen, sizeof(unsigned long long));

	#ifdef LOG
	printf("CipherText size: %llu bytes, array: ", cbytelen);
	for (int i=0; i < cbytelen/2 - 1; i++)
		printf(" {%d %d},  ", c[2*i], c[2*i+1]);
	#endif

	return 0;
}



int decryptBit(bool *m, const unsigned char *c, unsigned long long clen, const unsigned char *sk) {

	unsigned char secretKey;
        unsigned char *output = (unsigned char *) malloc(2);
	int aggregator = 0;
	float result = 0;
	
	#ifdef LOG	
	printf("\n		*********Decrypt bit *****************");
	#endif
	
	/* 	
	*	Bob takes his private b_i corresponding to that B_i and recovers the bit
	*	corresponding to the label of the interval {x < a_i } or {x > a_i } where his b_i is. Having
	*	recovered R bits like that, Bob selects the bit that has been recovered more times than
	*	the other bit.
	*/	
	for (int i=0; i < ITERATIONS; i++) {
		memcpy(&secretKey, sk + i*sizeof(unsigned char), sizeof(unsigned char));
		memcpy(output, c + i*sizeof(short), sizeof(short));
		
		#ifdef LOG
		printf("\n			%d iteration. secretkey %d, ciphertext {%d %d}\n", i, secretKey, output[0], output[1]);
		#endif		

	
		
		if (output[0] > secretKey)
			aggregator += output[1]&1;
		else
			aggregator += (output[1]>>1)&1; 
	}
	result = aggregator/ (float)ITERATIONS;
	if (result > 0.5)
		*m = 1;
	else
		*m = 0;
	
	#ifdef LOG	
	printf("\n		Result %f \n", result);
	printf("		Decryted bit %d \n", m[0]);
	#endif

	free(output);
	return 0;

}

int decryptByte(unsigned char *m, const unsigned char *c, unsigned long long clen, const unsigned char *sk) {
	#ifdef LOG
	printf("\n	*********Decrypt byte *****************");
	#endif	
	
	bool mBit = 0;
	unsigned char mByte = 0;
	for (int i=0; i < 8*sizeof(unsigned char); i++) {
		#ifdef LOG
		printf("\n	****bit num. %d\n", i);
		#endif	
		
		decryptBit(&mBit, c + i*CIPHERSIZEPERBIT, CIPHERSIZEPERBIT, sk);
		mByte = mByte|(mBit<<i);
		
		#ifdef LOG		
		printf("\n	****temp byte %d, decrypted %d\n",mByte, mBit);
		#endif	
	}
	#ifdef LOG
	printf("\n	****Decrypted byte: %d\n", mByte);
	#endif	
	memcpy(m, &mByte, sizeof(unsigned char));
	return 0;
}




/*	Bob does a number of random walks with h(n) steps, starting at points b_i
*	uniformly distributed on integers from the interval [0, n], with end points
*	B i , until he gets ITERATIONS=2,000 random walks with B_i < n. The (ordered) tuple of
*	ITERATIONS=2,000 points B_i < n is Bob’s public key.
*/
int crypto_encrypt_keypair(unsigned char *pk, unsigned char *sk) {
	short end = 0;
        unsigned char start = 0;
        unsigned char *randb = (unsigned char *) malloc(1);
	for (int i=0; i < ITERATIONS; i++) {
		randombytes(randb, 1);    
		start = randb[0]%(INTERVAL+1);
		memcpy(sk + i, &start, sizeof(unsigned char));
                end = INTERVAL + 1;
                while (end >= INTERVAL)
                    end = random_walk(start, H_n);
		memcpy(pk + i*sizeof(short), &end, sizeof(short));
	}

	#ifdef LOG
	printf("Public key: \n");
	for (int i=0; i < ITERATIONS; i++) 
		printf("{%d %d}, ", pk[2*i], pk[2*i+1]);
	printf("\n Secret key: \n");
	for (int i=0; i < ITERATIONS; i++) 
		printf("%d, ", sk[i]);
	printf("\n");
	#endif	

	free(randb);
	return 0;
}
     
int crypto_encrypt(unsigned char *c, unsigned long long *clen, const unsigned char *m, unsigned long long mlen, const unsigned char *pk) {
	unsigned long long cdatalen = 0;
	unsigned long long cbytelen = 0;
	
        libFStart = (unsigned char *) malloc(2*libSize);
        libFEnd = (short *) malloc(2*libSize);
        libGStart = (unsigned char *) malloc(2*libSize);
        libGEnd = (short *) malloc(2*libSize);
	FILE *libF, *libG;
	libF = fopen("libraryF.bin","rb");
	libG = fopen("libraryG.bin","rb");

 
	for(int i = 0; i < libSize; i++) {
		fread(libFStart+i, 1, 1, libF);
		fread(libFEnd+i, 2, 1, libF);
	}

	for(int i = 0; i < libSize; i++) {
		fread(libGStart+i, 1, 1, libG);
		fread(libGEnd+i, 2, 1, libG);
	}

	#ifdef LOG
	printf("\n*********");
	printf("\n*********Encrypt data, size %llu, array", mlen);
	for (int i=0; i < mlen; i++) 
		printf("%d, ", m[i]);
	#endif

	for (int i=0; i < mlen; i++) {
		encryptByte(c + i*cbytelen, &cbytelen, m[i], pk);
		cdatalen += cbytelen;
		
		#ifdef LOG
		printf("\n****%d Encrypt data iteration, byte %d\n", i, m[i]);
		#endif
	}

	memcpy(clen, &cdatalen, sizeof(unsigned long long));

	#ifdef LOG
	printf("CipherText size: %llu bytes, array: ", cdatalen);
	for (int i=0; i < cdatalen/2 ; i++)
		printf(" {%d %d},  ", c[2*i], c[2*i+1]);
	#endif

	free(libFStart);
	free(libFEnd);
	free(libGStart);
	free(libGEnd);
	fclose(libF);
	fclose(libG);

	return 0;
}

int crypto_encrypt_open(unsigned char *m, unsigned long long *mlen, const unsigned char *c, unsigned long long clen, const unsigned char *sk) {
	#ifdef LOG	
	printf("\n\n\n*********");	
	printf("\n*********Decrypt data *****************");
	#endif	
	unsigned long long cnt = 0;
	unsigned char tmpM[2];
	for (int i=0; i < clen; i += CIPHERSIZEPERBYTE) {
		#ifdef LOG
		printf("\n****byte num. %lli\n", cnt);
		#endif	
		
		decryptByte(tmpM, c + i, CIPHERSIZEPERBYTE, sk);
		memcpy(m+cnt, tmpM, sizeof(unsigned char));

		#ifdef LOG		
		printf("\n****decrypted byte %d\n", tmpM[0]);
		#endif
		cnt++;	
	}

	memcpy(mlen, &cnt, sizeof(unsigned long long));
	return 0;
}

