/*
 * The optimized implementation uses an optimized structure of generated library of random walks.
 * This library is sorted by starting points of walks, i.e. it has the following structure:  
 * (0, F^0_n (0)), ... , (0, F^4096_n (0)), ... , (255, F^4096_n (255)).
 * Thus, the condition (publicKey <= start_point) is always true for start_point := publicKey*4096 + random_bytes() 
*/

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include "rng.h"

#define INTERVAL 255
#define H_n 2000
#define G_n 2000
#define F_n 120000
#define ITERATIONS 2000
#define size_m 4096
#define libSize size_m*(INTERVAL + 1)

#define CIPHERSIZEPERBIT ITERATIONS*sizeof(short)
#define CIPHERSIZEPERBYTE 8*CIPHERSIZEPERBIT
#define BITSPERBYTE 8 

typedef enum { false, true } bool;

int randombytes(unsigned char *x, unsigned long long xlen);

unsigned char *libFStart;
short *libFEnd; 
unsigned char *libGStart;
short *libGEnd;

short random_walk(int startPoint, int length){
	int endPoint = startPoint;
	int step = 0;
	int rand_bytes_len = length/BITSPERBYTE;
	int padding_steps = length%BITSPERBYTE;
	int i,j;
        unsigned char *randb = (unsigned char *) malloc(rand_bytes_len + 1);
	
	randombytes(randb, rand_bytes_len + 1);
 	
	for (i=0; i < rand_bytes_len; i++ ) {
		for (j=0; j < BITSPERBYTE; j++) {
			step = ((randb[i]>>j)&0x1 == 1) ? -1 : 1;
			endPoint += step;
		}
	}

	for (j=0; j < padding_steps; j++) {
		step = ((randb[rand_bytes_len]>>j)&0x1 == 1) ? -1 : 1;	
		endPoint += step;
	}

	free(randb);
    	return endPoint;
}

int createLibrary(int size) {
	FILE *file;
	file = fopen("libraryF.bin","wb"); 
	int counter = 0;
        unsigned char a = 0;
        short A = 0;
	while (counter < INTERVAL + 1) {
		for (int i = 0;i < size; i++) {
                	fwrite(&a, sizeof(a), 1, file);
                	A = random_walk(counter, F_n);
                	fwrite(&A, sizeof(short), 1, file);
		}
		a++;
		counter++;
	}
	fclose(file);

	file = fopen("libraryG.bin","wb"); 
	counter = 0;
        a = 0;
        A = 0;
       
	while (counter < INTERVAL + 1) {
		for (int i = 0;i < size; i++) {
                	fwrite(&a, sizeof(a), 1, file);
                	A = random_walk(counter, G_n);
                	fwrite(&A, sizeof(short), 1, file);
		}
		a++;
		counter++;
	}

	fclose(file);
}



int basicProtocol(short publicKey, bool bit, unsigned char* output) {
    	unsigned int counter = 0, counter_m = 0, counter_size = 0;
    	int total = 0;
	int cntABF = 0, cntBAF = 0, cntABG = 0, cntBAG = 0;
    	int flag = 0;
	unsigned char start = 0;
	unsigned char label = 0;
	short end = 0;
	short item = 0;    	
        unsigned char *randb = (unsigned char *) malloc(4);
	bool choiceF_G;
	bool choiceA_B;

init:
	randombytes(randb, 1); 
 
	choiceF_G = randb[0]&0x1;   
	choiceA_B = (randb[0]>>1)&0x1;
        counter_m = 0;
        counter_size = 0;
	if ((choiceA_B == true) && (choiceF_G == true)) {
		while (true) {
			randombytes(randb, 4);
			counter_m =(unsigned int)(randb[0] << 24) | (randb[1] << 16) | (randb[2] << 8) | randb[3];
			counter = publicKey*size_m;
			if (publicKey < 0)
				counter = 0;
			counter_m = counter_m%(libSize-counter);
			counter = counter + counter_m;
			start = libFStart[counter];
			end = libFEnd[counter];

			if (end < publicKey) {
				output[0] = start;
				output[1] = ((1-bit)<<1)|bit;		// (bit, 1 - bit)
				break;
			}
			if (++counter_size > libSize) {
				goto init;
			} 
		}		
	}

	else if ((choiceA_B == true) && (choiceF_G == false)) {

		while (true) {
			randombytes(randb, 4);
			counter_m =(unsigned int)(randb[0] << 24) | (randb[1] << 16) | (randb[2] << 8) | randb[3];
			counter = publicKey*size_m;
			if (publicKey < 0)
				counter = 0;
			counter_m = counter_m%(libSize-counter);
			counter = counter + counter_m;
			start = libGStart[counter];
			end = libGEnd[counter];
			if (end < publicKey) {
				output[0] = start;
				output[1] = (bit<<1)|(1-bit);		// (1 - bit, bit)
				break;
			}
			if (++counter_size > libSize) {
				goto init;
			}
			
		}
	}

	else if ((choiceA_B == false) && (choiceF_G == true)) {
		while (true) {
			randombytes(randb, 4);
			counter_m =(unsigned int)(randb[0] << 24) | (randb[1] << 16) | (randb[2] << 8) | randb[3];
			counter = publicKey*size_m;
			if (publicKey < 0)
				counter = 0;
			counter_m = counter_m%(libSize-counter);
			counter = counter + counter_m;
			start = libFStart[counter];
			end = libFEnd[counter];
			if (end >= publicKey) {
				output[0] = start;
				output[1] = (bit<<1)|(1-bit);		// (1 - bit, bit)
				break;
			}
			if (++counter_size > libSize) {
				goto init;
			} 
		}		
	}


	else if ((choiceA_B == false) && (choiceF_G == false)) {
		while (true) {
			randombytes(randb, 4);
			counter_m =(unsigned int)(randb[0] << 24) | (randb[1] << 16) | (randb[2] << 8) | randb[3];
			counter = publicKey*size_m;
			if (publicKey < 0)
				counter = 0;
			counter_m = counter_m%(libSize-counter);
			counter = counter + counter_m;
			start = libFStart[counter];
			end = libFEnd[counter];
	
			if ((publicKey <= start)&&(end >= publicKey)) {
				output[0] = start;
				output[1] = (bit<<1)|(1-bit);		// (1 - bit, bit)
				break;
			}
			if (++counter_size > libSize) {
				goto init;
			} 
		}	
	}

	free(randb);
	return 0;
}


int encryptBit (unsigned char *c, unsigned long long *clen, const bool m, const unsigned char *pk) {

	short publicKey;
	unsigned long long cBitlen = 0;
        unsigned char *output = (unsigned char *) malloc(2);

	for (int i=0; i < ITERATIONS; i++) {
		memcpy(&publicKey, pk + i*sizeof(short), sizeof(short));
		basicProtocol(publicKey, m, output);
		memcpy(c + i*sizeof(short), output, sizeof(short));
		cBitlen += sizeof(short);
	}
	memcpy(clen, &cBitlen, sizeof(unsigned long long));

	free(output);
	return 0;
}


int encryptByte (unsigned char *c, unsigned long long *clen, const unsigned char m, const unsigned char *pk) {
	unsigned long long cbitlen = 0;
	unsigned long long cbytelen = 0;

	for (int i=0; i < 8*sizeof(unsigned char); i++) {
		encryptBit(c + i*cbitlen, &cbitlen, (m>>i)&1 , pk);
		cbytelen += cbitlen;
	}
	memcpy(clen, &cbytelen, sizeof(unsigned long long));

	return 0;
}



int decryptBit(bool *m, const unsigned char *c, unsigned long long clen, const unsigned char *sk) {

	unsigned char secretKey;
        unsigned char *output = (unsigned char *) malloc(2);
	int aggregator = 0;
	float result = 0;
	
	for (int i=0; i < ITERATIONS; i++) {
		memcpy(&secretKey, sk + i*sizeof(unsigned char), sizeof(unsigned char));
		memcpy(output, c + i*sizeof(short), sizeof(short));
	
		if (output[0] > secretKey)
			aggregator += output[1]&1;
		else
			aggregator += (output[1]>>1)&1; 
	}
	result = aggregator/ (float)ITERATIONS;
	if (result > 0.5)
		*m = 1;
	else
		*m = 0;
	
	free(output);
	return 0;

}

int decryptByte(unsigned char *m, const unsigned char *c, unsigned long long clen, const unsigned char *sk) {
	bool mBit = 0;
	unsigned char mByte = 0;
	for (int i=0; i < 8*sizeof(unsigned char); i++) {	
		decryptBit(&mBit, c + i*CIPHERSIZEPERBIT, CIPHERSIZEPERBIT, sk);
		mByte = mByte|(mBit<<i);
		
	}
	memcpy(m, &mByte, sizeof(unsigned char));
	return 0;
}

int crypto_encrypt_keypair(unsigned char *pk, unsigned char *sk) {
	short end = 0;
        unsigned char start = 0;
        unsigned char *randb = (unsigned char *) malloc(1);
	for (int i=0; i < ITERATIONS; i++) {
		randombytes(randb, 1);    
		start = randb[0]%(INTERVAL);
		memcpy(sk + i, &start, sizeof(unsigned char));
                end = INTERVAL + 1;
                while (end >= INTERVAL)
                    end = random_walk(start, H_n);
		memcpy(pk + i*sizeof(short), &end, sizeof(short));
	}
	free(randb);
	return 0;
}
     
int crypto_encrypt(unsigned char *c, unsigned long long *clen, const unsigned char *m, unsigned long long mlen, const unsigned char *pk) {
	unsigned long long cdatalen = 0;
	unsigned long long cbytelen = 0;
	
        libFStart = (unsigned char *) malloc(2*libSize);
        libFEnd = (short *) malloc(2*libSize);
        libGStart = (unsigned char *) malloc(2*libSize);
        libGEnd = (short *) malloc(2*libSize);
	FILE *libF, *libG;
	libF = fopen("libraryF.bin","rb");
	libG = fopen("libraryG.bin","rb");

 
	for(int i = 0; i < libSize; i++) {
		fread(libFStart+i, 1, 1, libF);
		fread(libFEnd+i, 2, 1, libF);
	}

	for(int i = 0; i < libSize; i++) {
		fread(libGStart+i, 1, 1, libG);
		fread(libGEnd+i, 2, 1, libG);
	}

	for (int i=0; i < mlen; i++) {
		encryptByte(c + i*cbytelen, &cbytelen, m[i], pk);
		cdatalen += cbytelen;
	}

	memcpy(clen, &cdatalen, sizeof(unsigned long long));

	free(libFStart);
	free(libFEnd);
	free(libGStart);
	free(libGEnd);
	fclose(libF);
	fclose(libG);

	return 0;
}

int crypto_encrypt_open(unsigned char *m, unsigned long long *mlen, const unsigned char *c, unsigned long long clen, const unsigned char *sk) {
	unsigned long long cnt = 0;
	unsigned char tmpM[2];
	for (int i=0; i < clen; i += CIPHERSIZEPERBYTE) {	
		decryptByte(tmpM, c + i, CIPHERSIZEPERBYTE, sk);
		memcpy(m+cnt, tmpM, sizeof(unsigned char));

		cnt++;	
	}

	memcpy(mlen, &cnt, sizeof(unsigned long long));
	return 0;
}

