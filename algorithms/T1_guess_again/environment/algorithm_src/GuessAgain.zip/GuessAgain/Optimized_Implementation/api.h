#define CRYPTO_SECRETKEYBYTES 2000
#define CRYPTO_PUBLICKEYBYTES 4000 	// can be reduced to 2250

#define CRYPTO_BYTES 9216000 		// the size of ciphertext for 1 bit of cleartext is 36000 bits (can be reduced to 18000 bits). 
					// Because of an exponential factor for ciphertext size we use the maximum size of 32 bytes cleartext here. 

#define CRYPTO_ALGNAME "GuessAgain"
#define CRYPTO_VERSION "1.1"

int crypto_encrypt_keypair(
       unsigned char *pk,
       unsigned char *sk
     );
  
int crypto_encrypt(
       unsigned char *c,unsigned long long *clen,
       const unsigned char *m,unsigned long long mlen,
       const unsigned char *pk
     );

int crypto_encrypt_open(
       unsigned char *m,unsigned long long *mlen,
       const unsigned char *c,unsigned long long clen,
       const unsigned char *sk
     );
