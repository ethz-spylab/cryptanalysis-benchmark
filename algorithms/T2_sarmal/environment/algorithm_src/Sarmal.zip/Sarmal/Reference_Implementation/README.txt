# Algorithm Name: Sarmal
# Principal Submitter: Kerem VARICI

Reference ANSI C Implementation (Unoptimised)
-------------------------------------------------------------------------------------------------

This folder contains the following files:



File Name			Description
-------------------------------------------------------------------------------------------------

sarmal.h			NIST API header file adapted for Sarmal

sarmal_ref.c			Reference Code of Sarmal

sarmal-tables.h			Tables of Sarmal
