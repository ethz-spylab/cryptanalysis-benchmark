# Algorithm Name: Sarmal
# Principal Submitter: Kerem VARICI

32-bit Optimized ANSI C Implementation of Sarmal
-------------------------------------------------------------------------------------------------

This folder contains the following files:



File Name			Description
-------------------------------------------------------------------------------------------------

sarmal.h			NIST API header file adapted for Sarmal

sarmal_o32.c			32-bit Optimized Code of Sarmal
