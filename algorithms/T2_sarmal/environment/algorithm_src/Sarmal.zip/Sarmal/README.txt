# Algorithm Name: Sarmal
# Principal Submitter: Kerem VARICI

Optical Media of Sarmal
-------------------------------------------------------------------------------------------------

This CD-ROM contains the following folders:



Folder Name				Description
-------------------------------------------------------------------------------------------------

\KAT_MCT				This folder includes KAT, MCT and Intermediate Values of Sarmal

\Optimized_32_bit			32-bit Optimized Code of Sarmal	is included in this folder  

\Optimized_64_bit			64-bit Optimized Code of Sarmal	is included in this folder 

\Reference_Implementation		Reference Implementation of Sarmal is included in this folder 

\Supporting_Documentation		Proposal of Sarmal and a copy of Cover Sheet and Statements are included in this folder.
