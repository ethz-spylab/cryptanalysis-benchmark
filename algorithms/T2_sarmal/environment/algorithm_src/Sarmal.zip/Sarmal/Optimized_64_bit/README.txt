# Algorithm Name: Sarmal
# Principal Submitter: Kerem VARICI

64-bit Optimized ANSI C Implementation of Sarmal
-------------------------------------------------------------------------------------------------

This folder contains the following files:



File Name			Description
-------------------------------------------------------------------------------------------------

sarmal.h			NIST API header file adapted for Sarmal

sarmal_o64.c			64-bit Optimized Code of Sarmal
