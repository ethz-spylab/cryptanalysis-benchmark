# Algorithm Name: Sarmal
# Principal Submitter: Kerem VARICI

KAT_MCT Documents of Sarmal
-------------------------------------------------------------------------------------------------

This folder contains the following files:



File Name				Description
-------------------------------------------------------------------------------------------------

ExtremelyLongMsgKAT.txt			Input File for Extremely Long Message KAT Test

ExtremelyLongMsgKAT_224.txt		Extremely Long Message KAT Test Results for Sarmal-224

ExtremelyLongMsgKAT_256.txt		Extremely Long Message KAT Test Results for Sarmal-256

ExtremelyLongMsgKAT_384.txt		Extremely Long Message KAT Test Results for Sarmal-384

ExtremelyLongMsgKAT_512.txt		Extremely Long Message KAT Test Results for Sarmal-512

	
genKAT.c				Source Code to Generate KAT and MCT Results				


Intermediate_1Block.txt			Intermediate Values for a 1-block Message Digest Computation for Sarmal-224/256/384/512

Intermediate_2Block.txt			Intermediate Values for a 2-block Message Digest Computation for Sarmal-224/256/384/512


LongMsgKAT.txt				Input File for Long Message KAT Test

LongMsgKAT_224.txt			Long Message KAT Test Results for Sarmal-224

LongMsgKAT_256.txt			Long Message KAT Test Results for Sarmal-256

LongMsgKAT_384.txt			Long Message KAT Test Results for Sarmal-384

LongMsgKAT_512.txt			Long Message KAT Test Results for Sarmal-512


MonteCarlo.txt				Input File for Monte Carlo Test

MonteCarlo_224.txt			Monte Carlo Test Results for Sarmal-224

MonteCarlo_256.txt			Monte Carlo Test Results for Sarmal-256

MonteCarlo_384.txt			Monte Carlo Test Results for Sarmal-384

MonteCarlo_512.txt			Monte Carlo Test Results for Sarmal-512


README.txt				This File

sarmal.h				NIST API header file adapted for Sarmal

sarmal_ref.c				Reference Code of Sarmal

sarmal-tables.h				Tables of Sarmal


ShortMsgKAT.txt				Input File for Short Message KAT Test

ShortMsgKAT_224.txt			Short Message KAT Test Results for Sarmal-224

ShortMsgKAT_256.txt			Short Message KAT Test Results for Sarmal-256

ShortMsgKAT_384.txt			Short Message KAT Test Results for Sarmal-384

ShortMsgKAT_512.txt			Short Message KAT Test Results for Sarmal-512
