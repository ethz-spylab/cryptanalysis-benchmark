# Algorithm Name: Sarmal
# Principal Submitter: Kerem VARICI

Supporting Documentation of Sarmal
-------------------------------------------------------------------------------------------------

This folder contains the following files:



File Name			Description
-------------------------------------------------------------------------------------------------

Cover_Sheet.pdf			A Soft Copy of Cover Sheet

Sarmal.pdf			Sarmal: SHA-3 Proposal

Statements.pdf			A Soft Copy of Statements
