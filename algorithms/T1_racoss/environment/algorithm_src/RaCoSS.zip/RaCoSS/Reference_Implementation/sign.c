﻿#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "api.h"
#include "rng.h"
#include "sha3.h"

#include "sign.h"
#include "sign_tab.h"



/**
 *  Calculate a real value not less than 0 and less than 1 from two-byte hexadecimal digits.
 */
double byteTo01(
	unsigned char *r	//[IN] Two-byte hexadecimal digits
){
	unsigned int t;
	t = (((unsigned int)r[0])<<8)&0xff00
	  ^ ( (unsigned int)r[1]    )&0x00ff;
	return (double)t/65536;
}


/**
 *  Calculate SHA3-512 hash of input message with an index number prepended.
 *  No index number is prepended in the case where the index number is negative.
 */
void sha3_512(
	unsigned char *hash,	//[Out] SHA3-512 hash 
	int            index,	//[In] Index number 
	const void    *msg,		//[In] Input message
	int            msglen	//[In] Byte length of input message
){
    sha3_ctx_t sha3;

	sha3_init( &sha3, (512/8) );

	if( index >= 0 )
	{
		unsigned char ind_msg[4];
		int           ind_len;
		if( index <= 0xff )
		{
			ind_msg[0] = (unsigned char)(index&0xff);
			ind_len = 1;
		}
		else if( index <= 0xffff )
		{
			ind_msg[0] = (unsigned char)((index>> 8)&0xff);
			ind_msg[1] = (unsigned char)((index    )&0xff);
			ind_len = 2;
		}
		else if( index <= 0xffffff )
		{
			ind_msg[0] = (unsigned char)((index>>16)&0xff);
			ind_msg[1] = (unsigned char)((index>> 8)&0xff);
			ind_msg[2] = (unsigned char)((index    )&0xff);
			ind_len = 3;
		}
		else
		{
			ind_msg[0] = (unsigned char)((index>>24)&0xff);
			ind_msg[1] = (unsigned char)((index>>16)&0xff);
			ind_msg[2] = (unsigned char)((index>> 8)&0xff);
			ind_msg[3] = (unsigned char)((index    )&0xff);
			ind_len = 4;
		}
		sha3_update( &sha3, ind_msg, ind_len );
	}
	sha3_update( &sha3, msg, msglen );
    
	sha3_final( hash, &sha3 );
}

/**
 *  Find the minimum integer that is not smaller than log_2(n) for given integer n.
 */
int lg_n(
	unsigned int  n	//[In] integer 
){
	int i;
	for( i=0 ; i<32 ; i++ )
	{
		if( (((unsigned int)0x1)<<i) >= n )
		{
			return i;
		}
	}
	return 32;
}

/**
 *  Extract a bit string with "size" bits starting at "start"-th bit from a byte string "hash"
    and converts it into an integer value.
 */
int getX(
	unsigned char *hash,	//[In] Byte string
	int            start,	//[In] Start position
	int            size		//[In] Size of extracted bit string
){
	int retval;
	int i;

	retval = 0;
	for( i=0 ; i<size ; i++ )
	{
		int index = start + i;
		int val;
		val = (hash[index>>3]>>(7-index&0x7))&0x1;
		retval = (retval<<1) ^ val;
	}

	return retval;
}

/**
 *  Calculate real number rho.
 */
double getRho(
	unsigned int n,	//[In] Parameter n
	double omega,	//[In] Parameter omega
	double gamma	//[In] Parameter gamma
){
	double  rho;
	double  t;
	double  u;
	int     v;
	int loop;
	int i;

	t = 1.0 - (2.0 * omega) / n;

	loop = (int)(gamma * omega);
	u = 1;
	for( i=0 ; i<loop ; i++ )
	{
		u = u * t;
	}
	
	v = (int)(500.0 * (1.0 - u));
	
	rho = (double)v / 1000;

	return rho;
}

/**
 *  Calculate the Hamming weight of a given byte string.
 */
int wt(
	unsigned char *z,	//[In] Input byte string
	int            zlen	//[In] Length of input byte string
){
	int hw=0;
	int i;
	for( i=0 ; i<zlen ; i++ )
	{
		hw += z[i];
	}
	return hw;
}

/**
 *  Weight restricted hash function (wrhf)
 */
void wrhf(
	unsigned char  *c,		//[Out] Output 
	unsigned char  *m,		//[In] Input message
	int             mlen,	//[In] Byte length of input message
	int             w,		//[In] Hamming weight of ouput 
	unsigned int    n		//[In] Bit length of output
){
	int l;
	unsigned int  *I;
	int            Isize;
	unsigned char  x[(512/8)];
	int i;

	// l <- ceil(log_2 n)
	l = lg_n( n );
	// I <- {}
	I = (unsigned int*)malloc( sizeof(unsigned int) * w );
	Isize = 0;

	for( i=0 ; i<=(0xff+1) ; i++ )
	{
		int j;
		// s <- m  if  i=0
		// s <- 0xXX || m  if  i>0
		// x <- SHA3-512(s)
		sha3_512( x, i-1, m, mlen );
		for( j=0 ; j<(512/l) ; j++ )
		{
			unsigned int y;

			// y <- int(x_j)
			y = getX( x, j*l, l );
			if( y < n )
			{
				// I <-  I U {y}  if  y<n
				int containFlag = 0;
				int k;
				for( k=0 ; k<Isize ; k++ )
				{
					if( I[k] == y )
					{
						containFlag = 1;
						break;
					}
				}
				if( containFlag == 0 )
				{
					I[Isize] = y;
					Isize++;
				}
			}

			if( Isize == w )
			{
				// if |I| = w -> break
				break;
			}
		}

		if( Isize == w )
		{
			// if |I| = w -> break
			break;
		}
	}

	for( i=0 ; i<RACOSS_N ; i++ )
	{
		c[i] = 0;
	}
	for( i=0 ; i<Isize ; i++ )
	{
		// I_i-th bit is 1
		c[I[i]] = 1;
	}
}

/**
 *   Key Generation 
 */
int crypto_sign_keypair(
	unsigned char *pk,	//[Out] Public key 
	unsigned char *sk	//[Out] Private key
){
	unsigned char St[RACOSS_N][RACOSS_N];
	unsigned char T[RACOSS_N_K][RACOSS_N];
	int index;
	int i;
	int j;
	int l;
	unsigned char rbyte[RACOSS_N_K*(RACOSS_N/8)];

	memset( sk, 0, CRYPTO_SECRETKEYBYTES );
	memset( pk, 0, CRYPTO_PUBLICKEYBYTES );
	memset( St, 0, RACOSS_N*(RACOSS_N/8) );

	// Generate S^t
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		randombytes( rbyte, RACOSS_N*2 );
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			int r = 0;
			int f = (int)(byteTo01( rbyte + (j*2) ) * RACOSS_N);
			if( f < RACOSS_OMEGA )
			{
				r = 0x1;
			}
			St[i][j] = r;
		}
	}

	// T <- H * S^t
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			int s = 0;
			for( l=0 ; l<RACOSS_N ; l++ )
			{
				s = s ^ (RACOSS_H[i][l] * St[l][j]);
			}

			T[i][j] = s;
		}
	}

	// sk <- S^t
	index = 0;
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		unsigned char tmp = 0;
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			tmp ^= St[i][j]<<(7-j&0x7);
			if( (j&0x7) == 0x7 )
			{
				sk[index] = tmp;
				tmp = 0;
				index++;
			}
		}
	}

	// pk <- T
	index = 0;
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		unsigned char tmp = 0;
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			tmp ^= T[i][j]<<(7-j&0x7);
			if( (j&0x7) == 0x7 )
			{
				pk[index] = tmp;
				tmp = 0;
				index++;
			}
		}
	}

	return 0;
}

/**
 *  Signature Generation
 */
int crypto_sign(
	unsigned char *sm, 			//[Out] Signature
	unsigned long long *smlen,	//[Out] Byte length of Signature
	const unsigned char *m, 	//[In] Message
	unsigned long long mlen,	//[In]  Byte length of Message
	const unsigned char *sk		//[In]  Private key
){
	unsigned char  St[RACOSS_N][RACOSS_N];
	unsigned char  c[RACOSS_N];
	unsigned char  z[RACOSS_N];
	unsigned char  y[RACOSS_N];
	unsigned char  v[RACOSS_N_K];
	unsigned char *b;
	int            blen;
	unsigned char  tmp;
	unsigned char  rbyte[RACOSS_N*2];
	double rho;
	int index;
	int w;
	int i;
	int j;

	memcpy( sm, m, (size_t)mlen );

	// S^t <- sk
	index = 0;
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			St[i][j] = (sk[index/8]>>(7-(index&0x7)))&0x1;
			index++;
		}
	}

	// rho <- floor(1/2 * (1 - (1 - 2*omega / n)^(gamma*omega))*1000))/1000
	rho = getRho( RACOSS_N, RACOSS_OMEGA, RACOSS_GAMMA );

	// Generate y.
	randombytes( rbyte, RACOSS_N*2 );
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		int r = 0;
		int f = (int)(byteTo01(rbyte + (i*2)) * 1000);
		if( f < (1000*rho) )
		{
			r = 1;
		}
		y[i] = r;
	}

	// v <- H*y
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		int s = 0;
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			s = s ^ (RACOSS_H[i][j] * y[j]);
		}
		v[i] = s;
	}

	// b <- byte(v)||m||encode(H)
	blen = ((RACOSS_N_K+7)/8) + (int)mlen + ((RACOSS_N_K*RACOSS_N)/8);
	b = (unsigned char*)malloc( sizeof(unsigned char) * blen );
	index = 0;
	// byte(v)
	tmp = 0;
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		tmp ^= v[i]<<(7-i&0x7);
		if( (i&0x7) == 0x7 )
		{
			b[index] = tmp;
			tmp = 0;
			index++;
		}
	}
	if( (i&0x7) != 0 )
	{
		b[index] = tmp;
		tmp = 0;
		index++;
	}
	// m
	for( i=0 ; i<mlen ; i++ )
	{
		b[index] = m[i];
		index++;
	}
	// encode(H)
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		tmp = 0;
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			tmp ^= RACOSS_H[i][j]<<(7-j&0x7);
			if( (j&0x7) == 0x7 )
			{
				b[index] = tmp;
				tmp = 0;
				index++;
			}
		}
		if( (j&0x7) != 0 )
		{
			b[index] = tmp;
			tmp = 0;
			index++;
		}
	}

	w = (int)(RACOSS_GAMMA * RACOSS_OMEGA);
	// c <- wrhf( b, floor(gamma*omega), n );
	wrhf( c, b, blen, w, RACOSS_N );
	free( b );

	// z <- S^t * c + y
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		int s=0;
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			s = s ^ (St[i][j] * c[j]);
		}
		z[i] = s ^ y[i];
	}

	// sm <- (z,c)
	index = (int)mlen;
	tmp = 0;
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		tmp ^= z[i]<<(7-i&0x7);
		if( (i&0x7) == 0x7 )
		{
			sm[index] = tmp;
			tmp = 0;
			index++;
		}
	}
	if( (i&0x7) != 0 )
	{
		sm[index] = tmp;
		tmp = 0;
		index++;
	}
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		tmp ^= c[i]<<(7-i&0x7);
		if( (i&0x7) == 0x7 )
		{
			sm[index] = tmp;
			tmp = 0;
			index++;
		}
	}
	if( (i&0x7) != 0 )
	{
		sm[index] = tmp;
		tmp = 0;
		index++;
	}
	*smlen = mlen + (RACOSS_N/8) + (RACOSS_N/8);

	return 0;
}


/**
 * Signature Verification
 */
int crypto_sign_open(
	unsigned char *m, 			//[Out] Original message
	unsigned long long *mlen,	//[Out] Byte length of original message
	const unsigned char *sm, 	//[In] Signature
	unsigned long long smlen,	//[In] Byte length of signature
	const unsigned char *pk		//[In] Public key
){
	unsigned char T[RACOSS_N_K][RACOSS_N];
	unsigned char  c[RACOSS_N];
	unsigned char  c2[RACOSS_N];
	unsigned char  z[RACOSS_N];
	unsigned char  v1[RACOSS_N_K];
	unsigned char  v2[RACOSS_N_K];
	unsigned char  v[RACOSS_N_K];
	unsigned char *b;
	int            blen;
	double maxZ;
	int    absZ;
	unsigned char  tmp;
	double rho;
	int index;
	int w;
	int i;
	int j;

	*mlen = smlen - ((RACOSS_N/8) + (RACOSS_N/8));
	memcpy( m, sm, (size_t)(*mlen) );

	// T <- pk
	index = 0;
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			T[i][j] = (pk[index/8]>>(7-(index&0x7)))&0x1;
			index++;
		}
	}

	// (z,c) <- sm
	index = (int)(*mlen) * 8;
	tmp = 0;
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		z[i] = (sm[index/8]>>(7-(index&0x7)))&0x1;
		index++;
	}
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		c[i] = (sm[index/8]>>(7-(index&0x7)))&0x1;
		index++;
	}


	// rho <- floor(1/2 * (1 - (1 - 2*omega / n)^(gamma*omega))*1000))/1000
	rho = getRho( RACOSS_N, RACOSS_OMEGA, RACOSS_GAMMA );

	// Evaluate the Hamming weight of z.
	maxZ = (double)12 * RACOSS_N * rho * (1 - rho);
	absZ = wt( z, RACOSS_N );
	if( absZ >= maxZ )
	{
		// Signature is invalid.
		memset( m, 0, (size_t)(*mlen) );
		*mlen = 0;
		return 1;
	}

	// v_1 <- H*z
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		int s = 0;
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			s = s ^ (RACOSS_H[i][j] * z[j]);
		}
		v1[i] = s;
	}

	// v_2 <- T*c
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		int s = 0;
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			s = s ^ (T[i][j] * c[j]);
		}
		v2[i] = s;
	}

	// v <- v_1 + v_2 (= H*z + T*c)
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		v[i] = v1[i] ^ v2[i];
	}


	// b <- byte(v)||m||encode(H)
	blen = ((RACOSS_N_K+7)/8) + (int)(*mlen) + ((RACOSS_N_K*RACOSS_N)/8);
	b = (unsigned char*)malloc( sizeof(unsigned char) * blen );
	index = 0;
	// byte(v)
	tmp = 0;
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		tmp ^= v[i]<<(7-i&0x7);
		if( (i&0x7) == 0x7 )
		{
			b[index] = tmp;
			tmp = 0;
			index++;
		}
	}
	if( (i&0x7) != 0 )
	{
		b[index] = tmp;
		tmp = 0;
		index++;
	}
	// m
	for( i=0 ; i<(*mlen) ; i++ )
	{
		b[index] = m[i];
		index++;
	}
	// encode(H)
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		tmp = 0;
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			tmp ^= RACOSS_H[i][j]<<(7-j&0x7);
			if( (j&0x7) == 0x7 )
			{
				b[index] = tmp;
				tmp = 0;
				index++;
			}
		}
		if( (j&0x7) != 0 )
		{
			b[index] = tmp;
			tmp = 0;
			index++;
		}
	}

	// c <- wrhf( b, floor(gamma * omega), n )
	w = (int)(RACOSS_GAMMA * RACOSS_OMEGA);
	wrhf( c2, b, blen, w, RACOSS_N );

	// Check wethere c2 (c') = c
	for( i=0 ; i<(RACOSS_N/8) ; i++ )
	{
		if( c2[i] != c[i] )
		{
			memset( m, 0, (size_t)(*mlen) );
			*mlen = 0;
			return 1;
		}
	}

	return 0;
}

