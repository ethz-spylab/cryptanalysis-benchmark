
#ifndef __SIGN_H__
#define __SIGN_H__

#ifdef __cplusplus
extern "C" {
#endif


#include <stdlib.h>

// System parameters
#define RACOSS_N         2400
#define RACOSS_K         2060
#define RACOSS_OMEGA       48
#define RACOSS_GAMMA     0.07
#define RACOSS_RHO      0.057
#define RACOSS_W            3
#define RACOSS_LG_N        12


#define RACOSS_N_K (RACOSS_N-RACOSS_K)



#ifdef __cplusplus
};
#endif

#endif // __SIGN_H__
