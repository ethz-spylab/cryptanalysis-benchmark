
#ifndef __SIGN_H__
#define __SIGN_H__

#ifdef __cplusplus
extern "C" {
#endif


#include <stdlib.h>


typedef unsigned long long uint64;

#define RACOSS_N         2400
#define RACOSS_K         2060
#define RACOSS_OMEGA       48
#define RACOSS_GAMMA     0.07
#define RACOSS_RHO      0.057
#define RACOSS_W            3
#define RACOSS_LG_N        12

#define RACOSS_N_K (RACOSS_N-RACOSS_K)
#define RACOSS_N_U64_SIZE    ((RACOSS_N+63)/64)
#define RACOSS_N_K_U64_SIZE  ((RACOSS_N_K+63)/64)
#define RACOSS_N_K_U8_SIZE   ((RACOSS_N_K+7)/8)


#ifdef __cplusplus
};
#endif

#endif // __SIGN_H__
