﻿#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "api.h"
#include "rng.h"

#include "sha3.h"

#include "sign.h"
#include "sign_tab.h"


#define LITTLE_ENDIAN

/**
 *  Calculate SHA3-512 hash of processed input.
 */
void sha3AddIndex(
	unsigned char       *hash,
	unsigned char       *Hy,
	const unsigned char *u,
	int                  usize,
	int                  index
){
	sha3_ctx_t sha3;
	unsigned char ind_msg[4];

	// Re-calculate SHA3-512 hash.
	sha3_init( &sha3, (512/8) );
	ind_msg[0] = (unsigned char)(index&0xff);
	sha3_update( &sha3, ind_msg, 1 );
	sha3_update( &sha3, Hy, RACOSS_N_K_U8_SIZE );
	sha3_update( &sha3, u, usize );
	sha3_update( &sha3, RACOSS_H, ((RACOSS_N>>3)*RACOSS_N_K) );
	sha3_final( hash, &sha3 );
}

/*
 *  Weight Restrictedx Hash Function 
 *  We assume the Hamming weight of output is 3.
 */
void wrhf(
	unsigned char       *c,
	unsigned char       *Hy,
	const unsigned char *u,
	int                  usize
){
	unsigned char *tp;
	unsigned char  hash[(512/8)];
	unsigned int   x[4];
	unsigned int   t[2];
	sha3_ctx_t sha3;
	int  posHash = 0;
	int  xIndex = 0;
	int i;
	int j;
	int k;

	memset( c, 0, (RACOSS_N>>3) );

	// Calculate SHA3-512 hash.
	sha3_init( &sha3, (512/8) );
	sha3_update( &sha3, Hy, RACOSS_N_K_U8_SIZE );
	sha3_update( &sha3, u, usize );
	sha3_update( &sha3, RACOSS_H, ((RACOSS_N>>3)*RACOSS_N_K) );
	sha3_final( hash, &sha3 );

	for( i=0 ; i<=(0xff+1) ; i++ )
	{
		tp = hash;
		for( j=0 ; j<21 ; j++ )
		{
			t[0] = (((unsigned int)tp[0])<<4)&0xff0
			     ^ (((unsigned int)tp[1])>>4)&0x00f;
			t[1] = (((unsigned int)tp[1])<<8)&0xf00
			     ^ (((unsigned int)tp[2])   )&0x0ff;
			tp += 3;

			for( k=0 ; k<2 ; k++ )
			{
				if( t[k] < RACOSS_N )
				{
					for( i=0 ; i<xIndex ; i++ )
					{
						if( t[k] == x[i] )
						{
							break;
						}
					}
					if( i == xIndex )
					{
						x[xIndex] = t[k];
						xIndex++;
					}
				}
			}
			if( xIndex >= 3 )
			{
				break;
			}
		}
		if( xIndex >= 3 )
		{
			break;
		}
		else
		{
			sha3AddIndex( hash, Hy, u, usize, i );
		}
	}

	c[x[0]>>3] ^= 0x1<<(7-(x[0]&0x7));
	c[x[1]>>3] ^= 0x1<<(7-(x[1]&0x7));
	c[x[2]>>3] ^= 0x1<<(7-(x[2]&0x7));
}

/**
 *  Key Generation 
 */
int crypto_sign_keypair(
	unsigned char *pk, 	//[Out] Public key 
	unsigned char *sk	//[Out] Private key 
){
	uint64 *ph;
	uint64  S[RACOSS_N][RACOSS_N_U64_SIZE];
	unsigned char rbyte[RACOSS_N<<1];
	unsigned int  rint;
	uint64 val;
	int i;
	int j;
	int k;

	memset( sk, 0, CRYPTO_SECRETKEYBYTES );
	memset( pk, 0, CRYPTO_PUBLICKEYBYTES );
	memset( S, 0, sizeof(uint64)*RACOSS_N*RACOSS_N_U64_SIZE );

	// Generate S^t (Private key)
	// sk <- S^t
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		randombytes( rbyte, RACOSS_N<<1 );
		for( j=0 ; j<(RACOSS_N>>3) ; j++ )
		{
			for( k=0 ; k<8 ; k++ )
			{
				rint = (((unsigned int)rbyte[(j<<4)+(k<<1)  ])<<8)&0xff00
				     ^ ( (unsigned int)rbyte[(j<<4)+(k<<1)+1]    )&0x00ff;
				if( rint < ((double)RACOSS_OMEGA*65536)/RACOSS_N )
				{
#ifdef LITTLE_ENDIAN
					S[(j<<3)+k][i>>6] ^= ((uint64)0x1)<<( (i&0x38)+7-(i&0x7) );
#else
					S[(j<<3)+k][i>>6] ^= ((uint64)0x1)<<(63-(i&0x3f));
#endif
					sk[i*(RACOSS_N>>3)+j] ^= 0x1<<(7-k);
				}
			}
		}
	}

	// Generate T (Public key)
	// pk <- H * S^t
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		for( j=0 ; j<RACOSS_N ; j++ )
		{
			val = 0;
			ph = (uint64*)&(RACOSS_H[i*(RACOSS_N>>3)]);
			for( k=0 ; k<RACOSS_N_U64_SIZE ; k++ )
			{
				val ^= ph[k] & S[j][k];
			}
			val = ((val>>32) ^ val);
			val = ((val>>16) ^ val);
			val = ((val>>8) ^ val);
			val = ((val>>4) ^ val);
			val = ((val>>2) ^ val);
			val = ((val>>1) ^ val)&0x1;

			pk[(i*(RACOSS_N>>3))+(j>>3)] ^= val<<(7-(j&0x7));
		}
	}

	return 0;
}

/*
 * Signature Generation
 */
int crypto_sign(
	unsigned char *sm, 			//[Out] Signature
	unsigned long long *smlen,	//[Out] Byte length of Signature
	const unsigned char *m, 	//[In] Message
	unsigned long long  mlen,	//[In] Byte length of Message
	const unsigned char *sk		//[In] Private key
){
	uint64 *ph;
	uint64 *py;
	uint64 *psk;
	uint64 *pc;
	unsigned char  Hy[RACOSS_N_K_U8_SIZE];
	unsigned char  rbyte[RACOSS_N<<1];
	unsigned char *psm = sm;
	uint64 val;
	unsigned int rint;
	int i;
	int j;
	int k;

	memset( Hy, 0, sizeof(unsigned char)*RACOSS_N_K_U8_SIZE);

	memcpy( psm, m, (size_t)mlen );
	memset( psm+mlen, 0, RACOSS_N>>3 );

	// Generate y
	randombytes( rbyte, RACOSS_N<<1 );
	for( i=0 ; i<RACOSS_N>>3 ; i++ )
	{
		for( j=0 ; j<8 ; j++ )
		{
			rint = (((unsigned int)rbyte[(i<<4)+(j<<1)  ])<<8)&0xff00
			     ^ ( (unsigned int)rbyte[(i<<4)+(j<<1)+1]    )&0x00ff;
			if( rint < ((double)65536 * RACOSS_RHO) )
			{
				psm[mlen+i] ^= 0x1<<(7-j);
			}
		}
	}

	// Hy <- H*y
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		val = 0;
		ph = (uint64*)&(RACOSS_H[i*(RACOSS_N>>3)]);
		py = (uint64*)&(psm[mlen]);
		for( j=0 ; j<(RACOSS_N>>6) ; j++ )
		{
			val ^= ph[j] & py[j];
		}
		for( k=0 ; k<((RACOSS_N&0x3f)>>3) ; k++ )
		{
			val ^= (RACOSS_H[i*(RACOSS_N>>3)+j*8+k] & psm[mlen+j*8+k])&0xff;
		}
		val = ((val>>32) ^ val);
		val = ((val>>16) ^ val);
		val = ((val>>8) ^ val);
		val = ((val>>4) ^ val);
		val = ((val>>2) ^ val);
		val = ((val>>1) ^ val)&0x1;

		Hy[i>>3] ^= val<<(7-(i&0x7));
	}

	// c <- wrhf( b, floor(gamma*omega), n );
	wrhf( psm+mlen+(RACOSS_N>>3), Hy, m, (int)mlen );

	// z <- S^t * c + y
	for( i=0 ; i<RACOSS_N ; i++ )
	{
		val = 0;
		psk = (uint64*)&(sk[i*(RACOSS_N>>3)]);
		pc = (uint64*)&(psm[mlen+(RACOSS_N>>3)]);
		for( j=0 ; j<(RACOSS_N>>6) ; j++ )
		{
			val ^= psk[j] & pc[j];
		}
		for( k=0 ; k<((RACOSS_N&0x3f)>>3) ; k++ )
		{
			val ^= (sk[i*(RACOSS_N>>3)+j*8+k] & psm[mlen+(RACOSS_N>>3)+j*8+k])&0xff;
		}
		val = ((val>>32) ^ val);
		val = ((val>>16) ^ val);
		val = ((val>>8) ^ val);
		val = ((val>>4) ^ val);
		val = ((val>>2) ^ val);
		val = ((val>>1) ^ val)&0x1;

		psm[mlen+(i>>3)] ^= val<<(7-(i&0x7));
	}

	*smlen = mlen + (RACOSS_N>>3) + (RACOSS_N>>3);

	return 0;
}

/*
 * Signature Generation
 */
int crypto_sign_open(
	unsigned char *m, 			//[Out] Original message
	unsigned long long *mlen,	//[Out] Byte length of original message
	const unsigned char *sm, 	//[In] Signature
	unsigned long long smlen,	//[In] Byte length of signature
	const unsigned char *pk		//[In] Public key
){
	uint64 *pz;
	uint64 *pc;
	uint64 *pH;
	uint64 *pT;
	unsigned char HzTc[RACOSS_N_K_U8_SIZE];
	unsigned char c[RACOSS_N>>3];
	double maxZ;
	int    absZ;
	uint64 val;
	unsigned char hw;
	int i;
	int j;

	memset( HzTc, 0, sizeof(unsigned char)*RACOSS_N_K_U8_SIZE);

	*mlen = smlen - ((RACOSS_N>>3) + (RACOSS_N>>3));
	memcpy( m, sm, (size_t)(*mlen) );

	maxZ = (double)12 * RACOSS_N * RACOSS_RHO * (1 - RACOSS_RHO);
	absZ = 0;
	for( i=0 ; i<(RACOSS_N>>3) ; i++ )
	{
		hw = sm[(*mlen)+i];
		hw = (hw&0x55) + ((hw>>1)&0x55);
		hw = (hw&0x33) + ((hw>>2)&0x33);
		hw = (hw&0x0f) + ((hw>>4)&0x0f);
		absZ += hw;
	}
	if( absZ >= maxZ )
	{
		// Signature is invalid
		memset( m, 0, (size_t)(*mlen) );
		*mlen = 0;
		return 1;
	}

	// HzTc <- H*z + T*c
	pz = (uint64*)&(sm[(*mlen)]);
	pc = (uint64*)&(sm[(*mlen)+(RACOSS_N>>3)]);
	for( i=0 ; i<RACOSS_N_K ; i++ )
	{
		val = 0;
		pH = (uint64*)&(RACOSS_H[i*(RACOSS_N>>3)]);
		pT = (uint64*)&(pk[i*(RACOSS_N>>3)]);
		for( j=0 ; j<(RACOSS_N>>6) ; j++ )
		{
			val ^= (pH[j] & pz[j]) ^ (pT[j] & pc[j]);
		}
		val ^= ((pH[j] & pz[j]) ^ (pT[j] & pc[j]))&0xffffffff;
		val = ((val>>32) ^ val);
		val = ((val>>16) ^ val);
		val = ((val>>8) ^ val);
		val = ((val>>4) ^ val);
		val = ((val>>2) ^ val);
		val = ((val>>1) ^ val)&0x1;

		HzTc[i>>3] ^= val<<(7-(i&0x7));
	}
	// c <- wrhf( b, floor(gamma*omega), n );
	wrhf( c, HzTc, m, (int)(*mlen) );

	// Check c = c'
	for( i=0 ; i<(RACOSS_N>>3) ; i++ )
	{
		if( sm[*mlen+(RACOSS_N>>3)+i] != c[i] )
		{
			memset( m, 0, (size_t)(*mlen) );
			*mlen = 0;
			return 1;
		}
	}

	return 0;
}

