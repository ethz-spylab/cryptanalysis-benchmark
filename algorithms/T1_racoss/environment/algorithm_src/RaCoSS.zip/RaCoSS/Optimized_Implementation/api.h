//
//  api.h
//
//  Created by Bassham, Lawrence E (Fed) on 9/6/17.
//  Copyright © 2017 Bassham, Lawrence E (Fed). All rights reserved.
//


//   This is a sample 'api.h' for use 'sign.c'

#ifndef api_h
#define api_h

#include "sign.h"

//  Set these three values apropriately for your algorithm
#define CRYPTO_SECRETKEYBYTES (RACOSS_N * (RACOSS_N/8))
#define CRYPTO_PUBLICKEYBYTES (RACOSS_N_K * (RACOSS_N/8))
#define CRYPTO_BYTES ((RACOSS_N/8) + (RACOSS_N/8))

// Change the algorithm name
#define CRYPTO_ALGNAME "RaCoSS"

int
crypto_sign_keypair(unsigned char *pk, unsigned char *sk);

int
crypto_sign(unsigned char *sm, unsigned long long *smlen,
            const unsigned char *m, unsigned long long mlen,
            const unsigned char *sk);

int
crypto_sign_open(unsigned char *m, unsigned long long *mlen,
                 const unsigned char *sm, unsigned long long smlen,
                 const unsigned char *pk);

#endif /* api_h */
