MCSSHA-3 Optical Media maintenance

\KAT_MCT  
       Known Answer Tests and Monte Carlo Tests results for MCSSHA-3 algorithm. 
      Are executed by means of the program genKAT.exe

\Optimized_32 bit
      mcssha3.c - source code (ANSI C programming language) of the optimized implementation MCSSHA-3 algorithm for 32-bits platform
     mcssha3.h - header file for mcssha.c

\Optimized_32 bit\KAT_MCT
     source codes and results KATs and MCTs for optimized-32 implementation

\Optimized_64 bit
      mcssha3.c - source code (ANSI C programming language) of the optimized implementation MCSSHA-3 algorithm for 64-bits platform
      mcssha3.h - header file for mcssha.c

\Optimized_64 bit\KAT_MCT
     source codes and results KATs and MCTs for optimized-64 implementation

\README
      this file

\Reference Implementation
      mcssha3.c - source code (ANSI C programming language) of the reference implementation MCSSHA-3 algorithm
      mcssha3.h - header file for mcssha.c

\Reference Implementation\KAT_MCT
     source codes and results KATs and MCTs for reference implementation

\Supported Documentation
     MCSSHA-3.pdf - algorithm specifications

    
