//# Algorithm Name: MCSSHA-3
//# Principal Submitter: Mikhail Maslennikov

#ifndef HEADER_MCSSHA_H
#define HEADER_MCSSHA_H

// This is maximum hash length in bytes for 512 hash length in bits
#define MCSSHA_LBLOCK       	64

typedef unsigned char BitSequence;
typedef unsigned long long DataLength;
typedef enum { SUCCESS = 0, FAIL = 1, BAD_HASHBITLEN = 2 } HashReturn;

typedef struct MCSSHAstate_st
	{
	DataLength hashbitlen;
	BitSequence x[7];
	BitSequence data[MCSSHA_LBLOCK];
	} MCSSHA_CTX,hashState;


HashReturn Init(MCSSHA_CTX *c,int hashbitlen);
HashReturn Update(MCSSHA_CTX *c, const BitSequence *data, DataLength databitlen);
HashReturn Final(MCSSHA_CTX *c, BitSequence *md);
HashReturn Hash(int hashbitlen,
														 const BitSequence *data,
														 DataLength databitlen,
														 BitSequence *hashval);


#endif	
