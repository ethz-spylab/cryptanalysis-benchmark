/*
Implementation by the Keccak, Keyak and Ketje Teams, namely, Guido Bertoni,
Joan Daemen, Michaël Peeters, Gilles Van Assche and Ronny Van Keer, hereby
denoted as "the implementer".

For more information, feedback or questions, please refer to our websites:
http://keccak.noekeon.org/
http://keyak.noekeon.org/
http://ketje.noekeon.org/

To the extent possible under law, the implementer has waived all copyright
and related or neighboring rights to the source code in this file.
http://creativecommons.org/publicdomain/zero/1.0/
*/

#ifndef _LakeKeyak_h_
#define _LakeKeyak_h_

#include "../keccak/Keyak-common.h"

/** Length of the Lake Keyak key pack. */
#define LakeKeyak_Lk                   40

/** Maximum nonce length for Lake Keyak. */
#define LakeKeyak_MaxNoncelength       150

#ifndef KeccakP1600_excluded
    #include "../keccak/KeccakP-1600-SnP.h"
    KCP_DeclarePistonsStructure(KeyakWidth1600, KeccakP1600_stateSizeInBytes, KeccakP1600_stateAlignment)
    KCP_DeclareEngineStructure(KeyakWidth1600, KeccakP1600_stateSizeInBytes, KeccakP1600_stateAlignment)
    KCP_DeclareMotoristStructure(KeyakWidth1600, KeccakP1600_stateSizeInBytes, KeccakP1600_stateAlignment)
    KCP_DeclareMotoristFunctions(KeyakWidth1600)
    KCP_DeclareKeyakStructure(Lake, KeyakWidth1600, KeccakP1600_stateAlignment)
    KCP_DeclareKeyakFunctions(Lake)
#endif

#endif
