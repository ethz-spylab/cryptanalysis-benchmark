#include "crunch_224.c"
#include "crunch_256.c"
#include "crunch_384.c"
#include "crunch_512.c"
#include "crunch_main2.c" 


