#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/*
Compilation instructions

gcc -lm -o gen_alea gen_alea.c

This programm compute the files const32.c and const64.c
define COMP to 32 for const32.c and COMP to 64 for const64.c
*/

#define NBROUND 256  
#define K 128 

#define ENTREE 1024 
#define SORTIE 256
#define COMP 32 

#if (COMP==64)

#define NE 16
#define NS 4
#define NPM 8

#endif

#if (COMP==32)

#define NE 32
#define NS 8
#define NPM 4

#endif

#define NA 256
#define NBE 8




FILE *resultats;

 unsigned long int nbalea[2*NE*NA*16+NE-(128/NE)];


#if (COMP==64)
unsigned  long int nb_hasard(int a) {
	double f;
	unsigned  long int sortie;
        f=sin(a+1);
        if (f<0) {f=-f;}
	f=f*8;
	f=f-floor(f);
        f=f*(1UL<<32);
	sortie=((unsigned long int)floor(f))<<32;
        f=sin(a+2);
        if (f<0) {f=-f;}
	f=f*8;
	f=f-floor(f);
        f=f*(1UL<<32);
	sortie|=(unsigned long int)floor(f);
        return(sortie);
}
#endif
#if (COMP==32)
/*Constants K_i */
unsigned long int nb_hasard(int a) {
	double f;
        f=sin(a+1);
        if (f<0) {f=-f;}
	f=f*8;
	f=f-floor(f);
        f=f*(1UL<<31)*2;
        return(floor(f));
}
#endif

void init_alea() {
    int i,nor,nof,part,a,place,pos,bloc;
    unsigned long   int x;

//First we calculate the K_i constant for i<0. These constant are used by the function g_j with j>16.
//There is no need of a mask
#if (COMP==64)
    for(a=0;a<NE-2;a++) {
                x=nb_hasard(2*a);
#endif
#if (COMP==32)
    for(a=0;a<NE-4;a++) {
		x=nb_hasard(a);
#endif
		nbalea[a]=x;
	}

    for(nof=0;nof<2;nof++) { //nof= number of the bijection, 0=G, 1=G'
    	for(nor=0;nor<16;nor++) {//Only 16 functions for each bijection
            pos=nor%K;
            bloc=pos/NPM;
            place=pos%NPM;
         //Since we do not want to shift the data at the end et the rounds, we
         //calculate where we must put a mask (two bytes equal to zero)
         //This depend only of the round
            for(i=0;i<NA;i++) {//we will calculate g(i)
                for(part=0;part<NE;part++) {
#if (COMP==64)
                    x=nb_hasard(2*a);
#endif
#if (COMP==32)
                    x=nb_hasard(a);
#endif
                    if (part==bloc) {//For this word we must use a mask
                        x&=~((unsigned long int)(NA-1)<<((NPM-place-1)*NBE));
                    }
                    nbalea[a]=x;
                    a++;
                }
            }
        }
    }
}


int main()
{
   int a;

   init_alea();

#if (COMP==64)
    resultats=fopen("const_64.c","w");
    fprintf(resultats,"nbalea=[");
    for (a=0;a<2*NE*NA*16+NE-(128/NE)-1;a++) {
            if ((a-NE+4)%4==0) fprintf(resultats,"\n");
            fprintf(resultats,"%llu, ",nbalea[a]);
    }
	fprintf(resultats,"%llu ];\n",nbalea[a]);
    
#else

    resultats=fopen("const_32.c","w");
    fprintf(resultats,"nbalea=[");
    for (a=0;a<2*NE*NA*16+NE-(128/NE)-1;a++) {
            if ((a-NE+4)%8==0) fprintf(resultats,"\n");
            fprintf(resultats,"%u, ",nbalea[a]);
    }
	fprintf(resultats,"%u ];\n",nbalea[a]);
#endif
    fclose(resultats);
return 0;
}


