To compile :
make 32
or
make 64

Then run crunch_32 or crunch_64 like this :
crunch_64 file_name digest_size
crunch_32 file_name digest_size
