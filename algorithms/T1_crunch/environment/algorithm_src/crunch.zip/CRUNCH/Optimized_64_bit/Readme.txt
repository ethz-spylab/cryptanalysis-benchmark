To compile :
make

Then run crunch_64 like this :
crunch_64 file_name digest_size
