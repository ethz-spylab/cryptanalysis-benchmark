#include <stdio.h>
#include <stdlib.h>
#include "crunch.h"


int main(int argc, char *argv[])
{
	char hash[512/8];
	char *to_hash;
	int i,len,hash_len,lSize;
	FILE *Input;
	if (argc<=2) {
		printf("Syntax error: crunch <file to be hashed name> <Digest Size>\n");
	}
	else {
		Input = fopen(argv[1],"r");
		hash_len=atoi(argv[2]);

  		fseek (Input , 0 , SEEK_END);
  		lSize = ftell (Input);
  		rewind (Input);

		to_hash=(char*)malloc(lSize);
		len=lSize*8;
		fread(to_hash,lSize,1,Input);

		Hash(hash_len,to_hash,len,hash);
		for(i=0;i<hash_len/8;i++)
		{
			printf("%02x",hash[i]&0x000000ff);
		}
		printf("\n");
	}
	return 0;
}
