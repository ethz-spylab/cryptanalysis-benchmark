To compile :
make

Then run crunch_32 like this :
crunch_32 file_name digest_size
