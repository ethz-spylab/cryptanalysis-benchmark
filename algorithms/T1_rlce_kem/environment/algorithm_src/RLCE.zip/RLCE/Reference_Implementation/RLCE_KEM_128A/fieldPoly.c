/* fieldPoly.c
 * Yongge Wang 
 *
 * Code was written: November 4, 2016-
 *
 * fieldPoly.c implements polynomial arithmetics 
 * for RLCE scheme that is part of the package 
 * RLCE.tar - Random Linear Code Encryption Scheme
 *
 * Copyright (C) 2016 Yongge Wang
 * 
 * Yongge Wang
 * Department of Software and Information Systems
 * UNC Charlotte
 * Charlotte, NC 28223
 * yonwang@uncc.edu
 *
 */

#include "rlce.h"

poly_t poly_init(int n) {
  poly_t p;
  p = (poly_t) malloc(sizeof (struct polynomial));
  p->deg = -1;
  p->size = n;
  p->coeff = (field_t *) calloc(n, sizeof (field_t));
  return p;
}

void poly_clear(poly_t p) {
  memset(&(p->coeff[1+p->deg]), 0, (p->size -1-(p->deg))*sizeof(field_t));
}

void poly_zero(poly_t p) {
  p->deg = -1;
  memset(p->coeff, 0, (p->size)*sizeof(field_t));
}

void poly_copy(poly_t p, poly_t q) {
  memset(q->coeff, 0, (q->size)*sizeof(field_t));
  q->deg = p->deg;
  memcpy(q->coeff, p->coeff, (p->size) * sizeof (field_t));
}


void poly_free(poly_t p) {
  free(p->coeff);
  p->coeff=NULL;
  free(p);
  p=NULL;
}

field_t poly_eval(poly_t p, field_t a, int m) {
  /* compute the value of p(a) over GF(2^m) */
  field_t result;
  int i;
  int d = p->deg;
  if (d<0) return 0;
  if ((d==0)||(a==0)) return p->coeff[0];
  result=p->coeff[d];
  for (i=d-1; i>=0; i--) {
    if (result != field_zero()) {
      result = GF_mul(result, a, m) ^ p->coeff[i];
    } else {
      result = p->coeff[i];
    }
  }
  return result; 
}

int poly_deg(poly_t p) {
  int i;
  for (i=(p->size - 1); i>=0; i--) {
    if (p->coeff[i] != field_zero()) {
      p->deg = i;
      return i;
    }
  }
  p->deg= -1;
  return -1;
}

void poly_print(poly_t p) {
  int i;
  printf("poly size: %d, degree: %d\n", p->size, p->deg);
  for (i=0; i<=p->deg; i++) {
    printf("0x%04x ", p->coeff[i]);
  }
  printf("\n");
}

int poly_mul_standard(poly_t p, poly_t q, poly_t r, int m) {
  /* multiplication is done over field GF(2^m), r=p*q */
  int d1, d2, d, i, j;
  field_t tmp;
  d1=p->deg;
  d2=q->deg;
  d=d1+d2;
  if (d >= r->size) return POLYMULTERRR;
  poly_zero(r);
  for (i = 0; i <= d1; ++i) {
    if (p->coeff[i] !=field_zero()) {
      for (j = 0; j <= d2; ++j) {
	tmp=GF_mul(q->coeff[j], p->coeff[i], m);
	r->coeff[i+j] ^= tmp;
      }
    }
  }
  poly_deg(r);
  return 0;
}

int poly_add(poly_t p, poly_t q, poly_t r) {
  /* r=p+q */
  poly_zero(r);
  int i=1;
  int d1=p->deg;
  int d2=q->deg;
  int d=d1;
  if (d2<d) {
    d=d2;
    i=2;
  }
  GF_addvec(p->coeff,q->coeff, r->coeff, d+1);
  if (i==1) {
    memcpy(&(r->coeff[d+1]), &(q->coeff[d+1]), (d2-d)*sizeof(field_t));
  } else {
    memcpy(&(r->coeff[d+1]), &(p->coeff[d+1]), (d1-d)*sizeof(field_t));
  }
  poly_deg(r);
  return 0;
}

int poly_div(poly_t p, poly_t d, poly_t q, poly_t r, int m) {
  /* input: p, d; output: p(x)=d(x)q(x)+r(x) */
  poly_copy(p,r);
  poly_zero(q);
  int dDegree = poly_deg(d);
  int rDegree = poly_deg(r);
  int j;
  if(dDegree<0) return 0;
  field_t *tmp;
  tmp=calloc(1+dDegree, sizeof(field_t));
  field_t bb;
  j = rDegree-dDegree;
  q->deg = j>0?j:0;
  for(; j>=0; j--) {
    if (r->coeff[j+dDegree] !=0) {
      bb=GF_div(r->coeff[j+dDegree],d->coeff[dDegree],m);
      GF_mulvec(bb,d->coeff,tmp,dDegree+1,  m);
      GF_addvec(tmp, &(r->coeff[j]),NULL,1+dDegree);
      q->coeff[j] = bb;
    }
  }
  free(tmp);
  poly_deg(r);
  return 0;
}

int poly_quotient (poly_t p, poly_t d, poly_t q, int m) {
  /* input: p, d; output: p(x)=d(x)q(x) */
  poly_t r=poly_init(p->size);
  poly_deg(p);
  poly_deg(d);
  
  poly_div(p, d, q, r, m);
  if (r->deg == -1) {
    poly_free(r);
    return 0;
  } else {
    poly_free(r);
    return POLYNOTFULLDIV;
  }
}

int poly_gcd(poly_t p1, poly_t p2, poly_t gcd, int m) {
  if (poly_deg(p2) == -1) {
    poly_copy(p1, gcd);
    return 0;
  } else {
    poly_t tmpQ=poly_init(p1->size);
    poly_t tmpR=poly_init(p1->size);
    poly_div(p1, p2, tmpQ, tmpR, m);
    poly_copy(tmpR, p1);
    poly_free(tmpQ);
    poly_free(tmpR);
    poly_gcd(p2, p1, gcd, m);
  }
  return 0;
}

int find_roots_Chien (poly_t lambda, field_t lambdaRoots[], field_t eLocation[], int m) {
  /* use Chien's search to find the roots of polynomial lambda 
   * Let alpha be the generator of GF(2^m)
   * lambdaRoots[i] contains the discrete logarithm of the i-th root
   * that is, if alpha^j is the i-th root of lambda, then lambdaRoots[i]=j
   * eLocatoin contians the discrete logarithm of the inverse of the i-th root
   */
  int i, j;
  matrix_t mat=matrix_init(1+lambda->deg, fieldSize(m));
  for (j=0;j<fieldSize(m);j++) mat->data[0][j]=lambda->coeff[0];  
  for (i=1;i<mat->numR;i++) mat->data[i][0]=lambda->coeff[i];
  for (i=1;i<mat->numR;i++) {
    GF_logmulvec(i,mat->data[i], &(mat->data[i][1]), mat->numC-1, m);
    GF_addvec(mat->data[i-1], mat->data[i],NULL, fieldSize(m));
  }
  i=0;
  for (j=0;j<fieldSize(m); j++) {
    if ((mat->data[lambda->deg][j])==field_zero()) {
      lambdaRoots[i]=j;
      if (j==0) {
	eLocation[i]=0;
      } else {
	eLocation[i]=fieldSize(m)-1-j;
      }
      i++;
    }
  }
  GF_expvec(lambdaRoots,i, m);
  matrix_free(mat);
  return i;
}

int find_roots (poly_t p, field_t roots[], field_t eLocation[], int m) {
  return find_roots_Chien(p, roots, eLocation, m);
}

int poly_mul(poly_t p, poly_t q, poly_t r, int m) {
  return poly_mul_standard(p, q, r, m);
}
