/* reedsolomon.c
 * Yongge Wang 
 *
 * Code was written: November 3, 2016-
 *
 * reedsolomon.c implements Reed-Solomon encoding/decoding  
 * operations for RLCE scheme that is part of the package 
 * RLCE.tar - Random Linear Code Encryption Scheme
 *
 * Copyright (C) 2016 Yongge Wang
 * 
 * Yongge Wang
 * Department of Software and Information Systems
 * UNC Charlotte
 * Charlotte, NC 28223
 * yonwang@uncc.edu
 *
 */

#include "rlce.h"

int rs_encode (poly_t genPoly, poly_t message, poly_t code, int m) {
  int result =poly_mul(genPoly, message, code, m);  
  if (result<0) return REENCODEERROR;
  return 0;
}

void get_syndrome(poly_t code, poly_t syndrome, int m) {
  field_t alphai;
  int i;
    for (i=0; i<= syndrome->deg; i++) {
      alphai = GF_exp(i+1, m);
      syndrome->coeff[i]=poly_eval(code, alphai, m);
    }
  poly_deg(syndrome);
}

int berlekamp_massey(poly_t syndrome, poly_t C, int m) {
  /* this process implements the algorithm in: 
     Massey, J. L. (1969), "Shift-register synthesis and BCH decoding", 
     IEEE Trans. Information Theory 15(1):122–127 
  */

  /* the following code implements BM-decoding algorithm 
   * on page 57 (under Appendix C Section "10.11.3 Berlekamp-Massey decoder"
   * of RLCEspec.pdf
   */
  
  
  int codelen=syndrome->size;
  int x=1;
  int L=0;
  int b=1;
  int N=0;
  int n=syndrome->deg;
  
  poly_t B, T;
  T = poly_init(codelen);
  B = poly_init(codelen);

  /* initialize B and C to 1 */
  poly_zero(B);
  B->coeff[0]=1;
  B->deg =L;
  poly_zero(C);
  C->coeff[0]=1;
  C->deg = L;
  

  field_t d, tmp1;
  int i, j, tmplog;
  for (N=0; N<=n; N++) {
    d=0;
    for (i=0; i<= L; i++) {
      d ^= GF_mul(C->coeff[i], syndrome->coeff[N-i],m);
    }
    if (d != field_zero()) {
      tmp1 = GF_div(d, b,m);
      tmplog=GF_log(tmp1,m);
      if (N<2*L) {
	for (j=0; j<=B->deg; j++) {
	  C->coeff[x+j] ^= GF_fexp(B->coeff[j],tmplog,m);
	}
	x++;
      } else {
	poly_copy(C,T);
	for (j=0; j<=B->deg; j++) {
	  C->coeff[j+x] =(T->coeff[j+x])^(GF_fexp(B->coeff[j],tmplog,m));
	}
	L=N+1-L;
	poly_copy(T,B);
	poly_deg(B);
	b=d;
	x=1;
      }
    } else {
      x++;
    }
  }
  poly_deg(C);
  poly_free(B);
  poly_free(T);
  return L;
}


int decode(int decoder, poly_t omega, poly_t syndrome, poly_t lambda,
	   int codelen, int codedim, int m) {
  int ret;
    ret=berlekamp_massey(syndrome, lambda, m);
    poly_mul(lambda, syndrome, omega, m);
    memset(&(omega->coeff[codelen-codedim]),0,(1+omega->deg-codelen+codedim)*sizeof(field_t));
    poly_deg(omega);
    return ret;
  return 0;
}

poly_t rs_decode(int decoder, poly_t code, int codelen, int codedim, field_t eLocation[], int m) {
  int numRoots;
  field_t tmp1, tmp2;
  field_t lambdaRoots[codelen-codedim];
  memset(lambdaRoots,0, (codelen-codedim)*sizeof(field_t)); //int eLocation[n-k];
  poly_t syndrome, omega, lambda, lambdaDerivative, error, result;
  memset(eLocation, 0, (codelen-codedim)*sizeof(field_t)); 
  syndrome = poly_init(1+codelen-codedim);
  syndrome->deg=codelen-codedim-1;  
  omega = poly_init(2*(1+codelen-codedim));
  lambda =poly_init(1+codelen-codedim);
  lambdaDerivative =poly_init(1+codelen-codedim);
  get_syndrome(code, syndrome, m);
  int i;
  decode(decoder, omega, syndrome, lambda, codelen, codedim, m);
  error = poly_init(codelen);  
  lambdaDerivative->deg = lambda->deg -1;
  for (i=0; i<= (lambda->deg); i+=2) lambdaDerivative->coeff[i]=lambda->coeff[i+1];
  poly_deg(lambdaDerivative);
  numRoots= find_roots(lambda, lambdaRoots, eLocation, m);
  for (i=0; i< numRoots; i++) {
    tmp1 = poly_eval(omega, lambdaRoots[i],m);
    tmp2 = poly_eval(lambdaDerivative, lambdaRoots[i],m);
    error->coeff[eLocation[i]] = GF_div(tmp1, tmp2, m);
  }  
  poly_free(omega);
  poly_deg(error);  
  poly_free(lambdaDerivative);
  poly_free(lambda);
  result = poly_init(codelen);
  poly_add(code, error, result);
  poly_free(error);
  poly_free(syndrome);
  return result;
}


