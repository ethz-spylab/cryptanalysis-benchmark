/* GaloisField.c
 * Yongge Wang 
 *
 * Code was written: November 1, 2016-December 1, 2016
 *
 * galois.c implements the field arithmetics 
 * for RLCE scheme that is part of the package 
 * RLCE.tar - Random Linear Code Encryption Scheme
 *
 * Copright (C) 2016 Yongge Wang
 * 
 * Yongge Wang
 * Department of Software and Information Systems
 * UNC Charlotte
 * Charlotte, NC 28223
 * yonwang@uncc.edu
 *
 Primitive polynomials are used for Galois field
 For GF(2^m), we use a primitive polynomial of degree m
 List of primitive polynomials from the  paper: 
        Stahnke, Wayne. "Primitive binary polynomials." 
        Math. of Comput. 27.124 (1973): 977-980.
 A tuple (9,4,0) represents the polynomial g(x)=x^9+x^4+1
 We can also denote a polynomial using it coefficients.
 e.g., (9, 4, 0) is written as  0000 0010 0001 0001 

 (8, 6, 5, 1, 0)     or  0000 0001 0110 0011 or 0x0163 or 0435
 (9, 4, 0)           or  0000 0010 0001 0001 or 0x0211 or 01021
 (10, 3, 0)          or  0000 0100 0000 1001 or 0x0409 or 02011
 (11, 2, 0)          or  0000 1000 0000 0101 or 0x0805 or 04005
 (12, 7, 4, 3, 0)    or  0001 0000 1001 1001 or 0x1099 or 010123
 (13, 4, 3, 1, 0)    or  0010 0000 0001 1011 or 0x2129 or 020033
 (14, 12, 11, 1, 0)  or  0101 1000 0000 0011 or 0x5803 or 042103
 (15, 1, 0)          or  1000 0000 0000 0011 or 0x8003 or 0100003
 (16, 5, 3, 2, 0)    or 10000 0000 0010 1101 or 0x002D or 0210013
 for GF(2^16), the primitive polynomial should be 0x1002D
 but we will ignore the most important bit
 This implementation only includes GF(2^8), .., GF(2^16)
 for GF(2^8) we may use uint8_t as the data type
 */

#include "rlce.h"
static int poly[17] = {0,0,0,0,0,0,0,0,0x0163,0x0211,0x0409,0x0805,0x1099,0x2129,0x5803,0x8003,0x002D};  
static int fieldSize[17]={0,0,0,0,0,0,0,0,(1u<<8), (1u<<9),(1u<<10),(1u<<11),(1u<<12),(1u<<13),(1u<<14),(1u<<15),(1u<<16)};
static int fieldOrder[17]={0,0,0,0,0,0,0,0,(1u<<8)-1,(1u<<9)-1,(1u<<10)-1,(1u<<11)-1,(1u<<12)-1,(1u<<13)-1,(1u<<14)-1,(1u<<15)-1,(1u<<16)-1};

static short *GFlogTable[17]={NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};
static short *GFexpTable[17]={NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};

int GF_init_logexp_table(int m) {
  field_t j,fE=1;
  if (GFlogTable[m] != NULL) return 0;
  GFlogTable[m] = (short *) calloc(fieldSize[m], sizeof(short)); 
  if (GFlogTable[m] == NULL) return GFTABLEERR; 
  GFexpTable[m] = (short *)calloc(fieldSize[m], sizeof(short)); 
  if (GFexpTable[m] == NULL) { 
    free(GFlogTable[m]);
    GFlogTable[m] = NULL;
    return GFTABLEERR ;
  } 
  for (j=0;j<fieldSize[m];j++) GFlogTable[m][j]=fieldOrder[m];
  GFexpTable[m][0] = 1;
  GFexpTable[m][fieldOrder[m]] = 1;
  for (j = 0; j < fieldOrder[m]; j++) {
    GFlogTable[m][fE] = j; 
    GFexpTable[m][j] = fE;
    fE = fE << 1; 
    if (fE & fieldSize[m]) fE = (fE ^ poly[m]) & (fieldOrder[m]);
  }
  return 0;
}

field_t GF_add(field_t x, field_t y) {return x^y;}

int GF_addvec(field_t vec1[], field_t vec2[],field_t vec3[], int vecSize){
  int i, longsize;
  longsize = sizeof(unsigned long long);
  if (vec3==NULL) vec3=vec2;
  unsigned int size=(sizeof(field_t)*vecSize)/longsize;
  unsigned long long* longvec1=(unsigned long long*) vec1;
  unsigned long long* longvec2=(unsigned long long*) vec2;
  unsigned long long* longvec3=(unsigned long long*) vec3;
  for (i=0; i<size; i++) longvec3[i]= longvec2[i] ^ longvec1[i];
  for (i=(longsize*size)/sizeof(field_t); i<vecSize; i++) vec3[i] =vec2[i]^vec1[i];
  return 0;
}
 
field_t GF_mul(field_t x, field_t y, int m) {
  int result;
  GF_init_logexp_table(m);
  if (x == field_zero() || y == field_zero()) return 0;
  result = (GFlogTable[m][x] + GFlogTable[m][y])%fieldOrder[m];
  return GFexpTable[m][result];
}

field_t GF_fexp(field_t x, int y, int m) {
  /* returns "x * alpha^y" where alpha is the generator of GF(2^m)  */
  int result;
  GF_init_logexp_table(m);
  if (x == field_zero()) return 0;
  if (y==0) return x;
  result = (GFlogTable[m][x] + y)%fieldOrder[m];
  return GFexpTable[m][result];
}

void GF_vecinverse(field_t vec1[], field_t vec2[], int vecsize, int m) {
  /* vec2[i] = vec1[i]^-1 over GF(2^m) */
  int i;
  GF_init_logexp_table(m);
  if (vec2==NULL) vec2=vec1;
  for (i=0; i<vecsize; i++) vec2[i]=GFexpTable[m][fieldOrder[m]-GFlogTable[m][vec1[i]]];
  return;
}

void GF_mulvec(field_t x, field_t vec[], field_t dest[],int dsize, unsigned int m) {
  /* multiply each element in a range of memory by x  
   * that is, dest[i] = x* vec[i]
   */
  int i;
  if (dest==NULL) dest=vec;
  unsigned int xlog, tmp;
  GF_init_logexp_table(m);
  if (x == field_zero()) {
    memset(vec, 0, dsize*sizeof(field_t));
    return;
  }
  xlog = GFlogTable[m][x];
  for (i=0; i<dsize; i++) {
    if(vec[i]==0) {
      dest[i]=0;
    } else {
      tmp=(xlog+GFlogTable[m][vec[i]])%fieldOrder[m];
      dest[i]= GFexpTable[m][tmp];
    }
  }
  return;
}

void GF_vecdiv(field_t x, field_t vec[], field_t dest[],int dsize, unsigned int m) {
  /* dest[i]= vec[i]/x */
  int i;
  if (dest==NULL) dest=vec;
  int xlog, tmp;
  GF_init_logexp_table(m);
  if (x == field_zero()) {
    memset(vec, 0, dsize*sizeof(field_t));
    return;
  }
  xlog = GFlogTable[m][x];
  for (i=0; i<dsize; i++) {
    if(vec[i]==0) {
      dest[i]=0;
    } else {
      tmp=(fieldOrder[m]-xlog+GFlogTable[m][vec[i]])%fieldOrder[m];
      dest[i]= GFexpTable[m][tmp];
    }
  }
  return;
}

int getMatrixAandAinv(matrixA_t mat, matrixA_t matInv,
			    field_t randomElements[], int randBytes,int m) {
  /* Implement Section "7.6 Get a random matrix A" of RLCEspec.pdf
   * at same time, compute the inverse of matrixA type mat. That is, mat * matInv = I
   */
  int i, j=0,randB=0; 
  field_t a,b;
  for (i=0;i<randBytes; i++) {
    if (randomElements[i]!=0) {
      randomElements[randB]=randomElements[i];
      randB++;
    }
  } 
  GF_init_logexp_table(m);
  for (i=0; i< mat->size; i++) {
    field_t det=0;
    while (det==0) {
      a=GFexpTable[m][(GFlogTable[m][randomElements[j]]+GFlogTable[m][randomElements[j+3]])%fieldOrder[m]];     
      b=GFexpTable[m][(GFlogTable[m][randomElements[j+1]]+GFlogTable[m][randomElements[j+2]])%fieldOrder[m]]; 
      det=a^b;
      if (det==0) j++; 
      if (j+4 >randB) return NEEDNEWRANDOMSEED;
    }
    (mat->A[i])->data[0][0]= randomElements[j];
    (mat->A[i])->data[0][1]= randomElements[j+1];
    (mat->A[i])->data[1][0]= randomElements[j+2];
    (mat->A[i])->data[1][1]= randomElements[j+3];
    a=fieldOrder[m]-GFlogTable[m][det];
    (matInv->A[i])->data[0][0] = GFexpTable[m][(GFlogTable[m][randomElements[j+3]]+a)%fieldOrder[m]];
    (matInv->A[i])->data[1][0] = GFexpTable[m][(GFlogTable[m][randomElements[j+2]]+a)%fieldOrder[m]];
    j=j+4;
  }
  return 0;
};

void GF_expvec(field_t vec[], int size, int m) {
  /* vec[i] = alpha^vec[i] where alpha is the generator of GF(2^m) */
  GF_init_logexp_table(m);
  int i;
  for (i=0;i<size;i++) vec[i]=GFexpTable[m][vec[i]];
}

void GF_logmulvec(int xlog, field_t vec[], field_t dest[],int dsize, unsigned int m) {
  /*  dest[i]=vec[i]* alpha^xlog
   */
  int i;
  unsigned int  tmp;
  GF_init_logexp_table(m);
  memset(dest,0,dsize*sizeof(field_t));
  for (i=0; i<dsize; i++) {
    if(vec[i]!=0) {
      tmp=(xlog+GFlogTable[m][vec[i]])%fieldOrder[m];
      dest[i]= GFexpTable[m][tmp];
    }    
  }
  return;
}

void GF_vecvecmul(field_t v1[], field_t v2[], field_t v3[], int vsize, unsigned int m)  {
  /* v3[i] = v1[i]*v2[i] */
  int i;
  if (v3==NULL) v3=v2;
  GF_init_logexp_table(m);
  for (i=0;i<vsize;i++) {
    if ((v1[i]!=0) && (v2[i]!=0)) {
      v3[i]=GFexpTable[m][(GFlogTable[m][v1[i]]+GFlogTable[m][v2[i]])%fieldOrder[m]];
    } else v3[i]=0;
  }
}

void getGenPoly (int deg, poly_t g, int m) {
  /* g is the generator polynomial of degree deg for Reed-Solomon code*/
  int i,j;
  GF_init_logexp_table(m);
  g->deg = 0;
  g->coeff[0] = 1; 
  GF_init_logexp_table(m);
  field_t *gcoeff=calloc(g->size, sizeof(field_t));
  for (i = 1; i <= deg; i++) {
    (g->deg)++;
    memcpy(&(gcoeff[1]), g->coeff, (1+g->deg)*sizeof(field_t));
    for (j=0;j<=g->deg; j++) {
      if (g->coeff[j] !=0) {
	g->coeff[j]=GFexpTable[m][(GFlogTable[m][g->coeff[j]]+i)%(fieldOrder[m])];
      }
    }
    GF_addvec(gcoeff,g->coeff,NULL,2+g->deg);
  }
  free(gcoeff);
  return;
}

void GF_mulAinv(field_t cp[], matrixA_t A, field_t C1[], int m) {
  /* multiply the vector using matrixA-type matrix A
   * in this case, A only contains the first column for each 2*2 matrix
   * So the size of C1 is reduced half of cp. See the decoding process for RLCE
   */
  int j;
  field_t b1, b2;
  for (j=0; j<A->size; j++) {
    b1=0;
    b2=0;
    if (cp[2*j]!=0)
      b1=GFexpTable[m][(GFlogTable[m][cp[2*j]]+GFlogTable[m][(A->A[j])->data[0][0]])%(fieldOrder[m])];
    if (cp[2*j+1]!=0)
      b2=GFexpTable[m][(GFlogTable[m][cp[2*j+1]]+GFlogTable[m][(A->A[j])->data[1][0]])%(fieldOrder[m])];
    C1[j]=b1 ^ b2;
  }
  return;
}

field_t GF_div(field_t x, field_t y, int m) {
  int result;
  GF_init_logexp_table(m);
  if (y == field_zero()) return -1;
  if (x == field_zero()) return field_zero(); 
  result = (GFlogTable[m][x]+fieldOrder[m]-GFlogTable[m][y])%(fieldOrder[m]);
  return GFexpTable[m][result];
}

field_t GF_exp(int x, int m){
  GF_init_logexp_table(m);
  return GFexpTable[m][x];
}

int GF_log(field_t x, int m){
  GF_init_logexp_table(m);
  return GFlogTable[m][x];
}


