/* fieldMatrix.c
 * Yongge Wang 
 *
 * Code was written: November 10, 2016-
 *
 * fieldMatrix.c implements matrix arithmetics 
 * for RLCE scheme that is part of the package 
 * RLCE.tar - Random Linear Code Encryption Scheme
 *
 * Copyright (C) 2016 Yongge Wang
 * 
 * Yongge Wang
 * Department of Software and Information Systems
 * UNC Charlotte
 * Charlotte, NC 28223
 * yonwang@uncc.edu
 *
 */


#include "rlce.h"

matrix_t matrix_init(int row, int column) {
  /* allocate memory space for a "row * column" matrix  */
  matrix_t mat;
  int i;
  mat = (matrix_t) malloc(sizeof (struct matrix));
  mat->numR = row;
  mat->numC = column;
  mat->data = calloc(row, sizeof(int*));
  for (i=0; i<row; i++) {
    mat->data[i]= (field_t *) calloc(column, sizeof(field_t));
  }
  return mat;
}

void matrix_free(matrix_t A){
  /* release the memory spaces used by the matrix A */
  int i;
  for (i=0; i<A->numR; i++) free(A->data[i]);
  free(A->data);
  free(A);
  return;
}

int vector_copy(vector_t v, vector_t dest) {
  /* a vector structure contains the size and data. This process copy 
   * the vector v to vector dest 
   */
  dest->size = v->size;
  memcpy(dest->data, v->data, (v->size) * sizeof (field_t));
  return 0;
}

int matrix_vec_mat_mul_standard(field_t V[], int vsize, matrix_t B, field_t dest[], int dsize, unsigned int m) {
  /* V is an array of vsize field elements, B is a vsize*dsize matrix, dest is an array of dsize field elements
   *  dest = V*B
   */
  if ((vsize>B->numR)||(B->numC<dsize)) return VECMATRIXMULERROR;
  int i;
  field_t *X;
  X=calloc(dsize, sizeof(field_t));
  memset(dest, 0, dsize*sizeof(field_t));
  for (i=0; i<vsize; i++) {
    if (V[i] !=0) {
      GF_mulvec(V[i],B->data[i],X,dsize, m);
      GF_addvec(X,dest,NULL,dsize);
    }
  }
  free(X);
  return 0;
}

int matrix_standard_mul(matrix_t A, matrix_t B, matrix_t C, int m) {
  /* A and B are matrices
   * C = A*B
   */
  if ((A->numC!=B->numR)||(A->numR!=C->numR)||(B->numC!=C->numC))
    return MATRIXMULERROR;
  int i;
  for (i=0;i<C->numR;i++)
    matrix_vec_mat_mul_standard(A->data[i],A->numC,B,C->data[i],B->numC, m);
  return 0;
}

matrixA_t matrixA_init(int size) {
  /* A type A matrix (matrixA) is a 2*2 matrix
   * this initiate an array of matrixA. 
   * The array size is "size"
   */
  matrixA_t matA;
  matA = (matrixA_t) malloc(sizeof (struct matrixA));
  matA->size = size;
  matA->A = malloc(size * sizeof(int*));
  int i;
  for (i=0; i<size; i++) matA->A[i]= matrix_init(2, 2);
  return matA;
}

void matrixA_free(matrixA_t A){
  /* releace the memory held for an array A of matrixA */
  int i;
  for (i=0; i<A->size; i++) {
    matrix_free(A->A[i]);
    A->A[i]=NULL;
  }
  free(A->A);
  A->A=NULL;
  free(A);
  A=NULL;
  return;
}

int matrix_col_permutation(matrix_t A, vector_t per) {
  /* Implement Section "7.9 Matrix operations-> matrix_col_permutation" of RLCEspec.pdf
   * per should contain a permutation of 
   * 0, 1, ..., A->numC 
   * at the end, the i-th column of A is the original 
   * per[i]-th column of A
   */
  if (per->size != A->numC) return MATRIXCOLPERERROR;
  field_t tmp[A->numC];
  int i,j;
  for (i=0; i<A->numR; i++) {
    memcpy(tmp, A->data[i], (A->numC) * sizeof(field_t));
    for (j=0; j<A->numC; j++) A->data[i][j]=tmp[per->data[j]];
  }
  return 0;
}


matrix_t matrix_mul_A(matrix_t G, matrixA_t A, int startP, int m) {
  /* Implement Section "7.9 Matrix operations-> matrix_mul_A" of RLCEspec.pdf
   * multiply A starting from column "startP" of G 
   * That is:
    mat= G * A' where A' is the following matrix 
            (I is an identity matrix of dim startP):
      I 0
      0 A

   */
  if ((G->numC - startP) != (2*(A->size))) return NULL;
  matrix_t mat;
  int i,j;
  mat = matrix_init(G->numR, G->numC);
  for (i=0;i<G->numR;i++) memcpy(mat->data[i], G->data[i], startP*sizeof(field_t));
  field_t b1,b2,b3,b4;
  for (j=0; j<A->size; j++) {
    for (i=0; i<G->numR; i++) {
      b1=GF_mul(G->data[i][startP+2*j],(A->A[j])->data[0][0], m);
      b2=GF_mul(G->data[i][startP+2*j], (A->A[j])->data[0][1], m);
      b3=GF_mul(G->data[i][startP+2*j+1], (A->A[j])->data[1][0], m);
      b4=GF_mul(G->data[i][startP+2*j+1], (A->A[j])->data[1][1], m);
      mat->data[i][startP+2*j]=b1 ^ b3;
      mat->data[i][startP+2*j+1]=b2^b4;
    }
  }
  return mat;
}

int matrix_inv_standard(matrix_t G, matrix_t result, int m) {
  /* Gauss-Jordan elimination 
   *  G*result = I
   */
  int n= G->numR;
  int i,ret;
  matrix_t mat; /* mat = [G, I] */
  mat = matrix_init(n, 2*n);
  for (i=0;i<n;i++) memcpy(mat->data[i], G->data[i], n*sizeof(field_t));
  for(i=0;i<n; i++) mat->data[i][n+i]=1;
  ret=matrix_echelon(mat, m);
  for (i=0;i<n;i++) memcpy(result->data[i], &(mat->data[i][n]), n*sizeof(field_t));
  matrix_free(mat);
  return ret;
}

int matrix_echelon(matrix_t G, int m) {
  /* Gauss-Jordan elimination 
   * compute the echelon form of G. return the dimension of G
   */
  int n= G->numR;
  if (G->numC <n) n=G->numC;
  int temp, i, j,k;
  field_t *tmp;
  field_t c;
  field_t *tmprow=calloc(G->numC, sizeof(field_t)); 
  for(j=0; j<n; j++) { /* converting first half to I */
    if (G->data[j][j] == 0) {
      temp=j;
      while  ((temp<G->numR) && (G->data[temp][j] == 0)) temp ++;
      if (temp == n) {
	free(tmprow);
	return -j;
      }
      tmp=G->data[j];
      G->data[j] = G->data[temp];
      G->data[temp]= tmp;
    }
    GF_vecdiv(G->data[j][j], &(G->data[j][j]), NULL,G->numC-j,m);
    for(i=0; i<n; i++) {
      if (i !=j) {
	c = G->data[i][j];
	if (c!=field_zero()){
	  for (k=j;k<G->numC;k++) G->data[i][k]^=GF_mul(G->data[j][k],c,m);
	}
      }
    }
  }
  free(tmprow);
  return n;
}

matrix_t matrix_join(matrix_t G, matrix_t R) {
  /* Implement Section "7.9 Matrix operations-> matrix_join " of RLCEspec.pdf
   * G is k*n matrix and G=(g_1, g_2, ..., g_n)
   * R is k*w matrix and R=(r_1, r_2, ..., r_w)
   * result = (g_1, ..., g_{n-w}, r_1, ..., g_n, r_w)
   */
  if ((G->numR != R->numR)||(G->numC < R->numC)) {
    return NULL;
  }
  matrix_t result;
  int i,j;
  result = matrix_init(G->numR, G->numC + R->numC);

  int d= G->numC - R->numC;
  for (i=0; i< G->numR; i++) {
    memcpy(result->data[i], G->data[i], d * sizeof(field_t));
  }
  for (i=0; i< G->numR; i++) {
    for (j=0; j<R->numC; j++) {
      result->data[i][d+2*j] = G->data[i][d+j];
      result->data[i][d+2*j+1]= R->data[i][j];
    }
  }
  return result;
}

vector_t vec_init(int n) {
  /* allocate memory for an array of field elements, the array size is n */
  vector_t v;
  v = (vector_t) malloc(sizeof (struct vector));
  v->size = n;
  v->data = (field_t *) calloc(n, sizeof (field_t));
  return v;
}

void vector_free(vector_t v) {
  free(v->data);
  v->data=NULL;
  free(v);
  v=NULL;
}

vector_t permu_inv(vector_t p) {
  /* compute the inverse of the permutation p 
   *
   * Implement Section "7.8 Get a permutation and a permutation inverse" of RLCEspec.pdf
   */
  int i;
  vector_t result;
  result = vec_init(p->size);
  for (i=0; i<p->size; i++) {
    result->data[p->data[i]]=i;
  }
  return result;
}

int getRandomMatrix(matrix_t mat, field_t randE[]) {
  /* use the field element in randE to fill a matrix mat 
   *
   *  Implement Section "7.7 Get a random matrix" of RLCEspec.pdf 
   */
  int i,j;
  for (j=0; j<mat->numC; j++) {
    for (i=0; i<mat->numR; i++) {
      mat->data[i][j]= randE[j*(mat->numR)+i];
    }
  }
  return 0;
}

vector_t getPermutation(int persize, int t, unsigned char randBytes[], int nRB) {
  /* this implements Fisher–Yates shuffle 
   * in Knuth "Algorithm P" of The Art of Computer Programming 
   * the randomness is from randBytes.
   * 
   * Implement Section "7.8 Get a permutation and a permutation inverse" of RLCEspec.pdf
   *
   * if t=persize, return a permutation of 0,...,persize-1. otherwise
   * return the first t elements of the permutation*/
  vector_t permutation = vec_init(persize);
  int i;
  for (i=0; i<persize; i++) permutation->data[i]=i;

  unsigned short randomShortIntegers[t];
  int ret=getShortIntegers(randBytes, nRB, randomShortIntegers,t);
  if (ret <0) return NULL;
  
  unsigned short swapi;
  field_t tmp;
  for (i=0; i<t; i++) {
    swapi = randomShortIntegers[i] % (persize -i);
    swapi += i;
    tmp = permutation->data[i];
    permutation->data[i]=permutation->data[swapi];
    permutation->data[swapi]=tmp;    
  }
  return permutation;  
}

int randomBytes2FE(unsigned char randomBytes[], int nRB,
		   field_t output[], int outputSize, int m) {
  /* Implement B2FE(BYTES,m) in Section "7.10 Byte array and field element array conversions" of RLCEspec.pdf
   *
   * let randomBytes = r_1r_2...r_{nRB}
   * converts randomBytes to elements of GF(2^m)
   * the first m-elements from randomBytes will be 
   * output[0], the second m-element will bbe output[1] and so on.
   */
  vector_t Vec;
  Vec =vec_init(outputSize);
  int ret = 0;
  switch (m) {
  case 10:
    ret=B2FE10(randomBytes,nRB, Vec);
    if (ret<0) return ret;
    break;
  case 11:
    ret=B2FE11(randomBytes,nRB, Vec);
    if (ret<0) return ret;
    break;
  default:
    return B2FEORFE2BNOTDEFINED;
  }
  memcpy(output, Vec->data, outputSize *sizeof(field_t));
  vector_free(Vec);
  return 0; 	 
}

int getShortIntegers(unsigned char randB[], int nRB,unsigned short output[], int outputSize) {
  /* Implement Section "7.2 Get short integers" of RLCEspec.pdf
   *
   * Let randB=r_1...r_{nRB}
   * the first two bytes of randB will be output[0], 
   * the second two bytes of randB will be output[1], and so on.
   */
  int i;
  for (i=0; i<outputSize; i++) {
    output[i]=randB[2*i];
    output[i]= (output[i]<<8);
    output[i]= output[i] | randB[2*i+1];
  }
  return 0; 	 
}

int getRandomBytes(unsigned char seed[], int seedSize,
		   unsigned char pers[], int persSize,
		   unsigned char output[], int outputlen,int cryptotype) {
  /* this will use seed and pers to generate random bytes.
   * if cryptotype = 0, use NIST DRBG_Hash based on SHA1
   * if cryptotype = 1, use NIST DRBG_Hash based on SHA-256
   * if cryptotype = 2, use NIST DRBG_Hash based on SHA=512
   * if cryptotype = 128, use NIST CTR_DRBG based on AES-128
   * if cryptotype = 192, use NIST CTR_DRBG based on AES-192
   * if cryptotype = 256, use NIST CTR_DRBG based on AES-256
   */
  int ret=0;
  if (cryptotype <3) {
    hash_drbg_state_t drbgState;
    drbgState=drbgstate_init(cryptotype);
    unsigned char nonce[8]={0xff, 0xf1, 0xc6, 0x64, 0x5f, 0x19, 0x23, 0x1f};
    unsigned char add[1];
    drbg_Input_t drbgInput;  
    drbgInput=drbgInput_init(seed,seedSize,nonce, 8, pers,persSize,add, 0);
    ret= hash_DRBG(drbgState, drbgInput, output, outputlen);
    free_drbg_state(drbgState);
    free_drbg_input(drbgInput);
  } else {
    ctr_drbg_state_t drbgState;
    drbgState=ctr_drbgstate_init(cryptotype);
    unsigned char nonce[1];
    unsigned char add[1];
    drbg_Input_t drbgInput;
    unsigned char newseed[drbgState->seedlen];
    memset(newseed, 0, drbgState->seedlen);
    int seedlen = seedSize;
    if (seedlen > drbgState->seedlen) seedlen = drbgState->seedlen;
    memcpy(newseed, seed, seedlen);
    drbgInput=drbgInput_init(seed,seedlen,nonce, 0, pers,persSize,add, 0);
    ret= ctr_DRBG(drbgState, drbgInput, output, outputlen);
    free_ctr_drbg_state(drbgState);
    free_drbg_input(drbgInput);
  } 
  return ret;  
}

void I2BS (unsigned int X, unsigned char S[], int slen) {
  /* Integer-to-Byte-String (I2BS) conversion from NIST SP800- 56 r1 Appendix B.
   * see also  Section "7.3 I2BS and BS2I" of RLCEspec.pdf
   */
  int i;
  for (i=slen-1; i>=0; i--) S[i]=(0xFF & (X>>((slen-1-i)*8)));
}

int BS2I (unsigned char S[], int slen) {
  /* Byte-String-to-Integer (BS2I) conversion from NIST SP800- 56 r1 Appendix B. 
   * see also  Section "7.3 I2BS and BS2I" of RLCEspec.pdf
   */
  unsigned int i, X=0;
  for (i=0; i<slen; i++) X=(X<<8)^S[i];
  return X;
}

int RLCE_MGF512(unsigned char mgfseed[], int mgfseedLen,
	     unsigned char mask[], int maskLen) {
  /* Mask Generation Function (MGF) from NIST SP800-56 r1 Section 7.2.2.2. based on SHA512
   * see also  Section "7.4 The Mask Generation Function (MGF)" of RLCEspec.pdf
   */
  unsigned char seed[mgfseedLen+4];  
  memcpy(seed, mgfseed, mgfseedLen);
  int i,j,m,r;
  unsigned long hash512[8];
  m=maskLen/64;
  r=maskLen%64;
  for (i=0; i<m;i++){
    for (j=3; j>=0; j--) seed[mgfseedLen+j]=(0xFF & (i>> ((3-j)*8)));
    sha512_md(seed, mgfseedLen+4, hash512);
    for (j=0;j<64;j++) mask[i*64+j]=(hash512[j/8]>>(56-(j%8)*8))&0xFF;
  }  
  if (r>0) {
    for (j=3; j>=0; j--) seed[mgfseedLen+j]=(0xFF & (m>>((3-j)*8)));
    sha512_md(seed, mgfseedLen+4, hash512);
    for (j=0;j<r;j++) mask[m*64+j]=(hash512[j/8]>>(56-(j%8)*8))&0xFF;
  }
  return 0;  
}

int RLCE_MGF(unsigned char mgfseed[], int mgfseedLen,
	     unsigned char mask[], int maskLen, int shatype) {
  /* Mask Generation Function (MGF) from NIST SP800-56 r1 Section 7.2.2.2. 
   * see also  Section "7.4 The Mask Generation Function (MGF)" of RLCEspec.pdf
   */
  unsigned char seed[mgfseedLen+4];  
  memcpy(seed, mgfseed, mgfseedLen);
  int hashSize=0; /* hashLen = 4*hashSize */
  void (*sha)(unsigned char[], int, unsigned int[]);

  if (shatype ==0) {
    hashSize = 5;
    sha = sha1_md;
  } else if (shatype == 1) {
    hashSize = 8;
    sha = sha256_md;
  } else if (shatype == 2) {
    hashSize = 8;
  } else {
    return SHATYPENOTSUPPORTED;
  }
  unsigned int hash[hashSize];
  int i,j, m,r;
  if  ((shatype==0) || (shatype==1)) {
    m=maskLen/(4*hashSize);
    r=maskLen%(4*hashSize);
    for (i=0; i<m;i++){
      for (j=3; j>=0; j--) seed[mgfseedLen+j]=(0xFF & i>>((3-j)*8));
      (*sha)(seed, mgfseedLen+4, hash);
      for (j=0;j<(4*hashSize);j++) mask[i*(4*hashSize)+j]=(hash[i/4]>>(24-(i%4)*8)) & 0xFF;
    }
    if (r>0) {
      for (j=3; j>=0; j--) seed[mgfseedLen+j]=(0xFF & m>>((3-j)*8));
      (*sha)(seed, mgfseedLen+4, hash);
      for (j=0;j<r;j++) mask[m*(4*hashSize)+j]=(hash[i/4]>>(24-(i%4)*8)) & 0xFF; 
    }
  } else if (shatype ==2 ) {
    unsigned long hash512[8];
    m=maskLen/64;
    r=maskLen%64;
    for (i=0; i<m;i++){
      for (j=3; j>=0; j--) seed[mgfseedLen+j]=(0xFF & i>> ((3-j)*8));
      sha512_md(seed, mgfseedLen+4, hash512);
      for (j=0;j<64;j++) mask[i*64+j]=(hash512[j/8]>>(56-(j%8)*8))&0xFF;
    }
    if (r>0) {
      for (j=3; j>=0; j--) seed[mgfseedLen+j]=(0xFF & m>> ((3-j)*8));
      sha512_md(seed, mgfseedLen+4, hash512);
      for (j=0;j<r;j++) mask[m*64+j]=(hash512[j/8]>>(56-(j%8)*8))&0xFF;
    }
  }
  return 0;  
}



int B2FE10 (unsigned char bytes[], unsigned int BLen, vector_t FE) {
  int vecLen =FE->size;  
  if (10*vecLen>8*BLen) {
    return BYTEVECTORTOOSMALL;
  }
  int j=0;
  int i;
  int used = 0;

  unsigned char bits = 0x00;
  for (i=0; i<vecLen; i++) {

    switch (used) {
    case 0:
      FE->data[i]=bytes[j];
      FE->data[i]=FE->data[i]<<2;
      j++;
      bits = (bytes[j] & 0xC0);
      bits = bits >>6;
      FE->data[i]=(FE->data[i]) | bits;
      used = 2;
      break;
    case 2:
      FE->data[i]= (bytes[j]<< 2) & 0x00FF;
      FE->data[i]=FE->data[i]<<2;
      j++;
      bits = (bytes[j] & 0xF0);
      bits = bits >>4;
      FE->data[i]=(FE->data[i]) | bits;
      used = 4;
      break;
    case 4:
      FE->data[i]= (bytes[j]<< 4) & 0x00FF;
      FE->data[i]=FE->data[i]<<2;
      j++;
      bits = (bytes[j] & 0xFC);
      bits = bits >>2;
      FE->data[i]=(FE->data[i]) | bits;
      used = 6;
      break;
    case 6:
      FE->data[i]= (bytes[j]<< 6) & 0x00FF;
      FE->data[i]=FE->data[i]<<2;
      j++;
      bits = (bytes[j] & 0xFF);
      FE->data[i]=(FE->data[i]) | bits;
      j++;
      used = 0;
      break;
    default:
      return -1;
    }
  }
  return 0;
}

int FE2B10 (vector_t FE, unsigned char bytes[], unsigned int BLen) {
  int vecLen =FE->size;
  if ((8*BLen) < (vecLen *10)) {
    return BYTEVECTORTOOSMALL;
  }
  int used = 0;
  int j=0;
  int i;
  bytes[j]=0x00;
  unsigned char bits = 0x00;

  for (i=0;i<vecLen;i++){
    switch (used) {
    case 0:
      bytes[j]=(FE->data[i])>>2;
      j++;
      bits = FE->data[i] & 0x0003;
      bytes[j]= bits <<6;
      used = 2;
      break;
    case 2:
      bytes[j]=(((FE->data[i])>>4) | bytes[j]);
      j++;
      bits = FE->data[i] & 0x000F;
      bytes[j]= bits<<4;
      used = 4;      
      break;
    case 4:
      bytes[j]=(((FE->data[i])>>6) | bytes[j]);
      j++;
      bits = FE->data[i] & 0x003F;
      bytes[j]= bits<<2;
      used = 6;      
      break;
    case 6:
      bytes[j]=(((FE->data[i])>>8) | bytes[j]);
      j++;
      bits = FE->data[i] & 0x00FF;
      bytes[j]= bits;
      used = 0;
      j++;
      break;      
    default:
      return -1;
    }
  }
  return 0;  
}




int B2FE11 (unsigned char bytes[], unsigned int BLen, vector_t FE) {
  int vecLen =FE->size;  
  if (11*vecLen>8*BLen) {
    return BYTEVECTORTOOSMALL;
  }
  int j=0;
  int i;
  int used = 0;

  unsigned char bits = 0x00;
  for (i=0; i<vecLen; i++) {

    switch (used) {
    case 0:
      FE->data[i]=bytes[j];
      FE->data[i]=FE->data[i]<<3;
      j++;
      bits = (bytes[j] & 0xE0);
      bits = bits >>5;
      FE->data[i]=(FE->data[i]) | bits;
      used = 3;
      break;
    case 3:
      FE->data[i]= (bytes[j]<< 3) & 0x00FF;
      FE->data[i]=FE->data[i]<<3;
      j++;
      bits = (bytes[j] & 0xFC);
      bits = bits >>2;
      FE->data[i]=(FE->data[i]) | bits;
      used = 6;
      break;
    case 6:
      FE->data[i]= (bytes[j]<< 6) & 0x00FF;
      FE->data[i]=FE->data[i]<<2;
      j++;
      bits = (bytes[j] & 0xFF);
      FE->data[i]=(FE->data[i]) | bits;
      FE->data[i]=FE->data[i]<<1;
      j++;
      bits = (bytes[j] & 0x80);
      bits = bits >>7;
      FE->data[i]=(FE->data[i]) | bits;     
      used = 1;
      break;
    case 1:
      FE->data[i]= (bytes[j]<< 1) & 0x00FF;
      FE->data[i]=FE->data[i]<<3;
      j++;
      bits = (bytes[j] & 0xF0);
      bits = bits >>4;
      FE->data[i]=(FE->data[i]) | bits;
      used = 4;
      break;
    case 4:
      FE->data[i]= (bytes[j]<< 4) & 0x00FF;
      FE->data[i]=FE->data[i]<<3;
      j++;
      bits = (bytes[j] & 0xFE);
      bits = bits >>1;
      FE->data[i]=(FE->data[i]) | bits;
      used = 7;
      break;
    case 7:
      FE->data[i]= (bytes[j]<< 7) & 0x00FF;
      FE->data[i]=FE->data[i]<<1;
      j++;
      bits = (bytes[j] & 0xFF);
      FE->data[i]=(FE->data[i]) | bits;
      FE->data[i]=FE->data[i]<<2;
      j++;
      bits = (bytes[j] & 0xC0);
      bits = bits >>6;      
      FE->data[i]=(FE->data[i]) | bits;
      used = 2;
      break;
    case 2:
      FE->data[i]= (bytes[j]<< 2) & 0x00FF;
      FE->data[i]=FE->data[i]<<3;
      j++;
      bits = (bytes[j] & 0xF8);
      bits = bits >>3;
      FE->data[i]=(FE->data[i]) | bits;
      used = 5;
      break;      
    case 5:
      FE->data[i]= (bytes[j]<< 5) & 0x00FF;
      FE->data[i]=FE->data[i]<<3;
      j++;
      bits = (bytes[j] & 0xFF);
      FE->data[i]=(FE->data[i]) | bits;
      j++;
      used = 0;
      break;
    default:
      return -1;
    }
  }
  return 0;
}

int FE2B11 (vector_t FE, unsigned char bytes[], unsigned int BLen) {
  int vecLen =FE->size;
  if ((8*BLen) < (vecLen *11)) {
    return BYTEVECTORTOOSMALL;
  }
  int used = 0;
  int j=0;
  int i;
  bytes[j]=0x00;
  unsigned char bits = 0x00;

  for (i=0;i<vecLen;i++){
    switch (used) {
    case 0:
      bytes[j]=(FE->data[i])>>3;
      j++;
      bits = FE->data[i] & 0x0007;
      bytes[j]= bits <<5;
      used = 3;
      break;
    case 3:
      bytes[j]=(((FE->data[i])>>6) | bytes[j]);
      j++;
      bits = FE->data[i] & 0x003F;
      bytes[j]= bits<<2;
      used = 6;      
      break;
    case 6:
      bytes[j]=(((FE->data[i])>>9) | bytes[j]);
      j++;
      bytes[j] = (FE->data[i]>>1) & 0x00FF;
      j++;
      bits = FE->data[i] & 0x0001;
      bytes[j]= bits<<7;
      used = 1;      
      break;
    case 1:
      bytes[j]=(((FE->data[i])>>4) | bytes[j]);
      j++;
      bits = FE->data[i] & 0x000F;
      bytes[j]= bits<<4;
      used = 4;
      break;
    case 4:
      bytes[j]=(((FE->data[i])>>7) | bytes[j]);
      j++;
      bits = FE->data[i] & 0x007F;
      bytes[j]= bits<<1;
      used = 7;
      break;
    case 7:
      bytes[j]=(((FE->data[i])>>10) | bytes[j]);
      j++;
      bytes[j] = (FE->data[i]>>2) & 0x00FF;
      j++;
      bits = FE->data[i] & 0x0003;
      bytes[j]= bits<<6;
      used = 2;      
      break;
    case 2:
      bytes[j]=(((FE->data[i])>>5) | bytes[j]);
      j++;
      bits = FE->data[i] & 0x001F;
      bytes[j]= bits<<3;
      used = 5;
      break;
    case 5:
      bytes[j]=(((FE->data[i])>>8) | bytes[j]);
      j++;
      bytes[j] = (FE->data[i]) & 0x00FF;
      j++;
      used = 0;      
      break;      
    default:
      return -1;
    }
  }
  return 0;  
}

int matrix_add(matrix_t A, matrix_t B, matrix_t C) {
  int i;
  for (i=0; i<A->numR; i++) {
    GF_addvec(A->data[i], B->data[i], C->data[i], C->numC);
  }
  return 0;
}

int matrix_vec_mat_mul(field_t V[], int vsize, matrix_t B, field_t dest[],int dsize, int m){
  return matrix_vec_mat_mul_standard(V,vsize, B, dest, dsize,m);
}

int matrix_mul(matrix_t A, matrix_t B, matrix_t C, int m) {
  return matrix_standard_mul(A,B,C,m);
}

int matrix_inv(matrix_t G, matrix_t Ginv, int m){
  return matrix_inv_standard(G,Ginv, m);
}
