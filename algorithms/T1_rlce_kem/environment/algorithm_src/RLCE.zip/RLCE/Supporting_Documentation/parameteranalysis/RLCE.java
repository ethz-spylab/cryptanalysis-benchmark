/*
 * Yongge Wang, April 10, 2017
 */
package rlce;

import java.io.IOException;
import java.math.BigInteger;
import java.util.Arrays;

/**
 * @author yonwang
 */
public class RLCE {  
    public static void main(String[] args) throws IOException
  {
      boolean invalidSwitch = false;     
      boolean helpRequested = false;
      int fast = 0;
      int brute = 0;
      int sysdecode = 0;
      int listparameter =0;
    
      int m=0;
      int n=0;
      int k=0;
      int t=0;
      int w=0;
      int q=0;
      int kc=0;
      int U=0;
      double kappac=0;
      double kappaq=0;
      double kappactmp=0;
      double kappaqtmp=0;
      BigInteger bigNum= new BigInteger("0");
      BigInteger bigNumtmp= new BigInteger("0");
      BigInteger bigNumtmp1= new BigInteger("0");
      BigInteger bigNumtmp2= new BigInteger("0");
      
      String arg;                  // Single argument extracted from list
      String commandLine="";       // Holds command line args for audit
    
      commandLine = Arrays.toString(args); // Get very first command line
      if (args.length == 0) {
          helpRequested = true; // Skip parsing as they have passed nothing in so provide help
      } else {
          for (int i = 0; i < args.length; i++) {
              arg = args[i].toLowerCase();
              if ((i == 0) && arg.charAt(0) != '-') {
                  invalidSwitch = true;
              } else if (arg.equals("-h")) {
                  helpRequested = true;
              } else if (arg.equals("-n")) //the codelength n
              {
                  if (i + 1 <= args.length - 1 && (args[i + 1].charAt(0) != '-')) {
                      String nString = args[i + 1];
                      n = Integer.parseInt(nString);
                  } else {
                      invalidSwitch = true;
                  }
              } else if (arg.equals("-k")) 
              {
                  if (i + 1 <= args.length - 1 && (args[i + 1].charAt(0) != '-')) {
                      String kString = args[i + 1];
                      k = Integer.parseInt(kString);
                  } else {
                      invalidSwitch = true;
                  }
              } else if (arg.equals("-w")) 
              {
                  if (i + 1 <= args.length - 1 && (args[i + 1].charAt(0) != '-')) {
                      String wString = args[i + 1];
                      w = Integer.parseInt(wString);
                  } else {
                      invalidSwitch = true;
                  }
              } else if (arg.equals("-t")) 
              {
                  if (i + 1 <= args.length - 1 && (args[i + 1].charAt(0) != '-')) {
                      String tString = args[i + 1];
                      t = Integer.parseInt(tString);
                  } else {
                      invalidSwitch = true;
                  }
              } else if (arg.equals("-m")) 
              {
                  if (i + 1 <= args.length - 1 && (args[i + 1].charAt(0) != '-')) {
                      String mString = args[i + 1];
                      m = Integer.parseInt(mString);
                  } else {
                      invalidSwitch = true;
                  }
              } else if (arg.equals("-s")) 
              {
                  if (i + 1 <= args.length - 1 && (args[i + 1].charAt(0) != '-')) {
                      String kcString = args[i + 1];
                      kc = Integer.parseInt(kcString);
                  } else {
                      invalidSwitch = true;
                  }
              }
              else if (arg.equals("-u")) 
              {
                  if (i + 1 <= args.length - 1 && (args[i + 1].charAt(0) != '-')) {
                      String uString = args[i + 1];
                      U = Integer.parseInt(uString);
                  } else {
                      invalidSwitch = true;
                  }
              }
              else if (arg.equals("-l")) {                  
                  listparameter = 1;
              }
              else if (arg.equals("-f")) {
                  fast = 1;                  
              }
              else if (arg.equals("-b")) {
                  brute =1;                  
              }              
          } // end for processing args
      } // end if args == 0
      if (helpRequested) {
          showHelp();
          System.out.flush();
          System.exit(0); 
      }
      if (U==0) U=k-(k*(n-w))/(n+w);
      if (t == 0) {
          t = (n - k) / 2;
      }
      if (w == 1) { //if w input is 1,then use w=(n-k)/2
          w = t;
      }
      q=(int) Math.pow((double) 2, m);
      System.out.println("\n********** RLCE parameter testing **********");
      System.out.printf("(n,k,t,w,m)=(%d,%d,%d,%d,%d)\n", n,k,t,w,m);
      if (invalidSwitch) {
          System.out.println("Invalid switch in command line: " + java.util.Arrays.toString(args) + ".\nApplication will terminate. Use -h for help.");
          System.exit(1);
      }
      
      if (listparameter == 1) {
          int johnson = n - 1 - (int) Math.floor(Math.sqrt(n * (k - 1)));

          System.out.println("list-decoding parameters:");
          System.out.printf("    can correct at most t_GS=%d errors\n", johnson);
          int cnm = 0;
          int tm = (n - k) / 2;
          int listm = 0;
          int Lm = 0;
          int xdeg=0;
          System.out.printf("    GS(%d): t_m=%d, Lm=1\n", listm, tm);
          listm++;

          int rAC = 0;
          int oldtm =tm;
          while (tm < johnson) {
              cnm = n * (listm + 1) * listm / 2;
              oldtm=tm;
              tm = n - 1 - (int) Math.floor((int) rA(cnm, k - 1) / (int) listm);
              Lm = (int) Math.floor(Math.sqrt((double) (n * listm * (listm + 1)) / (double) (k - 1)
                      + Math.pow((double) (k + 1) / (double) (2 * (k - 1)), 2)) - (double) (k + 1) / (double) (2 * (k - 1)));
              xdeg=(int) Math.ceil(Math.sqrt(2*(k-1)*n*binomialInt(listm,2)));
              if (tm>oldtm) {
                  System.out.printf("    GS(%d): t_m=%d, xdeg=%d, Lm=%d\n", listm, tm, xdeg, Lm);
              }
              listm++;
          }          
      }
      bigNum=BigInteger.valueOf(0);
      for (int i=1; i<U;i++) {
          bigNumtmp = binomial(n-w, k-i);
          bigNumtmp = bigNumtmp.multiply(binomial(2*w,i));
          bigNum =bigNum.add(bigNumtmp);
      }
      bigNum = bigNum.multiply(BigInteger.valueOf(100));
      bigNum = bigNum.divide(binomial(n+w,k));
              
      double pkSize=m*k*(n+w-k);
      pkSize = 1+pkSize/8;
      double sk2Size=m*(n+2*w+k*n+k*w-k*k); //decoding 2 RLCE private key size
      double sk0Size=m*(n+k+2*w+k*n+k*w+k*U-k*k); //regular RLCE private key size
      double sk1Size=m*(2*w+k*(U+1)+n+k*(n+w-k));
      sk2Size = sk2Size/8+4*n+2*w+1;
      sk0Size  = sk0Size/8+4*n+2*w+1; 
      sk1Size = sk1Size/8+4*n+2*w+1;
      int cipherSize = ((n+w)*m)/8;
      if (((n+w)*m) % 8>0) cipherSize++;
      
      
      System.out.println("Public/Private key size:");
      System.out.printf("    public key size: %.1f bytes\n", pkSize);
      System.out.printf("    Decoding 2 RLCE private key: %.1f bytes\n", sk2Size);
      System.out.printf("    Decoding 1 RLCE private key: %.1f bytes\n", sk1Size);
      System.out.printf("    Decoding 0 RLCE private key: %.1f bytes\n", sk0Size);
      System.out.printf("    cipher size: %d bytes\n", cipherSize);
      System.out.printf("    Decoding %d value's probability is: %d percent\n", U, bigNum.intValue());
      
      System.out.println("Basic ISD based security and quantum security (Grover's algorithm depth):");
      bigNum = binomial(n + w, k);
      bigNum = bigNum.divide(binomial(n + w - t, k));
      kappac = bigNum.bitLength();
      kappaq = kappac / 2;
      double kappacs = kappac;
      double kappaqs = kappaq;
      double tmp = 0;
      tmp = Math.pow((double) k, 2.807) + Math.pow((double) k, 2);
      kappac += Math.log(tmp) / Math.log(2);
      tmp += (n + w) * k;
      tmp *= Math.pow((double) m, 1.585) * 7;
      kappaq += Math.log(tmp) / Math.log(2);
      System.out.printf("    kappac=%.1f\n", kappac);
      System.out.printf("    kappaq=%.1f\n", kappaq);

      //System.out.println("ISD against systematic RLCE security and quantum security (Grover's algorithm depth):");
      tmp = (Math.pow((double) k, 3)) * (n + w - k);
      tmp /= Math.pow((double) n + w, 2);
      tmp += Math.pow(((double) (n + w - k) * k) / ((double) n + w), 2.807);
      tmp += Math.pow(((double) (n + w - k) * k) / ((double) n + w), 2);
      kappacs += Math.log(tmp) / Math.log(2);
      tmp *= 7 * Math.pow((double) m, 1.585);
      kappaqs += Math.log(tmp) / Math.log(2);
      System.out.printf("    systematic kappacs=%.1f\n", kappacs);
      System.out.printf("    systematic kappaqs=%.1f\n", kappaqs);

      System.out.println("non-optimized Stern's ISD and quantum ISD (Grover's algorithm depth):");
      int halfk=k/2;
      kappactmp=500;
      kappaqtmp=500;
      int ll=0;
      int pp=0;
      for (int l=1; l<10; l++) {
          for (int p=1; p<4; p++) {
              bigNum = binomial(n+w, halfk);
              bigNum = bigNum.multiply(binomial(n + w - halfk, k-halfk));
              bigNum = bigNum.multiply(binomial(n + w - k,l));
              bigNumtmp1 = binomial(n+w-t, halfk-p);
              bigNumtmp1 = bigNumtmp1.multiply(binomial(t, p));
              bigNumtmp1 = bigNumtmp1.multiply(binomial(n+w-t-halfk-p, k-halfk-p));              
              bigNumtmp1 = bigNumtmp1.multiply(binomial(t-p, 2*p));
              bigNumtmp1 = bigNumtmp1.multiply(binomial(n+w-t-k+2*p, l));
              bigNum = bigNum.divide(bigNumtmp1);
              kappactmp = bigNum.bitLength();
              kappaqtmp = kappactmp/2;
              bigNumtmp1 = BigInteger.valueOf(2*n+2*w-k);
              bigNumtmp1 = bigNumtmp1.multiply(BigInteger.valueOf((long)Math.pow((double) k, 2)));
              bigNumtmp2 = binomial(halfk,p).multiply(BigInteger.valueOf(2));
              bigNumtmp2 = bigNumtmp2.multiply(BigInteger.valueOf(l));
              bigNumtmp2 = bigNumtmp2.multiply(BigInteger.valueOf(k+1));
              bigNumtmp2 = bigNumtmp2.multiply((BigInteger.valueOf(q-1)).pow(p));              
              bigNumtmp1 = bigNumtmp1.add(bigNumtmp2);
              bigNumtmp2 = BigInteger.valueOf(n-k-l);
              bigNumtmp2 = bigNumtmp2.multiply(BigInteger.valueOf(k+1));
              bigNumtmp2 = bigNumtmp2.multiply(binomial(halfk,p));
              bigNumtmp2 = bigNumtmp2.multiply(binomial(halfk,p));
              bigNumtmp2 = bigNumtmp2.multiply((BigInteger.valueOf(q-1)).pow(2*p));
              bigNumtmp2 = bigNumtmp2.divide((BigInteger.valueOf(q-1)).pow(l));
              bigNumtmp1 = bigNumtmp1.add(bigNumtmp2);
              
              kappactmp += bigNumtmp1.bitLength();
              kappaqtmp += bigNumtmp1.bitLength();     
              if (kappac>kappactmp) {
                  kappac=kappactmp;
                  kappaq=kappaqtmp;
                  ll=l;
                  pp=p;
              }         
          }
      }
      System.out.printf("    Stern kappac=%.1f at l=%d, p=%d\n", kappac, ll, pp);
      System.out.printf("    Stern kappaq=%.1f at l=%d, p=%d\n", kappaq, ll,pp);      

      tmp = (Math.pow((double) k, 3)) * (n + w - k);
      tmp /= Math.pow((double) n + w, 2);
      tmp += Math.pow(((double) (n + w - k) * k) / ((double) n + w), 2.807);
      tmp += Math.pow(((double) (n + w - k) * k) / ((double) n + w), 2);
      kappacs += Math.log(tmp) / Math.log(2);
      tmp *= 7 * Math.pow((double) m, 1.585);
      kappaqs += Math.log(tmp) / Math.log(2);
      System.out.printf("    systematic kappacs=%.1f\n", kappacs);
      System.out.printf("    systematic kappaqs=%.1f\n", kappaqs);
 

      double kappaSS=0;
      System.out.println("Sidelnikov-Shestakov’s attack:");
      if (w<n-k) {          
          if (fast==1) {
          kappaSS=log2xCHOOSEy(q-n+w+1,w);
          } else {          
              bigNum = binomial(q-n+w+1,w);
              kappaSS=bigNum.bitLength();
          }
          kappaSS=kappaSS+(Math.log(2*3.14159*n)/2+n*Math.log(n/2.71828))/Math.log(2);
          System.out.printf("    strength: %.1f bits\n", kappaSS);
      } else {
          System.out.printf("    not applicable\n");
      }
      
      
      System.out.println("Known non-randomized columns-probability with insecure ciphertext:");
      double kappaF=0;
      BigInteger bigX= new BigInteger("0");
      BigInteger bigY= new BigInteger("0");
      BigInteger bigZ= new BigInteger("0");
      BigInteger big2= new BigInteger("2");
      double bound;      
      bound = n-w-Math.floor(Math.sqrt((n-w)*(k-1)));
      int temp=0;
      for (int i=0; i<bound; i++) {
          if (fast==1) {
              temp = (int) (log2xCHOOSEy(n - w, i) + log2xCHOOSEy(2 * w, t - i));
              bigX=bigX.add(big2.pow(temp));
          } else {
              bigX=bigX.add(binomial(n-w,i).multiply(binomial(2*w, t-i)));
          }
      }
      if (fast==1) {
          temp = (int) log2xCHOOSEy(n + w, t);
          bigY = bigY.add(big2.pow(temp));          
      } else {
          bigY=bigY.add(binomial(n+w,t));
      }
      bigZ = bigY.divide(bigX);
      kappaF = bigZ.bitLength();
      kappaF=kappaF+Math.log(Math.pow((double) k, 2)) / Math.log(2);
      System.out.printf("    %.1f bits (list-decoding %.0f errors)\n", kappaF,bound);      
      
      
      System.out.println("Filtration attack:");
      BigInteger bigXX= new BigInteger("0");
      BigInteger bigYY= new BigInteger("0");
      BigInteger bigZZ= new BigInteger("0");
      BigInteger big0= new BigInteger("0");
      BigInteger big2const= new BigInteger("2");
      double kappaFtemp = 0;
      double kappaFQtemp = 0;
      double kappaFQ = 0;
      int randDim = 0;
      int grsDim = 0;
      int totalDim = 0;
      int counter = 0;
      int start = 0;
      int l0=0;
      int u0=0;
      int l1=0;
      if (k>n-w-1) {
          System.out.printf("    k>=n-w. Filtration attack will not work\n");
      } else if (n-w>2*k-1) {
          System.out.printf("    n-w>=2k. Filtration attack can break the scheme\n");
      } else {
          kappaF = 10000;                    
          for (int l = 2 * k - n + w; l < k - 1; l++) {
              bigXX = big0;
              bigYY = big0;
              counter = 0;
              if (l - 2 * w < 0) {
                  start = 0;
              } else {
                  start = l - 2 * w;
              }
              for (int i = start; i < l + 1; i++) {
                  totalDim = 0;
                  randDim = 2 * w - (l - i);
                  if (randDim > (k - l) * (k - l)) {
                      randDim = (k - l) * (k - l);
                  }
                  
                  grsDim = 2 * (k - i) - 1;
                  if (grsDim > n - w - i) {
                      grsDim = n - w - i;
                  }
                  if (grsDim >(k - l) * (k - l)) {
                      grsDim = (k - l) * (k - l);
                  }
                 
                  totalDim = randDim + grsDim;
                  if (totalDim > (k - l) * (k - l)) {
                      totalDim = (k - l) * (k - l);
                  }
                  
                  if (totalDim == 2 * (k - i) - 1 + randDim) {
                      if (fast == 1) {
                          temp = (int) (log2xCHOOSEy(n - w, i) + log2xCHOOSEy(2 * w, l - i));
                          bigXX = bigXX.add(big2.pow(temp));
                      } else {
                          bigXX = bigXX.add(binomial(n - w, i).multiply(binomial(2 * w, l - i)));
                      }
                  }
              }
              if (fast == 1) {
                  temp = (int) log2xCHOOSEy(n + w, l);
                  bigYY = bigYY.add(big2.pow(temp));
              } else {
                  bigYY = binomial(n + w, l);
              }
              if (!bigXX.equals(big0)) {
                  bigZZ = bigYY.divide(bigXX);
                  kappaFtemp = bigZZ.bitLength();
                  kappaFQtemp = kappaFtemp/2 +Math.log(7*Math.pow((double) m, 1.585)*((n+w-l)*(k-l)*(k-l)*(k-l)*(k-l)+k*l*(n+w))) / Math.log(2);  
                  kappaFtemp += Math.log((n+w-l)*(k-l)*(k-l)*(k-l)*(k-l)+k*l*(n+w)) / Math.log(2);                  
                  if (kappaF > kappaFtemp) {
                      l0=l;
                      kappaF = kappaFtemp;
                      kappaFQ= kappaFQtemp;
                  }
              }
             
          }
          System.out.printf("    Filtration attack kappaf=: %.1f bits with l=%d\n", kappaF, l0);
          System.out.printf("    Quantum filtration attack kappafq=: %.1f bits\n", kappaFQ);
      }
      
      if (brute == 1 ) {
          bigXX = big0;
          bigYY = big0;
          bigZZ = big0;
          kappaFtemp = 0;
          kappaF = 10000;  
          for (int u = 0; u < w + 1; u++) {
              for (int l = 2 * k - n + w - u; l < k - u - 1; l++) {
                  counter = 0;
                  if (l - 2 * w + 2 * u < 0) {
                      start = 0;
                  } else {
                      start = l - 2 * w + 2 * u;
                  }
                  for (int i = start; i < l + 1; i++) {
                      totalDim = 0;
                      randDim = 2 * (w - u) - (l - i);
                      if (randDim > (k - l) * (k - l)) {
                          randDim = (k - l) * (k - l);
                      }

                      grsDim = 2 * (k - i) - 1;
                      if (grsDim > n - w + u - i) {
                          grsDim = n - w + u - i;
                      }
                      if (grsDim > (k - l) * (k - l)) {
                          grsDim = (k - l) * (k - l);
                      }

                      totalDim = randDim + grsDim;
                      if (totalDim > (k - l) * (k - l)) {
                          totalDim = (k - l) * (k - l);
                      }
                      if (totalDim == 2 * (k - i) - 1 + randDim) {
                          if ((n - w > i - 1) && (2 * (w - u) > l - i - 1)) {
                              if (fast == 1) {
                                  temp = (int) (log2xCHOOSEy(n - w, i) + log2xCHOOSEy(2 * (w - u), l - i));
                                  bigXX = bigXX.add(big2.pow(temp));
                              } else {
                                  bigXX = bigXX.add(binomial(n - w, i).multiply(binomial(2 * (w - u), l - i)));
                              }
                          }
                      }
                  }
                  if (fast == 1) {
                      temp = (int) log2xCHOOSEy(n + w - 2 * u, l);
                      bigYY = bigYY.add(big2.pow(temp));
                  } else {
                      bigYY = binomial(n + w - 2 * u, l);
                  }
                  if (!bigXX.equals(big0)) {
                      bigZZ = bigYY.divide(bigXX);
                      kappaFtemp = bigZZ.bitLength();
                      kappaFQtemp = 2*u*m+kappaFtemp/2+ Math.log(7*Math.pow((double)m,1.585)*((n+w-2*u-l)*(k-l)*(k-l)*(k-l)*(k-l)+k*l*(n+w-2*u)))/Math.log(2);
                      kappaFtemp += 2*u*m+Math.log((n+w-l)*(k-l)*(k-l)*(k-l)*(k-l) + k * l * (n + w)) / Math.log(2);
                      if (kappaF > kappaFtemp) {
                          l0 = l;
                          u0=u;
                          kappaF = kappaFtemp;
                          kappaFQ = kappaFQtemp;
                      }
                  }
                  
                  bigXX = big0;
                  bigYY = big0;
                  bigZZ = big0;
              }              
          }
          System.out.printf("    Filtration with Brute Force kappafb=: %.1f bits at l=%d, u=%d\n", kappaF, l0,u0);
          System.out.printf("    Quantum filtration attack with Brute Force kappafq=: %.1f bits\n", kappaFQ);
      }
       
      if (sysdecode==1) {
          if (w == n - k) {
              bigXX = big0;
              bigXX = bigXX.add(binomial(2 * w, 4));
              bigXX = bigXX.divide(binomial(w, 2));
              System.out.println("Systematic Decoding:");
              double kappaSD;
              kappaSD = bigXX.bitLength() + 4 * m + 3 * Math.log(k) / Math.log(2);
              System.out.printf("    kappaSD=: %.1f\n", kappaSD);
          }
      }
      
      double kappaISDsys1 = 0;
      double kappaISDsystmp = 0;
      double ElISDsys = 10000;
      ll=0;
      for (int l=0; l<t+1; l++) {
          kappaISDsys1 = 10000;
          for (int i=l; i<t+1; i++) { 
              bigNum = binomial(k, i).divide(binomial(k - l, i-l));
              kappaISDsystmp = bigNum.bitLength();
              kappaISDsystmp += i * m;
              if (kappaISDsystmp < kappaISDsys1) {
                  kappaISDsys1 = kappaISDsystmp;
              }
          }
          if (kappaISDsys1 <kc) {
              ll=l;
              bigNum = binomial(n + w, t);
              bigXX = big0;
              for (int i = 0; i < l + 1; i++) {
                  bigXX = bigXX.add(binomial(k, i).multiply(binomial(n + w - k, t - i)));
              }
              bigNum = bigNum.divide(bigXX);
              kappaISDsystmp = bigNum.bitLength();
              if (kappaISDsystmp<ElISDsys) {
                  ElISDsys=kappaISDsystmp;
              }
          } 
      }
      System.out.println("Systematic RLCE probability for insecure ciphertext:");
      System.out.printf("    kappaISDsys=%.1f\n", ElISDsys);
      System.out.printf("    first k-components should contain at least %d errors\n", ll);
      
      
      double kappaknowngrs = 10000;
      double kappaknowngrstmp = 0;
      ll=0;
      int uu =0;
      int l1l1=0;
      int test = 1;
      int upperbound=0;
      int u=0;
      int l=0;
      while (test>0) {
          if (n-w-l>k+2-l) {
              upperbound =k+2-l;
          } else {
              upperbound = n-w-l;
          }
          for (int ll1 = 0; ll1< upperbound+1; ll1++) {
              u = k - l - ll1 + 2;
              if (u < w + 1) {
                  bigNum = binomial(n + w - l, 2 * u);
                  bigNum = bigNum.multiply(binomial(n + w - l - 2 * u, ll1));
                  bigNum = bigNum.multiply(BigInteger.valueOf(l+u+ll1-k+2));
                  bigX = binomial(w, u);
                  bigX = bigX.multiply(binomial(n - w - l, ll1));
                  bigNum = bigNum.divide(bigX);
                  kappaknowngrstmp = bigNum.bitLength();
                  kappaknowngrstmp += 2 * m * u;
                  if (kappaknowngrstmp < kc) {
                      ll = l;
                      uu = u;
                      l1l1 = ll1;
                      test = 0;                      
                  }
              }
          }
          if (l<k+2) {
              l++;
          } else {
              ll=k;
              test =0;
          }
      }
      System.out.println("Known non-randomized column attack revisited:");
      System.out.printf("    at most %d non-randomized columns can be published (filtration to 2 columns)\n", ll);
      System.out.printf("    one can guess %d non-randomized columns and %d-pairs of randomized columns to break the system (filtration to 2 columns)\n", l1l1, uu);      
      
      test = 1;
      u = 0;
      if (k<n-w-1) {
          while (test > 0) {
              kappaF = 1000;
              for (l = 2 * k - n + w; l < k - 1; l++) {
                  counter = 0;
                  if (l - 2 * w < 0) {
                      start = 0;
                  } else {
                      start = l - 2 * w;
                  }
                  for (int i = start; i < l + 1; i++) {
                      totalDim = 0;
                      randDim = 2 * w - (l - i);
                      if (randDim > (k - l) * (k - l)) {
                          randDim = (k - l) * (k - l);
                      }

                      grsDim = 2 * (k - i) - 1;
                      if (grsDim > n - w - i) {
                          grsDim = n - w - i;
                      }
                      if (grsDim > (k - l) * (k - l)) {
                          grsDim = (k - l) * (k - l);
                      }

                      totalDim = randDim + grsDim;
                      if (totalDim > (k - l) * (k - l)) {
                          totalDim = (k - l) * (k - l);
                      }
                      if (totalDim == 2 * (k - i) - 1 + randDim) {
                          bigXX = bigXX.add(binomial(n - w - u, i).multiply(binomial(2 * w, l - i)));
                      }
                  }
                  bigYY = binomial(n + w - u, l);
                  if (!bigXX.equals(big0)) {
                      bigZZ = bigYY.divide(bigXX);
                      kappaFtemp = bigZZ.bitLength();
                      if (kappaF > kappaFtemp) {
                          l0 = l;
                          kappaF = kappaFtemp;
                      }
                  }
                  bigXX = big0;
                  bigYY = big0;
                  bigZZ = big0;
              }
              kappaF = kappaF + Math.log((n + w - l0) * (k - l0) * (k - l0) * (k - l0) * (k - l0) + k * l0 * (n + w)) / Math.log(2);
              if (kappaF < kc) {
                  ll = u;
                  test = 0;
              }
              if (u < k + 2) {
                  u++;
              } else {
                  ll = k;
                  test = 0;
              }
          }
          if (ll<k) {
              System.out.printf("    at most %d non-randomized columns can be published (general filtration attack)\n", ll);
              System.out.printf("    one can shorten %d non-randomized columns to break the system (general filtration attack)\n", l0);
          }
      }
      
      
      if (kappac<kc) {
          System.out.println("the parameter does not achieve the requried security");
          System.exit(0);
      }
      double k1spad,k3spad,k1pad,k2pad;
      int kcB = kc/8;
      double mLen;
      double totalk;
      System.out.println("RLCE padding parameters:");
      mLen = m*k;
      totalk=Math.ceil(mLen/8);
      k1spad=Math.floor(mLen/32);
      k3spad=totalk-2*k1spad;
      k2pad=2*kcB;
      k1pad=totalk-2*k2pad;
      System.out.printf("    basic encoding mLen=%.0f\n", mLen);
      System.out.printf("        RLCEspad: (k1,k2,k3)=(%.0f,%.0f,%.0f)\n", k1spad,k1spad,k3spad);
      System.out.printf("        RLCEpad: (k1,k2,k3)=(%.0f.%.0f,%.0f)\n", k1pad,k2pad,k2pad);
      
      mLen = m*(k+t);
      totalk = Math.ceil(mLen / 8);
      k1spad = Math.floor(mLen / 32);
      k3spad = totalk - 2 * k1spad;
      k2pad = 2 * kcB;
      k1pad = totalk - 2 * k2pad;
      System.out.printf("    medium encoding mLen=%.0f\n", mLen);
      System.out.printf("        RLCEspad: (k1,k2,k3)=(%.0f,%.0f,%.0f)\n", k1spad,k1spad,k3spad);
      System.out.printf("        RLCEpad: (k1,k2,k3)=(%.0f,%.0f,%.0f)\n", k1pad,k2pad,k2pad);
          
      bigNum = binomial(n + w, t);
      mLen = m * (k + t) + bigNum.bitLength()-1;      
      totalk = Math.ceil(mLen / 8);
      k1spad = Math.floor(mLen / 32);
      k3spad = totalk - 2 * k1spad;
      k2pad = 2 * kcB;
      k1pad = totalk - 2 * k2pad;
      System.out.printf("    advanced encoding mLen=%.0f\n", mLen);
      System.out.printf("        RLCEspad: (k1,k2,k3)=(%.0f,%.0f,%.0f)\n", k1spad,k1spad,k3spad);
      System.out.printf("        RLCEpad: (k1,k2,k3)=(%.0f.%.0f,%.0f)\n", k1pad,k2pad,k2pad);
  } // end main
    
  
    
  private static void showHelp() throws IOException         
  {
   System.out.println("\n***************** RLCE help *******************");
   System.out.println("This software is for education/research purpose only and should not be used \n"
           + "for any commercial purpose. "
           + "For details, please contact: Yongge.Wang@gmail.com\n\n"
           + "Switches can be in any order and are not case sensitive:");
   System.out.println("-h  Provides help, it  overrides any other switches to simply provide this help");
   System.out.println("-n  followed by code length integer n");
   System.out.println("-k  followed by code dimension integer k");
   System.out.println("-t  [default t=(n-k)/2] followed by error number integer t");
   System.out.println("-w  [default w=n-k] followed by integer w (number of random columns to be added)");
   System.out.println("-m  followed by field integer m (GF(2^m))");   
   System.out.println("-s  followed by expected security strength kappac (e.g., 128, 192, or 256)"); 
   System.out.println("-b  no argument follows. If set, analyze filtration attack with brute-force (slow)"); 
   System.out.println("-l  no argument follows. If set, compute list-decoding parameters (slow)"); 
   System.out.println("-f  no argument follows. If set, compute binomials using Sterling’s approximation\n"
           + "    It is not recommended to use this flag unless you have a very slow computer.");
   System.out.println("-u  followed by the number of msg symbols not recovered by RS decoding"); 
   System.out.println("Example 1: java -jar RLCE.jar -m 10 -n 630 -k 470 -t 80 -w 160 -s 128 -f -b -l");
   System.out.println("Example 1: java -jar RLCE.jar -m 10 -n 630 -k 470 -t 80 -w 160 -s 128 -b -l");
   System.out.println("Example 2: java -jar RLCE.jar -m 10 -n 630 -k 470 -t 80 -w 160 -s 128 -l");
   System.out.println("******************************************************\n");
}
  
  
  static double binaryEntropy(double x) {
      double y;
      y = -(x * Math.log(x) + (1 - x) * Math.log(1 - x)) / Math.log(2);
      return y;
  }
  
  static double log2xCHOOSEy(int x, int y) {
      double xx=x;
      double yy=y;
      double z;
      if (x<y) {
          return 0;
      }
      if (x==y) {
          return 0;
      }
      z=x*binaryEntropy(yy/xx);
      return z;
  }
  
    static BigInteger binomialOLD(int n, int k) {
        if (k > n - k) {
            k = n - k;
        }

        BigInteger b = BigInteger.ONE;
        BigInteger M;
        BigInteger I;
        for (int i = 1, m = n; i <= k; i++, m--) {
            M=BigInteger.valueOf(m);
            I=BigInteger.valueOf(i);
            b = b.multiply(M);
            b = b.divide(I);
        }
        return b;
    }
    
    static BigInteger binomial(int n, int k) {
        if (k>n) {
            return BigInteger.valueOf(0);
        }        
        if (k > n - k) {
            k = n - k;
        }
        BigInteger  C=BigInteger.valueOf(1);
        for (int i = 0; i < k ; i++) {
            C=C.multiply(BigInteger.valueOf(n - i));
            C=C.divide(BigInteger.valueOf(i+1));
        }
        return C;
    }
    
    static int binomialInt(int n, int k) {
        if (k > n) {
            return 0;
        }
        if (k > n - k) {
            k = n - k;
        }
        int C = 1;
        for (int i = 0; i < k; i++) {
            C = C*(n - i);
            C = C/(i + 1);
        }
        return C;
    }
    
    static int A(int K, int v) {
        int bound = K/v;  
        int Akv=0;
        for (int i=0; i<bound+1; i++) {
            Akv += K-i*v;            
        }
        return Akv;
    }
    
    static int rA(int J, int v) {
        int rAJ = 0;
        int i=v;
        while (A(i,v)<J+1) {
                rAJ=i;
                i++;
            }
        return rAJ;
    }
    
}
