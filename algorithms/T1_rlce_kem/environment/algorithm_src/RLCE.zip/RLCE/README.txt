This is the README file for the RLCE-KEM scheme submitted to NIST post-quantum 
cryptography project. RLCE-KEM standards for "Random Linear Code Encryption based 
Key Encapsulation Mechanism". The details for RLCE-KEM could be found in the 
included paper: RLCE Key Encapsulation Mechanism (RLCE-KEM) Specification

The proposed RLCE-KEM schemes have three security levels:

1. Schemes with ID=0,1 have equivalent security strength of AES-128 where
   Scheme ID=0 randomizes w=n-k columns of the generator matrix
   Scheme ID=1 randomizes w<n-k columns of the generator matrix
2. Schemes with ID=2,3 have equivalent security strength of AES-192 where
   Scheme ID=2 randomizes w=n-k columns of the generator matrix
   Scheme ID=3 randomizes w<n-k columns of the generator matrix
3. Schemes with ID=4,5 have equivalent security strength of AES-256 where
   Scheme ID=4 randomizes w=n-k columns of the generator matrix
   Scheme ID=5 randomizes w<n-k columns of the generator matrix

It is preferred to use Schemes ID=1,3,5 (that is, RLCE-KEM-128A, RLCE-KEM-192A,
and RLCE-KEM-256A) which have smaller public keys and short cipher texts. 
These schemes are mapped to the optimized/reference implementation folders 
as follows:

	RLCE_KEM_128A <-> ID=1 (preferred)
	RLCE_KEM_128B <-> ID=0
	RLCE_KEM_192A <-> ID=3 (preferred)
	RLCE_KEM_192B <-> ID=2
	RLCE_KEM_256A <-> ID=5 (preferred)
	RLCE_KEM_256B <-> ID=4

The referenced implementation C source codes are identical in all
referenced implementation folders and the optimized implementation 
C source codes are identical in all optimized implementation folders. 

The C source code is the same. The only difference is the content of 
the api.h file in each folder. In particular, the following variable in api.h 

#define CRYPTO_SCHEME 1 /* 0, ..., 5 */
 
defines the ID for the RLCD scheme.

For each scheme, we have "#define CRYPTO_BYTES 64" in api.h. But
this can be changed if you want to increase the maximum length of the encapsulated
secret string. The following is the maximum CRYPTO_BYTES allowed for 
each scheme if you want to modify the default "#define CRYPTO_BYTES 64" in api.h.

	RLCE_KEM_128A:  504 (maximum allowed value for CRYPTO_BYTES)
	RLCE_KEM_128B:  624 (maximum allowed value for CRYPTO_BYTES)
	RLCE_KEM_192A:  819 (maximum allowed value for CRYPTO_BYTES)
	RLCE_KEM_192B: 1007 (maximum allowed value for CRYPTO_BYTES)
	RLCE_KEM_256A: 1159 (maximum allowed value for CRYPTO_BYTES)
	RLCE_KEM_256B: 1356 (maximum allowed value for CRYPTO_BYTES)

The sample program "NISTexample.c" (or reference "NISTexample.c")is included 
in each implementation folder. In each folder, I also include NIST provided 
rng.h/rng.c/PQCgenKAT_kem.c which have the implementation for 

int randombytes(unsigned char *x,unsigned long long xlen);

You can test the program by running 

make

It will generate an executable program "NISTexample” and an executable program
"PQCgenKAT_kem”. You can run them as follows:

./NISTexample
./PQCgenKAT_kem

In the Makefile, I used the following library:
<pre>
 -lcrypto -lssl
</pre>
This is only needed for NIST programs "rng.h/rng.c/PQCgenKAT_kem.c". 
RLCE has its own AES/SHA implementation. Thus if NIST program does not need 
OpenSSL library, then you can remove these two libraries from the Makefile.

The TEST vectors are located within KAT folder. 6 KAT files generated 
by the NIST KAT scripts “PQCgenKAT_kem” are included:

PQCkemKAT_179946.rsp (for scheme RLCEKEM128A)
PQCkemKAT_310116.rsp (for scheme RLCEKEM128B)
PQCkemKAT_440008.rsp (for scheme RLCEKEM192A)
PQCkemKAT_747393.rsp (for scheme RLCEKEM192B)
PQCkemKAT_1048176.rsp (for scheme RLCEKEM256A)
PQCkemKAT_1773271.rsp (for scheme RLCEKEM256B)


Furthermore, I also include three additional KAT files for each scheme. They are:

RLCE_KEM_KAT_128A_DECAPSULATION.txt
RLCE_KEM_KAT_128A_ENCAPSULATION.txt
RLCE_KEM_KAT_128A_KEY.txt
RLCE_KEM_KAT_128B_DECAPSULATION.txt
RLCE_KEM_KAT_128B_ENCAPSULATION.txt
RLCE_KEM_KAT_128B_KEY.txt
RLCE_KEM_KAT_192A_DECAPSULATION.txt
RLCE_KEM_KAT_192A_ENCAPSULATION.txt
RLCE_KEM_KAT_192A_KEY.txt
RLCE_KEM_KAT_192B_DECAPSULATION.txt
RLCE_KEM_KAT_192B_ENCAPSULATION.txt
RLCE_KEM_KAT_192B_KEY.txt
RLCE_KEM_KAT_256A_DECAPSULATION.txt
RLCE_KEM_KAT_256A_ENCAPSULATION.txt
RLCE_KEM_KAT_256A_KEY.txt
RLCE_KEM_KAT_256B_DECAPSULATION.txt
RLCE_KEM_KAT_256B_ENCAPSULATION.txt
RLCE_KEM_KAT_256B_KEY.txt

These KAT files contain intermediate variable values for debugging purpose. 
For example, for the scheme "RLCE_KEM_128A", we have the following files:

RLCE_KEM_KAT_128A_KEY.txt (to test the crypto_kem_keypair() processs)
RLCE_KEM_KAT_128A_ENCAPSULATION.txt (to test the crypto_kem_enc() process)
RLCE_KEM_KAT_128A_DECAPSULATION.txt (to test the crypto_kem_dec() process)

Each non-NIST-KAT-script generated KAT file contains input, intermediate, and 
output values for the corresponding test. It should be noted that each key 
generation KAT (e.g., RLCE_KEM_KAT_128A_KEY.txt) contains a "nonce" input 
value, you can safely ignore this value since it is hard coded in 
crypto_kem_keypair() process of file kem.c. I provide it in the KAT file 
so that it is consistent with "RLCE Key Encapsulation Mechanism (RLCE-KEM) 
Specification".

If you want to make any changes to test the performance for various algorithms such
as FFT, Strassen, Karatsuba, or Winograd, you may change corresponding switches 
located in "config.h" of the optimized implementation. 

In the Supporting_Documentation/parameteranalysis folder, I include a Java
source code RLCE.java and a compiled RLCE.jar which can be used to analyze 
the security strength of any parameters for RLCE-KEM scheme. For help, run

java -jar RLCE.jar

For any questions, please contact: yongge.wang@gmail.com

Thanks!
Yongge Wang




