// To create this project in Visual Studio 2005:
//	set the language choice to Visual C++
//	create new project: windows console application, empty project
//	copy this file and genKAT.c source file to the folder with the project file in it
//	do project/add existing item and select this file
//		wrapper.c should appear in the Solution Explorer panel
//	double click on wrapper.c in the Solution Explorer panel
//		the file should open in the editing panel

#define _CRT_SECURE_NO_DEPRECATE

#include "genKat.c"
#include "Blender.c"

// This is an alternative to editing the C files to include the above definition.

