BLENDER Read-me file
====================

The file Blander.pdf contains the complete disclosure of the 
algorithm and the rationale behind the design decisions.

The Reference Implementation and the two "optimised" implementations
are all the same since the algorithm is indifferent to the target 
machine word size - neither a 32-bit processor nor a 64-bit processor
presents any advantages or disadvantages.


The files on this disk are as follows:

README.TXT	this file

Blender_Specification.pdf	specification of the submitted algortihm

Reference Implementation	folder containing the following files
	Blender.h	header file defining the data structures
	Blender.c	source code for the algorithm subroutines
	SHA3api_ref.h	header file for the reference API
	Genkat.c	source code of the program for KAT/MCT files
	Wrapper.c	top-level source file for the project

Optimised_32 bit	folder containing the following files
	Blender.h	header file defining the data structures
	Blender.c	source code for the algorithm subroutines
	SHA3api_ref.h	header file for the reference API
	Genkat.c	source code of the program for KAT/MCT files
	Wrapper.c	top-level source file for the project

Optimised_64 bit	folder containing the following files
	Blender.h	header file defining the data structures
	Blender.c	source code for the algorithm subroutines
	SHA3api_ref.h	header file for the reference API
	Genkat.c	source code of the program for KAT/MCT files
	Wrapper.c	top-level source file for the project

Supporting Documentation	folder containing the following files
	Blender_Specification.pdf	copy of the specification of the submitted algortihm
	Blender_Supplement.pdf		informal discussion and illustrations
	Slice_Attack.pdf		outline of a first preimage attack on SHA-2

KAT_MCT		folder containing the following subfolders and files
	ShortMsgKAT_512.txt	short message KAT using eight 64-bit words
	ShortMsgKAT_384.txt	short message KAT using six 64-bit words
	ShortMsgKAT_256.txt	short message KAT using eight 32-bit words
	ShortMsgKAT_224.txt	short message KAT using seven 32-bit words
	LongMsgKAT_512.txt	long message KAT using eight 64-bit words
	LongMsgKAT_384.txt	long message KAT using six 64-bit words
	LongMsgKAT_256.txt	long message KAT using eight 32-bit words
	LongMsgKAT_224.txt	long message KAT using seven 32-bit words
	ExtremelyLongMsgKAT_512.txt	very long message KAT using eight 64-bit words
	ExtremelyLongMsgKAT_384.txt	very long message KAT using six 64-bit words
	ExtremelyLongMsgKAT_256.txt	very long message KAT using eight 32-bit words
	ExtremelyLongMsgKAT_224.txt	very long message KAT using seven 32-bit words
	MonteCarlo_512.txt	Monte-Carlo KAT using eight 64-bit words
	MonteCarlo_384.txt	Monte-Carlo KAT using six 64-bit words
	MonteCarlo_256.txt	Monte-Carlo KAT using eight 32-bit words
	MonteCarlo_224.txt	Monte-Carlo KAT using seven 32-bit words

Intermediate Values		subfolder containing:
	VerboseMsgKAT.txt	source file for creating intermediate values
	VerboseMsgKAT_512.txt	intermediate values using eight 64-bit words
	VerboseMsgKAT_384.txt	intermediate values using six 64-bit words
	VerboseMsgKAT_256.txt	intermediate values using eight 32-bit words
	VerboseMsgKAT_224.txt	intermediate values using seven 32-bit words



Additional Implementations	folder containing the following subfolders and files
	Original Implementation		subfolder - see below
	C8051F120			subfolder - see below
	Pic18F2525			subfolder - see below
	Original KAT_MCT		subfolder - see below



Additional Implementations\Original Implementation	folder containing the following subfolders and files
	Blender.h	header file defining the data structures
	Blender.c	source code for the algorithm subroutines
	Genkat.c	modified source code of the program for KAT/MCT files

Additional Implementations\C8051F120	folder containing the following subfolders and files
	Blender.h	header file defining the data structures
	Blender.c	source code for the algorithm subroutines
	SHA3api_ref.h	header file for the reference API
	Wrapper.c	top-level source file for the project
	startup.a51	initialisation code for the processor
	genkat.Uv2	Keil compiler project file
	genkat.M51	compiler report file
	genkat.lnp	linker working file

Additional Implementations\Pic18F2525	folder containing the following subfolders and files
	README - URGENT.txt	read-me file about this version
	Blender.h	header file defining the data structures
	Blender.c	source code for the algorithm subroutines
	SHA3api_ref.h	header file for the reference API
	Wrapper.c	top-level source file for the project
	CryptoHash.mpp	Microchip project file
	CryptoHash.mpw	Microchip workspace file

Additional Implementations\Original KAT_MCT		folder containing the following subfolders and files
	ShortMsgKAT_512_64.txt	short message KAT using eight 64-bit words
	ShortMsgKAT_384_64.txt	short message KAT using six 64-bit words
	ShortMsgKAT_256_32.txt	short message KAT using eight 32-bit words
	ShortMsgKAT_224_32.txt	short message KAT using seven 32-bit words
	ShortMsgKAT_128_16.txt	short message KAT using eight 16-bit words
	ShortMsgKAT_160_16t.txt	short message KAT using ten 16-bit words
	ShortMsgKAT_320_32t.txt	short message KAT using ten 32-bit words
	ShortMsgKAT_640_64t.txt	short message KAT using ten 64-bit words
	LongMsgKAT_512_64.txt	long message KAT using eight 64-bit words
	LongMsgKAT_384_64.txt	long message KAT using six 64-bit words
	LongMsgKAT_256_32.txt	long message KAT using eight 32-bit words
	LongMsgKAT_224_32.txt	long message KAT using seven 32-bit words
	LongMsgKAT_128_16.txt	long message KAT using eight 16-bit words
	LongMsgKAT_160_16t.txt	long message KAT using ten 16-bit words
	LongMsgKAT_320_32t.txt	long message KAT using ten 32-bit words
	LongMsgKAT_640_64t.txt	long message KAT using ten 64-bit words
	ExtremelyLongMsgKAT_512_64.txt	very long message KAT using eight 64-bit words
	ExtremelyLongMsgKAT_384_64.txt	very long message KAT using six 64-bit words
	ExtremelyLongMsgKAT_256_32.txt	very long message KAT using eight 32-bit words
	ExtremelyLongMsgKAT_224_32.txt	very long message KAT using seven 32-bit words
	ExtremelyLongMsgKAT_128_16.txt	very long message KAT using eight 16-bit words
	ExtremelyLongMsgKAT_160_16t.txt	very long message KAT using ten 16-bit words
	ExtremelyLongMsgKAT_320_32t.txt	very long message KAT using ten 32-bit words
	ExtremelyLongMsgKAT_640_64t.txt	very long message KAT using ten 64-bit words
	MonteCarlo_512_64.txt	Monte-Carlo KAT using eight 64-bit words
	MonteCarlo_384_64.txt	Monte-Carlo KAT using six 64-bit words
	MonteCarlo_256_32.txt	Monte-Carlo KAT using eight 32-bit words
	MonteCarlo_224_32.txt	Monte-Carlo KAT using seven 32-bit words
	MonteCarlo_128_16.txt	Monte-Carlo KAT using eight 16-bit words
	MonteCarlo_160_16t.txt	Monte-Carlo KAT using ten 16-bit words
	MonteCarlo_320_32t.txt	Monte-Carlo KAT using ten 32-bit words
	MonteCarlo_640_64t.txt	Monte-Carlo KAT using ten 64-bit words
	Source Files		subfolder - see below
	Other Word Sizes	subfolder - see below
	Gate Reduced		subfolder - see below
	Intermediate Values	subfolder - see below

Additional Implementations\Original KAT_MCT\Source Files	subfolder containung the files for generating the KATs:
	genKAT.c		source code for the integrated implementation
	ShortMsgKAT.txt		short message KAT source file
	LongMsgKAT.txt		long message KAT source file
	ExtremelyLongMsgKAT.txt	very long message KAT source file
	MonteCarlo.txt		Monte-Carlo KAT source file
	VerboseMsgKAT.txt	source file for intermediate values output

Additional Implementations\Original KAT_MCT\Other Word Sizes	subfolder for other word size/word count combinations:
	ShortMsgKAT_448_64.txt	short message KAT using seven 64-bit words
	ShortMsgKAT_448_56.txt	short message KAT using eight 56-bit words
	ShortMsgKAT_392_56.txt	short message KAT using seven 56-bit words
	ShortMsgKAT_336_56.txt	short message KAT using six 56-bit words
	ShortMsgKAT_384_48.txt	short message KAT using eight 48-bit words
	ShortMsgKAT_336_48.txt	short message KAT using seven 48-bit words
	ShortMsgKAT_288_48.txt	short message KAT using six 48-bit words
	ShortMsgKAT_320_40.txt	short message KAT using eight 40-bit words
	ShortMsgKAT_280_40.txt	short message KAT using seven 40-bit words
	ShortMsgKAT_240_40.txt	short message KAT using six 40-bit words
	ShortMsgKAT_192_32.txt	short message KAT using six 32-bit words
	ShortMsgKAT_192_24.txt	short message KAT using eight 24-bit words
	ShortMsgKAT_168_24.txt	short message KAT using seven 24-bit words
	ShortMsgKAT_144_24.txt	short message KAT using six 24-bit words
	ShortMsgKAT_112_16.txt	short message KAT using seven 16-bit words
	ShortMsgKAT_96_16.txt	short message KAT using six 16-bit words
	ShortMsgKAT_144_16t.txt	short message KAT using nine 16-bit words
	ShortMsgKAT_288_32t.txt	short message KAT using nine 32-bit words
	ShortMsgKAT_576_64t.txt	short message KAT using nine 64-bit words
	LongMsgKAT_448_64.txt	long message KAT using seven 64-bit words
	LongMsgKAT_448_56.txt	long message KAT using eight 56-bit words
	LongMsgKAT_392_56.txt	long message KAT using seven 56-bit words
	LongMsgKAT_336_56.txt	long message KAT using six 56-bit words
	LongMsgKAT_384_48.txt	long message KAT using eight 48-bit words
	LongMsgKAT_336_48.txt	long message KAT using seven 48-bit words
	LongMsgKAT_288_48.txt	long message KAT using six 48-bit words
	LongMsgKAT_320_40.txt	long message KAT using eight 40-bit words
	LongMsgKAT_280_40.txt	long message KAT using seven 40-bit words
	LongMsgKAT_240_40.txt	long message KAT using six 40-bit words
	LongMsgKAT_192_32.txt	long message KAT using six 32-bit words
	LongMsgKAT_192_24.txt	long message KAT using eight 24-bit words
	LongMsgKAT_168_24.txt	long message KAT using seven 24-bit words
	LongMsgKAT_144_24.txt	long message KAT using six 24-bit words
	LongMsgKAT_112_16.txt	long message KAT using seven 16-bit words
	LongMsgKAT_96_16.txt	long message KAT using six 16-bit words
	LongMsgKAT_144_16t.txt	long message KAT using nine 16-bit words
	LongMsgKAT_288_32t.txt	long message KAT using nine 32-bit words
	LongMsgKAT_576_64t.txt	long message KAT using nine 64-bit words
	ExtremelyLongMsgKAT_448_64.txt	very long message KAT using seven 64-bit words
	ExtremelyLongMsgKAT_448_56.txt	very long message KAT using eight 56-bit words
	ExtremelyLongMsgKAT_392_56.txt	very long message KAT using seven 56-bit words
	ExtremelyLongMsgKAT_336_56.txt	very long message KAT using six 56-bit words
	ExtremelyLongMsgKAT_384_48.txt	very long message KAT using eight 48-bit words
	ExtremelyLongMsgKAT_336_48.txt	very long message KAT using seven 48-bit words
	ExtremelyLongMsgKAT_288_48.txt	very long message KAT using six 48-bit words
	ExtremelyLongMsgKAT_320_40.txt	very long message KAT using eight 40-bit words
	ExtremelyLongMsgKAT_280_40.txt	very long message KAT using seven 40-bit words
	ExtremelyLongMsgKAT_240_40.txt	very long message KAT using six 40-bit words
	ExtremelyLongMsgKAT_192_32.txt	very long message KAT using six 32-bit words
	ExtremelyLongMsgKAT_192_24.txt	very long message KAT using eight 24-bit words
	ExtremelyLongMsgKAT_168_24.txt	very long message KAT using seven 24-bit words
	ExtremelyLongMsgKAT_144_24.txt	very long message KAT using six 24-bit words
	ExtremelyLongMsgKAT_112_16.txt	very long message KAT using seven 16-bit words
	ExtremelyLongMsgKAT_96_16.txt	very long message KAT using six 16-bit words
	ExtremelyLongMsgKAT_144_16t.txt	very long message KAT using nine 16-bit words
	ExtremelyLongMsgKAT_288_32t.txt	very long message KAT using nine 32-bit words
	ExtremelyLongMsgKAT_576_64t.txt	very long message KAT using nine 64-bit words
	MonteCarlo_448_64.txt	Monte-Carlo KAT using seven 64-bit words
	MonteCarlo_448_56.txt	Monte-Carlo KAT using eight 56-bit words
	MonteCarlo_392_56.txt	Monte-Carlo KAT using seven 56-bit words
	MonteCarlo_336_56.txt	Monte-Carlo KAT using six 56-bit words
	MonteCarlo_384_48.txt	Monte-Carlo KAT using eight 48-bit words
	MonteCarlo_336_48.txt	Monte-Carlo KAT using seven 48-bit words
	MonteCarlo_288_48.txt	Monte-Carlo KAT using six 48-bit words
	MonteCarlo_320_40.txt	Monte-Carlo KAT using eight 40-bit words
	MonteCarlo_280_40.txt	Monte-Carlo KAT using seven 40-bit words
	MonteCarlo_240_40.txt	Monte-Carlo KAT using six 40-bit words
	MonteCarlo_192_32.txt	Monte-Carlo KAT using six 32-bit words
	MonteCarlo_192_24.txt	Monte-Carlo KAT using eight 24-bit words
	MonteCarlo_168_24.txt	Monte-Carlo KAT using seven 24-bit words
	MonteCarlo_144_24.txt	Monte-Carlo KAT using six 24-bit words
	MonteCarlo_112_16.txt	Monte-Carlo KAT using seven 16-bit words
	MonteCarlo_96_16.txt	Monte-Carlo KAT using six 16-bit words
	MonteCarlo_144_16t.txt	Monte-Carlo KAT using nine 16-bit words
	MonteCarlo_288_32t.txt	Monte-Carlo KAT using nine 32-bit words
	MonteCarlo_576_64t.txt	Monte-Carlo KAT using nine 64-bit words

Additional Implementations\Original KAT_MCT\Gate Reduced		subfolder with results for gate-reduced implementations
	Short Message KATs		subfolder - see below
	Long Message KATs		subfolder - see below
	Extremely Long Message KATs	subfolder - see below
	Monte-Carlo KATs		subfolder - see below

Additional Implementations\Original KAT_MCT\Gate Reduced\Short Message KATs	subfolder containing:
	ShortMsgKAT_512_64_56.txt	short message KAT using eight
					64-bit words reduced to 56 bits
	ShortMsgKAT_512_64_48.txt	short message KAT using eight
					64-bit words reduced to 48 bits
	ShortMsgKAT_512_64_40.txt	short message KAT using eight
					64-bit words reduced to 40 bits
	ShortMsgKAT_512_64_32.txt	short message KAT using eight
					64-bit words reduced to 32 bits
	ShortMsgKAT_512_64_24.txt	short message KAT using eight
					64-bit words reduced to 24 bits
	ShortMsgKAT_512_64_16.txt	short message KAT using eight
					64-bit words reduced to 16 bits
	ShortMsgKAT_448_64_56.txt	short message KAT using seven
					64-bit words reduced to 56 bits
	ShortMsgKAT_448_64_48.txt	short message KAT using seven
					64-bit words reduced to 48 bits
	ShortMsgKAT_448_64_40.txt	short message KAT using seven
					64-bit words reduced to 40 bits
	ShortMsgKAT_448_64_32.txt	short message KAT using seven
					64-bit words reduced to 32 bits
	ShortMsgKAT_448_64_24.txt	short message KAT using seven
					64-bit words reduced to 24 bits
	ShortMsgKAT_448_64_16.txt	short message KAT using seven
					64-bit words reduced to 16 bits
	ShortMsgKAT_384_64_56.txt	short message KAT using six
					64-bit words reduced to 56 bits
	ShortMsgKAT_384_64_48.txt	short message KAT using six
					64-bit words reduced to 48 bits
	ShortMsgKAT_384_64_40.txt	short message KAT using six
					64-bit words reduced to 40 bits
	ShortMsgKAT_384_64_32.txt	short message KAT using six
					64-bit words reduced to 32 bits
	ShortMsgKAT_384_64_24.txt	short message KAT using six
					64-bit words reduced to 24 bits
	ShortMsgKAT_384_64_16.txt	short message KAT using six
					64-bit words reduced to 16 bits
	ShortMsgKAT_448_56_48.txt	short message KAT using eight
					56-bit words reduced to 48 bits
	ShortMsgKAT_448_56_40.txt	short message KAT using eight
					56-bit words reduced to 40 bits
	ShortMsgKAT_448_56_32.txt	short message KAT using eight
					56-bit words reduced to 32 bits
	ShortMsgKAT_448_56_24.txt	short message KAT using eight
					56-bit words reduced to 24 bits
	ShortMsgKAT_448_56_16.txt	short message KAT using eight
					56-bit words reduced to 16 bits
	ShortMsgKAT_392_56_48.txt	short message KAT using seven
					56-bit words reduced to 48 bits
	ShortMsgKAT_392_56_40.txt	short message KAT using seven
					56-bit words reduced to 40 bits
	ShortMsgKAT_392_56_32.txt	short message KAT using seven
					56-bit words reduced to 32 bits
	ShortMsgKAT_392_56_24.txt	short message KAT using seven
					56-bit words reduced to 24 bits
	ShortMsgKAT_392_56_16.txt	short message KAT using seven
					56-bit words reduced to 16 bits
	ShortMsgKAT_336_56_48.txt	short message KAT using six
					56-bit words reduced to 48 bits
	ShortMsgKAT_336_56_40.txt	short message KAT using six
					56-bit words reduced to 40 bits
	ShortMsgKAT_336_56_32.txt	short message KAT using six
					56-bit words reduced to 32 bits
	ShortMsgKAT_336_56_24.txt	short message KAT using six
					56-bit words reduced to 24 bits
	ShortMsgKAT_336_56_16.txt	short message KAT using six
					56-bit words reduced to 16 bits
	ShortMsgKAT_384_48_40.txt	short message KAT using eight
					48-bit words reduced to 40 bits
	ShortMsgKAT_384_48_32.txt	short message KAT using eight
					48-bit words reduced to 32 bits
	ShortMsgKAT_384_48_24.txt	short message KAT using eight
					48-bit words reduced to 24 bits
	ShortMsgKAT_384_48_16.txt	short message KAT using eight
					48-bit words reduced to 16 bits
	ShortMsgKAT_336_48_40.txt	short message KAT using seven
					48-bit words reduced to 40 bits
	ShortMsgKAT_336_48_32.txt	short message KAT using seven
					48-bit words reduced to 32 bits
	ShortMsgKAT_336_48_24.txt	short message KAT using seven
					48-bit words reduced to 24 bits
	ShortMsgKAT_336_48_16.txt	short message KAT using seven
					48-bit words reduced to 16 bits
	ShortMsgKAT_288_48_40.txt	short message KAT using six
					48-bit words reduced to 40 bits
	ShortMsgKAT_288_48_32.txt	short message KAT using six
					48-bit words reduced to 32 bits
	ShortMsgKAT_288_48_24.txt	short message KAT using six
					48-bit words reduced to 24 bits
	ShortMsgKAT_288_48_16.txt	short message KAT using six
					48-bit words reduced to 16 bits
	ShortMsgKAT_320_40_32.txt	short message KAT using eight
					40-bit words reduced to 32 bits
	ShortMsgKAT_320_40_24.txt	short message KAT using eight
					40-bit words reduced to 24 bits
	ShortMsgKAT_320_40_16.txt	short message KAT using eight
					40-bit words reduced to 16 bits
	ShortMsgKAT_280_40_32.txt	short message KAT using seven
					40-bit words reduced to 32 bits
	ShortMsgKAT_280_40_24.txt	short message KAT using seven
					40-bit words reduced to 24 bits
	ShortMsgKAT_280_40_16.txt	short message KAT using seven
					40-bit words reduced to 16 bits
	ShortMsgKAT_240_40_32.txt	short message KAT using six
					40-bit words reduced to 32 bits
	ShortMsgKAT_240_40_24.txt	short message KAT using six
					40-bit words reduced to 24 bits
	ShortMsgKAT_240_40_16.txt	short message KAT using six
					40-bit words reduced to 16 bits
	ShortMsgKAT_256_32_24.txt	short message KAT using eight
					32-bit words reduced to 24 bits
	ShortMsgKAT_256_32_16.txt	short message KAT using eight
					32-bit words reduced to 16 bits
	ShortMsgKAT_224_32_24.txt	short message KAT using seven
					32-bit words reduced to 24 bits
	ShortMsgKAT_224_32_16.txt	short message KAT using seven
					32-bit words reduced to 16 bits
	ShortMsgKAT_192_32_24.txt	short message KAT using six
					32-bit words reduced to 24 bits
	ShortMsgKAT_192_32_16.txt	short message KAT using six
					32-bit words reduced to 16 bits
	ShortMsgKAT_192_24_16.txt	short message KAT using eight
					24-bit words reduced to 16 bits
	ShortMsgKAT_168_24_16.txt	short message KAT using seven
					24-bit words reduced to 16 bits
	ShortMsgKAT_144_24_16.txt	short message KAT using six
					24-bit words reduced to 16 bits

Additional Implementations\Original KAT_MCT\Gate Reduced\Long Message KATs	subfolder containing:
	LongMsgKAT_512_64_56.txt	long message KAT using eight
					64-bit words reduced to 56 bits
	LongMsgKAT_512_64_48.txt	long message KAT using eight
					64-bit words reduced to 48 bits
	LongMsgKAT_512_64_40.txt	long message KAT using eight
					64-bit words reduced to 40 bits
	LongMsgKAT_512_64_32.txt	long message KAT using eight
					64-bit words reduced to 32 bits
	LongMsgKAT_512_64_24.txt	long message KAT using eight
					64-bit words reduced to 24 bits
	LongMsgKAT_512_64_16.txt	long message KAT using eight
					64-bit words reduced to 16 bits
	LongMsgKAT_448_64_56.txt	long message KAT using seven
					64-bit words reduced to 56 bits
	LongMsgKAT_448_64_48.txt	long message KAT using seven
					64-bit words reduced to 48 bits
	LongMsgKAT_448_64_40.txt	long message KAT using seven
					64-bit words reduced to 40 bits
	LongMsgKAT_448_64_32.txt	long message KAT using seven
					64-bit words reduced to 32 bits
	LongMsgKAT_448_64_24.txt	long message KAT using seven
					64-bit words reduced to 24 bits
	LongMsgKAT_448_64_16.txt	long message KAT using seven
					64-bit words reduced to 16 bits
	LongMsgKAT_384_64_56.txt	long message KAT using six
					64-bit words reduced to 56 bits
	LongMsgKAT_384_64_48.txt	long message KAT using six
					64-bit words reduced to 48 bits
	LongMsgKAT_384_64_40.txt	long message KAT using six
					64-bit words reduced to 40 bits
	LongMsgKAT_384_64_32.txt	long message KAT using six
					64-bit words reduced to 32 bits
	LongMsgKAT_384_64_24.txt	long message KAT using six
					64-bit words reduced to 24 bits
	LongMsgKAT_384_64_16.txt	long message KAT using six
					64-bit words reduced to 16 bits
	LongMsgKAT_448_56_48.txt	long message KAT using eight
					56-bit words reduced to 48 bits
	LongMsgKAT_448_56_40.txt	long message KAT using eight
					56-bit words reduced to 40 bits
	LongMsgKAT_448_56_32.txt	long message KAT using eight
					56-bit words reduced to 32 bits
	LongMsgKAT_448_56_24.txt	long message KAT using eight
					56-bit words reduced to 24 bits
	LongMsgKAT_448_56_16.txt	long message KAT using eight
					56-bit words reduced to 16 bits
	LongMsgKAT_392_56_48.txt	long message KAT using seven
					56-bit words reduced to 48 bits
	LongMsgKAT_392_56_40.txt	long message KAT using seven
					56-bit words reduced to 40 bits
	LongMsgKAT_392_56_32.txt	long message KAT using seven
					56-bit words reduced to 32 bits
	LongMsgKAT_392_56_24.txt	long message KAT using seven
					56-bit words reduced to 24 bits
	LongMsgKAT_392_56_16.txt	long message KAT using seven
					56-bit words reduced to 16 bits
	LongMsgKAT_336_56_48.txt	long message KAT using six
					56-bit words reduced to 48 bits
	LongMsgKAT_336_56_40.txt	long message KAT using six
					56-bit words reduced to 40 bits
	LongMsgKAT_336_56_32.txt	long message KAT using six
					56-bit words reduced to 32 bits
	LongMsgKAT_336_56_24.txt	long message KAT using six
					56-bit words reduced to 24 bits
	LongMsgKAT_336_56_16.txt	long message KAT using six
					56-bit words reduced to 16 bits
	LongMsgKAT_384_48_40.txt	long message KAT using eight
					48-bit words reduced to 40 bits
	LongMsgKAT_384_48_32.txt	long message KAT using eight
					48-bit words reduced to 32 bits
	LongMsgKAT_384_48_24.txt	long message KAT using eight
					48-bit words reduced to 24 bits
	LongMsgKAT_384_48_16.txt	long message KAT using eight
					48-bit words reduced to 16 bits
	LongMsgKAT_336_48_40.txt	long message KAT using seven
					48-bit words reduced to 40 bits
	LongMsgKAT_336_48_32.txt	long message KAT using seven
					48-bit words reduced to 32 bits
	LongMsgKAT_336_48_24.txt	long message KAT using seven
					48-bit words reduced to 24 bits
	LongMsgKAT_336_48_16.txt	long message KAT using seven
					48-bit words reduced to 16 bits
	LongMsgKAT_288_48_40.txt	long message KAT using six
					48-bit words reduced to 40 bits
	LongMsgKAT_288_48_32.txt	long message KAT using six
					48-bit words reduced to 32 bits
	LongMsgKAT_288_48_24.txt	long message KAT using six
					48-bit words reduced to 24 bits
	LongMsgKAT_288_48_16.txt	long message KAT using six
					48-bit words reduced to 16 bits
	LongMsgKAT_320_40_32.txt	long message KAT using eight
					40-bit words reduced to 32 bits
	LongMsgKAT_320_40_24.txt	long message KAT using eight
					40-bit words reduced to 24 bits
	LongMsgKAT_320_40_16.txt	long message KAT using eight
					40-bit words reduced to 16 bits
	LongMsgKAT_280_40_32.txt	long message KAT using seven
					40-bit words reduced to 32 bits
	LongMsgKAT_280_40_24.txt	long message KAT using seven
					40-bit words reduced to 24 bits
	LongMsgKAT_280_40_16.txt	long message KAT using seven
					40-bit words reduced to 16 bits
	LongMsgKAT_240_40_32.txt	long message KAT using six
					40-bit words reduced to 32 bits
	LongMsgKAT_240_40_24.txt	long message KAT using six
					40-bit words reduced to 24 bits
	LongMsgKAT_240_40_16.txt	long message KAT using six
					40-bit words reduced to 16 bits
	LongMsgKAT_256_32_24.txt	long message KAT using eight
					32-bit words reduced to 24 bits
	LongMsgKAT_256_32_16.txt	long message KAT using eight
					32-bit words reduced to 16 bits
	LongMsgKAT_224_32_24.txt	long message KAT using seven
					32-bit words reduced to 24 bits
	LongMsgKAT_224_32_16.txt	long message KAT using seven
					32-bit words reduced to 16 bits
	LongMsgKAT_192_32_24.txt	long message KAT using six
					32-bit words reduced to 24 bits
	LongMsgKAT_192_32_16.txt	long message KAT using six
					32-bit words reduced to 16 bits
	LongMsgKAT_192_24_16.txt	long message KAT using eight
					24-bit words reduced to 16 bits
	LongMsgKAT_168_24_16.txt	long message KAT using seven
					24-bit words reduced to 16 bits
	LongMsgKAT_144_24_16.txt	long message KAT using six
					24-bit words reduced to 16 bits

Additional Implementations\Original KAT_MCT\Gate Reduced\Extremely Long Message KATs	subfolder containing:
	ExtremelyLongMsgKAT_512_64_56.txt	very long message KAT using eight
					64-bit words reduced to 56 bits
	ExtremelyLongMsgKAT_512_64_48.txt	very long message KAT using eight
					64-bit words reduced to 48 bits
	ExtremelyLongMsgKAT_512_64_40.txt	very long message KAT using eight
					64-bit words reduced to 40 bits
	ExtremelyLongMsgKAT_512_64_32.txt	very long message KAT using eight
					64-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_512_64_24.txt	very long message KAT using eight
					64-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_512_64_16.txt	very long message KAT using eight
					64-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_448_64_56.txt	very long message KAT using seven
					64-bit words reduced to 56 bits
	ExtremelyLongMsgKAT_448_64_48.txt	very long message KAT using seven
					64-bit words reduced to 48 bits
	ExtremelyLongMsgKAT_448_64_40.txt	very long message KAT using seven
					64-bit words reduced to 40 bits
	ExtremelyLongMsgKAT_448_64_32.txt	very long message KAT using seven
					64-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_448_64_24.txt	very long message KAT using seven
					64-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_448_64_16.txt	very long message KAT using seven
					64-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_384_64_56.txt	very long message KAT using six
					64-bit words reduced to 56 bits
	ExtremelyLongMsgKAT_384_64_48.txt	very long message KAT using six
					64-bit words reduced to 48 bits
	ExtremelyLongMsgKAT_384_64_40.txt	very long message KAT using six
					64-bit words reduced to 40 bits
	ExtremelyLongMsgKAT_384_64_32.txt	very long message KAT using six
					64-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_384_64_24.txt	very long message KAT using six
					64-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_384_64_16.txt	very long message KAT using six
					64-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_448_56_48.txt	very long message KAT using eight
					56-bit words reduced to 48 bits
	ExtremelyLongMsgKAT_448_56_40.txt	very long message KAT using eight
					56-bit words reduced to 40 bits
	ExtremelyLongMsgKAT_448_56_32.txt	very long message KAT using eight
					56-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_448_56_24.txt	very long message KAT using eight
					56-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_448_56_16.txt	very long message KAT using eight
					56-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_392_56_48.txt	very long message KAT using seven
					56-bit words reduced to 48 bits
	ExtremelyLongMsgKAT_392_56_40.txt	very long message KAT using seven
					56-bit words reduced to 40 bits
	ExtremelyLongMsgKAT_392_56_32.txt	very long message KAT using seven
					56-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_392_56_24.txt	very long message KAT using seven
					56-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_392_56_16.txt	very long message KAT using seven
					56-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_336_56_48.txt	very long message KAT using six
					56-bit words reduced to 48 bits
	ExtremelyLongMsgKAT_336_56_40.txt	very long message KAT using six
					56-bit words reduced to 40 bits
	ExtremelyLongMsgKAT_336_56_32.txt	very long message KAT using six
					56-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_336_56_24.txt	very long message KAT using six
					56-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_336_56_16.txt	very long message KAT using six
					56-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_384_48_40.txt	very long message KAT using eight
					48-bit words reduced to 40 bits
	ExtremelyLongMsgKAT_384_48_32.txt	very long message KAT using eight
					48-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_384_48_24.txt	very long message KAT using eight
					48-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_384_48_16.txt	very long message KAT using eight
					48-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_336_48_40.txt	very long message KAT using seven
					48-bit words reduced to 40 bits
	ExtremelyLongMsgKAT_336_48_32.txt	very long message KAT using seven
					48-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_336_48_24.txt	very long message KAT using seven
					48-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_336_48_16.txt	very long message KAT using seven
					48-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_288_48_40.txt	very long message KAT using six
					48-bit words reduced to 40 bits
	ExtremelyLongMsgKAT_288_48_32.txt	very long message KAT using six
					48-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_288_48_24.txt	very long message KAT using six
					48-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_288_48_16.txt	very long message KAT using six
					48-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_320_40_32.txt	very long message KAT using eight
					40-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_320_40_24.txt	very long message KAT using eight
					40-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_320_40_16.txt	very long message KAT using eight
					40-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_280_40_32.txt	very long message KAT using seven
					40-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_280_40_24.txt	very long message KAT using seven
					40-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_280_40_16.txt	very long message KAT using seven
					40-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_240_40_32.txt	very long message KAT using six
					40-bit words reduced to 32 bits
	ExtremelyLongMsgKAT_240_40_24.txt	very long message KAT using six
					40-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_240_40_16.txt	very long message KAT using six
					40-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_256_32_24.txt	very long message KAT using eight
					32-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_256_32_16.txt	very long message KAT using eight
					32-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_224_32_24.txt	very long message KAT using seven
					32-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_224_32_16.txt	very long message KAT using seven
					32-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_192_32_24.txt	very long message KAT using six
					32-bit words reduced to 24 bits
	ExtremelyLongMsgKAT_192_32_16.txt	very long message KAT using six
					32-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_192_24_16.txt	very long message KAT using eight
					24-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_168_24_16.txt	very long message KAT using seven
					24-bit words reduced to 16 bits
	ExtremelyLongMsgKAT_144_24_16.txt	very long message KAT using six
					24-bit words reduced to 16 bits

Additional Implementations\Original KAT_MCT\Gate Reduced\Monte-Carlo KATs	subfolder containing:
	MonteCarlo_512_64_56.txt	Monte-Carlo KAT using eight
					64-bit words reduced to 56 bits
	MonteCarlo_512_64_48.txt	Monte-Carlo KAT using eight
					64-bit words reduced to 48 bits
	MonteCarlo_512_64_40.txt	Monte-Carlo KAT using eight
					64-bit words reduced to 40 bits
	MonteCarlo_512_64_32.txt	Monte-Carlo KAT using eight
					64-bit words reduced to 32 bits
	MonteCarlo_512_64_24.txt	Monte-Carlo KAT using eight
					64-bit words reduced to 24 bits
	MonteCarlo_512_64_16.txt	Monte-Carlo KAT using eight
					64-bit words reduced to 16 bits
	MonteCarlo_448_64_56.txt	Monte-Carlo KAT using seven
					64-bit words reduced to 56 bits
	MonteCarlo_448_64_48.txt	Monte-Carlo KAT using seven
					64-bit words reduced to 48 bits
	MonteCarlo_448_64_40.txt	Monte-Carlo KAT using seven
					64-bit words reduced to 40 bits
	MonteCarlo_448_64_32.txt	Monte-Carlo KAT using seven
					64-bit words reduced to 32 bits
	MonteCarlo_448_64_24.txt	Monte-Carlo KAT using seven
					64-bit words reduced to 24 bits
	MonteCarlo_448_64_16.txt	Monte-Carlo KAT using seven
					64-bit words reduced to 16 bits
	MonteCarlo_384_64_56.txt	Monte-Carlo KAT using six
					64-bit words reduced to 56 bits
	MonteCarlo_384_64_48.txt	Monte-Carlo KAT using six
					64-bit words reduced to 48 bits
	MonteCarlo_384_64_40.txt	Monte-Carlo KAT using six
					64-bit words reduced to 40 bits
	MonteCarlo_384_64_32.txt	Monte-Carlo KAT using six
					64-bit words reduced to 32 bits
	MonteCarlo_384_64_24.txt	Monte-Carlo KAT using six
					64-bit words reduced to 24 bits
	MonteCarlo_384_64_16.txt	Monte-Carlo KAT using six
					64-bit words reduced to 16 bits
	MonteCarlo_448_56_48.txt	Monte-Carlo KAT using eight
					56-bit words reduced to 48 bits
	MonteCarlo_448_56_40.txt	Monte-Carlo KAT using eight
					56-bit words reduced to 40 bits
	MonteCarlo_448_56_32.txt	Monte-Carlo KAT using eight
					56-bit words reduced to 32 bits
	MonteCarlo_448_56_24.txt	Monte-Carlo KAT using eight
					56-bit words reduced to 24 bits
	MonteCarlo_448_56_16.txt	Monte-Carlo KAT using eight
					56-bit words reduced to 16 bits
	MonteCarlo_392_56_48.txt	Monte-Carlo KAT using seven
					56-bit words reduced to 48 bits
	MonteCarlo_392_56_40.txt	Monte-Carlo KAT using seven
					56-bit words reduced to 40 bits
	MonteCarlo_392_56_32.txt	Monte-Carlo KAT using seven
					56-bit words reduced to 32 bits
	MonteCarlo_392_56_24.txt	Monte-Carlo KAT using seven
					56-bit words reduced to 24 bits
	MonteCarlo_392_56_16.txt	Monte-Carlo KAT using seven
					56-bit words reduced to 16 bits
	MonteCarlo_336_56_48.txt	Monte-Carlo KAT using six
					56-bit words reduced to 48 bits
	MonteCarlo_336_56_40.txt	Monte-Carlo KAT using six
					56-bit words reduced to 40 bits
	MonteCarlo_336_56_32.txt	Monte-Carlo KAT using six
					56-bit words reduced to 32 bits
	MonteCarlo_336_56_24.txt	Monte-Carlo KAT using six
					56-bit words reduced to 24 bits
	MonteCarlo_336_56_16.txt	Monte-Carlo KAT using six
					56-bit words reduced to 16 bits
	MonteCarlo_384_48_40.txt	Monte-Carlo KAT using eight
					48-bit words reduced to 40 bits
	MonteCarlo_384_48_32.txt	Monte-Carlo KAT using eight
					48-bit words reduced to 32 bits
	MonteCarlo_384_48_24.txt	Monte-Carlo KAT using eight
					48-bit words reduced to 24 bits
	MonteCarlo_384_48_16.txt	Monte-Carlo KAT using eight
					48-bit words reduced to 16 bits
	MonteCarlo_336_48_40.txt	Monte-Carlo KAT using seven
					48-bit words reduced to 40 bits
	MonteCarlo_336_48_32.txt	Monte-Carlo KAT using seven
					48-bit words reduced to 32 bits
	MonteCarlo_336_48_24.txt	Monte-Carlo KAT using seven
					48-bit words reduced to 24 bits
	MonteCarlo_336_48_16.txt	Monte-Carlo KAT using seven
					48-bit words reduced to 16 bits
	MonteCarlo_288_48_40.txt	Monte-Carlo KAT using six
					48-bit words reduced to 40 bits
	MonteCarlo_288_48_32.txt	Monte-Carlo KAT using six
					48-bit words reduced to 32 bits
	MonteCarlo_288_48_24.txt	Monte-Carlo KAT using six
					48-bit words reduced to 24 bits
	MonteCarlo_288_48_16.txt	Monte-Carlo KAT using six
					48-bit words reduced to 16 bits
	MonteCarlo_320_40_32.txt	Monte-Carlo KAT using eight
					40-bit words reduced to 32 bits
	MonteCarlo_320_40_24.txt	Monte-Carlo KAT using eight
					40-bit words reduced to 24 bits
	MonteCarlo_320_40_16.txt	Monte-Carlo KAT using eight
					40-bit words reduced to 16 bits
	MonteCarlo_280_40_32.txt	Monte-Carlo KAT using seven
					40-bit words reduced to 32 bits
	MonteCarlo_280_40_24.txt	Monte-Carlo KAT using seven
					40-bit words reduced to 24 bits
	MonteCarlo_280_40_16.txt	Monte-Carlo KAT using seven
					40-bit words reduced to 16 bits
	MonteCarlo_240_40_32.txt	Monte-Carlo KAT using six
					40-bit words reduced to 32 bits
	MonteCarlo_240_40_24.txt	Monte-Carlo KAT using six
					40-bit words reduced to 24 bits
	MonteCarlo_240_40_16.txt	Monte-Carlo KAT using six
					40-bit words reduced to 16 bits
	MonteCarlo_256_32_24.txt	Monte-Carlo KAT using eight
					32-bit words reduced to 24 bits
	MonteCarlo_256_32_16.txt	Monte-Carlo KAT using eight
					32-bit words reduced to 16 bits
	MonteCarlo_224_32_24.txt	Monte-Carlo KAT using seven
					32-bit words reduced to 24 bits
	MonteCarlo_224_32_16.txt	Monte-Carlo KAT using seven
					32-bit words reduced to 16 bits
	MonteCarlo_192_32_24.txt	Monte-Carlo KAT using six
					32-bit words reduced to 24 bits
	MonteCarlo_192_32_16.txt	Monte-Carlo KAT using six
					32-bit words reduced to 16 bits
	MonteCarlo_192_24_16.txt	Monte-Carlo KAT using eight
					24-bit words reduced to 16 bits
	MonteCarlo_168_24_16.txt	Monte-Carlo KAT using seven
					24-bit words reduced to 16 bits
	MonteCarlo_144_24_16.txt	Monte-Carlo KAT using six
					24-bit words reduced to 16 bits

Additional Implementations\Original KAT_MCT\Intermediate Values		subfolder containing:
	VerboseMsgKAT_512_64.txt	intermediate values using eight 64-bit words
	VerboseMsgKAT_384_64.txt	intermediate values using six 64-bit words
	VerboseMsgKAT_256_32.txt	intermediate values using eight 32-bit words
	VerboseMsgKAT_224_32.txt	intermediate values using seven 32-bit words
	VerboseMsgKAT_128_16.txt	intermediate values using eight 16-bit words
	VerboseMsgKAT_160_16t.txt	intermediate values using ten 16-bit words
	VerboseMsgKAT_320_32t.txt	intermediate values using ten 32-bit words
	VerboseMsgKAT_640_64t.txt	intermediate values using ten 64-bit words
	Other Word Sizes		subfolder - see below
	Gate Reduced			subfolder - see below

Additional Implementations\Original KAT_MCT\Intermediate Values\Other Word Sizes	subfolder containing:
	VerboseMsgKAT_448_64.txt	intermediate values using seven 64-bit words
	VerboseMsgKAT_448_56.txt	intermediate values using eight 56-bit words
	VerboseMsgKAT_392_56.txt	intermediate values using seven 56-bit words
	VerboseMsgKAT_336_56.txt	intermediate values using six 56-bit words
	VerboseMsgKAT_384_48.txt	intermediate values using eight 48-bit words
	VerboseMsgKAT_336_48.txt	intermediate values using seven 48-bit words
	VerboseMsgKAT_288_48.txt	intermediate values using six 48-bit words
	VerboseMsgKAT_320_40.txt	intermediate values using eight 40-bit words
	VerboseMsgKAT_280_40.txt	intermediate values using seven 40-bit words
	VerboseMsgKAT_240_40.txt	intermediate values using six 40-bit words
	VerboseMsgKAT_192_32.txt	intermediate values using six 32-bit words
	VerboseMsgKAT_192_24.txt	intermediate values using eight 24-bit words
	VerboseMsgKAT_168_24.txt	intermediate values using seven 24-bit words
	VerboseMsgKAT_144_24.txt	intermediate values using six 24-bit words
	VerboseMsgKAT_112_16.txt	intermediate values using seven 16-bit words
	VerboseMsgKAT_96_16.txt		intermediate values using six 16-bit words
	VerboseMsgKAT_144_16t.txt	intermediate values using nine 16-bit words
	VerboseMsgKAT_288_32t.txt	intermediate values using nine 32-bit words
	VerboseMsgKAT_576_64t.txt	intermediate values using nine 64-bit words

Additional Implementations\Original KAT_MCT\Intermediate Values\Gate Reduced	subfolder containing:
	VerboseMsgKAT_512_64_56.txt	intermediate values using eight
					64-bit words reduced to 56 bits
	VerboseMsgKAT_512_64_48.txt	intermediate values using eight
					64-bit words reduced to 48 bits
	VerboseMsgKAT_512_64_40.txt	intermediate values using eight
					64-bit words reduced to 40 bits
	VerboseMsgKAT_512_64_32.txt	intermediate values using eight
					64-bit words reduced to 32 bits
	VerboseMsgKAT_512_64_24.txt	intermediate values using eight
					64-bit words reduced to 24 bits
	VerboseMsgKAT_512_64_16.txt	intermediate values using eight
					64-bit words reduced to 16 bits
	VerboseMsgKAT_448_64_56.txt	intermediate values using seven
					64-bit words reduced to 56 bits
	VerboseMsgKAT_448_64_48.txt	intermediate values using seven
					64-bit words reduced to 48 bits
	VerboseMsgKAT_448_64_40.txt	intermediate values using seven
					64-bit words reduced to 40 bits
	VerboseMsgKAT_448_64_32.txt	intermediate values using seven
					64-bit words reduced to 32 bits
	VerboseMsgKAT_448_64_24.txt	intermediate values using seven
					64-bit words reduced to 24 bits
	VerboseMsgKAT_448_64_16.txt	intermediate values using seven
					64-bit words reduced to 16 bits
	VerboseMsgKAT_384_64_56.txt	intermediate values using six
					64-bit words reduced to 56 bits
	VerboseMsgKAT_384_64_48.txt	intermediate values using six
					64-bit words reduced to 48 bits
	VerboseMsgKAT_384_64_40.txt	intermediate values using six
					64-bit words reduced to 40 bits
	VerboseMsgKAT_384_64_32.txt	intermediate values using six
					64-bit words reduced to 32 bits
	VerboseMsgKAT_384_64_24.txt	intermediate values using six
					64-bit words reduced to 24 bits
	VerboseMsgKAT_384_64_16.txt	intermediate values using six
					64-bit words reduced to 16 bits
	VerboseMsgKAT_448_56_48.txt	intermediate values using eight
					56-bit words reduced to 48 bits
	VerboseMsgKAT_448_56_40.txt	intermediate values using eight
					56-bit words reduced to 40 bits
	VerboseMsgKAT_448_56_32.txt	intermediate values using eight
					56-bit words reduced to 32 bits
	VerboseMsgKAT_448_56_24.txt	intermediate values using eight
					56-bit words reduced to 24 bits
	VerboseMsgKAT_448_56_16.txt	intermediate values using eight
					56-bit words reduced to 16 bits
	VerboseMsgKAT_392_56_48.txt	intermediate values using seven
					56-bit words reduced to 48 bits
	VerboseMsgKAT_392_56_40.txt	intermediate values using seven
					56-bit words reduced to 40 bits
	VerboseMsgKAT_392_56_32.txt	intermediate values using seven
					56-bit words reduced to 32 bits
	VerboseMsgKAT_392_56_24.txt	intermediate values using seven
					56-bit words reduced to 24 bits
	VerboseMsgKAT_392_56_16.txt	intermediate values using seven
					56-bit words reduced to 16 bits
	VerboseMsgKAT_336_56_48.txt	intermediate values using six
					56-bit words reduced to 48 bits
	VerboseMsgKAT_336_56_40.txt	intermediate values using six
					56-bit words reduced to 40 bits
	VerboseMsgKAT_336_56_32.txt	intermediate values using six
					56-bit words reduced to 32 bits
	VerboseMsgKAT_336_56_24.txt	intermediate values using six
					56-bit words reduced to 24 bits
	VerboseMsgKAT_336_56_16.txt	intermediate values using six
					56-bit words reduced to 16 bits
	VerboseMsgKAT_384_48_40.txt	intermediate values using eight
					48-bit words reduced to 40 bits
	VerboseMsgKAT_384_48_32.txt	intermediate values using eight
					48-bit words reduced to 32 bits
	VerboseMsgKAT_384_48_24.txt	intermediate values using eight
					48-bit words reduced to 24 bits
	VerboseMsgKAT_384_48_16.txt	intermediate values using eight
					48-bit words reduced to 16 bits
	VerboseMsgKAT_336_48_40.txt	intermediate values using seven
					48-bit words reduced to 40 bits
	VerboseMsgKAT_336_48_32.txt	intermediate values using seven
					48-bit words reduced to 32 bits
	VerboseMsgKAT_336_48_24.txt	intermediate values using seven
					48-bit words reduced to 24 bits
	VerboseMsgKAT_336_48_16.txt	intermediate values using seven
					48-bit words reduced to 16 bits
	VerboseMsgKAT_288_48_40.txt	intermediate values using six
					48-bit words reduced to 40 bits
	VerboseMsgKAT_288_48_32.txt	intermediate values using six
					48-bit words reduced to 32 bits
	VerboseMsgKAT_288_48_24.txt	intermediate values using six
					48-bit words reduced to 24 bits
	VerboseMsgKAT_288_48_16.txt	intermediate values using six
					48-bit words reduced to 16 bits
	VerboseMsgKAT_320_40_32.txt	intermediate values using eight
					40-bit words reduced to 32 bits
	VerboseMsgKAT_320_40_24.txt	intermediate values using eight
					40-bit words reduced to 24 bits
	VerboseMsgKAT_320_40_16.txt	intermediate values using eight
					40-bit words reduced to 16 bits
	VerboseMsgKAT_280_40_32.txt	intermediate values using seven
					40-bit words reduced to 32 bits
	VerboseMsgKAT_280_40_24.txt	intermediate values using seven
					40-bit words reduced to 24 bits
	VerboseMsgKAT_280_40_16.txt	intermediate values using seven
					40-bit words reduced to 16 bits
	VerboseMsgKAT_240_40_32.txt	intermediate values using six
					40-bit words reduced to 32 bits
	VerboseMsgKAT_240_40_24.txt	intermediate values using six
					40-bit words reduced to 24 bits
	VerboseMsgKAT_240_40_16.txt	intermediate values using six
					40-bit words reduced to 16 bits
	VerboseMsgKAT_256_32_24.txt	intermediate values using eight
					32-bit words reduced to 24 bits
	VerboseMsgKAT_256_32_16.txt	intermediate values using eight
					32-bit words reduced to 16 bits
	VerboseMsgKAT_224_32_24.txt	intermediate values using seven
					32-bit words reduced to 24 bits
	VerboseMsgKAT_224_32_16.txt	intermediate values using seven
					32-bit words reduced to 16 bits
	VerboseMsgKAT_192_32_24.txt	intermediate values using six
					32-bit words reduced to 24 bits
	VerboseMsgKAT_192_32_16.txt	intermediate values using six
					32-bit words reduced to 16 bits
	VerboseMsgKAT_192_24_16.txt	intermediate values using eight
					24-bit words reduced to 16 bits
	VerboseMsgKAT_168_24_16.txt	intermediate values using seven
					24-bit words reduced to 16 bits
	VerboseMsgKAT_144_24_16.txt	intermediate values using six
					24-bit words reduced to 16 bits

<end of file>
