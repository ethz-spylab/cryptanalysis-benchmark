#Overview

This submission contains implementations of SecureRF's "WalnutDSA" algorithms.  Provided for WalnutDSA are 2 security level implementations with 3 variations per security level each.  For Kayawood we've included 2 security level implementations with 1 variation per security level. 

For Walnut, the only functional difference between the 3 variations per security level is the method used to "rewrite" the signature in the final step of signature generation.  These 3 variations are as follows:

	BKL - Stored in crypto_sign/walnut*/bkl
	Stochastic Rewriting - Stored in crypto_sign/walnut*/stochasticrewrite
	Stochastic Rewriting w/o Dehornoy - Stored in crypto_sign/walnut*/stochasticrewritenodehornoy
	
Please see the accompanying design spec for detailed descriptions about these rewrite methods.


The reference implementations do not contain seperate folders for each of these security levels and variants, but instead leave it to the user to swap out #defines in api.h and/or ae_crypto.h to switch between security levels and rewrite methods.

#Building

The Supporting_Documentation folder contains (among other things) a main.c, rng.c/h (NIST provided), crypto_sign.h, PQCgenKAT_kem.c, PQCgenKAT_sign.c and Makefile.

Makefile:

	By default this Makefile is configured to compile the reference implementation of WalnutDSA using the simple main.c provided in this directory.  This implementation uses the randombytes() method in rng.c/h and openssl for SHA256 and SHA512, provided the code is compiled with the WORKING_COPY flag.
	
	PLEASE NOTE: The WORKING_COPY flag must be enabled to correctly compile this code outside of the SUPERCOP framework.  Calls to SUPERCOP specific hash functions will cause compile errors. 
	
	The "TARGET" and "VARIATION" variables in the makefile can be altered to change the security level and rewriting methods, respectively.  These two variable simply change what directory of Optimized_Implementation/crypto_sign/ or crypto_kem code is pulled from.
	
	Please note that for reference implementation builds (VARIATION=ref) rewriting methods must be changed by altering the #defines declared in api.h.
	
	If desired, the user can include SUPERCOP's try.c/h, try-anything.c/h, measure.c/h and measure-anything.c/h files with few modifications by including these files (not included in this package) in this directory as well as any additional dependencies (such as cpucycles.c/osfreq.c, etc).
	
	Finally, the flag KAT_INTERMEDIATES can be added to print out a wide range of data for debugging purposes

	Below is a full list of the possible Makefile TARGET and VARIATION combinations and a quick description:

			TARGET=walnut128
				VARIATION=	bkl - 128 Security level optimized WalnutDSA using the BKL rewriting method
							stochasticrewrite - 128 Security level optimized WalnutDSA using the stochastic rewriting method followed by a round of dehornoy reduction
							stochasticrewritenodehornoy - 128 Security level optimized WalnutDSA using the stochastic rewriting method *without* dehornoy
							ref - 128 Security level reference implementation.  Rewriting method can be changed by altering api.h
			TARGET=walnut256
				VARIATION=	bkl - 256 Security level optimized WalnutDSA using the BKL rewriting method
							stochasticrewrite - 256 Security level optimized WalnutDSA using the stochastic rewriting method followed by a round of dehornoy reduction
							stochasticrewritenodehornoy - 256 Security level optimized WalnutDSA using the stochastic rewriting method *without* dehornoy
							ref - 256 Security level reference implementation.  Rewriting method can be changed by altering api.h


#File Descriptions - Supporting_Documentation

	crypto_sign.h - Defines some constants used by main.c
	main.c - Runs one loop of the WalnutDSA key generation, signature generation and signature verification cycle or Kayawood keypair generation and shared secret calculation.
	Makefile - See above
	rng.c/h - Provided by NIST, included here for randombytes()
	WalnutDSA_Cover_Sheet.pdf - NIST's required cover sheet for this submission
	walnutdsa-specification.pdf - The method specification
	walnutdsa.pdf - The academic paper referenced in the specification
	PQCgenKAT_kem.c - NIST provided KAT generator for key encapsulation mechanisms
	PQCgenKAT_sign.c - NIST provided KAT generator for digital signature algorithms

#File Descriptions - KAT

	intermediates - This folder contains 1 intermediate data file per implementation
	walnut128 - This folder provides script generated KAT data for all walnut128 implementations
	walnut256 - This folder provides script generated KAT data for all walntu256 implementations
	
#File Descriptions - Optimized_Implementation

	Optimized_Implementation/crypto_sign/walnut128/bkl:
	
		ae_config.h - General configuration #defines
		ae_crypto.c/.h - These files contain the code used for signature verification. 
		ae_dsa.c/h - Contain code for WalnutDSA public/private key generation and signature generation
		aekeys.h - Defines structures used for public/private keys
		aelib.h - Consolidates #includes
		aetypes.h - Defines frequently used primitives
		aeutil.h - Defines frequently used system calls
		api.h - SUPERCOP required header file used to define maximum signature/public key/private key sizes.  Also declares a #define for the rewrite method of the current directory.  This is one of only a few files actually different between each implementation.
		bands.c/h - Defines band behavior, specifically for use with the BKL rewriting algorithm
		braids.c/.h - General purpose file for forming and manipulating braids
		constants.h - Another file that changes between implementations, this file defines security level, bit packing variables, and other information that changes between implementations
		dehornoy.c/h - Defines dehornoy rewriting functionality
		emultiply.c/.h - E-Multiply methods used specifically during key generation
		FF2.c/FF2.h/FFmod.c/FFmod.h/FFprime.c/FFprime.h/finitefields.c/finitefields.h/primefields.c/.h - Files that define various finite field functionality
		hash.c/.h -  Reponsible for hashing messages during signature generation and verification.  Which hash method used is controlled by #defines in constants.h
		keygen.c/.h - Utility class used for public and private key generation as well as cloaking element generation
		obfuscate.c/.h - Reponsible for calling rewrite functions.  Which rewrite function is called is controlled by #defines in constants.h
		pack.c/.h - Pack utilities for packing/unpacking keys/signatures
		sign.c - SUPERCOP required file responsible for defining outlets for key generation, signature generation and signature validation
		
	Optimized_Implementation/crypto_sign/walnut128/stochasticrewrite:
	
		All files from here are inherited from walnut128/bkl with the exception of:
		
		api.h - Defines different signature and key sizes as well as a #define that compiles stochastic rewriting code in obfuscate.c
		y-gen.c/h - Responsible for stochastic rewriting functionality
		
	Optimized_Implementation/crypto_sign/walnut128/stochasticrewritenodehornoy:
	
		All files from here are inherited from walnut128/stochasticrewrite with the exception of:
		
		api.h - Defines different signature and key sizes as well as a #define that compiles stochastic rewriting (no dehornoy) code in obfuscate.c
		
	Optimized_Implementation/crypto_sign/walnut256/bkl:
	
		All files from here are inherited from walnut128/bkl with the exception of:
		
		api.h - Defines different signature and key sizes as well as a #define that compiles bkl rewriting code in obfuscate.c
		constants.h - Declares different security level, packing constants and hash sizes based on the 256 security level
		
	Optimized_Implementation/crypto_sign/walnut256/stochasticrewrite:
	
		All files from here are inherited from walnut256/bkl with the exception of:
		
		api.h - Defines different signature and key sizes as well as a #define that compiles stochastic rewriting code in obfuscate.c
		
	Optimized_Implementation/crypto_sign/walnut256/stochasticrewritenodehornoy:
	
		All files from here are inherited from walnut256/stochasticrewrite with the exception of:
		
		api.h - Defines different signature and key sizes as well as a #define that compiles stochastic rewriting (no dehornoy) code in obfuscate.c
		


#File Descriptions - Reference_Implementation

	walnut:
		ae_crypto.c/h - Contains the bulk of the algorithmic work of WalnutDSA including key generation, signature generation, rewriting methods, signature verification, etc
		ae_lib.c/.h - Contains utility methods such as hash functions, packing functions, random number generation, etc
		api.h - Controls which rewriting method and security levels are used through the use of #defines
		sign.c - Similar to the optimized implementation, this file has been included in case the user wants to run the reference implementation through SUPERCOP

