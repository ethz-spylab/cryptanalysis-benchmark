/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#include <stdio.h>
#include <limits.h> 
#include "FFprime.h"

/* Definition of the FFprime interface; it's a finite field with local data */
typedef struct SrfFFprime_ {
  SrfFiniteField  ff;
  // my local parameters here:
  unsigned int order;
} SrfFFprime;

static inline int FFprimecheckbit(FFprimeelem a, int position)
{
  return (a & (1<<(position)));
}

static inline int FFprimeelemiszero(FFprimeelem a)
{
  return (a==0);
}


static inline FFprimeelem FFprimereduce(FFprimeelem a, unsigned int p) 
{
  return ((a)%(p)<0 ? ((a)%(p)+(p)) : (a)%(p));
}

static inline FFprimeelem FFprimeneg(FFprimeelem a, unsigned int p)
{
  return FFprimereduce(-a,p);
}

static inline FFprimeelem FFprimeadd(FFprimeelem a, FFprimeelem b, unsigned int p) 
{
  return FFprimereduce(a+b, p);
}

static inline FFprimeelem FFprimemult(FFprimeelem a, FFprimeelem b, unsigned int p)
{
  return FFprimereduce(a*b,p);
}

static inline int FFprimeisoddlong(long a)
{
  return ((a)%2);
}

static inline int FFprimeisevenlong(long a)
{
  return (!FFprimeisoddlong(a));
}

/* Construct multiplicative inverses using the extended Euclidean */
/* algorithm.  Algorithm is Algorithm 2.22, Binary inversion algorithm */
/* in F_p, from Hankerson, et al, Guide to elliptic curve */
/* cryptography.   */

static inline FFprimeelem FFprimeinverse(FFprimeelem a, unsigned int p)
{
  long int u, v, x1, x2, ainv;

  u=a, v=p;
  x1=1, x2=0;
  while (u != 1 && v !=1) {
    while (FFprimeisevenlong(u)) {
      u /= 2;
      if (FFprimeisevenlong(x1)) {
	x1 /= 2;
      }
      else {
	x1 = ((x1+p)/2);
      }
      printf("FFprimeisevenlong(u): %ld %ld %ld %ld\n", u,v,x1,x2);
    }
    while (FFprimeisevenlong(v)) {
      v /= 2;
      if (FFprimeisevenlong(x2)) {
	x2 /= 2;
      }
      else {
	x2 = ((x2+p)/2);
      }
      printf("FFprimeisevenlong(v): %ld %ld %ld %ld\n", u,v,x1,x2);
    }
    if ((u-v)>=0) {
      u=u-v, x1=x1-x2;
    }
    else {
      v=v-u, x2=x2-x1;
    }
    printf("ATBOTTOM: %ld %ld %ld %ld\n", u,v,x1,x2);
  }
  if (u==1) {
    long x1mp = x1 % p;
    ainv = x1mp < 0 ? x1mp + p : x1mp;
  }
  else {
    long x2mp = x2 % p;
    ainv = x2mp < 0 ? x2mp + p : x2mp;
  }
  printf("1/a is %ld\n",ainv);
  if (ainv >= UINT_MAX) {
    fprintf(stderr, "overflow in FFprimeeleminverse! input was (a,p) = %d, %d\n",a,p);
  }
  return ((FFprimeelem) ainv);
}

static inline FFprimeelem FFprimeneginverse(FFprimeelem a, unsigned int p)
{
  return (FFprimeinverse(-a, p));
}

static inline FFprimeelem FFprimedivide(FFprimeelem a, FFprimeelem b, unsigned int p)
{
  if (!FFprimeelemiszero(b)) {
    return FFprimemult(a,FFprimeinverse(b, p),p);
  }
}

/****************************************************************/
/* "Public" APIs: */

static ffelem ffprimeneg(const SrfFiniteField* ff, ffelem a)
{
  const SrfFFprime* ffprime = (const SrfFFprime*) ff;
  return (ffelem) FFprimeneg(a,ffprime->order);
}

static ffelem ffprimeinverse(const SrfFiniteField* ff, ffelem a)
{
  const SrfFFprime* ffprime = (const SrfFFprime*) ff;
  return (ffelem) FFprimeinverse(a, ffprime->order);
}

static ffelem ffprimeneginverse(const SrfFiniteField* ff, ffelem a)
{
  const SrfFFprime* ffprime = (const SrfFFprime*) ff;
  return (ffelem) FFprimeneginverse(a,ffprime->order);
}

static ffelem ffprimeadd(const SrfFiniteField* ff, ffelem a, ffelem b)
{
  const SrfFFprime* ffprime = (const SrfFFprime*) ff;
  return (ffelem) FFprimeadd(a, b, ffprime->order);
}

static ffelem ffprimemult(const SrfFiniteField* ff, ffelem a, ffelem b)
{
  const SrfFFprime* ffprime = (const SrfFFprime*) ff;
  return (ffelem) FFprimemult(a, b, ffprime->order);
}

static ffelem ffprimereduce(const SrfFiniteField* ff, ffelem a)
{
  const SrfFFprime* ffprime = (const SrfFFprime*) ff;
  return (ffelem) FFprimereduce(a,ffprime->order);
}

/****************************************************************/

// parameter is order of finite field
#define DEFINE_FF(num)	\
  {  num, ffprimeneg, ffprimeinverse, ffprimeneginverse, ffprimeadd, ffprimemult, ffprimereduce }

static SrfFFprime ffFields[] = {
#ifdef ENABLE_FIELD_13
    DEFINE_FF(13),
#endif
#ifdef ENABLE_FIELD_2147483647
    DEFINE_FF(2147483647),
#endif
};
#define NUM_FIELDS (sizeof(ffFields)/sizeof(*ffFields))

extern const SrfFiniteField* ffprimeGetFF(ffelem primepower)
{
  int i;
  for (i = 0; i < NUM_FIELDS; i++) {
    if (ffFields[i].ff.primepower == primepower)
      return &ffFields[i].ff;
  }
  return NULL;
}

