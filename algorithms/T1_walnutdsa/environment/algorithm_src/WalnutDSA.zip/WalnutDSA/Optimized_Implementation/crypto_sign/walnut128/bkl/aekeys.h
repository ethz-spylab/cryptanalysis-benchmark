/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * aekeys.h
 */
#ifndef AEKEYS_H
#define AEKEYS_H 1
/* includes */
#include <stdio.h>
#include "braids.h"

/* constants */

/* structures/datatypes */
/*
 * Private key consists of two parts;
 *    part 1 contains the CB list and its permutation
 *    part 2 contains the braidlist generators
 */
typedef struct _aePrivateKey {
    ae_pcbdata_t part1;
    ae_plist_t part2;
} ae_privateKey_t, *ae_pPrivateKey_t;
/*
 * public key consists of the CB list and its permuation
 */
typedef struct _aePublicKey {
    ae_pcbdata_t pk;
} ae_publicKey_t, *ae_pPublicKey_t;
/*
 * exchange key consisting of the CB list and its permutation
 */
typedef struct _aeExchangeKey {
    ae_pcbdata_t ek;
} ae_exchangeKey_t, *ae_pExchangeKey_t;

#endif /* AEKEYS_H */
