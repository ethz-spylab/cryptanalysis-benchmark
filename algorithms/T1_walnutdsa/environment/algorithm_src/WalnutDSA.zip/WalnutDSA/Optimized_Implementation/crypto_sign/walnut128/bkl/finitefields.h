/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#ifndef FINITEFIELDS_H
#define FINITEFIELDS_H

typedef unsigned ffelem;

// these are the functions that any finite field implementation must support
typedef struct SrfFiniteField_ {
  ffelem primepower;

  ffelem (*neg)(const struct SrfFiniteField_*, ffelem a);
  ffelem (*inverse)(const struct SrfFiniteField_*, ffelem a); 
  ffelem (*neginverse)(const struct SrfFiniteField_*, ffelem a); 
  ffelem (*add)(const struct SrfFiniteField_*, ffelem a, ffelem b);
  ffelem (*mult)(const struct SrfFiniteField_*, ffelem a, ffelem b);
  ffelem (*reduce)(const struct SrfFiniteField_*, ffelem a);
} SrfFiniteField;

const SrfFiniteField* getFiniteField(ffelem primepower);

#endif
