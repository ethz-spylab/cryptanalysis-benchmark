/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#include "finitefields.h"
#include "FFmod.h"
#include "FF2.h"
#include "primefields.h"
#include <stdio.h>  // for NULL

extern const SrfFiniteField* getFiniteField(ffelem primepower)
{
  const SrfFiniteField *ff = ffGetFF(primepower);
  if (NULL == ff)
    ff = ff2GetFF(primepower);
  if (NULL == ff)
    ff = ffGetPrimeField(primepower);
  return ff;
}




