/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/
#ifdef KAT_INTERMEDIATES

#include <stdio.h>
#include "printUtils.h"
#include "ae_crypto.h"

void printBraid(unsigned char *braid,  char *name)
{
	printf("%s:\n",name);

	int sig_length = ((((braid[0] << 8) | braid[1]) + 1)/2) + 2;
	int i = 0, count = 0;
	for(i=0; i<sig_length; i++)
	{
        count++;
		printf("%02x,\t", braid[i]);
        if(count == 8)
        {
            printf("\n");
            count = 0;
        }   
	}	
	printf("\n");

	fflush(stdout);
}

void printplist(ae_plist_t braid,  char *name)
{
	printf("%s:\n",name);

	int i = 0, count = 0;
	for(i=0; i<braid->len; i++)
	{
        count++;
		if(braid->b[i].u == -1)
			printf("-");

		printf("%d\t", braid->b[i].l - 1);
        if(count == 8)
        {
            printf("\n");
            count = 0;
        }
        
            
	}	
	printf("\n");

	fflush(stdout);
}

void print_column_major_matrix(uint8_t matrix[WALNUT_BRAID][WALNUT_BRAID],  char *name)
{
	int i, j, count = 0;
	printf("%s\n", name);

	for(i=0; i<WALNUT_BRAID; i++) {
	        for(j=0; j<WALNUT_BRAID; j++) {
				printf("%02x,\t", matrix[j][i]);
			}
			printf("\n");
	}

	printf("\n");
}

static uint8_t extract_elem(const uint8_t *in, size_t curr_bit, uint8_t packwidth)
{
    /* Element to be returned */
    uint8_t ret = 0;

    /* The mask used to return the extracted element */
    uint8_t mask = 0xFF >> (8 - packwidth);

    /* The amount by which to shift the byte(s) of input buffer in */
    int8_t shiftby = (8 - packwidth) - (curr_bit % 8);

    /* curr_bit is the location of the first bit
       addr is the location of the byte that contains this bit */
    size_t addr = curr_bit / 8;

    /* If shiftby is negative, the bits needed for the extracted element are
       located at both the current buffer address and the next buffer
       address */
    if(shiftby < 0) {

        /* Entry at current buffer address */
        uint8_t entry1 = in[addr];

        /* Entry at incremented buffer address */
        uint8_t entry2 = in[addr + 1];

        /* shiftby for entry2 */
        uint8_t t = 8 + shiftby;

        /* Extracted bits from entry1, shifted into the proper place */
        ret = (entry1 << -shiftby);

        /* Extracted bits from entry2, shifted into the proper place */
        ret |= (entry2 >> t) & mask;

    /* Else, the bits are all located at the current buffer address */
    } else {

        /* Entry at current buffer address */
        uint8_t entry = in[addr];

        /* Shift the entry */
        ret = (entry >> shiftby);
    }

    return ret & mask;
}

void unpack_and_print_matrix(uint8_t *matrix,  char *name)
{
	int i,j, count = 0;
	printf("%s\n", name);

	for(i=0; i < 3; i++)
	{
		printf("%02x\t", matrix[i]);
	}
	printf("\n");

	for(i=0; i<8; i++) {
		count++;
		printf("%02x\t", extract_elem(&matrix[3], i * 5, 5));
	}

	printf("\n");

	for(i=0; i<WALNUT_BRAID; i++) {
	        for(j=0; j<WALNUT_BRAID; j++) {
	        	printf("%02x\t", extract_elem(&matrix[8],
	        	                5 * (j + (i * WALNUT_BRAID)), 5));
	        }
	        printf("\n");
	}

	printf("\n");
}

void printBuffer(unsigned char *braid, size_t size,  char *name)
{
	printf("%s:\n",name);

	int i = 0, count = 0;
	for(i=0; i<size; i++)
	{
        count++;
		printf("%02x,\t", braid[i]);
        if(count == 8)
        {
            printf("\n");
            count = 0;
        }
	}	
	printf("\n");
}
#endif