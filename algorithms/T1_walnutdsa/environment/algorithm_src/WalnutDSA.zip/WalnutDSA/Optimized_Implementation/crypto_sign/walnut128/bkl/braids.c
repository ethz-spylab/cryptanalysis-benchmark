/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * braids.c - braid group related functions
 */
#include "aelib.h"
#include <math.h>
#include <assert.h>

#ifdef WORKING_COPY
#include "rng.h"
#else
#include "randombytes.h"
#endif

#ifndef RANDOM_FILE
#define RANDOM_FILE       "/dev/random"
#endif
static FILE *randstream = NULL;

/*
 * Global data
 */
const SrfFiniteField* g_ffield = NULL;

/*
 * Constants
 */
#define m16Long    65536L	 /* 2^16 */
#define m16Mask    0xFFFF        /* mask for lower 16 bits */
#define m15Mask    0x7FFF	 /* mask for lower 15 bits */
#define m31Mask    0x7FFFFFFF    /* mask for 31 bits */
/*
 * static  data
 */
static ae_int32_t    _seed = 0;            /* seed for PRNG */
static ae_short16_t  mother1[10];          /* generators    */
static ae_short16_t  mother2[10];          /*    ditto      */
/* landau function: landau[n] is the 
   maximum order of a permutation in the symmetric group S_n */
/*
static int           landau[] = {1, 1, 2, 3, 4, 6, 6, 12, 15, 20, 30, 
				 30, 60, 60, 84, 105, 140, 210, 210, 
				 420, 420, 420, 420, 840, 840, 1260, 1260, 
				 1540, 2310, 2520, 4620, 4620, 5460, 5460};
static int           max_symmetric_group = sizeof(landau)/sizeof(landau[0]);
*/


/*+
* braidInitRandom - initialize the PRNG
*
* usage:
*            braidInitRandom()
*
* args:
*        N/A
*
* returns:
*       N/A
*
* notes:
*      Based on George Marsaglia's mother of all rng's.
*      see ../archive/mother.c, contains full description.
*-
*/
void
braidInitRandom(unsigned int seed) {
	ae_uint32_t   number;
	ae_short16_t  n;
	ae_pshort16_t p;
	ae_ushort16_t sNumber;

	_seed = seed;

	_seed = 1;
	return;
		
}

/*+
* braidGetRandom - gets a random integer that's less than max_n and
*                  greater than or equal to 0.
*
* usage:
*        braidGetRandom(max_n)
*
* args:
*        max_n - one more than maximum value for random number
*
* returns:
*        random integer >= 0 and < max_n.
*
* notes:
*      Based on George Marsaglia's mother of all rng's.
*      see ../archive/mother.c, contains full description.
*-
*/
ae_uint32_t
braidGetRandom(unsigned int n) {
	ae_uint32_t number1, number2;
	unsigned int i;
	unsigned long number = 0;


	if (_seed == 0)
		braidInitRandom(0);

	randombytes(&number, 1);


	// XXX: Is this going to bias the output at all? */
	return (ae_uint32_t)number % n;
}
/*+
 *
 * braidGetRandomInRange - get a random number within the range specified.
 *
 * usage:
 *       braidGetRandomInRange (min, max)
 *
 * args:
 *       min - the minimum positive value for the range.
 *       max - the maximum positive value for the range
 *
 * returns:
 *       random integer in range
 *
 * notes:
 *-
 */
#define RANDOM_IN_RANGE_DBG
ae_uint32_t
braidGetRandomInRange(unsigned int _min, unsigned int _max) {
  int r;

  r = (braidGetRandom(_max) % (_max-_min+1))+_min;
#ifdef RANDOM_IN_RANGE_DBG
  assert (r >= _min && r <= _max);
#endif
  return (unsigned int) r;
}

/*+
 * braidAllocateBraidlist - allocate a braidlist structure of the specified size.
 *
 * usage:
 *       braidAllocateBraidlist (nbr)
 *
 * args:
 *      nbr - number of elements to allocate
 *
 * returns:
 *         Pointer to allocated braidlist or NULL if memory cannot be allocated.
 *
 * notes:
 *       see braids.h for layout of a braidlist.
 *-
 */
ae_plist_t
braidAllocateBraidlist (unsigned int l) {
  ae_plist_t bl;

  bl = (ae_plist_t) ae_malloc (sizeof(ae_list_t));
  bl->len = l;
  bl->b = (ae_pbraidlist_t) ae_calloc(l,sizeof(ae_braidlist_t));
  return bl;
}

/*+
 * braidCopyBraidlist - make a copy of the braidlist
 *
 * usage:
 *       braidCopyBraidlist (src)
 *
 * args:
 *       src - braidlist to make a copy of
 *
 * returns:
 *       pointer to a copy of the braidlist
 *       NULL - allocation error
 *
 * notes:
 *       a full copy is made
 *-
 */
ae_plist_t
braidCopyBraidlist (ae_plist_t src) {
  ae_plist_t bl;
  unsigned int i;

  if (src == NULL) {
    return NULL; /* cannot copy nothing */
  }
  bl = braidAllocateBraidlist (src->len);
  if (bl == NULL) {
    return NULL; /* allocation error */
  }
  for (i=0; i < src->len; i++) {
    bl->b[i] = src->b[i];
  }
  return bl;
}

/*+
 * braidFreeBraidlist - de-allocate an existing braidlist
 *
 * usage:
 *       braidFreeBraidlist (&bl)
 *
 * args:
 *       bl - pointer to braidlist to free
 *
 * returns: N/A
 *
 * notes:
 *       will set the braidlist pointer to NULL on successfull deallocation.
 *-
 */
void
braidFreeBraidlist (ae_plist_t * bl) {
  if (*bl != NULL) {
    if ((*bl)->b != NULL)
      memset ((*bl)->b, 0, (*bl)->len * sizeof(ae_braidlist_t));
    ae_free ((*bl)->b);
    ae_free ((*bl));
    *bl = NULL;
  }
}

/*+
 * braidDropElements - remove a range of contiguous elements from a braidlist.
 *
 * usage:
 *       braidDropElements(bl,lb,ub)
 *
 * args:
 *      bl - braidlist
 *      lb - lower bound of removal
 *      ub - upper bound of removal
 *
 * returns:
 *      new braidlist with elements removed. 
 *
 * notes:
 *      the original braidlist is unmodified.
 *-
 */
ae_plist_t
braidDropElements (ae_plist_t bl, unsigned int lb, unsigned ub) {
  ae_plist_t t;
  unsigned int i=0,j;
  int len;

  len = bl->len - (ub-lb+1);
  if (len < 0)
    return bl;

  t = braidAllocateBraidlist (len);
  if (!t)
    return NULL;

  for (j=0; j < bl->len; j++) {
    if (j < lb || j > ub) {
      t->b[i++] = bl->b[j];
    }
  }
  return t;
}

/*+
 * braidCompareBraidlists - compare two braidlists for equality. 
 *
 * usage:
 *       braidCompareBraidlists  (bl1, bl2)
 *
 * args:
 *       bl1 - first braidlist to compare
 *       bl2 - second braidlist to compare
 *
 * returns:
 *       -1 - bl1 <  bl2
 *        0 - bl1 == bl2
 *       +1 - bl1 >  bl2
 *
 * notes:
 *-
 */
int
braidCompareBraidlists (ae_plist_t bl1, ae_plist_t bl2) {
  unsigned int i;

  if (bl1->len < bl2->len)
    return -1;
  if (bl1->len > bl2->len)
    return 1;

  for (i=0; i < bl1->len; i++) {
    if (bl1->b[i].l < bl2->b[i].l)
      return -1;
    if (bl1->b[i].l > bl2->b[i].l)
      return 1;
    if (bl1->b[i].u < bl2->b[i].u)
      return -1;
    if (bl1->b[i].u > bl2->b[i].u)
      return 1;
  }
  return 0;
}


/*+
 * braidFreelyReduceOnce - reduce one set of artin numbers that cancel each other.
 *
 * usage:
 *       braidFreelyReduceOnce (bl)
 *
 * args:
 *       bl - braidlist to reduce
 *
 * returns:
 *       reduced braidlist
 *
 * notes:
 *       see the AE mathematica model for more details
 *-
 */
ae_plist_t
braidFreelyReduceOnce(ae_plist_t bl) {
  unsigned int len;
  unsigned int i;

  len = bl->len;
  if (bl->len == 0 || len == 1) {
    return bl;
  }
  i = 0;
  while (i < len-2) {
    if (bl->b[i].l !=  bl->b[i+1].l ||
	bl->b[i].u != -bl->b[i+1].u) {
      i++;
    } else  {
      break;
    }
  }
  if (i == len-2 &&
      (bl->b[i].l !=  bl->b[i+1].l ||
       bl->b[i].u != -bl->b[i+1].u)) {
    return bl;
  } else {
    return braidDropElements(bl,i,i+1);
  }
}

/*
 * braidFreelyReduce - go through a braidlist looking to remove self-canceling artin terms
 *
 * usage:
 *       braidFreelyReduce(bl)
 *
 * args:
 *       bl - braidlist to reduce
 *
 * returns:
 *       reduced braidlist
 *
 * notes:
 *       this algorithm is very inefficient
 *-
 */
ae_plist_t
braidFreelyReduce (ae_plist_t list) {
  ae_plist_t answer;
  ae_plist_t temp;

  answer = braidCopyBraidlist (list); /* need to make a copy of the input */
  while (1) {
    temp =  braidFreelyReduceOnce(answer);
    if (!braidCompareBraidlists(answer,temp)) 
      break;

    braidFreeBraidlist (&answer);
    answer = temp;
  }
  /*
   * temp doesn't need to be freed, since if it was not reduced, then it is the
   * same as the answer.
   */
  return answer;
}

/*+
 * braidFreelyReduceRandomArtinWord - freely reduce random artin words in a braidlist
 *
 * usage:
 *       braidFreelyReduceRandomArtinWord (n,l)
 *
 * args:
 *      n - max value for braidlist
 *      l - size of braid in braidlist
 *
 * returns:
 *      braidlist with random braids
 *
 * notes:
 *
 *-
 */
ae_plist_t
braidFreelyReduceRandomArtinWord(unsigned int n, unsigned int l) {
  ae_plist_t bl, answer;
  unsigned int i;

  bl = braidAllocateBraidlist(l);

  for (i=0; i < bl->len; i++) {
    bl->b[i].l = braidGetRandomInRange(1,n-1);
    bl->b[i].u = 2 * braidGetRandomInRange(0,2) - 1;
  }

  answer = braidFreelyReduce (bl);

  braidFreeBraidlist(&bl);
  return answer;
}

/*+
 * braidArtinGenerator - return a braidlist representing an Artin Generator
 *
 * usage:
 *       braidArtinGenerator (n,i,e)
 *
 * args:
 *      n - number of strands in braid group
 *      i - index of the relevant generator
 *      e - sign of generator (e=1 for generator, e=-1 for inverse)
 *
 * returns:
 *      braidlist representing the generator
 *
 * notes:
 *
 *-
 */
ae_plist_t   
braidArtinGenerator (int n, int i, int e) {
  ae_plist_t bl;

  bl = braidAllocateBraidlist(1);

  SETBRAID(bl,0,i,e)   

  return bl;
}


/*+
 * braidGenOfFreeSubgpOfPureBraidGroup - return a generator in a certain free subgroup
 *                                       of the braid group
 *
 * usage:
 *       braidGenOfFreeSubgpOfPureBraidGroup(i,n)
 *
 * args:
 *      i - index of the relevant generator
 *      n - number of strands in braid group
 *
 * returns:
 *      braidlist representing this generator
 *
 * notes:
 *
 *-
 */
ae_plist_t   
braidGenOfFreeSubgpOfPureBraidGroup (int i, int n) {

  ae_plist_t answer = NULL;

  // in the following we let b_i be the ith artin generator
  if (i==n-1) {
    // returns b_{n-1}^2
    answer = braidAllocateBraidlist(2);
    SETBRAID(answer,0,n-1,1);
    SETBRAID(answer,1,n-1,1);
    return answer;
  }

  if (i==n-2) {
    // returns b_{n-1}*b_{n-2}^2*b_{n-1}^-1
    answer = braidAllocateBraidlist(4);
    SETBRAID(answer,0,n-1, 1);
    SETBRAID(answer,1,n-2, 1);
    SETBRAID(answer,2,n-2, 1);
    SETBRAID(answer,3,n-1,-1);
    return answer;
  }
  /* otherwise i=1,...,n-3 */
  {
    int k;
    ae_plist_t conjelt = braidAllocateBraidlist(n-i-3+2);
    ae_plist_t conjeltinv = NULL;
    ae_plist_t mid = NULL;
    ae_plist_t ans1 = NULL;
    SETBRAID(conjelt,0,n-1,1);
    SETBRAID(conjelt,1,n-2,1);
    for (k=1; k<=n-i-3; k++) {
      SETBRAID(conjelt, 1+k, n-2-k, 1);
    }
    mid = braidAllocateBraidlist(2);
    SETBRAID(mid, 0, i, 1);
    SETBRAID(mid, 1, i, 1);

    // need conjelt * mid * conjelt^-1
    conjeltinv = braidInverse(conjelt);
    ans1 = braidMultiplication(conjelt, mid);
    answer = braidMultiplication(ans1, conjeltinv);

    // cleanup
    braidFreeBraidlist(&ans1);
    braidFreeBraidlist(&conjeltinv);
    braidFreeBraidlist(&mid);
    braidFreeBraidlist(&conjelt);

    // returns b_{n-1}*b_{n-2}*...*b_{n-i+1}*b_{n-i}^2
    //          *b_{n-i+1}^-1*...*b_{n-2}^-1*b_{n-1}
    return answer; 
  }
}

ae_plist_t
braidFastBKLNormalFormOfBraid (ae_plist_t braid, int n) {
    ae_pBandList_t bklform;
    ae_plist_t answer;

    if (!braid || !n)
      return NULL;

    bklform = bandFastBKLNormalForm(braid, n);
    answer = keygenBKLNormalFormToArtinWord(bklform, n);
    bandFreeBandList(bklform);
    return answer;
}

/*+
 * braidAllocateCBList - allocate a cblist 
 *
 * usage:
 *        braidAllocateCBList (len)
 *
 * args:
 *        len - number of entries in the list to allocate
 *
 * returns:
 *        pointer to allocated list
 *
 * note:
 *       all entries are set to 0 in the allocated list
 *       must be freed with braidFreeColoredBurauList
 *-
 */
ae_pcblist_t
braidAllocateCBList (unsigned int len) {
  ae_pcblist_t cblist;

  cblist = (ae_pcblist_t) ae_malloc(sizeof(ae_cblist_t));
  cblist->len = len;
  cblist->data = (ae_pcbdata_t) ae_calloc(len,sizeof(ae_cbdata_t));

  return cblist;
}
/*+
 * braidFreeCBList - free a cblist structure
 *     also frees memory for the entries in the list
 *
 * usage:
 *        braidFreeCBList (cblist)
 *
 * args:
 *        cblist - pointer to cblist structure
 *
 * returns:
 *         N/A
 *
 * notes:
 *-
 */
void
braidFreeCBList (ae_pcblist_t cblist) {
  unsigned int i,j;

  if (cblist) {
    if (cblist->data) {
      for (i=0; i < cblist->len; i++) {
	if (cblist->data[i].m){
	  for (j=0; j < cblist->data[i].n; j++) {
	    ae_free (cblist->data[i].m[j]);
	  }
	  ae_free(cblist->data[i].m);
	}
	if (cblist->data[i].p) {
	  ae_free(cblist->data[i].p);
	}
      }
      ae_free (cblist->data);
    }
    ae_free (cblist);
  }
}

/*+
 * braidCBx - gives a matrix associated to the i'th Artin Generator in B_n.
 *
 * usage: braidCBx (n, k, plusminus, p, tValues)
 *
 * args:
 *      n - braid selector B_n
 *      k - value to associate with B_n
 *      plusminus - inverse flag
 *      tValues - the tValues to use
 *
 * returns:
 *      a n by n matrix associated to the i'th Artin Generator in B_n
 *
 * notes:
 *       The matrices x[i,n,+1], x[i,n,-1] are n by n matrices which differ 
 *       from the identity matrix only in the ith row.
 *       The minus -1 refers to the inverse in a semidirect product.
 *
 * uses:
 *
 *-
 */
ae_pcbvalue_t *
braidCBx(unsigned int n, unsigned int k, int plusminus, ae_pTvalues_t tValues) {
  int i;
  ae_pcbvalue_t * m;

  m = braidAllocate2DMatrix (n);

  for (i=0; i<n; i++) {
    m[i][i]=1;
  }
  if (plusminus == 1) {
    m[k-1][k]=1;    
    m[k-1][k-1]=g_ffield->neg(g_ffield, tValues[k-1]);
    if (k>1) {
      m[k-1][k-2]=tValues[k-1];
    }
  }
  else if (plusminus == -1) {
    m[k-1][k-1]=g_ffield->neginverse(g_ffield, tValues[k]);
    m[k-1][k]=g_ffield->inverse(g_ffield, tValues[k]);
    if (k>1) {
      m[k-1][k-2]=1;
    }
  }

  return m;
}

/*+
 * braidCBs - The s[i,n] are permutations of the first n integers which just interchange i and i+1. "
 *
 * usage: braidCBs(n, i)
 *
 * args:
 *        n - size of permutation array
 *        i - elements to interchange
 *
 * returns:
 *        permutation array
 *
 * notes:
 *
 * uses:
 *
 *-
 */
ae_pcbvalue_t
braidCBs (unsigned int n, unsigned int i) {
  ae_pcbvalue_t answer;
  int j;

  answer = (ae_pcbvalue_t) ae_calloc (n, sizeof(ae_cbvalue_t));

  if (i == n) {
    answer[0] = n;
    for (j=1; j < n; j++) {
      answer[j] = j+1;
    }
  } 
  if (i < n) {
    for (j=0;j < n; j++) {
      if (j == i-1) {
	answer[j] = i+1;
      } else if (j == i) {
	answer[j] = i;
      } else {
	answer[j] = j+1;
      }
    }
  }
  if (i > n) {
    i -= n;
    for (j=0;j < n; j++) {
      if (j == i-1) {
	answer[j] = i+1;
      } else if (j == i) {
	answer[j] = i;
      } else {
	answer[j] = j+1;
      }
    }
  }

  return answer;
}

/*+
 * braidToCBConverter - convert braid in B_n to CB form
 *
 * usage: braidToCBConverter (n, w, tValues)
 *
 * args:
 *      n - B_n
 *      w - braidlist
 *      tValues - tValues to use for conversion
 *
 * returns:
 *      list of arrays representing w in CB form
 *
 * notes:
 *
 * uses:
 *      braidAllocateCBList
 *      braidCBx
 *      braidCBs
 *-
 */
ae_pcblist_t
braidToCBConverter (unsigned int n, ae_plist_t w, ae_pTvalues_t tValues) 
{
  unsigned int i;    
  ae_pcblist_t cblist;

  cblist = braidAllocateCBList(w->len);

  for (i=0; i < w->len; i++) {
    cblist->data[i].n = n;
    cblist->data[i].m = braidCBx(n,w->b[i].l,w->b[i].u,tValues);
    cblist->data[i].p = braidCBs(n,w->b[i].l);
    cblist->data[i].k = w->b[i].l;
    cblist->data[i].e = w->b[i].u;
  }

  return cblist;
}

/*+
 * braidAllocate2DMatrix - convenience function to allocate a 2 dimensional matrix
 *
 * usage: braidAllocate2DMatrix (n)
 *
 * args:
 *      n - number of rows/columns
 *
 * returns:
 *      pointer to created matrix or NULL if memory could not be allocated
 *
 * notes:
 *      always creates a square matrix which is zeroed
 *
 * uses:
 *      ae_malloc
 *      ae_calloc
 *
 *-
 */
ae_pcbvalue_t *
braidAllocate2DMatrix (unsigned int n) {
  unsigned int i;
  ae_pcbvalue_t * m;

  m = (ae_pcbvalue_t *) ae_malloc (n*sizeof(ae_pcbvalue_t));
  if (m == NULL) {
    return NULL; /* Allocation failure */
  }
  for (i=0; i < n; i++) {
    m[i] = (ae_pcbvalue_t) ae_calloc (n,sizeof(ae_cbvalue_t));
    if (m[i] == NULL) {
      return NULL; /* allocation failure */
    }
  }
  return m;
}


/*+
 * braidAllocateCBData - allocate a cbdata structure
 *
 * usage:
 *        braidAllocateCBData (n)
 *
 * args:
 *       n - number of rows in arrays
 *
 * returns:
 *       pointer to allocated cbdata structure
 *
 * notes:
 *       use braidFreeCBData to de-allocate
 *       NULL if allocation failure
 *-
 */
ae_pcbdata_t
braidAllocateCBData (unsigned int n) {
  ae_pcbdata_t cbdata;

  cbdata = (ae_pcbdata_t) ae_malloc (sizeof(ae_cbdata_t));
  if (cbdata == NULL) {
    return NULL; /* Allocation failure */
  }
  cbdata->n = n;
  cbdata->m = braidAllocate2DMatrix(n);
  if (cbdata->m == NULL) {
    ae_free (cbdata);
    return NULL; /* Allocation failure */
  }

  cbdata->p = (ae_pcbvalue_t) ae_calloc (n,sizeof(ae_cbvalue_t));
  if (cbdata->p == NULL) {
    braidFreeCBData (cbdata);
    return NULL; /* Allocation failure */
  }
  cbdata->k = 0;
  cbdata->e = 0;
  return cbdata;
}

/*+
 * braidFreeCBData - free a cbdata structure
 *
 * usage:
 *        braidFreeCBData (pcbdata)
 *
 * args:
 *        pcbdata - pointer to cbdata structure to free
 *
 * returns:
 *         N/A
 *
 * notes:
 *
 *-
 */
void
braidFreeCBData (ae_pcbdata_t cbdata) {
  unsigned int i;

  if (cbdata) {
    if (cbdata->m) {
      for (i=0; i<cbdata->n; i++) {
	if (cbdata->m[i]) {
	  ae_free (cbdata->m[i]);
	}
      }
      ae_free (cbdata->m);
      if (cbdata->p) {
	ae_free (cbdata->p);
      }
    }
    ae_free (cbdata);
  }
}

/*+
 * braidAppendBraidlistToBraidlist - extends and appends the first braidlist
 *                                   by the length of the second.
 *
 * usage: braidAppendBraidlistToBraidlist (dst, src)
 *
 * args:
 *       dst - destination braidlist
 *       src - src braidlist
 *
 * returns:
 *         0 - success
 *         1 - allocation failure
 *
 * notes:
 *
 * uses:
 *
 *-
 */
int
braidAppendBraidlistToBraidlist (ae_plist_t dst, ae_plist_t  src) {
  int i;

  dst->b = (ae_pbraidlist_t) ae_realloc (dst->b,(dst->len+src->len)*sizeof(ae_braidlist_t));
  if (dst->b == NULL)
    return 1;

  for (i=0; i < src->len; i++) {
    dst->b[dst->len+i] = src->b[i];
  }
  dst->len += src->len;

  return 0;
}

/*+
 * braidInverse - produces the unique inverse of a braidword 
 *
 * usage: braidInverse (z)
 *
 * args:
 *       z - braidword to be inverted
 *
 * returns:
 *        inverted braidword or NULL if allocation error
 *
 * notes:
 *        
 *
 * uses:
 *      braidAllocateBraidlist
 * 
 *-
 */
ae_plist_t
braidInverse (ae_plist_t bl) {
  int i;
  ae_plist_t inv;
  if (bl == NULL) {
    return NULL;
  }
  inv = braidAllocateBraidlist (bl->len);
  if (inv == NULL)
    return NULL;

  for (i=0; i < bl->len; i++) {
    inv->b[i].l = bl->b[bl->len-i-1].l;
    inv->b[i].u = -bl->b[bl->len-i-1].u;
  }
  return inv;
} 

/*+
 * braidMultiplication - produces the product of two braids, which
 *                       is a Join of the two braids.
 *
 * usage: braidMultiplication (m,n)
 *
 * args:
 *       m - braidword
 *       n - braidword
 *
 * returns:
 *        product of the two braids or NULL if memory cannot be allocated
 *
 * notes:
 *        
 *
 * uses:
 *      braidCopyBraidlist
 *      braidAppendBraidlistToBraidlist
 * 
 *-
 */
ae_plist_t
braidMultiplication (ae_plist_t m, ae_plist_t n) {
  ae_plist_t answer;
  int failed;

  answer = braidCopyBraidlist (m);
  if (answer == NULL) {
    return NULL;
  }
  failed = braidAppendBraidlistToBraidlist (answer, n);
  if (failed) {
    braidFreeBraidlist (&answer);
    return NULL;
  }
  return answer;
}

/*
 * braidIdentityMatrix - create an identity matrix of the given size
 *
 * usage: braidIdentityMatrix (n)
 *
 * args:
 *      n - size of matrix to create
 *
 * returns:
 *      pointer to matrix or NULL if memory could not be allocated
 *
 * notes:
 *      this creates the matrix as part of CBData, so there is also a permutation
 *      created.  the permutation is set to be the identity (and is 1-referenced).
 * uses:
 *     braidAllocateCBData
 *
 *-
 */
ae_pcbdata_t
braidIdentityMatrix (unsigned int n) {
  ae_pcbdata_t im;
  unsigned int i;

  im = braidAllocateCBData (n);

  for (i=0; i <n; i++) {
    im->m[i][i] = 1;
  }
  // 1-referenced permutation
  for (i=0; i < n; i++) {
    im->p[i] = i+1;
  }
  im->k=0;
  im->e=0;
  return im;
}

/*+
 * braidFreeIdentityMatrix - free a previously allocated Identity Matrix
 *
 * usage: braidFreeIdentityMatrix (im)
 *
 * args:
 *      im - pointer to identity matrix to free
 *
 * returns: N/A
 *
 * notes:
 *       complementary function to braidIdentityMatrix
 *
 * uses:
 *       braidFreeCBData
 *
 *-
 */
void
braidFreeIdentityMatrix (ae_pcbdata_t im) {
  if (im)
    braidFreeCBData (im);
}


/*+
 * braidAllocateTvalues - allocate a simple Tvalues array
 *
 * usage: braidAllocateTvalues (n)
 *
 * args:
 *       n - size of array
 *
 * returns:
 *       pointer to Tvalues or NULL if memory could not be allocated
 *
 * notes:
 *       a simple tvalue array is created starting at 1...n
 *
 * uses:
 *      ae_calloc
 *
 *-
 */
ae_pTvalues_t
braidAllocateTvalues (unsigned int n) {
  int i;
  ae_pTvalues_t ptr;

  ptr = (ae_pTvalues_t) ae_calloc (n, sizeof(ae_Tvalues_t));
  if (!ptr)
    return NULL;

  for (i=0; i < n; i++) {
    ptr[i] = i+1;
  }
  return ptr;
}


/*+
 * braidAllocateRandomTvalues - allocate a random Tvalues array
 *
 * usage: braidAllocateRandomTvalues (n,q)
 *
 * args:
 *       n - size of array
 *       q - field parameter -- will generate entries from 2..q-1
 *
 * returns:
 *       pointer to Tvalues or NULL if memory could not be allocated
 *
 * notes:
 *       performs no validation on the random entries, so you
 *       could have duplicates.
 *
 * uses:
 *      ae_calloc
 *
 *-
 */
ae_pTvalues_t
braidAllocateRandomTvalues (unsigned int n, unsigned int q)
{
  int i;
  ae_pTvalues_t ptr;

  ptr = (ae_pTvalues_t) ae_calloc (n, sizeof(ae_Tvalues_t));
  if (ptr)
  {
    for (i = 0; i < n; i++)
      /* Note: we don't check for duplication here */
      ptr[i] = braidGetRandom(q-2)+2;
  }
  return ptr;
}

void
braidFreeBraidwordList(ae_plistOfLists_t bwl) {
	unsigned int i;

	if (bwl) {
		if (bwl->l) {
			for (i = 0; i < bwl->len; i++) {
				if (bwl->l[i]) {
					braidFreeBraidlist(&bwl->l[i]);
				}
			}
			ae_free(bwl->l);
		}
		ae_free(bwl);
	}
}

void
braidAppendToBraidlist(ae_plist_t bl, ae_pbraidlist_t b) {

	bl->b = (ae_pbraidlist_t)ae_realloc(bl->b, (bl->len + 1) * sizeof(ae_braidlist_t));
	bl->b[bl->len].l = b->l;
	bl->b[bl->len++].u = b->u;
}

ae_plistOfLists_t
braidAllocateBraidwordList(unsigned int len) {
	ae_plistOfLists_t bwl;

	bwl = (ae_plistOfLists_t)ae_malloc(sizeof(ae_listOfLists_t));
	bwl->len = len;
	bwl->l = (ae_plist_t *)ae_calloc(len, sizeof(ae_plist_t));

	return bwl;
}

/*+
 * braidFreeTvalues - free a previously allocated Tvalues array
 *
 * usage: braidFreeTvalues (ptr)
 *
 * args:
 *     ptr - pointer to tvalues array
 *
 * returns: N/A
 *
 * notes:
 *      complementary function to braidAllocateTvalues
 *
 * uses:
 *      ae_free
 *
 *-
 */
void
braidFreeTvalues (ae_pTvalues_t ptr) {
  if (ptr)
    ae_free (ptr);
}

int aeLibReInit(ffelem primepower)
{
  if (g_ffield && g_ffield->primepower == primepower)
      return 0;

  g_ffield = getFiniteField(primepower);
  return (g_ffield == NULL);
}
