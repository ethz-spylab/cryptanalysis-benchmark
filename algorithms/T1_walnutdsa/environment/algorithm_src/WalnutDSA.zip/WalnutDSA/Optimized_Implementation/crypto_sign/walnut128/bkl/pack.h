/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * pack.h -- code to pack (and unpack) arrays, matrices, and braids into
 *           compact byte-strings.
 */

#ifndef AE_PACK_H
#define AE_PACK_H

#include "aelib.h"

typedef struct {
  unsigned char* buffer;
  size_t buflen;
  int entrysize;
  int bytelen;
} AePackCtx;

/* Initialize a Pack Context Object.
 * @ctx: context to be initialized
 * @buffer: buffer to use for input/output
 * @buflen: length of buffer (to prevent overruns)
 * @entrysize: number of bits per field to pack/unpack
 */
void ae_pack_init(AePackCtx* ctx, unsigned char* buffer, size_t buflen, int entrysize);

/* Pack an entry value into the buffer. */
void ae_pack_entry(AePackCtx* ctx, ae_cbvalue_t entry);

/* Unpack an entry value from the buffer */
ae_cbvalue_t ae_unpack_entry(AePackCtx* ctx);


/*******************************************************************
 * Helper functions to pack objects
 *******************************************************************/
/* Pack/Unpack a matrix (these only pack the last entry in the final row) */
int ae_pack_matrix(const ae_2dMatrix_t m, int index, int field, unsigned char** buffer, size_t* buflen);
int ae_unpack_matrix(const unsigned char* buffer, size_t buflen, int index, int field, ae_2dMatrix_t m);
int ae_unpack_matrix_new(const unsigned char* buffer, size_t buflen, int index, int field, ae_2dMatrix_t* m);

/* Pack/Unpack a full matrix (all N x N values) */
int ae_pack_matrix_full(const ae_2dMatrix_t m, int index, int field, unsigned char** buffer, size_t* buflen);
int ae_unpack_matrix_full(const unsigned char* buffer, size_t buflen, int index, int field, ae_2dMatrix_t m);
int ae_unpack_matrix_full_new(const unsigned char* buffer, size_t buflen, int index, int field, ae_2dMatrix_t* m);

/* Pack/Unpack an array */
int ae_pack_array(const ae_pcbvalue_t arr, int arrlen, int field, unsigned char** buffer, size_t* buflen);
int ae_unpack_array(const unsigned char* buffer, size_t buflen, int arrlen, int field, ae_pcbvalue_t arr);
int ae_unpack_array_new(const unsigned char* buffer, size_t buflen, int arrlen, int field, ae_pcbvalue_t* arr);

/* Pack/Unpack a braid */
int ae_pack_braid(const ae_plist_t braid, int index, unsigned char** buffer, size_t* buflen);
int ae_unpack_braid(const unsigned char* buffer, size_t buflen, int index, ae_plist_t* braid);

#endif /* AE_PACK_H */
