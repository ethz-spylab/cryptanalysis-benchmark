/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/


/* ae_crypto.c - Algebraic Eraser Diffie-Hellman and 
 *               Algebraic Eraser Digital Signature Algorithm 
 */
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include "ae_crypto.h"
#include <time.h>
#include "aelib.h"

#include <emmintrin.h>

#define PASTE_INTERNAL(f,b) f ## b
#define PASTE(f,b) PASTE_INTERNAL(f,b)

#ifdef __C51__
#	define	AE_LOOKUP code
#else
#	define AE_LOOKUP 
#endif

#if WALNUT_FIELD == 32

static AE_LOOKUP const uint8_t minv_32[32] = {
	0,1,18,28,9,23,14,12,22,4,25,16,7,15,6,13,11,24,2,29,30,26,8,5,17,10,21,31,3,19,20,27
};

static AE_LOOKUP const uint8_t mtable_32[32][32] = {
	{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
	{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31},
	{0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,5,7,1,3,13,15,9,11,21,23,17,19,29,31,25,27},
	{0,3,6,5,12,15,10,9,24,27,30,29,20,23,18,17,21,22,19,16,25,26,31,28,13,14,11,8,1,2,7,4},
	{0,4,8,12,16,20,24,28,5,1,13,9,21,17,29,25,10,14,2,6,26,30,18,22,15,11,7,3,31,27,23,19},
	{0,5,10,15,20,17,30,27,13,8,7,2,25,28,19,22,26,31,16,21,14,11,4,1,23,18,29,24,3,6,9,12},
	{0,6,12,10,24,30,20,18,21,19,25,31,13,11,1,7,15,9,3,5,23,17,27,29,26,28,22,16,2,4,14,8},
	{0,7,14,9,28,27,18,21,29,26,19,20,1,6,15,8,31,24,17,22,3,4,13,10,2,5,12,11,30,25,16,23},
	{0,8,16,24,5,13,21,29,10,2,26,18,15,7,31,23,20,28,4,12,17,25,1,9,30,22,14,6,27,19,11,3},
	{0,9,18,27,1,8,19,26,2,11,16,25,3,10,17,24,4,13,22,31,5,12,23,30,6,15,20,29,7,14,21,28},
	{0,10,20,30,13,7,25,19,26,16,14,4,23,29,3,9,17,27,5,15,28,22,8,2,11,1,31,21,6,12,18,24},
	{0,11,22,29,9,2,31,20,18,25,4,15,27,16,13,6,1,10,23,28,8,3,30,21,19,24,5,14,26,17,12,7},
	{0,12,24,20,21,25,13,1,15,3,23,27,26,22,2,14,30,18,6,10,11,7,19,31,17,29,9,5,4,8,28,16},
	{0,13,26,23,17,28,11,6,7,10,29,16,22,27,12,1,14,3,20,25,31,18,5,8,9,4,19,30,24,21,2,15},
	{0,14,28,18,29,19,1,15,31,17,3,13,2,12,30,16,27,21,7,9,6,8,26,20,4,10,24,22,25,23,5,11},
	{0,15,30,17,25,22,7,8,23,24,9,6,14,1,16,31,11,4,21,26,18,29,12,3,28,19,2,13,5,10,27,20},
	{0,16,5,21,10,26,15,31,20,4,17,1,30,14,27,11,13,29,8,24,7,23,2,18,25,9,28,12,19,3,22,6},
	{0,17,7,22,14,31,9,24,28,13,27,10,18,3,21,4,29,12,26,11,19,2,20,5,1,16,6,23,15,30,8,25},
	{0,18,1,19,2,16,3,17,4,22,5,23,6,20,7,21,8,26,9,27,10,24,11,25,12,30,13,31,14,28,15,29},
	{0,19,3,16,6,21,5,22,12,31,15,28,10,25,9,26,24,11,27,8,30,13,29,14,20,7,23,4,18,1,17,2},
	{0,20,13,25,26,14,23,3,17,5,28,8,11,31,6,18,7,19,10,30,29,9,16,4,22,2,27,15,12,24,1,21},
	{0,21,15,26,30,11,17,4,25,12,22,3,7,18,8,29,23,2,24,13,9,28,6,19,14,27,1,20,16,5,31,10},
	{0,22,9,31,18,4,27,13,1,23,8,30,19,5,26,12,2,20,11,29,16,6,25,15,3,21,10,28,17,7,24,14},
	{0,23,11,28,22,1,29,10,9,30,2,21,31,8,20,3,18,5,25,14,4,19,15,24,27,12,16,7,13,26,6,17},
	{0,24,21,13,15,23,26,2,30,6,11,19,17,9,4,28,25,1,12,20,22,14,3,27,7,31,18,10,8,16,29,5},
	{0,25,23,14,11,18,28,5,22,15,1,24,29,4,10,19,9,16,30,7,2,27,21,12,31,6,8,17,20,13,3,26},
	{0,26,17,11,7,29,22,12,14,20,31,5,9,19,24,2,28,6,13,23,27,1,10,16,18,8,3,25,21,15,4,30},
	{0,27,19,8,3,24,16,11,6,29,21,14,5,30,22,13,12,23,31,4,15,20,28,7,10,17,25,2,9,18,26,1},
	{0,28,29,1,31,3,2,30,27,7,6,26,4,24,25,5,19,15,14,18,12,16,17,13,8,20,21,9,23,11,10,22},
	{0,29,31,2,27,6,4,25,19,14,12,17,8,21,23,10,3,30,28,1,24,5,7,26,16,13,15,18,11,22,20,9},
	{0,30,25,7,23,9,14,16,11,21,18,12,28,2,5,27,22,8,15,17,1,31,24,6,29,3,4,26,10,20,19,13},
	{0,31,27,4,19,12,8,23,3,28,24,7,16,15,11,20,6,25,29,2,21,10,14,17,5,26,30,1,22,9,13,18},
};

#define DSA_GET_LOOKUP(val) (PASTE(mtable_, WALNUT_FIELD)[val])
#define DSA_MUL(lookup, val) (lookup[val])
#define DSA_INVERSE(val) (PASTE(minv_, WALNUT_FIELD)[val])

enum {
	WALNUT_FIELD_ENUM = 0x20
};

#else

static const uint8_t minv_256[256] = {
	0, 1, 141, 246, 203, 82, 123, 209, 232, 79, 41, 192, 176, 225,
	229, 199, 116, 180, 170, 75, 153, 43, 96, 95, 88, 63, 253, 204,
	255, 64, 238, 178, 58, 110, 90, 241, 85, 77, 168, 201, 193, 10,
	152, 21, 48, 68, 162, 194, 44, 69, 146, 108, 243, 57, 102, 66,
	242, 53, 32, 111, 119, 187, 89, 25, 29, 254, 55, 103, 45, 49,
	245, 105, 167, 100, 171, 19, 84, 37, 233, 9, 237, 92, 5, 202,
	76, 36, 135, 191, 24, 62, 34, 240, 81, 236, 97, 23, 22, 94, 175,
	211, 73, 166, 54, 67, 244, 71, 145, 223, 51, 147, 33, 59, 121,
	183, 151, 133, 16, 181, 186, 60, 182, 112, 208, 6, 161, 250,
	129, 130, 131, 126, 127, 128, 150, 115, 190, 86, 155, 158, 149,
	217, 247, 2, 185, 164, 222, 106, 50, 109, 216, 138, 132, 114,
	42, 20, 159, 136, 249, 220, 137, 154, 251, 124, 46, 195, 143,
	184, 101, 72, 38, 200, 18, 74, 206, 231, 210, 98, 12, 224, 31,
	239, 17, 117, 120, 113, 165, 142, 118, 61, 189, 188, 134, 87,
	11, 40, 47, 163, 218, 212, 228, 15, 169, 39, 83, 4, 27, 252,
	172, 230, 122, 7, 174, 99, 197, 219, 226, 234, 148, 139, 196,
	213, 157, 248, 144, 107, 177, 13, 214, 235, 198, 14, 207, 173,
	8, 78, 215, 227, 93, 80, 30, 179, 91, 35, 56, 52, 104, 70, 3,
	140, 221, 156, 125, 160, 205, 26, 65, 28
};

#ifdef AE_LOOKUP_IN_RAM
static uint8_t ltable_256[] = {
#else
static const uint8_t ltable_256[] = {
#endif
	0x00, 0xFF, 0xC8, 0x08, 0x91, 0x10, 0xD0, 0x36,
	0x5A, 0x3E, 0xD8, 0x43, 0x99, 0x77, 0xFE, 0x18,
	0x23, 0x20, 0x07, 0x70, 0xA1, 0x6C, 0x0C, 0x7F,
	0x62, 0x8B, 0x40, 0x46, 0xC7, 0x4B, 0xE0, 0x0E,
	0xEB, 0x16, 0xE8, 0xAD, 0xCF, 0xCD, 0x39, 0x53,
	0x6A, 0x27, 0x35, 0x93, 0xD4, 0x4E, 0x48, 0xC3,
	0x2B, 0x79, 0x54, 0x28, 0x09, 0x78, 0x0F, 0x21,
	0x90, 0x87, 0x14, 0x2A, 0xA9, 0x9C, 0xD6, 0x74,
	0xB4, 0x7C, 0xDE, 0xED, 0xB1, 0x86, 0x76, 0xA4,
	0x98, 0xE2, 0x96, 0x8F, 0x02, 0x32, 0x1C, 0xC1,
	0x33, 0xEE, 0xEF, 0x81, 0xFD, 0x30, 0x5C, 0x13,
	0x9D, 0x29, 0x17, 0xC4, 0x11, 0x44, 0x8C, 0x80,
	0xF3, 0x73, 0x42, 0x1E, 0x1D, 0xB5, 0xF0, 0x12,
	0xD1, 0x5B, 0x41, 0xA2, 0xD7, 0x2C, 0xE9, 0xD5,
	0x59, 0xCB, 0x50, 0xA8, 0xDC, 0xFC, 0xF2, 0x56,
	0x72, 0xA6, 0x65, 0x2F, 0x9F, 0x9B, 0x3D, 0xBA,
	0x7D, 0xC2, 0x45, 0x82, 0xA7, 0x57, 0xB6, 0xA3,
	0x7A, 0x75, 0x4F, 0xAE, 0x3F, 0x37, 0x6D, 0x47,
	0x61, 0xBE, 0xAB, 0xD3, 0x5F, 0xB0, 0x58, 0xAF,
	0xCA, 0x5E, 0xFA, 0x85, 0xE4, 0x4D, 0x8A, 0x05,
	0xFB, 0x60, 0xB7, 0x7B, 0xB8, 0x26, 0x4A, 0x67,
	0xC6, 0x1A, 0xF8, 0x69, 0x25, 0xB3, 0xDB, 0xBD,
	0x66, 0xDD, 0xF1, 0xD2, 0xDF, 0x03, 0x8D, 0x34,
	0xD9, 0x92, 0x0D, 0x63, 0x55, 0xAA, 0x49, 0xEC,
	0xBC, 0x95, 0x3C, 0x84, 0x0B, 0xF5, 0xE6, 0xE7,
	0xE5, 0xAC, 0x7E, 0x6E, 0xB9, 0xF9, 0xDA, 0x8E,
	0x9A, 0xC9, 0x24, 0xE1, 0x0A, 0x15, 0x6B, 0x3A,
	0xA0, 0x51, 0xF4, 0xEA, 0xB2, 0x97, 0x9E, 0x5D,
	0x22, 0x88, 0x94, 0xCE, 0x19, 0x01, 0x71, 0x4C,
	0xA5, 0xE3, 0xC5, 0x31, 0xBB, 0xCC, 0x1F, 0x2D,
	0x3B, 0x52, 0x6F, 0xF6, 0x2E, 0x89, 0xF7, 0xC0,
	0x68, 0x1B, 0x64, 0x04, 0x06, 0xBF, 0x83, 0x38
};

#ifdef AE_LOOKUP_IN_RAM
static uint8_t atable_256[] = {
#else
static const uint8_t atable_256[] = {
#endif
	0x01, 0xE5, 0x4C, 0xB5, 0xFB, 0x9F, 0xFC, 0x12,
	0x03, 0x34, 0xD4, 0xC4, 0x16, 0xBA, 0x1F, 0x36,
	0x05, 0x5C, 0x67, 0x57, 0x3A, 0xD5, 0x21, 0x5A,
	0x0F, 0xE4, 0xA9, 0xF9, 0x4E, 0x64, 0x63, 0xEE,
	0x11, 0x37, 0xE0, 0x10, 0xD2, 0xAC, 0xA5, 0x29,
	0x33, 0x59, 0x3B, 0x30, 0x6D, 0xEF, 0xF4, 0x7B,
	0x55, 0xEB, 0x4D, 0x50, 0xB7, 0x2A, 0x07, 0x8D,
	0xFF, 0x26, 0xD7, 0xF0, 0xC2, 0x7E, 0x09, 0x8C,
	0x1A, 0x6A, 0x62, 0x0B, 0x5D, 0x82, 0x1B, 0x8F,
	0x2E, 0xBE, 0xA6, 0x1D, 0xE7, 0x9D, 0x2D, 0x8A,
	0x72, 0xD9, 0xF1, 0x27, 0x32, 0xBC, 0x77, 0x85,
	0x96, 0x70, 0x08, 0x69, 0x56, 0xDF, 0x99, 0x94,
	0xA1, 0x90, 0x18, 0xBB, 0xFA, 0x7A, 0xB0, 0xA7,
	0xF8, 0xAB, 0x28, 0xD6, 0x15, 0x8E, 0xCB, 0xF2,
	0x13, 0xE6, 0x78, 0x61, 0x3F, 0x89, 0x46, 0x0D,
	0x35, 0x31, 0x88, 0xA3, 0x41, 0x80, 0xCA, 0x17,
	0x5F, 0x53, 0x83, 0xFE, 0xC3, 0x9B, 0x45, 0x39,
	0xE1, 0xF5, 0x9E, 0x19, 0x5E, 0xB6, 0xCF, 0x4B,
	0x38, 0x04, 0xB9, 0x2B, 0xE2, 0xC1, 0x4A, 0xDD,
	0x48, 0x0C, 0xD0, 0x7D, 0x3D, 0x58, 0xDE, 0x7C,
	0xD8, 0x14, 0x6B, 0x87, 0x47, 0xE8, 0x79, 0x84,
	0x73, 0x3C, 0xBD, 0x92, 0xC9, 0x23, 0x8B, 0x97,
	0x95, 0x44, 0xDC, 0xAD, 0x40, 0x65, 0x86, 0xA2,
	0xA4, 0xCC, 0x7F, 0xEC, 0xC0, 0xAF, 0x91, 0xFD,
	0xF7, 0x4F, 0x81, 0x2F, 0x5B, 0xEA, 0xA8, 0x1C,
	0x02, 0xD1, 0x98, 0x71, 0xED, 0x25, 0xE3, 0x24,
	0x06, 0x68, 0xB3, 0x93, 0x2C, 0x6F, 0x3E, 0x6C,
	0x0A, 0xB8, 0xCE, 0xAE, 0x74, 0xB1, 0x42, 0xB4,
	0x1E, 0xD3, 0x49, 0xE9, 0x9C, 0xC8, 0xC6, 0xC7,
	0x22, 0x6E, 0xDB, 0x20, 0xBF, 0x43, 0x51, 0x52,
	0x66, 0xB2, 0x76, 0x60, 0xDA, 0xC5, 0xF3, 0xF6,
	0xAA, 0xCD, 0x9A, 0xA0, 0x75, 0x54, 0x0E, 0x01,

	0xE5, 0x4C, 0xB5, 0xFB, 0x9F, 0xFC, 0x12,
	0x03, 0x34, 0xD4, 0xC4, 0x16, 0xBA, 0x1F, 0x36,
	0x05, 0x5C, 0x67, 0x57, 0x3A, 0xD5, 0x21, 0x5A,
	0x0F, 0xE4, 0xA9, 0xF9, 0x4E, 0x64, 0x63, 0xEE,
	0x11, 0x37, 0xE0, 0x10, 0xD2, 0xAC, 0xA5, 0x29,
	0x33, 0x59, 0x3B, 0x30, 0x6D, 0xEF, 0xF4, 0x7B,
	0x55, 0xEB, 0x4D, 0x50, 0xB7, 0x2A, 0x07, 0x8D,
	0xFF, 0x26, 0xD7, 0xF0, 0xC2, 0x7E, 0x09, 0x8C,
	0x1A, 0x6A, 0x62, 0x0B, 0x5D, 0x82, 0x1B, 0x8F,
	0x2E, 0xBE, 0xA6, 0x1D, 0xE7, 0x9D, 0x2D, 0x8A,
	0x72, 0xD9, 0xF1, 0x27, 0x32, 0xBC, 0x77, 0x85,
	0x96, 0x70, 0x08, 0x69, 0x56, 0xDF, 0x99, 0x94,
	0xA1, 0x90, 0x18, 0xBB, 0xFA, 0x7A, 0xB0, 0xA7,
	0xF8, 0xAB, 0x28, 0xD6, 0x15, 0x8E, 0xCB, 0xF2,
	0x13, 0xE6, 0x78, 0x61, 0x3F, 0x89, 0x46, 0x0D,
	0x35, 0x31, 0x88, 0xA3, 0x41, 0x80, 0xCA, 0x17,
	0x5F, 0x53, 0x83, 0xFE, 0xC3, 0x9B, 0x45, 0x39,
	0xE1, 0xF5, 0x9E, 0x19, 0x5E, 0xB6, 0xCF, 0x4B,
	0x38, 0x04, 0xB9, 0x2B, 0xE2, 0xC1, 0x4A, 0xDD,
	0x48, 0x0C, 0xD0, 0x7D, 0x3D, 0x58, 0xDE, 0x7C,
	0xD8, 0x14, 0x6B, 0x87, 0x47, 0xE8, 0x79, 0x84,
	0x73, 0x3C, 0xBD, 0x92, 0xC9, 0x23, 0x8B, 0x97,
	0x95, 0x44, 0xDC, 0xAD, 0x40, 0x65, 0x86, 0xA2,
	0xA4, 0xCC, 0x7F, 0xEC, 0xC0, 0xAF, 0x91, 0xFD,
	0xF7, 0x4F, 0x81, 0x2F, 0x5B, 0xEA, 0xA8, 0x1C,
	0x02, 0xD1, 0x98, 0x71, 0xED, 0x25, 0xE3, 0x24,
	0x06, 0x68, 0xB3, 0x93, 0x2C, 0x6F, 0x3E, 0x6C,
	0x0A, 0xB8, 0xCE, 0xAE, 0x74, 0xB1, 0x42, 0xB4,
	0x1E, 0xD3, 0x49, 0xE9, 0x9C, 0xC8, 0xC6, 0xC7,
	0x22, 0x6E, 0xDB, 0x20, 0xBF, 0x43, 0x51, 0x52,
	0x66, 0xB2, 0x76, 0x60, 0xDA, 0xC5, 0xF3, 0xF6,
	0xAA, 0xCD, 0x9A, 0xA0, 0x75, 0x54, 0x0E, 0x01
};

#define GET_LOOKUP(val) (PASTE(atable_, WALNUT_FIELD) + \
        PASTE(ltable_, WALNUT_FIELD)[val])
#define MUL(lookup, val) (mul(lookup, val))
#define INVERSE(val) (PASTE(minv_, WALNUT_FIELD)[val])
#define STRUCT_LOOKUP(c) ((c)->lookup = PASTE(ltable_, WALNUT_FIELD))

static uint8_t mul(const uint8_t *lookup, uint8_t val)
{
	bool iszero = (val == 0);
	uint8_t t = ltable_256[val];

	return iszero ? ltable_256[t] : lookup[t];
}

enum {
	WALNUT_FIELD_ENUM = 0x00
};

#endif

enum {
	WALNUT_BRAID_ENUM = 0x08
};



static uint8_t extract_elem(const uint8_t *in, size_t curr_bit, uint8_t packwidth, uint8_t mask)
{
	uint8_t ret = 0;
	int8_t shiftby = (8 - packwidth) - (curr_bit % 8);
	size_t addr = curr_bit / 8;

	if(shiftby < 0) {
		uint8_t entry1 = in[addr];
		uint8_t entry2 = in[addr + 1];
		uint8_t t = 8 + shiftby;

		ret = (entry1 << -shiftby);
		ret |= (entry2 >> t) & mask;
	} else {
		uint8_t entry = in[addr];
		ret = (entry >> shiftby);
	}

	return ret & mask;
}


static void mmul(uint8_t d[WALNUT_BRAID][WALNUT_BRAID], 
                 uint8_t a[WALNUT_BRAID][WALNUT_BRAID], 
                 uint8_t b[WALNUT_BRAID][WALNUT_BRAID])

{
	uint16_t i, j, k;

#if WALNUT_FIELD == 256
	const uint8_t *lookup;
#endif

	for(i=0; i<WALNUT_BRAID; i++) {
		for(j=0; j<WALNUT_BRAID; j++) {
			d[j][i] = 0;
			for(k=0; k<WALNUT_BRAID; k++) {
#if WALNUT_FIELD == 32
				d[j][i] ^= DSA_MUL(DSA_GET_LOOKUP(a[k][i]), b[j][k]);
#else
				if (a[k][i] != 0)
				{
					lookup = GET_LOOKUP(a[k][i]);
					d[j][i] ^= MUL(lookup, b[j][k]);
				}
#endif

			}
		}
	}
}

static int walnut_emul(walnut_verify_ctx *c, 
		uint8_t m[WALNUT_BRAID][WALNUT_BRAID], 
		const uint8_t *b, size_t count)
{
	size_t i;

	for(i=0; i<count; i++) {
		uint8_t br = (i % 2) ? b[i/2] & 0x0F : b[i/2] >> 4; 
		
		uint8_t r = (br & ~0xF8); 
		const uint8_t *mp;
		uint8_t *r0, *r1, *r2;
		uint8_t j, t0, t1;

		t0 = c->p[r]; 
		t1 = c->p[r + 1];
		
		if (t0 > WALNUT_BRAID || t1 > WALNUT_BRAID)
			return -2;

		c->p[r] = t1;
		c->p[r + 1] = t0;

		r1 = m[r];

		if (br & 0x08) {	// - sign
			r0 = r1 - WALNUT_BRAID;
			r2 = r1 + WALNUT_BRAID;
			mp = c->imp[t1];
		} else {				// + sign
			r0 = r1 + WALNUT_BRAID;
			r2 = r1 - WALNUT_BRAID;
			mp = c->mp[t0];
		}

		__m128i regX = _mm_loadu_si128((__m128i*)r0);
		__m128i regY = _mm_loadu_si128((__m128i*)r1);

		__m128i res = _mm_xor_si128(regX, regY);

		_mm_storel_epi64((__m128i *)r0, res);

		for(j=0; j<WALNUT_BRAID; j++) {
#if WALNUT_FIELD == 32
			r1[j] = mp[r1[j]];
#else
			r1[j] = MUL(mp, r1[j]);
#endif
		}

		regX = _mm_loadu_si128((__m128i*)r2);
		regY = _mm_loadu_si128((__m128i*)r1);

		res = _mm_xor_si128(regX, regY);
		_mm_storel_epi64((__m128i *)r2, res);

	}

	return 0;
}

static int process_digest(walnut_verify_ctx *c, const uint8_t *dgst)
{
	size_t i;
	int ret = 0;
	AE_LOOKUP const uint8_t braiddata[16][11] = {
		{14, 0x65, 0x43, 0x21, 0x00, 0x9A, 0xBC, 0xDE },
		{10, 0x65, 0x43, 0x22, 0xBC, 0xDE },
		{6,  0x65, 0x44, 0xDE},
		{2,  0x66},

		{16, 0x65, 0x43, 0x21, 0x00, 0x00, 0x9A, 
			0xBC, 0xDE },
		{12, 0x65, 0x43, 0x22, 0x22, 0xBC, 0xDE },
		{8,  0x65, 0x44, 0x44, 0xDE},
		{4,  0x66, 0x66},

		{18, 0x65, 0x43, 0x21, 0x00, 0x00, 0x00, 0x9A, 
			0xBC, 0xDE },
		{14, 0x65, 0x43, 0x22, 0x22, 0x22, 0xBC, 0xDE },
		{10,  0x65, 0x44, 0x44, 0x44, 0xDE},
		{6,  0x66, 0x66, 0x66},

		{20, 0x65, 0x43, 0x21, 0x00, 0x00, 0x00, 0x00, 
			0x9A, 0xBC, 0xDE },
		{16, 0x65, 0x43, 0x22, 0x22, 0x22, 0x22, 0xBC, 
			0xDE },
		{12, 0x65, 0x44, 0x44, 0x44, 0x44, 0xDE},
		{8,  0x66, 0x66, 0x66, 0x66},
	};
	
	for(i=0; i<WALNUT_BRAID; i++) {
		c->encode[i][i] = 1;
	}

	for(i=0; i<WALNUT_BRAID; i++) {
		c->p[i] = i;
	}

	for(i=0; i<WALNUT_DGST_SIZ * 2; i++) {
		uint8_t word;
		const uint8_t *b;
		uint8_t len;

		if(i % 2 == 0) {
			word = (dgst[i/2] & 0xF0) >> 4;
		} else {
			word = (dgst[i/2] & 0x0F) >> 0;
		}

		//This skips past the length in the lookup table braid
		b = braiddata[word] + 1;
		len = braiddata[word][0];

		ret = walnut_emul(c, c->encode, b, len);
		if (ret < 0)
			return ret;
	}

	return 0;
}

extern int walnut_verify_init(const void *aekey, const void *dgst,
		walnut_verify_ctx *c)
{
	uint8_t i, j;
	size_t curr_bit = 0;
	int ret = 0;

	static const uint8_t cfg[] = {
		WALNUT_BRAID_ENUM,
		WALNUT_FIELD == 32 ? 0 : 0x01,
		WALNUT_FIELD == 32 ? 32 : 0
	};
	
	const uint8_t *key = aekey;

	enum {
		FIELD_MASK = 0xFF >> (8 - WALNUT_FIELD_BIT),
		BRAID_MASK = 0xFF >> (8 - WALNUT_BRAID_BIT)
	};

	if(memcmp(cfg, key, sizeof(cfg))) {
		return -1;
	}

	memset(c, 0, sizeof(*c));
	key += 3;

	for(i=0; i<WALNUT_BRAID; i++) {
		uint8_t tv = extract_elem(key, curr_bit, 
				WALNUT_FIELD_BIT, FIELD_MASK);

		if (tv >= WALNUT_FIELD)
			return -2;

#if WALNUT_FIELD == 32
		c->mp[i] = DSA_GET_LOOKUP(tv);
		c->imp[i] = DSA_GET_LOOKUP(DSA_INVERSE(tv));
#else
		c->mp[i] = GET_LOOKUP(tv);
		c->imp[i] = GET_LOOKUP(INVERSE(tv));
#endif

		curr_bit += WALNUT_FIELD_BIT;
	}

	for(i=0; i<WALNUT_BRAID; i++) {
		for(j=0; j<WALNUT_BRAID; j++) {

			if(i == WALNUT_BRAID-1)
			{
				c->ans1[j][i] = j != WALNUT_BRAID-1 ? 0 : extract_elem(key, curr_bit,
						WALNUT_FIELD_BIT, FIELD_MASK);
			}
			else
			{
				c->ans1[j][i] = extract_elem(key, curr_bit,
						WALNUT_FIELD_BIT, FIELD_MASK);
				curr_bit += WALNUT_FIELD_BIT;
			}
		}

	}

	curr_bit += (WALNUT_FIELD_BIT + WALNUT_FIELD_MATRIX_REMAINDER);

	unsigned char newperm[WALNUT_BRAID];

	for(i=0; i<WALNUT_BRAID; i++) {
		newperm[i] = extract_elem(key, curr_bit, WALNUT_BRAID_BIT, BRAID_MASK);
		if (newperm[i] >= WALNUT_BRAID)
			return -2;

		curr_bit += WALNUT_BRAID_BIT;
	}

	for(i=0; i<WALNUT_BRAID; i++) {
			for(j=0; j<WALNUT_BRAID; j++) {

				if(i == WALNUT_BRAID-1)
				{
					c->ansprime[j][i] = j != WALNUT_BRAID-1 ? 0 : extract_elem(key, curr_bit,
							WALNUT_FIELD_BIT, FIELD_MASK);
				}
				else
				{
					c->ansprime[j][i] = extract_elem(key, curr_bit,
							WALNUT_FIELD_BIT, FIELD_MASK);
					curr_bit += WALNUT_FIELD_BIT;
				}
			}
		}

	curr_bit += (WALNUT_FIELD_BIT + WALNUT_FIELD_MATRIX_REMAINDER);

	memset(c->encode, 0, sizeof(c->encode));

	/* encode = E(dgst) aka M1, sigma1 */
	ret = process_digest(c, dgst);
	if (ret < 0)
		return -3;

#ifdef KAT_INTERMEDIATES
	print_column_major_matrix(c->encode, "E(hash) * Identity Matrix");
#endif
	
	/* ans2 = E(dgst) \dot Pub_S */
	mmul(c->d.ans2, c->encode, c->ansprime);

#ifdef KAT_INTERMEDIATES
	print_column_major_matrix(c->d.ans2, "E(hash) * Public Key");
#endif

	memcpy(c->p, newperm, WALNUT_BRAID);

	return 0;
}

extern int walnut_verify_update(walnut_verify_ctx *c, const void *sig,
		size_t len) 
{
	const uint8_t *s = sig;


	if(c->idx == 0 && len > 0) {
		c->count = *s << 8;
		s++;
		len--;
		c->idx++;
	}

	if(c->idx == 1 && len > 0) {
		c->count |= *s;
		s++;
		len--;
		c->idx++;
	}

	if(c->idx >= 2 && len > 0) {
		size_t generators = len * 2;
		/* overflow */
		if(generators < len) {
			return -1;
		}
		if(generators > c->count) {
			walnut_emul(c, c->ans1, s, c->count);
			c->count = 0;
		} else {
			walnut_emul(c, c->ans1, s, generators);
			c->count -= generators;
		}

	}

#ifdef KAT_INTERMEDIATES
	print_column_major_matrix(c->ans1, "Public Key * Signature");
#endif

	return 0;
}

extern int walnut_verify_final(walnut_verify_ctx *c)
{
	int ret = memcmp(c->ans1[0], c->d.ans2[0], sizeof(c->ans1));

	return ret == 0 ? ret : -1;
}


