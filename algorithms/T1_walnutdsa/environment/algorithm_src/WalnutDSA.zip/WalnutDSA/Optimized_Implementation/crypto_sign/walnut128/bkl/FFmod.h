/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * FFmod.h - declarations of macros/data for computing in finite fields
 */
#ifndef FFmod_H
#define FFmod_H

#include "finitefields.h"

#define ENABLE_FIELD_2
#define ENABLE_FIELD_3
#define ENABLE_FIELD_4
#define ENABLE_FIELD_5
#define ENABLE_FIELD_7
#define ENABLE_FIELD_8
#define ENABLE_FIELD_11
#define ENABLE_FIELD_16
#define ENABLE_FIELD_31
#define ENABLE_FIELD_32
#define ENABLE_FIELD_64
#ifndef __MSP430__  /* These are too big to fit on an MSP430 */
#define ENABLE_FIELD_127
#define ENABLE_FIELD_128
#define ENABLE_FIELD_256
#endif

const SrfFiniteField* ffGetFF(ffelem);

#if 0

#ifdef TWO
#define PRIMEPOWER 2
#define CHARACTERISTIC 2
#define REDUCE(n) ((n) & 0x1)
#endif

#ifdef THREE
#define PRIMEPOWER 3
#define CHARACTERISTIC 3
#define REDUCE(n) ((n)%3)
#endif

#ifdef FOUR
#define PRIMEPOWER 4
#define CHARACTERISTIC 2
#define REDUCE(n) ((n) & 0x3)
#endif

#ifdef FIVE
#define PRIMEPOWER 5
#define CHARACTERISTIC 5
#define REDUCE(n) ((n)%5)
#endif

// polynomial is x^3+x+1
#ifdef EIGHT
#define PRIMEPOWER 8
#define CHARACTERISTIC 2
#define REDUCE(n) ((n) & 0x7)
#endif

#ifdef ELEVEN
#define PRIMEPOWER 11
#define CHARACTERISTIC 11
#define REDUCE(n) ((n)%11)
#endif

// polynomial is x^4+x+1
#ifdef SIXTEEN
#define PRIMEPOWER 16
#define CHARACTERISTIC 2
#define REDUCE(n) ((n) & 0xF)
#endif

#ifdef THIRTYONE
#define PRIMEPOWER 31
#define CHARACTERISTIC 31
#define REDUCE(n) ((n)%31)
#endif

#ifdef THIRTYTWO
#define PRIMEPOWER 32
#define CHARACTERISTIC 2
#define REDUCE(n) ((n) & 0x1F)
#endif

// polynomial is x^6+x^1+1
#ifdef SIXTYFOUR
#define PRIMEPOWER 64
#define CHARACTERISTIC 2
#define REDUCE(n) ((n) & 0x3F)
#endif

// polynomial is x^7+x^1+1
#ifdef ONETWENTYEIGHT
#define PRIMEPOWER 128
#define CHARACTERISTIC 2
#define REDUCE(n) ((n) & 0x7F)
#endif

// polynomial is x^8+x^4+x^3+x^1+1
#ifdef TWOFIFTYSIX
#define PRIMEPOWER 256
#define CHARACTERISTIC 2
#define REDUCE(n) ((n) & 0xFF)
#endif


/* lookup tables for basic computations in this field */

/* mneg[x] = -x */
extern const char mneg[];

/* minv[x] = 1/x */
extern const char minv[];

/* nminv[x] = -1/x */
extern const char nminv[];

/* atable[x][y] = x+y */
extern const char atable[][PRIMEPOWER];

/* mtable[x][y] = x*y */
extern const char mtable[][PRIMEPOWER];

#endif // 0

#endif /* FFmod_H */

