/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * bands.c - band creation, processing, and conversion
 */
#include "aeutil.h"
#include "aelib.h"
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>

typedef struct {
	uint8_t *permutation;
	uint8_t *temp;
	uint8_t *identity_perm;
	uint8_t *delta_perm;
	unsigned int permsize;
	unsigned int count;
	int delta;
	uint8_t index;
} bklctx;

/*+
 * bandAllocateBandList - allocate a band list structure with the number of elements requested.
 *                        the elements will be initialized to 0
 *
 * usage:
 *        bandAllocateBandList (l)
 *
 * args:
 *       l - number of bandwords to allocate
 *
 * returns: NULL - could not allocate
 *          ae_pBandList_t - pointer to allocated bandlist
 *
 * notes:
 *       can be called with l == 0 to create a null band list
 *
 * uses:
 *      ae_malloc - allocate memory
 *      ae_calloc - allocate and clear memory
 *-
 */
ae_pBandList_t
bandAllocateBandList (unsigned int l) {
  ae_pBandList_t p;
  p = (ae_pBandList_t) ae_malloc (sizeof(ae_BandList_t));
  if (p) {
    if (l > 0) {
      p->n = l;
      p->bwl = (ae_pBandWord_t) ae_calloc(l,sizeof(ae_BandWord_t));
    } else {
      p->n = 0;
      p->bwl = NULL;
    }
  }
  return p;
}

/*+
 * bandCloneBandList - make an exact copy of a bandlist structure
 *
 * usage:
 *       bandCloneBandList (bl)
 *
 * args:
 *       bl - bandlist to be cloned
 *
 * returns:
 *       - NULL - could not allocate memory
 *       - pointer to cloned copy
 *
 * notes:
 *       if input pointer is null, then null is returned
 *
 * uses:
 *       ae_malloc
 *       bandCloneBandList
 */ 
ae_pBandList_t
bandCloneBandList (ae_pBandList_t bl) {
  ae_pBandList_t p = NULL;
  unsigned int i;
    
  if (bl) {
    p = (ae_pBandList_t) bandAllocateBandList (bl->n);
    if (p) {
      if (bl->n > 0) {
	for (i=0; i < bl->n; i++) {
	  /* sublist entry */
	  if (bl->bwl[i].bl) {
	    p->bwl[i].bl = bandCloneBandList (bl->bwl[i].bl);
	  } else if (bl->bwl[i].d) {  /* delta */
	    p->bwl[i].d = bl->bwl[i].d;
	  } else {                    /* bandword */
	    p->bwl[i].s[0] = bl->bwl[i].s[0];
	    p->bwl[i].s[1] = bl->bwl[i].s[1];
	    p->bwl[i].e    = bl->bwl[i].e;
	  }
	}
      } else {
	p->n = 0;
	p->bwl = NULL;
      }
    }
  }
  return p;
}

/*+
 * bandAppendToBandList - append a bandlist to an existing bandlist 
 *
 * usage:
 *         bandAppendToBandList (bl,s)
 * 
 * args:
 *        bl - bandlist to be appended to
 *        s - bandlist to append
 *
 * returns:
 *         N/A
 *
 * notes:
 *        Bandlists support the notion of lists of individual lists of band words
 *        hence the bl field in the band word structure is meant to allow for this
 *        and all that this function does is to extend the first band list by one
 *        and add the specified bandlist to the end as another list.
 *
 * uses:
 *       ae_realloc
 *       bandCloneBandList
 *-
 */
void
bandAppendToBandList (ae_pBandList_t bl, ae_pBandList_t s) {
  bl->n++;
  bl->bwl = (ae_pBandWord_t) ae_realloc (bl->bwl, bl->n*sizeof(ae_BandWord_t));
  bl->bwl[bl->n-1].bl = bandCloneBandList (s);
  bl->bwl[bl->n-1].d = 0;
  bl->bwl[bl->n-1].s[0] = 0;
  bl->bwl[bl->n-1].s[1] = 0;
  bl->bwl[bl->n-1].e = 0;
    
}

/*+
 * bandAppendBandListToBandList - append one bandlist to another at the same level.
 *
 * usage: bandAppendBandListToBandList (bl, s)
 *
 * args:
 *      bl - target band list
 *      s  - band list to append onto the end of bl
 *
 * returns:
 *     N/A
 *
 * notes:
 *      bandlists are multi level, this routine will join one bandlist to another
 *      at the same level. The assumption is that the list being joined is a single
 *      level list. Otherwise, strange things may happen when one goes to free the
 *      result of this function.
 *
 * uses:
 *      ae_realloc
 *
 *-
 */
void
bandAppendBandListToBandList (ae_pBandList_t bl, ae_pBandList_t s) {
  int i;
  if (s->n == 0) {
    return;
  }
  bl->bwl = ae_realloc (bl->bwl, (bl->n+s->n)*sizeof(ae_BandWord_t));
  for (i=0; i < s->n; i++) {
    bl->bwl[bl->n+i] = s->bwl[i];
  }
  bl->n += s->n;  /* Set new length */
}

/*+
 * bandAppendToBandListEx - append a bandlist to an existing bandlist, flattening the list
 *                          by one level.
 *
 * usage:
 *         bandAppendToBandListEx (bl,s)
 * 
 * args:
 *        bl - bandlist to be appended to
 *        s - bandlist to append
 *
 * returns:
 *         N/A
 *
 * notes:
 *        Bandlists support the notion of lists of individual lists of band words
 *        hence the bl field in the band word structure is meant to allow for this
 *        and all that this function does is to extend the first band list by one
 *        and add the specified bandlist to the end as another list.
 *
 * uses:
 *       ae_realloc
 *       bandCloneBandList
 *-
 */
void
bandAppendToBandListEx (ae_pBandList_t bl, ae_pBandList_t s) {
  unsigned int i,j,len;
  len = bl->n+s->n;
  bl->bwl = (ae_pBandWord_t) ae_realloc (bl->bwl, len*sizeof(ae_BandWord_t));
  for (i=bl->n,j=0; i < len; i++,j++) {
    bl->bwl[i].bl = bandCloneBandList (s->bwl[j].bl);
    bl->bwl[i].d    = s->bwl[j].d;
    bl->bwl[i].s[0] = s->bwl[j].s[0];
    bl->bwl[i].s[1] = s->bwl[j].s[1];
    bl->bwl[i].e    = s->bwl[j].e;
  }
  bl->n = len;
}

/*+
 * bandFreeBandList - free a bandlist allocated with bandAllocateBandList.
 *
 * usage:
 *       bandFreeBandList (bl)
 *
 * args:
 *       bl - pointer to bandlist to free
 *
 * returns: N/A
 *
 * notes:
 *
 * uses:
 *      ae_free - free memory allocated by ae_calloc, ae_malloc, or ae_realloc
 *-
 */
void
bandFreeBandList (ae_pBandList_t bl) {
  unsigned int i;

  if (bl != NULL) {
    for (i=0; i < bl->n; i++) {
      bandFreeBandList (bl->bwl[i].bl);
    }
    if (bl->bwl)
      ae_free (bl->bwl);
    ae_free (bl);
  }
}

/*+
 * bandAllocateIntList - allocate a list of integers
 * 
 * usage:
 *        bandAllocateIntList (n)
 *
 * args:
 *      n - number of integer slots to allocate
 *
 * returns:
 *         - NULL - could not allocate memory
 *         - pointer to allocated list
 *
 * notes:
 *       use bandFreeIntList to free the allocated list
 *
 * uses:
 *      ae_malloc
 *      ae_calloc
 *-
 */
ae_pIntList_t
bandAllocateIntList (unsigned int l) {
  ae_pIntList_t p;
  p = (ae_pIntList_t) ae_malloc (sizeof(ae_IntList_t));
  if (p) {
    if (l > 0) {
      p->n = l;
      p->items = (unsigned int *) ae_calloc (l, sizeof (unsigned int));
    } else {
      p->n = 0;
      p->items = NULL;
    }
  }
  return p;
}

/*+
 * bandFreeIntList - free a allocated integer list
 * 
 * usage:
 *        bandFreeIntList (p)
 *
 * args:
 *        p - pointer to integer list to free
 *
 * returns:
 *        N/A
 *
 * notes:
 *
 * uses:
 *      ae_free
 *
 *-
 */
void
bandFreeIntList (ae_pIntList_t p) {
  if (p != NULL) {
    if (p->n > 0)
      ae_free (p->items);
    ae_free (p);
  }
}

/*+
 * bandAllocateListOfIntLists - allocate a list of individual integer lists
 *
 * usage:
 *         bandAllocateListOfIntLists (n)
 *
 * args:
 *         n - number of slots to allocate. 0 is ok.
 *
 * returns:
 *        - NULL - could not allocate memory
 *        - pointer to list of int lists allocated
 *
 * notes:
 *
 * uses:
 *       ae_malloc
 *       ae_calloc
 *
 *-
 */
ae_pListOfIntLists_t
bandAllocateListOfIntLists (unsigned int n) {
  ae_pListOfIntLists_t l;

  l = (ae_pListOfIntLists_t) ae_malloc (sizeof(ae_ListOfIntLists_t));
  if (n > 0) {
    l->n = n;
    l->p = (ae_pIntList_t *) ae_calloc (n,sizeof(ae_pIntList_t));
  } else {
    l->n = 0;
    l->p = NULL;
  }
  return l;
}

/*+
 * bandAppendToListOfIntLists - append to the end of the list of lists
 *
 * usage:
 *         bandAppendToListOfIntLists (l,p)
 *
 * args:
 *         l - list to append to
 *         p - int list to append
 *
 * returns:
 *         N/A
 *
 * notes:
 *        NULL pointer to list results in nothing being changed.
 *        item becomes part of appended list, must not be freed except in
 *        the context of the larger list.
 *
 * uses:
 *       ae_realloc
 *-
 */
void
bandAppendToListOfIntLists (ae_pListOfIntLists_t l, ae_pIntList_t p) {
  if (l != NULL) {
    l->p = (ae_pIntList_t *) ae_realloc (l->p, (l->n+1) * sizeof(ae_pIntList_t));
    l->p[l->n++] = (ae_pIntList_t) p;
  }
}

/*+
 * bandFreeListOfIntLists - free a list of int lists
 *
 * usage:
 *        bandFreeListOfIntLists (l, flags)
 *
 * args:
 *       l - pointer to list to free
 *       flags - if 1, then free each individual int list first
 *
 * returns:
 *         N/A
 *
 * notes:
 *
 * uses:
 *       bandFreeIntList
 *       ae_free
 *
 *-
 */
void
bandFreeListOfIntLists (ae_pListOfIntLists_t l, unsigned int flags) {
  unsigned int i;
  if (l != NULL) {
    if (flags) {
      for (i=0; i < l->n; i++) {
	bandFreeIntList (l->p[i]);
	l->p[i] = NULL;
      }
    }
    if (l->p)
      ae_free(l->p);
    ae_free (l);
  }
}

/*+
 * bandDelta - produce a delta band list of the specified size
 *
 * usage:  bandDelta (n)
 *
 * args:
 *         n - size of list
 *
 * returns:
 *         NULL - could not allocate memory
 *         pointer to created delta bandlist
 *
 * notes:
 *
 * uses:
 *      bandAllocateBandList - allocates an empty bandlist
 *-
 */
ae_pBandList_t
bandDelta(unsigned int n) {
  ae_pBandList_t bl = NULL;
  unsigned int i;

  if (n > 0) {
    bl = bandAllocateBandList (n-1);
    for (i=0; i < n-1; i++) {
      bl->bwl[i].s[0] = n-i;
      bl->bwl[i].s[1] = n-i-1;
      bl->bwl[i].e = 1;
    }
  }
  return bl;
}

/*+
 * bandGenToArtinWord - convert a band generator to an Artin Word
 *
 * usage:
 *        bandGenToArtinWord (bw)
 *
 * args:
 *        bw - band word generator to convert
 *
 * returns:
 *        NULL - could not allocate memory
 *        pointer to Artin Word
 *
 * notes:
 *
 * uses:
 *       braidAllocateBraidList
 *       braidFreeBraidList
 *
 *-
 */
ae_plist_t
bandGenToArtinWord(ae_pBandWord_t bw) {
  ae_plist_t leftSide, rightSide,aw = NULL;
  unsigned int i, t, s;
  char e;
  unsigned int ai=0,lc=0,rc=0;

  if (bw != NULL) {
    t = bw->s[0];
    s = bw->s[1];
    e = bw->e;
    leftSide = braidAllocateBraidlist(t);
    for (i=s+1; i < t; i++) {
      leftSide->b[lc].l = s+t-i;
      leftSide->b[lc].u = 1;
      lc++;
    }
    rightSide = braidAllocateBraidlist(t);
    for (i=s+1; i<t;i++) {
      rightSide->b[rc].l = i;
      rightSide->b[rc].u = (ae_braiddata_t) -1;
      rc++;
    }
    /*
     * join(leftside,mid,rightside)
     */
    aw = braidAllocateBraidlist(lc+rc+1);
    for (i=0; i<lc; ai++,i++) {
      aw->b[ai].l = leftSide->b[i].l;
      aw->b[ai].u = leftSide->b[i].u;
    }

    aw->b[ai].l   = s;
    aw->b[ai++].u = e;

    for (i=0; i<rc; ai++,i++) {
      aw->b[ai].l = rightSide->b[i].l;
      aw->b[ai].u = rightSide->b[i].u;
    }
    braidFreeBraidlist (&leftSide);
    braidFreeBraidlist (&rightSide);
  }
  return aw;
}
 
/*+
 * bandWordToArtinWord - convert a bandword list to a braidword list
 *
 * usage:
 *        bandWordToArtinWord (bl)
 *
 * args:
 *        bl - pointer to band word list
 *
 * returns:
 *        NULL - could not allocate memory
 *        pointer to created braid list
 *
 * notes:
 *       
 * uses:
 *       braidAllocateBraidList
 *       bandGenToArtinWord
 *       braidFreeBraidlist
 *
 *-
 */
ae_plist_t
bandWordToArtinWord(ae_pBandList_t bl) {
  ae_plist_t aw = NULL;
  ae_plist_t temp;
  unsigned int i,len=0,j,k;
  if (bl && bl->n) {
    /*
     * run through once to figure out how big the list will be.  there
     * must be a better way to do this.  this uses a lot of
     * malloc/free for what should be a simple computation.
     */
    for (i=0; i < bl->n; i++) {
      temp = bandGenToArtinWord(&bl->bwl[i]);
      len += temp->len;
      braidFreeBraidlist(&temp);
    }
    aw = braidAllocateBraidlist(len);
    for (i=0,j=0; i < bl->n; i++) {
      temp = bandGenToArtinWord(&bl->bwl[i]);
      for (k=0; k < temp->len; k++) {
	aw->b[j].l   = temp->b[k].l;
	aw->b[j++].u = temp->b[k].u;
      }
      braidFreeBraidlist(&temp);
    }
  }
  return aw;
}
 
/*+
 * bandInverseOf - determine the inverse of the input band word list
 *
 * usage:
 *        bandInverseOf(bl)
 *
 * args:
 *        bl - band word list
 *
 * returns:
 *        NULL - could not allocate memory
 *        pointer to new band word list now inverted
 *
 * notes:
 *
 * uses:
 *        bandAllocateBandList
 *-
 */
ae_pBandList_t
bandInverseOf(ae_pBandList_t bl) {
	ae_pBandList_t ibl = NULL;
	unsigned int i;

	if (bl != NULL) {
		ibl = bandAllocateBandList(bl->n);
		for (i = 0; i < bl->n; i++) {
			ibl->bwl[i].s[0] = bl->bwl[bl->n - i - 1].s[0];
			ibl->bwl[i].s[1] = bl->bwl[bl->n - i - 1].s[1];
			ibl->bwl[i].e = -bl->bwl[bl->n - i - 1].e;
		}
	}
	return ibl;
}
 
/*+
 * bandMultiplyPermutations - gives the product of the permutations a and b in the symmetric 
 *                            group on n symbols
 * 
 * usage:
 *        bandMultiplyPermutations(a,b)
 *
 * args:
 *        a - first permutation
 *        b - second permutation
 *
 * returns:
 *        - NULL - cannot allocate memory
 *        - pointer to the product list
 *
 * notes:
 *
 * uses:
 *      bandAllocatePermutation
 *-
 */
ae_pPermutation_t
bandMultiplyPermutations(ae_pPermutation_t a, ae_pPermutation_t b) {
  ae_pIntList_t result;
  unsigned int i;

  result = bandAllocatePermutation (a->n);
  if (result) {
    for (i=0; i < a->n; i++) {
      result->items[i] = a->items[(b->items[i]-1)];
    }
  }
  return result;
}

/*+
 * bandIntListIndexOf - finds the index of a member in an intlist
 *
 * usage:
 *        bandIntListIndexOf(a,m)
 *
 * args:
 *        a - int list to search
 *        b - member to search for
 *
 * returns:
 *        - -1 - cannot find member
 *        - 0-index into list if member is found
 *
 * notes:
 *
 * uses:
 *
 *-
 */
int
bandIntListIndexOf(const ae_pIntList_t a, unsigned int m)
{
  int i;

  if (!a)
    return -1;

  for (i=0; i < a->n; i++) {
    if (a->items[i] == m)
      return i;
  }
  return -1;
}

/*+
 * bandToCycles - gives the cycle structure of permutation p as a list of cyclic permutations
 *
 * usage:
 *         bandToCycles (p)
 *
 * args:
 *        p - permutation to convert to cyclic form
 *
 * returns:
 *        - NULL - could not allocate memory
 *        - pointer to list of cyclic permutations
 *
 * notes:
 *        Converted from the Combinatorica Mathematica library. If you have a
 *        Mathematica installation, see Packages\Combinatorica\Combinatorica.nb
 *        for more details.
 *
 * uses:
 *       bandAllocatePermutation
 *       bandAllocateCycles
 *       bandAppendToCycles
 *       bandFreeCycles
 *       bandFreePermutation
 *-
 */
ae_pListOfIntLists_t
bandToCycles (ae_pIntList_t p) {
  int k, j, first;
  ae_pIntList_t np, q, temp;
  ae_pListOfIntLists_t t, answer = NULL;
  unsigned int i;
  int ii,cases=0;

  t = bandAllocateCycles(0);
  /*
   * Make a copy of the input list
   */
  np = bandAllocatePermutation (p->n);
  for (i=0; i < p->n; i++) {
    np->items[i] = p->items[i];
  }
  q = bandAllocatePermutation (p->n);

  for (i=0; i < p->n; i++) {
    if (np->items[i] == 0) {
      bandAppendToCycles (t, bandAllocatePermutation(0));
    } else {
      j = 0;
      first = np->items[i];
      np->items[i] = 0;
      k = q->items[j++] = first;
      while (np->items[k-1] != 0) {
	q->items[j++] = np->items[k-1];
	np->items[k-1] = 0;
	k = q->items[j-1];
      }
      temp = bandAllocatePermutation (j);
      for (ii=0; ii < j; ii++) {
	temp->items[ii] = q->items[ii];
      }
      bandAppendToCycles (t, temp);
      cases++;
    }
  }
  bandFreePermutation (np);
  bandFreePermutation (q);
  /*
   * now pull out the non-null cases
   */
  answer = bandAllocateCycles (cases);
  for (i=0,k=0; i < p->n; i++) {
    if (t->p[i]->n != 0) {
      answer->p[k++] = t->p[i];
      t->p[i] = NULL;
    }
  }
  bandFreeCycles (t, 1);

  return answer;

}
 
/*+
 * bandCyclesToCanonicalFactor - converts cycles from a list of parallel descending cycles, 
 *                               into a canonical factor
 *
 * usage:
 *          bandCyclesToCanonicalFactor (l)
 *
 * args:
 *          l - cycles list
 *
 * returns:
 *          - NULL - could not allocate memory
 *          - pointer to canonical factor
 *
 * notes:
 *
 * uses:
 *       bandAllocateBandList
 *       bandFreeBandList
 *
 *-
 */
ae_pBandList_t
bandCyclesToCanonicalFactor(ae_pCycles_t l) {
  unsigned int i,j,k;
  ae_pBandList_t temp,t1,answer;

  answer = bandAllocateBandList (0);

  for (i=0; i<l->n; i++) {
    if (l->p[i]->n >1) {
      temp = bandAllocateBandList (l->p[i]->n-1);
      for (j=0; j < l->p[i]->n-1;j++) {
	temp->bwl[j].s[0] = l->p[i]->items[j];
	temp->bwl[j].s[1] = l->p[i]->items[j+1];
	temp->bwl[j].e    = 1;
      }
      /* prepend onto the answer */
      t1 = bandAllocateBandList (answer->n + temp->n);
      for (j=0; j < temp->n; j++) {
	t1->bwl[j].s[0] = temp->bwl[j].s[0];
	t1->bwl[j].s[1] = temp->bwl[j].s[1];
	t1->bwl[j].e    = temp->bwl[j].e;
      }
      for (k=0; k < answer->n; k++,j++) {
	t1->bwl[j].s[0] = answer->bwl[k].s[0];
	t1->bwl[j].s[1] = answer->bwl[k].s[1];
	t1->bwl[j].e    = answer->bwl[k].e;
      }
      bandFreeBandList (temp);
      bandFreeBandList (answer);
      answer = t1;
    }
  }
  return answer;
}

/*+
*
* bandRandomPermutation - generate a random permutation based on n
*
* usage: bandRandomPermutation(n)
*
* args:
*       n - length and max value of permutation items
*
* returns:
*      pointer to permutation array
*
* notes:
*      return pointer must be freed by caller
*
* uses:
*      bandAllocatePermutation
*      braidGetRandomInRange
*
*-
*/
ae_pPermutation_t
bandRandomPermutation(unsigned int  n) {
	int i, j;
	ae_pPermutation_t p;
	int tmp;

	p = bandAllocatePermutation(n);

	for (i = 0; i<n; i++)
		p->items[i] = i + 1;
	for (i = n - 1; i != 0; i--) {
		j = braidGetRandom(i + 1);
		tmp = p->items[i];
		p->items[i] = p->items[j];
		p->items[j] = tmp;
	}
	return p;
}
 
/*+
 * bandSetOfCanonicalFactorsToBandWord - take a list of canonical factors and convert
 *                                       them to BandWords
 *
 * usage:
 *       bandSetOfCanonicalFactorsToBandWord (bl)
 *
 * args:
 *       bl - list of canonical factors
 *
 * returns:
 *       NULL - could not allocate memory
 *       pointer to list of band words
 *
 * notes:
 *
 * uses:
 *      bandCloneBandList
 *      bandAppendToBandListEx
 *-
 */
ae_pBandList_t
bandSetOfCanonicalFactorsToBandWord (ae_pBandList_t bl) {
  ae_pBandList_t answer;
  unsigned int i;

  answer = bandCloneBandList (bl->bwl[0].bl);
  if (bl->n > 1) {
    for (i=1; i < bl->n; i++) {
      bandAppendToBandListEx (answer, bl->bwl[i].bl);
    }
  }
  return answer;
}
 
/*+
 * bandDrop - drop an element of a band list
 *
 * usage:  bandDrop (bl, elem)
 *
 * args:
 *        bl   - bandlist to operate on
 *        elem - element number to drop
 *
 * returns:
 *        new bandlist with the element removed
 *
 * notes:
 *
 * uses:
 *
 *-
 */
ae_pBandList_t
bandDrop (ae_pBandList_t bl, unsigned int elem) {
  ae_pBandList_t p = NULL;
  unsigned int i,k;

  if (bl) {
    p = (ae_pBandList_t) bandAllocateBandList (bl->n-1);
    if (p) {
      if (bl->n > 0) {
	for (i=0,k=0; i < bl->n; i++) {
	  if (elem == i) /* if element to be removed, skip copying */
	    continue;
	  /* sublist entry */
	  if (bl->bwl[i].bl) {
	    p->bwl[k++].bl = bandCloneBandList (bl->bwl[i].bl);
	  } else if (bl->bwl[i].d) {  /* delta */
	    p->bwl[k++].d = bl->bwl[i].d;
	  } else {                    /* bandword */
	    p->bwl[k].s[0] = bl->bwl[i].s[0];
	    p->bwl[k].s[1] = bl->bwl[i].s[1];
	    p->bwl[k++].e    = bl->bwl[i].e;
	  }
	}
      } else {
	p->n = 0;
	p->bwl = NULL;
      }
    }
  }
  return p;
}
 
/*+
 * bandAllocateTranspositions - allocate a transposition list
 *
 * usage: bandAllocateTranspositions (len)
 *
 * args:
 *      len - length of transposition to allocate
 *
 * returns:
 *      pointer to transposition list or NULL if memory could not be allocated
 *
 * notes:
 *
 * uses:
 *      ae_calloc
 *      ae_free
 *-
 */ 
ae_pTranspositions_t
bandAllocateTranspositions (unsigned int len) {
  ae_pTranspositions_t p;

  p = (ae_pTranspositions_t) ae_calloc (1, sizeof (ae_Transpositions_t));
  if (!p)
    return NULL;

  p->len = len;
  p->v = (ae_pTransposition_t *) ae_calloc (len, sizeof (ae_pTransposition_t));
  if (!p->v) {
    ae_free (p);
    return NULL;
  }
  return p;
}

/*+
 * bandAllocateTransposition - allocate a transposition
 *
 * usage: bandAllocateTransposition (len)
 *
 * args:
 *      len - length of transposition to allocate
 *
 * returns:
 *      pointer to transposition or NULL if memory could not be allocated
 *
 * notes:
 *
 * uses:
 *      ae_calloc
 *      ae_free
 *-
 */
ae_pTransposition_t
bandAllocateTransposition (unsigned int len) {
  ae_pTransposition_t p;

  p = (ae_pTransposition_t) ae_calloc (1,sizeof(ae_Transposition_t));
  if (!p)
    return NULL;
  p->len = len;
  p->data = (ae_pTranspositionData_t) ae_calloc (len, sizeof(ae_TranspositionData_t));
  if (!p->data) {
    ae_free (p);
    return NULL;
  }
  return p;
}

/*+
 * bandFreeTransposition - free a previously allocated transposition
 *
 * usage: bandFreeTransposition (ptr)
 *
 * args:
 *      ptr - pointer to transposition to free
 *
 * returns: N/A
 *
 * notes:
 *
 * uses:
 *       ae_free
 *
 *-
 */
void
bandFreeTransposition (ae_pTransposition_t p) {
  if (p) {
    if (p->data)
      ae_free (p->data);
    ae_free (p);
  }
}

/*+
 * bandFreeTranspositions - free a list of transpositions
 *
 * usage: bandFreeTransposition (ptr, flags)
 *
 * args:
 *      ptr - pointer to list of transpositions
 *      flags - if 1, then free all transpositions as well
 *
 * returns: N/A
 *
 * notes:
 *
 * uses:
 *      ae_free
 *
 *-
 */
void
bandFreeTranspositions (ae_pTranspositions_t p, unsigned int flags) {
  if (p) {
    if (p->v) {
      if (flags) {
	int i;
	for (i=0; i<p->len; i++) {
	  bandFreeTransposition(p->v[i]);
	  p->v[i] = NULL;
	}
      }
      ae_free (p->v);
    }
    ae_free (p);
  }
}

/*+
 * bandAppendTranspositionsToTranspositions - concatenate two transpositions
 *
 * usage: bandAppendTranspositionsToTranspositions (d,s)
 *
 * args:
 *      d - destination transposition
 *      a - source transposition
 *
 * returns: N/A
 *
 * notes:
 *
 * uses:
 *     ae_realloc
 *
 *-
 */
void
bandAppendTranspositionsToTranspositions (ae_pTranspositions_t d, ae_pTranspositions_t a) {
  int i;
  d->v = (ae_pTransposition_t *) ae_realloc (d->v,(d->len+a->len)*sizeof(ae_pTransposition_t));
  for (i=0; i < a->len; i++) {
    d->v[d->len++] = a->v[i];
  }
}


/* \delta\tau(n) = n\delta.  Used to move rightmost deltas to the
 * beginning of the permutation list
 *
 * As defined in the paper,
 * \tau(a_{ts}) = a_{(t+1)(s+1) and
 * \tau^{-1}(a_{ts}) = a_{(t-1)(s-1).
 *
 * delta refers to the number of iterations which tau must run.  That
 * is, to move \delta^{n} to the left of the permutation perm, apply
 * \tau^{n}(perm)
 */
static void tau(uint8_t *perm, int delta, void *tmp, uint8_t index)
{
	uint8_t i;
	uint8_t *difference = tmp;

	delta = delta % index;

	if(delta < 0) {
		delta += index;
	}

	for(i=0; i<index; i++) {
		difference[i] = (perm[i] - i) % index;
	}

	for (i = 0; i<index; i++) {
		int idx = (i - delta) % index;
		int t;

		if (idx < 0) {
			idx += index;
		}

		t = (i + difference[idx]) % index;
		if (t < 0) {
			t += index;
		}

		perm[i] = (uint8_t)t;
	}
}

enum {
	SIGN_BIT = 0x80
};

/* multiply band generator that takes `to' to `from' by a permutation
 * perm.
 */
static void band_mul(uint8_t to, uint8_t from, uint8_t *perm,
		uint8_t index)
{
	uint8_t toaddr = 0;
	uint8_t fromaddr = 0;
	uint8_t i;
	for(i=0; i<index; i++) {
		if(perm[i] == to) {
			toaddr = i;
		}

		if(perm[i] == from) {
			fromaddr = i;
		}
	}

	perm[fromaddr] = to;
	perm[toaddr] = from;
}

/* Convert as many Artin generators as possible to the permutation
 * representation of a canonical factor.  This includes converting
 * negative generators to positive, descending cycles by multiplying
 * them by \delta.  This function uses a greedy algorithm to combine as
 * many positive Artin generators into a single canonical factor as
 * possible.  It will add Artin generators to a canonical factor until
 * two elements in the canonical factor form an obstructing pair, or in
 * this case if, for two positive generators a_i and a_j,
 * a_i - a_j <= 1 and
 * a_i < a_j
 *
 * TODO: it may be possible to also combine negative factors into a
 * single canonical factor and a positive delta.
 */
static unsigned int artin2canonical(uint8_t *canonical, const uint8_t *artin,
  unsigned int count, const uint8_t *identity, const uint8_t *delta,
  uint8_t index)
{
	if(*artin & SIGN_BIT) { /* negative */
		uint8_t from = *artin & ~SIGN_BIT;
		uint8_t to = (from + 1) % index;
		int t;

		memcpy(canonical, delta, index);
		t = (to - 1) % index;
		if(t < 0) {
			t += index;
		}
		canonical[from] = t;

		t = (from - 1) % index;
		if(t < 0) {
			t += index;
		}
		canonical[to] = t;


		return 1;
	} else {
		unsigned int i;
		int last = -1;
		memcpy(canonical, identity, index);

		for(i=0; i<count; i++) {
			uint8_t to = *artin;
			uint8_t from = (to + 1) % index;
			bool isnegative = (*artin & SIGN_BIT) != 0;

			/* combine only positive, descending cycles */
			if(isnegative || to <= last) {
				break;
			}

			/* this heuristic algorithm won't necessarily
			 * work if the band wraps from index to 0, so
			 * don't bother combining those elements
			 */
			if(last != -1 && from == 0) {
				break;
			}

			last = to;
			band_mul(to, from, canonical, index);

			artin--;
		}

		return i;
	}
}

/* Apply steps 1 and 2 in the bkl paper by iterating backwards over the
 * array of Artin generators pointed to by artin once.  That is,
 * delta^{c->delta} is at index i and all canonical factors to the right
 * of i are positive and contain no deltas.
 */
static unsigned int first_rewrite(bklctx *c, const uint8_t *artin,
  unsigned int count)
{
	unsigned int i;
	unsigned int processed = 0;
	unsigned int canonical_count = 0;
	uint8_t *perm =  c->permutation;

	/* iterate backwards through count generators in artin,
	 * converting each generator to a permutation
	 */
	for(i=0; i < count; i += processed, canonical_count++) {
		uint8_t *dest = &perm[(c->permsize - 1 -
		  canonical_count) * c->index];

		processed = artin2canonical(dest,
		  &artin[count - i - 1], count - i,
		  c->identity_perm, c->delta_perm, c->index);
		tau(dest, c->delta, c->temp, c->index);

		/* if the last canonical factor was negative
		 * artin2canonical multiplied it by \delta.  Prepend
		 * \delta^{-1}
		 */
		if(artin[count - i-1] & SIGN_BIT) {
			c->delta--;
		}
	}

	/* Some Artin generators may not have been combined so the array
	 * of permutations may not be full.  Move the permutations back
	 * to the beginning of the struct.
	 */
	memmove(perm, &perm[(c->permsize -
	  canonical_count) * c->index], canonical_count * c->index);
	return canonical_count;
}

static const uint8_t logtable[256] = {
#define LT(n) n, n, n, n, n, n, n, n, n, n, n, n, n, n, n, n
	0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3,
	LT(4), LT(5), LT(5), LT(6), LT(6), LT(6), LT(6),
	LT(7), LT(7), LT(7), LT(7), LT(7), LT(7), LT(7), LT(7)
};


static uint8_t high_bit(uint64_t n)
{
	uint8_t ret = 0x0;
	for(; n > 0xFF; n >>= 8) {
		ret += 8;
	}

	ret += logtable[n];
	return ret;
}

/* computes the meet (denoted by ^ in the paper) of a and b.
 * Informally, the meet of two canonical factors is the union of the
 * cycles in both a and b.  Using the example in the paper,
 * a = (5, 4, 1)(3,2)
 * b = (4, 2, 1)
 * a ^ b = (4, 1)
 *
 * This code creates two arrays of bitfields that denote descending
 * cycles.  Any bit set in the bitfield means that the corresponding
 * element is in the cycle.  For example, the cycles above would be
 * denoted (omitting elements with 1 cycle as above)
 * a = (0x31)(0x0C)
 * b = (0x13)
 * a & b = (0x11) = (0x11)
 * Once bitfields have been generated the meet of two elements can be
 * detected by anding values at the same index.  If a lower bit is set
 * that is the next value in the cycle.  If not, the cycle repeats and
 * the highest bit set is the beginning of the cycle.
 */
static void meet(uint8_t *out, const uint8_t *a, const uint8_t *b,
		uint64_t *temp, uint8_t index)
{

	uint64_t *a_cycles = temp;
	uint64_t *b_cycles = temp + index;

	uint8_t i;
	uint64_t mask;
	uint64_t mask_init = UINT64_MAX >> (1 + 64 - index);

	memset(a_cycles, 0, index * sizeof(a_cycles[0]));
	memset(b_cycles, 0, index * sizeof(b_cycles[0]));

	for(i=index; i>0; i--) {
		uint64_t cycle_bit = (uint64_t) 1u << (i-1);

		uint64_t acycle = a_cycles[i-1] | cycle_bit;
		a_cycles[a[i-1]] = acycle;
	}

	for(i=index; i>0; i--) {
		a_cycles[a[i-1]] = a_cycles[i-1];
	}

	for(i=index; i>0; i--) {
		uint64_t cycle_bit = (uint64_t) 1u << (i-1);

		uint64_t bcycle = b_cycles[i-1] | cycle_bit;
		b_cycles[b[i-1]] = bcycle;
	}

	for(i=index; i>0; i--) {
		b_cycles[b[i-1]] = b_cycles[i-1];
	}

	for(i=index, mask = mask_init; i>0; i--, mask >>= 1) {
		uint64_t meet = a_cycles[i-1] & b_cycles[i-1];
		uint64_t lower_cycles = meet & mask;

		if(lower_cycles) {
			out[i-1] = high_bit(lower_cycles);
		} else {
			out[i-1] = high_bit(meet);
		}
	}
}

/* mul: multiply two permutations a and b */
static void mul(uint8_t *out, const uint8_t *a, const uint8_t *b,
		uint8_t index)
{
	uint8_t i;

	for(i=0; i<index; i++) {
		out[i] = a[b[i]];
	}
}

/* find the right complement of a relative to b.  That is,
 * a * out = b
 */
static void right_complement(uint8_t *out, const uint8_t *a,
		const uint8_t *b, uint8_t *temp, uint8_t index)
{

	uint8_t i;

	for(i=0; i<index; i++) {
		temp[a[i]] = i;
	}


	mul(out, temp, b, index);
}

/* Apply the \Gamma operator to a and b, storing the resulting a' and b'
 * back in a and b.  This closely follows the algorithm described in
 * lemma 4.3.
 */
static void left_weight(uint8_t *a, uint8_t *b, uint8_t *temp,
		const uint8_t *delta, uint8_t index)
{
	uint8_t *c = temp;
	uint8_t *t0 = c + index;
	uint8_t *t1 = t0 + index;
	uint64_t *t1_meet = (uint64_t *) t1;
	uint8_t *t2 = t1 + index;

	right_complement(t0, a, delta, t2, index);
	meet(c, t0, b, t1_meet, index);

	mul(t1, a, c, index);
	right_complement(t0, c, b, t2, index);

	memcpy(a, t1, index);
	memcpy(b, t0, index);
}

/* unbiased check for probability */
static int roll_success(int chance)
{
	ae_uint32_t n;
	if(chance >= 100) {
		return 1;
	}

	do {
		n = braidGetRandom(1024);
	} while(n >= 1000);

	return n < (chance * 10);

}

/* Iterate backwards through the permutation array in c, left weighting
 * each value.  Each iteration may produce a delta at the beginning or
 * an identity matrix at the end.  Before each iteration, remove any
 * identity matrices at the end and add any deltas into the power of
 * delta variable c->delta.
 */
static void full_left_weight(bklctx *c, int backchance, 
		int forwardchance, int startindex)
{
	size_t i, j;
	size_t factors_begin = 0;
	size_t factors_end = 1;
	uint8_t *perm = c->permutation;

	if(startindex >= c->count) {
		startindex = c->count - 1;
	}

	factors_end += startindex;

	for(i=factors_end; i<c->count; i++) {
		memmove(&perm[factors_end * c->index],
		  &perm[i * c->index], c->index);

		if(!roll_success(forwardchance)) {
			factors_end++;
			continue;
		}

		for(j=factors_end; j>factors_begin; j--) {
			if(roll_success(backchance)) {
			left_weight(&perm[(j-1) * c->index], &perm[j * c->index], c->temp, c->delta_perm, c->index);
			}
		}

		if(!memcmp(&perm[factors_begin * c->index],
		  c->delta_perm, c->index) && factors_begin < i) {
			factors_begin++;
		}

		if(!memcmp(&perm[factors_end * c->index],
		  c->identity_perm, c->index) &&
		  factors_end > factors_begin) {
			factors_end--;
		}

		factors_end++;
	}

	c->count = factors_end - factors_begin;
	memmove(perm, &perm[factors_begin * c->index],
	  c->index * c->count);
	c->delta += factors_begin;
}

static void init_identity(uint8_t *perm, uint8_t index)
{
	uint8_t i;
	for(i=0; i<index; i++) {
		perm[i] = i;
	}
}

static void init_delta(uint8_t *perm, uint8_t index)
{
	uint8_t i;
	perm[0] = index - 1;
	for(i=1; i<index; i++) {
		perm[i] = i-1;
	}
}

static int bkl(bklctx *c, const uint8_t *artin, unsigned int count,
	int delta, uint8_t index, int backchance, int forwardchance, unsigned int startindex)
{
	c->delta = delta;
	c->permsize = count;
	c->index = index;
	init_identity(c->identity_perm, index);
	init_delta(c->delta_perm, index);
	c->count = first_rewrite(c, artin, count);

	full_left_weight(c, backchance, forwardchance, startindex);

	return c->delta;
}

ae_pBandList_t
bklwrap(ae_plist_t braid, unsigned int n, unsigned int len, int u,
        unsigned int backchance, unsigned int forwardchance, unsigned int
	startindex)

{
	bklctx c;
	uint8_t *artin;
	size_t alloc_len = n * len;
	int i;
	ae_pBandList_t ret;
	ae_pIntList_t perm;

	if(n > 64) {
		return NULL;
	}

	artin = malloc(len);

	/* allocate all bklctx data with one malloc */
	alloc_len += n * (16 + 2);
	alloc_len += n * 2;

	c.permutation = malloc(alloc_len);
	c.temp = c.permutation + (n * len);
	c.identity_perm = c.temp + (n * (16 + 2));
	c.delta_perm = c.identity_perm + n;

	if(artin == NULL || c.permutation == NULL) {
		free(artin);
		free(c.permutation);
		return NULL;
	}

	/* convert sdk braid list to internal format */
	for(i=0; i<len; i++) {
		artin[i] = braid->b[i].l - 1;

		if(braid->b[i].u == -1) {
			artin[i] |= SIGN_BIT;
		}
	}

	bkl(&c, artin, len, u, n, backchance, forwardchance, startindex);

	/* prepend band list with delta */
	ret = bandAllocateBandList (1);
	ret->bwl[0].d = c.delta;

	/* to return band list, convert output bkl
	 * permutations -> cycles -> bands
	 */
	perm = bandAllocatePermutation(n);
	for(i=0; i<c.count; i++) {
		ae_pListOfIntLists_t cycle;
		ae_pBandList_t band;
		unsigned int j;

		uint8_t *p = c.permutation;
		p += n * i;

		for(j=0; j<n; j++) {
			perm->items[j] = p[j] + 1;
		}

		cycle = bandToCycles(perm);
		band = bandCyclesToCanonicalFactor(cycle);
		bandAppendToBandList (ret, band);

		bandFreeBandList(band);
		bandFreeCycles(cycle, 1);
	}

	free(c.permutation);
	free(artin);
	bandFreePermutation(perm);

	return ret;
}

ae_pBandList_t
bandFastBKLNormalFormWithCarry(ae_plist_t braid, unsigned int n, unsigned int len, int u)
{
	return bklwrap(braid, n, len, u, 100, 100, 0);
}

ae_pBandList_t
bandFastBKLNormalForm(ae_plist_t braid, int n)
{
  return bandFastBKLNormalFormWithCarry(braid, n, braid->len, 0);
}
