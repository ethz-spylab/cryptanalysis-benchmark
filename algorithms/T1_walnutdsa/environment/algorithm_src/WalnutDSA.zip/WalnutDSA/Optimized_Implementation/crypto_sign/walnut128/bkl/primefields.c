/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#include "primefields.h"
#include <stdio.h>

/* This assumes a >= 0, b > 1 */
static inline ffelem mul_inv(long a, long b)
{
	ffelem b0 = b;
	long t, q;
	long x0 = 0, x1 = 1;
	while (a > 1) {
		q = a / b;
		t = b, b = a % b, a = t;
		t = x0, x0 = x1 - q * x0, x1 = t;
	}
	return (ffelem) ((x1 + b0) % b0);
}

static ffelem pf_neg(const struct SrfFiniteField_* ff, ffelem a)
{
  return a ? ff->primepower - a : 0;
}

static ffelem pf_inverse(const struct SrfFiniteField_* ff, ffelem a)
{
  return a ? mul_inv(a, ff->primepower) : 0;
}
static ffelem pf_neginverse(const struct SrfFiniteField_* ff, ffelem a)
{
  return a ? ff->primepower - mul_inv(a, ff->primepower) : 0;
}
static ffelem pf_add(const struct SrfFiniteField_* ff, ffelem a, ffelem b)
{
  unsigned long long x = (unsigned long long) a + b;
  return (ffelem) (x % ff->primepower);
}
static ffelem pf_mult(const struct SrfFiniteField_* ff, ffelem a, ffelem b)
{
  unsigned long long x = (unsigned long long) a * b;
  return (ffelem) (x % ff->primepower);
}
static ffelem pf_reduce(const struct SrfFiniteField_* ff, ffelem a)
{
  return a % ff->primepower;
}

#define DEFINE_FF(num) \
  { num, pf_neg, pf_inverse, pf_neginverse, pf_add, pf_mult, pf_reduce }

static SrfFiniteField ffFields[] = {
#ifdef ENABLE_FIELD_127
  DEFINE_FF(127),
#endif
#ifdef ENABLE_FIELD_2147483647
  DEFINE_FF(2147483647),
#endif
};
#define NUM_FIELDS (sizeof(ffFields)/sizeof(*ffFields))

extern const SrfFiniteField* ffGetPrimeField(ffelem primepower)
{
  int i;
  for (i = 0; i < NUM_FIELDS; i++) {
    if (ffFields[i].primepower == primepower)
      return &ffFields[i];
  }
  return NULL;
}
