/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#include "ae_dsa.h"
#include "braids.h"
#include "api.h"
#include "ae_crypto.h"
#include "hash.h"
#include "crypto_sign.h"
#include <stdio.h>

int crypto_sign_keypair(
	unsigned char *pk,
	unsigned char *sk
)
{
	AeDSAPubKey pub;
	AeDSAPrivKey priv2;
	int status = 0;

	status = ae_dsa_random_keypair(WALNUT_BRAID, WALNUT_FIELD, WALNUT_SL, &pub, &priv2);
	if (status < 0)
		goto done;

	status = ae_dsa_save_private_key(priv2, sk);
	if (status < 0)
		goto done;

#ifdef KAT_INTERMEDIATES
	printplist(priv2->privatebraid_S, "Unpacked private braid 1");
	printplist(priv2->privatebraid_Sprime, "Unpacked private braid 2");
	int sig_length = ((((sk[0] << 8) | sk[1]) + 1)/2) + 2;
	printBraid(sk, "Packed private braid 1");
	printBraid(sk+sig_length, "Packed private braid 2");
#endif

	status = ae_dsa_save_public_key(pub, pk);
	if (status < 0)
		goto done;

#ifdef KAT_INTERMEDIATES
    unpack_and_print_matrix(pk, "Unpacked public key");
	printBuffer(pk, CRYPTO_PUBLICKEYBYTES, "Packed public key");
#endif

done:
	ae_dsa_keys_free(pub ? &pub : NULL, priv2 ? &priv2 : NULL);

	return status;
}


int crypto_sign(
	unsigned char *sm, unsigned long long *smlen,
	const unsigned char *m, unsigned long long mlen,
	const unsigned char *sk
)
{
	unsigned char *tempBuf = NULL;
	AeDSASig sig = NULL;
	AeDSAPrivKey priv = NULL;
	size_t packed_braid_size;
	int ret = 0;

	unsigned char *digest = NULL;

	hash_message(m, mlen, &digest);

#ifdef KAT_INTERMEDIATES
	printBuffer(digest, WALNUT_DGST_SIZ, "Hash in crypto_sign");
#endif

	ret = ae_dsa_load_private_key(&priv, sk);
	if (ret < 0)
		goto done;

	ret = ae_dsa_sign(priv, digest, WALNUT_DGST_SIZ, &sig);
	if (ret < 0)
		goto done;

	ret = ae_pack_braid(sig->signature, WALNUT_BRAID, &tempBuf, &packed_braid_size);
	if (ret < 0)
		goto done;

	memcpy(sm, tempBuf, packed_braid_size);
	memcpy(sm + packed_braid_size, m, mlen);

	*smlen = packed_braid_size + mlen;

done:
	free(digest);
	if(tempBuf)
		free(tempBuf);
	if(priv)
		ae_dsa_keys_free(NULL, &priv);
	if(sig)
		ae_dsa_sign_free(&sig);

	return ret;
}

int crypto_sign_open(
	unsigned char *m, unsigned long long *mlen,
	const unsigned char *sm, unsigned long long smlen,
	const unsigned char *pk
)
{
	int sig_length, message_length, ret = 0;
	unsigned char *digest = NULL;
	unsigned char *message = NULL;
	walnut_verify_ctx walnut;

	//This is the signature length in generators, so divide it by 2 to find the actual packed bytes
	sig_length = (((sm[0] << 8) | sm[1]) + 1)/2;

	//Check for corruption
	if(sig_length > CRYPTO_BYTES || sig_length < 0)
	{
		message = calloc(0, 1);
		*mlen = 0;
		return -1;
	}

	//smlen includes the 2 size bytes, so account for that by subtracting 2
	message_length = smlen - sig_length - 2;
	message = calloc(message_length, 1);
	memcpy(message, &sm[smlen - message_length], message_length);

	hash_message(message, message_length, &digest);

#ifdef KAT_INTERMEDIATES
	printBuffer(digest, WALNUT_DGST_SIZ, "Hash in crypto_sign_open");
#endif

	ret = walnut_verify_init(pk, digest, &walnut);
	if (ret < 0)
		goto done;

	//sig_length doesn't include the 2 bytes for length, so add those back in
	ret = walnut_verify_update(&walnut, sm, sig_length+2);
	if (ret < 0)
		goto done;

	ret = walnut_verify_final(&walnut);
	if (ret < 0)
		goto done;

	memcpy(m, message, message_length);
	*mlen = message_length;

done:
	free(message);
	free(digest);

	return ret;
}
