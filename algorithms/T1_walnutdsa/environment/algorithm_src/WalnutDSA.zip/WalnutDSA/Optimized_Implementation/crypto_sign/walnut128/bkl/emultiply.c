/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * emultiply.c - emultiplication
 */

#include "aelib.h"

/*+
 * ae_eMultiplyModP - perform emultiplication 
 *
 * usage: ae_eMultiplyModP (m1, m2, tvalues)
 *
 * args:
 *       m1 - first CB data
 *       m2 - second CB data
 *       tvalues - tvalues to use
 *
 * returns:
 *       pointer to product matrix or NULL if memory could not be allocated
 *
 * notes:
 *       m1 can be a general CB pair (matrix, perm), but m2 must be a primitive CB pair 
 *       corresponding to a generator of the braid group (or the inverse of one)
 *       we also should use this in the keyexchange code instead of reimplementing emultiplication there.
 * uses:
 *      braidAllocateCBData
 *-
 */
//#define EMULTMODPDBG
//#define PERMDBG
ae_pcbdata_t
ae_eMultiplyModP (ae_pcbdata_t m1, ae_pcbdata_t m2, ae_pTvalues_t tvalues) {
  ae_pcbdata_t result;
  unsigned int row,col;
  ae_cbvalue_t a,b,c;
  ae_cbvalue_t tt;
  /*
   * allocate an empty array to hold the result
   */
  result = braidAllocateCBData (m1->n);
  if (!result)
    return NULL;

  for (col=0; col < m2->n; col++) {
    if (col < m2->k -2 || col > m2->k) { /* in this range we just copy over the column of m1 */
      for (row=0; row<m1->n;row++) {
	result->m[row][col] = m1->m[row][col];
      }
    }
    /*
     * handle the permutations
     */
    result->p[col] = m1->p[(m2->p[col])-1];
  }

  if (m2->e == 1) {
    a =                         tvalues[m1->p[m2->k -1]-1];
    b = g_ffield->neg(g_ffield, tvalues[m1->p[m2->k -1]-1]);
    c = 1;
  }
  else {
    a=1;
    b=g_ffield->neginverse(g_ffield, tvalues[m1->p[m2->k]-1]);
    c=   g_ffield->inverse(g_ffield, tvalues[m1->p[m2->k]-1]);
  }

#ifdef EMULTMODPDBG
  fprintf(stdout,"(k,e) a b c: (%d,%d) %d %d %d\n",m2->k, m2->e,a,b,c);
#endif

  /* perform the matrix multiplication for the remaining columns */
  for(row = 0; row < m1->n; row++) {
    tt = g_ffield->mult(g_ffield, m1->m[row][m2->k -1],b);
    result->m[row][m2->k -1] = tt;

    tt = g_ffield->add(g_ffield, g_ffield->mult(g_ffield, m1->m[row][m2->k -1],c),m1->m[row][m2->k]);
    result->m[row][m2->k] = tt; 

    if (m2->k >1) {
      tt = g_ffield->add(g_ffield, m1->m[row][m2->k -2],g_ffield->mult(g_ffield, m1->m[row][m2->k -1],a));
      result->m[row][m2->k -2] = tt;
    }
  }

  return result;
}

/*+
 * ae_eMultiplicationIterator - perform emultiplication iterating over a list of CB matrices
 *
 * usage: ae_eMultiplicationIterator (cb, b, tvalues)
 *
 * args:
 *      cb - matrix to multiply
 *      b - list of matrices to iterate over
 *      tvalues - list of T-values to use
 *
 * returns:
 *      product matrix or NULL if memory could not be allocated
 *
 * notes:
 *
 * uses:
 *      braidAllocateCBData
 *      ae_eMultiplyModP
 *      braidFreeCBData
 *-
 */
ae_pcbdata_t
ae_eMultiplicationIterator (ae_pcbdata_t cb, ae_pcblist_t b, ae_pTvalues_t tvalues) {
  int len = b->len;
  int i,j;
  ae_pcbdata_t answer;
  ae_pcbdata_t temp;
  /*
   * make a working copy of the first matrix
   */
  answer = braidAllocateCBData (cb->n);
  if (!answer)
    return NULL;

  for (i=0; i < cb->n; i++) {
    for (j=0; j < cb->n; j++) {
      answer->m[i][j] = cb->m[i][j];
    }
    answer->p[i] = cb->p[i];
  }
  /*
   * emultiply, iterating over the cb values, accumulating the result
   */
  for (i=0; i < len; i++) {
    temp = ae_eMultiplyModP (answer, &(b->data[i]), tvalues);
    if (!temp)
      return NULL;
    braidFreeCBData (answer);
    answer = temp;
  }

  return answer;
}
