/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * aelib.h - public structures and prototypes
 */
#ifndef AELIB_H
#define AELIB_H 1

/*
 * system includes
 */
#include "ae_config.h"
#include "aetypes.h"
#include "aeutil.h"
#include "constants.h"

/*
 * ae specific includes
 */
#include "braids.h"
#include "bands.h"
#include "keygen.h"
#include "aekeys.h"
#include "emultiply.h"
#include "dehornoy.h"
#include "pack.h"
#include "finitefields.h"
#include "ae_dsa.h"

/*
 * Constants
 */

/*
 * data structures
 */
extern const SrfFiniteField* g_ffield;


/*
 * prototypes
 */
extern int aeLibInit(ffelem primepower);
extern int aeLibReInit(ffelem primepower);

#endif /* AELIB_H */
