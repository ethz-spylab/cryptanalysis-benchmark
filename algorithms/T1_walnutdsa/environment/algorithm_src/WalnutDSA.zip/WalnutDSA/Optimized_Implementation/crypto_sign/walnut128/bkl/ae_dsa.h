/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/


/*
 * ae_dsa.h -- Algebraic Eraser DSA general abstraction
 *
 * Copyright (C) 2015, SecureRF Corporation.  All Rights Reserved.
 *
 */

#ifndef AE_DSA_H
#define AE_DSA_H
#include "aelib.h"

/*
 * Constants
 */

/*
 * Structure definitions
 */

typedef struct _message_ {
  unsigned char m[WALNUT_DGST_SIZ];
} ae_message_t, *ae_pmessage_t;

typedef struct _aedsaparams_ {
  int n;
  ffelem q;
  int a;
  int b; 
  int L;
  int i;
  ae_pTvalues_t tvalues;
} AeDSAParamsData, *AeDSAParams;

typedef struct _aedsapubkey_ {
  int n;
  ffelem q;
  ae_pTvalues_t tvalues;
  ae_pPublicKey_t publickey_S;
  ae_pPublicKey_t publickey_Sprime;
} AeDSAPubKeyData, *AeDSAPubKey;
  
typedef struct _aedsaprivkey_ {
  AeDSAParamsData params;
  ae_plist_t privatebraid_S;
  ae_plist_t privatebraid_Sprime;
} AeDSAPrivKeyData, *AeDSAPrivKey;
  
typedef struct _aedsasig_ {
  ae_plist_t signature;
} AeDSASigData, *AeDSASig;

/*
 * Public API
 */


int ae_dsa_random_parameters(AeDSAParams params, int n, int q, int sl);
int ae_dsa_parameters_free(AeDSAParams *pParams);


int ae_dsa_load_private_key(AeDSAPrivKey* pPriv, const unsigned char *sk);
int ae_dsa_save_private_key(const AeDSAPrivKey priv, unsigned char *sk);
int ae_dsa_save_public_key(const AeDSAPubKey pub, unsigned char *pk);


/* Generate public and private keys from parameters */
int ae_dsa_keygen(const AeDSAParams, AeDSAPubKey* pub, AeDSAPrivKey* priv);

/* Generate RANDOM private and public keys */
int ae_dsa_random_keypair(int n, int q, int sl, AeDSAPubKey* pPub, AeDSAPrivKey* pPriv);

/* Free public and private keys constructed from parameters */
int ae_dsa_keys_free(AeDSAPubKey* pub, AeDSAPrivKey* priv);

/* Compute signature */
int ae_dsa_sign(const AeDSAPrivKey priv, const unsigned char* msg, size_t msglen, AeDSASig* sig);

/* Verify signature using the public key */
int ae_dsa_verify(const AeDSAPubKey pub, const unsigned char* msg, size_t msglen, AeDSASig sig);

/* Free signature data */
int ae_dsa_sign_free(AeDSASig *sig);

/*
 * Internal functions
 */

ae_plist_t	aedsaPrivateKeyGenerator			(int a, int b, int L, int n);
ae_plist_t	aedsaFourBitEncoder				(unsigned char c, int n);
ae_plist_t	aedsaFourBitMessageEncoder			(ae_pmessage_t M, int n);
ae_plist_t	aedsaVariableFourBitEncoder			(unsigned char c, int g[4], int n);
ae_plist_t	aedsaVariableFourBitMessageEncoder		(ae_pmessage_t M, int g[4], int n);
ae_plist_t	aedsaVariableFourBitMessageEncoderCloakers	(ae_pmessage_t M, int g[4], int n, int ii, int a, int b, int L, double threshold);
ae_plist_t	aedsaFourBitMessageEncoder1257			(ae_pmessage_t M, int n);
ae_plist_t	aedsaFourBitMessageEncoder1357			(ae_pmessage_t M, int n);
ae_plist_t	aedsaFourBitVariableEncoder			(unsigned char c, int n, int a, int b);
ae_plist_t	aedsaFourBitVariableMessageEncoder		(ae_pmessage_t M, int n, int a, int b);
ae_plist_t	aedsaMessageEncoder				(ae_pmessage_t M, int n);
ae_plist_t	aedsaMessageEncoderCloakers			(ae_pmessage_t M, int n, int ii, int a, int b, int L, double threshold);
ae_pcbdata_t    aedsaPublicKeyGenerator				(int n, ae_plist_t privatebraid, ae_pTvalues_t tvalues);
ae_plist_t      aedsaDigitalSignature				(ae_pmessage_t M, ae_plist_t privatebraid_S, ae_plist_t privatebraid_Sprime, int i, int a, int b, int L, int n);
int             aedsaVerifySignature				(ae_pmessage_t M, ae_plist_t signature, ae_pcbdata_t publickey_S, ae_pcbdata_t publickey_Sprime, ae_pTvalues_t tvalues, int n);

unsigned int    aedsaComputeLFromSL				(unsigned int secLevel, unsigned int n);



#endif /* AE_DSA_H */

