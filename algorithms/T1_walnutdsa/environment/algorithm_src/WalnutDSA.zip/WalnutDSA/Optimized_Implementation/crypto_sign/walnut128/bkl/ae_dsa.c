/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#include "aelib.h"
#include "ae_dsa.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h> /* for ceil */
#include "api.h"
#include <stdint.h>
#include "ae_crypto.h"
#include "obfuscate.h"

const uint8_t braiddata[16][41] = {
	{ 14,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x04, 0x01, 0x03, 0x01, 0x02, 0x01, 0x01, 0x01, 0x01, 0x01, 0x02, 0xFF, 0x03, 0xFF, 0x04, 0xFF, 0x05, 0xFF, 0x06, 0xFF, 0x07, 0xFF },
	{ 10,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x04, 0x01, 0x03, 0x01, 0x03, 0x01, 0x04, 0xFF, 0x05, 0xFF, 0x06, 0xFF, 0x07, 0xFF },
	{ 6,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x05, 0x01, 0x06, 0xFF, 0x07, 0xFF },
	{ 2,  0x07, 0x01, 0x07, 0x01 },
	{ 16, 0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x04, 0x01, 0x03, 0x01, 0x02, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x02, 0xFF, 0x03, 0xFF, 0x04, 0xFF, 0x05, 0xFF, 0x06, 0xFF, 0x07, 0xFF },
	{ 12,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x04, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x04, 0xFF, 0x05, 0xFF, 0x06, 0xFF, 0x07, 0xFF },
	{ 8,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x06, 0xFF, 0x07, 0xFF },
	{ 4,  0x07, 0x01, 0x07, 0x01, 0x07, 0x01, 0x07, 0x01 },
	{ 18,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x04, 0x01, 0x03, 0x01, 0x02, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x02, 0xFF, 0x03, 0xFF, 0x04, 0xFF, 0x05, 0xFF, 0x06, 0xFF, 0x07, 0xFF },
	{ 14,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x04, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x04, 0xFF, 0x05, 0xFF, 0x06, 0xFF, 0x07, 0xFF },
	{ 10,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x06, 0xFF, 0x07, 0xFF },
	{ 6,  0x07, 0x01, 0x07, 0x01, 0x07, 0x01, 0x07, 0x01, 0x07, 0x01, 0x07, 0x01 },
	{ 20,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x04, 0x01, 0x03, 0x01, 0x02, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x02, 0xFF, 0x03, 0xFF, 0x04, 0xFF, 0x05, 0xFF, 0x06, 0xFF, 0x07, 0xFF },
	{ 16,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x04, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x03, 0x01, 0x04, 0xFF, 0x05, 0xFF, 0x06, 0xFF, 0x07, 0xFF },
	{ 12,  0x07, 0x01, 0x06, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x05, 0x01, 0x06, 0xFF, 0x07, 0xFF },
	{ 8,  0x07, 0x01, 0x07, 0x01, 0x07, 0x01, 0x07, 0x01, 0x07, 0x01, 0x07, 0x01, 0x07, 0x01, 0x07, 0x01 },
};
/*+
 * aedsaComputeLFromSL - Compute the 'L' parameter based on the Security Level
 *
 * usage: aedsaComputeLFromSL(sl)
 *
 * args:
 *      sl - The desired Security Level (2^sl)
 *
 * returns: the required L parameter based on the security level
 *
 * notes:
 *
 * Compute L from the desired security level:
 *  2^sl = ((n-1)(n-2))^(2L)
 *    sl = ln2(((((n-1)(n-2))^(2L))
 *       = ln2((n-1)(n-2))*2L
 *     L = sl / (2 * ln2((n-1)(n-2)))
 *
 * uses:
 *-
 */
unsigned int
aedsaComputeLFromSL(unsigned int sl, unsigned int n)
{
  unsigned int L = ceil((double)sl / (2.0 * logtwo((double)(n-1)*(n-2))));

  /* For now, let's make L a *bit* longer for safety... -derek, 2015-11-08 */
  L *= 1.25;

  return L;
}

/*+
 * compareToIdentityPermutation - Compares a given permutation to the identity permutation
 *
 * usage: compareToIdentityPermutation(p1, n)
 *
 * args:
 *      p1 - The permutation to compare to the identity
 *      n - number of strangs of braid group / size of permutation
 *
 * returns: 1 if permutation equals idenity, otherwise 0
 *
 * notes:
 *
 * uses:
 *
 *
 *-
 */
static int compareToIdentityPermutation(ae_pPermutation_t p1, size_t n)
{
	  unsigned int i;
    unsigned int identity[n];

    for(i=1; i<=n; i++) {
        identity[i-1] = i;
    }

    return !memcmp(p1->items, identity, n * sizeof(unsigned int));
}

/*+
 * aedsaPrivateKeyGenerator - generates a private key for the signer in the AEDSA
 *
 * usage: aedsaPrivateKeyGenerator(a, b, L, n)
 *
 * args:
 *      a - first distinguished element for our permutations
 *      b - second distinguished element for our permutations
 *      L - length of random braid to use
 *      n - number of strands of braid group / size of permutations
 *
 * returns: a braid to be used as a private key in the AEDSA
 *
 * notes:
 *
 * uses:
 *
 *
 *-
 */
//#define AEDSA_PK_DBG
ae_plist_t
aedsaPrivateKeyGenerator (int a, int b, int L, int n) {
  ae_plist_t w = NULL;
  ae_pPermutation_t perm = NULL;

	double SL = logtwo((double)(n - 1)*(n - 2)) * 2.0 * L;
	int len = keygenBraidLengthForSecurityLevel(SL, n);
#ifdef KAT_INTERMEDIATES
  printf("l: %d\n", len);
#endif
	
  do
  {
	  if(perm)
		  bandFreePermutation(perm);
 
    w = braidFreelyReduceRandomArtinWord(n, len);
    perm = keygenArtinWordToPermutation(w, n);
  } while (compareToIdentityPermutation(perm, n));

  if(perm)
		  bandFreePermutation(perm);

	return w;

}

/*+
 * aedsaFourBitEncoder - converts four bits (nybble) into a braid in a free subgroup of Bn
 *
 * usage: aedsaFourBitEncoder(c, n)
 * usage: aedsaVariableFourBitEncoder(c, g, n)
 *
 * args:
 *      c - an unsigned char.  we use the lowest four bits of c
 *      g - an array of generators to use (must be 1<=g<n
 *      n - number of strands of braid group
 *
 * returns: a braid in a free subgroup of Bn encoding this nybble
 *
 * notes:
 *     this is the "original" algorithm -- useful when encoding a hashed input
 *     the original algorithm is effectively the variable algorithm with
 *         input of {7,6,5,4} for the generators
 * uses:
 *
 *
 *-
 */
ae_plist_t
aedsaVariableFourBitEncoder (unsigned char c, int gen[4], int n) {
  unsigned char b[4];
  int k;
  unsigned char cc = c & 0x0F;
  ae_plist_t br[4];
  ae_plist_t answer = NULL, kpow = NULL;

  for (k=0; k<4; k++) {
    b[k] = cc & 0x01;
    cc >>= 1;
    if (gen[k] < 1 || gen[k] > (n-1))
      return NULL;
    br[k] = braidGenOfFreeSubgpOfPureBraidGroup(gen[k], n);
  }

  kpow = keygenKthPower( br[ b[0] + 2*b[1] ], 1 + b[2] + 2*b[3] );
  answer = braidFreelyReduce(kpow);

  for (k=0; k<4; k++) {
    braidFreeBraidlist( &br[k] );
  }
  braidFreeBraidlist( &kpow );

  return answer;
}

ae_plist_t
aedsaFourBitMessageEncoder1357(ae_pmessage_t M, int n)
{
	int g[4] = { 1,3,5,7 };
	return aedsaVariableFourBitMessageEncoder(M, g, n);
}

ae_plist_t
aedsaVariableFourBitMessageEncoder(ae_pmessage_t M, int g[4], int n) {
	ae_plist_t answer = NULL, ans1 = NULL;
	int i;

	for (i = 0; i<4; i++) {
		if (g[i] < 0 || g[i] >= n)
			return NULL;
	}

	ans1 = braidAllocateBraidlist(0);

	for (i = 0; i<WALNUT_DGST_SIZ; i++) {
		unsigned char ch, cl;
		ae_plist_t bh = NULL, bl = NULL;
		const uint8_t *b1, *b2;

		ch = (M->m[i] & 0xF0);
		cl = (M->m[i] & 0x0F);
		ch >>= 4;

		b1 = braiddata[ch] + 1;
		b2 = braiddata[cl] + 1;
		bh = braidAllocateBraidlist(braiddata[ch][0]);
		bl = braidAllocateBraidlist(braiddata[cl][0]);

		memcpy(bh->b, &braiddata[ch][1], braiddata[ch][0] * 2);
		memcpy(bl->b, &braiddata[cl][1], braiddata[cl][0] * 2);

		braidAppendBraidlistToBraidlist(ans1, bh);
		braidAppendBraidlistToBraidlist(ans1, bl);
		braidFreeBraidlist(&bh);
		braidFreeBraidlist(&bl);
	}
	answer = braidFreelyReduce(ans1);
	braidFreeBraidlist(&ans1);
	return answer;
}

/*+
 * aedsaPublicKeyGenerator - wrapper for keygenPublicKeyEvaluator
 *
 * usage: aedsaPublicKeyGenerator(n, privatebraid, tvalues)
 *
 * args:
 *      n - number of strands of braid group
 *      privatebraid - braid chosen by signer in protocol
 *      tvalues - the T-values
 *
 * returns: pointer to Colored Burau data (matrix, permutation)
 *
 * notes:
 *
 * uses:
 *      keygenPublicKeyEvaluator
 *      braidIdentityMatrix
 *      braidFreeIdentityMatrix
 *-
 */
ae_pcbdata_t    
aedsaPublicKeyGenerator (int n, ae_plist_t privatebraid, ae_pTvalues_t tvalues) {
  
  ae_pcbdata_t answer = NULL;
  ae_pcbdata_t idmatperm = braidIdentityMatrix(n);
  
  answer = keygenPublicKeyEvaluator(n, idmatperm, privatebraid, tvalues);

  braidFreeIdentityMatrix(idmatperm);

  return answer;
}


/*+
 * aedsaDigitalSignature - produce the signature for a message
 *
 * usage: aedsaDigitalSignature(M, privatebraid, i, a, b, L, n)
 *
 * args:
 *      M - the message to be signed
 *      privatebraid - braid chosen by signer in protocol
 *      i - secret integer chosen by signer (used in constructing cloaking elements)
 *      a, b, L, n - inputs to private key generator
 *
 * returns: braid that is the signature
 *
 * notes:
 *         no BKL/Dehornoy at the moment is performed on the answer
 * uses:
 *
 *-
 */
ae_plist_t      
aedsaDigitalSignature (ae_pmessage_t M, ae_plist_t privatebraid_S, ae_plist_t privatebraid_Sprime, int i, int a, int b, int L, int n) {
	ae_plist_t braidformM, v, v1, v2, answer, obfuscatedanswer;
  ae_plist_t ipb, p0, p1, p2, p3, p4;
  ae_plist_t vtwo = NULL, vstar = NULL, v1inv = NULL;
  ae_pPermutation_t sigma_privs;
  ae_pPermutation_t sigma_privsprime;

  braidformM = aedsaFourBitMessageEncoder1357(M, n);

  // permutations for the private braids
  sigma_privs = keygenArtinWordToPermutation(privatebraid_S, n);
  sigma_privsprime = keygenArtinWordToPermutation(privatebraid_Sprime, n);

  i = braidGetRandom(n-2)+2;

  // cloakers
  // identity
  v = keygenCloakingElement(i, a, b, L, n);

#ifdef KAT_INTERMEDIATES
  printplist(v, "Cloaking element v1");
#endif

  // the braid Sprime
  v1 = keygenLeftCloakingElement(sigma_privsprime, a, b, L);

#ifdef KAT_INTERMEDIATES
  printplist(v1, "Cloaking element v2");
#endif

  // the braid S
  v2 = keygenLeftCloakingElement(sigma_privs, a, b, L);

#ifdef KAT_INTERMEDIATES
  printplist(v2, "Cloaking element v3");
#endif

  // Put the signature together
    ipb = braidInverse(privatebraid_S);

    p0 = braidMultiplication(v2, ipb);
    p1 = braidMultiplication(p0, v);
    p2 = braidMultiplication(p1, braidformM);
    p3 = braidMultiplication(p2, privatebraid_Sprime);
    p4 = braidMultiplication(p3, v1);
    answer = braidFreelyReduce(p4);

#ifdef KAT_INTERMEDIATES
  printplist(answer, "Signature w/free reduction pre-rewriting");
#endif

	  obfuscatedanswer = obfuscateBraid(answer);

    // cleanup
    braidFreeBraidlist(&answer);
    braidFreeBraidlist(&p4);
    braidFreeBraidlist(&p3);
    braidFreeBraidlist(&p2);
    braidFreeBraidlist(&p1);
    braidFreeBraidlist(&p0);
    if (ipb) braidFreeBraidlist(&ipb);
    if (vtwo) braidFreeBraidlist(&v2);
    if (vstar) braidFreeBraidlist(&vstar);
    if (v1inv) braidFreeBraidlist(&v1inv);
    braidFreeBraidlist(&v2);
    braidFreeBraidlist(&v1);
    braidFreeBraidlist(&v);  
    braidFreeBraidlist(&braidformM);
    bandFreePermutation(sigma_privs);
    bandFreePermutation(sigma_privsprime);

    return obfuscatedanswer;
}

/*
 * Create a random set of parameters, using the desired:
 * n  -- braid index
 * q  -- field
 * sl -- desired signature security level (to compute L and i)
 *
 * This will generate a random Tvalue array and choose random a and b
 * parameters within the array.
 */
int
ae_dsa_random_parameters(AeDSAParams params, int n, int q, int sl)
{
  int err = 0;
#if 0
  int p;
  ae_pPermutation_t perm;
#endif

  params->n = n;
  params->q = q;

  params->tvalues = braidAllocateRandomTvalues(params->n, params->q);
  if (!params->tvalues)
  {
    err = -1;
    goto err;
  }

  params->a = 0;
  params->b = 1;
  
  params->i = 0;

  /* Reset tvalues[a] and tvalues[b] to 1 */
  params->tvalues[params->a] = 1;
  params->tvalues[params->b] = 1;

  /* a and b need to be 1-indexed, not 0-indexed */
  params->a++;
  params->b++;

  params->L = aedsaComputeLFromSL(sl, n);

#ifdef KAT_INTERMEDIATES
  printf("n: %d\nq: %d\nL: %d\n", params->n, params->q, params->L);
  int i;
  printf("T-values:\n");
  for(i=0;i<8;i++)
  {
    printf("%02x, ", params->tvalues[i]);
  }
  printf("\n");
#endif

  return 0;

 err:
  ae_dsa_parameters_free(&params);

  return err;
}

int
ae_dsa_parameters_free(AeDSAParams *pParams)
{
  if (!pParams)
    return -1;
  ae_free((*pParams)->tvalues);
  ae_free(*pParams);
  *pParams = NULL;
  return 0;
}

static int
do_ae_dsa_keygen(AeDSAPubKey* pPub, AeDSAPrivKey priv)
{
  int i;
  AeDSAPubKey pub;
  ae_pPermutation_t perm = NULL, permprime = NULL;

  pub = ae_calloc(1, sizeof(AeDSAPubKeyData));

  // copy the public parameter data
  pub->n = priv->params.n;
  pub->q = priv->params.q;
  pub->tvalues = braidAllocateTvalues(priv->params.n);
  for (i=0; i<priv->params.n; i++) {
    pub->tvalues[i] = priv->params.tvalues[i];
  }

  priv->privatebraid_S = aedsaPrivateKeyGenerator (priv->params.a, priv->params.b, priv->params.L, priv->params.n);
  perm = keygenArtinWordToPermutation(priv->privatebraid_S, WALNUT_BRAID);

  do
  {
    if(permprime)
      bandFreePermutation(permprime);

    priv->privatebraid_Sprime = aedsaPrivateKeyGenerator (priv->params.a, priv->params.b, priv->params.L, priv->params.n);
    permprime = keygenArtinWordToPermutation(priv->privatebraid_Sprime, priv->params.n);
  } while (!memcmp(perm->items, permprime->items, priv->params.n * sizeof(unsigned int)));

  if(perm)
	  bandFreePermutation(perm);
  if(permprime)
  		bandFreePermutation(permprime);

  // make public keys
  pub->publickey_S = ae_calloc(1,sizeof( ae_publicKey_t));
  if (!pub->publickey_S)
    return -1;
  pub->publickey_Sprime = ae_calloc(1,sizeof( ae_publicKey_t));
  if (!pub->publickey_Sprime)
    return -1;

  aeLibReInit(priv->params.q);

  pub->publickey_S->pk = aedsaPublicKeyGenerator(pub->n, priv->privatebraid_S, pub->tvalues);
  pub->publickey_Sprime->pk = aedsaPublicKeyGenerator(pub->n, priv->privatebraid_Sprime, pub->tvalues);

 // return the public key
 *pPub = pub;
 return 0;
}

int
ae_dsa_random_keypair(int n, int q, int sl, AeDSAPubKey* pPub, AeDSAPrivKey* pPriv)
{
  int ret;
  AeDSAPrivKey priv;

  priv = ae_calloc(1, sizeof(AeDSAPrivKeyData));
  ret = ae_dsa_random_parameters(&(priv->params), n, q, sl);
  if (0 == ret)
    ret = do_ae_dsa_keygen(pPub, priv);

  if (0 == ret)
    *pPriv = priv;

  return ret;
}

int 
ae_dsa_keys_free(AeDSAPubKey* pub, AeDSAPrivKey* priv)
{
  if (pub) {
    if (*pub) {
      if((*pub)->publickey_S) {
	braidFreeCBData((*pub)->publickey_S->pk);
      }
      if((*pub)->publickey_Sprime) {
	braidFreeCBData((*pub)->publickey_Sprime->pk);
      }
      if((*pub)->tvalues) {
	braidFreeTvalues((*pub)->tvalues);
      }
      ae_free((*pub)->publickey_S);
      ae_free((*pub)->publickey_Sprime);
      ae_free(*pub);
      *pub = NULL;
    }
  }

  if (priv) {
    if (*priv) {
      if ((*priv)->params.tvalues) {
	braidFreeTvalues((*priv)->params.tvalues);
      }
      if((*priv)->privatebraid_S) {
	braidFreeBraidlist( &((*priv)->privatebraid_S) );
      }
      if((*priv)->privatebraid_Sprime) {
	braidFreeBraidlist( &((*priv)->privatebraid_Sprime) );
      }
      ae_free(*priv);
      *priv = NULL;
    }
  }
  return 0;
}

//#define API_SIGN_DBG
int
ae_dsa_sign(const AeDSAPrivKey priv, const unsigned char* msg, size_t msglen, AeDSASig* sig)
{
  ae_message_t M;
  ae_plist_t computedsig;
  AeDSASig tmpsig;
  int i;

  if (msglen != WALNUT_DGST_SIZ) {
    return -1;
  }

  for (i = 0; i<WALNUT_DGST_SIZ; i++) {
    M.m[i] = msg[i];
  }

  computedsig = aedsaDigitalSignature 
    (&M, priv->privatebraid_S, priv->privatebraid_Sprime, priv->params.i, priv->params.a, priv->params.b, priv->params.L, priv->params.n);

  tmpsig = ae_calloc(1,sizeof(AeDSASigData));
  if (!tmpsig)
    return -1;
  tmpsig->signature = computedsig;  
  
  *sig = tmpsig;

  return 0;

}

int 
ae_dsa_sign_free(AeDSASig *sig)
{
  if (sig) {
    if (*sig) {
      braidFreeBraidlist( &((*sig)->signature) );
      ae_free(*sig);
      *sig = NULL;
    }
  }
  return 0;
}

int
ae_dsa_load_private_key(AeDSAPrivKey* pPriv, const unsigned char *sk)
{
	AeDSAPrivKey priv = ae_calloc(1, sizeof(AeDSAPrivKeyData) + 1);
	unsigned char *lsk = sk;
  unsigned char *pbraid2 = NULL;
	ae_plist_t bl, bl2 = NULL;
	size_t size1, size2, i;
	int ret = 0;

	priv->params.n = WALNUT_BRAID;
	priv->params.q = WALNUT_FIELD;
	priv->params.a = 1;
	priv->params.b = 2;
	priv->params.L = CONSTANT_L;
	priv->params.i = 0;

	priv->params.tvalues = braidAllocateTvalues(priv->params.n);

	size1 = (*lsk << 8) | (*(lsk+1));
  size1 = ((size1 + 1)/2) + 2;

	ret = ae_unpack_braid(lsk, size1, WALNUT_BRAID, &bl);

	priv->privatebraid_S = bl;

  pbraid2 = lsk+size1;

  size2 = (*pbraid2 << 8) | (*(pbraid2+1));
  size2 = ((size2 + 1)/2) + 2;

	ret = ae_unpack_braid(pbraid2, size2, WALNUT_BRAID, &bl2);

	priv->privatebraid_Sprime = bl2;

	if (priv->privatebraid_S && priv->privatebraid_Sprime)
	{
		*pPriv = priv;
		return ret;
	}

  ae_free(priv);
  return -1;
}

int
ae_dsa_save_private_key(const AeDSAPrivKey priv, unsigned char *sk)
{
	size_t size1, size2, i;
	unsigned char *tmpBuf = NULL;
	unsigned char *lsk = sk;
	int ret = 0;

  ret = ae_pack_braid(priv->privatebraid_S, WALNUT_BRAID, &tmpBuf, &size1);

	memcpy(lsk, tmpBuf, size1);

  free(tmpBuf);

  ret = ae_pack_braid(priv->privatebraid_Sprime, WALNUT_BRAID, &tmpBuf, &size2);

  memcpy(lsk + size1, tmpBuf, size2);

	free(tmpBuf);

  return ret;
}

int
ae_dsa_save_public_key(const AeDSAPubKey pub, unsigned char *pk)
{
	int i, j, n;
	ae_pcbdata_t cbdata = pub->publickey_S->pk;
  ae_pcbdata_t cbdataPrime = pub->publickey_Sprime->pk;

	n = cbdata->n;
	memset(pk, 0, CRYPTO_PUBLICKEYBYTES);

	pk[0] = WALNUT_BRAID;
  pk[1] = WALNUT_FIELD == 32 ? 0 : 0x01;
	pk[2] = WALNUT_FIELD == 32 ? 32 : 0;

	AePackCtx pack;
	int count = 3;
	ae_pack_init(&pack, &pk[count], WALNUT_BRAID, WALNUT_FIELD_BIT);

	for (i = 0; i < n; i++)
	{
		ae_pack_entry(&pack, (unsigned char)pub->tvalues[i]);
	}

	count += PACKED_TVALUES_LENGTH;
	ae_pack_init(&pack, &pk[count], MATRIX_SIZE-n+1, WALNUT_FIELD_BIT);

  //Skip packing of the last row
	for (i = 0; i<n-1; i++) {
		for (j = 0; j<n; j++) {
			ae_pack_entry(&pack, (unsigned char) cbdata->m[i][j]);
		}        
	}

  ae_pack_entry(&pack, (unsigned char) cbdata->m[n-1][n-1]);

	count += PACKED_MATRIX_LENGTH;

	ae_pack_init(&pack, &pk[count], PACKED_PERMUTATION_LENGTH, PERMUTATION_BIT_PACK);

	for (i = 0; i < n; i++)
	{
		ae_pack_entry(&pack, (unsigned char)(cbdata->p[i] - 1));
	}

	count += PACKED_PERMUTATION_LENGTH;

  ae_pack_init(&pack, &pk[count], MATRIX_SIZE-n+1, WALNUT_FIELD_BIT);

  //Skip packing of the last row
	for (i = 0; i<n-1; i++) {
		for (j = 0; j<n; j++) {
			ae_pack_entry(&pack, (unsigned char) cbdataPrime->m[i][j]);
		}        
	}

  ae_pack_entry(&pack, (unsigned char) cbdataPrime->m[n-1][n-1]);

	count += PACKED_MATRIX_LENGTH;



  return 0;
}

