/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * keygen.c - low level core key generation routines
 */

/*
 * Includes
 */
#include "aeutil.h"
#include "aelib.h"


#include <math.h>
/*
 * Macros/Defines
 */
//#define ALICE_SHOW_PUBLIC_CONJUGATE
//#define BOB_SHOW_PUBLIC_CONJUGATE
//#define NO_BKL_REWRITE

/*
 * Static Data
 */
/* landau function: landau[n] is the 
   maximum order of a permutation in the symmetric group S_n */
static int           landau[] = {1, 1, 2, 3, 4, 6, 6, 12, 15, 20, 30,
				 30, 60, 60, 84, 105, 140, 210, 210,
				 420, 420, 420, 420, 840, 840, 1260, 1260,
				 1540, 2310, 2520, 4620, 4620, 5460, 5460};
int           max_symmetric_group = sizeof(landau)/sizeof(landau[0]);

/*
 * Prototypes
 */
long int lrint (double x);
double fmax (double x, double y);
/*+
 * logtwo - compute log to base 2 of a number
 *
 * usage:
 *       logtwo(x)
 *
 * args:
 *       x - a double
 *
 * returns:
 *       a double y such that 2^y = x
 *
 * uses:
 *       log from math.h, the constant M_LN2 from math.h, which is log(2)
 *-
 */
double
logtwo(double x) 
{
  return log(x)/M_LN2;
}

ae_plist_t
keygenLeftCloakingElement(ae_pPermutation_t perm, unsigned int a, unsigned int b, int L)
{
	ae_plist_t result = NULL;
	int i;
	int n;

	if (!perm || !a || !b || !L)
		return NULL;
	n = perm->n;

	/* Choose a random i for this word */
	i = braidGetRandom(n - 2) + 2;

	if (a > b) {
		int tmp = a;
		a = b;
		b = tmp;
	}

#ifdef DBG_MLCE
	bandPrintPermutation(stderr, perm, "Cloaking for permutation");
	fprintf(stderr, "mu=%d, nu=%d, ", a, b);
#endif
	a = bandIntListIndexOf(perm, a) + 1;
	b = bandIntListIndexOf(perm, b) + 1;
#ifdef DBG_MLCE
	fprintf(stderr, "pre-mu=%d, pre-nu=%d\n", a, b);
#endif

	/* Generate the cloaking element */
	result = keygenCloakingElement(i, a, b, L, n);

	return result;
}


/*+
 * gcd - find greatest common denominator for two numbers
 *
 * usage:
 *        gcd (a, b)
 *
 * args:
 *       a - first
 *       b - second
 *
 * returns:
 *       greatest common denominator
 *
 * notes:
 *
 * uses:
 *
 *-
 */
static unsigned int
gcd (unsigned int a, unsigned int b) {
    int r;

    r = a % b;
    while (r) {
	a = b;
	b = r;
	r = a % b;
    }
    return b;
}

/*+
 *
 * lcm - least common multiple
 *
 * usage:
 *        lcm (a,b)
 *
 * args:
 *        a - first number
 *        b - second number
 *
 * returns:
 *        least common multiple of two numbers
 *
 * notes:
 *
 * uses:
 *       gcd
 *-
 */
static unsigned int
lcm (unsigned int a, unsigned int b) {

    return a * b / gcd(a,b);
}

//#define FACT_DBG
#define TWO_PI 2*M_PI
#define E 2.7182818284590451


/*+
 *
 * keygenTwoCycle - produces the two cycle {i, i + 1}
 *
 * usage:
 *       keygenTwoCycle (i, n)
 *
 * args:
 *       i - starting value
 *       n - max subscript value
 *
 * returns:
 *       permutation for two cycle
 *
 * notes:
 *
 * uses:
 *       bandAllocatePermutation
 *
 *-
 */
ae_pPermutation_t
keygenTwoCycle (unsigned int i, unsigned int n) {
    unsigned int j;
    ae_pPermutation_t p;

    p = bandAllocatePermutation (n);

    for (j=0; j < n; j++) {
	if (j+1 == i) {
	    p->items[j] = i+1;
	} else if (j+1 == i+1) {
	    p->items[j] = i;
	} else {
	    p->items[j] = j+1;
	}
    }
    return p;
}

/*+
 *
 * keygenArtinWordToPermutation - yields the permutation in S_n associated with the Artin word.
 *
 * usage:
 *        keygenArtinWordToPermutation (braidlist, n)
 *
 * args:
 *        braidlist - Artin word
 *        n - max value of subscripts
 *
 * returns:
 *        permutation in S_n for braidlist
 *
 * notes:
 *
 * uses:
 *      keygenTwoCycle
 *      bandMultiplyPermutations
 *      bandFreePermutation
 *
 *-
 */
#define AW_TO_PERM_DBG
ae_pPermutation_t
keygenArtinWordToPermutation (ae_plist_t braidlist, unsigned int n) {
    ae_pPermutation_t answer, t1, t2;
    unsigned int j;

    answer = keygenTwoCycle (braidlist->b[0].l,n);
    for (j=1; j < braidlist->len; j++) {
	t1 = keygenTwoCycle (braidlist->b[j].l,n);
	t2 = bandMultiplyPermutations (answer, t1);
	bandFreePermutation (t1);
	bandFreePermutation (answer);
	answer = t2;
    }
    return answer;
}


/*+
 *
 * keygenKthPower - produces the K^th Power of v
 *
 * usage: keygenKthPower (bl, k)
 *
 * args:
 *         bl - braidlist to raise to kth power
 *         k - power
 *
 * returns:
 *         braidlist or NULL if allocation error
 *
 * notes:
 *   
 * uses:
 *       braidAllocateBraidlist
 *       braidCopyBraidlist
 *       braidAppendBraidlistToBraidlist
 *       braidInverse
 *-
 */
ae_plist_t
keygenKthPower (ae_plist_t bl, int k) {
    ae_plist_t answer, zinv;
    int i;
    /*
     * if k is 0, then we're done
     */
    if (k == 0) {
	return braidAllocateBraidlist (0);
    }
    /*
     * copy in the list
     */
    if (k > 0) {
	answer = braidCopyBraidlist (bl);
	for (i=0; i < k-1; i++) {
	    braidAppendBraidlistToBraidlist (answer, bl);
	}
    } else {
	zinv = braidInverse (bl);
	answer = braidCopyBraidlist (zinv);
	for (i=0; i < -k-1; i++) {
	    braidAppendBraidlistToBraidlist (answer, zinv);
	}
	braidFreeBraidlist( &zinv );
    }
    return answer;
}

/*+
 *
 * keygenKthPowerEx - produces the K^th Power of v
 *
 * usage: keygenKthPowerEx (bl, k)
 *
 * args:
 *       bl - pointer to band list to raise to kth power
 *       k - power
 *
 * returns:
 *       pointer to resultant bandlist or NULL if allocation fails
 *
 * notes:
 *
 * uses:
 *       bandAllocateBandList
 *       bandCloneBandList
 *       bandAppendToBandList
 *       bandInverseOf
 *-
 */

ae_pBandList_t
keygenKthPowerEx (ae_pBandList_t bl, int k) {
    ae_pBandList_t answer, zinv;
    int i;
    /*
     * if k is 0, then we're done
     */
    if (k == 0) {
	return bandAllocateBandList (0);
    }
    /*
     * copy in the list
     */
    if (k > 0) {
	answer = bandCloneBandList (bl);
	for (i=0; i < k-1; i++) {
	    bandAppendBandListToBandList (answer, bl);
	}
    } else {
	zinv = bandInverseOf (bl);
	answer = bandCloneBandList (zinv);
	for (i=0; i < -k-1; i++) {
	    bandAppendBandListToBandList (answer, zinv);
	}
	bandFreeBandList(zinv);
    }
    return answer;
}

/*+
 *
 * keygenBKLNormalFormToArtinWord - turns the BKLNormalForm BKL into a word in the Artin Generators
 *
 * usage:      keygenBKLNormalFormToArtinWord (bl, n)
 *
 * args:
 *         bl - BKL list to convert to Artin Word
 *         n  - order of the BKL list
 *
 * returns:
 *
 * notes:
 *
 * uses:
 *
 *-
 */
//#define BKLNORMALFORMTOARTINWORD_DBG
ae_plist_t
keygenBKLNormalFormToArtinWord (ae_pBandList_t bkl, unsigned int n) {
    ae_pBandList_t bw;
    ae_pBandList_t bkl1;      /* factor list minus first factor, which is delta */
    ae_pBandList_t d;         /* delta[n] */
    ae_pBandList_t kd;        /* kth power of delta */
    ae_plist_t abl;           /* bkl1 in artin form */
    ae_plist_t powerOfDelta;  /* kthPower(delta(n)) */
    ae_plist_t temp;          /* combined bkl1 and powerOfDelta */
    ae_plist_t answer;        /* reduced combined bkl1 and powerOfDelta */
    int u;
    /*
     * extract delta power and remove from input
     */
    u = bkl->bwl[0].d;
#ifdef BKLNORMALFORMTOARTINWORD_DBG
    ae_fprintf(stderr, "bkl->bwl[0].d = %d, u = %d\n", bkl->bwl[0].d, u);
#endif    
    
    if (u) {
      /* follow old code logic */

      bkl1 = bandDrop (bkl, 0);
      /*
       * calculate kthpower of delta(n)
       */
      d = bandDelta(n);
      kd = keygenKthPowerEx (d, u);
      bandFreeBandList (d);
      powerOfDelta = bandWordToArtinWord (kd);
#ifdef BKLNORMALFORMTOARTINWORD_DBG
      braidPrintFlat(stderr, powerOfDelta);
#endif
      bandFreeBandList (kd);
      /*
       * calculate the initial answer, which gets combined with the kthpower
       */
      if (bkl1->bwl[0].bl) {
	bw = bandSetOfCanonicalFactorsToBandWord (bkl1);
	bandFreeBandList (bkl1);
      } else {
	/* XXX: Is this always true? */
	bw = bkl1;
      }
      abl = bandWordToArtinWord (bw);
      bandFreeBandList (bw);
      /*
       * now need to prepend kthpowerofdelta to the answer to form the final answer
       */
      temp = braidCopyBraidlist (powerOfDelta);
      braidAppendBraidlistToBraidlist (temp, abl);
      
      braidFreeBraidlist (&powerOfDelta);
      braidFreeBraidlist (&abl);
      /*
       * reduce the result
       */
      answer = braidFreelyReduce (temp);
      /*
       * Clean up
       */
      braidFreeBraidlist (&temp);
      /*
       * and return the answer
       */
      return answer;
    }
    else {
      fprintf(stderr, "zero power of delta encountered -- assuming empty\n");
      return braidAllocateBraidlist(0);
    }
}

/*+
 *
 * keygenTranspositionToRandomArtinWord - produces an Artin Word whose associated permutation is the transposition T.
 *
 * usage: keygenTranspositionToRandomArtinWord (list)
 *
 * args:
 *     list - the transposition T as a list of integers
 *
 * returns:
 *         pointer to artin word created
 *
 * notes:
 *
 * uses:
 *
 *-
 */
ae_plist_t
keygenTranspositionToRandomArtinWord (ae_pTranspositionData_t t) {
    int i,k;
    int max=1, min=1;
    ae_plist_t left, right;
    ae_plist_t answer;
    /*
     * find min and max of  T
     */
    max = min = t->l;
    if (t->r < min)
	min = t->r;
    if (t->r > max)
	max = t->r;
    if (t->l > max)
	max = t->l;
    /*
     * calculate left hand side
     */
    left = braidAllocateBraidlist (max-min);
    for (k=min,i=0; k < max; i++,k++) {
	left->b[i].l = k;
	left->b[i].u = 2 * braidGetRandomInRange (0,2)-1;
    }
    /*
     * calculate right hand side
     */
    right = braidAllocateBraidlist (max-min-1);
    for (k=2,i=0; i < max-min-1; i++,k++) {
	right->b[i].l = max-k;
	right->b[i].u = 2 * braidGetRandomInRange (0,2)-1;
    }
    /*
     * Now join left and right
     */
    answer = left;
    braidAppendBraidlistToBraidlist (answer,right);
    /*
     * clean up
     */
    braidFreeBraidlist (&right);

    return answer;
}

/*+
 *
 * keygenCycleToProductOfTranspositions - decomposes Cycle into a product of transpositions.
 *
 * usage: keygenCycleToProductOfTranspositions (cycle)
 *
 * args:
 *       cycle - the cycle list to use to generate the transpositions
 *
 * returns:
 *       list of transpositions
 *
 * notes:
 *      caller must free return value using braidFreeBraidlist
 *      transposition must have at least two elements or NULL is returned
 *
 * uses:
 *      bandAllocateTranspositions
 *      bandAllocateTransposition
 *-
 */
//#define CYCLE_PROD_TRANS_DBG
ae_pTranspositions_t
keygenCycleToProductOfTranspositions (ae_pCycle_t cycle) {
    int i;
    ae_pTranspositions_t answer;
    if (cycle->n < 2)
	return NULL;

    answer = bandAllocateTranspositions (cycle->n-1);
    for (i=1; i < cycle->n; i++) {
	answer->v[i-1] = bandAllocateTransposition(1);
	answer->v[i-1]->data[0].l = cycle->items[0];
	answer->v[i-1]->data[0].r = cycle->items[i];
    }
#ifdef CYCLE_PROD_TRANS_DBG
    bandPrintTranspositions(stderr, answer, "computed transpositions");
#endif
    return answer;
}

/*+
 *
 * keygenPermutationToProductOfTranspositions - decomposes the permutation P into a product of transpositions.
 *
 * usage: keygenPermutationToProductOfTranspositions(permutation)
 *
 * args:
 *      permutation - the permutation to convert
 *
 * returns:
 *      list of transpositins
 *
 * notes:
 *
 * uses:
 *      braidAllocateBraidlist
 *      bandToCycles
 *      braidAppendBraidlistToBraidlist
 *      braidFreeBraidlist
 *      bandFreeCycles
 *-
 */
//#define PERM_PROD_TRANS_DBG
ae_pTranspositions_t
keygenPermutationToProductOfTranspositions (ae_pPermutation_t p) {
    int i;
    ae_pCycles_t cycles;
    ae_pTranspositions_t pt;
    ae_pTranspositions_t answer;

    answer = bandAllocateTranspositions (0);

    cycles = bandToCycles (p);
#ifdef PERM_PROD_TRANS_DBG
    bandPrintCycles(stderr,cycles,"computed cycles");
#endif
    for (i=0; i < cycles->n; i++) {
	if (cycles->p[i]->n > 1) {
	    pt = keygenCycleToProductOfTranspositions(cycles->p[i]);
	    bandAppendTranspositionsToTranspositions (answer, pt);
	    bandFreeTranspositions (pt,0);
	}
    }
    bandFreeCycles (cycles,1);

    return answer;
}

/*+
 *
 * keygenPermutationToRandomBraidWord - produces a braid whose associated permutation is in P.
 *
 * usage: keygenPermutationToRandomBraidWord(permutation)
 *
 * args:
 *       p - permutation to use
 *
 * returns:
 *       pointer to generated braid list
 *
 * notes:
 *
 * uses:
 *      keygenPermutationToRandomBraidWord
 *      braidAllocateBraidlist
 *      keygenTranspositionToRandomArtinWord
 *      braidAppendBraidlistToBraidlist
 *      braidFreeBraidlist
 *-
 */
//#define PERM_RBW_DBG
ae_plist_t
keygenPermutationToRandomBraidWord (ae_pPermutation_t p) {
    ae_pTransposition_t t;
    ae_pTranspositions_t ts;
    ae_plist_t answer, temp;
    int i,j,k=0,l=0;

    ts = keygenPermutationToProductOfTranspositions (p);
#ifdef PERM_RBW_DBG
    bandPrintTranspositions(stderr,ts,"ts");
#endif
    /* need to flatten ts into t */
    for (i=0; i < ts->len; i++) {
	l += ts->v[i]->len;
    }
    t = bandAllocateTransposition (l);
    /*
     * flatten the product
     */
    k = 0;
    for (i=0; i < ts->len; i++) {
	for (j=0; j < ts->v[i]->len; j++) {
	    t->data[k++] = ts->v[i]->data[j];
	}
    }
    bandFreeTranspositions (ts,1);

    answer = braidAllocateBraidlist(0);

    for (i=0; i < t->len; i++) {
	temp = keygenTranspositionToRandomArtinWord (&t->data[i]);
	braidAppendBraidlistToBraidlist (answer, temp);
	braidFreeBraidlist (&temp);
    }
    bandFreeTransposition (t);

    return answer;
}

/*+
 *
 * keygenOrderOfPermutation - computes the order of the permutation  P.
 *
 * usage:
 *
 * args:
 *
 * returns:
 *
 * notes:
 *
 * uses:
 *      bandToCycles
 *      bandFreeCycles
 *-
 */
unsigned int
keygenOrderOfPermutation (ae_pPermutation_t p) {
    ae_pCycles_t cycles;
    int i;
    int l;

    cycles = bandToCycles (p);
    /*
     * find the least common multiplier
     */
    l = cycles->p[0]->n;
    for (i=1; i < cycles->n; i++) {
	l = lcm(l, cycles->p[i]->n);
    }
    bandFreeCycles (cycles,1);

    return l;
}


/*+
*
* keygenRandomPermutationOfMaxOrder -  produces a random  permutation in S_n of high order.
*
* usage:  keygenRandomPermutationOfMaxOrder (n)
*
* args:
*         n - max value for randomnesss
*
* returns:
*         pointer to permutation created
*
* notes:
*
* uses:
*
*-
*/
//#define PERM_MAX_ORDER_DBG
ae_pPermutation_t
keygenRandomPermutationOfMaxOrder(unsigned int n) {

	while (1) {
		int ord;
		ae_pPermutation_t answer = bandRandomPermutation(n);
		ord = keygenOrderOfPermutation(answer);
#ifdef PERM_MAX_ORDER_DBG
		bandPrintPermutation(stderr, answer, "trying perm of max order");
		ae_fprintf(stderr, "order is %d, max possible is %d\n", ord, landau[n]);
#endif
		if (ord == landau[n]) {
			return (answer);
		}
		bandFreeIntList(answer);
	}

}

/*+
 * permutationFixXtoY - given a permutation, fix X to Y
 *
 * usage: permutationFixXtoY(p, x, y)
 *
 * args:
 *       p - permutation to be adjusted
 *       x - permutation starting point
 *       y - permutation ending point (where x -> y)
 *
 * modifies:
 *       p -- the permutation is modified in-place
 *
 * returns:
 *       nothing
 *
 * remarks:
 *       the permutations, x, and y are all 1-referenced, not 0-referenced
 */
static void
permutationFixXtoY(ae_pPermutation_t p, int x, int y)
{
  if (p->items[x-1] != y) {
    int i;
    for (i=0; i < p->n; i++) {
      if (p->items[i] == y) {
	int t = p->items[x-1];
	p->items[i] = t;
	p->items[x-1] = y;
      }
    }
  }
}

/*+
 * keygenRandomPermutationTakingabToa1b1 - creates a permutation taking 
 *                                         a1->a and b1->b
 *
 * usage: keygenRandomPermutationTakingabToa1b1(a1, b1, a, b, n)
 * 
 * args:
 *       a1 - first distinguished index, preimage of a
 *       b1 - second distinguished index, preimage of b
 *       a  - image of a1
 *       b  - image of b1
 *       n  - we work in the symmetric group S_n
 *
 * returns:
 *       the desired permutation
 *
 * remarks:
 *       the permutations are 1-referenced, not 0-referenced
 */
//#define RAND_PERM_MOVING_A1B1_TO_AB_DBG
ae_pPermutation_t
keygenRandomPermutationMovinga1b1Toab(int a1, int b1, int a, int b, int n) {
  
  ae_pPermutation_t answer = keygenRandomPermutationOfMaxOrder(n);
#ifdef RAND_PERM_MOVING_A1B1_TO_AB_DBG
  bandPrintPermutation(stderr, answer, "starting perm of max order");
#endif
  permutationFixXtoY(answer, a1, a);

#ifdef RAND_PERM_MOVING_A1B1_TO_AB_DBG
  bandPrintPermutation(stderr, answer, "after checking a");
#endif
  permutationFixXtoY(answer, b1, b);
#ifdef RAND_PERM_MOVING_A1B1_TO_AB_DBG
  bandPrintPermutation(stderr, answer, "after checking b");
  bandPrintPermutation(stderr, answer, "perm moving a->a1 and b->b1");
#endif
    return answer;
}

/*+
 *
 * keygenPureBraidGen - displays the pure braid element in B_n associated to the pair, 
 *                      i,j where 1<= i < j <= n.   
 *
 * usage: keygenPureBraidGen (i, j, e)
 *
 * args:
 *         i,j - the pair associated with the braid element, B_n
 *         e   - the exponent associated with the braid element, B_n
 *
 * returns:
 *          braidlist with the pure braid element
 *
 * notes:
 *
 * uses:
 *        braidAllocateBraidlist
 *        braidFreeBraidlist
 *
 *-
 */
ae_plist_t
keygenPureBraidGen (int i, int j, int e) {
    ae_plist_t left, right, answer;
    int k;

    left = braidAllocateBraidlist (j-i-1);
    for (k=0; k < j-i-1; k++) {
	left->b[k].l = j-k-1;
	left->b[k].u = 1;
    }
    right = braidAllocateBraidlist (j-i-1);
    for (k=0; k < j-i-1; k++) {
	right->b[k].l = i+k+1;
	right->b[k].u = -1;
    }
    answer = braidAllocateBraidlist (left->len + right->len + 2);
    for (k=0; k < left->len; k++) {
	answer->b[k] = left->b[k];
    }
    answer->b[left->len].l = i;
    answer->b[left->len].u = e;
    answer->b[left->len+1].l = i;
    answer->b[left->len+1].u = e;
    for (k=0; k < right->len; k++) {
	answer->b[k+left->len+2] = right->b[k];
    }
    braidFreeBraidlist (&left);
    braidFreeBraidlist (&right);

    return answer;
}

/*+
 *
 * keygenRandomPureBraidGen - produces a random pure band generator in B_n
 *
 * usage: keygenRandomPureBraidGen (n)
 *
 * args:
 *       n - size of braid
 *
 * returns:
 *       braidlist in B_n
 *
 * notes:
 *
 * uses:
 *      braidGetRandom
 *      keygenPureBraidGen
 *-
 */
//#define RPBG_DBG 
ae_plist_t
keygenRandomPureBraidGen (int n) {
    int i, j, e;

    i = braidGetRandom (n-1) + 1;
    j = i + braidGetRandom (n-i) + 1;
    e = 2 * braidGetRandom (2) - 1;
#ifdef RPBG_DBG
    fprintf(stderr, "i, j, e: %d, %d, %d\n", i, j, e);
#endif
    return keygenPureBraidGen (i, j, e);
}

/*+
 *
 * keygenRandomPureBraidWord - produces a random word in the pure band generators of B_n
 *
 * usage: keygenRandomPureBraidWord (n, l)
 *
 * args:
 *       n - size of the braidword
 *       l - length of the braidword
 *
 * returns:
 *       pointer to braidword
 *
 * notes:
 *
 * uses:
 *       keygenRandomPureBraidWord
 *       braidAllocateBraidlist
 *       braidFreeBraidlist
 *       braidFreelyReduce
 *-
 */
//#define RPBW_DBG
ae_plist_t
keygenRandomPureBraidWord (int n, int l) {
    ae_plist_t base, temp, new;
    int i,j;

    base = keygenRandomPureBraidGen (n);
    for (i=0; i < l-1; i++) {
	temp = keygenRandomPureBraidGen (n);
	new = braidAllocateBraidlist (base->len+temp->len);
	for (j=0; j < base->len; j++) {
	    new->b[j] = base->b[j];
	}
	for (j=0; j < temp->len; j++) {
	    new->b[base->len+j] = temp->b[j];
	}
	braidFreeBraidlist (&base);
	braidFreeBraidlist (&temp);
	base = new;
    }
    temp = braidFreelyReduce (base);
    braidFreeBraidlist (&base);

    return temp;
}

/*+
 * keygenBraidWordBuilder - 
 *        creates a braid word in B_n whose associated permutation is the output of 
 *        keygenPermutationBuilder multiplied by some extra elementary pure braids.  
 *
 * usage:
 *        keygenBraidWordBuilder(i, a, b, L, n)
 * args:
 *        i, a, b, n - inputs to keygenPermutationBuilder
 *        L          - the number of elementary pure braids to muliply by
 * returns:
 *        pointer to the braidlist
 * notes:
 *
 * uses:
 *
 *-
 */
//#define BWB_DBG
ae_plist_t
keygenBraidWordBuilder(int i, int a, int b, int L, int n) {
  
  ae_plist_t answer = NULL;
  ae_pPermutation_t perm = NULL, test_perm = NULL;
  ae_plist_t rpbw2 = NULL;
  ae_plist_t rpbw1 = NULL;
  ae_plist_t irpbw1 = NULL;
  int count;
  int order, max_order = 0;

  /* Loop 25 times building permutations to find the one of highest order
   * Note that this can take a significant amount of time.
   */
  for (count = 0; count < 25; count++) {
    // keygenPermutationBuilder(i,a,b,n);
    test_perm = keygenRandomPermutationMovinga1b1Toab(i,i+1,a,b,n);
    order = keygenOrderOfPermutation(test_perm);
    if (order > max_order) {
      max_order = order;
      bandFreePermutation(perm);
      perm = test_perm;
      if (order >= landau[n]) /* quit if we found max order */
	break;
    } else {
      bandFreePermutation(test_perm);
    }
  }
#ifdef BWB_DBG
  fprintf(stderr, "Finalized on permutation of order %d, max order: %d\n",
	  max_order, landau[n]);
  fprintf(stderr, "i=%d, a=%d, b=%d\n", i, a, b);
  bandPrintPermutation(stderr, perm, "BraidWordBuilder Permutation");
#endif

  rpbw1 = keygenPermutationToRandomBraidWord(perm);

  if (L)
	rpbw2 = keygenRandomPureBraidWord(n, L);

  irpbw1 = braidInverse(rpbw1);
  answer = L ? braidMultiplication(irpbw1, rpbw2) : irpbw1;

  bandFreePermutation(perm);
  braidFreeBraidlist(&rpbw2);
  braidFreeBraidlist(&rpbw1);
  if (L)
    braidFreeBraidlist(&irpbw1);

  return(answer);
}


/*+
 * keygenCloakingElement - 
 *        creates a pure braid v in B_n satisfying (1,1)*CB(v) = (1,1) and 
 *        (M, sigma_M)*CB(v) = (M, sigma_M).    
 *
 * usage:
 *        keygenCloakingElement(i, a, b, L, n)
 * args:
 *        i, a, b, L, n - inputs to keygenBraidWordBuilder 

 * returns:
 *        pointer to the braidlist
 * notes:
 *        
 * uses:
 *
 *-
 */
ae_plist_t
keygenCloakingElement(int i, int a, int b, int L, int n) {
  
  ae_plist_t answer = NULL;
  ae_plist_t x = keygenBraidWordBuilder(i, a, b, L, n);
  ae_plist_t bi = braidArtinGenerator(n, i, 1);
  ae_plist_t bi2 = braidMultiplication(bi, bi);
  ae_plist_t ix = braidInverse(x);
  ae_plist_t ans1 = braidMultiplication(x, bi2);
  answer = braidMultiplication(ans1, ix);

  // answer is x * bi^2 * x^-1

  braidFreeBraidlist(&x);
  braidFreeBraidlist(&bi);
  braidFreeBraidlist(&bi2);
  braidFreeBraidlist(&ix);
  braidFreeBraidlist(&ans1);

  return(answer);
}

/*+
 * keygenPublicKeyEvaluator - create a public key from the first and second private keys
 *
 * usage: keygenPublicKeyEvaluator (n, firstPrivateKey, secondPrivateKey, tvalues)
 *
 * args:
 *      n - B_n
 *      firstPrivateKey - the first private key matrix
 *      secondPrivateKey - the second private key artin generators
 *      tvalues - the tvalues to use
 *
 * returns:
 *     pointer to the public key matrix or NULL if memory could not be allocated
 *
 * notes:
 *
 * uses:
 *
 *-
 */
//#define PUBLIC_DBG
ae_pcbdata_t
keygenPublicKeyEvaluator (unsigned int n, ae_pcbdata_t firstPrivateKey,
			  ae_plist_t secondPrivateKey, ae_pTvalues_t tvalues) {
    ae_pcblist_t spk;
    ae_pcbdata_t answer;
    /*
     * need to convert to CB form first
     */
    spk = braidToCBConverter (n, secondPrivateKey, tvalues);
    if (!spk)
	return NULL;
#ifdef PUBLIC_DBG
    ae_printCBList(stderr, spk);
#endif
    /*
     * now emultiply to get the key
     */
    answer = ae_eMultiplicationIterator (firstPrivateKey, spk, tvalues);
    braidFreeCBList(spk);

    return answer;
}

static double f(double r, int n, double SL) {
	double ans = 0;
	int i;

	ans += (r + (n - 2)*log2(r));
	ans -= SL;
	for (i = 2; i <= n - 1; i++) {
		ans -= log2(i);
	}

	return ans;
}

static double fder(double r, int n, double SL) {
	return (1 + (n - 2) / r / log(2));
}

	int keygenBraidLengthForSecurityLevel(double SL, int n)
{
	double tol = 1E-10;
	int maxits = 1000, its = 0;
	double ans = SL;

	while (fabs(f(ans, n, SL)) > tol) {
		double xi = ans;
		if (its > maxits) {
			fprintf(stderr, "maximum number of iterations exceeded\n");
			return 0;
		}
		its++;
		ans = xi - f(xi, n, SL) / fder(xi, n, SL);
#ifdef DBG
		fprintf(stderr, "  at bottom: f=%lf, f'=%lf\n", f(ans, n, SL), fder(ans, n, SL));
#endif
	}
	return (int)ceil(ans);
}

