/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/
#ifdef KAT_INTERMEDIATES

#include <stddef.h>
#include <stdint.h>
#include "aelib.h"
void printplist(ae_plist_t braid,  char *name);
void print_column_major_matrix(uint8_t matrix[WALNUT_BRAID][WALNUT_BRAID],  char *name);
void unpack_and_print_matrix(uint8_t *matrix,  char *name);
void printBraid(unsigned char *braid,  char *name);
void printBuffer(unsigned char *braid, size_t size,  char *name);

#endif