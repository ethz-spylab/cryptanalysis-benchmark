/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * bands.h - bands definitions
 */
#ifndef BANDS_H
#define BANDS_H 1
/*
 * Constants, Macros, etc
 */
#define THETA(i,t) (t->bwl[i].e<0?1:0)
#define SETBAND(bl,i,T,S,E)			\
    bl->bwl[i].s[0] = T;                        \
    bl->bwl[i].s[1] = S;                        \
    bl->bwl[i].e = E;
#define SETBANDDELTA(bl,i,e)                    \
    bl->bwl[i].d = e;
#define SETBANDLIST(bl,i,L)                     \
    bl->bwl[i].bl = L;
#define SETPERMUTATION(p,i,v)			\
    p->items[i] = v;
#define bandAllocatePermutation bandAllocateIntList
#define bandAllocateCycle  bandAllocateIntList
#define bandAllocateCycles bandAllocateListOfIntLists
#define bandAppendToCycles bandAppendToListOfIntLists
#define bandFreeCycles bandFreeListOfIntLists
#define bandCopyPermutation bandCloneIntList
#define bandFreePermutation bandFreeIntList
#define bandFreeCycle bandFreeIntList
#define bandPrintCycles bandPrintListOfIntLists
#define bandPrintPermutation bandPrintIntList
#define bandPrintPermutationFlat bandPrintIntListFlat
#define bandLoadPermutationFlat bandLoadIntListFlat
#define bandAppendToPermutation bandAppendToIntList
/*
 * Data structures/typedefs
 */
typedef struct _intlist_ {
    unsigned int n; /* number of items in the list */
    unsigned int * items;
} ae_IntList_t, * ae_pIntList_t;
typedef ae_IntList_t  ae_Permutation_t;

typedef ae_pIntList_t ae_pPermutation_t;
typedef ae_IntList_t ae_Cycle_t;
typedef ae_pIntList_t ae_pCycle_t;

typedef struct _bandword_ {
    struct _bandlist_ * bl;   /* next level of band word list */
    int                 s[2]; /* band subscripts */
    char                e;    /* band exponent */
    short               d;    /* if this is delta raised to a negative power */
                              /* s and e are 0 and d contains the negative power */
} ae_BandWord_t, * ae_pBandWord_t;

typedef struct _bandlist_ {
    unsigned int   n;   /* number of items in the list */
    ae_pBandWord_t bwl; /* bandword list represented as an array */
} ae_BandList_t, * ae_pBandList_t;

typedef struct _transposition_data_ {
    ae_ubraiddata_t l;
    ae_ubraiddata_t r;
} ae_TranspositionData_t, *ae_pTranspositionData_t;

typedef struct _transposition_ {
    unsigned int len;
    ae_pTranspositionData_t data;
} ae_Transposition_t, *ae_pTransposition_t;

typedef struct _transpositions_ {
    unsigned int len;
    ae_pTransposition_t * v;
} ae_Transpositions_t, *ae_pTranspositions_t;

typedef struct _listofintlists_ {
    unsigned int n; /* number of items in the list */
    ae_pIntList_t * p; /* array of int lists */
} ae_ListOfIntLists_t, * ae_pListOfIntLists_t;
typedef ae_ListOfIntLists_t  ae_Cycles_t;
typedef ae_pListOfIntLists_t ae_pCycles_t;
/*
 * prototypes
 */
ae_pBandList_t         bandAllocateBandList			(unsigned int l);
ae_pBandList_t         bandCloneBandList			(ae_pBandList_t bl);
void                   bandAppendToBandList			(ae_pBandList_t bl, ae_pBandList_t s);
void                   bandAppendToBandListEx			(ae_pBandList_t bl, ae_pBandList_t s);
void                   bandFreeBandList				(ae_pBandList_t bl);
unsigned int           bandCompareBandList			(ae_pBandList_t orig, ae_pBandList_t new);
ae_pIntList_t          bandAllocateIntList			(unsigned int l);
#define                bandAllocatePermutation                  bandAllocateIntList
void                   bandFreeIntList				(ae_pIntList_t p);
#define                bandFreePermutation                      bandFreeIntList
unsigned int           bandCompareIntList			(ae_pIntList_t a, ae_pIntList_t b);
#define                bandComparePermutations                  bandCompareIntList
ae_pIntList_t          bandFindPermutationFixedPoints           (ae_pPermutation_t perm);
#ifdef HAVE_STDIO
void                   bandPrintIntList				(FILE * fd, ae_pIntList_t p, char * comment);
void                   bandPrintIntListFlat			(FILE * fd, ae_pIntList_t p);
void                   bandPrintIntListFlatFile			(const char *filename, ae_pIntList_t p);
ae_pIntList_t          bandLoadIntListFlat			(FILE * fd, int index);
#endif
void                   bandAppendToIntList			(ae_pIntList_t p, unsigned int n);
ae_pListOfIntLists_t   bandAllocateListOfIntLists		(unsigned int i);
void                   bandAppendToListOfIntLists		(ae_pListOfIntLists_t l, ae_pIntList_t p);
ae_pIntList_t          bandCloneIntList				(ae_pIntList_t s);
void                   bandAppendIntListsToIntLists		(ae_pListOfIntLists_t d, ae_pListOfIntLists_t s);
void                   bandFreeListOfIntLists			(ae_pListOfIntLists_t l, unsigned int flags);
#define                bandFreeCycles bandFreeListOfIntLists
#ifdef HAVE_STDIO
void                   bandPrintListOfIntLists			(FILE * fd, ae_pListOfIntLists_t l, char * comment);
void                   bandPrintListOfIntListsFlat		(FILE * fd, ae_pListOfIntLists_t l);
#define                bandPrintCycles bandPrintListOfIntLists
#define                bandPrintCyclesFlat bandPrintListOfIntListsFlat
#endif
#ifdef HAVE_STDIO
void                   bandPrintBandList			(FILE * fd, ae_pBandList_t bl, 
              						          unsigned char * comment, unsigned int width);
void                   bandDumpBandList				(FILE * fd, ae_pBandList_t bl);
void                   bandPrintBandListFlat                    (FILE *fd, ae_pBandList_t bl);
void                   bandPrintBandListReallyFlat              (FILE *fd, ae_pBandList_t bl);
ae_pBandList_t         bandLoadBandListFlat                     (FILE *fd);
#endif
ae_pBandList_t         bandDelta				(unsigned int n);
ae_pBandList_t         bandArtinToBand				(ae_plist_t braidlist);
ae_plist_t             bandGenToArtinWord			(ae_pBandWord_t bw);
ae_plist_t             bandWordToArtinWord			(ae_pBandList_t bl);
ae_pBandList_t         bandInverseOf				(ae_pBandList_t bl);
ae_pBandList_t         bandDescendingCycle			(int l, int r);
ae_pBandList_t         bandInverseBandGenRewrite		(ae_pBandWord_t bandgen, unsigned int n);
unsigned int           bandModifiedMod				(unsigned int x, unsigned int n);
void                   bandLocalTauInverse			(ae_pBandWord_t bw, unsigned int n,  ae_pBandWord_t tinvbw);
ae_pBandList_t         bandTauInverse				(ae_pBandList_t bl, unsigned int n);
ae_pBandList_t         bandIteratedTauInverse			(unsigned int iterations, ae_pBandList_t bl, unsigned int n);
ae_pBandList_t         bandPositiveSubword			(unsigned int i, ae_pBandList_t bl, unsigned int n);
ae_pBandList_t         bandFirstBKLRewrite			(ae_pBandList_t bl, unsigned int n);
ae_plist_t             bandFirstBKLToArtin			(ae_pBandList_t bl, unsigned int n);
ae_pPermutation_t      bandMultiplyPermutations			(ae_pPermutation_t a, ae_pPermutation_t b);
ae_pIntList_t          bandPermuteIntList                       (const ae_pIntList_t a, ae_pPermutation_t b);
int                    bandIntListIndexOf                       (const ae_pIntList_t a, unsigned int m);
ae_pIntList_t          bandJoinComplement                       (const ae_pIntList_t a, const ae_pIntList_t b, unsigned int n);
ae_pCycles_t           bandCanonicalFactorToCycles		(ae_pBandList_t bl, unsigned int n);
ae_pCycles_t           bandToCycles				(ae_pPermutation_t p);
ae_pBandList_t         bandCyclesToCanonicalFactor		(ae_pCycles_t l);
ae_pCycles_t           bandCyclesInverse			(ae_pCycles_t l);
ae_pCycles_t           bandMultiplyCycles			(ae_pCycles_t l1, ae_pCycles_t l2);
ae_pPermutation_t      bandFromCycles				(ae_pCycles_t l);
ae_pCycles_t           bandRemoveSingletons			(ae_pCycles_t l);
ae_pBandList_t         bandRightComplement			(ae_pBandList_t bl, unsigned int n);
ae_pPermutation_t      bandMeetOfTwoSingleDescendingCycles	(ae_pPermutation_t sigma, ae_pPermutation_t tau);
ae_pBandList_t         bandMeetOfTwoCanonicalFactors		(ae_pBandList_t a, ae_pBandList_t b, unsigned int n);
ae_pBandList_t         bandGeneralRightComplement		(ae_pBandList_t bl, ae_pBandList_t meet, unsigned int n);
ae_pBandList_t         bandLocalLeftWeight			(ae_pBandList_t A, ae_pBandList_t B, unsigned int n);
ae_pBandList_t         bandBackwardsIteratedLeftWeight		(ae_pBandList_t bl, unsigned int n);
ae_pBandList_t         bandSetOfCanonicalFactorsToBandWord	(ae_pBandList_t bl);
ae_pBandList_t         bandRandomBandWord			(unsigned int n, unsigned int l);
ae_pBandList_t         bandStandardCanonicalFactor		(ae_pBandList_t bl, unsigned int n);
ae_pBandList_t         bandStandardSetOfCanonicalFactors	(ae_pBandList_t bl, unsigned int n);
ae_pBandList_t         bandBKLNormalForm			(ae_pBandList_t bl, unsigned int n);
ae_pBandList_t         bandBKLNormalFormWithCarry               (ae_pBandList_t bl, unsigned int n, unsigned int len, int delta, unsigned int percent);
ae_pBandList_t         bandFastBKLNormalForm                    (ae_plist_t braid, int n);
ae_pPermutation_t      bandRandomPermutation			(unsigned int n);
ae_pBandList_t         bandFastBKLNormalFormWithCarry           (ae_plist_t braid, unsigned int n, unsigned int len, int u);
ae_pBandList_t
bandFastBKLNormalFormWithCarryRandomSkip(ae_plist_t braid, unsigned int n, unsigned int len, int u, unsigned int backchance, unsigned int forwardchance, unsigned int startindex);

ae_pIntList_t          bandRandomSampleOfIntList                (ae_pIntList_t s, int l);

ae_pBandList_t         bandDrop					(ae_pBandList_t bl, unsigned int elem);
void                   bandAppendBandListToBandList		(ae_pBandList_t bl, ae_pBandList_t s);
ae_pTranspositions_t   bandAllocateTranspositions		(unsigned int len);
ae_pTransposition_t    bandAllocateTransposition		(unsigned int len);
void                   bandFreeTransposition			(ae_pTransposition_t p);
void                   bandFreeTranspositions			(ae_pTranspositions_t p, unsigned int flags);
void                   bandAppendTranspositionsToTranspositions	(ae_pTranspositions_t d, ae_pTranspositions_t a);
unsigned int           bandBandListLength                       (ae_pBandList_t bl);
#endif /* BANDS_H */
