/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#include "constants.h"
#include "aeutil.h"
#if WALNUT_SL == 128

#	ifdef WORKING_COPY
#include "openssl/sha.h"
#	else
#include "crypto_hash_sha256.h"
#	endif

#else
	
#	ifdef WORKING_COPY
#include "openssl/sha.h"
#	else
#include "crypto_hash_sha512.h"
#include "constants.h"
#	endif

#endif

void hash_message(const unsigned char *m, size_t mlen, unsigned char **digest)
{
	unsigned char *returndigest = ae_calloc(1, WALNUT_DGST_SIZ);

#if WALNUT_SL == 128
#	ifdef WORKING_COPY
		SHA256(m, mlen, returndigest);
#	else
		crypto_hash_sha256(returndigest, m, mlen);
#	endif
	
#else
	
#	ifdef WORKING_COPY
		SHA512(m, mlen, returndigest);
#	else
		crypto_hash_sha512(returndigest, m, mlen);
#	endif

#endif
		*digest = returndigest;
}