/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * pack.c -- Code to pack and unpack objects into byte strings
 */

#include "pack.h"
#include <math.h>    // for ceil(), log2()

#define PACK_USED(ctx,len) ((pack.bytelen == 8) ? (len - pack.buflen) : (len - pack.buflen + 1))

// buffer must already be zeroed out.
void ae_pack_init(AePackCtx* ctx, unsigned char* buffer, size_t buflen, int entrysize)
{
  ctx->buffer = buffer;
  ctx->buflen = buflen;
  ctx->entrysize = entrysize;
  ctx->bytelen = 8;
}

void ae_pack_entry(AePackCtx* ctx, ae_cbvalue_t entry)
{
  int entrylen = ctx->entrysize;
  int pack;
  unsigned char tmpentry;

  // So long as we have more bits available than the byte
  // then fill the byte, add to the buffer, reset, and continue
  while (entrylen > ctx->bytelen && ctx->buflen)
  {
    pack = ctx->bytelen;
    tmpentry = entry >> (entrylen - pack);
    entrylen -= pack;


    *(ctx->buffer) |= (tmpentry & ((1 << pack)-1));
    ctx->buffer++;
    ctx->buflen--;
    ctx->bytelen = 8;
  }

  // Now that we don't have enough bits then we pack entrylen into
  // the byte and can reduce bytelen
  if (entrylen && ctx->buflen)
  {
    pack = ctx->bytelen - entrylen;
    ctx->bytelen -= entrylen;
    tmpentry = entry & ((1 << entrylen)-1);
    *(ctx->buffer) |= tmpentry << pack;

    // Just in case we hit the end of the byte
    if (ctx->bytelen == 0)
    {
      ctx->bytelen = 8;
      ctx->buffer++;
      ctx->buflen--;
    }
  }
}

ae_cbvalue_t ae_unpack_entry(AePackCtx* ctx)
{
  int entrylen = ctx->entrysize;
  int pack;
  ae_cbvalue_t tmpentry;
  ae_cbvalue_t res = 0;

  // use up as many bits from the current byte as we have left
  // and then use as many full bytes as necessary
  while (entrylen >= ctx->bytelen && ctx->buflen)
  {
    pack = ctx->bytelen;
    tmpentry = *(ctx->buffer) & ((1 << pack)-1);
    res |= tmpentry << (entrylen - pack);
    entrylen -= pack;

    ctx->buffer++;
    ctx->buflen--;
    ctx->bytelen = 8;
  }

  // fill up remaining bits from the remaining byte
  if (entrylen && ctx->buflen)
  {
    pack = ctx->bytelen - entrylen;
    ctx->bytelen -= entrylen;
    tmpentry = *(ctx->buffer) >> pack;
    res |= tmpentry & ((1 << entrylen)-1);

    // And adjust, if we hit the end of the byte:
    if (ctx->bytelen == 0)
    {
      ctx->bytelen = 8;
      ctx->buffer++;
      ctx->buflen--;
    }
  }

  return res;
}

/*
 * braid packing format:
 *  <# generators>  (2 bytes: network byte order)
 *     generators
 *
 * For future expansion require that the two highest bits of the first
 * byte MUST be 0 (which reduces us to 16383 generators max).  Down
 * the road we can expand the length using the high bits as "feature
 * bits".
 *
 * In practice we've never seen more than ~4000 generators (even going
 * up to B16F256/SL2^128), so only allowing 16k should be sufficient
 * for now.
 */

/* How many bytes will be used to pack this braid? */
static int ae_pack_braid_len(const ae_plist_t braid, int index)
{
  if (!braid || !index)
    return 0;
  return (2 + ((braid->len * (ceil(log2(index)) + 1)) + 7)/8);
}

static int ae_pack_braid_direct(const ae_plist_t braid, int index, unsigned char* buffer, size_t buflen)
{
  AePackCtx pack;
  int i;
  int braidbits;

  if (!braid || !index || !buffer || !buflen)
    return -1;
  if (buflen < ae_pack_braid_len(braid, index))
    return -2;
  if (braid->len >= 1 << 14)  // 2^14
    return -3;

  // Encode the number of braid words.  Make sure the highest 2 bits are 0
  buffer[0] = (braid->len >> 8) & 0x3F;
  buffer[1] = braid->len & 0xFF;

  // Pack the braid
  braidbits = ceil(log2(index));
  ae_pack_init(&pack, buffer+2, buflen-2, braidbits+1);
  for (i = 0; i < braid->len; i++) {
    ae_cbvalue_t entry = braid->b[i].l-1;
    if (braid->b[i].u < 0)
      entry |= (1 << braidbits);
    ae_pack_entry(&pack, entry);
  }

  return PACK_USED(pack,buflen);
}

int ae_pack_braid(const ae_plist_t braid, int index, unsigned char** buffer, size_t *buflen)
{
  unsigned char *buf;
  size_t bl;
  int res;

  if (buffer) *buffer = NULL;
  if (buflen) *buflen = 0;

  if (!braid || !index || !buffer || !buflen)
    return -1;

  bl = ae_pack_braid_len(braid, index);
  buf = calloc(1, bl);
  if (!buf)
    return -2;

  res = ae_pack_braid_direct(braid, index, buf, bl);
  if (res < 0) {
    memset(buf, 0, bl);
    free(buf);
    buf = NULL;
    bl = 0;
  }

  *buffer = buf;
  *buflen = bl;
  return ((res < 0) ? res : 0);
}

int ae_unpack_braid(const unsigned char* buffer, size_t buflen, int index, ae_plist_t* braid)
{
  AePackCtx pack;
  int i;
  int len;
  int braidbits;

  if (!buffer || buflen < 2 || !index || !braid)
    return -1;

  // Make sure the highest two bits are not set
  if (buffer[0] & 0xC0)
    return -2;

  len = ((unsigned)buffer[0] << 8) | buffer[1];

  *braid = braidAllocateBraidlist(len);
  if (!*braid)
    return -3;

  braidbits = ceil(log2(index));
  ae_pack_init(&pack, (unsigned char*)buffer+2, buflen-2, braidbits+1);
  for (i = 0; i < len; i++) {
    ae_cbvalue_t entry = ae_unpack_entry(&pack);
    (*braid)->b[i].l = (entry & ((1 << braidbits) - 1)) + 1;
    (*braid)->b[i].u = ((entry & (1 << braidbits)) ? -1 : 1);
  }

  return PACK_USED(pack,buflen);
}

