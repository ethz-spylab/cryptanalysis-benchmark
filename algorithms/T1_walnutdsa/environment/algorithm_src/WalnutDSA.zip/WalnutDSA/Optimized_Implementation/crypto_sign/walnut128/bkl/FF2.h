/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#ifndef FF2_H
#define FF2_H

#include "finitefields.h"

#define ENABLE_FIELD_4
#define ENABLE_FIELD_8
#define ENABLE_FIELD_16
#define ENABLE_FIELD_32
#define ENABLE_FIELD_64
#define ENABLE_FIELD_128
#define ENABLE_FIELD_256
#define ENABLE_FIELD_512
#define ENABLE_FIELD_1024
#define ENABLE_FIELD_2048
#define ENABLE_FIELD_4096
#define ENABLE_FIELD_8192
#define ENABLE_FIELD_16384
#define ENABLE_FIELD_32768
#ifndef __MSP430__  /* The following fields don't work on MSP430 */
#define ENABLE_FIELD_65536
#define ENABLE_FIELD_4194304
#define ENABLE_FIELD_2147483648
#endif

typedef unsigned FF2elem;

const SrfFiniteField* ff2GetFF(ffelem);

#define CHECK_BIT(var,pos) ((var) & (1<<(pos)))




#if 0 

#define F16

#ifdef F2
#define FF2ORDER    4
#define POL         0x7 // x^2+x+1
#define POLDEGREE   2
#define HIGHESTBIT  0x4 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x3 // x^2->x+1
#define REDUCEMASK  0x3 // this picks off the allowed part of a word (only works in 
                        // single precision
#endif

#ifdef F3
#define FF2ORDER    8
#define POL         0xb // x^3+x+1
#define POLDEGREE   3
#define HIGHESTBIT  0x8 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x3 // x^3->x+1
#define REDUCEMASK  0x7 // this picks off the allowed part of a word (only works in 
                        // single precision
#endif

#ifdef F4
#define FF2ORDER    16
#define POL         0x13 // x^4 + x + 1
#define POLDEGREE   4
#define HIGHESTBIT  0x10 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x03 // x^4 -> x + 1
#endif

#ifdef F5
#define FF2ORDER    32
#define POL         0x25 // x^5 + x^2 + 1
#define POLDEGREE   5
#define HIGHESTBIT  0x20 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x05 // x^5 -> x^2 + 1
#endif

#ifdef F6
#define FF2ORDER    64
#define POL         0x43 // x^6 + x + 1
#define POLDEGREE   6
#define HIGHESTBIT  0x40 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x03 // x^6 -> x + 1
#endif

#ifdef F7
#define FF2ORDER    128
#define POL         0x83 // x^7 + x + 1
#define POLDEGREE   7
#define HIGHESTBIT  0x80 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x03 // x^7 -> x + 1
#endif

#ifdef F8
#define FF2ORDER    256
#define POL         0x11b // x^8 + x^4 + x^3 + x + 1
#define POLDEGREE   8
#define HIGHESTBIT  0x100 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x01b // x^8 -> x^4 + x^3 + x + 1
#endif

#ifdef F9
#define FF2ORDER    512
#define POL         0x203 // x^9 + x + 1
#define POLDEGREE   9
#define HIGHESTBIT  0x200 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x003 // x^9 -> x + 1
#endif

#ifdef F10
#define FF2ORDER    1024
#define POL         0x409 // x^10 + x^3 + 1
#define POLDEGREE   10
#define HIGHESTBIT  0x400 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x009 // x^10 -> x^3 + 1
#endif

#ifdef F11
#define FF2ORDER    2048
#define POL         0x805// x^11 + x^2 + 1
#define POLDEGREE   11
#define HIGHESTBIT  0x800 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x005 // x^11 -> x^2 + 1
#endif

#ifdef F12
#define FF2ORDER    4096
#define POL         0x1009 // x^12 + x^3 + 1
#define POLDEGREE   12
#define HIGHESTBIT  0x1000 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x0009 // x^12 -> x^3 + 1
#endif

#ifdef F13
#define FF2ORDER    8192
#define POL         0x201b // x^13 + x^4 + x^3 + x + 1
#define POLDEGREE   13
#define HIGHESTBIT  0x2000 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x001b // x^13 -> x^4 + x^3 + x + 1
#endif

#ifdef F14
#define FF2ORDER    16384
#define POL         0x4021 // x^14 + x^5 + 1
#define POLDEGREE   14
#define HIGHESTBIT  0x4000 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x0021 // x^14 -> x^5 + 1
#endif

#ifdef F15
#define FF2ORDER    32768
#define POL         0x8003 // x^15 + x + 1
#define POLDEGREE   15
#define HIGHESTBIT  0x8000 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x0003 // x^15 -> x + 1
#endif

#ifdef F16
#define FF2ORDER    65536
#define POL         0x1002b // x^16 + x^5 + x^3 + x +1
#define POLDEGREE   16
#define HIGHESTBIT  0x10000 // and with complement of this to turn off highest degree in POL
#define POLRELATION 0x0002b // x^16 -> x^5 + x^3 + x + 1
#endif



#ifdef F22
#define FF2ORDER    4194304
#define POL         0x400003 // x^22+x+1
#define POLDEGREE   22
#define HIGHESTBIT  0x400000
#define POLRELATION 0x000003 // x^22 -> x+1
#endif 

#ifdef F31
#define FF2ORDER    2147483648
#define POL         0x80000009 // x^31 + x^3 + 1
#define POLDEGREE   31
#define HIGHESTBIT  0x80000000
#define POLRELATION 0x00000009 // x^31 -> x^3 + 1
#endif

typedef unsigned FF2elem;

int      FF2checkbit(FF2elem a, int position);
void	 FF2rightshift(FF2elem *b);
int	 FF2elemiszero(FF2elem a);
int	 FF2elemisone(FF2elem a);
int	 FF2degree(FF2elem a);
int	 FF2checkifreduced(FF2elem a, int poldegree);
FF2elem	 FF2add(FF2elem a, FF2elem b);
FF2elem	 FF2neg(FF2elem a);
FF2elem	 FF2multbyx(FF2elem a, unsigned pol, int poldegree);
FF2elem	 FF2multbyxtok(FF2elem a, int k, unsigned pol, int poldegree);
FF2elem	 FF2xtok(int k, unsigned pol, int poldegree);
FF2elem	 FF2reduce(FF2elem x, unsigned pol, int poldegree);
FF2elem	 FF2mult(FF2elem a, FF2elem b, unsigned pol, int poldegree);
FF2elem  FF2inverse(FF2elem a, unsigned pol);
FF2elem  FF2neginverse(FF2elem a, unsigned pol);
FF2elem  FF2divide(FF2elem a, FF2elem b, unsigned pol, int poldegree);

#endif // 0

#endif /* FF2_H */

