/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/


/* 
 * Includes 
 */
#include "aelib.h"
#include <stdlib.h>
#include <stdint.h>
#include <string.h>


/*
 * constants, data structures, etc
 */
// cutoff length for the divide and conquer algorithm
#define CUTOFF 5

enum {
	SIZE_MULTIPLE = 3,
	SIGN_BIT = 0x80,
	SHORTEN_LIMIT = 5
};

#define NOT_FOUND (~0)

struct handle {
	size_t start;
	size_t end;
};

typedef struct {
	size_t reduced_sp;
	size_t end_sp;

	uint8_t *buf;
	size_t *lastseen;
	uint64_t *sign;

	size_t bufsize;
	uint8_t braid;

	size_t signfield;
	size_t last[64];
	
} dehornoy_ctx;

int segment;
/*
 * externs, prototypes
 */

/***********************************************************************/

/* This code implements handle reduction as described in the paper "A
 * fast method for Comparing Braids" by Patrick Dehornoy.  In
 * particular, this code implements the algorithm FullHRed, where the
 * leftmost handle is removed until no handles exist.  Though GreedyHRed
 * theoretically runs faster, the goal of this code is to produce the
 * smallest braid possible, not to produce a braid in Dehornoy's form.
 *
 * A handle is made up of all elements between two generators n^e,
 * n^{-e} without any generators with the value n-1 between them.  That
 * is,
 * 2,3,5,2^{-1}
 * is a handle but
 * 2,1,2^{-1} and 2,3,2
 * are not.
 *
 * A braid can be broken up into two parts: a portion that contains no
 * handles and a portion that may contain handles.  To begin, an
 * arbitrary braid is input entirely into the portion that may have
 * handles.
 *
 * [ ]         [b0..bn]
 *  ^              ^
 *  |              |
 *  |              |
 *  no handles     may have handles
 *
 * The portion with handles is added to the portion with handles until a
 * handle is found
 * [b0..bk]  [bk+1..bn]
 *  ^              ^
 *  |              |
 *  |              |
 *  no handles     may have handles
 *
 * At this point the generators that belong to the handle (say bj to bk)
 * are popped and stored as a handle.
 *
 * [b0..bj-1][bj..bk]     [bk+1..bn]
 * ^             ^                 ^
 * |             |                 |
 * no handles    leftmost handle   may have handles
 *
 * The handle is then reduced into the may have handles buffer
 * [b0..bk]  [bj'..bk',bk+1..bn]
 *  ^              ^
 *  |              |
 *  |              |
 *  no handles     may have handles
 *
 * The reduced handle is often, but not always shorter than the handle
 * before it was reduced.
 *
 * This code implements this algorithm using two stacks: the "reduced"
 * stack and the "end" stack.  Each value in the reduced stack also
 * keeps track of the last time a generator with the same value was seen
 * and the sign of the last seen value.  This makes popping values off
 * the reduced stack cheaper.
 */

/* grow the buffer and memo buffer lengths by 1.5x and move the values
 * in c->buf pointed to by c->end_sp over to the newly allocated memory
 */
static int grow_ctx(dehornoy_ctx *c)
{
	size_t growsize = c->bufsize + (c->bufsize / 2);
	size_t endlen = c->bufsize - c->end_sp;

	c->buf = realloc(c->buf, growsize * sizeof(c->buf[0]));
	c->lastseen = realloc(c->lastseen, growsize *
			sizeof(c->lastseen[0]));

	c->sign = realloc(c->sign, growsize * sizeof(c->sign[0]));

	if(c->buf == NULL || c->lastseen == NULL || c->sign == NULL) {
		free(c->buf);
		free(c->lastseen);
		free(c->sign);
		return 0;
	}

	/* since the reduced stack must necessarily fit in the old
	 * buffer only the values in end must be moved over on realloc
	 */
	memmove(c->buf + growsize - endlen, c->buf + c->end_sp,
			endlen * sizeof(c->buf[0]));

	c->end_sp = growsize - endlen;
	c->bufsize = growsize;

	return 1;
}

/* pop count values off of the reduced stack in c, updating state
 * for memoized data.
 */
static void pop_reduced_n(dehornoy_ctx *c, size_t count)
{
	size_t adjusted_sp = c->reduced_sp - count;

	size_t i;
	if(c->braid > count) {
		for(; c->reduced_sp > adjusted_sp; c->reduced_sp--) {
			uint8_t generator = c->buf[c->reduced_sp-1];
			uint8_t val = generator & ~SIGN_BIT;

			c->last[val] = c->lastseen[c->reduced_sp-1];
		}
	} else {
		for(i=0; i<c->braid; i++) {
			size_t last = c->last[i];
			while(last != NOT_FOUND && last >= adjusted_sp) {
				last = c->lastseen[last];
			}

			c->last[i] = last;
		}

	}

	c->reduced_sp = adjusted_sp;
	c->signfield = c->sign[c->reduced_sp];


}

size_t lastsp = 0;
/* push an artin generator onto the reduced stack in c, updating state
 * information for memoized data
 */
static void push_reduced(uint8_t generator, dehornoy_ctx *c)
{
	uint8_t val = generator & ~SIGN_BIT;
	uint8_t sign = generator & SIGN_BIT;
	size_t val_bit = 1 << val;
	size_t sign_bit = sign ? val_bit : 0x0;

	c->signfield = (c->signfield & ~val_bit) | sign_bit;

	c->buf[c->reduced_sp] = generator;
	c->sign[c->reduced_sp] = c->signfield;
	c->lastseen[c->reduced_sp] = c->last[val];

	c->last[val] = c->reduced_sp;

	c->reduced_sp++;
}

/* return start address of handle in [reduced stack || generator], or
 * NOT_FOUND if a handle does not exist
 */
static size_t handle_start(uint8_t generator, dehornoy_ctx *c)
{
	uint8_t val = generator & ~SIGN_BIT;
	uint8_t sign = generator & SIGN_BIT;
	size_t val_bit = 1 << val;
	size_t sign_bit = sign ? val_bit : 0x0;

	int valid_handle = c->last[val] != NOT_FOUND;

	if (!valid_handle)
		return NOT_FOUND;

	valid_handle = valid_handle && (c->signfield & val_bit) ^ sign_bit;

	if (!valid_handle)
		return NOT_FOUND;

	valid_handle = valid_handle && ((val == 0) ||
			(c->last[val - 1] == NOT_FOUND) ||
			c->last[val] > c->last[val - 1]);

	if(valid_handle) {
		return c->last[val];
	} else {
		return NOT_FOUND;
	}
}

/* sets c such that begin stack contains values up to start of returned
 * handle and c contains the rest of the braid, excluding the values in
 * the range of the returned handle.
 *
 * Returns (0,0) if no such handle exists.
 */
static struct handle find_handle(dehornoy_ctx *c)
{
	struct handle h;

	//Starting at end_sp and continuing until the end of our entire braid
	for(; c->end_sp<c->bufsize; c->end_sp++) {
		//Grab the generator at end_sp
		uint8_t generator = c->buf[c->end_sp];

		//Look through 
		size_t start = handle_start(generator, c);

		if(start == NOT_FOUND) {
			push_reduced(generator, c);
		} else {
			size_t end = c->reduced_sp;
			c->end_sp++;
			pop_reduced_n(c, c->reduced_sp - start);

			h.start = start;
			h.end = end;
			return h;
		}
	}

	h.start = 0;
	h.end = 0;
	return h;
}

/* Iterate backwards over the range of the handle, pushing values
 * reduced from the handle onto the end stack.
 */
static void reduce_handle(dehornoy_ctx *c, struct handle h)
{
	size_t i;
	size_t length = 0;
	uint8_t *dest = c->buf + c->end_sp - 1;

	uint8_t main_generator = c->buf[h.start];
	uint8_t main_sign = main_generator & SIGN_BIT;
	uint8_t main_val = main_generator & ~SIGN_BIT;

	for(i=h.end - 1; i>h.start; i--) {
		uint8_t generator = c->buf[i];
		uint8_t sign = generator & SIGN_BIT;
		uint8_t val = generator & ~SIGN_BIT;

		if(val == main_val + 1) {
			*dest-- = val | main_sign;
			*dest-- = main_val | sign;
			*dest-- = val | (main_sign ^ SIGN_BIT);
			length += 3;
		} else if(val != main_val) {
			*dest-- = generator;
			length++;
		}
	}

	c->end_sp -= length;
}

/* reduce all handles stored in c until none exist.  On exit,
 * c->reduced_sp will hold the length of the reduced braid and c->buf
 * will store the associated Artin generators.
 *
 * Returns true on success, false on out of memory.
 */
static int dehornoy(dehornoy_ctx *c)
{
	for(;;) {
		struct handle h = find_handle(c);

		if(h.start == 0 && h.end == 0) {
			return 1;
		}

		/* Worst case, each value between h.start and h.end
		 * exclusive will output 3 elements.  If this will grow
		 * past the distance between our two stacks, reallocate
		 * more memory.
		 */
		if((h.end - h.start - 1) * 3 >
		    c->end_sp - c->reduced_sp) {
			if(!grow_ctx(c)) {
				return 0;
			}
		}

		reduce_handle(c, h);
	}
}

/* dehornoy will return a braid that has no handles.  Some handles may
 * exist if the braid is "flipped" about its strands.  This method will
 * return the same thing as dehornoy, except the strands will be flipped
 * several times.  In practice this often produces a shorter braid at
 * the expense of a small amount of computation time.
 *
 * Returns true on success, false on out of memory.
 */
static int dehornoy_shorten(dehornoy_ctx *c)
{
	size_t i;

	if(!dehornoy(c)) {
		return 0;
	}

	return 1;
}

/* Initialize a context with artin generators before calling dehornoy.
 * An uninitialized context must be cleared with memset.  braid cannot
 * exceed 64.  Contexts can be reused with new braids to avoid
 * supurious allocations.
 */
static int dehornoy_getctx(const uint8_t *artin, size_t count,
		uint8_t braid, dehornoy_ctx *c)
{
	size_t i;

	if(braid > 64) {
		return 0;
	}

	if(c->bufsize >= count * SIZE_MULTIPLE) {
		goto init;
	}

	c->bufsize = count * SIZE_MULTIPLE;

	c->buf = realloc(c->buf, c->bufsize * sizeof(c->buf[0]));
	c->lastseen = realloc(c->lastseen, c->bufsize *
			sizeof(c->lastseen[0]));
	c->sign = realloc(c->sign, c->bufsize * sizeof(c->sign[0]));

	if(c->buf == NULL || c->lastseen == NULL || c->sign == NULL) {
		free(c->buf);
		free(c->lastseen);
		free(c->sign);
		return 0;
	}

init:
	for(i=0; i<braid; i++) {
		c->last[i] = NOT_FOUND;
	}

	memcpy(c->buf + c->bufsize - count, artin, count);

	c->signfield = 0;
	c->braid = braid;
	c->reduced_sp = 0;
	c->end_sp = c->bufsize - count;

	return 1;
}

/* free a braid context allocated with dehornoy_getctx */
static void dehornoy_freectx(dehornoy_ctx *c)
{
	free(c->buf);
	free(c->lastseen);
	free(c->sign);
}

ae_plist_t ae_FastDehornoyReduction(ae_plist_t w, unsigned int index)
{
	uint8_t *artin = (uint8_t *)ae_malloc(w->len); 
	size_t i;
	dehornoy_ctx c;

	ae_plist_t ret;

	if(artin == NULL) {
		return NULL;
	}

	for(i=0; i<w->len; i++) {
		artin[i] = w->b[i].l - 1;

		if(w->b[i].u == -1) {
			artin[i] |= SIGN_BIT;
		}

	}

	memset(&c, 0, sizeof(c));

	if(!dehornoy_getctx(artin, w->len, index, &c)) {
		free(artin);
		return NULL;
	}

	if(!dehornoy_shorten(&c)) {
		free(artin);
		return NULL;
	}

	ret = braidAllocateBraidlist(c.reduced_sp);

	for(i=0; i<c.reduced_sp; i++) {
		uint8_t generator = c.buf[i];
		uint8_t val = generator & ~SIGN_BIT;
		int sign = generator & SIGN_BIT ? -1 : 1;

		ret->b[i].l = val + 1;
		ret->b[i].u = sign;
	}

	dehornoy_freectx(&c);
	free(artin);

	return ret;
}
