/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * config.h - porting configuration parameters for the AE sdk
 */

#ifndef CONFIG_H
#define CONFIG_H 1
/*
 * default settings for this file are for an x86_64 linux/windows port
 */

/*
 * Native type lengths, define according to the compiler being used.
 */
#define NATIVE_CHAR_8_BITS 1
/*#define NATIVE_SHORT_8_BITS 1*/
#define NATIVE_SHORT_16_BITS 1
/*#define NATIVE_INT_16_BITS 1*/
#define NATIVE_INT_32_BITS 1
/*#define NATIVE_LONG_32_BITS 1*/
#define NATIVE_LONG_64_BITS 1
/*
 * any system functions or types that we need
 */
#define HAVE_STDIO 1 
#define HAVE_MALLOC_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1
#define HAVE_TIMEVAL 1
#define HAVE_SIGACTION 1
#define HAVE_RTX_INSTRUCTIONS
#define HAVE_DEV_RANDOM 1
#endif /* CONFIG_H */
