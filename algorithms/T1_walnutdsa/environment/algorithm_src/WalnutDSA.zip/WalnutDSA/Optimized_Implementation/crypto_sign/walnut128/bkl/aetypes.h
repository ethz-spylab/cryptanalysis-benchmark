/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * aetypes.h - define portable datatypes for ae
 */
#include "ae_config.h"

#ifndef AETYPE_H
#define AETYPES_H 1

#if NATIVE_CHAR_8_BITS
typedef char            ae_char8_t;
typedef ae_char8_t      ae_int8_t;
typedef char *          ae_pchar8_t;
typedef ae_pchar8_t     ae_pint8_t;
typedef unsigned char   ae_uchar8_t;
typedef ae_uchar8_t     ae_uint8_t;
typedef unsigned char * ae_puchar8_t;
typedef ae_puchar8_t    ae_puint8_t;
#endif

#if NATIVE_SHORT_8_BITS
typedef int            ae_short16_t;
typedef int *          ae_pshort16_t;
typedef unsigned int   ae_ushort16_t;
typedef unsigned int * ae_pushort16_t;
#endif

#if NATIVE_SHORT_16_BITS
typedef short int            ae_short16_t;
typedef short int *          ae_pshort16_t;
typedef unsigned short   ae_ushort16_t;
typedef unsigned short * ae_pushort16_t;
#endif

#if NATIVE_INT_16_BITS
typedef long            ae_int32_t;
typedef long *          ae_pint32_t;
typedef unsigned long   ae_uint32_t;
typedef unsigned long * ae_puint32_t;
#endif

#if NATIVE_INT_32_BITS
typedef int            ae_int32_t;
typedef int *          ae_pint32_t;
typedef unsigned int   ae_uint32_t;
typedef unsigned int * ae_puint32_t;
#endif

#if NATIVE_LONG_32_BITS
typedef long long            ae_long64_t;
typedef long long *          ae_plong64_t;
typedef unsigned long long   ae_ulong64_t;
typedef unsigned long long * ae_pulong64_t;
#endif

#if NATIVE_LONG_64_BITS
typedef long            ae_long64_t;
typedef long *          ae_plong64_t;
typedef unsigned long   ae_ulong64_t;
typedef unsigned long * ae_pulong64_t;
#endif

#endif
