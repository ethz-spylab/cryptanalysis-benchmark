/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * keygen.h - data structures/prototypes for keygen.c
 */

#ifndef KEYGEN_H
#define KEYGEN_H 1

/*
 * Constants, Macros, etc
 */
#ifndef TRUE
# define TRUE 1
# define FALSE 0
#endif
/*
 * Data structures/typedefs
 */
typedef struct _TTPchoices {
  unsigned int z_len;
  unsigned int word_len;
  unsigned int num_gens;
} ae_TTPchoices_t, *ae_pTTPchoices_t;
/*
 * prototypes
 */
double                   logtwo						(double x);
double                   factorial					(int n);
void                     keygenShiftLeftBraidRight                      (ae_plist_t b, unsigned int n);
ae_pIntList_t            keygenRandomSampleAB                           (unsigned int a, unsigned int b, unsigned int n);
unsigned int             keygenOrderOfBraidPermutation			(ae_plist_t braidlist, unsigned int n);
ae_pPermutation_t        keygenTwoCycle					(unsigned int i, unsigned int n);
ae_pPermutation_t        keygenArtinWordToPermutation			(ae_plist_t braidlist, unsigned int n);
ae_plist_t               keygenFreelyReducedRandomArtinWord		(unsigned int n, unsigned int l);
ae_plist_t               keygenFreelyReducedLeftRandomArtinWord		(unsigned int n, unsigned int l);
ae_plist_t               keygenFreelyReducedRightRandomArtinWord	(unsigned int n, unsigned int l);
unsigned int             keygenBKLLength				(ae_pBandList_t bklnormal);
ae_plist_t               keygenKthPower					(ae_plist_t bl, int k);
ae_pBandList_t           keygenKthPowerEx				(ae_pBandList_t bl, int k);
ae_plist_t               keygenBKLNormalFormToArtinWord			(ae_pBandList_t bkl, unsigned int n);
ae_plist_t               keygenBKLOfBraidWord    			(ae_plist_t b, int n);
ae_plist_t               keygenTranspositionToRandomArtinWord		(ae_pTranspositionData_t t);
ae_pTranspositions_t     keygenCycleToProductOfTranspositions		(ae_pCycle_t cycle);
ae_pTranspositions_t     keygenPermutationToProductOfTranspositions	(ae_pPermutation_t p);
ae_plist_t               keygenPermutationToRandomBraidWord		(ae_pPermutation_t p);
unsigned int             keygenOrderOfPermutation			(ae_pPermutation_t p);
ae_pPermutation_t        keygenRandomPermutationOfMaxOrder		(unsigned int n);
ae_pPermutation_t        keygenRandomRightPermutationOfMaxOrder		(unsigned int n);
unsigned int             keygenNumberOfPermutationsWithGivenCycles	(ae_pIntList_t p, unsigned int n);
unsigned int             keygenSecurePermutationQ			(ae_pPermutation_t p, unsigned int n);
ae_pPermutation_t        keygenRandomSecurePermutation			(unsigned int n);
int                      keygenNumberOfSecurePermutations		(unsigned int n);
ae_pPermutation_t        keygenPermutationBuilder                       (int i, int a, int b, int n);
ae_pPermutation_t        keygenRandomPermutationFixingab                (int a, int b, int n);
ae_pPermutation_t        keygenRandomPermutationMovinga1b1Toab          (int a1, int b1, int a, int b, int n);

ae_plist_t               keygenPureBraidGen				(int i, int j, int e);
ae_plist_t               keygenRandomPureBraidGen			(int n);
ae_plist_t               keygenRandomPureBraidWord			(int n, int l);
ae_plist_t               keygenRandomPureRightBraidGen			(int n);
ae_plist_t               keygenRandomRightPureBraidWord			(int n, int l);
ae_plist_t               keygenRandomRightPureBraidWordInSquares	(int n, int l);
ae_plist_t               keygenRandomRightPureBraidWordShortWords	(int n, int l);
ae_plist_t               keygenBraidWordBuilder                         (int i, int a, int b, int L, int n);
ae_plist_t               keygenCloakingElement                          (int i, int a, int b, int L, int n);
ae_pIntList_t            keygenUsableFixedPoints                        (ae_pPermutation_t perm, ae_pTvalues_t tvalues);
ae_pIntList_t            keygenFindUnityTValues                         (unsigned int n, ae_pTvalues_t tvalues);
ae_plist_t               keygenLeftCloakingElement                      (ae_pPermutation_t perm, unsigned int a, unsigned int b, int L);
ae_plist_t               keygenRightCloakingElement                     (ae_pPermutation_t perm, ae_pPermutation_t my_perm, unsigned int a, unsigned int b, int L);
ae_pPermutation_t        keygenNewLookPerm                              (unsigned int n);
ae_plist_t               keygenNewLookZCreator                          (unsigned int n, unsigned int secLevel);
ae_plist_t               keygenZCreatorFromPermutation                  (ae_pPermutation_t perm, unsigned int secLevel);
ae_plist_t               keygenCloakingZCreator                         (unsigned int n, unsigned int c1, unsigned int c2, unsigned int d1, unsigned int d2, unsigned int secLevel);
ae_plistOfLists_t        keygenKayaAliceConjugates                      (unsigned int n, ae_plist_t z, unsigned int secLevel, unsigned int num);
ae_plistOfLists_t        keygenKayaBobConjugates                        (unsigned int n, ae_plist_t z, unsigned int secLevel, unsigned int num);
ae_plist_t               keygenZCreator					(int n, int lowerSecLevel, 
								          int upperSecLevel, int * actualSecLevel);
ae_plist_t               keygenAlicesPublicWord				(int n, int securityLevel);
ae_plist_t               keygenBobsPublicWord				(int n, int securityLevel);
ae_plist_t               keygenAlicesPublicConjugate			(ae_plist_t z, int n, int securityLevel);
ae_plist_t               keygenBobsPublicConjugate			(ae_plist_t z, int n, int securityLevel);
ae_plist_t               keygenSecondPrivateKeyGenerator		(unsigned int n, ae_plistOfLists_t sog, unsigned int l);
void                     keygenModifiedSecondPrivateKeyGenerator	(unsigned int n, ae_plistOfLists_t conjugates, ae_plistOfLists_t purebraids, unsigned int len, ae_plist_t *braid1, ae_plist_t *braid2);
ae_pcbdata_t             keygenFirstPrivateKey				(ae_2dMatrix_t mo, unsigned int n);
ae_pcbdata_t             keygenSecureFirstPrivateKeySeed                (ae_plistOfLists_t b, ae_pTvalues_t tValues, 
									 unsigned int n, unsigned int L);
ae_plist_t               keygenAlicesPublicConjugateGenerator		(unsigned int n, ae_plist_t z, unsigned int secLevel);
ae_plist_t               keygenBobsPublicConjugateGenerator		(unsigned int n, ae_plist_t z, unsigned int secLevel);
ae_plist_t               keygenAlicesSecureConjugateGenerator		(unsigned int n, ae_plist_t z, unsigned int secLevel);
ae_plist_t               keygenBobsSecureConjugateGenerator		(unsigned int n, ae_plist_t z, unsigned int secLevel);
ae_plistOfLists_t        keygenAlicesPublicConjugateList		(unsigned int n, ae_plist_t z, unsigned int secLevel, unsigned int L);
ae_plistOfLists_t        keygenBobsPublicConjugateList			(unsigned int n, ae_plist_t z, unsigned int secLevel, unsigned int L);
ae_plistOfLists_t        keygenAlicesSecureConjugateList		(unsigned int n, ae_plist_t z, unsigned int secLevel, unsigned int L);
ae_plistOfLists_t        keygenBobsSecureConjugateList			(unsigned int n, ae_plist_t z, unsigned int secLevel, unsigned int L);
ae_pcbdata_t             keygenPublicKeyEvaluator			(unsigned int n, ae_pcbdata_t firstPrivateKey,
								     ae_plist_t secondPrivateKey, ae_pTvalues_t tvalues);
ae_pcbdata_t             keygenSecureFirstPrivateKeyEvaluator           (unsigned int n, ae_pcbdata_t firstPrivateKey,
								     ae_plist_t secondPrivateKey, ae_pTvalues_t tvalues);

#endif /* KEYGEN_H */

