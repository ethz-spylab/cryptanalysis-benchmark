/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#ifndef DEHORNOY_H
#define DEHORNOY_H 1
/*
 * Includes
 */

/*
 * Constants, data declarations, macros
 */
#define REPLACE(list, item, orig)			\
  item->bck = orig->bck;    \
  if (item->bck)             \
    item->bck->fwd = item;   \
  item->fwd = orig->fwd;    \
  if (item->fwd)             \
    item->fwd->bck = item;   \
  if (!item->bck)            \
    list->head = item;       \
  if (!item->fwd)            \
    list->tail = item;

#define INSERT(list, item, after)    \
  item->fwd = after->fwd;            \
  item->bck = after;                 \
  after->fwd = item;                 \
  if (item->fwd)                     \
    item->fwd->bck = item;	     \
  if (list->tail == after)           \
    list->tail = item;

/*
 * externs, prototypes, etc
 */
ae_plist_t ae_FastDehornoyReduction             (ae_plist_t w, unsigned int index);
void       ae_ReduceHandle			(ae_pllist_t H, ae_pllist_t U);
ae_plist_t ae_DehornoyReduction			(ae_plist_t w);
void       ae_DehornoyReductionSplit            (ae_pllist_t *ll);
void       ae_DehornoyReductionNoSplit          (ae_pllist_t *ll);
ae_plist_t ae_DehornoyReductionOrig		(ae_plist_t w);
int        ae_FindLeftmostHandle		(ae_pllist_t A, ae_pbraidlist_ll_t *handle_left, ae_pbraidlist_ll_t *handle_right);
void       ae_ReplaceLeftmostHandle		(ae_pllist_t A, ae_pbraidlist_ll_t handle_left, ae_pbraidlist_ll_t handle_right);
void       ae_FreelyReduceLinkedList		(ae_pllist_t A);
int        ae_FreelyReduceLinkedListOnce	(ae_pllist_t A);

#endif /* DEHORNOY_H */
