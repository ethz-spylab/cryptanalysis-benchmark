/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/


/*
 * braids.h - data structures and function prototypes
 */

#ifndef BRAIDS_H
#define BRAIDS_H 1
#ifdef HAVE_STDIO
#include <stdio.h>
#endif
/*
 * Constants, Macros, etc
 */
#define SETBRAID(B,i,L,U)             \
    B->b[i].l = L;                    \
    B->b[i].u = U;

/*
 * default braid data size is 8 bits. Change this typedef if it needs to be larger
 */
typedef ae_int8_t  ae_braiddata_t;
typedef ae_uint8_t ae_ubraiddata_t;

typedef unsigned   ae_cbvalue_t, *ae_pcbvalue_t;

typedef ae_cbvalue_t  ae_Tvalues_t;
typedef ae_pcbvalue_t ae_pTvalues_t;

typedef ae_pcbvalue_t * ae_2dMatrix_t;
//typedef unsigned        ae_ucbvalue_t, *ae_pucbvalue_t;

typedef struct _braidlist {
    ae_ubraiddata_t l;   // artin generator
    ae_braiddata_t u;    // plus-minus (inverse)
} ae_braidlist_t, *ae_pbraidlist_t;

typedef struct _braidlist_ll_ {
  struct _braidlist_ll_ * fwd;
  struct _braidlist_ll_ * bck;
  ae_ubraiddata_t t;
  ae_braiddata_t inverse;
} ae_braidlist_ll_t, *ae_pbraidlist_ll_t;

typedef struct _braid_generator {
    ae_int8_t value :5;
    ae_int8_t inv:1;
} ae_braidGenerator_t, *ae_pBraidGenerator_t;

typedef struct _list {
    unsigned int    len;
    ae_pbraidlist_t b;
} ae_list_t, *ae_plist_t;

typedef struct _llist_ {
  unsigned int len;
  ae_pbraidlist_ll_t head;
  ae_pbraidlist_ll_t tail;
} ae_llist_t, *ae_pllist_t;

typedef struct _braid_generator_list {
    unsigned int len;
    ae_pBraidGenerator_t g;
} ae_braidGeneratorList_t, * ae_pBraidGeneratorList_t;

typedef struct _listOfLists {
    unsigned int len;
    ae_plist_t  * l;

} ae_listOfLists_t, *ae_plistOfLists_t;

typedef struct _cbdata {
    unsigned int   n;         /* number of rows/columns */
    ae_2dMatrix_t  m;         /* 2d array of cb values */
    ae_pcbvalue_t  p;         /* 1d array of p values (i.e. the permutation) */
    int            k;         /* if nonzero, records the generator of Bn given to 
				 construct this cbdata */
    int            e;         /* if k is nonzero, this is the exponent of the generator 
				 k given to construct this cbdata */
} ae_cbdata_t, *ae_pcbdata_t;

typedef struct _cblist {
    unsigned int len;
    ae_pcbdata_t data;
} ae_cblist_t, *ae_pcblist_t;

typedef struct _value_list_ {
    unsigned int len;
    ae_pcbvalue_t data;
} ae_valueList, *ae_pValueList;
/*
 * prototypes
 */
void         braidInitRandom				();
ae_uint32_t  braidGetRandom				(unsigned int n);
ae_uint32_t  braidGetRandomInRange			(unsigned int _min, unsigned int _max);
void         braidCleanupRandom				(void);
ae_plist_t   braidAllocateBraidlist			(unsigned int l);
ae_plist_t   braidCopyBraidlist				(ae_plist_t src);
void         braidFreeBraidlist				(ae_plist_t * bl);
ae_plist_t   braidDropElements				(ae_plist_t bl, unsigned int lb, unsigned ub);
int          braidCompareBraidlists			(ae_plist_t bl1, ae_plist_t bl2);
int          braidLengthBraidlist                       (ae_plist_t bl);
ae_plist_t   braidFreelyReduceOnce			(ae_plist_t bl);
ae_plist_t   braidFreelyReduce				(ae_plist_t list);
ae_pBraidGeneratorList_t braidFreelyReduceEx		(ae_pBraidGeneratorList_t list);
ae_plist_t   braidFreelyReduceRandomArtinWord		(unsigned int n, unsigned int l);
ae_plist_t   braidArtinGenerator                        (int n, int i, int e);
ae_plist_t   braidGenOfFreeSubgpOfPureBraidGroup        (int i, int n);
ae_plist_t   braidBKLNormalFormOfBraid                  (ae_plist_t braid, int n); 
ae_plist_t   braidFastBKLNormalFormOfBraid              (ae_plist_t braid, int n);

#ifdef HAVE_STDIO
void                braidPrint				(FILE * fd, char * s, ae_plist_t bl) ;
void                braidPrintFlat			(FILE * fd, ae_plist_t bl) ;
void                braidPrintFlatFile			(const char * file, ae_plist_t bl) ;
void                braidPrintReallyFlat		(FILE * fd, ae_plist_t bl) ;
void                braidPrintByteForm			(FILE * fd, ae_plist_t bl) ;
ae_plist_t          braidLoadFlat                       (FILE * fd) ;
ae_plist_t          braidLoadFlatFile                   (const char * file);
void                braidPrintPerlForm			(FILE * fd, ae_plist_t bl) ;
#endif
ae_pcbvalue_t *     braidCBm				(unsigned int n, unsigned int t1, int plusminus, ae_pcbvalue_t tvalues);
ae_pcbvalue_t       braidCBp				(unsigned int n,unsigned int v);
void                braidCBpEx				(ae_pcbvalue_t s, unsigned int n,unsigned int v);
ae_pcblist_t        braidToCB				(unsigned int n, ae_plistOfLists_t bl);
ae_pcblist_t        braidToCBex				(unsigned int n, ae_plist_t bl,ae_pcbvalue_t tvalues);
ae_pcbvalue_t *     braidCBx				(unsigned int n, unsigned int k, int plusminus, ae_pTvalues_t tValues);
ae_pcblist_t        braidToCBConverter			(unsigned int n, ae_plist_t w, ae_pTvalues_t tValues);
ae_plistOfLists_t   ae_braidlistGenerator		(unsigned int n, unsigned int l);
#ifdef HAVE_STDIO
void                ae_printBraidlist			(FILE * fd, ae_plistOfLists_t p);
void                ae_printBraidlistFlat		(FILE * fd, ae_plistOfLists_t p);
void                ae_printBraidlistFlatFile		(const char* file, ae_plistOfLists_t p);
ae_plistOfLists_t   ae_loadBraidlistFlat		(FILE * fd);
ae_plistOfLists_t   ae_loadBraidlistFlatFile		(const char* file);
#endif
ae_pcbdata_t        braidAllocateCBData			(unsigned int n);
ae_pcbdata_t        braidCreateIdentityCBData           (int n);
void                braidFreeCBData			(ae_pcbdata_t cbdata);
void                braidFreeCBDataEx			(ae_pcbdata_t cbdata);
ae_pcbdata_t        braidCopyCBData			(ae_pcbdata_t src);
ae_plistOfLists_t   braidAllocateBraidwordList		(unsigned int len);
void                braidFreeBraidwordList		(ae_plistOfLists_t bwl);
ae_pcblist_t        braidAllocateCBList			(unsigned int len);
void                braidFreeCBList			(ae_pcblist_t cblist);
ae_plist_t          braidWordFromString			(ae_plistOfLists_t sbl, unsigned int len, unsigned char * string);
ae_plist_t          braidInverse			(ae_plist_t bl);
int                 braidAppendBraidlistToBraidlist	(ae_plist_t dbl, ae_plist_t sbl);
ae_plist_t          braidMultiplication			(ae_plist_t m, ae_plist_t n);
ae_plist_t          braidConjugate                      (ae_plist_t w, ae_plist_t x);

#ifdef HAVE_STDIO
void                ae_printCBData			(FILE * fd, char * label, ae_pcbdata_t cbdata);
void                ae_printCBDataFlat			(FILE * fd, ae_pcbdata_t cbdata);
void                ae_printCBDataReallyFlat		(FILE * fd, ae_pcbdata_t cbdata);
void                ae_printCBDataDebug			(FILE * fd, ae_pcbdata_t cbdata);
ae_pcbdata_t        ae_loadCBDataFlat			(FILE * fd, int index);
ae_pcbdata_t        ae_loadCBDataFlatFile		(const char* file, int index);
#endif
ae_2dMatrix_t       braidAllocate2DMatrix		(unsigned int n);
ae_2dMatrix_t       braidCopy2DMatrix                   (ae_2dMatrix_t m, int n);
ae_2dMatrix_t       braidIdentity2DMatrix               (int n);
ae_2dMatrix_t       braidRandom2DMatrix                 (unsigned int n, unsigned int q);
void                braidFree2DMatrix			(ae_2dMatrix_t m, int n);
int                 braidEqualityof2DMatrices		(ae_2dMatrix_t m1, ae_2dMatrix_t m2, int n); 
ae_2dMatrix_t       braidScale2DMatrix			(ae_2dMatrix_t m1, int c, int n); 
void                braidScaleAndReplace2DMatrix        (ae_2dMatrix_t m1, int c, int n); 
ae_2dMatrix_t       braidAdd2DMatrices			(ae_2dMatrix_t m1, ae_2dMatrix_t m2, int n); 
void                braidAddAndReplace2DMatrices        (ae_2dMatrix_t m1, ae_2dMatrix_t m2, int n); 
ae_2dMatrix_t       braidMultiply2DMatrices		(ae_2dMatrix_t m1, ae_2dMatrix_t m2, int n); 
int                 braidInvert2DMatrix		        (ae_2dMatrix_t m, ae_2dMatrix_t * minv, int n); 
void                braidMultiplyAndReplace2DMatrices   (ae_2dMatrix_t m1, ae_2dMatrix_t m2, int n); 
ae_2dMatrix_t       braidKthPowerOf2DMatrix		(ae_2dMatrix_t m1, int k, int n); 
ae_2dMatrix_t       braidRandomPolynomialIn2DMatrix	(ae_2dMatrix_t m1, int n); 
#ifdef HAVE_STDIO
void                ae_print2DMatrixFlat		(FILE * fd, ae_2dMatrix_t m, int n);
void                ae_printMatrixReallyFlat		(FILE * fd, ae_2dMatrix_t m, int n);
ae_2dMatrix_t       ae_loadSeedMatrixFlat		(FILE * fd);
ae_2dMatrix_t       ae_loadSeedMatrixFlatFile		(const char* file);
#endif
ae_pcbdata_t        braidIdentityMatrix			(unsigned int n);
void                braidFreeIdentityMatrix		(ae_pcbdata_t im);
void                braidAppendToBraidlist		(ae_plist_t bl, ae_pbraidlist_t b);
ae_pTvalues_t       braidAllocateTvalues		(unsigned int n);
ae_pTvalues_t       braidCopyTvalues                    (ae_pTvalues_t orig, unsigned int n);
ae_pTvalues_t       braidAllocateRandomTvalues		(unsigned int n, unsigned int q);
void                braidFreeTvalues			(ae_pTvalues_t ptr);
#ifdef HAVE_STDIO
int                 ae_saveTvalues			(FILE * fd, int index, ae_pTvalues_t tvalues);
int                 ae_saveTvaluesFile                  (const char * filename, int index, ae_pTvalues_t tvalues);
ae_pTvalues_t       ae_loadTvalues			(FILE * fd, int index);
ae_pTvalues_t       ae_loadTvaluesFile			(const char* file, int index);
#endif
ae_plist_t          braidGetSubBraidlist		(ae_plist_t bl, unsigned int start, unsigned int end);
void                braidReplaceSubBraidlist		(ae_plist_t bl, unsigned int start, unsigned int end, ae_plist_t new);
/*
 * linked list functions
 */
ae_pllist_t         braidBraidlistToLinkedList		(ae_plist_t bl);
ae_plist_t          braidLinkedListToBraidlist		(ae_pllist_t bll);
void                braidFreeLinkedList			(ae_pllist_t *ll);
int                 braidDivideLinkedList		(ae_pllist_t *ll, ae_pllist_t *head, ae_pllist_t *tail);
int                 braidJoinLinkedLists		(ae_pllist_t *head, ae_pllist_t *tail, ae_pllist_t *result); 
unsigned int        braidLength				(ae_pllist_t bll);
void                braidGetSubList			(ae_pllist_t sub, ae_pllist_t src, unsigned int start, unsigned int end);
#ifdef HAVE_STDIO
void                braidPrintLL			(FILE * fd, char * title, ae_pllist_t bl);
void                braidAnalyzeLL			(FILE * fd, char * title, ae_pllist_t bl);
#endif
#endif /* BRAIDS_H */
