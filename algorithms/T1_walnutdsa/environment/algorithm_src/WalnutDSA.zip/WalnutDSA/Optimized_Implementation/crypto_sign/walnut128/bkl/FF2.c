/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#include <stdio.h>
#include "FF2.h"

/* Definition of the FF2 interface; it's a finite field with local data */
typedef struct SrfFF2_ {
  SrfFiniteField  ff;
  // my local parameters here:
  unsigned pol;
  int poldegree;
} SrfFF2;

static inline int FF2checkbit(FF2elem a, int position)
{
  return (a & (1<<(position)));
}


static inline void FF2rightshift(FF2elem *b)
{
  (*b) >>= 1;
}

static inline int FF2elemiszero(FF2elem a)
{
  return (a==0);
}

static inline int FF2degree(FF2elem a)
{
  int i=-1;
  unsigned tx = a;
  if (tx == 0)
    return(0);
  while (tx) {
    tx >>= 1;
    i++;
  }
  return i;
}

static inline int FF2elemisone(FF2elem a)
{
  return (FF2degree(a) == 0 && !FF2elemiszero(a));
}

static inline int FF2checkifreduced(FF2elem a, int poldegree)
{
  int i=poldegree;
  unsigned tx = a;
  while (i--) {
    tx >>= 1;
  }
  if (tx) 
    return 0;
  else
    return 1;
}

static inline FF2elem	FF2neg(FF2elem a)
{
  return a;
}

static inline FF2elem FF2add(FF2elem a, FF2elem b) 
{
  return (a^b);
}

static inline FF2elem FF2multbyx(FF2elem a, unsigned pol, int poldegree)
{
  FF2elem ans = (a<<1);
  if (FF2checkbit(ans,poldegree)) {
    ans ^= pol;
  }
  return (ans);
}

static inline FF2elem FF2multbyxtok(FF2elem a, int k, unsigned pol, int poldegree)
{
  FF2elem ans = a;
  while (k--) {
    ans <<= 1;
    if (FF2checkbit(ans,poldegree)) {
      ans ^= pol;
    }
  }
  return (ans);
}

static inline FF2elem FF2xtok(int k, unsigned pol, int poldegree)
{
  return (FF2multbyxtok(1, k, pol, poldegree));
}

static inline FF2elem FF2reduce(FF2elem x, unsigned pol, int poldegree)
{
  FF2elem ans = 0;
  if (x==0)
    return(0);
  int i, d = FF2degree(x);
  for (i=0; i<=d; i++) {
    if (x & 1) {
      ans = FF2add(ans, FF2xtok(i, pol, poldegree));
    }
    x >>= 1;
  }
  return (ans);
}


static inline FF2elem FF2mult(FF2elem a, FF2elem b, unsigned pol, int poldegree)
{
  FF2elem tb, ta, ans;
  ta = a, tb = b;
  ans=0;
  while (!FF2elemiszero(tb)) {
    //    fprintf(stderr, "ta is %x, tb is %x, ans is %x\n", ta, tb,ans);
    if (tb & 1) {
      ans = FF2add(FF2reduce(ta, pol, poldegree),ans);
    }
    ta <<=1;
    tb >>=1;
  }
  return ans;
}

/* Construct multiplicative inverses using the extended Euclidean algorithm */

static inline FF2elem FF2inverse(FF2elem a, unsigned pol)
{
  FF2elem u,v,g1,g2;
  int j;

  if (FF2elemiszero(a)) 
    return 0; // can't be the inverse of anything

  u = a, v = pol;
  g1 = 1, g2 = 0;
  while (!FF2elemisone(u)) {
    //    fprintf(stderr, "test: u==1 = %d\n", FF2elemisone(u));
    j=FF2degree(u)-FF2degree(v);
    //    fprintf(stderr,"before swap: u=%02x, v=%02x, g1=%02x, g2=%02x, j=%d\n", u,v,g1,g2,j);
    if (j<0) {
      FF2elem t;
      t=u, u=v, v=t;
      t=g1, g1=g2, g2=t;
      j=-j;
    }
    //    fprintf(stderr,"after swap : u=%02x, v=%02x, g1=%02x, g2=%02x, j=%d\n", u,v,g1,g2,j);
    //    fprintf(stderr,"   x^%d * v = %02x\n", j,v<<j);
    u ^= (v << j);
    g1 ^= (g2 << j);
    //    fprintf(stderr,"bottom     : u=%02x, v=%02x, g1=%02x, g2=%02x, j=%d\n", u,v,g1,g2,FF2degree(u)-FF2degree(v));
  }
  return (g1);
}


static inline FF2elem FF2neginverse(FF2elem a, unsigned pol)
{
  return (FF2inverse(a, pol));
}

static inline FF2elem FF2divide(FF2elem a, FF2elem b, unsigned pol, int poldegree)
{
  if (!FF2elemiszero(b)) {
    return FF2mult(a,FF2inverse(b, pol),pol,poldegree);
  }
}

/****************************************************************/
/* "Public" APIs: */

static ffelem ff2neg(const SrfFiniteField* ff, ffelem a)
{
  return (ffelem) FF2neg(a);
}

static ffelem ff2inverse(const SrfFiniteField* ff, ffelem a)
{
  const SrfFF2* ff2 = (const SrfFF2*) ff;
  return (ffelem) FF2inverse(a, ff2->pol);
}

static ffelem ff2neginverse(const SrfFiniteField* ff, ffelem a)
{
  const SrfFF2* ff2 = (const SrfFF2*) ff;
  return (ffelem) FF2neginverse(a,ff2->pol);
}

static ffelem ff2add(const SrfFiniteField* ff, ffelem a, ffelem b)
{
  return (ffelem) FF2add(a, b);
}

static ffelem ff2mult(const SrfFiniteField* ff, ffelem a, ffelem b)
{
  const SrfFF2* ff2 = (const SrfFF2*) ff;
  return (ffelem) FF2mult(a, b, ff2->pol, ff2->poldegree);
}

static ffelem ff2reduce(const SrfFiniteField* ff, ffelem a)
{
  const SrfFF2* ff2 = (const SrfFF2*) ff;
  return (ffelem) FF2reduce(a,ff2->pol,ff2->poldegree);
}

/****************************************************************/

// parameters are order of finite field, polynomial, and polynomial degree
#define DEFINE_FF(num,pol,poldegree)    \
  { { num, ff2neg, ff2inverse, ff2neginverse, ff2add, ff2mult, ff2reduce },  pol, poldegree }

static SrfFF2 ffFields[] = {
#ifdef ENABLE_FIELD_4
    DEFINE_FF(4,0x7,2),				// x^2+x+1
#endif
#ifdef ENABLE_FIELD_8
    DEFINE_FF(8,0xb,3),				// x^3+x+1
#endif
#ifdef ENABLE_FIELD_16
    DEFINE_FF(16,0x13,4),			// x^4 + x + 1
#endif
#ifdef ENABLE_FIELD_32
    DEFINE_FF(32,0x25,5),			// x^5 + x^2 + 1
#endif
#ifdef ENABLE_FIELD_64
    DEFINE_FF(64,0x43,6),			// x^6 + x + 1
#endif
#ifdef ENABLE_FIELD_128
    DEFINE_FF(128,0x83,7),			// x^7 + x + 1
#endif
#ifdef ENABLE_FIELD_256
    DEFINE_FF(256,0x11b,8),			// x^8 + x^4 + x^3 + x + 1
#endif
#ifdef ENABLE_FIELD_512
    DEFINE_FF(512,0x203,9),			// x^9 + x + 1
#endif
#ifdef ENABLE_FIELD_1024
    DEFINE_FF(1024,0x409,10),			// x^10 + x^3 + 1
#endif
#ifdef ENABLE_FIELD_2048
    DEFINE_FF(2048,0x805,11),			// x^11 + x^2 + 1
#endif
#ifdef ENABLE_FIELD_4096
    DEFINE_FF(4096,0x1009,12),			// x^12 + x^3 + 1
#endif
#ifdef ENABLE_FIELD_8192
    DEFINE_FF(8192,0x201b,13),			// x^13 + x^4 + x^3 + x + 1
#endif
#ifdef ENABLE_FIELD_16384
    DEFINE_FF(16384,0x4021,14),			// x^14 + x^5 + 1
#endif
#ifdef ENABLE_FIELD_32768
    DEFINE_FF(32768,0x8003,15),			// x^15 + x + 1
#endif
#ifdef ENABLE_FIELD_65536 
    DEFINE_FF(65536,0x1002b,16),		// x^16 + x^5 + x^3 + x + 1
#endif
#ifdef ENABLE_FIELD_4194304
    DEFINE_FF(4194304,0x400003,22),		// x^22+x+1
#endif
#ifdef ENABLE_FIELD_2147483648
    DEFINE_FF(2147483648,0x80000009,31),	// x^31 + x^3 + 1
#endif
};
#define NUM_FIELDS (sizeof(ffFields)/sizeof(*ffFields))

extern const SrfFiniteField* ff2GetFF(ffelem primepower)
{
  int i;
  for (i = 0; i < NUM_FIELDS; i++) {
    if (ffFields[i].ff.primepower == primepower)
      return &ffFields[i].ff;
  }
  return NULL;
}

