/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * y-gen.h - Y-Generator definitions
 */
#ifndef Y_GEN_H
#define Y_GEN_H 1

/*
 * Constants, Macros, etc
 */

/*
 * Data structures/typedefs
 */
typedef ae_IntList_t ae_Partition_t;
typedef ae_pIntList_t ae_pPartition_t;

typedef ae_list_t ae_YWord_t;
typedef ae_plist_t ae_pYWord_t;

typedef ae_listOfLists_t ae_YWordList_t;
typedef ae_plistOfLists_t ae_pYWordList_t;

#define ygenAllocatePartition  bandAllocateIntList
#define ygenFreePartition      bandFreeIntList

/*
 * prototypes
 */
ae_pPartition_t	ygenRandomPartition	(int n, int min, int max);
ae_plist_t	ygenGenerators		(ae_pPartition_t p, int k);
ae_pYWord_t	ygenFreelyReduceY	(ae_pYWord_t w);
ae_pYWord_t	ygenArtinToYGenerators	(ae_pPartition_t p, int k);
ae_pYWord_t	ygenArtinWordToYWord	(ae_plist_t w, ae_pPartition_t p);
ae_plist_t	ygenYWordToArtinWord	(ae_pYWord_t w, ae_pPartition_t p);
ae_plistOfLists_t ygenTableOfArtinRelations (int n);
ae_pYWordList_t ygenTableOfYRelations	(ae_pPartition_t p);
ae_pYWordList_t	ygenExtraRelations	(ae_pPartition_t p);
ae_pYWordList_t	ygenAugmentedTableOfYRelations	(ae_pPartition_t p);
ae_pYWordList_t	ygenAugmentedTableOfYRelations2	(ae_pPartition_t p);

int		ygenFindSubWord(unsigned char* w, ae_pYWord_t sw);
ae_pYWord_t	ygenRewriteSubWord(unsigned char* w, ae_pYWord_t sw);
int		ygenGlobalFindSubWord(unsigned char* rels, ae_pYWord_t sw, int *index);
ae_pYWord_t	ygenRandomYWordRewriteOnce(ae_pYWord_t w);

ae_pYWord_t	ygenRandomYWordRewrite	(ae_pYWord_t w, int iterations);
ae_pYWord_t	ygenRandomYWordRewriteOnceV2x (ae_pYWord_t w, ae_pPartition_t p, ae_pYWordList_t rels);
ae_pYWord_t	ygenRandomYWordRewriteV2x     (ae_pYWord_t w, ae_pPartition_t p, ae_pYWordList_t rels, int iterations);
void		ygenSortRelations	(ae_pYWordList_t r);

ae_pYWord_t	ygenMoveYiLeftOnce	(ae_pYWord_t wl, int *j, ae_pPartition_t p);
ae_pYWord_t	ygenMoveY1LeftOnce	(ae_pYWord_t wl, int *j, ae_pPartition_t p);
ae_pYWord_t	ygenMoveAllY1Left	(ae_pYWord_t wl, ae_pPartition_t p);
ae_pYWord_t	ygenMoveAllYiLeft	(ae_pYWord_t wl, int yi, ae_pPartition_t p);

ae_pYWord_t	ygenMoveYiLeftOnceV2x	(ae_pYWord_t wl, int *j, ae_pPartition_t p);
ae_pYWord_t	ygenMoveAllYiLeftV2x	(ae_pYWord_t wl, int max_yi, ae_pPartition_t p);
ae_pYWord_t	ygenPartialMoveYi	(ae_pYWord_t wl, int max_yi, ae_pPartition_t p);


#endif /* Y_GEN_H */
