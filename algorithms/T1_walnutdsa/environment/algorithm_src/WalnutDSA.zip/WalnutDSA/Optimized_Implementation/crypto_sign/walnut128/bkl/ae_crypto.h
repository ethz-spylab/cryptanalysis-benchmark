/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#ifndef AE_DH_H
#define AE_DH_H

#include <stdint.h>
#include "aelib.h"

typedef struct walnut_verify_ctx {
	union {
		unsigned char ans2[WALNUT_BRAID][WALNUT_BRAID];
		unsigned char generators[(4 * 22) / 2];
	} d;
	unsigned char encode[WALNUT_BRAID][WALNUT_BRAID];
	unsigned char ans1[WALNUT_BRAID][WALNUT_BRAID];
	unsigned char ansprime[WALNUT_BRAID][WALNUT_BRAID];

	unsigned char p[WALNUT_BRAID];
	const unsigned char *mp[WALNUT_BRAID];
	const unsigned char *imp[WALNUT_BRAID];
	size_t count;
	unsigned char idx;
} walnut_verify_ctx;



extern int walnut_verify_init(const void *aekey, const void *dgst,
	walnut_verify_ctx *c);
extern int walnut_verify_update(walnut_verify_ctx *c, const void *sig,
                            size_t len);
extern int walnut_verify_final(walnut_verify_ctx *c);

#endif
