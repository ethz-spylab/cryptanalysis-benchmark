/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#ifndef CONSTANTS_H
#define CONSTANTS_H

#define WALNUT_SL 128
#define WALNUT_VERSION 0x01
#define MATRIX_SIZE 64
#define PERMUTATION_BIT_PACK 3

#define PACKED_TVALUES_LENGTH 5
#define PACKED_MATRIX_LENGTH 36
#define PACKED_PERMUTATION_LENGTH 3

#define WALNUT_BRAID 8
#define WALNUT_FIELD 32
#define WALNUT_BRAID_BIT 3
#define WALNUT_FIELD_BIT 5
#define WALNUT_FIELD_MATRIX_REMAINDER WALNUT_BRAID - WALNUT_FIELD_BIT

#define CONSTANT_L 15

enum {
	WALNUT_DGST_SIZ = 32,
	WALNUT_PUBLIC_KEY_BYTES = 3 + (WALNUT_FIELD_BIT * WALNUT_BRAID / 8) +
	(WALNUT_FIELD_BIT * WALNUT_BRAID * WALNUT_BRAID / 8) +
	(WALNUT_BRAID_BIT * WALNUT_BRAID / 8)
};

#endif