/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#include "api.h"
#include "obfuscate.h"
#include "ae_dsa.h"
#include "ae_crypto.h"

#ifndef OBFUSCATE_BKL
#include "y-gen.h"
#endif

ae_plist_t obfuscateBraid(ae_plist_t braidword)
{
#ifdef OBFUSCATE_BKL
	ae_plist_t bklanswer = NULL, reducedAnswer = NULL;
	
	bklanswer = braidFastBKLNormalFormOfBraid(braidword, WALNUT_BRAID);
	
#ifdef KAT_INTERMEDIATES
  printplist(bklanswer, "Signature after BKL pre-dehornoy");
#endif

	reducedAnswer = ae_FastDehornoyReduction(bklanswer, WALNUT_BRAID);

#ifdef KAT_INTERMEDIATES
  printplist(reducedAnswer, "Signature after dehornoy");
#endif
	
	braidFreeBraidlist(&bklanswer);
#else
	ae_pYWord_t yinput;
	ae_pYWord_t result;
	ae_pYWordList_t relations;
	ae_pPartition_t pp;
	ae_plist_t  obscuredbraid, reducedAnswer;
	int j, i = 0;

	pp = ygenAllocatePartition(2);
	pp->items[0] = 4;
	pp->items[1] = 3;

	yinput = ygenArtinWordToYWord(braidword, pp);

	result = ygenRandomYWordRewrite(yinput, 3);

	obscuredbraid = ygenYWordToArtinWord(result, pp);

#ifdef KAT_INTERMEDIATES
  printplist(obscuredbraid, "Signature after stochastic rewriting");
#endif

#ifdef OBFUSCATE_YREWRITE_WO_DEHORNOY
	reducedAnswer = obscuredbraid;
#else
	reducedAnswer = ae_FastDehornoyReduction(obscuredbraid, WALNUT_BRAID);

#ifdef KAT_INTERMEDIATES
  printplist(reducedAnswer, "Signature after dehornoy");
#endif

	braidFreeBraidlist(&obscuredbraid);
#endif
	braidFreeBraidlist(&result);
#endif


	return reducedAnswer;
	
}