/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#ifndef FFPRIME_H
#define FFPRIME_H

#include "finitefields.h"

#define ENABLE_FIELD_13
#define ENABLE_FIELD_2147483647

typedef unsigned FFprimeelem;

const SrfFiniteField* ffprimeGetFF(ffelem);

#define CHECK_BIT(var,pos) ((var) & (1<<(pos)))

#endif /* FFPRIME_H */

