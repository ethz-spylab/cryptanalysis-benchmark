/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * y-gen.c - Y-generator creation/conversion/manipulation
 */
#include "aelib.h"
#include <stdlib.h>  // for qsort()
#include "y-gen.h"
#include <stdint.h>

static ae_plist_t ygen_plist = NULL;

typedef struct ae_ygen ae_ygen_t, *ae_pygen_t;
typedef struct ae_ylist ae_ylist_t, *ae_pylist_t;

const int8_t flatywordslookup[16][16] = {
		{ 0, -1, -1, 1, -1, -1, -1, -1, -1, 2, 3, 4, -1, -1, -1, -1, },
		{ 5, 6, -1, 7, -1, -1, -1, -1, 8, -1, 9, 10, -1, -1, -1, -1, },
		{ -1, 11, 12, 13, -1, -1, -1, -1, 14, 15, -1, 16, -1, -1, -1, -1, },
		{ 17, 18, 19, -1, 20, 21, 22, -1, 23, 24, 25, -1, -1, -1, 26, -1, },
		{ -1, -1, -1, -1, 27, -1, 28, -1, -1, -1, -1, -1, -1, 29, 30, -1, },
		{ -1, -1, -1, -1, 31, 32, 33, -1, -1, -1, -1, -1, 34, -1, 35, -1, },
		{ 36, 37, 38, 39, 40, 41, -1, -1, -1, -1, -1, 42, 43, 44, -1, -1, },
		{ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, },
		{ -1, 45, 46, 47, -1, 48, 49, -1, 50, 51, -1, 52, -1, -1, 53, -1, },
		{ 54, -1, 55, 56, 57, 58, 59, -1, -1, 60, 61, 62, -1, -1, 63, -1, },
		{ 64, 65, -1, 66, 67, 68, 69, -1, -1, -1, 70, 71, -1, -1, 72, -1, },
		{ 73, 74, 75, -1, 76, 77, 78, -1, 79, 80, 81, -1, -1, -1, 82, -1, },
		{ 83, 84, 85, 86, -1, 87, 88, -1, -1, -1, -1, 89, 90, 91, 92, -1, },
		{ 93, 94, 95, 96, 97, -1, 98, -1, -1, -1, -1, 99, -1, 100, 101, -1, },
		{ 102, 103, 104, 105, 106, 107, -1, -1, -1, -1, -1, 108, 109, 110, -1, -1, },
		{ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, },
};

const uint8_t flatywords[111][15] = {
		{ 3, 0x02, 0x01, 0x01, 0x01, 0x04, 0x01, },
		{ 3, 0x02, 0xff, 0x01, 0x01, 0x01, 0x01, },
		{ 4, 0x04, 0x01, 0x01, 0x01, 0x02, 0xff, 0x04, 0xff, },
		{ 6, 0x02, 0x01, 0x03, 0xff, 0x01, 0x01, 0x03, 0xff, 0x02, 0x01, 0x01, 0xff, },
		{ 3, 0x01, 0xff, 0x02, 0x01, 0x01, 0x01, },
		{ 3, 0x01, 0x01, 0x01, 0x01, 0x04, 0xff, },
		{ 3, 0x03, 0x01, 0x02, 0x01, 0x04, 0x01, },
		{ 3, 0x03, 0xff, 0x02, 0x01, 0x02, 0x01, },
		{ 4, 0x04, 0xff, 0x02, 0x01, 0x01, 0xff, 0x04, 0x01, },
		{ 4, 0x04, 0x01, 0x02, 0x01, 0x03, 0xff, 0x04, 0xff, },
		{ 3, 0x02, 0xff, 0x03, 0x01, 0x02, 0x01, },
		{ 3, 0x02, 0x01, 0x02, 0x01, 0x04, 0xff, },
		{ 3, 0x04, 0x01, 0x03, 0x01, 0x04, 0x01, },
		{ 3, 0x04, 0xff, 0x03, 0x01, 0x03, 0x01, },
		{ 6, 0x02, 0x01, 0x01, 0xff, 0x03, 0x01, 0x01, 0xff, 0x02, 0x01, 0x03, 0xff, },
		{ 4, 0x04, 0xff, 0x03, 0x01, 0x02, 0xff, 0x04, 0x01, },
		{ 3, 0x03, 0xff, 0x04, 0x01, 0x03, 0x01, },
		{ 4, 0x01, 0x01, 0x02, 0xff, 0x04, 0x01, 0x02, 0x01, },
		{ 4, 0x02, 0x01, 0x01, 0xff, 0x04, 0x01, 0x01, 0x01, },
		{ 3, 0x03, 0x01, 0x03, 0x01, 0x04, 0xff, },
		{ 7, 0x05, 0x01, 0x06, 0xff, 0x04, 0x01, 0x05, 0x01, 0x06, 0xff, 0x04, 0xff, 0x06, 0x01, },
		{ 4, 0x06, 0x01, 0x07, 0xff, 0x04, 0x01, 0x07, 0x01, },
		{ 2, 0x07, 0x01, 0x04, 0x01, },
		{ 3, 0x01, 0xff, 0x02, 0xff, 0x01, 0x01, },
		{ 3, 0x02, 0xff, 0x03, 0xff, 0x02, 0x01, },
		{ 3, 0x03, 0xff, 0x04, 0xff, 0x03, 0x01, },
		{ 2, 0x07, 0xff, 0x04, 0x01, },
		{ 3, 0x06, 0x01, 0x05, 0x01, 0x07, 0x01, },
		{ 3, 0x06, 0xff, 0x05, 0x01, 0x05, 0x01, },
		{ 4, 0x07, 0x01, 0x05, 0x01, 0x06, 0xff, 0x07, 0xff, },
		{ 3, 0x05, 0xff, 0x06, 0x01, 0x05, 0x01, },
		{ 3, 0x05, 0x01, 0x05, 0x01, 0x07, 0xff, },
		{ 3, 0x07, 0x01, 0x06, 0x01, 0x07, 0x01, },
		{ 3, 0x07, 0xff, 0x06, 0x01, 0x06, 0x01, },
		{ 4, 0x07, 0xff, 0x06, 0x01, 0x05, 0xff, 0x07, 0x01, },
		{ 3, 0x06, 0xff, 0x07, 0x01, 0x06, 0x01, },
		{ 4, 0x01, 0x01, 0x02, 0xff, 0x07, 0x01, 0x02, 0x01, },
		{ 4, 0x02, 0x01, 0x01, 0xff, 0x07, 0x01, 0x01, 0x01, },
		{ 4, 0x03, 0x01, 0x02, 0xff, 0x07, 0x01, 0x02, 0x01, },
		{ 2, 0x04, 0x01, 0x07, 0x01, },
		{ 4, 0x05, 0x01, 0x06, 0xff, 0x07, 0x01, 0x06, 0x01, },
		{ 3, 0x06, 0x01, 0x06, 0x01, 0x07, 0xff, },
		{ 2, 0x04, 0xff, 0x07, 0x01, },
		{ 3, 0x05, 0xff, 0x06, 0xff, 0x05, 0x01, },
		{ 3, 0x06, 0xff, 0x07, 0xff, 0x06, 0x01, },
		{ 3, 0x01, 0x01, 0x04, 0xff, 0x01, 0xff, },
		{ 6, 0x03, 0xff, 0x02, 0x01, 0x01, 0xff, 0x03, 0x01, 0x01, 0xff, 0x02, 0x01, },
		{ 6, 0x02, 0xff, 0x04, 0x01, 0x03, 0xff, 0x02, 0x01, 0x01, 0xff, 0x03, 0x01, },
		{ 6, 0x02, 0xff, 0x06, 0x01, 0x05, 0xff, 0x02, 0x01, 0x01, 0xff, 0x05, 0x01, },
		{ 6, 0x02, 0xff, 0x07, 0x01, 0x06, 0xff, 0x02, 0x01, 0x01, 0xff, 0x06, 0x01, },
		{ 3, 0x04, 0xff, 0x01, 0xff, 0x02, 0xff, },
		{ 3, 0x04, 0x01, 0x01, 0xff, 0x01, 0xff, },
		{ 4, 0x02, 0xff, 0x04, 0xff, 0x02, 0x01, 0x01, 0xff, },
		{ 4, 0x02, 0xff, 0x07, 0xff, 0x02, 0x01, 0x01, 0xff, },
		{ 3, 0x01, 0x01, 0x04, 0x01, 0x01, 0xff, },
		{ 3, 0x02, 0x01, 0x04, 0xff, 0x02, 0xff, },
		{ 4, 0x01, 0xff, 0x04, 0x01, 0x01, 0x01, 0x02, 0xff, },
		{ 6, 0x01, 0xff, 0x05, 0x01, 0x06, 0xff, 0x01, 0x01, 0x02, 0xff, 0x06, 0x01, },
		{ 6, 0x03, 0xff, 0x06, 0x01, 0x05, 0xff, 0x03, 0x01, 0x02, 0xff, 0x05, 0x01, },
		{ 4, 0x01, 0xff, 0x07, 0x01, 0x01, 0x01, 0x02, 0xff, },
		{ 3, 0x04, 0xff, 0x02, 0xff, 0x03, 0xff, },
		{ 3, 0x04, 0x01, 0x02, 0xff, 0x02, 0xff, },
		{ 4, 0x03, 0xff, 0x04, 0xff, 0x03, 0x01, 0x02, 0xff, },
		{ 4, 0x03, 0xff, 0x07, 0xff, 0x03, 0x01, 0x02, 0xff, },
		{ 6, 0x01, 0xff, 0x02, 0x01, 0x03, 0xff, 0x01, 0x01, 0x03, 0xff, 0x02, 0x01, },
		{ 3, 0x02, 0x01, 0x04, 0x01, 0x02, 0xff, },
		{ 4, 0x02, 0xff, 0x04, 0x01, 0x02, 0x01, 0x03, 0xff, },
		{ 6, 0x02, 0xff, 0x05, 0x01, 0x06, 0xff, 0x02, 0x01, 0x03, 0xff, 0x06, 0x01, },
		{ 6, 0x04, 0xff, 0x06, 0x01, 0x05, 0xff, 0x04, 0x01, 0x03, 0xff, 0x05, 0x01, },
		{ 4, 0x02, 0xff, 0x07, 0x01, 0x02, 0x01, 0x03, 0xff, },
		{ 3, 0x04, 0xff, 0x03, 0xff, 0x04, 0xff, },
		{ 3, 0x04, 0x01, 0x03, 0xff, 0x03, 0xff, },
		{ 4, 0x04, 0xff, 0x07, 0xff, 0x04, 0x01, 0x03, 0xff, },
		{ 4, 0x01, 0x01, 0x02, 0xff, 0x04, 0xff, 0x02, 0x01, },
		{ 4, 0x02, 0x01, 0x03, 0xff, 0x04, 0xff, 0x03, 0x01, },
		{ 3, 0x03, 0x01, 0x04, 0x01, 0x03, 0xff, },
		{ 6, 0x03, 0xff, 0x05, 0x01, 0x06, 0xff, 0x03, 0x01, 0x04, 0xff, 0x06, 0x01, },
		{ 6, 0x03, 0xff, 0x06, 0x01, 0x07, 0xff, 0x03, 0x01, 0x04, 0xff, 0x07, 0x01, },
		{ 4, 0x07, 0x01, 0x06, 0xff, 0x04, 0xff, 0x06, 0x01, },
		{ 3, 0x01, 0xff, 0x01, 0xff, 0x02, 0x01, },
		{ 3, 0x02, 0xff, 0x02, 0xff, 0x03, 0x01, },
		{ 3, 0x03, 0xff, 0x03, 0xff, 0x04, 0x01, },
		{ 2, 0x07, 0xff, 0x04, 0xff, },
		{ 6, 0x06, 0xff, 0x01, 0x01, 0x02, 0xff, 0x06, 0x01, 0x05, 0xff, 0x02, 0x01, },
		{ 6, 0x06, 0xff, 0x02, 0x01, 0x03, 0xff, 0x06, 0x01, 0x05, 0xff, 0x03, 0x01, },
		{ 6, 0x06, 0xff, 0x03, 0x01, 0x04, 0xff, 0x06, 0x01, 0x05, 0xff, 0x04, 0x01, },
		{ 6, 0x06, 0xff, 0x04, 0x01, 0x03, 0xff, 0x06, 0x01, 0x05, 0xff, 0x03, 0x01, },
		{ 3, 0x05, 0x01, 0x07, 0xff, 0x05, 0xff, },
		{ 6, 0x07, 0xff, 0x06, 0x01, 0x05, 0xff, 0x07, 0x01, 0x05, 0xff, 0x06, 0x01, },
		{ 7, 0x06, 0xff, 0x04, 0xff, 0x06, 0x01, 0x05, 0xff, 0x04, 0xff, 0x05, 0x01, 0x06, 0xff, },
		{ 3, 0x07, 0xff, 0x05, 0xff, 0x06, 0xff, },
		{ 3, 0x07, 0x01, 0x05, 0xff, 0x05, 0xff, },
		{ 4, 0x06, 0xff, 0x07, 0xff, 0x06, 0x01, 0x05, 0xff, },
		{ 6, 0x07, 0xff, 0x01, 0x01, 0x02, 0xff, 0x07, 0x01, 0x06, 0xff, 0x02, 0x01, },
		{ 6, 0x05, 0xff, 0x02, 0x01, 0x01, 0xff, 0x05, 0x01, 0x06, 0xff, 0x01, 0x01, },
		{ 6, 0x05, 0xff, 0x03, 0x01, 0x02, 0xff, 0x05, 0x01, 0x06, 0xff, 0x02, 0x01, },
		{ 4, 0x07, 0xff, 0x04, 0x01, 0x07, 0x01, 0x06, 0xff, },
		{ 3, 0x05, 0x01, 0x07, 0x01, 0x05, 0xff, },
		{ 3, 0x06, 0x01, 0x07, 0xff, 0x06, 0xff, },
		{ 4, 0x07, 0xff, 0x04, 0xff, 0x07, 0x01, 0x06, 0xff, },
		{ 3, 0x07, 0xff, 0x06, 0xff, 0x07, 0xff, },
		{ 3, 0x07, 0x01, 0x06, 0xff, 0x06, 0xff, },
		{ 4, 0x01, 0x01, 0x02, 0xff, 0x07, 0xff, 0x02, 0x01, },
		{ 4, 0x02, 0x01, 0x03, 0xff, 0x07, 0xff, 0x03, 0x01, },
		{ 4, 0x03, 0x01, 0x04, 0xff, 0x07, 0xff, 0x04, 0x01, },
		{ 2, 0x04, 0x01, 0x07, 0xff, },
		{ 4, 0x05, 0x01, 0x06, 0xff, 0x07, 0xff, 0x06, 0x01, },
		{ 3, 0x06, 0x01, 0x07, 0x01, 0x06, 0xff, },
		{ 2, 0x04, 0xff, 0x07, 0xff, },
		{ 3, 0x05, 0xff, 0x05, 0xff, 0x06, 0x01, },
		{ 3, 0x06, 0xff, 0x06, 0xff, 0x07, 0x01, },
};

struct ae_ygen {
  ae_pygen_t	next;
  ae_pygen_t	prev;
  ae_pylist_t	top;
  ae_uint8_t	gen;
  ae_short16_t	exp;
};

struct ae_ylist {
  unsigned long long	len;
  ae_pygen_t	head;
  ae_pygen_t	tail;
  ae_pPartition_t partition;
};

static void list_insert_after(ae_pygen_t listelm, ae_pygen_t elm) {
  if ((elm->next = listelm->next) == NULL) {
    listelm->top->tail = elm;
  } else {
    listelm->next->prev = elm;
  }
  listelm->next = elm;
  elm->prev = listelm;
  elm->top = listelm->top;
  elm->top->len++;
}

static void list_insert_before(ae_pygen_t listelm, ae_pygen_t elm) {
  if ((elm->prev = listelm->prev) == NULL) {
    listelm->top->head = elm;
  } else {
    elm->prev->next = elm;
  }
  elm->next = listelm;
  listelm->prev = elm;
  elm->top = listelm->top;
  elm->top->len++;
}

static void list_insert_head(ae_pylist_t list, ae_pygen_t elm) {
  if ((elm->next = list->head) == NULL) {
    list->tail = elm;
  } else {
    list->head->prev = elm;
  }
  elm->prev = NULL;
  list->head = elm;
  elm->top = list;
  elm->top->len++;
}

static ae_pygen_t list_new_elm(int g, int e) {
  ae_pygen_t elm = ae_calloc(1, sizeof(ae_ygen_t));
  elm->gen = g;
  elm->exp = e;
  return elm;
}

static size_t list_length(ae_pylist_t l) {
  size_t i = 0;
  ae_pygen_t elm;

  for (elm = l->head; elm; elm = elm->next)
    i++;

  return i;
}

static size_t list_index_of(ae_pygen_t e) {
  size_t i = 0;
  ae_pygen_t elm;

  if (!e)
    return 0;

  for (elm = e->top->head; elm && elm != e; elm = elm->next)
    i++;

  return i;
}


static int
ygenRandomPartitionLoop(ae_pPartition_t p, int i, int n, int min, int max)
{
  int c, res;

  if (n == 0)
    return i;

  if (n < min)
    return -1;

  do {
    c = braidGetRandom(max-min+1)+min;
    res = ygenRandomPartitionLoop(p, i+1, n-c, min, max);
  } while((i == 0 || n > (max*min)) && res < 0);

  if (res >= 0)
    p->items[i] = c;

  return res;
}

/*
* ygenRandomPartition(n,min,max) -- generate a random partition where
*           each partition min <= p_i <= max
*
* Args:
*    n      -- integer to be partitioned
*    min    -- minimum size of each partition
*    max    -- maximum size of each partition
*
* Returns:
*    the new partition, or NULL if there is an error
*/
ae_pPartition_t
ygenRandomPartition(int n, int min, int max)
{
	ae_pPartition_t answer;

	if (n <= 1 || min <= 0 || max <= min || n < 2 * min)
		return NULL;

	answer = bandAllocateIntList(n / min + 1);
	if (!answer)
		return NULL;

	answer->n = ygenRandomPartitionLoop(answer, 0, n, min, max);
	return answer;
}

/*
 * ygenGenerators(partition, k) -- generate the Artin Braid that makes up
 *                                 the kth Y Generator using the partition.
 *
 * Args:
 *    partition -- the partitioning of B_n to use for these generators
 *    k         -- the index into the list of generators (0-indexed)
 *
 * a partition of n-1 given by n-1 = p[[1]]+p[[2]]+ ... +p[[i]] and an
 * integer k. Let r[1]=1 and r[i] = r[i-1]+p[[i-1]]. Then write k =
 * r[j]+u which is used to determine a new generator for the braid
 * group B_n. There will be exactly n-1 such new generators.
 *
 * Returns the kth generator.  Note that k is 0-indexed!
 * Note that 0 <= k < n-1
 */
ae_plist_t
ygenGenerators(ae_pPartition_t p, int k)
{
  ae_plist_t answer = NULL;
  ae_pIntList_t r;
  int i, jj = 1, u;
  int n = 0;

  if (!p || k < 0)
    return NULL;

  for (i = 0; i < p->n; i++) {
    n += p->items[i];
  }

  if (k > n-1)
    return NULL;

  r  = bandAllocateIntList(p->n);
  if (!r)
    return NULL;

  // r[1] = 1;
  r->items[0] = 0;
  // Do[r[i] = r[i - 1] + p[[i - 1]], {i, 2, Length[p]}];
  for (i = 1; i < p->n; i++) {
    r->items[i] = r->items[i-1] + p->items[i-1];
  }

  // jj = 1; While[r[jj] ≤ k, jj = jj + 1];
  while(r->items[jj]-1 < k) {
    jj++;
  }

  //j = jj - 1;
  jj--;

  //  u = k - r[j];
  u = k - r->items[jj];
  answer = braidAllocateBraidlist(p->items[jj] - u);
  if (!answer) {
    bandFreeIntList(r);
    return NULL;
  }

  //Table[{r[j] + u + t, 1}, {t, 0, p[[j]] - u - 1}]];
  for (i = 0; i < answer->len; i++) {
    SETBRAID(answer, i, r->items[jj]+u+i+1, 1);
  }

  bandFreeIntList(r);
  return answer;
}

/*
 * ygenFreelyReduceY(w) -- Freely Reduce the Y-Word
 *
 * Args:
 *    w     -- the braid word in Y generators
 *
 * Returns the freely reduced braid word.
 */
ae_pYWord_t
ygenFreelyReduceY(ae_pYWord_t w)
{
  if (!w)
    return NULL;
  return braidFreelyReduce(w);
}

/*
 * ygenArtinToYGenerators(p, k) -- Convert from Artin generator to Y Generator
 *
 * Args:
 *    p     -- the partition on B_n to use for this set of Y generators
 *    k     -- the Artin generator to convert (0-indexed)
 *
 * Returns the Y Generator for the i+1st Artin Generator
 */
ae_pYWord_t
ygenArtinToYGenerators(ae_pPartition_t p, int k)
{
  ae_pYWord_t answer = NULL;
  ae_pIntList_t r;
  int i, jj = 1, u;
  int n = 0;

  if (!p || k < 0)
    return NULL;

  for (i = 0; i < p->n; i++) {
    n += p->items[i];
  }

  if (k > n-1)
    return NULL;

  r  = bandAllocateIntList(p->n);
  if (!r)
    return NULL;

  // r[1] = 1;
  r->items[0] = 0;
  // Do[r[i] = r[i - 1] + p[[i - 1]], {i, 2, Length[p]}];
  for (i = 1; i < p->n; i++) {
    r->items[i] = r->items[i-1] + p->items[i-1];
  }

  // jj = 1; While[r[jj] ≤ k, jj = jj + 1];
  while(r->items[jj]-1 < k) {
    jj++;
  }

  //j = jj - 1;
  jj--;

  //  u = k - r[j];
  u = k - r->items[jj];

  // If[u < p[[j]] - 1,
  //    {{Y[r[j] + u], 1}, {Y[r[j] + u + 1], - 1}},
  //    {{Y[r[j] + u], 1}}]];
  if (u < p->items[jj] - 1) {
    answer = braidAllocateBraidlist(2);
    if (answer) {
      SETBRAID(answer, 0, r->items[jj]+u+1, 1);
      SETBRAID(answer, 1, r->items[jj]+u+2, -1);
    }
  } else {
    answer = braidAllocateBraidlist(1);
    if (answer) {
      SETBRAID(answer, 0, r->items[jj]+u+1, 1);
    }
  }

  bandFreeIntList(r);
  return answer;
}

/*
 * ygenArtinWordToYWord(w, p) -- Convert from Artin word to Y Word
 *
 * Args:
 *    w     -- Word in Artin Generators
 *    p     -- Partition of B_n for generating Y Generators
 *
 * Returns the word in Y-Generators for the input word
 */
ae_pYWord_t
ygenArtinWordToYWord(ae_plist_t w, ae_pPartition_t p)
{
  ae_pYWord_t answer, ygen, iygen;
  int i;

  if (!w || !p)
    return NULL;

  answer = braidAllocateBraidlist(0);
  if (!answer)
    return NULL;

  for (i = 0; i < w->len; i++) {
    ygen = ygenArtinToYGenerators(p, w->b[i].l-1);
    if (w->b[i].u > 0) {
      braidAppendBraidlistToBraidlist(answer, ygen);
    } else {
      iygen = braidInverse(ygen);
      braidAppendBraidlistToBraidlist(answer, iygen);
      braidFreeBraidlist(&iygen);
    }
    braidFreeBraidlist(&ygen);
  }

  ygen = answer;
  answer = ygenFreelyReduceY(ygen);
  braidFreeBraidlist(&ygen);

  return answer;
}

/*
 * ygenYWordToArtinWord(w, p) -- Convert from Y Word to Artin word
 *
 * Args:
 *    w     -- Word in Y Generators
 *    p     -- Partition of B_n for generating Y Generators
 *
 * Returns the word in Artin Generators for the input word
 */
ae_plist_t
ygenYWordToArtinWord(ae_pYWord_t w, ae_pPartition_t p)
{
	ae_plist_t answer, agen, iagen;
	int i, j;

	if (!w || !p)
		return NULL;

	answer = braidAllocateBraidlist(0);
	if (!answer)
		return NULL;

	for (i = 0; i < w->len; i++) {
		agen = ygenGenerators(p, w->b[i].l - 1);
		if (w->b[i].u > 0) {
			assert(w->b[i].u < 32000); // XXX: ~32K
			for (j = w->b[i].u; j > 0; j--)
				braidAppendBraidlistToBraidlist(answer, agen);
		}
		else {
			iagen = braidInverse(agen);
			assert(w->b[i].u > -32000);  // XXX: ~32K
			for (j = w->b[i].u; j < 0; j++)
				braidAppendBraidlistToBraidlist(answer, iagen);
			braidFreeBraidlist(&iagen);
		}
		braidFreeBraidlist(&agen);
	}

	agen = answer;
	answer = braidFreelyReduce(agen);
	braidFreeBraidlist(&agen);
	return answer;
}

/*
 * ygenRandomYWordRewriteOnce(w, r) -- rewrite the word using the relations
 *
 * Args:
 *   w      -- word to rewrite
 *   r      -- list of relations to use
 *
 * Chooses a random partition to break apart w.
 * For each partitioned block it chooses a random 2-generator subword
 * Then it attempts to rewrite that subword using the list of relations.
 *
 * Returns the resulting rewritten braid.
 */

ae_pYWord_t
ygenRandomYWordRewriteOnce(ae_pYWord_t w)
{
  ae_pYWord_t answer = NULL, rewrite, rewritten;
  ae_pPartition_t p;
  int i, pos, index, offset = 0, off, m,k ;
  ae_YWord_t sw;

  if (!w )
    return NULL;

  answer = braidAllocateBraidlist(0);
  if (!answer)
    return NULL;

  p = ygenRandomPartition(w->len, 5, 10);
  if (!p)
    goto err;

  for (i = 0; i < p->n; i++) {
    // Choose a random subword in the block */
    off = braidGetRandom(p->items[i]-1);
    sw.len = 2;
    sw.b = &(w->b[offset]) + off;

	//The generators are 1 indexed, but, obviously, our lookup table is not.
	uint8_t lookup1 = (sw.b[0].l - 1) + (sw.b[0].u == -1 ? 8 : 0);
	uint8_t lookup2 = (sw.b[1].l - 1) + (sw.b[1].u == -1 ? 8 : 0);


	index = flatywordslookup[lookup1][lookup2];
	pos = index;

    if (pos < 0) 
	{
      sw.len = p->items[i];
      sw.b = &(w->b[offset]);
    } 
	else 
	{
		rewrite = braidAllocateBraidlist(flatywords[index][0]);
		memcpy(rewrite->b, &flatywords[index][1], flatywords[index][0] * 2);

      if (!rewrite)
		goto err;
      if (off) 
	  {
		sw.len = off;
		sw.b = &(w->b[offset]);
		braidAppendBraidlistToBraidlist(answer, &sw);
      }

      braidAppendBraidlistToBraidlist(answer, rewrite);
      braidFreeBraidlist(&rewrite);
      sw.len = p->items[i]-off-2;
      sw.b = &(w->b[offset]) + off + 2;
    }
    if (sw.len)
      braidAppendBraidlistToBraidlist(answer, &sw);

    offset += p->items[i];
  }
  goto done;

 err:
  if (answer)
    braidFreeBraidlist(&answer);
 done:
  if (p)
    bandFreeIntList(p);
  if (answer) {
    rewrite = ygenFreelyReduceY(answer);
    braidFreeBraidlist(&answer);
    answer = rewrite;
  }
  return answer;
}

/*
 * ygenRandomYWordRewrite(w, r, i) -- rewrite the word using the relations
 *
 * Args:
 *   w      -- word to rewrite
 *   r      -- list of relations to use
 *   i      -- number of iterations over the word
 *
 * Rewrites the word using RandomYWordRewriteOnce i times.
 *
 * Returns the resulting rewritten braid.
 */
ae_pYWord_t
ygenRandomYWordRewrite(ae_pYWord_t w, int iterations)
{
  ae_pYWord_t answer = NULL, rewrite = NULL, last = NULL;

  if (!w  || iterations <= 0)
    return NULL;

  while (iterations-- > 0) {
    rewrite = ygenRandomYWordRewriteOnce(w);
    if (!rewrite)
      goto err;
    if (last)
      braidFreeBraidlist(&last);
    last = w = rewrite;
  }

  answer = ygenFreelyReduceY(rewrite);
  braidFreeBraidlist(&rewrite);
  return answer;

 err:
  if (last)
    braidFreeBraidlist(&last);
  return NULL;
}
