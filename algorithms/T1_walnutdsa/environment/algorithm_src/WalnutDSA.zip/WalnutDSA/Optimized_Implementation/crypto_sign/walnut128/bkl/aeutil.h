/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#ifndef AEUTIL_H
#define AEUTIL_H 1
/*
 * Includes
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <assert.h>
#ifdef HAVE_SYS_TYPES_H
#include <sys/types.h>
#endif
#include <errno.h>
#include <setjmp.h>
#include <signal.h>
#  ifdef HAVE_UNISTD_H
#    include <unistd.h>
#  endif
#ifndef USE_WRAPPERS
#include <sys/time.h> // For gettimeofday()
#endif

#  define ae_malloc       malloc
#  define ae_calloc       calloc
#  define ae_realloc      realloc
#  define ae_free         free
#  define ae_memcpy       memcpy
#define ae_aligned_malloc(x, y)	malloc(x)
#define ae_aligned_free free
#  define ae_fopen        fopen
#  define ae_fclose       fclose
#  define ae_fread        fread
#  define ae_fgetc        fgetc
#  define ae_fprintf      fprintf
#  define ae_gettimeofday gettimeofday

#    define ae_getpid     getpid

#  define ae_clock        clock
#  define ae_errno()      errno
#endif /* AEUTIL_H */
