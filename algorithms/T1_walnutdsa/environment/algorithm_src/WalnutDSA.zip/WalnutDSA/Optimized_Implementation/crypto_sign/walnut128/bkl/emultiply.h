/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

/*
 * emultiply.h - constants, data structures, and prototypes for emultiply
 */

#ifndef EMULTIPLY_H
#define EMULTIPLY_H 1

/* constants */


/* data structures */


/* prototypes */
ae_pcbdata_t  ae_eMultiplyModP   		(ae_pcbdata_t m1, ae_pcbdata_t m2, ae_pTvalues_t tvalues);
ae_pcbdata_t  ae_eMultiplicationIterator	(ae_pcbdata_t cb, ae_pcblist_t b, ae_pTvalues_t tvalues);
ae_pcbdata_t  ae_eMultiplicationPermuteIterator	(ae_pcbdata_t cb, ae_pcblist_t b, ae_pTvalues_t tvalues);
ae_pcbdata_t  ae_MultiplyModP			(ae_pcbdata_t m1, ae_pcbdata_t m2, ae_pTvalues_t tvalues);
ae_pcbdata_t  ae_MultiplicationIterator		(ae_pcbdata_t cb, ae_pcblist_t b, ae_pTvalues_t tvalues);
#endif /* EMULTIPLY_H */
