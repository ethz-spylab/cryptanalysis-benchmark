/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#include "api.h"
#include <string.h>
#include <stddef.h>
#include <ae_crypto.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "crypto_sign.h"


int crypto_sign_keypair(
	unsigned char *pk,
	unsigned char *sk
)
{

	unsigned char privkey[2*(((WALNUT_VALUE_l + 1)/ 2)+2)];
	unsigned char pubkey[WALNUT_PUBKEY_LENGTH];
	unsigned char * privkey2;

	int success = 1;

	success &= key_generation(privkey, pubkey);

	privkey2 = privkey + GET_NUM_BRAID_BYTES(privkey);

	memcpy(pk, pubkey, WALNUT_PUBKEY_LENGTH);
	memcpy(sk, privkey, GET_NUM_BRAID_BYTES(privkey) + GET_NUM_BRAID_BYTES(privkey2));

#ifdef KAT_INTERMEDIATES
	unpack_and_print_braid(sk, "Unpacked private braid 1");
	unpack_and_print_braid(privkey2, "Unpacked private braid 2");
	printBuffer(sk, GET_NUM_BRAID_BYTES(privkey), "Packed Private braid 1");
	printBuffer(privkey2, GET_NUM_BRAID_BYTES(privkey2), "Packed Private braid 2");
	unpack_and_print_matrix(pk, "Unpacked Public Key");
	printBuffer(pk, WALNUT_PUBKEY_LENGTH, "Packed Public Key");
#endif

	return !success;
}


int crypto_sign(
	unsigned char *sm, unsigned long long *smlen,
	const unsigned char *m, unsigned long long mlen,
	const unsigned char *sk
)
{
	int success = 1;
	unsigned char signature[CRYPTO_BYTES + mlen];

	success = signature_generation(signature, smlen, m, mlen, sk);

	memcpy(sm, signature, *smlen);

	return !success;
}

int crypto_sign_open(
	unsigned char *m, unsigned long long *mlen,
	const unsigned char *sm, unsigned long long smlen,
	const unsigned char *pk
)
{
	int success = 1;

	unsigned char *message = NULL;

	success &= signature_verification((unsigned char *)pk, (unsigned char *)sm, &smlen, &message, mlen);

	memcpy(m, message, *mlen);

	free(message);

	return !success;
}
