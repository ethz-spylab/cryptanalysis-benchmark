/*
* Copyright (c) 2017 SecureRF Corporation, All rights reserved.
* -------------------------------------------------------------------------
* This computer program is proprietary information of SecureRF Corporation.
* The receipt or possession of this program does not convey any rights to
* reproduce or disclose its contents, or to manufacture, use, or sell
* anything that it may describe, in whole or in part, except for the purposes of 
* the post-quantum algorithm public review and evaluation in connection with 
* the National Institute of Standards and Technology’s development of standards 
* for post-quantum cryptography.  Any reproduction of this program for any other 
* purpose without the express written consent of SecureRF is a violation of the 
* copyright laws and may subject you to criminal prosecution.
* -------------------------------------------------------------------------
*/

#include "api.h"
#ifdef WALNUT
#include "crypto_sign.h"
#else
#include "crypto_kem.h"
#endif
#include <stdio.h>
#include <stdlib.h>

static unsigned char *p;
static unsigned char *s;
static unsigned char *m;
static unsigned char *sig;
static unsigned char *returnedmessage;

#define MAXTEST_BYTES 100000
#define TUNE_BYTES 1536

int main()
{
	
#ifdef WALNUT
	unsigned long long alloclen = 0;
	if (alloclen < TUNE_BYTES) alloclen = TUNE_BYTES;
	if (alloclen < MAXTEST_BYTES + crypto_sign_BYTES) alloclen = MAXTEST_BYTES + crypto_sign_BYTES;
	if (alloclen < crypto_sign_PUBLICKEYBYTES) alloclen = crypto_sign_PUBLICKEYBYTES;
	if (alloclen < crypto_sign_SECRETKEYBYTES) alloclen = crypto_sign_SECRETKEYBYTES;

	printf("Allocating %llu\n", alloclen);

	p = calloc(alloclen, 1);
	s = calloc(alloclen, 1);
	m = calloc(alloclen, 1);
	sig = calloc(alloclen, 1);
	returnedmessage = calloc(MAXTEST_BYTES, 1);

	if (crypto_sign_keypair(p,s) != 0)
	{
		printf("Key generation failure\n");
		exit(111);
	}
	
	unsigned long long mlen = rand() % 1000;
	unsigned long long clen = 0;
	
	int i=0;
	
	printf("Generated message of size %llu and allocated signature of max size %llu\n", mlen, crypto_sign_BYTES + mlen);
	
	for(i=0; i<mlen; i++)
	{
		m[i] = rand() % 255;
	}
	
	clen = mlen + crypto_sign_BYTES;

	if (crypto_sign(sig,&clen,m,mlen,s) != 0) 
	{
		printf("Signature generation failure\n");
		exit(111);
	}

	printf("Generated signature of size %llu (that's the message and the signature)\n", clen);
	
	unsigned long long returnmessagelen= clen;
	
	if (crypto_sign_open(returnedmessage,&returnmessagelen,sig,clen,p) != 0) 
	{
		printf("Signature verification failure\n");
		exit(111);
	}
	else
	{
		printf("Successfully verified signature\n");
	}
#else
	unsigned char       ct[CRYPTO_CIPHERTEXTBYTES], ss[CRYPTO_BYTES], ss1[CRYPTO_BYTES];
	unsigned char       pk[CRYPTO_PUBLICKEYBYTES], sk[CRYPTO_SECRETKEYBYTES];
	int                 ret_val;

	if ( (ret_val = crypto_kem_keypair(pk, sk)) != 0) {
		printf("crypto_kem_keypair returned <%d>\n", ret_val);
		exit(111);
	}
	
	printf("Created Alice's private and Bob's public and private keys\n");
	
	if ( (ret_val = crypto_kem_enc(ct, ss, pk)) != 0) {
		printf("crypto_kem_enc returned <%d>\n", ret_val);
		exit(111);
	}
	
	printf("Created Alice's public key and shared secret using Bob's public key and Alice's private\n");

	if ( (ret_val = crypto_kem_dec(ss1, ct, sk)) != 0) {
		printf("crypto_kem_dec returned <%d>\n", ret_val);
		exit(111);
	}

	printf("Created shared secret using Alice's public key and Bob's private key\n");

	if ( memcmp(ss, ss1, CRYPTO_BYTES) ) {
		printf("crypto_kem_dec returned bad 'ss' value\n");
		exit(111);
	}

	printf("Successfully created two identical shared secrets\n");

#endif
	
	
}