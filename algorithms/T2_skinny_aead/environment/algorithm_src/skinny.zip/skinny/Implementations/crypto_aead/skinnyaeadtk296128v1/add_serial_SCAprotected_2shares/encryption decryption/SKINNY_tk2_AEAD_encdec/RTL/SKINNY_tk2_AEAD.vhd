--
-- SKINNY-AEAD Reference Hardware Implementation
-- 
-- Copyright 2019:
--     Amir Moradi & Pascal Sasdrich for the SKINNY Team
--     https://sites.google.com/site/skinnycipher/
-- 
-- This program is free software; you can redistribute it and/or
-- modify it under the terms of the GNU General Public License as
-- published by the Free Software Foundation; either version 2 of the
-- License, or (at your option) any later version.
-- 
-- This program is distributed in the hope that it will be useful, but
-- WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
-- General Public License for more details.
-- 

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity SKINNY_tk2_AEAD is
Generic (
	tl				 : integer := 0); -- 0: 128-bit tag,   1: 64-bit tag
Port (  
	clk          : in  STD_LOGIC;
	rst      	 : in  STD_LOGIC;
	a_data       : in  STD_LOGIC;
	enc          : in  STD_LOGIC;
	dec          : in  STD_LOGIC;
	gen_tag      : in  std_logic;
	Input1       : in  STD_LOGIC_VECTOR (127       downto 0);  -- Message or Associated Data (share 1)
	Input2       : in  STD_LOGIC_VECTOR (127       downto 0);  -- Message or Associated Data (share 2)
	N            : in  STD_LOGIC_VECTOR ( 95       downto 0);
	K1           : in  STD_LOGIC_VECTOR (127       downto 0); -- Key (share 1)
	K2				 : in  STD_LOGIC_VECTOR (127       downto 0); -- Key (share 2)
	Block_Size	 : in  STD_LOGIC_VECTOR (  3       downto 0); -- Size of the given block as Input (in BYTES) - 1
	Output1      : out STD_LOGIC_VECTOR (127       downto 0); -- Ciphertext (share 1)
	Output2      : out STD_LOGIC_VECTOR (127       downto 0); -- Ciphertext (share 2) 
	Tag1			 : out STD_LOGIC_VECTOR (127-tl*64 downto 0); -- Tag (share 1)
	Tag2			 : out STD_LOGIC_VECTOR (127-tl*64 downto 0); -- Tag (share 2)
	done         : out STD_LOGIC);
end SKINNY_tk2_AEAD;

architecture dfl of SKINNY_tk2_AEAD is

	constant nl				 		: integer := 1;  -- 96-bit nonce

	signal full_size				: STD_LOGIC;

	signal Cipher_Input1			: STD_LOGIC_VECTOR(127 downto 0);
	signal Cipher_Input2			: STD_LOGIC_VECTOR(127 downto 0);
	signal Cipher_Output1		: STD_LOGIC_VECTOR(127 downto 0);
	signal Cipher_Output2		: STD_LOGIC_VECTOR(127 downto 0);
	signal tk1 		 				: STD_LOGIC_VECTOR(127 downto 0);
	signal tk2_1	 				: STD_LOGIC_VECTOR(127 downto 0);
	signal tk2_2	 				: STD_LOGIC_VECTOR(127 downto 0);
	
	signal LFSR_Output			: STD_LOGIC_VECTOR( 23 downto 0);
	signal LFSR_rst         	: STD_LOGIC;
	signal LFSR_en          	: STD_LOGIC;
		
	signal Auth_Reg_rst			: STD_LOGIC;
	signal Auth_Reg_en			: STD_LOGIC;
	
	signal Tag_Reg_rst			: STD_LOGIC;
	signal Tag_Reg_en				: STD_LOGIC;
	
	signal Domain_Separation	: STD_LOGIC_VECTOR(  7 downto 0);
	
	signal Cipher_rst				: STD_LOGIC;
	signal Cipher_dec				: STD_LOGIC;
	signal Cipher_done			: STD_LOGIC;
	
begin
		
	LFSRInst: entity work.LFSR
	Port Map (
		clk,
		LFSR_rst,
		LFSR_en,
		LFSR_Output);

	CipherInst: entity work.Skinny256_serial
	Port Map (
		clk,
		Cipher_rst,
		Cipher_dec,
		Cipher_done,
		tk1,
		tk2_1,
		tk2_2,
		Cipher_Input1,
		Cipher_Input2,
		Cipher_Output1,
		Cipher_Output2);

	ControlInst: entity work.Controller
	Generic Map (nl, tl)
	Port Map (
		clk,
		rst,
		a_data,
		enc,
		dec,
		gen_tag,
		full_size,
		LFSR_rst,
		LFSR_en,
		Auth_Reg_rst,
		Auth_Reg_en,
		Tag_Reg_rst,
		Tag_Reg_en,
		Cipher_rst,
		Cipher_dec,
		Cipher_done,
		Domain_Separation,
		done);
	
	-----------------------------------------------------

	full_size					<= '1' when Block_Size  = "1111" else '0';
	
	tk1							<= LFSR_Output( 7 downto  0) & LFSR_Output(15 downto  8) & LFSR_Output(23 downto 16) &
										Domain_Separation & N;
										
	tk2_1							<= K1;
	tk2_2							<= K2;

	-----------------------------------------------------

	MainPart1: entity work.MainPart
	Generic Map (tl, 1)
	Port Map (
		clk,
		a_data,
		dec,
		gen_tag,
		Block_Size,
		full_size,
		Auth_Reg_rst,
		Auth_Reg_en,
		Tag_Reg_rst,
		Tag_Reg_en,
		Input1,
		Cipher_Input1,
		Cipher_Output1,
		Output1,
		Tag1);

	MainPart2: entity work.MainPart
	Generic Map (tl, 0)
	Port Map (
		clk,
		a_data,
		dec,
		gen_tag,
		Block_Size,
		full_size,
		Auth_Reg_rst,
		Auth_Reg_en,
		Tag_Reg_rst,
		Tag_Reg_en,
		Input2,
		Cipher_Input2,
		Cipher_Output2,
		Output2,
		Tag2);
		
end dfl;

