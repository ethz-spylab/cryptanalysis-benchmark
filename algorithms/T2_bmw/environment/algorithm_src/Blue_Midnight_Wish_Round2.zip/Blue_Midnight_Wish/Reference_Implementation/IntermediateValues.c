#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#include "SHA3api_ref.h"


int main()
{
	int		                    i, bitlens[4] = { 224, 256, 384, 512 };
	BitSequence	                Msg[100001], MD[64];

	printf("\n");
	
	for ( i=0; i<2; i++ ) 
	{
		printf("\n##############################################################\n");
		printf("\n  Blue Midnight Wish hash algorithm, \n");
		printf("\n  tweaked for the Second Round of SHA-3 competition.\n");
		printf("\n    Message Digest Length = %d\n", bitlens[i]);
		printf("\n##############################################################\n\n\n");
		printf("\n  One Block Message Sample\n\n");
		printf("\n  Input Message: \"abc\" \n");
		memcpy(Msg, "abc", 3);
		Hash(bitlens[i], Msg, 24, MD);

		printf("\n\n\n==============================================================\n");
		printf("\n  Two Block Message Sample\n\n");
		printf("\n  Input Message: \"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq\" \n");
		memcpy(Msg, "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq", 56);
		Hash(bitlens[i], Msg, 56*8, MD);
		printf("\n\n\n\n\n");
	}
	for ( i=2; i<4; i++ ) 
	{
		printf("\n##############################################################\n");
		printf("\n  Blue Midnight Wish hash algorithm\n");
		printf("\n  tweaked for the Second Round of SHA-3 competition.\n");
		printf("\n    Message Digest Length = %d\n", bitlens[i]);
		printf("\n##############################################################\n\n\n");
		printf("\n  One Block Message Sample\n\n");
		printf("\n  Input Message: \"abc\" \n");
		memcpy(Msg, "abc", 3);
		Hash(bitlens[i], Msg, 24, MD);

		printf("\n\n==============================================================\n");
		printf("\n  Two Block Message Sample\n\n");
		printf("\n  Input Message: \"abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnmnopqrsmopqrstu\" \n");
		memcpy(Msg, "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnmnopqrsmopqrstu", 120);
		Hash(bitlens[i], Msg, 120*8, MD);
		printf("\n\n\n\n\n");
	}

	return 0;
}
