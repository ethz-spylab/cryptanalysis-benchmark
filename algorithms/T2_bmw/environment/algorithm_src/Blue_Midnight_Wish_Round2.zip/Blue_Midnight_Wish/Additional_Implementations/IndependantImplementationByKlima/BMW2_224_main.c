/* This is tweaked BMW, denoted as BMW2 */
#include  <stdio.h>
#include  <string.h>
#include  <stdlib.h>
#include  <conio.h>

#define rotl32(x,n)   (((x) << (n)) | ((x) >> (32 - (n))))
#define rotr32(x,n)   (((x) >> (n)) | ((x) << (32 - (n))))
#define shl32(x,n)   ((x) << (n))
#define shr32(x,n)   ((x) >> (n))

#define s_0(x)  (((x)>> 1) ^ ((x)<<  3) ^ rotl32((x),  4) ^ rotl32((x), 19))
#define s_1(x)  (((x)>> 1) ^ ((x)<<  2) ^ rotl32((x),  8) ^ rotl32((x), 23))
#define s_2(x)  (((x)>> 2) ^ ((x)<<  1) ^ rotl32((x), 12) ^ rotl32((x), 25))
#define s_3(x)  (((x)>> 2) ^ ((x)<<  2) ^ rotl32((x), 15) ^ rotl32((x), 29))
#define s_4(x)  (((x)>> 1) ^ (x))
#define s_5(x)  (((x)>> 2) ^ (x))
#define r_01(x) rotl32((x),  3)
#define r_02(x) rotl32((x),  7)
#define r_03(x) rotl32((x), 13)
#define r_04(x) rotl32((x), 16)
#define r_05(x) rotl32((x), 19)
#define r_06(x) rotl32((x), 23)
#define r_07(x) rotl32((x), 27)

const unsigned long i224p2[16] =
{   0x00010203ul, 0x04050607ul, 0x08090a0bul, 0x0c0d0e0ful,
    0x10111213ul, 0x14151617ul, 0x18191a1bul, 0x1c1d1e1ful,
    0x20212223ul, 0x24252627ul, 0x28292a2bul, 0x2c2d2e2ful,
    0x30313233ul, 0x34353637ul, 0x38393a3bul, 0x3c3d3e3ful,
};

unsigned long CONST32final[16] =
	{
		0xaaaaaaa0ul,  0xaaaaaaa1ul,  0xaaaaaaa2ul, 0xaaaaaaa3ul,
		0xaaaaaaa4ul,  0xaaaaaaa5ul,  0xaaaaaaa6ul, 0xaaaaaaa7ul,
		0xaaaaaaa8ul,  0xaaaaaaa9ul,  0xaaaaaaaaul, 0xaaaaaaabul,
		0xaaaaaaacul,  0xaaaaaaadul,  0xaaaaaaaeul, 0xaaaaaaaful
	};
 
unsigned char N;//global variable - number of expandrounds1

/*================================ ok ================================*/
void BMW2_256(unsigned char *IV, unsigned char *indata, unsigned char *outdata)
{
  //this processes just one block - for the simplicity and verifiability
	// written only for LITTLE endian machines
	// this is only one block,  without final invocation

  unsigned char    i;
  unsigned long XH,XL,tp[16],p[16],p2[48], H[16];

   //this is only for LITTLE endian
	memcpy((unsigned char*)p, indata, 64);
	memcpy((unsigned char*)H, IV, 64);

	for(i = 0; i < 16; i++) tp[ i] = p[i] ^ H[i];  

/*  Mix the message block with the previous double pipe. */
	p2[ 0] = s_0( tp[5]-tp[7]+tp[10]+tp[13]+tp[14]);
	p2[ 1] = s_1( tp[6]-tp[8]+tp[11]+tp[14]-tp[15]);
	p2[ 2] = s_2( tp[0]+tp[7]+tp[ 9]-tp[12]+tp[15]);
	p2[ 3] = s_3( tp[0]-tp[1]+tp[ 8]-tp[10]+tp[13]);
	p2[ 4] = s_4( tp[1]+tp[2]+tp[ 9]-tp[11]-tp[14]);
	p2[ 5] = s_0( tp[3]-tp[2]+tp[10]-tp[12]+tp[15]);
	p2[ 6] = s_1( tp[4]-tp[0]-tp[ 3]-tp[11]+tp[13]);
	p2[ 7] = s_2( tp[1]-tp[4]-tp[ 5]-tp[12]-tp[14]);
	p2[ 8] = s_3( tp[2]-tp[5]-tp[ 6]+tp[13]-tp[15]);
	p2[ 9] = s_4( tp[0]-tp[3]+tp[ 6]-tp[ 7]+tp[14]);
	p2[10] = s_0( tp[8]-tp[1]-tp[ 4]-tp[ 7]+tp[15]);
	p2[11] = s_1( tp[8]-tp[0]-tp[ 2]-tp[ 5]+tp[ 9]);
	p2[12] = s_2( tp[1]+tp[3]-tp[ 6]-tp[ 9]+tp[10]);
	p2[13] = s_3( tp[2]+tp[4]+tp[ 7]+tp[10]+tp[11]);
	p2[14] = s_4( tp[3]-tp[5]+tp[ 8]-tp[11]-tp[12]);
	p2[15] = s_0( tp[12]-tp[4]-tp[6]-tp[ 9]+tp[13]);

	//tweak
	for(i = 0; i < 16; i++) p2[ i] = p2[i] + H[(i+1)%16]; 

	for(i = 16; i < (N + 16); i++) 
	{//tweak
		p2[i] = s_1(p2[i - 16])  + s_2(p2[i - 15])  + s_3(p2[i - 14]  ) + s_0(p2[i - 13] )
			  + s_1(p2[i - 12])  + s_2(p2[i - 11])  + s_3(p2[i - 10]  ) + s_0(p2[i -  9] )
			  + s_1(p2[i -  8])  + s_2(p2[i -  7])  + s_3(p2[i -  6]  ) + s_0(p2[i -  5] )
			  + s_1(p2[i -  4])  + s_2(p2[i -  3])  + s_3(p2[i -  2]  ) + s_0(p2[i -  1] )
			  + ( ( i*(0x05555555ul) + rotl32(p[(i-16)%16],((i-16)%16) +1) + rotl32(p[(i-13)%16],((i-13)%16) +1) - rotl32(p[(i-6)%16],((i-6)%16)+1) ) ^ H[(i-16+7)%16] );
	}
	
	for(i = (N + 16); i < 32; i++) 
	{//tweak
		p2[i] = p2[i - 16] + r_01(p2[i - 15]) + p2[i - 14] + r_02(p2[i - 13])
			  + p2[i - 12] + r_03(p2[i - 11]) + p2[i - 10] + r_04(p2[i -  9])
			  + p2[i -  8] + r_05(p2[i -  7]) + p2[i -  6] + r_06(p2[i -  5])
			  + p2[i -  4] + r_07(p2[i -  3]) + s_4( p2[i -  2] ) + s_5(p2[i -  1])
			  + ( ( i*(0x05555555ul) + rotl32(p[(i-16)%16],((i-16)%16) +1) + rotl32(p[(i-13)%16],((i-13)%16) +1) - rotl32(p[(i-6)%16],((i-6)%16)+1) ) ^ H[(i-16+7)%16] );
	}
	
/*  Compute the double chaining pipe for the next message block. */
XL = p2[16]^p2[17]^p2[18]^p2[19]^p2[20]^p2[21]^p2[22]^p2[23];
XH = XL ^ p2[24]^p2[25]^p2[26]^p2[27]^p2[28]^p2[29]^p2[30]^p2[31];

p2[0] =          (shl32(XH, 5) ^ shr32(p2[16],5) ^ p[ 0]) + (XL ^ p2[24] ^ p2[ 0]);
p2[1] =          (shr32(XH, 7) ^ shl32(p2[17],8) ^ p[ 1]) + (XL ^ p2[25] ^ p2[ 1]);
p2[2] =          (shr32(XH, 5) ^ shl32(p2[18],5) ^ p[ 2]) + (XL ^ p2[26] ^ p2[ 2]);
p2[3] =          (shr32(XH, 1) ^ shl32(p2[19],5) ^ p[ 3]) + (XL ^ p2[27] ^ p2[ 3]);
p2[4] =          (shr32(XH, 3) ^       p2[20]    ^ p[ 4]) + (XL ^ p2[28] ^ p2[ 4]);
p2[5] =          (shl32(XH, 6) ^ shr32(p2[21],6) ^ p[ 5]) + (XL ^ p2[29] ^ p2[ 5]);
p2[6] =          (shr32(XH, 4) ^ shl32(p2[22],6) ^ p[ 6]) + (XL ^ p2[30] ^ p2[ 6]);
p2[7] =          (shr32(XH,11) ^ shl32(p2[23],2) ^ p[ 7]) + (XL ^ p2[31] ^ p2[ 7]);
                 
p2[ 8] = rotl32(p2[4], 9) + (XH ^ p2[24] ^ p[ 8]) + (shl32(XL,8) ^ p2[23] ^ p2[ 8]);
p2[ 9] = rotl32(p2[5],10) + (XH ^ p2[25] ^ p[ 9]) + (shr32(XL,6) ^ p2[16] ^ p2[ 9]);
p2[10] = rotl32(p2[6],11) + (XH ^ p2[26] ^ p[10]) + (shl32(XL,6) ^ p2[17] ^ p2[10]);
p2[11] = rotl32(p2[7],12) + (XH ^ p2[27] ^ p[11]) + (shl32(XL,4) ^ p2[18] ^ p2[11]);
p2[12] = rotl32(p2[0],13) + (XH ^ p2[28] ^ p[12]) + (shr32(XL,3) ^ p2[19] ^ p2[12]);
p2[13] = rotl32(p2[1],14) + (XH ^ p2[29] ^ p[13]) + (shr32(XL,4) ^ p2[20] ^ p2[13]);
p2[14] = rotl32(p2[2],15) + (XH ^ p2[30] ^ p[14]) + (shr32(XL,7) ^ p2[21] ^ p2[14]);
p2[15] = rotl32(p2[3],16) + (XH ^ p2[31] ^ p[15]) + (shr32(XL,2) ^ p2[22] ^ p2[15]);

memcpy( outdata, (unsigned char*)p2, 64);

 }//BMW2_256
/*================================================================*/
unsigned char BMW2_224_test_samples( void )
{
 unsigned char i, block[65], hout[64], temp[64], *abcstring;
 unsigned long ii;
 
	static unsigned char BMW2_224_test_repeat[28] = 
	{0x78,0xE9,0xAE,0xD5,0x97,0x59,0x4F,0x7B,
	 0x7A,0x7F,0x0C,0x16,0xA9,0xFA,0x87,0xD9,
     0x80,0x85,0xA7,0x37,0xE7,0x3B,0xD4,0x28,
	 0x24,0x2F,0xDF,0xA2};	

	N = 2;

	
	/* 
Repeat = 16777216
Text = abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmno
MD = 78E9AED597594F7B7A7F0C16A9FA87D98085A737E73BD428242FDFA2

	16777216*64 *8 = 0x 02 0000 0000 */

	abcstring = "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmno";
	for(i = 0; i < 64; i++) block[i] = abcstring[i];
	memcpy(hout, (unsigned char *)i224p2, 64);
	for( ii = 0; ii < 16777216; ii++ )
	{
		if ((ii % 10000) == 0) printf("%d ", ii/10000);
		BMW2_256( hout, block, hout ); 
	}
	for(i = 0; i < 64; i++) block[i] = 0;
	block[0]=0x80; block[64-4]=0x02;
	BMW2_256( hout, block, hout ); 
	BMW2_256( (unsigned char *)CONST32final, hout, hout );printf("\n\n"); 
	//for( i = 0; i < 28; i++ ) printf("0x%02X,",hout[i+36]);printf("\n\n"); 
	for( i = 0; i < 28; i++ ) if( hout[i+36] != BMW2_224_test_repeat[i] ) return( -1 );	

  return( 0 );
}
/*====================================================*/
int main( int argc, char* argv[] )
{
	//test the definition  	
  printf( "\nTEST BMW2_224 :\n" );	 
  if ( BMW2_224_test_samples() == 0 ) printf( "OK.\n" );
  else { printf( "Failed.\n" ); goto failed; }
	
ok:
  printf( "\nEnd of program. Push a key.\n" );  
  getch();
  return( 0 );
failed:
  printf( "\nEnd of program. Push a key.\n" );  
  getch();
  return( -1 );
}
/*====================================================*/
