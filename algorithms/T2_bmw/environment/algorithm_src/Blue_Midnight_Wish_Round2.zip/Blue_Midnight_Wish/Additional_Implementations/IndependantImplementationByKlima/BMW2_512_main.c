#include  <stdio.h>
#include  <string.h>
#include  <stdlib.h>
#include  <conio.h>

#define rotl64(x,n)   (((x) << (n)) | ((x) >> (64 - (n))))
#define rotr64(x,n)   (((x) >> n) | ((x) << (64 - (n))))
#define shl64(x,n)   ((x) << (n))
#define shr64(x,n)   ((x) >> (n))

/* Components used for 384 and 512 bit version */
#define s64_0(x)  (shr64((x), 1) ^ shl64((x), 3) ^ rotl64((x),  4) ^ rotl64((x), 37))
#define s64_1(x)  (shr64((x), 1) ^ shl64((x), 2) ^ rotl64((x), 13) ^ rotl64((x), 43))
#define s64_2(x)  (shr64((x), 2) ^ shl64((x), 1) ^ rotl64((x), 19) ^ rotl64((x), 53))
#define s64_3(x)  (shr64((x), 2) ^ shl64((x), 2) ^ rotl64((x), 28) ^ rotl64((x), 59))
#define s64_4(x)  (shr64((x), 1) ^ (x))
#define s64_5(x)  (shr64((x), 2) ^ (x))
#define r64_01(x) rotl64((x),  5)
#define r64_02(x) rotl64((x), 11)
#define r64_03(x) rotl64((x), 27)
#define r64_04(x) rotl64((x), 32)
#define r64_05(x) rotl64((x), 37)
#define r64_06(x) rotl64((x), 43)
#define r64_07(x) rotl64((x), 53)
/* BlueWish512 double chaining pipe */
const unsigned long long i512p2[16] =
{
    0x8081828384858687ull, 0x88898a8b8c8d8e8full,
    0x9091929394959697ull, 0x98999a9b9c9d9e9full,
    0xa0a1a2a3a4a5a6a7ull, 0xa8a9aaabacadaeafull,
    0xb0b1b2b3b4b5b6b7ull, 0xb8b9babbbcbdbebfull,
    0xc0c1c2c3c4c5c6c7ull, 0xc8c9cacbcccdcecfull,
    0xd0d1d2d3d4d5d6d7ull, 0xd8d9dadbdcdddedfull,
    0xe0e1e2e3e4e5e6e7ull, 0xe8e9eaebecedeeefull,
    0xf0f1f2f3f4f5f6f7ull, 0xf8f9fafbfcfdfeffull
};
const unsigned long long CONST64final[16] =
	{
		0xaaaaaaaaaaaaaaa0ull,  0xaaaaaaaaaaaaaaa1ull,
		0xaaaaaaaaaaaaaaa2ull,  0xaaaaaaaaaaaaaaa3ull, 
		0xaaaaaaaaaaaaaaa4ull,  0xaaaaaaaaaaaaaaa5ull, 
		0xaaaaaaaaaaaaaaa6ull,  0xaaaaaaaaaaaaaaa7ull, 
		0xaaaaaaaaaaaaaaa8ull,  0xaaaaaaaaaaaaaaa9ull, 
		0xaaaaaaaaaaaaaaaaull,  0xaaaaaaaaaaaaaaabull, 
		0xaaaaaaaaaaaaaaacull,  0xaaaaaaaaaaaaaaadull, 
		0xaaaaaaaaaaaaaaaeull,  0xaaaaaaaaaaaaaaafull
	};
unsigned char N;//global variable - number of expandrounds1
/*================================================================*/
void BMW2_512(unsigned char *IV, unsigned char *indata, unsigned char *outdata )
{  //this processes just one block - for the simplicity and verifiability
	// written only for LITTLE endian machines
	
	// only the first block
	unsigned char i;
	unsigned long long XL,XH,tp[16],H[16],p[16],p2[48];

    //this is only for LITTLE endian
	memcpy((unsigned char*)p, indata, 128);
	memcpy((unsigned char*)H, IV, 128);

	for(i = 0; i < 16; i++) tp[ i] = p[i] ^ H[i];  
		
/*  Mix the message block with the previous double pipe. */
	p2[ 0] = s64_0( tp[5]-tp[7]+tp[10]+tp[13]+tp[14]);
	p2[ 1] = s64_1( tp[6]-tp[8]+tp[11]+tp[14]-tp[15]);
	p2[ 2] = s64_2( tp[0]+tp[7]+tp[ 9]-tp[12]+tp[15]);
	p2[ 3] = s64_3( tp[0]-tp[1]+tp[ 8]-tp[10]+tp[13]);
	p2[ 4] = s64_4( tp[1]+tp[2]+tp[ 9]-tp[11]-tp[14]);
	p2[ 5] = s64_0( tp[3]-tp[2]+tp[10]-tp[12]+tp[15]);
	p2[ 6] = s64_1( tp[4]-tp[0]-tp[ 3]-tp[11]+tp[13]);
	p2[ 7] = s64_2( tp[1]-tp[4]-tp[ 5]-tp[12]-tp[14]);
	p2[ 8] = s64_3( tp[2]-tp[5]-tp[ 6]+tp[13]-tp[15]);
	p2[ 9] = s64_4( tp[0]-tp[3]+tp[ 6]-tp[ 7]+tp[14]);
	p2[10] = s64_0( tp[8]-tp[1]-tp[ 4]-tp[ 7]+tp[15]);
	p2[11] = s64_1( tp[8]-tp[0]-tp[ 2]-tp[ 5]+tp[ 9]);
	p2[12] = s64_2( tp[1]+tp[3]-tp[ 6]-tp[ 9]+tp[10]);
	p2[13] = s64_3( tp[2]+tp[4]+tp[ 7]+tp[10]+tp[11]);
	p2[14] = s64_4( tp[3]-tp[5]+tp[ 8]-tp[11]-tp[12]);
	p2[15] = s64_0( tp[12]-tp[4]-tp[6]-tp[ 9]+tp[13]);

	//tweak
	for(i = 0; i < 16; i++) p2[ i] = p2[i] + H[(i+1)%16]; 

/*  This is the Message expansion */
//N = 2; global variable
	
for(i = 16; i < (N + 16); i++)//tweak
{p2[i]     = s64_1(p2[i - 16])  + s64_2(p2[i - 15])  + s64_3(p2[i - 14]  ) + s64_0(p2[i - 13] )
	                       + s64_1(p2[i - 12])  + s64_2(p2[i - 11])  + s64_3(p2[i - 10]  ) + s64_0(p2[i -  9] )
						   + s64_1(p2[i -  8])  + s64_2(p2[i -  7])  + s64_3(p2[i -  6]  ) + s64_0(p2[i -  5] )
						   + s64_1(p2[i -  4])  + s64_2(p2[i -  3])  + s64_3(p2[i -  2]  ) + s64_0(p2[i -  1] )
						   + ( ( i*(0x0555555555555555ull) + rotl64(p[(i-16)%16],((i-16)%16)+1) + rotl64(p[(i-13)%16],((i-13)%16)+1) - rotl64(p[(i-6)%16],((i-6)%16)+1) ) ^ H[(i-16+7)%16] );
}

for(i = (N + 16); i < 32; i++)//tweak
{
p2[i]     = p2[i - 16]       + r64_01(p2[i - 15]) + p2[i - 14]        + r64_02(p2[i - 13])
	                       + p2[i - 12]       + r64_03(p2[i - 11]) + p2[i - 10]        + r64_04(p2[i -  9])
						   + p2[i -  8]       + r64_05(p2[i -  7]) + p2[i -  6]        + r64_06(p2[i -  5])
						   + p2[i -  4]       + r64_07(p2[i -  3]) + s64_4( p2[i -  2] ) + s64_5(p2[i -  1])
						   + ( ( i*(0x0555555555555555ull) + rotl64(p[(i-16)%16],((i-16)%16)+1) + rotl64(p[(i-13)%16],((i-13)%16)+1) - rotl64(p[(i-6)%16],((i-6)%16)+1) ) ^ H[(i-16+7)%16] );
}

/*  Compute the double chaining pipe for the next message block. */
XL = p2[16]^p2[17]^p2[18]^p2[19]^p2[20]^p2[21]^p2[22]^p2[23];
XH = XL ^ p2[24]^p2[25]^p2[26]^p2[27]^p2[28]^p2[29]^p2[30]^p2[31];

p2[0] =          (shl64(XH, 5) ^ shr64(p2[16],5) ^ p[ 0]) + (XL ^ p2[24] ^ p2[ 0]);
p2[1] =          (shr64(XH, 7) ^ shl64(p2[17],8) ^ p[ 1]) + (XL ^ p2[25] ^ p2[ 1]);
p2[2] =          (shr64(XH, 5) ^ shl64(p2[18],5) ^ p[ 2]) + (XL ^ p2[26] ^ p2[ 2]);
p2[3] =          (shr64(XH, 1) ^ shl64(p2[19],5) ^ p[ 3]) + (XL ^ p2[27] ^ p2[ 3]);
p2[4] =          (shr64(XH, 3) ^       p2[20]    ^ p[ 4]) + (XL ^ p2[28] ^ p2[ 4]);
p2[5] =          (shl64(XH, 6) ^ shr64(p2[21],6) ^ p[ 5]) + (XL ^ p2[29] ^ p2[ 5]);
p2[6] =          (shr64(XH, 4) ^ shl64(p2[22],6) ^ p[ 6]) + (XL ^ p2[30] ^ p2[ 6]);
p2[7] =          (shr64(XH,11) ^ shl64(p2[23],2) ^ p[ 7]) + (XL ^ p2[31] ^ p2[ 7]);
                 
p2[ 8] = rotl64(p2[4], 9) + (XH ^ p2[24] ^ p[ 8]) + (shl64(XL,8) ^ p2[23] ^ p2[ 8]);
p2[ 9] = rotl64(p2[5],10) + (XH ^ p2[25] ^ p[ 9]) + (shr64(XL,6) ^ p2[16] ^ p2[ 9]);
p2[10] = rotl64(p2[6],11) + (XH ^ p2[26] ^ p[10]) + (shl64(XL,6) ^ p2[17] ^ p2[10]);
p2[11] = rotl64(p2[7],12) + (XH ^ p2[27] ^ p[11]) + (shl64(XL,4) ^ p2[18] ^ p2[11]);
p2[12] = rotl64(p2[0],13) + (XH ^ p2[28] ^ p[12]) + (shr64(XL,3) ^ p2[19] ^ p2[12]);
p2[13] = rotl64(p2[1],14) + (XH ^ p2[29] ^ p[13]) + (shr64(XL,4) ^ p2[20] ^ p2[13]);
p2[14] = rotl64(p2[2],15) + (XH ^ p2[30] ^ p[14]) + (shr64(XL,7) ^ p2[21] ^ p2[14]);
p2[15] = rotl64(p2[3],16) + (XH ^ p2[31] ^ p[15]) + (shr64(XL,2) ^ p2[22] ^ p2[15]);

/*   The hash value is: (p2[8], ..., p2[15]) */
	memcpy( outdata, (unsigned char*)p2, 128);

 }//BMW2_512
/*================================================================*/
unsigned char BMW2_512_test_samples( void )
{
unsigned char    i, block[129], hout[128], temp[128], *abcstring;
unsigned long ii;

static unsigned char BMW2_512_test_1F877C[64] = 
	{0x89,0x87,0xD4,0x58,0xCF,0x27,0xD4,0xC1,0xB1,0xDD,0xD1,0x15,0xFE,0x5C,0x15,0xA6,
0x7A,0xF4,0x31,0x56,0x18,0x12,0xB1,0xD2,0x02,0x8C,0x3A,0xF0,0xA5,0x2F,0xB8,0xF7,
0x33,0x42,0x05,0xCB,0xE0,0x03,0xCE,0xAB,0x14,0x46,0x26,0x15,0x50,0x87,0x0E,0xEA,
0x69,0x21,0xC2,0x31,0x5D,0x75,0x0F,0x9C,0x49,0xAD,0x78,0x77,0x59,0x0A,0x9B,0xDE};
	static unsigned char BMW2_512_test_abc[64] = 
	{0x8F,0x37,0xBE,0xF2,0x64,0x28,0x9F,0x61,0xF3,0xD7,0x13,0x94,0x4D,0x39,0x4A,0x7A,
0xC1,0xDD,0x95,0xD3,0xFE,0x57,0x87,0xB5,0xD3,0x25,0xA3,0x10,0xBC,0x9C,0xD1,0x87,
0x83,0x85,0x2B,0xFE,0xE1,0x2F,0xBD,0xEA,0xAB,0x3A,0xD9,0xA6,0x7F,0x2B,0x65,0x4E,
0x34,0x87,0x14,0xAE,0xD3,0xAC,0xF7,0xD7,0x54,0x8E,0x95,0x59,0x1A,0xF6,0x80,0x46};
	static unsigned char BMW2_512_test_void_string[64] = 
	{0x6A,0x72,0x56,0x55,0xC4,0x2B,0xC8,0xA2,0xA2,0x05,0x49,0xDD,0x5A,0x23,0x3A,0x6A,
0x2B,0xEB,0x01,0x61,0x69,0x75,0x85,0x1F,0xD1,0x22,0x50,0x4E,0x60,0x4B,0x46,0xAF,
0x7D,0x96,0x69,0x7D,0x0B,0x63,0x33,0xDB,0x1D,0x17,0x09,0xD6,0xDF,0x32,0x8D,0x2A,
0x6C,0x78,0x65,0x51,0xB0,0xCC,0xE2,0x25,0x5E,0x8C,0x73,0x32,0xB4,0x81,0x9C,0x0E};
	static unsigned char BMW2_512_test_0[64] = 
	{0x46,0x75,0x80,0xF2,0x8C,0xA0,0xF0,0x52,0x18,0x18,0x05,0xB1,0x7C,0xD7,0x09,0x98,
0xFB,0x24,0xA4,0x4B,0x69,0x79,0xFD,0xD4,0xE8,0xC6,0x9D,0xAA,0xB7,0x79,0x1E,0x8B,
0xEE,0xA6,0xF5,0x77,0x02,0x21,0xA4,0x4E,0x9A,0x11,0xAB,0x12,0xDE,0x62,0x9C,0x81,
0xDE,0x1E,0xEE,0xD0,0x29,0x37,0xF3,0xA0,0x83,0x97,0xF3,0xD4,0x5D,0x88,0x22,0xF6};	
	static unsigned char BMW2_512_test_repeat[64] = 
	{0xBE,0x2E,0xA5,0x22,0x4B,0x45,0xD1,0x44,0x13,0x79,0x58,0x08,0x2F,0xBB,0x1C,0xAE,
0x91,0x58,0xF4,0x57,0x48,0xBC,0xA4,0xD8,0x47,0x0E,0x55,0x01,0xA8,0x94,0x0C,0x1F,
0x14,0x38,0x57,0x6D,0x5F,0x83,0x63,0xE9,0xD5,0xA3,0x15,0xF3,0x17,0x94,0xCA,0xAF,
0xAD,0x4E,0x1B,0x4E,0x1F,0x69,0x23,0xD3,0x7E,0x8D,0x09,0x0A,0xD3,0x06,0x4E,0x15};	

	N = 2;
	/*Len = 24,Msg = "abc", MD =  */ 
	/**/  for(i = 0; i < 128; i++) block[i] = 0;
	block[0]=0x61;block[1]=0x62;block[2]=0x63; block[3]=0x80; block[128-8]=0x18;
	BMW2_512( (unsigned char *)i512p2, block, temp );
	BMW2_512( (unsigned char *)CONST64final, temp, hout );
	 for( i = 0; i < 64; i++ ) if( hout[i+64] != BMW2_512_test_abc[i] ) return( -1 );
	 //for( i = 0; i < 64; i++ ) printf("0x%02X,",hout[i+64]);printf("\n\n"); 

	/*Len = 24,Msg = 1F877C, MD =  */ 
	/**/  for(i = 0; i < 128; i++) block[i] = 0;
	block[0]=0x1F;block[1]=0x87;block[2]=0x7C; block[3]=0x80; block[128-8]=0x18;
	BMW2_512( (unsigned char *)i512p2, block, temp );
	BMW2_512( (unsigned char *)CONST64final, temp, hout );	
	  for( i = 0; i < 64; i++ ) if( hout[i+64] != BMW2_512_test_1F877C[i] ) return( -1 );
	//for( i = 0; i < 64; i++ ) printf("0x%02X,",hout[i+64]);printf("\n\n"); 

	/*  Len = 0,Msg = 00,MD = */ 
	/**/  for(i = 0; i < 128; i++) block[i] = 0;
	block[0]=0x80;
	BMW2_512( (unsigned char *)i512p2, block, temp );
	BMW2_512( (unsigned char *)CONST64final, temp, hout );	
	 for( i = 0; i < 64; i++ ) if( hout[i+64] != BMW2_512_test_void_string[i] ) return( -1 );
	// for( i = 0; i < 64; i++ ) printf("0x%02X,",hout[i+64]);printf("\n\n"); 

	/* Len = 1,Msg = 00,MD =   */
	/**/  for(i = 0; i < 128; i++) block[i] = 0;
	block[0]=0x40; block[128-8]=0x01;
	BMW2_512( (unsigned char *)i512p2, block, temp );
	BMW2_512( (unsigned char *)CONST64final, temp, hout );
	  for( i = 0; i < 64; i++ ) if( hout[i+64] != BMW2_512_test_0[i] ) return( -1 );
	//for( i = 0; i < 64; i++ ) printf("0x%02X,",hout[i+64]);printf("\n\n"); 


	/* Repeat = 16777216
Repeat = 16777216
Text = abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmno
MD = 
BE2EA5224B45D144137958082FBB1CAE9158F45748BCA4D8470E5501A8940C1F
1438576D5F8363E9D5A315F31794CAAFAD4E1B4E1F6923D37E8D090AD3064E15

	16777216*64 *8 = 0x 02 0000 0000 */

	abcstring = "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoabcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmno";
	for(i = 0; i < 128; i++) block[i] = abcstring[i];
	memcpy(hout, (unsigned char *)i512p2, 128);
	for( ii = 0; ii < 16777216/2; ii++ )
	{
		if ((ii % 10000) == 0) printf("%d ", ii/10000);
		BMW2_512( hout, block, hout ); 
	}
	for(i = 0; i < 128; i++) block[i] = 0;
	block[0]=0x80; block[128-4]=0x02;
	BMW2_512( hout, block, hout ); 
	BMW2_512( (unsigned char *)CONST64final, hout, hout );
	//printf("\n\n"); for( i = 0; i < 64; i++ ) printf("0x%02X,",hout[i+64]);printf("\n\n"); 
	for( i = 0; i < 64; i++ ) if( hout[i+64] != BMW2_512_test_repeat[i] ) return( -1 );	


  return( 0 );
}
/*====================================================*/
int main( int argc, char* argv[] )
{
  	
  printf( "\nTEST BMW2_512 :\n" );	 
  if ( BMW2_512_test_samples() == 0 ) printf( "OK.\n" );
  else { printf( "Failed.\n" ); goto failed; }


ok:
  printf( "\nEnd of program. Push a key.\n" );  
  getch();
  return( 0 );
failed:
  printf( "\nEnd of program. Push a key.\n" );  
  getch();
  return( -1 );
}
/*====================================================*/