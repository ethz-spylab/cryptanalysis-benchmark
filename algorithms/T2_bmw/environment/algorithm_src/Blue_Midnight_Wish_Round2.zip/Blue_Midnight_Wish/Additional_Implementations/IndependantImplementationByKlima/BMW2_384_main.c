#include  <stdio.h>
#include  <string.h>
#include  <stdlib.h>
#include  <conio.h>

#define rotl64(x,n)   (((x) << (n)) | ((x) >> (64 - (n))))
#define rotr64(x,n)   (((x) >> n) | ((x) << (64 - (n))))
#define shl64(x,n)   ((x) << (n))
#define shr64(x,n)   ((x) >> (n))

/* Components used for 384 and 512 bit version */
#define s64_0(x)  (shr64((x), 1) ^ shl64((x), 3) ^ rotl64((x),  4) ^ rotl64((x), 37))
#define s64_1(x)  (shr64((x), 1) ^ shl64((x), 2) ^ rotl64((x), 13) ^ rotl64((x), 43))
#define s64_2(x)  (shr64((x), 2) ^ shl64((x), 1) ^ rotl64((x), 19) ^ rotl64((x), 53))
#define s64_3(x)  (shr64((x), 2) ^ shl64((x), 2) ^ rotl64((x), 28) ^ rotl64((x), 59))
#define s64_4(x)  (shr64((x), 1) ^ (x))
#define s64_5(x)  (shr64((x), 2) ^ (x))
#define r64_01(x) rotl64((x),  5)
#define r64_02(x) rotl64((x), 11)
#define r64_03(x) rotl64((x), 27)
#define r64_04(x) rotl64((x), 32)
#define r64_05(x) rotl64((x), 37)
#define r64_06(x) rotl64((x), 43)
#define r64_07(x) rotl64((x), 53)

/* BlueMidnightWish384 initial double chaining pipe */
const unsigned long long i384p2[16] =
{
    0x0001020304050607ull, 0x08090a0b0c0d0e0full,
    0x1011121314151617ull, 0x18191a1b1c1d1e1full,
    0x2021222324252627ull, 0x28292a2b2c2d2e2full,
    0x3031323334353637ull, 0x38393a3b3c3d3e3full,
    0x4041424344454647ull, 0x48494a4b4c4d4e4full,
    0x5051525354555657ull, 0x58595a5b5c5d5e5full,
    0x6061626364656667ull, 0x68696a6b6c6d6e6full,
    0x7071727374757677ull, 0x78797a7b7c7d7e7full
};

const unsigned long long CONST64final[16] =
	{
		0xaaaaaaaaaaaaaaa0ull,  0xaaaaaaaaaaaaaaa1ull,
		0xaaaaaaaaaaaaaaa2ull,  0xaaaaaaaaaaaaaaa3ull, 
		0xaaaaaaaaaaaaaaa4ull,  0xaaaaaaaaaaaaaaa5ull, 
		0xaaaaaaaaaaaaaaa6ull,  0xaaaaaaaaaaaaaaa7ull, 
		0xaaaaaaaaaaaaaaa8ull,  0xaaaaaaaaaaaaaaa9ull, 
		0xaaaaaaaaaaaaaaaaull,  0xaaaaaaaaaaaaaaabull, 
		0xaaaaaaaaaaaaaaacull,  0xaaaaaaaaaaaaaaadull, 
		0xaaaaaaaaaaaaaaaeull,  0xaaaaaaaaaaaaaaafull
	};
unsigned char N;//global variable - number of expandrounds1
/*================================================================*/
void BMW2_512(unsigned char *IV, unsigned char *indata, unsigned char *outdata )
{  //this processes just one block - for the simplicity and verifiability
	// written only for LITTLE endian machines
	
	// only the first block
	unsigned char i;
	unsigned long long XL,XH,tp[16],H[16],p[16],p2[48];

    //this is only for LITTLE endian
	memcpy((unsigned char*)p, indata, 128);
	memcpy((unsigned char*)H, IV, 128);

	for(i = 0; i < 16; i++) tp[ i] = p[i] ^ H[i];  
		
/*  Mix the message block with the previous double pipe. */
	p2[ 0] = s64_0( tp[5]-tp[7]+tp[10]+tp[13]+tp[14]);
	p2[ 1] = s64_1( tp[6]-tp[8]+tp[11]+tp[14]-tp[15]);
	p2[ 2] = s64_2( tp[0]+tp[7]+tp[ 9]-tp[12]+tp[15]);
	p2[ 3] = s64_3( tp[0]-tp[1]+tp[ 8]-tp[10]+tp[13]);
	p2[ 4] = s64_4( tp[1]+tp[2]+tp[ 9]-tp[11]-tp[14]);
	p2[ 5] = s64_0( tp[3]-tp[2]+tp[10]-tp[12]+tp[15]);
	p2[ 6] = s64_1( tp[4]-tp[0]-tp[ 3]-tp[11]+tp[13]);
	p2[ 7] = s64_2( tp[1]-tp[4]-tp[ 5]-tp[12]-tp[14]);
	p2[ 8] = s64_3( tp[2]-tp[5]-tp[ 6]+tp[13]-tp[15]);
	p2[ 9] = s64_4( tp[0]-tp[3]+tp[ 6]-tp[ 7]+tp[14]);
	p2[10] = s64_0( tp[8]-tp[1]-tp[ 4]-tp[ 7]+tp[15]);
	p2[11] = s64_1( tp[8]-tp[0]-tp[ 2]-tp[ 5]+tp[ 9]);
	p2[12] = s64_2( tp[1]+tp[3]-tp[ 6]-tp[ 9]+tp[10]);
	p2[13] = s64_3( tp[2]+tp[4]+tp[ 7]+tp[10]+tp[11]);
	p2[14] = s64_4( tp[3]-tp[5]+tp[ 8]-tp[11]-tp[12]);
	p2[15] = s64_0( tp[12]-tp[4]-tp[6]-tp[ 9]+tp[13]);

	//tweak
	for(i = 0; i < 16; i++) p2[ i] = p2[i] + H[(i+1)%16]; 

/*  This is the Message expansion */
//N = 2; global variable
	
for(i = 16; i < (N + 16); i++)//tweak
{p2[i]     = s64_1(p2[i - 16])  + s64_2(p2[i - 15])  + s64_3(p2[i - 14]  ) + s64_0(p2[i - 13] )
	                       + s64_1(p2[i - 12])  + s64_2(p2[i - 11])  + s64_3(p2[i - 10]  ) + s64_0(p2[i -  9] )
						   + s64_1(p2[i -  8])  + s64_2(p2[i -  7])  + s64_3(p2[i -  6]  ) + s64_0(p2[i -  5] )
						   + s64_1(p2[i -  4])  + s64_2(p2[i -  3])  + s64_3(p2[i -  2]  ) + s64_0(p2[i -  1] )
						   + ( ( i*(0x0555555555555555ull) + rotl64(p[(i-16)%16],((i-16)%16)+1) + rotl64(p[(i-13)%16],((i-13)%16)+1) - rotl64(p[(i-6)%16],((i-6)%16)+1) ) ^ H[(i-16+7)%16] );
}

for(i = (N + 16); i < 32; i++)//tweak
{
p2[i]     = p2[i - 16]       + r64_01(p2[i - 15]) + p2[i - 14]        + r64_02(p2[i - 13])
	                       + p2[i - 12]       + r64_03(p2[i - 11]) + p2[i - 10]        + r64_04(p2[i -  9])
						   + p2[i -  8]       + r64_05(p2[i -  7]) + p2[i -  6]        + r64_06(p2[i -  5])
						   + p2[i -  4]       + r64_07(p2[i -  3]) + s64_4( p2[i -  2] ) + s64_5(p2[i -  1])
						   + ( ( i*(0x0555555555555555ull) + rotl64(p[(i-16)%16],((i-16)%16)+1) + rotl64(p[(i-13)%16],((i-13)%16)+1) - rotl64(p[(i-6)%16],((i-6)%16)+1) ) ^ H[(i-16+7)%16] );
}

/*  Compute the double chaining pipe for the next message block. */
XL = p2[16]^p2[17]^p2[18]^p2[19]^p2[20]^p2[21]^p2[22]^p2[23];
XH = XL ^ p2[24]^p2[25]^p2[26]^p2[27]^p2[28]^p2[29]^p2[30]^p2[31];

p2[0] =          (shl64(XH, 5) ^ shr64(p2[16],5) ^ p[ 0]) + (XL ^ p2[24] ^ p2[ 0]);
p2[1] =          (shr64(XH, 7) ^ shl64(p2[17],8) ^ p[ 1]) + (XL ^ p2[25] ^ p2[ 1]);
p2[2] =          (shr64(XH, 5) ^ shl64(p2[18],5) ^ p[ 2]) + (XL ^ p2[26] ^ p2[ 2]);
p2[3] =          (shr64(XH, 1) ^ shl64(p2[19],5) ^ p[ 3]) + (XL ^ p2[27] ^ p2[ 3]);
p2[4] =          (shr64(XH, 3) ^       p2[20]    ^ p[ 4]) + (XL ^ p2[28] ^ p2[ 4]);
p2[5] =          (shl64(XH, 6) ^ shr64(p2[21],6) ^ p[ 5]) + (XL ^ p2[29] ^ p2[ 5]);
p2[6] =          (shr64(XH, 4) ^ shl64(p2[22],6) ^ p[ 6]) + (XL ^ p2[30] ^ p2[ 6]);
p2[7] =          (shr64(XH,11) ^ shl64(p2[23],2) ^ p[ 7]) + (XL ^ p2[31] ^ p2[ 7]);
                 
p2[ 8] = rotl64(p2[4], 9) + (XH ^ p2[24] ^ p[ 8]) + (shl64(XL,8) ^ p2[23] ^ p2[ 8]);
p2[ 9] = rotl64(p2[5],10) + (XH ^ p2[25] ^ p[ 9]) + (shr64(XL,6) ^ p2[16] ^ p2[ 9]);
p2[10] = rotl64(p2[6],11) + (XH ^ p2[26] ^ p[10]) + (shl64(XL,6) ^ p2[17] ^ p2[10]);
p2[11] = rotl64(p2[7],12) + (XH ^ p2[27] ^ p[11]) + (shl64(XL,4) ^ p2[18] ^ p2[11]);
p2[12] = rotl64(p2[0],13) + (XH ^ p2[28] ^ p[12]) + (shr64(XL,3) ^ p2[19] ^ p2[12]);
p2[13] = rotl64(p2[1],14) + (XH ^ p2[29] ^ p[13]) + (shr64(XL,4) ^ p2[20] ^ p2[13]);
p2[14] = rotl64(p2[2],15) + (XH ^ p2[30] ^ p[14]) + (shr64(XL,7) ^ p2[21] ^ p2[14]);
p2[15] = rotl64(p2[3],16) + (XH ^ p2[31] ^ p[15]) + (shr64(XL,2) ^ p2[22] ^ p2[15]);

/*   The hash value is: (p2[8], ..., p2[15]) */
	memcpy( outdata, (unsigned char*)p2, 128);

 }//BMW2_512
/*================================================================*/
unsigned char BMW2_384_test_samples( void )
{
unsigned char    i, block[129], hout[128], temp[128], *abcstring;
unsigned long ii;

	static unsigned char BMW2_384_test_repeat[48] = 
	{0x21,0x66,0x67,0x9A,0x1A,0xFC,0x2A,0xF7,0x04,0xE5,0xF7,0xF3,0xA6,0x0E,0x65,0x39,
0x68,0x39,0xDC,0x11,0x43,0xB7,0x57,0xD0,0x31,0xBE,0x18,0x5C,0xD1,0x3B,0x4D,0x46,
0x16,0xD8,0x62,0x44,0x4E,0xAA,0x4B,0x80,0xD6,0xED,0x29,0x57,0x43,0x35,0x9A,0x82};	

	N = 2;
	/* 
Repeat = 16777216
Text = abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmno
MD = 2166679A1AFC2AF704E5F7F3A60E65396839DC1143B757D031BE185CD13B4D4616D862444EAA4B80D6ED295743359A82

	16777216*64 *8 = 0x 02 0000 0000 */

	abcstring = "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoabcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmno";
	for(i = 0; i < 128; i++) block[i] = abcstring[i];
	memcpy(hout, (unsigned char *)i384p2, 128);
	for( ii = 0; ii < 16777216/2; ii++ )
	{
		if ((ii % 10000) == 0) printf("%d ", ii/10000);
		BMW2_512( hout, block, hout ); 
	}
	for(i = 0; i < 128; i++) block[i] = 0;
	block[0]=0x80; block[128-4]=0x02;
	BMW2_512( hout, block, hout ); 
	BMW2_512( (unsigned char *)CONST64final, hout, hout );
	//printf("\n\n"); for( i = 0; i < 48; i++ ) printf("0x%02X,",hout[i+80]);printf("\n\n"); 
	for( i = 0; i < 48; i++ ) if( hout[i+80] != BMW2_384_test_repeat[i] ) return( -1 );	


  return( 0 );
}
/*====================================================*/
int main( int argc, char* argv[] )
{
  	
  printf( "\nTEST BMW2_384 :\n" );	 
  if ( BMW2_384_test_samples() == 0 ) printf( "OK.\n" );
  else { printf( "Failed.\n" ); goto failed; }


ok:
  printf( "\nEnd of program. Push a key.\n" );  
  getch();
  return( 0 );
failed:
  printf( "\nEnd of program. Push a key.\n" );  
  getch();
  return( -1 );
}
/*====================================================*/