#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#include "SHA3api_ref.h"


#ifndef SHA3_DIGESTSIZE
#define SHA3_DIGESTSIZE  32
#endif

#ifndef SHA3_BLOCKSIZE
#define SHA3_BLOCKSIZE   64
#endif

void truncate
(
 char*   d1,   /* data to be truncated */
 char*   d2,   /* truncated data */
 int     len   /* length in bytes to keep */
)
{
        int     i;
        for (i = 0; i < len; i++) d2[i] = d1[i];
}

/* Function to compute the digest */
void hmac_sha3
(
 char*    k,     /* secret key */
 int      lk,    /* length of the key in bytes */
 char*    d,     /* data */
 int      ld,    /* length of data in bytes */
 char*    out,   /* output buffer, at least "t" bytes */
 int      t
)
{
        hashState ictx, octx;
        char      isha[SHA3_DIGESTSIZE], osha[SHA3_DIGESTSIZE];
        char      key[SHA3_DIGESTSIZE];
        char      buf[SHA3_BLOCKSIZE];
        int       i;

        if (lk > SHA3_BLOCKSIZE) {

                hashState         tctx;

                Init(&tctx, 256);
                Update(&tctx, k, lk*8);
                Final(&tctx, key);

                k = key;
                lk = SHA3_DIGESTSIZE;
        }

        /**** Inner Digest ****/

        Init(&ictx, 256);

        /* Pad the key for inner digest */
        for (i = 0; i < lk; ++i) buf[i] = k[i] ^ 0x36;
        for (i = lk; i < SHA3_BLOCKSIZE; ++i) buf[i] = 0x36;

        Update(&ictx, buf, SHA3_BLOCKSIZE*8);
        Update(&ictx, d, ld*8);

        Final(&ictx, isha);

        /**** Outter Digest ****/

        Init(&octx, 256);

        /* Pad the key for outter digest */

        for (i = 0; i < lk; ++i) buf[i] = k[i] ^ 0x5C;
        for (i = lk; i < SHA3_BLOCKSIZE; ++i) buf[i] = 0x5C;

        Update(&octx, buf, SHA3_BLOCKSIZE*8);
        Update(&octx, isha, SHA3_DIGESTSIZE*8);

        Final(&octx, osha);

        /* truncate and print the results */
        t = t > SHA3_DIGESTSIZE ? SHA3_DIGESTSIZE : t;
        truncate(osha, out, t);
}

int main()
{
    /* k  -  secret key */
    int      lk;    /* length of the key in bytes */
    /* d  -  data */
    int      ld;    /* length of data in bytes */
    char     out[SHA3_DIGESTSIZE];   /* output buffer, at least "t" bytes */
    int      t;
	int      i;
	FILE		                *fp_out;

	if ( (fp_out = fopen("HMAC-BMW256.txt", "w")) == NULL ) 
	{
		printf("Couldn't open HMAC-BMW256.txt for write\n");
		return 1;
	}
	fprintf(fp_out,"BMW256-MAC Test Examples\n\n");

	{
		/* Test #1 */
		char d[]   = "Sample #1";
		/* Test #1 */
		/* BMW256-MAC with 64-Byte Key */
		char k[64] =
		{
			0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
			0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
			0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,
			0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f
		};
		lk = 64;
		ld = 9;
		t=SHA3_DIGESTSIZE;
		fprintf(fp_out,"\n");
		fprintf(fp_out,"\n Key: ");
		for (i = 0; i < lk; i++)
		{
			if (i % 4 == 0)
			{
				fprintf(fp_out," ");
			}
			if (i % 16 == 0)
			{
				fprintf(fp_out,"\n     ");
			}
			fprintf(fp_out,"%02X", k[i]&0xFF);
		}
		fprintf(fp_out,"\n\n Key_length: \n     %d",lk);
		fprintf(fp_out,"\n\n Data: \n     '%s'",d);
		fprintf(fp_out,"\n\n Data_length: \n     %d",ld);
		hmac_sha3(k, lk, d, ld, out, t);
		fprintf(fp_out,"\n\n HMAC:");
		for (i = 0; i < t; i++)
		{
			if (i % 4 == 0)
			{
				fprintf(fp_out," ");
			}
			if (i % 16 == 0)
			{
				fprintf(fp_out,"\n     ");
			}
			fprintf(fp_out,"%02X", out[i]&0xFF);
		}
	}

	{
		/* Test #2 */
		char d[]   = "Sample #2";
		/* Test #2 */
		/* BMW256-MAC with 20-Byte Key */
		char k[20] =
		{
			0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,
			0x40, 0x41, 0x42, 0x43
		};
		lk = 20;
		ld = 9;
		t=SHA3_DIGESTSIZE;
		fprintf(fp_out,"\n\n\n\n");
		fprintf(fp_out,"\n Key: ");
		for (i = 0; i < lk; i++)
		{
			if (i % 4 == 0)
			{
				fprintf(fp_out," ");
			}
			if (i % 16 == 0)
			{
				fprintf(fp_out,"\n     ");
			}
			fprintf(fp_out,"%02X", k[i]&0xFF);
		}
		fprintf(fp_out,"\n\n Key_length: \n     %d",lk);
		fprintf(fp_out,"\n\n Data: \n     '%s'",d);
		fprintf(fp_out,"\n\n Data_length: \n     %d",ld);
		hmac_sha3(k, lk, d, ld, out, t);
		fprintf(fp_out,"\n\n HMAC:");
		for (i = 0; i < t; i++)
		{
			if (i % 4 == 0)
			{
				fprintf(fp_out," ");
			}
			if (i % 16 == 0)
			{
				fprintf(fp_out,"\n     ");
			}
			fprintf(fp_out,"%02X", out[i]&0xFF);
		}
	}

	{
		/* Test #3 */
		char d[]   = "The successful verification of a MAC does not completely guarantee that the accompanying message is authentic.";
		/* Test #2 */
		/* BMW256-MAC with 20-Byte Key */
		char k[100] =
		{
			0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0x5f,
			0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f,
			0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x7b, 0x7c, 0x7d, 0x7e, 0x7f,
			0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0x8a, 0x8b, 0x8c, 0x8d, 0x8e, 0x8f,
			0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f,
			0xa0, 0xa1, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xab, 0xac, 0xad, 0xae, 0xaf,
			0xb0, 0xb1, 0xb2, 0xb3
		};
		lk = 100;
		ld = 110;
		t=SHA3_DIGESTSIZE;
		fprintf(fp_out,"\n\n\n\n");
		fprintf(fp_out,"\n Key: ");
		for (i = 0; i < lk; i++)
		{
			if (i % 4 == 0)
			{
				fprintf(fp_out," ");
			}
			if (i % 16 == 0)
			{
				fprintf(fp_out,"\n     ");
			}
			fprintf(fp_out,"%02X", k[i]&0xFF);
		}
		fprintf(fp_out,"\n\n Key_length: \n     %d",lk);
		fprintf(fp_out,"\n\n Data: \n     '%s'",d);
		fprintf(fp_out,"\n\n Data_length: \n     %d",ld);
		hmac_sha3(k, lk, d, ld, out, t);
		fprintf(fp_out,"\n\n HMAC:");
		for (i = 0; i < t; i++)
		{
			if (i % 4 == 0)
			{
				fprintf(fp_out," ");
			}
			if (i % 16 == 0)
			{
				fprintf(fp_out,"\n     ");
			}
			fprintf(fp_out,"%02X", out[i]&0xFF);
		}
	}

	{
		/* Test #4 */
		char d[]   = "The successful verification of a MAC does not completely guarantee that the accompanying message is authentic: there is a chance that a source with no knowledge of the key can present a purported MAC.";
		/* Test #2 */
		/* BMW256-MAC with 20-Byte Key */
		char k[100] =
		{
			0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0x5f,
			0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f,
			0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x7b, 0x7c, 0x7d, 0x7e, 0x7f,
			0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0x8a, 0x8b, 0x8c, 0x8d, 0x8e, 0x8f,
			0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f,
			0xa0, 0xa1, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xab, 0xac, 0xad, 0xae, 0xaf,
			0xb0, 0xb1, 0xb2, 0xb3
		};
		lk = 100;
		ld = 200;
		t=SHA3_DIGESTSIZE;
		fprintf(fp_out,"\n\n\n\n");
		fprintf(fp_out,"\n Key: ");
		for (i = 0; i < lk; i++)
		{
			if (i % 4 == 0)
			{
				fprintf(fp_out," ");
			}
			if (i % 16 == 0)
			{
				fprintf(fp_out,"\n     ");
			}
			fprintf(fp_out,"%02X", k[i]&0xFF);
		}
		fprintf(fp_out,"\n\n Key_length: \n     %d",lk);
		fprintf(fp_out,"\n\n Data: \n     '%s'",d);
		fprintf(fp_out,"\n\n Data_length: \n     %d",ld);
		hmac_sha3(k, lk, d, ld, out, t);
		fprintf(fp_out,"\n\n HMAC:");
		for (i = 0; i < t; i++)
		{
			if (i % 4 == 0)
			{
				fprintf(fp_out," ");
			}
			if (i % 16 == 0)
			{
				fprintf(fp_out,"\n     ");
			}
			fprintf(fp_out,"%02X", out[i]&0xFF);
		}
	}

	fclose(fp_out);
	printf("\n A file HMAC-BMW256.txt has been created with BMW256-MAC test examples.\n\n");
	return 0;
}
