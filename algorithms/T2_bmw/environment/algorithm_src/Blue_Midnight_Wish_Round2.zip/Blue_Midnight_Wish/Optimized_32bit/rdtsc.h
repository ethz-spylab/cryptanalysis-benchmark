
#ifndef RDTSC_H
#define RDTSC_H

#if defined( _MSC_VER )

#define _WIN32
#if defined( _WIN32 )

#include <intrin.h>
#pragma intrinsic( __rdtsc )
__inline volatile unsigned long long read_tsc(void)
{
	return __rdtsc();
}

#else

__inline volatile unsigned long long read_tsc(void)
{   unsigned long lo, hi;
	__asm cpuid __asm rdtsc __asm mov [lo],eax __asm mov [hi],edx ; 
	return (((unsigned long long)hi) << 32) + lo;
}

#endif

#elif defined( __GNUC__ )

__inline volatile unsigned long long read_tsc(void)
{   unsigned long lo, hi;
    asm volatile("cpuid; rdtsc" : "=a" (lo), "=d" (hi)); 
	return (((unsigned long long)hi) << 32) + lo;
}

#else
#error A high resolution timer is not available
#endif

#endif
