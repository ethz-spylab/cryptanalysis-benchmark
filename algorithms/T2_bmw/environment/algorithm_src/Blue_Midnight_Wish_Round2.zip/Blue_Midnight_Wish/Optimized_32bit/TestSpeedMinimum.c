#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include "rdtsc.h"

#include "SHA3api_ref.h"

#define _WIN32
#define DUAL_CORE

#if defined( DUAL_CORE )
#include <windows.h>
#endif

int main()
{
	int		                    i, ii, j, bitlens[4] = { 224, 256, 384, 512 };
    unsigned int                c1 = -1, c2 = -1;
    unsigned volatile long long cy0, cy1, cy2;
	BitSequence	                Msg[100001], MD[64];
	FILE		                *fp_out;

#if defined( DUAL_CORE ) && defined( _WIN32 )
	// we need to constrain the process to one core in order to 
	// obtain meaningful timing data
	HANDLE ph;
	DWORD_PTR afp;
	DWORD_PTR afs;
	ph = GetCurrentProcess();
	if(GetProcessAffinityMask(ph, &afp, &afs))
	{
		afp &= (GetCurrentProcessorNumber() + 1);
		if(!SetProcessAffinityMask(ph, afp))
		{
			printf("Couldn't set Process Affinity Mask\n\n"); return -1;
		}
	}
	else
	{
		printf("Couldn't get Process Affinity Mask\n\n"); return -1;
	}
#endif


	if ( (fp_out = fopen("SpeedTest.txt", "w")) == NULL ) 
	{
		printf("Couldn't open SpeedTest.txt for write\n");
		return 1;
	}
    printf("\n");
	fprintf(fp_out,"\n");

    printf("\nBlueMidnightWish performance in Cycles/Byte with different message lengths in BYTES\n");
	fprintf(fp_out,"\nBlueMidnightWish performance in Cycles/Byte with different message lengths in BYTES\n");

    printf(             "\n                      1       10      100    1000    10000   100000");
	fprintf(fp_out,     "\n                      1       10      100    1000    10000   100000");

	for (i=0; i<100001; i++) Msg[i] = (unsigned char)i;

	
	for ( i=0; i<4; i++ ) 
	{
		printf(        "\nMD Size: %d      ", bitlens[i]);
		fprintf(fp_out,"\nMD Size: %d      ", bitlens[i]);
		
		for(j=1; j<=100000; j*=10)
		{
			cy0 = read_tsc();
			Hash(bitlens[i], Msg, j*8, MD);
			cy1 = read_tsc();
			c1 = cy1 - cy0;
			for(ii=0; ii<10000; ii++ ) 
			{
				cy0 = read_tsc();
				Hash(bitlens[i], Msg, j*8, MD);
				cy1 = read_tsc();
				cy1-=cy0;
				c1 = (unsigned int)(c1 > cy1 ? cy1 : c1);
			}
			printf("%8.2f", ((c1) + 1) / (double)j);
			fprintf(fp_out,"%8.2f", ((c1) + 1) / (double)j);
		}
	}

	fclose(fp_out);
	return 0;
}
