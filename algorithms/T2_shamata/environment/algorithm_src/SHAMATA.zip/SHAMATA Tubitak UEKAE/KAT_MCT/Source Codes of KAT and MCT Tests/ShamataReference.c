/********************************************************************************
 * SHAMATA Reference Code
 * October 2008

 # ShamataReference.c
 # Algorithm Name: SHAMATA
 # Principal Submitter: Orhun KARA
 *******************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include "ShamataReference.h"

// Substitution Box of AES
unsigned int SubByte[256] = { 99, 124, 119, 123, 242, 107, 111, 197,  48,   1, 103,  43, 254, 215, 171, 118, 
							 202, 130, 201, 125, 250,  89,  71, 240, 173, 212, 162, 175, 156, 164, 114, 192, 
							 183, 253, 147,  38,  54,  63, 247, 204,  52, 165, 229, 241, 113, 216,  49,  21, 
							   4, 199,  35, 195,  24, 150,   5, 154,   7,  18, 128, 226, 235,  39, 178, 117, 
							   9, 131,  44,  26,  27, 110,  90, 160,  82,  59, 214, 179,  41, 227,  47, 132, 
							  83, 209,   0, 237,  32, 252, 177,  91, 106, 203, 190,  57,  74,  76,  88, 207, 
							 208, 239, 170, 251,  67,  77,  51, 133,  69, 249,   2, 127,  80,  60, 159, 168,
							  81, 163,  64, 143, 146, 157,  56, 245, 188, 182, 218,  33,  16, 255, 243, 210, 
							 205,  12,  19, 236,  95, 151,  68,  23, 196, 167, 126,  61, 100,  93,  25, 115,
							  96, 129,  79, 220,  34,  42, 144, 136,  70, 238, 184,  20, 222,  94,  11, 219, 
							 224,  50,  58,  10,  73,   6,  36,  92, 194, 211, 172,  98, 145, 149, 228, 121, 
							 231, 200,  55, 109, 141, 213,  78, 169, 108,  86, 244, 234, 101, 122, 174,   8, 
							 186, 120,  37,  46,  28, 166, 180, 198, 232, 221, 116,  31,  75, 189, 139, 138, 
							 112,  62, 181, 102,  72,   3, 246,  14,  97,  53,  87, 185, 134, 193,  29, 158, 
							 225, 248, 152,  17, 105, 217, 142, 148, 155,  30, 135, 233, 206,  85,  40, 223, 
							 140, 161, 137,  13, 191, 230,  66, 104,  65, 153,  45,  15, 176,  84, 187,  22};

/*************************************************************************************************************
 * Hash : Main hash function.
 *************************************************************************************************************/
HashReturn Hash (int hashbitlen, const BitSequence *data, DataLength databitlen, BitSequence *hashval)
{ 
	// Allocate memory for the state
	hashState *state = (hashState *)malloc(sizeof(hashState));

	// The digest lengths are multiples of 32 bits starting from 224 bits up to 512 bits.
	if (hashbitlen%32 != 0 || hashbitlen<160 || hashbitlen>512){
		printf("Bad Hash Bit Length Error!\n");
		return BAD_HASHBITLEN;
	}

	// Initiate the state
	Init(state, hashbitlen);

    // Update the state using data
	Update(state, data, databitlen);

	// Finalize the state and calculate the digest
	Final(state, hashval);

	return SUCCESS;
}

/*************************************************************************************************************
 * Init : Initializes the state registers.
 *************************************************************************************************************/
HashReturn Init (hashState *state, int hashbitlen)
{
	// The following is the initial vector blocks used to initiate the state
	unsigned char IV[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,(char)(hashbitlen>>8),(char)hashbitlen};

	// The followings are looping parameters
	unsigned int i, j;

	// Set hashbitlen, databitlen and remainingdatabitlen
	state->hashbitlen          = hashbitlen; 
	state->databitlen          = 0;
	state->remainingdatabitlen = 0;

	// Set 0 to the state registers (B and K)
	for(i=0;i<4;i++)
		for(j=0;j<4;j++)
			state->B[i][j] = 0;
	for(i=0;i<12;i++)
		for(j=0;j<4;j++)
			state->K[i][j] = 0;

    // Set the following parameter r w.r.t. the digest size
	if(hashbitlen<=256)
		state->r=1;
	else
		state->r=2;
	
	// Set remaingdata to 0
	for(i=0;i<8;i++)
		state->remainingdata[i] = 0;

	// Run UpdateRegister using IV as block
	for(i=0;i<8;i++)
		UpdateRegister(state, IV, state->r, i+1);

	return SUCCESS;
}

/*************************************************************************************************************
 * Update : Updates the state registers using data except padding data.
 *************************************************************************************************************/
HashReturn Update (hashState *state, const BitSequence *data, DataLength databitlen)
{
	// The following calculates the block count which will be processed and the block count processed already. 
	DataLength messageblockcount          = databitlen/128;     
	DataLength processedmessageblockcount = state->databitlen/128;

	// The following declares looping parameter i
	unsigned int i; 
	
	// Check : Update function must be called with a databitlen which is a multiple of 128 if it is not a final call
	if (state->remainingdatabitlen != 0 && databitlen%128 != 0){
        printf("\n\n !!! Update function must be called with a databitlen which is a multiple of 128 if it is not a final call... \n");	
		return FAIL;
	}

	// Update state databitlen and remainingdatabitlen
	state->databitlen          += databitlen;
	state->remainingdatabitlen  = databitlen%128;

	// The following calls UpdateRegister for message blocks
	for(i=0; i<messageblockcount; i++){
		// Call UpdateRegister
		UpdateRegister(state, data+16*i, state->r, i+1+processedmessageblockcount);
	}

	// Set remaining data if it exists 
	for(i=0;i<(state->remainingdatabitlen/8 + (state->remainingdatabitlen%8 == 0 ? 0:1));i++)
		state->remainingdata[i/4] |= data[16*messageblockcount+i] << ((3-i%4)*8);
	
    return SUCCESS;
}

/*************************************************************************************************************
 * Final : Finilizes the state and produces digest.
 *************************************************************************************************************/
HashReturn Final(hashState *state, BitSequence *hashval)
{
	// The following is looping parameter
	unsigned int i;

	// RData is used for temporary data block
	unsigned char RData[16];

	// Calculate number of already processed message blocks
	DataLength processedmessageblockcount = state->databitlen/128;

    // Pad the message and process the calculated block(s)
	if(state->remainingdatabitlen <= 63){   // if remainindatabitlen <= 63 only 1 block will be filled, otherwise 2 blocks is needed
		
		// Add one '1'
		if (state->remainingdatabitlen%32 == 0)
			state->remainingdata[state->remainingdatabitlen/32] &= 0;
		else
			state->remainingdata[state->remainingdatabitlen/32] &= (0xffffffff << (32-(state->remainingdatabitlen%32)));
		state->remainingdata[state->remainingdatabitlen/32] |= (0x80000000 >> (state->remainingdatabitlen%32));

		// Add '0's 
		for(i=state->remainingdatabitlen/32+1;i<2;i++)
			state->remainingdata[i] = 0;
		
		// Add databitlen 
		state->remainingdata[2] = state->databitlen>>32;
		state->remainingdata[3] = state->databitlen;

		// Copy remainingdata to RData in the form of byte array
		for(i=0;i<16;i++)
			RData[i]=(state->remainingdata[i/4]>>(24-8*(i%4)))&0xff;

		// Calculate the current block index
		processedmessageblockcount++;

		// Call the compression function for the RData
		UpdateRegister(state, RData, state->r, processedmessageblockcount);

	}else{

		// Add one '1'
		if (state->remainingdatabitlen%32 == 0)
			state->remainingdata[state->remainingdatabitlen/32] &= 0;
		else
			state->remainingdata[state->remainingdatabitlen/32] &= (0xffffffff << (32-(state->remainingdatabitlen%32)));
		state->remainingdata[state->remainingdatabitlen/32] |= (0x80000000 >> (state->remainingdatabitlen%32));

		// Add '0's
		for(i=state->remainingdatabitlen/32+1;i<6;i++)
			state->remainingdata[i] = 0;

		// Add databitlen 
		state->remainingdata[6] = state->databitlen>>32;
		state->remainingdata[7] = state->databitlen;

		// Copy first 128 bits of remainingdata to RData in the form of byte array
        for(i=0;i<16;i++)
			RData[i]=(state->remainingdata[i/4]>>(24-8*(i%4)))&0xff;

		// Calculate the current block index
		processedmessageblockcount++;

		// Call the compression function for the calculated blocks
        UpdateRegister(state,RData,state->r,processedmessageblockcount);

		// Copy last 128 bits of remainingdata to RData int the form of byte array
		for(i=16;i<32;i++)
			RData[i-16]=(state->remainingdata[i/4]>>(24-8*(i%4)))&0xff;
     
		// Calculate the current block index
		processedmessageblockcount++;

		// Call the compression function for the calculated blocks
		UpdateRegister(state,RData,state->r,processedmessageblockcount);
	}

	// Copy number of message block count to RData in the form of byte array
	for(i=0;i<16;i++)
		RData[i]=(processedmessageblockcount>>(120-8*(i%16)));

	// Call UpdateRegister 32 times using the number of message blocks as block
	for(i=0;i<32;i++)
		UpdateRegister(state,RData,state->r,i+1);

	// Produce hash value
	ProduceOutput(state,hashval);	

	return SUCCESS;
}

/*************************************************************************************************************
 * ProduceOutput : Produces the digest using the register B.
 *************************************************************************************************************/
HashReturn ProduceOutput(hashState *state, BitSequence *hashval)
{
	// The following is looping parameter
	unsigned int i;

	// Produces the digest. The digest is the first hashbitlen least significant bits of the register B.
	for(i=0;i<state->hashbitlen/8;i++)
		hashval[(state->hashbitlen/8)-1-i]=(state->B[3-i/16][3-(i/4)%4]>>(8*i)%32)&0xff;


	return SUCCESS;
}

/*************************************************************************************************************
 * UpdateRegister : Updates the registers using one data block.
 *************************************************************************************************************/
HashReturn UpdateRegister(hashState *state, const BitSequence *data, unsigned int r, unsigned long long blockno)
{
	// Load message block
	LoadDataBlock(state, data, blockno);
	
	// Clock the registers 2 times
    ClockRegister(state, r);

	return SUCCESS;
}


/*************************************************************************************************************
 * LoadDataBlock : Loads an extended copy of the given data block and its index blockno into the registers B and K.
 *************************************************************************************************************/
HashReturn LoadDataBlock(hashState *state, const BitSequence *data, unsigned long long blockno)
{
	// P2 is for P' and Q2 is for Q'
	unsigned int P[4]={0}, Q[4]={0}, P2[4], Q2[4], i;
	
	// MixColumn(data)                    
    for(i=0;i<4;i++)
		Q[i] = ((MULT8_BY_2(data[i]) ^ MULT8_BY_3(data[i+4]) ^            data[i+8]  ^            data[i+12])  << 24) | 
		       ((           data[i]  ^ MULT8_BY_2(data[i+4]) ^ MULT8_BY_3(data[i+8]) ^            data[i+12])  << 16) | 
			   ((           data[i]  ^            data[i+4]  ^ MULT8_BY_2(data[i+8]) ^ MULT8_BY_3(data[i+12])) <<  8) | 
			   ((MULT8_BY_3(data[i]) ^            data[i+4]  ^            data[i+8]  ^ MULT8_BY_2(data[i+12])) <<  0);

	// MixColumn(transpose of data) 
	for(i=0;i<4;i++)
		P[i] = ((MULT8_BY_2(data[4*i]) ^ MULT8_BY_3(data[4*i+1]) ^            data[4*i+2]  ^            data[4*i+3])  << 24) | 
		       ((           data[4*i]  ^ MULT8_BY_2(data[4*i+1]) ^ MULT8_BY_3(data[4*i+2]) ^            data[4*i+3])  << 16) | 
			   ((           data[4*i]  ^            data[4*i+1]  ^ MULT8_BY_2(data[4*i+2]) ^ MULT8_BY_3(data[4*i+3])) <<  8) | 
			   ((MULT8_BY_3(data[4*i]) ^            data[4*i+1]  ^            data[4*i+2]  ^ MULT8_BY_2(data[4*i+3])) <<  0);

	// Calculate P' and Q'
	P2[0]=P[2];	P2[1]=P[3];	P2[2]=Q[0];	P2[3]=Q[1];
	Q2[0]=Q[2];	Q2[1]=Q[3];	Q2[2]=P[0];	Q2[3]=P[1];

	// Load (P xor blockno) to B2
	state->B[2][0]^=P[0];
	state->B[2][1]^=P[1];
	state->B[2][2]^=(P[2]^((unsigned int)(blockno>>32)));
	state->B[2][3]^=(P[3]^(unsigned int)blockno);

	// Load (Q xor blockno) to B3
	state->B[3][0]^=Q[0];
	state->B[3][1]^=Q[1];
	state->B[3][2]^=(Q[2]^((unsigned int)(blockno>>32)));
	state->B[3][3]^=(Q[3]^(unsigned int)blockno);

	// Load P' to K3
	state->K[3][0]^=P2[0];
	state->K[3][1]^=P2[1];
	state->K[3][2]^=P2[2];
	state->K[3][3]^=P2[3];

	// Load Q to K5
	state->K[5][0]^=Q[0];
	state->K[5][1]^=Q[1];
	state->K[5][2]^=Q[2];
	state->K[5][3]^=Q[3];

	// Load P to K7
	state->K[7][0]^=P[0];
	state->K[7][1]^=P[1];
	state->K[7][2]^=P[2];
	state->K[7][3]^=P[3];

	// Load Q' to K11
	state->K[11][0]^=Q2[0];
	state->K[11][1]^=Q2[1];
	state->K[11][2]^=Q2[2];
	state->K[11][3]^=Q2[3];

	return SUCCESS;
}


/*************************************************************************************************************
 * ClockRegister : It is used to update the contents of B and K registers using the modified AES round function (ARF).
 *************************************************************************************************************/
HashReturn ClockRegister(hashState *state, unsigned int r)
{
	// The following declares temporary and loop variables
    unsigned int i, j, k;
	unsigned int tmp1[4], FeedB[4], FeedK[4];

	// Clock the registers 2 times
	for(k=0;k<2;k++){

		// Copy B2 to tmp1
		for(i=0;i<4;i++)
			tmp1[i] = state->B[2][i];

		// Apply ARF function
		for(i=0;i<r;i++)
			ARF(tmp1);

		// Calculate FeedK
		FeedK[0]=tmp1[0]^state->B[0][0];
		FeedK[1]=tmp1[1]^state->B[0][1];
		FeedK[2]=tmp1[2]^state->B[0][2];
		FeedK[3]=tmp1[3]^state->B[0][3];

		// Calculate FeedB
		FeedB[0]=(FeedK[0]^state->K[9][0])^state->K[0][0];
		FeedB[1]=(FeedK[1]^state->K[9][1])^state->K[0][1];
		FeedB[2]=(FeedK[2]^state->K[9][2])^state->K[0][2];
		FeedB[3]=(FeedK[3]^state->K[9][3])^state->K[0][3];

		// Shift the B registers to the left one time 
		for(i=0;i<3;i++)
			for(j=0;j<4;j++)
				state->B[i][j] = state->B[i+1][j];
		
		// Write FeedB to B3
		for(j=0;j<4;j++)
				state->B[3][j] = FeedB[j];
		
		// Shift the K registers to the left one time
		for(i=0;i<11;i++)
			for(j=0;j<4;j++)
				state->K[i][j] = state->K[i+1][j];
		
		// Write FeedK to K11
		for(j=0;j<4;j++)
				state->K[11][j] = FeedK[j];
	}

	return SUCCESS;
}

/*************************************************************************************************************
 * ARF : It is the AES round function without key addition.
 *************************************************************************************************************/
HashReturn ARF (unsigned int *input)
{
	// The followings are looping parameters
	int i,m,j;

	// state is used as in AES
    unsigned char state[4][4],tmp2;

	// copy data to state
	for(i=0;i<4;i++)
		for(j=0;j<4;j++)
		    state[j][i] = ((input[i] >> ((3-j)*8))&0xff);

	// SubByte
	for(i=0;i<4;i++)
		for(j=0;j<4;j++)
			state[i][j] = SubByte[state[i][j]];

	// ShiftRow
	for(i=0;i<4;i++)
		for(m=0;m<i;m++){
			tmp2=state[i][0];
			for(j=0;j<3;j++)
				state[i][j]=state[i][j+1];
			state[i][3]=tmp2;
		}

    // MixColumn                     
    for(i=0;i<4;i++)
		input[i] = ((MULT8_BY_2(state[0][i]) ^ MULT8_BY_3(state[1][i]) ^            state[2][i]  ^            state[3][i])  << 24) | 
			       ((           state[0][i]  ^ MULT8_BY_2(state[1][i]) ^ MULT8_BY_3(state[2][i]) ^            state[3][i])  << 16) | 
				   ((           state[0][i]  ^            state[1][i]  ^ MULT8_BY_2(state[2][i]) ^ MULT8_BY_3(state[3][i])) <<  8) | 
				   ((MULT8_BY_3(state[0][i]) ^            state[1][i]  ^            state[2][i]  ^ MULT8_BY_2(state[3][i])) <<  0);

	return SUCCESS;
}
