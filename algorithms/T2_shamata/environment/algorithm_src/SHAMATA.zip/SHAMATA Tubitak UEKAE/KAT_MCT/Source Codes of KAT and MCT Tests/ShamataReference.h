/********************************************************************************
 * Header File of SHAMATA Reference Code
 * October 2008

 # ShamataReference.h
 # Algorithm Name: SHAMATA
 # Principal Submitter: Orhun KARA
 *******************************************************************************/

// The followings are for multiplication over GF(2^8) with the primitive polynomial (x^8 + x^4 + x^3 + x + 1) for AES round
#define R_f8 0x1b                                                // Primitive polynomial remainder
#define MULT8_BY_2(x) (((x<<1)&0xff) ^ ((x>>7) == 1 ? R_f8 : 0)) // Multiplication by x over GF(2^8)
#define MULT8_BY_3(x) (MULT8_BY_2(x) ^ x)                        // Multiplication by (x + 1) over GF(2^8)

// Data definitions 
typedef unsigned char BitSequence;
typedef unsigned long long DataLength;
typedef enum {SUCCESS = 0, FAIL = 1, BAD_HASHBITLEN = 2} HashReturn;
typedef enum {MESSAGEBLOCK = 0, PARITYBLOCK = 1} BlockType;

// Data structure
typedef struct {
     unsigned int B[4][4], K[12][4];   // State registers
	 unsigned int r;                   // Number of ARF in clocking register
	 unsigned int hashbitlen;          // Hash bit length
	 unsigned int remainingdatabitlen; // databitlen%128
	 unsigned int remainingdata[8];    // The last databitlen%128 bits data in the input data of the hash function
	 DataLength databitlen;            // Data bit length
     } hashState;

// Hash : Main hash function.
HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen, BitSequence *hashval);

// Init : Initializes the state registers.
HashReturn Init(hashState *state, int hashbitlen);

// Update : Updates the state registers using data except padding data.
HashReturn Update(hashState *state, const BitSequence *data, DataLength databitlen);

// Final : Finilizes the state and produces digest.
HashReturn Final(hashState *state, BitSequence *hashval);

// ProduceOutput : Produces the digest using the register B.
HashReturn ProduceOutput(hashState *state, BitSequence *hashval);

// UpdateRegister : Updates the registers using one data block.
HashReturn UpdateRegister(hashState *state, const BitSequence *data, unsigned int r, unsigned long long blockno);

// LoadDataBlock : Loads an extended copy of the given data block and its index blockno into the registers B and K.
HashReturn LoadDataBlock(hashState *state, const BitSequence *data, unsigned long long blockno);

// ClockRegister : It is used to update the contents of B and K registers using the modified AES round function (ARF).
HashReturn ClockRegister(hashState *state, unsigned int r);

// ARF : It is the AES round function without key addition.
HashReturn ARF (unsigned int *input);
