# README.txt
# Algorithm Name: SHAMATA
# Principal Submitter: Orhun KARA

This README file lists all files that are included on this disc with a brief description of each. 

\README.txt					
	List of all files with brief description of each.


\Supporting Documentation\SHAMATA Specification.pdf
	Electronic version of the supporting documentation

\Supporting Documentation\Statement by Submitter.pdf
	Statement by Submitter

\Supporting Documentation\ferhat_Statement by Reference Implementation Owner.pdf
	Statement by Ferhat Karako�

\Supporting Documentation\cevat_Statement by Reference Implementation Owner.pdf
	Statement by Cevat Manap

\Supporting Documentation\adem_Statement by Reference Implementation Owner.pdf
	Statement by Adem Atalay

\Supporting Documentation\COVER SHEET.pdf
	Cover Sheet of specification document

\Supporting Documentation\UEKAEOwners.pdf
	Statement by Authorized Representative of Owner


\Optimized_32 bit\ShamataOptimized_32bit.h 	
	32-Bit Optimized ANSI C Header File of SHAMATA.

\Optimized_32 bit\ShamataOptimized_32bit.c 	
	32-Bit Optimized ANSI C Code of SHAMATA, this code does not contain main function. This can be used as API.

\Optimized_64 bit\ShamataOptimized_64bit.h 	
	64-Bit Optimized ANSI C Header File of SHAMATA.

\Optimized_64 bit\ShamataOptimized_64bit.c 	
	64-Bit Optimized ANSI C Code of SHAMATA, this code does not contain main function. This can be used as API.


\Reference Implementation\ShamataReference.h 	
	Reference ANSI C Header File of SHAMATA.

\Reference Implementation\ShamataReference.c 
	Reference ANSI C Code of SHAMATA, this code does not contain main  function. This can be used as API. 


\KAT_MCT\Source Code of Intermediate Values KAT\IntermediateValuesKAT_1Block_224.c
	This ANSI C code generates intermediate values for 1-block 224-bit message digest calculation  

\KAT_MCT\Source Code of Intermediate Values KAT\IntermediateValuesKAT_1Block_256.c
	This ANSI C code generates intermediate values for 1-block 256-bit message digest calculation 

\KAT_MCT\Source Code of Intermediate Values KAT\IntermediateValuesKAT_1Block_384.c
	This ANSI C code generates intermediate values for 1-block 384-bit message digest calculation 

\KAT_MCT\Source Code of Intermediate Values KAT\IntermediateValuesKAT_1Block_512.c
	This ANSI C code generates intermediate values for 1-block 512-bit message digest calculation 

\KAT_MCT\Source Code of Intermediate Values KAT\IntermediateValuesKAT_2Blocks_224.c
	This ANSI C code generates intermediate values for 2-block 224-bit message digest calculation  

\KAT_MCT\Source Code of Intermediate Values KAT\IntermediateValuesKAT_2Blocks_256.c
	This ANSI C code generates intermediate values for 2-block 256-bit message digest calculation 

\KAT_MCT\Source Code of Intermediate Values KAT\IntermediateValuesKAT_2Blocks_384.c
	This ANSI C code generates intermediate values for 2-block 384-bit message digest calculation 

\KAT_MCT\Source Code of Intermediate Values KAT\IntermediateValuesKAT_2Blocks_512.c
	This ANSI C code generates intermediate values for 2-block 512-bit message digest calculation 

\KAT_MCT\Source Codes of KAT and MCT Tests\SHAMATA_KAT_MCT_ref.c
	This ANSI C code generates Short Message Kat, Long Message Kat, Extremely Long Message KAT and Monte Carlo Test values with using Reference Implementation ANSI C code as API in 224,256,284 and 512 degist sizes

\KAT_MCT\Source Codes of KAT and MCT Tests\ShamataReference.h
	This is the Reference Implementation ANSI C Header File in API format which is used in SHAMATA_KAT_MCT_ref.c

\KAT_MCT\Source Codes of KAT and MCT Tests\ShamataReference.c
	This is the Reference Implementation ANSI C code in API format which is used in SHAMATA_KAT_MCT_ref.c

\KAT_MCT\Source Codes of KAT and MCT Tests\SHAMATA_KAT_MCT_32bit_Optimized.c
	This 32 bit Optimized ANSI C code generates Short Message Kat, Long Message Kat, Extremely Long Message KAT and Monte Carlo Test values with using Reference Implementation ANSI C code as API in 224,256,284 and 512 degist sizes

\KAT_MCT\Source Codes of KAT and MCT Tests\ShamataOptimized_32bit.h
	This is the 32 bit Optimized Implementation Header File in API format which is used in SHAMATA_KAT_MCT_ref.c

\KAT_MCT\Source Codes of KAT and MCT Tests\ShamataOptimized_32bit.c
	This is the 32 bit Optimized Implementation ANSI C code in API format which is used in SHAMATA_KAT_MCT_ref.c

\KAT_MCT\Source Codes of KAT and MCT Tests\SHAMATA_KAT_MCT_64bit_Optimized.c
	This 64 bit Optimized ANSI C code generates Short Message Kat, Long Message Kat, Extremely Long Message KAT and Monte Carlo Test values with using Reference Implementation ANSI C code as API in 224,256,284 and 512 degist sizes

\KAT_MCT\Source Codes of KAT and MCT Tests\ShamataOptimized_64bit.h
	This is the 64 bit Optimized Implementation Header File in API format which is used in SHAMATA_KAT_MCT_ref.c

\KAT_MCT\Source Codes of KAT and MCT Tests\ShamataOptimized_64bit.c
	This is the 64 bit Optimized Implementation ANSI C code in API format which is used in SHAMATA_KAT_MCT_ref.c

\KAT_MCT\Source Codes of KAT and MCT Tests\ShortMsgKAT.txt
	Data file for Short Message Kat Test

\KAT_MCT\Source Codes of KAT and MCT Tests\LongMsgKAT.txt
	Data file for Long Message Kat Test

\KAT_MCT\Source Codes of KAT and MCT Tests\ExtremelyLongMsgKAT.txt
	Data file for Extremely Long Message Kat Test

\KAT_MCT\Source Codes of KAT and MCT Tests\MonteCarlo.txt
	Data file for Monte Carlo Test

\KAT_MCT\ShortMsgKAT_224.txt			
	Result of Known Answer Test (KAT) with using messages have the length of 0-2047 bits in 224 bit hash value mode

\KAT_MCT\ShortMsgKAT_256.txt			
	Result of Known Answer Test (KAT) with using messages have the length of 0-2047 bits in 256 bit hash value mode

\KAT_MCT\ShortMsgKAT_384.txt			
	Result of Known Answer Test (KAT) with using messages have the length of 0-2047 bits in 384 bit hash value mode

\KAT_MCT\ShortMsgKAT_512.txt			
	Result of Known Answer Test (KAT) with using messages have the length of 0-2047 bits in 512 bit hash value mode

\KAT_MCT\LongMsgKAT_224.txt			
	Result of Known Answer Test (KAT) with using messages have the length of 2048-34304 bits in 224 bit hash value mode

\KAT_MCT\LongMsgKAT_256.txt			
	Result of Known Answer Test (KAT) with using messages have the length of 2048-34304 bits in 256 bit hash value mode

\KAT_MCT\LongMsgKAT_384.txt			
	Result of Known Answer Test (KAT) with using messages have the length of 2048-34304 bits in 384 bit hash value mode

\KAT_MCT\LongMsgKAT_512.txt			
	Result of Known Answer Test (KAT) with using messages have the length of 2048-34304 bits in 512 bit hash value mode

\KAT_MCT\ExtremelyLongMsgKAT_224.txt		
	Result of Known Answer Test (KAT) with using a message have the length of 4gb in 224 bit hash value mode

\KAT_MCT\ExtremelyLongMsgKAT_256.txt		
	Result of Known Answer Test (KAT) with using a message have the length of 4gb in 256 bit hash value mode

\KAT_MCT\ExtremelyLongMsgKAT_384.txt		
	Result of Known Answer Test (KAT) with using a message have the length of 4gb in 384 bit hash value mode

\KAT_MCT\ExtremelyLongMsgKAT_512.txt		
	Result of Known Answer Test (KAT) with using a message have the length of 4gb in 512 bit hash value mode

\KAT_MCT\MonteCarlo_224.txt			
	Result of Monte Carlo Test(MCT) in 224 bit hash value mode

\KAT_MCT\MonteCarlo_256.txt			
	Result of Monte Carlo Test(MCT) in 256 bit hash value mode

\KAT_MCT\MonteCarlo_384.txt			
	Result of Monte Carlo Test(MCT) in 384 bit hash value mode

\KAT_MCT\MonteCarlo_512.txt			
	Result of Monte Carlo Test(MCT) in 512 bit hash value mode

\KAT_MCT\IntermediateValuesKAT_224.txt		
	Intermediate Values for a 1-block and a 2-block 224-bit message digest computation

\KAT_MCT\IntermediateValuesKAT_256.txt		
	Intermediate Values for a 1-block and a 2-block 256-bit message digest computation

\KAT_MCT\IntermediateValuesKAT_384.txt		
	Intermediate Values for a 1-block and a 2-block 384-bit message digest computation

\KAT_MCT\IntermediateValuesKAT_512.txt		
	Intermediate Values for a 1-block and a 2-block 512-bit message digest computation
