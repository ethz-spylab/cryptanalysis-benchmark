#ifndef crypto_encrypt_pqrsa15_H
#define crypto_encrypt_pqrsa15_H

#define crypto_encrypt_pqrsa15_ref_SECRETKEYBYTES 98304
#define crypto_encrypt_pqrsa15_ref_PUBLICKEYBYTES 32768
#define crypto_encrypt_pqrsa15_ref_BYTES 32768
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_encrypt_pqrsa15_ref(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_encrypt_pqrsa15_ref_open(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_encrypt_pqrsa15_ref_keypair(unsigned char *,unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_encrypt_pqrsa15 crypto_encrypt_pqrsa15_ref
#define crypto_encrypt_pqrsa15_open crypto_encrypt_pqrsa15_ref_open
#define crypto_encrypt_pqrsa15_keypair crypto_encrypt_pqrsa15_ref_keypair
#define crypto_encrypt_pqrsa15_BYTES crypto_encrypt_pqrsa15_ref_BYTES
#define crypto_encrypt_pqrsa15_SECRETKEYBYTES crypto_encrypt_pqrsa15_ref_SECRETKEYBYTES
#define crypto_encrypt_pqrsa15_PUBLICKEYBYTES crypto_encrypt_pqrsa15_ref_PUBLICKEYBYTES

#endif
