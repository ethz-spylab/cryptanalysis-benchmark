#ifndef crypto_encrypt_pqrsa25_H
#define crypto_encrypt_pqrsa25_H

#define crypto_encrypt_pqrsa25_ref_SECRETKEYBYTES 100663296LL
#define crypto_encrypt_pqrsa25_ref_PUBLICKEYBYTES 33554432LL
#define crypto_encrypt_pqrsa25_ref_BYTES 33554432LL
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_encrypt_pqrsa25_ref(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_encrypt_pqrsa25_ref_open(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_encrypt_pqrsa25_ref_keypair(unsigned char *,unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_encrypt_pqrsa25 crypto_encrypt_pqrsa25_ref
#define crypto_encrypt_pqrsa25_open crypto_encrypt_pqrsa25_ref_open
#define crypto_encrypt_pqrsa25_keypair crypto_encrypt_pqrsa25_ref_keypair
#define crypto_encrypt_pqrsa25_BYTES crypto_encrypt_pqrsa25_ref_BYTES
#define crypto_encrypt_pqrsa25_SECRETKEYBYTES crypto_encrypt_pqrsa25_ref_SECRETKEYBYTES
#define crypto_encrypt_pqrsa25_PUBLICKEYBYTES crypto_encrypt_pqrsa25_ref_PUBLICKEYBYTES

#endif
