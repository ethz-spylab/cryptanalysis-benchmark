#ifndef crypto_encrypt_pqrsa20_H
#define crypto_encrypt_pqrsa20_H

#define crypto_encrypt_pqrsa20_ref_SECRETKEYBYTES 3145728LL
#define crypto_encrypt_pqrsa20_ref_PUBLICKEYBYTES 1048576LL
#define crypto_encrypt_pqrsa20_ref_BYTES 1048576LL
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_encrypt_pqrsa20_ref(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_encrypt_pqrsa20_ref_open(unsigned char *,unsigned long long *,const unsigned char *,unsigned long long,const unsigned char *);
extern int crypto_encrypt_pqrsa20_ref_keypair(unsigned char *,unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_encrypt_pqrsa20 crypto_encrypt_pqrsa20_ref
#define crypto_encrypt_pqrsa20_open crypto_encrypt_pqrsa20_ref_open
#define crypto_encrypt_pqrsa20_keypair crypto_encrypt_pqrsa20_ref_keypair
#define crypto_encrypt_pqrsa20_BYTES crypto_encrypt_pqrsa20_ref_BYTES
#define crypto_encrypt_pqrsa20_SECRETKEYBYTES crypto_encrypt_pqrsa20_ref_SECRETKEYBYTES
#define crypto_encrypt_pqrsa20_PUBLICKEYBYTES crypto_encrypt_pqrsa20_ref_PUBLICKEYBYTES

#endif
