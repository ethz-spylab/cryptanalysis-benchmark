/*\
\ / Average implementation of EnRUPT32 and EnRUPT64 in irRUPT stream hashing mode of operation for P=2
/ \ Designed and implemented by Sean O'Neil
\ / NIST SHA-3 submission by VEST Corporation
/ \ Released to the public domain by the author on November 1, 2008.
\ /
/ \ #define _ER_w_ 32 for EnRUPT32
\ / #define _ER_w_ 64 for EnRUPT64, proposed for SHA-3
/ \
\ / #define _ER_s_ 1 for non-cryptographic hashing and MACs; minimum hash size = 2*w for any s
/ \ #define _ER_s_ 2 for indistinguishability from random; maximum hash size = 8*w
\ / #define _ER_s_ 3 for resistance to non-adaptive attacks; maximum hash size = 16*w
/ \ #define _ER_s_ 4 for resistance to adaptive attacks; maximum hash size = 24*w
\ / #define _ER_s_ 5 or greater for higher security; maximum hash size = 8*(s-1)*w
/ \
\*/

#ifndef _EnRUPT_h_
#define _EnRUPT_h_

#include "../portEnRUPT.h"

#define _ER_w_				64					/* Word size in bits, w=32 or w=64 */
												/* 2x parallelisable variant */
#define _ER_s_				4					/* Security parameter, 1<=s, default s=4 */

#if (_ER_w_>32)
	#define rotr			rotr64				/* only rotation right is needed */
	#define uw				u64					/* unsigned 64-bit word type for the state */
	#define bswap			bswap64				/* only needed for little-endian architectures */
#else
	#define rotr			rotr32				/* only rotation right is needed */
	#define uw				u32					/* unsigned 32-bit word type for the state */
	#define bswap			bswap32				/* only needed for little-endian architectures */
#endif

#if defined(ENRUPT_1234_BYTE_ORDER)
	#define in_word(x,p)	(x[1]^=bswap(p))
	#define out_word(h,x)	((h)=bswap(x))
#elif defined(ENRUPT_4321_BYTE_ORDER)
	#define in_word(x,p)	(x[1]^=p)
	#define out_word(h,x)	((h)=x)
#else
	#error Unknown endianness! Please define.
#endif

typedef u8					BitSequence;
typedef size_t				DataLength;	/* the largest integer type supported by the environment */
typedef enum _HashReturn
{
	SUCCESS = 0, FAIL = 1, BAD_HASHBITLEN = 2
} HashReturn;

typedef HashReturn dru (void * state, const BitSequence * data, const DataLength databitlen);
typedef HashReturn drf (void * state, BitSequence * hashval);

typedef struct _hashState
{
#if defined(_MSC_VER)||defined(__INTEL_COMPILER)
	__declspec(align(16))
#endif
	uw						x[4+16*(_ER_s_-1)]	/* internal state of H words, two d accumulators and two last r indexes (it's okay if they roll over 2^w) */
#ifdef __GNUC__
	__attribute__ ((aligned (16)))
#endif
	;
	uw						p[16*(_ER_s_-1)+1];	/* input block with a spare word for the padding */
	int						hashbitlen;			/* hash output size in bits */
	int						n;					/* bits in the input block */
	int						H;					/* number of words in the internal state x */
} hashState
;

HashReturn Init (hashState *state, int hashbitlen);
HashReturn Update (hashState *state, const BitSequence *data, DataLength databitlen);
HashReturn Final (hashState *state, BitSequence *hashval);
HashReturn Hash (int hashbitlen, const BitSequence *data, DataLength databitlen, BitSequence *hashval);

#endif
