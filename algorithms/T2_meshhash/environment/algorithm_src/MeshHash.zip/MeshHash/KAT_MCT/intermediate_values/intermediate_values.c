/* usage:
 * intermediate_values m hl [key [m1 [m2] ... ] ] 
 *
 * m = 1: one block message
 *     2: two block message
 *     3: multi messages m1, m2, ...
 * 
 * hl: hashlength
 *
 * key: is the key, if given
 *
 * m1, m2, ...: messages that are processed one after another with update, if m = 3
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "meshhash.h"


int main(int argn, char **argv)
{
	HashReturn error;
	hashState state;
	BitSequence
		hashval[16320],
		*message[2] = {
			(BitSequence *)"Hi World",
			NULL
		};
	int m,hl,i,j,w,k;
	unsigned char *key;

	if (argn < 3)
	{
		printf("Error: Need 2 arguments.\n");
		return 1;
	}

	m = atoi(argv[1]) - 1;
	if (errno || m < 0 || m > 2)
	{
		printf("Error: First argument must be 1, 2 or 3.\n");
		return 1;
	}

	hl = atoi(argv[2]);
	if (errno || hl < 0 || hl > 16320)
	{
		printf("Error: Second argument must be >= 0 and <= 16320.\n");
		return 1;
	}

	if (m == 1)
	{
		w = (hl+63)/64 + 1;
		message[1] = calloc(w*64 + 9, sizeof(BitSequence));
		if (message[1] == NULL)
		{
			printf("Error: Memory allocation failed.\n");
			return 1;
		}
		for (i = 0; i < w; i++)
		{
			message[1][i*8] = '0'+(i%10);
			for (j = 1; j < 8; j++)
				message[1][i*8+j] = 'a'-1+j;
		}
		strcpy((char*)message[1]+8*w, (char*)message[0]);
	}

	if (argn >= 4)
	{
		key = (unsigned char*) argv[3];
		k = strlen(argv[3]);
	}
	else
	{
		key = NULL;
		k = 0;
	}

	if (m < 2)
	{
		printf("######################################################################\n\n");	
		printf("        MeshHash Algorithm\n");
		printf("          Message Digest Length = %i Bit\n\n",hl);
		printf("######################################################################\n\n");	
		printf("%i Block Message Sample\n\n",m+1);
		printf("Input Message:\n\"%s\"\n\n",message[m]);
		if (k > 0)
			printf("Key:\n\"%s\"\n\n",key);
		printf("All further numbers are hexadecimal!\n\n");
		printf("######################################################################\n\n");	

		error = Hash2(hl, message[m], 8*strlen((char*)message[m]), hashval, k, key);
	}
	else
	{
		printf("######################################################################\n\n");	
		printf("        MeshHash Algorithm\n");
		printf("          Message Digest Length = %i Bit\n\n",hl);
		printf("######################################################################\n\n");	
		printf("Multi Message Sample\n\n");
		printf("Input Messages:\n");
		for (i = 4; i < argn; i++)
			printf("\"%s\"\n",argv[i]);
		printf("\n");
		if (k > 0)
			printf("Key:\n\"%s\"\n\n",key);
		printf("All further numbers are hexadecimal!\n\n");
		printf("######################################################################\n\n");	

		error = Init2(&state, hl, k, key);
		if (error != SUCCESS)
			return error;

		for (i = 4; i < argn; i++)
		{
			error = Update(&state, (BitSequence*)argv[i], strlen(argv[i])*8);
			if (error != SUCCESS)
				return error;
		}

		error = Final(&state, hashval);
		if (error != SUCCESS)
			return error;
	}

	return 0;
}



