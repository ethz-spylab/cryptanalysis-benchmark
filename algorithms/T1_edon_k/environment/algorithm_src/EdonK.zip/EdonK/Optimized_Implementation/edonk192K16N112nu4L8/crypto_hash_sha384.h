#ifndef crypto_hash_sha384_H
#define crypto_hash_sha384_H

#include <openssl/rand.h>
#include <stddef.h>
#include <openssl/opensslv.h>
#define crypto_hash_sha384_openssl_VERSION OPENSSL_VERSION_TEXT
#define crypto_hash_sha384_openssl_BYTES 48
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_hash_sha384_openssl(unsigned char *,const unsigned char *,unsigned long long);
#ifdef __cplusplus
}
#endif

#define crypto_hash_sha384 crypto_hash_sha384_openssl
#define crypto_hash_sha384_BYTES crypto_hash_sha384_openssl_BYTES
#define crypto_hash_sha384_IMPLEMENTATION "crypto_hash/sha384/openssl"
#ifndef crypto_hash_sha384_openssl_VERSION
#define crypto_hash_sha384_openssl_VERSION "-"
#endif
#define crypto_hash_sha384_VERSION crypto_hash_sha384_openssl_VERSION

#endif
