#ifndef crypto_kem_edonk128K32N96nu4L4_H
#define crypto_kem_edonk128K32N96nu4L4_H

#define crypto_kem_edonk128K32N96nu4L4_ref_SECRETKEYBYTES 32
#define crypto_kem_edonk128K32N96nu4L4_ref_PUBLICKEYBYTES 1680
#define crypto_kem_edonk128K32N96nu4L4_ref_CIPHERTEXTBYTES 1568
#define crypto_kem_edonk128K32N96nu4L4_ref_BYTES 32
#define crypto_kem_edonk128K32N96nu4L4_ref_ALGNAME "EdonK128K32N96nu4L4"

int crypto_kem_keypair(unsigned char *pk, unsigned char *sk); 

int crypto_kem_enc(unsigned char *ct, unsigned char *ss, const unsigned char *pk);

int crypto_kem_dec(unsigned char *ss, const unsigned char *ct, const unsigned char *sk);
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_kem_edonk128K32N96nu4L4_ref_keypair(unsigned char *,unsigned char *);
extern int crypto_kem_edonk128K32N96nu4L4_ref_enc(unsigned char *,unsigned char *,const unsigned char *);
extern int crypto_kem_edonk128K32N96nu4L4_ref_dec(unsigned char *,const unsigned char *,const unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_kem_edonk128K32N96nu4L4_keypair crypto_kem_edonk128K32N96nu4L4_ref_keypair
#define crypto_kem_edonk128K32N96nu4L4_enc crypto_kem_edonk128K32N96nu4L4_ref_enc
#define crypto_kem_edonk128K32N96nu4L4_dec crypto_kem_edonk128K32N96nu4L4_ref_dec
#define crypto_kem_edonk128K32N96nu4L4_PUBLICKEYBYTES crypto_kem_edonk128K32N96nu4L4_ref_PUBLICKEYBYTES
#define crypto_kem_edonk128K32N96nu4L4_SECRETKEYBYTES crypto_kem_edonk128K32N96nu4L4_ref_SECRETKEYBYTES
#define crypto_kem_edonk128K32N96nu4L4_BYTES crypto_kem_edonk128K32N96nu4L4_ref_BYTES
#define crypto_kem_edonk128K32N96nu4L4_CIPHERTEXTBYTES crypto_kem_edonk128K32N96nu4L4_ref_CIPHERTEXTBYTES

#endif
