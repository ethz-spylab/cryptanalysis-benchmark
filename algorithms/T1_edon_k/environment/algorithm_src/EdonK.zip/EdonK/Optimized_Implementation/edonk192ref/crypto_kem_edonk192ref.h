#ifndef crypto_kem_edonk192ref_H
#define crypto_kem_edonk192ref_H

#define crypto_kem_edonk192ref_ref_SECRETKEYBYTES 32
#define crypto_kem_edonk192ref_ref_PUBLICKEYBYTES 2192
#define crypto_kem_edonk192ref_ref_CIPHERTEXTBYTES 2736
#define crypto_kem_edonk192ref_ref_BYTES 48
#define crypto_kem_edonk192ref_ref_ALGNAME "EdonK192REF"

int crypto_kem_keypair(unsigned char *pk, unsigned char *sk); 

int crypto_kem_enc(unsigned char *ct, unsigned char *ss, const unsigned char *pk);

int crypto_kem_dec(unsigned char *ss, const unsigned char *ct, const unsigned char *sk);
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_kem_edonk192ref_ref_keypair(unsigned char *,unsigned char *);
extern int crypto_kem_edonk192ref_ref_enc(unsigned char *,unsigned char *,const unsigned char *);
extern int crypto_kem_edonk192ref_ref_dec(unsigned char *,const unsigned char *,const unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_kem_edonk192ref_keypair crypto_kem_edonk192ref_ref_keypair
#define crypto_kem_edonk192ref_enc crypto_kem_edonk192ref_ref_enc
#define crypto_kem_edonk192ref_dec crypto_kem_edonk192ref_ref_dec
#define crypto_kem_edonk192ref_PUBLICKEYBYTES crypto_kem_edonk192ref_ref_PUBLICKEYBYTES
#define crypto_kem_edonk192ref_SECRETKEYBYTES crypto_kem_edonk192ref_ref_SECRETKEYBYTES
#define crypto_kem_edonk192ref_BYTES crypto_kem_edonk192ref_ref_BYTES
#define crypto_kem_edonk192ref_CIPHERTEXTBYTES crypto_kem_edonk192ref_ref_CIPHERTEXTBYTES

#endif
