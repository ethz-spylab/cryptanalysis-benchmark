#define CRYPTO_SECRETKEYBYTES 32
#define CRYPTO_PUBLICKEYBYTES 2256
#define CRYPTO_CIPHERTEXTBYTES 3120
#define CRYPTO_BYTES 48
#define CRYPTO_ALGNAME "EdonK192K32N128nu4L6"

int crypto_kem_keypair(unsigned char *pk, unsigned char *sk); 

int crypto_kem_enc(unsigned char *ct, unsigned char *ss, const unsigned char *pk);

int crypto_kem_dec(unsigned char *ss, const unsigned char *ct, const unsigned char *sk);
