#ifndef crypto_hash_sha256_H
#define crypto_hash_sha256_H

#include <openssl/rand.h>
#include <stddef.h>
#include <openssl/opensslv.h>
#define crypto_hash_sha256_openssl_VERSION OPENSSL_VERSION_TEXT
#define crypto_hash_sha256_openssl_BYTES 32
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_hash_sha256_openssl(unsigned char *,const unsigned char *,unsigned long long);
#ifdef __cplusplus
}
#endif

#define crypto_hash_sha256 crypto_hash_sha256_openssl
#define crypto_hash_sha256_BYTES crypto_hash_sha256_openssl_BYTES
#define crypto_hash_sha256_IMPLEMENTATION "crypto_hash/sha256/openssl"
#ifndef crypto_hash_sha256_openssl_VERSION
#define crypto_hash_sha256_openssl_VERSION "-"
#endif
#define crypto_hash_sha256_VERSION crypto_hash_sha256_openssl_VERSION

#endif
