#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "nist.h"

#define NRUN 100000

void print_state(hashState *s) {
  unsigned int i;

  for (i=0; i<s->n_feistels; i++) {
    printf ("%08x %08x %08x %08x\n", s->A[i], s->B[i], s->C[i], s->D[i]);
  }
}

int main(int argc, char* argv[]) {
  unsigned char* A;
  unsigned char output[64];
  hashState s;
#ifdef rdtsc
  u64 tsc;
#endif
  clock_t t1, t2;
  float dt;
  int i, j;
  u32 c;

  A = malloc(128 + 16);
  /*
   * Align the buffer to a 128 bit boundary.
   */
  A += ((unsigned char*)NULL - A)&15;

  printf("THIS IS VERSION: %s\n", VERSION());

  /* Check implemenation using a fixed message */
  for (i=0; i<128; i++) {
    A[i] = i;
  }
  
  printf("SIMD-256:\n===============\n");

  Init(&s, 256);

  Update(&s, A, 512);
  Final(&s, output);
  print_state(&s);

  /** now benches speed ****/

#ifdef rdtsc
  tsc = rdtsc();
#endif
  t1 = clock();

  for(i=0; i<NRUN; i++)
    SIMD_Compress(&s, A, 0);

#ifdef rdtsc
  tsc = rdtsc() - tsc;
#endif
  t2 = clock();
  dt = (float) (t2 - t1) / CLOCKS_PER_SEC;

  printf ("Time : %g s           (clock)\n", dt);
#ifdef rdtsc
  printf ("Speed: %g cycles/byte (rdtsc)\n", (float)tsc/NRUN/64);
#endif
  printf ("Speed: %g Mbyte/s     (clock)\n", ((float)NRUN/1000000)*64/dt);

  if (Init(&s, 512) == BAD_HASHBITLEN)
    return 0;

  printf("SIMD-512:\n===============\n");

  Update(&s, A, 1024);
  Final(&s, output);
  print_state(&s);

#ifdef rdtsc
  tsc = rdtsc();
#endif
  t1 = clock();

  for(i=0; i<NRUN; i++)
    SIMD_Compress(&s, A, 0);

#ifdef rdtsc
  tsc = rdtsc() - tsc;
#endif
  t2 = clock();
  dt = (float) (t2 - t1) / CLOCKS_PER_SEC;
 
  printf ("Time : %g s           (clock)\n", dt);
#ifdef rdtsc
  printf ("Speed: %g cycles/byte (rdtsc)\n", (float)tsc/NRUN/128);
#endif
  printf ("Speed: %g Mbyte/s     (clock)\n", ((float)NRUN/1000000)*128/dt);

  return 0;
}
