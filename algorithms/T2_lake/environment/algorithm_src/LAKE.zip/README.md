+=============================================================================+
|                                                                             |
|               ***********************************************               |
|               *     POST-QUANTUM CRYPTO STANDARDIZATION     *               |
|               ***********************************************               |
|                                                                             |
|=============================================================================|
|                                                                             |
|        Proposal: LAKE                                                       |
|        Principal Submitters (alphabetical order):                           |
|                  - Nicolas ARAGON                                           |
|                  - Olivier BLAZY                                            |
| [backup contact] - Jean-Christophe DENEUVILLE                               |
| [main contact]   - Philippe GABORIT                                         |
|                  - Adrien HAUTEVILLE                                        |
|                  - Olivier RUATTA                                           |
|                  - Jean-Pierre TILLICH                                      |
|                  - Gilles ZÉMOR                                             |
|                                                                             |
|        Inventors: Same as submitters                                        |
|                                                                             |
|        Developers: Same as submitters                                       |
|                                                                             |
|        Owners: Same as submitters                                           |
|                                                                             |
+=============================================================================+

This archive is a proposal in response to NIST's call for proposal for standar-
dization of quantum-resistant public-key cryptographic algorithms.

LAKE provides POST-QUANTUM CODE-BASED KEY EXCHANGE and targets NIST's security
levels 1, 3, and 5.

This archive is organized as follows:

===============================================================================

.
├── KATs
│   ├── Optimized_Implementation
│   │   ├── LAKE-I
│   │   │   ├── lakeI-verbose.txt : Verbose output for LAKEI
│   │   │   ├── PQCkemKAT_40.req : KAT request for LAKEI
│   │   │   └── PQCkemKAT_40.rsp : KAT response for LAKEI
│   │   ├── LAKE-II
│   │   │   ├── lakeII-verbose.txt : Verbose output for LAKEII
│   │   │   ├── PQCkemKAT_40.req : KAT request for LAKEII
│   │   │   └── PQCkemKAT_40.rsp : KAT response for LAKEII
│   │   └── LAKE-III
│   │       ├── lakeIII-verbose.txt : Verbose output for LAKEIII
│   │       ├── PQCkemKAT_40.req : KAT request for LAKEIII
│   │       └── PQCkemKAT_40.rsp : KAT response for LAKEIII
│   └── Reference_Implementation
│       ├── LAKE-I
│       │   ├── lakeI-verbose.txt : Verbose output for LAKEI
│       │   ├── PQCkemKAT_40.req : KAT request for LAKEI
│       │   └── PQCkemKAT_40.rsp : KAT response for LAKEI
│       ├── LAKE-II
│       │   ├── lakeII-verbose.txt : Verbose output for LAKEII
│       │   ├── PQCkemKAT_40.req : KAT request for LAKEII
│       │   └── PQCkemKAT_40.rsp : KAT response for LAKEII
│       └── LAKE-III
│           ├── lakeIII-verbose.txt : Verbose output for LAKEIII
│           ├── PQCkemKAT_40.req : KAT request for LAKEIII
│           └── PQCkemKAT_40.rsp : KAT response for LAKEIII
├── Optimized_Implementation
│   ├── LAKE-I
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash
│   │   │   │   ├── hash.c : Implementation of hash.h
│   │   │   │   └── hash.h : SHA512 wrapper
│   │   │   └── rng
│   │   │       ├── rng.c : Implementation of rng.h
│   │   │       └── rng.h : NIST provided randomness routines
│   │   ├── Makefile : Makefile to compile code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── decoder.cpp : Implementation of decoder.h
│   │       ├── decoder.h : Rank Support Recover Algorithm
│   │       ├── ffi
│   │       │   ├── ffi_elt.cpp : Implementation of ffi_elt.h
│   │       │   ├── ffi_elt.h : Computations in GF(2^m)
│   │       │   ├── ffi_field.cpp : Implementation of ffi_field.h
│   │       │   ├── ffi_field.h : Parameters for the finite field
│   │       │   ├── ffi.h : Parameters for the finite field
│   │       │   ├── ffi_vec.cpp : Implementation of ffi_vec.h
│   │       │   └── ffi_vec.h : Vector over GF(2^m)
│   │       ├── kem.cpp : Implementation of api.h
│   │       ├── lake_types.h : Types used for LAKE
│   │       ├── main_kat.c : Main file for KAT generation
│   │       ├── main_lake.cpp : Main file for normal and verbose modes
│   │       ├── parameters.h : Parameters of the scheme
│   │       ├── parsing.cpp : Implementation of parsing.h
│   │       └── parsing.h : Conversion from/to lake_types to/from string
│   ├── LAKE-II
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash
│   │   │   │   ├── hash.c : Implementation of hash.h
│   │   │   │   └── hash.h : SHA512 wrapper
│   │   │   └── rng
│   │   │       ├── rng.c : Implementation of rng.h
│   │   │       └── rng.h : NIST provided randomness routines
│   │   ├── Makefile : Makefile to compile code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── decoder.cpp : Implementation of decoder.h
│   │       ├── decoder.h : Rank Support Recover Algorithm
│   │       ├── ffi
│   │       │   ├── ffi_elt.cpp : Implementation of ffi_elt.h
│   │       │   ├── ffi_elt.h : Computations in GF(2^m)
│   │       │   ├── ffi_field.cpp : Implementation of ffi_field.h
│   │       │   ├── ffi_field.h : Parameters for the finite field
│   │       │   ├── ffi.h : Parameters for the finite field
│   │       │   ├── ffi_vec.cpp : Implementation of ffi_vec.h
│   │       │   └── ffi_vec.h : Vector over GF(2^m)
│   │       ├── kem.cpp : Implementation of api.h
│   │       ├── lake_types.h : Types used for LAKE
│   │       ├── main_kat.c : Main file for KAT generation
│   │       ├── main_lake.cpp : Main file for normal and verbose modes
│   │       ├── parameters.h : Parameters of the scheme
│   │       ├── parsing.cpp : Implementation of parsing.h
│   │       └── parsing.h : Conversion from/to lake_types to/from string
│   ├── LAKE-III
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash
│   │   │   │   ├── hash.c : Implementation of hash.h
│   │   │   │   └── hash.h : SHA512 wrapper
│   │   │   └── rng
│   │   │       ├── rng.c : Implementation of rng.h
│   │   │       └── rng.h : NIST provided randomness routines
│   │   ├── Makefile : Makefile to compile code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── decoder.cpp : Implementation of decoder.h
│   │       ├── decoder.h : Rank Support Recover Algorithm
│   │       ├── ffi
│   │       │   ├── ffi_elt.cpp : Implementation of ffi_elt.h
│   │       │   ├── ffi_elt.h : Computations in GF(2^m)
│   │       │   ├── ffi_field.cpp : Implementation of ffi_field.h
│   │       │   ├── ffi_field.h : Parameters for the finite field
│   │       │   ├── ffi.h : Parameters for the finite field
│   │       │   ├── ffi_vec.cpp : Implementation of ffi_vec.h
│   │       │   └── ffi_vec.h : Vector over GF(2^m)
│   │       ├── kem.cpp : Implementation of api.h
│   │       ├── lake_types.h : Types used for LAKE
│   │       ├── main_kat.c : Main file for KAT generation
│   │       ├── main_lake.cpp : Main file for normal and verbose modes
│   │       ├── parameters.h : Parameters of the scheme
│   │       ├── parsing.cpp : Implementation of parsing.h
│   │       └── parsing.h : Conversion from/to lake_types to/from string
│   └── README.md : Implementation README
├── README.md : This file
├── Reference_Implementation
│   ├── LAKE-I
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash
│   │   │   │   ├── hash.c : Implementation of hash.h
│   │   │   │   └── hash.h : SHA512 wrapper
│   │   │   └── rng
│   │   │       ├── rng.c : Implementation of rng.h
│   │   │       └── rng.h : NIST provided randomness routines
│   │   ├── Makefile : Makefile to compile code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── decoder.cpp : Implementation of decoder.h
│   │       ├── decoder.h : Rank Support Recover Algorithm
│   │       ├── ffi
│   │       │   ├── ffi_elt.cpp : Implementation of ffi_elt.h
│   │       │   ├── ffi_elt.h : Computations in GF(2^m)
│   │       │   ├── ffi_field.cpp : Implementation of ffi_field.h
│   │       │   ├── ffi_field.h : Parameters for the finite field
│   │       │   ├── ffi.h : Parameters for the finite field
│   │       │   ├── ffi_vec.cpp : Implementation of ffi_vec.h
│   │       │   └── ffi_vec.h : Vector over GF(2^m)
│   │       ├── kem.cpp : Implementation of api.h
│   │       ├── lake_types.h : Types used for LAKE
│   │       ├── main_kat.c : Main file for KAT generation
│   │       ├── main_lake.cpp : Main file for normal and verbose modes
│   │       ├── parameters.h : Parameters of the scheme
│   │       ├── parsing.cpp : Implementation of parsing.h
│   │       └── parsing.h : Conversion from/to lake_types to/from string
│   ├── LAKE-II
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash
│   │   │   │   ├── hash.c : Implementation of hash.h
│   │   │   │   └── hash.h : SHA512 wrapper
│   │   │   └── rng
│   │   │       ├── rng.c : Implementation of rng.h
│   │   │       └── rng.h : NIST provided randomness routines
│   │   ├── Makefile : Makefile to compile code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── decoder.cpp : Implementation of decoder.h
│   │       ├── decoder.h : Rank Support Recover Algorithm
│   │       ├── ffi
│   │       │   ├── ffi_elt.cpp : Implementation of ffi_elt.h
│   │       │   ├── ffi_elt.h : Computations in GF(2^m)
│   │       │   ├── ffi_field.cpp : Implementation of ffi_field.h
│   │       │   ├── ffi_field.h : Parameters for the finite field
│   │       │   ├── ffi.h : Parameters for the finite field
│   │       │   ├── ffi_vec.cpp : Implementation of ffi_vec.h
│   │       │   └── ffi_vec.h : Vector over GF(2^m)
│   │       ├── kem.cpp : Implementation of api.h
│   │       ├── lake_types.h : Types used for LAKE
│   │       ├── main_kat.c : Main file for KAT generation
│   │       ├── main_lake.cpp : Main file for normal and verbose modes
│   │       ├── parameters.h : Parameters of the scheme
│   │       ├── parsing.cpp : Implementation of parsing.h
│   │       └── parsing.h : Conversion from/to lake_types to/from string
│   ├── LAKE-III
│   │   ├── doc
│   │   │   ├── main_page.txt : Main page for Doxygen documentation
│   │   │   └── refs.bib : References
│   │   ├── doxygen.conf : Doxygen configuration file
│   │   ├── lib
│   │   │   ├── hash
│   │   │   │   ├── hash.c : Implementation of hash.h
│   │   │   │   └── hash.h : SHA512 wrapper
│   │   │   └── rng
│   │   │       ├── rng.c : Implementation of rng.h
│   │   │       └── rng.h : NIST provided randomness routines
│   │   ├── Makefile : Makefile to compile code
│   │   └── src
│   │       ├── api.h : NIST api.h
│   │       ├── decoder.cpp : Implementation of decoder.h
│   │       ├── decoder.h : Rank Support Recover Algorithm
│   │       ├── ffi
│   │       │   ├── ffi_elt.cpp : Implementation of ffi_elt.h
│   │       │   ├── ffi_elt.h : Computations in GF(2^m)
│   │       │   ├── ffi_field.cpp : Implementation of ffi_field.h
│   │       │   ├── ffi_field.h : Parameters for the finite field
│   │       │   ├── ffi.h : Parameters for the finite field
│   │       │   ├── ffi_vec.cpp : Implementation of ffi_vec.h
│   │       │   └── ffi_vec.h : Vector over GF(2^m)
│   │       ├── kem.cpp : Implementation of api.h
│   │       ├── lake_types.h : Types used for LAKE
│   │       ├── main_kat.c : Main file for KAT generation
│   │       ├── main_lake.cpp : Main file for normal and verbose modes
│   │       ├── parameters.h : Parameters of the scheme
│   │       ├── parsing.cpp : Implementation of parsing.h
│   │       └── parsing.h : Conversion from/to lake_types to/from string
│   └── README.md : Implementation README
└── Supporting_Documentation
    └── LAKE_Submission.pdf : Supporting documentation of the scheme

===============================================================================

The authors did their best to make this archive complete and proper.
    
-------------------------------------------------------------------------------

Important note regarding Intellectual Property.

As requested by the NIST, the statements will be sent to Dustin MOODY at the 
address provided by the NIST (see below) *and/or* given to NIST at the first 
PQC Standardization Conference 

Dustin MOODY
Information Technology Laboratory
Attention: Post-Quantum Cryptographic Algorithm Submissions
100 Bureau Drive – Stop 8930
National Institute of Standards and Technology
Gaithersburg, MD 20899-8930

Please note that in the meantime, electronic copies of these statements have
been included in appendix to the supporting documentation.

