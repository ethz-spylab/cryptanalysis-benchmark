FILE:  Readme.txt (in the Optimized_32bit subdirectory)

AUTHOR: Jason Worth Martin

DESCRIPTION: This is identical to the Reference Code for the ESSENCE
hashing algorithm submitted to the NIST hashing competition.  It is
included here only to meet the submission requirements of having a
Optimized_32bit subdirectory.



PORTABILITY ISSUES: This code *assumes* that the "long long" data type
is available and is a 64-bit integer.  That does not mean that the
target needs to be a 64-bit processor, only that the compiler must
support a 64-bit type.  The code also *assumes* that the int data type
is a 32-bit integer.  If that is not correct for your compiler, then
adjust the type definitions in "essence_api.h".  You must have a
64-bit and 32-bit data type available for this code to compile.  Note
that the types "int32_t, uint32_t, int64_t, and uint64_t" are defined
in essence_api.h based on these assumptions.  If you compiler
environment supports the "stdint.h" header file, you may remove the
definitions in essence_api.h and replace them by the same types
included from "stdint.h" This would be the prefered method, however
many older compilers suites do not have the "stdint.h" file but do
have the "long long" data type for 64-bit integers.



 Contents		            Description
---------------           ---------------------------------------

essence_api.h ----------- The header file that should be included by
                          applications wishing to used ESSENCE.  This
                          file contains the algorithm parameters and
                          declarations for the ESSENCE API.

essence_api.c ----------- This file contains the C code to implement
                          the ESSENCE API functions.

essence_compress_256.c -- The ESSENCE 256-bit compression function.

essence_compress_512.c -- The ESSENCE 512-bit compression function.

essence_L_tables.c ------ This file just contains the tables used to
                          implement the L_32 and L_64 linear
                          functions.

essence.h --------------- A header file used internally within the
                          ESSENCE implementation.

verify_essence.c -------- This program verifies that each component of
                          an implementation is correct.  It includes
                          verification that data sizes are correct,
                          verfication that arithmetic shift right
                          copies the sign bit, an exhaustive test of
                          all possible 7-bit inputs to the F function,
                          and an exhaustive test of all the table
                          values used by the L_32 and L_64 functions.
                          If the ESSENCE_DEBUG_LEVEL constant is set
                          to 0x0f, then this program will also
                          generate the intermediate values for test
                          messages for each of the four hash sizes
                          with one and two blocks of input.

genKAT.c ---------------- NIST source code to generate KAT files for
                          required digest sizes.

stress_test.c ----------- An additional test program based on the NIST
			  genKAT code.  This program uses the same
			  messages as the genKAT program, but in
			  addition it compares the results of hashing
			  the message all at once with hashing the
			  same message sequencially by calling the
			  Update function repeatedly taking
			  "step_size" bits at a time.  The value for
			  "step_size" is varied across values that
			  have been choosen to give good code coverage
			  and hit corner cases.  NOTE: The Extremely
			  Long Message is created completely in RAM
			  for this program.  So, the target machine
			  must have enough RAM to hold the entire
			  Extremely Long Message (not just the string
			  that gets repeated).  Otherwise the machine
			  will grind to a halt from disk paging.

ShortMsgKAT.txt --------- Input file for Short Message KAT Test.

LongMsgKAT.txt ---------- Input file for Long Message KAT Test.

ExtremelyLongMsgKAT.txt - Input file for Extremely Long Message KAT
                          Test.

MonteCarlo.txt ---------- Input file for Monte Carlo Test.

Makefile ---------------- A makefile suitable for use on a Unix
                          platform.  The default compiler called in
                          the makefile is gcc, but that can easily be
                          modified.

Makefile_nmake ---------- A makefile suitable for use with the nmake
                          utility in the Microsoft Visual Studio
                          suite.

Readme.txt -------------- This file.
