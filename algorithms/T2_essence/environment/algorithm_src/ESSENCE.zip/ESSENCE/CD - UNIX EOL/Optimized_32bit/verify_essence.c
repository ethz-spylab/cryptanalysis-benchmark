/* FILE: verify_essence.c
 *
 * AUTHOR: Jason Worth Martin <jason.worth.martin@gmail.com>
 *
 * DESCRIPTION:  This file verifies that a given ESSENCE implementation
 * is functioning correctly by going through a series of test vectors
 * designed to exercise all the elements of the compression functions.
 * It also hashes a one and two block message for each hash size.
 *
 * If you want to produce the full output of the intermediate states
 * of the hashing function, then set the ESSENCE_DEBUG_LEVEL to 0x0f
 * in essence_api.h
 * 
 */
#include "essence.h"
#include <stdio.h>
#include <stdlib.h>

typedef enum {success = 0, failure = 1} test_return_value;




/*
 * This is just a simple test to verify that our assumptions
 * on data sizes are correct.
 */
test_return_value verify_data_sizes()
{
  int int32_size;
  int uint32_size;
  int int64_size;
  int uint64_size;
  int DataLength_size;
  test_return_value ecode;

  ecode = success;
  int32_size = (int)sizeof(int32_t);
  uint32_size = (int)sizeof(uint32_t);
  int64_size = (int)sizeof(int64_t);
  uint64_size = (int)sizeof(uint64_t);
  DataLength_size = (int)sizeof(DataLength);

  if (int32_size != 4)
    {
      ecode = failure;
    }
  if (uint32_size != 4)
    {
      ecode = failure;
    }
  if (int64_size != 8)
    {
      ecode = failure;
    }
  if (uint64_size != 8)
    {
      ecode = failure;
    }
  if (DataLength_size != 8)
    {
      ecode = failure;
    }

  if(ecode == failure)
    {
      printf("ERROR!  Data Type Sizes are wrong.\n");
      printf("    int32_t    is %i bytes.  Should be 4\n",int32_size);
      printf("    uint32_t   is %i bytes.  Should be 4\n",uint32_size);
      printf("    int64_t    is %i bytes.  Should be 8\n",int64_size);
      printf("    uint64_t   is %i bytes.  Should be 8\n",uint64_size);
      printf("    DataLength is %i bytes.  Should be 8\n",DataLength_size);
      printf("\n");
      printf("Edit the typedef statements in essence_api.h to fix this.\n");
      printf("Better yet, if you have a C99 compliant stdint.h then use it\n");
      printf("instead and remove the typedef statements.\n\n");
    }
	
  return(ecode);
}



/*
 * This function just verifies that the macros implementing the F
 * function are working correctly.  It tests all possible 7-bit
 * combinations.
 */
test_return_value verify_F()
{
  uint64_t f_low_val = 0x0c9ac1ac7974f57bLL;
  uint64_t f_hi_val  = 0x997083d5c9316b14LL;
  uint64_t tmp_64;
  uint64_t f_test_low[7] = {
    0xaaaaaaaaaaaaaaaaLL,
    0xccccccccccccccccLL,
    0xf0f0f0f0f0f0f0f0LL,
    0xff00ff00ff00ff00LL,
    0xffff0000ffff0000LL,
    0xffffffff00000000LL,
    0x0000000000000000LL
  };

  uint64_t f_test_hi[7] = {
    0xaaaaaaaaaaaaaaaaLL,
    0xccccccccccccccccLL,
    0xf0f0f0f0f0f0f0f0LL,
    0xff00ff00ff00ff00LL,
    0xffff0000ffff0000LL,
    0xffffffff00000000LL,
    0xffffffffffffffffLL
  };
  int i;

  tmp_64 = F_func_Reduced_Normal_Form(f_test_low[6],
				      f_test_low[5],
				      f_test_low[4],
				      f_test_low[3],
				      f_test_low[2],
				      f_test_low[1],
				      f_test_low[0]);
  if (tmp_64 != f_low_val)
    {
      printf("FAILURE!\n");
      printf("Verifying F_func_Reduced_Normal_Form:\n");
      printf("Testing lower order 64 possible inputs\n");
      printf("Input is\n");
      for(i=0;i<7;i++)
	{
	  printf("   f_test_low[%i] = 0x%.16llx\n",i,
		 f_test_low[i]);
	}
      printf("Result should be: 0x%.16llx\n",f_low_val);
      printf("       Result is: 0x%.16llx\n",tmp_64); 
      return(failure);
    }

  tmp_64 = F_func_Reduced_Normal_Form(f_test_hi[6],
				      f_test_hi[5],
				      f_test_hi[4],
				      f_test_hi[3],
				      f_test_hi[2],
				      f_test_hi[1],
				      f_test_hi[0]);
  if (tmp_64 != f_hi_val)
    {
      printf("FAILURE!\n");
      printf("Testing higher order 64 possible inputs\n");
      printf("Input is\n");
      for(i=0;i<7;i++)
	{
	  printf("   f_test_hi[%i] = 0x%.16llx\n",i,
		 f_test_hi[i]);
	}
      printf("Result should be: 0x%.16llx\n",f_hi_val);
      printf("       Result is: 0x%.16llx\n",tmp_64); 
      return(failure);
    }

  tmp_64 = F_func(f_test_low[6],
		  f_test_low[5],
		  f_test_low[4],
		  f_test_low[3],
		  f_test_low[2],
		  f_test_low[1],
		  f_test_low[0]);
  if (tmp_64 != f_low_val)
    {
      printf("FAILURE!\n");
      printf("\nVerifying F_func:\n");
      printf("Testing lower order 64 possible inputs\n");
      printf("Input is\n");
      for(i=0;i<7;i++)
	{
	  printf("   f_test_low[%i] = 0x%.16llx\n",i,
		 f_test_low[i]);
	}
      printf("Result should be: 0x%.16llx\n",f_low_val);
      printf("       Result is: 0x%.16llx\n",tmp_64); 
      return(failure);
    }

  tmp_64 = F_func(f_test_hi[6],
		  f_test_hi[5],
		  f_test_hi[4],
		  f_test_hi[3],
		  f_test_hi[2],
		  f_test_hi[1],
		  f_test_hi[0]);
  if (tmp_64 != f_hi_val)
    {
      printf("FAILURE!\n");
      printf("Testing higher order 64 possible inputs\n");
      printf("Input is\n");
      for(i=0;i<7;i++)
	{
	  printf("   f_test_hi[%i] = 0x%.16llx\n",i,
		 f_test_hi[i]);
	}
      printf("Result should be: 0x%.16llx\n",f_hi_val);
      printf("       Result is: 0x%.16llx\n",tmp_64); 
      return(failure);
    }

  return(success);
}



/*
 * This function verifies all the entries in the L_32_table and the
 * L_64_table by comparing againsts the results of the shift register
 * implementation.  We also check to make sure that the arithmetic
 * shift right operation is copying the sign bit like we expect it it.
 */
test_return_value verify_L()
{
  uint64_t tmp_64;
  uint32_t tmp_32;
  int i;
  int j;


  tmp_32 = 0x80000000;
  tmp_32 = (uint32_t)(((int32_t)tmp_32) >> 31);
  if (tmp_32 != 0xffffffff)
    {
      printf("FAILURE: 32-bit Arithmetic shift right doesn't copy sign bit\n");
      printf("The constant time compression functions will not work correctly.\n");
      return(failure);
    }
  tmp_64 = 0x8000000000000000LL;
  tmp_64 = (uint64_t)(((int64_t)tmp_64) >> 63);
  if (tmp_64 != 0xffffffffffffffffLL)
    {
      printf("FAILURE: 64-bit Arithmetic shift right doesn't copy sign bit\n");
      printf("The constant time compression functions will not work correctly.\n");
      return(failure);
    }
  
  /*
   * Now we run through a series of tests that verify the entries in the
   * L_32 and L_64 tables.
   */
  for(i=0;i<256;i++)
    {
      tmp_64 = (uint64_t)i;
      tmp_32 = (uint32_t)i;

      /*
       * This for loop implements L_32 via
       * the LFSR in Galois configuration.
       */
      for(j=0;j<32;j++)
	{
	  if (tmp_32 >> 31)
	    {
	      tmp_32 = (tmp_32 << 1) ^ P_32;
	    }
	  else
	    {
	      tmp_32 <<= 1;
	    }
	}
      if (tmp_32 != L_32_table[i])
	{
	  printf("FAILURE: L_32_table[%i] = 0x%.8x should be 0x%.8x\n",
		 i,L_32_table[i],tmp_32);
	  return(failure);
	}


      /*
       * This for loop implements L_64 via
       * the LFSR in Galois configuration.
       */
      for(j=0;j<64;j++)
	{
	  if (tmp_64 >> 63)
	    {
	      tmp_64 = (tmp_64 << 1) ^ P_64;
	    }
	  else
	    {
	      tmp_64 <<= 1;
	    }
	}
      if (tmp_64 != L_64_table[i])
	{
	  printf("FAILURE: L_64_table[%i] = 0x%.16llx should be 0x%.16llx\n",
		 i,L_64_table[i],tmp_64);
	  return(failure);
	}
    }

  return(success);
}


test_return_value verify_intermediate_results()
{
  BitSequence test_msg[128];
  BitSequence hashval[64];
  DataLength msglen, num_blocks, block_size;
  int hash_sizes[] = {224, 256, 384, 512};
  int hashbitlen;
  int i,j;
  
#ifdef ESSENCE_USE_CORE2_ASSEMBLY
  if (ESSENCE_USE_CONSTANT_TIME == 1)
    {
      printf("\nSTOP:  To generate intermediate results you must edit essence_api.h\n");
      printf("       and set ESSENCE_USE_CONSTANT_TIME to 0 then re-compile\n");
      return(failure);
    }
  if (ESSENCE_USE_CORE2_ASSEMBLY == 1)
    {
      printf("\nSTOP:  To generate intermediate results you must edit essence_api.h\n");
      printf("       and set ESSENCE_USE_CORE2_ASSEMBLY to 0 then re-compile\n");
      return(failure);
    }
#endif
  if ((ESSENCE_DEBUG_LEVEL & 0x0f) != 0x0f)
    {
      printf("\nSTOP:  To generate intermediate results you must edit essence_api.h\n");
      printf("       and set ESSENCE_DEBUG_LEVEL to 0x0f then re-compile\n");
      return(failure);
    }


  /*
   * Initialize the test message
   */
  for(i=0;i<128;i++)
    {
      test_msg[i] = i;
    }

  for(i=0;i<4;i++)
    {
      hashbitlen = hash_sizes[i];
      if (hashbitlen > 256)
	{
	  block_size = 512;
	}
      else
	{
	  block_size = 256;
	}
      for(num_blocks=1;num_blocks<=2;num_blocks++)
	{
	  msglen = num_blocks*block_size;
	  printf("\n\n\n\n********************************");
	  printf("*****************************************\n");
	  printf("******************************************");
	  printf("*******************************\n");
	  printf("    Intermediate Values\n");
	  printf("    hashbitlen = %i bits\n",hashbitlen);
	  printf("    Msglen = %lli bits (%lli blocks)\n",
		 msglen,
		 num_blocks);
	  printf("******************************************");
	  printf("*******************************\n");
	  printf("Msg = ");
	  for(j=0;j<(msglen/8);j++)
	    {
	      printf("0x%.2x ",test_msg[j]);
	      if (j%8 == 7)
		{
		  printf("\n      ");
		}
	    }
	  Hash(hashbitlen,
	       test_msg,
	       msglen,
	       hashval);
	}
    }
}


main()
{
  if (verify_data_sizes() != success)
    {
      printf("verify_data_sizes() failed.  Aborting test.\n");
      exit(0);
    }
  printf("\n Data type sizes are correct.\n");

  if (verify_F() != success)
    {
      printf("verify_F() failed.  Aborting test.\n");
      exit(0);
    }
  printf("\n F function is correct.\n");

  if (verify_L() != success)
    {
      printf("verify_L() failed.  Aborting test.\n");
      exit(0);
    }
  printf("\n L function tables are correct.\n");

  if (verify_intermediate_results() != success)
    {
      printf("verify_intermediate_results() failed.  Aborting test.\n");
      exit(0);
    }

}
