FILE:  Readme.txt (in the Additional_Implementations subdirectory)

AUTHOR: Jason Worth Martin

DESCRIPTION:  This code implements several highly optimized version
of the ESSENCE hashing algorithm.


BUILDING THE CODE
-----------------

Non-x86 UNIX
------------

1.  Edit the Makefile to remove the dependencies on all the assembly files.


2.  Be sure to edit essence_api.h to make sure that
ESSENCE_USE_CORE2_ASSEMBLY is defined to 0 instead of 1.  Also, unless
you know that your processor is Little Endian, you should set
ESSENCE_ASSUME_LITTLE_ENDIAN to 0.


3.  You won't be able to build the speed_test program since that
has an x86 specific call in it.



x86_64 UNIX (including OS X)
----------------------------

1.  YASM

To build for any x86_64 platforms, you first need to build (or copy)
the YASM assembler.  YASM is an open source assembler capable of
generating object files for 64-bit Windows, Linux, and Mac OS X from a
single source file.  The source code for YASM is included as a tar'd
gzipped file which needs to be unzipped, configured, and compiled in
the usual way.


2.  Edit the file essence_api.h to select the implementation parameters that
match your build.  The parameters to look at are:

ESSENCE_DEBUG_LEVEL
ESSENCE_USE_CONSTANT_TIME
ESSENCE_USE_PARALLEL_CODE
ESSENCE_ASSUME_LITTLE_ENDIAN
ESSENCE_USE_CORE2_ASSEMBLY


3.  Edit the Makefile to select your build options.  In particular,
you will need to specify the OpenMP compiler flags and the object file
type.  You will also need to give the correct path to YASM.




VISTA 64
--------

1.  YASM

To build for any x86_64 platforms, you first need to build (or copy)
the YASM assembler.  YASM is an open source assembler capable of
generating object files for 64-bit Windows, Linux, and Mac OS X from a
single source file.  For Windows users, there is a binary executable
of YASM in this directory.  For Unix users, the source code for YASM
is included as a tar'd gzipped file which needs to be unzipped,
configured, and compiled in the usual way.


2.  Setup the Environment for 64-bit target.

If you are using Microsoft Visual Studio and you want to build the
64-bit version from the command line (recommended), then you will
probably need to setup the environment using the "vcvarsall.bat"
script with the "x86_amd64" or "amd64" argument.  (The "vcvarsall.bat"
script is part of Visual Studio.)


2.  Edit Makefile_nmake

If you are building for Windows with Microsoft Visual Studio, you can
use the command line tool "nmake" with the Makefile_nmake makefile.
You should read the Makefile_nmake file first and choose the
compilation options for your build.


3.  Edit essence_api.h

Inside essence_api.h you may need to modify the implementation
parameters to match your build.  For example, you might want to
set ESSENCE_USE_CORE2_ASSEMBLY to 1 if you are going to use the
x86_64 assembly code or 0 if you aren't.  Likewise for the
parallel and constant time options.


4.  Obtain vcomp90.dll if you want to use the parallel code.

Visual Studio implements OpenMP using the vcomp90.dll which isn't in
the standard Vista distribution.  However, vcomp90.dll is available
from the Microsoft Visual C++ 2005 Redistributable Package located at

http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=32BC1BEE-A3F9-4C13-9C99-220B62A191EE

This package, vcredist_x86.exe, will place many dlls in the WinSxS
directory.  So, you might want to obtain it elsewhere if you have no
desire to install random things in your system directories.  I
recommend obtaining a copy of the dll and placing it in the same
directory as the parallel executable.  If you want to use the WinSxS
approach, then you will need to create a manifest for the essence
executable to indicate the location of vcomp90.dll.  If you already
have vcomp90.dll installed, you can just copy it from the WinSxS
directory to the executable directory to avoid creating a manifest.




PORTABILITY ISSUES: This code *assumes* that the "long long" data type
is available and is a 64-bit integer.  That does not mean that the
target needs to be a 64-bit processor, only that the compiler must
support a 64-bit type.  The code also *assumes* that the int data type
is a 32-bit integer.  If that is not correct for your compiler, then
adjust the type definitions in "essence_api.h".  You must have a
64-bit and 32-bit data type available for this code to compile.  Note
that the types "int32_t, uint32_t, int64_t, and uint64_t" are defined
in essence_api.h based on these assumptions.  If you compiler
environment supports the "stdint.h" header file, you may remove the
definitions in essence_api.h and replace them by the same types
included from "stdint.h" This would be the prefered method, however
many older compilers suites do not have the "stdint.h" file but do
have the "long long" data type for 64-bit integers.






 Contents
-------------------------------------------------------------------------

yasm-0.7.1-win32.exe
--------------------

This is a Windows binary executable version of the YASM assembler.


yasm-0.7.1.tar.gz
-----------------

This is a tar'd and gnu compressed copy of the source code for the
YASM assembler.  It is required to assemble the x86_64 code.  The YASM
assmeble is distributed under several open source licenses, for
details please refer to http://www.tortall.net/projects/yasm


essence_api.h
-------------

The header file that should be included by applications wishing to
used ESSENCE.  This file contains the algorithm parameters and
declarations for the ESSENCE API.


essence_api.c
-------------

This file contains the C code to implement the ESSENCE API functions.


essence_compress_256.c
----------------------

The ESSENCE 256-bit compression function.  ANSI C simple version.


essence_compress_256_const_time.c
---------------------------------

The ESSENCE 256-bit compression function in ANSI C using the
constant time implementation for the L function.


essence_compress_256_64.c
-------------------------

The ESSENCE 256-bit compression function in ANSI C optimized for
64-bit implementation.


essence_compress_256_64_const_time.c
------------------------------------

The ESSENCE 256-bit compression function in ANSI C optimized for
64-bit implementation and using the constant time version of the
L function.


essence_compress_256_64_dual.yasm
---------------------------------

An x86_64 assembly language implementation of the 256-bit compression
function written for the YASM assembler.  This code uses the XMM
registers and SSE instructions to implement two copies of the 256-bit
compression function in parallel (on the same core).


essence_compress_256_64_dual_const_time.yasm
--------------------------------------------

An x86_64 assembly language implementation of the 256-bit compression
function written for the YASM assembler.  This code uses the XMM
registers and SSE instructions to implement two copies of the 256-bit
compression function in parallel (on the same core).  This code
uses the constant time implementation of the L function.


essence_compress_512.c
----------------------

The ESSENCE 512-bit compression function.  ANSI C version.


essence_compress_512_const_time.c
---------------------------------

The ESSENCE 512-bit compression function.  ANSI C version using the
constant time implementation of the L function.


essence_compress_512_64.yasm
----------------------------

An x86_64 assembly language implementation of the 512-bit compression
function using the XMM registers and SSE instructions to exploit
instruction-level parallelism.  This code is written for the YASM
assembler.


essence_compress_512_64_const_time.yasm
---------------------------------------

An x86_64 assembly language implementation of the 512-bit compression
function using the XMM registers and SSE instructions to exploit
instruction-level parallelism.  This code is written for the YASM
assembler.  This code uses the constant time version of the L
function.


essence_L_tables.c
------------------

This file just contains the tables used to implement the L_32 and L_64
linear functions.


essence.h
---------

A header file used internally within the ESSENCE implementation.


verify_essence.c
----------------

This program verifies that each component of an implementation is
correct.  It includes verification that data sizes are correct,
verfication that arithmetic shift right copies the sign bit, an
exhaustive test of all possible 7-bit inputs to the F function, and an
exhaustive test of all the table values used by the L_32 and L_64
functions.  If the ESSENCE_DEBUG_LEVEL constant is set to 0x0f, then
this program will also generate the intermediate values for test
messages for each of the four hash sizes with one and two blocks of
input.


genKAT.c
--------

NIST source code to generate KAT files for required digest sizes.


stress_test.c
-------------

An additional test program based on the NIST genKAT code.  This
program uses the same messages as the genKAT program, but in addition
it compares the results of hashing the message all at once with
hashing the same message sequencially by calling the Update function
repeatedly taking "step_size" bits at a time.  The value for
"step_size" is varied across values that have been choosen to give
good code coverage and hit corner cases.  NOTE: The Extremely Long
Message is created completely in RAM for this program.  So, the target
machine must have enough RAM to hold the entire Extremely Long Message
(not just the string that gets repeated).  Otherwise the machine will
grind to a halt from disk paging.


ShortMsgKAT.txt
---------------

Input file for Short Message KAT Test.


LongMsgKAT.txt
--------------

Input file for Long Message KAT Test.

ExtremelyLongMsgKAT.txt
-----------------------

Input file for Extremely Long Message KAT Test.


MonteCarlo.txt
--------------

Input file for Monte Carlo Test.


read_time_stamp_counter.yasm
----------------------------

This is an x86_64 assembly file which contains two functions:
read_time_stamp_counter_low, which reads the lower 32-bits of the time
stamp counter, and read_time_stamp_counter_high, which reads the upper
32-bit of the time stamp counter.  The file is written for the YASM
assembler.


speed_test.c
------------

This program implements a speed test of the ESSENCE implementation
on various message sizes.  The speed_test can only be compiled on the
x86 platforms since it requires read_time_stamp_counter routines.


Makefile
--------

A makefile suitable for use on a Unix platform.  The default compiler
called in the makefile is gcc, but that can easily be modified.


Makefile_nmake
--------------

A makefile suitable for use with the nmake utility in the Microsoft
Visual Studio suite.


Readme.txt
----------

This file.
