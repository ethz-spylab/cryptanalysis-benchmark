/*
 * This code is designed to test the speed of a given ESSENCE
 * implementation.
 */
#include "essence_api.h"
#include <stdio.h>
#include <stdlib.h>


/*
 * For each MSG size, we will use NUM_TRIALS timing trials and
 * take the smallest one.  This is to help account for time delays
 * from task switching, etc.
 *
 * NOTE:  Make sure that your target machine has enough RAM to
 * support this test!!!  Otherwise, your timing data will be
 * meaningless.  You machine needs to have at least
 * 2*MAX_MSG_SIZE_IN_BYTES byte of RAM.  Without sufficient RAM,
 * the test will spend all its time paging out to disk.
 *
 * ALSO NOTE: MAX_MSG_SIZE_IN_BYTES and needs to be declared as a
 * "long long" constant. 
 *
 */
#define NUM_TRIALS 1
#define MAX_MSG_SIZE_IN_BYTES 536870912LL

/*
 * These functions are defined in the associate
 * assembly file.
 */
uint32_t read_time_stamp_counter_low();
uint32_t read_time_stamp_counter_high();


uint64_t read_time_stamp_counter()
{
  uint64_t counter;
  uint32_t counter_low;
  uint32_t counter_high;

  counter_low = read_time_stamp_counter_low();
  counter_high = read_time_stamp_counter_high();
  counter = ((uint64_t)counter_high) << 32;
  counter |= ((uint64_t)counter_low) & 0x00000000ffffffffLL;
  return(counter);
}


/*
 * Returns the number of clock cycles required to hash the
 * given message.  The returned value is a "double" to avoid
 * conversion problems.
 */
double speed_test(int hashbitlen, BitSequence *Msg, DataLength msglen)
{
  BitSequence hashval[64];
  uint64_t cpu_clock;
  double output;

  cpu_clock = read_time_stamp_counter();
  Hash(hashbitlen, Msg, msglen, hashval);
  cpu_clock = read_time_stamp_counter() - cpu_clock;
  output = (double)cpu_clock;
  return(output);
}



main()
{
  int bitlens[4] = {224, 256, 384, 512};
  int hashbitlen, i,j ;
  BitSequence *Msg;
  DataLength msglen;
  double cycles, cpu_cycles_per_byte;
  FILE *fp;
  char file_name[256];

  Msg = (BitSequence*)malloc(MAX_MSG_SIZE_IN_BYTES*sizeof(BitSequence));
  if (Msg == NULL)
    {
      printf("\n\nError: Cannot Allocate Enough RAM.\n\n");
      exit(1);
    }

  /*
   * We don't bother to initialize the Msg data because we don't
   * care what it is.  We are only testing speed here.
   */

  for(i=0;i<4;i++)
    {
      hashbitlen = bitlens[i];
      sprintf(file_name, "speed_test_%i.txt",hashbitlen);
      fp = fopen(file_name,"w");
      if (fp == NULL)
	{
	  printf("\n\nERROR: Can't open file %s for writing\n\n",file_name);
	  exit(1);
	}

      printf("Working on %s\n",file_name);
      fflush(stdout);
      
      msglen = 4;
      while(msglen < (8*(MAX_MSG_SIZE_IN_BYTES)) )
	{
	  msglen = 2*msglen;
	  if ( msglen > (8*(MAX_MSG_SIZE_IN_BYTES)) )
	    {
	      msglen = 8*(MAX_MSG_SIZE_IN_BYTES);
	    }
	  cycles = speed_test(hashbitlen, Msg, msglen);
	  cpu_cycles_per_byte = 8*cycles/msglen;
	  fprintf(fp,"%10lli\t%15.2f\t%10.3f\n",
		  (msglen/8),
		  cycles,
		  cpu_cycles_per_byte);
	  fflush(fp);
	}

      fclose(fp);
    }

}
