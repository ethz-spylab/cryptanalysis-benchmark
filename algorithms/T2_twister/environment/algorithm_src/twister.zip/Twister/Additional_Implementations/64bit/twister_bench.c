/***********************************************************************
**
** Benchmark code for the Twister optimized 64 bit version.
**
** Source code author: Christian Forler, 2008.
**
** This algorithm and source code is released to the public domain.
**
***********************************************************************/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifdef __GNUC__
#include <sys/time.h>
#include <unistd.h>
#include <stdint.h>
#endif

#include "twister_o64_nist.h"

#define HERTZ 2000e6
#define ITERATIONS 1000

static BitSequence data[256];
static BitSequence hashval[64];



/***************************************************************************/

void test_hash64_mb(int hashlen)
{
  int i;
  hashState state;
  uint64_t *hash = (uint64_t *) hashval;

  printf("\nHashing 64 mega byte with Twister-%d\n",hashlen);
  Init(&state,hashlen);
  for(i=0;i<1024*1024;i++) Update(&state,data,512);
  Final(&state,hashval);
  for(i=0;i<hashlen/64;i++)
    {
#ifdef __GNUC__
      printf("%016lx ",hash[i]);
#else
      printf("%016llx ",hash[i]);
#endif
    }
  puts("\n");
}

/***************************************************************************/

void test_hash_bitrotation(int hashlen)
{
  int i,j;
  hashState state;

  for(i=0;i<64;i++)
    for(j=0;j<8;j++)
      {
	memset(data,0,256);
	data[i]=1<<j;
	Init(&state,hashlen);
	Update(&state,data,512);
	Final(&state,hashval);
	write(1,hashval,hashlen>>3);
      }
}


/***************************************************************************/

double test_cpb_update(int hashlen)

{
  hashState state;
   clock_t a;
   double result;
   int i,j;

   a=clock();
   for(i=0;i<ITERATIONS;i++)
     {
       Init(&state,hashlen);
       for(j=0;j<1024;j++) Update(&state,data,512);
       Final(&state,hashval);
     }
   result = clock()-a;
   return ((result*HERTZ)/((double)CLOCKS_PER_SEC*65536*ITERATIONS));
   
  
}


/***************************************************************************/

int main()
{
  printf("%s, %s, CPU: %ld-bit, %4.0lf MHz\n",__DATE__,__TIME__,sizeof(size_t)<<3,HERTZ/1000000);
  test_hash64_mb(512);  
  printf("Clock cycle per byte Twister-224: %3.2lf\n",test_cpb_update(224));
  printf("Clock cycle per byte Twister-256: %3.2lf\n",test_cpb_update(256));
  printf("Clock cycle per byte Twister-512: %3.2lf\n",test_cpb_update(384));
  printf("Clock cycle per byte Twister-512: %3.2lf\n",test_cpb_update(512));
  
  //test_hash_bitrotation(512);  
  return SUCCESS;
}
