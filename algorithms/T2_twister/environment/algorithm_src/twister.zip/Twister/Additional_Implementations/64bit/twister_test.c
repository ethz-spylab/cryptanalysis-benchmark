/***********************************************************************
**
** Test/verification code for the Skein block functions.
**
** Source code author: Doug Whiting, 2008.
**
** This algorithm and source code is released to the public domain.
**
** Testing:
**   - buffering of incremental calls (random cnt steps)
**   - partial input byte handling
**   - output sample hash results (for comparison of ref vs. optimized)
**   - performance
**
***********************************************************************/

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <assert.h>


#include "twister_o64_nist.h"

#ifdef __GNUC__
typedef unsigned int uint_t;
typedef uint8_t u08b_t;
typedef uint32_t uint_32t;
typedef uint64_t u64b_t;
#else
typedef unsigned int uint_t;
typedef unsigned __int8 u08b_t;
typedef unsigned __int32 uint_32t;
typedef unsigned __int64 u64b_t;
#endif


#define MSG_CNT 20

   /* list of hash tag lengths to test */
static const uint_t TAG_BITS[] =  {224,256,384,512};

#define TAG_BITS_CNT (sizeof(TAG_BITS)/sizeof(TAG_BITS[0]))

/* automatic compiler version number detection */
#if !defined(CompilerVersion)

#if   defined(_MSC_VER) && (_MSC_VER >= 1400)
#define CompilerVersion (900)
#elif defined(_MSC_VER) && (_MSC_VER >= 1200)
#define CompilerVersion (600)
#elif defined(_MSC_VER) && (_MSC_VER >= 1000)
#define CompilerVersion (420)
#elif defined(__GNUC__) && defined(__GNUC_MINOR__) && defined(__GNUC_PATCHLEVEL__)
#define CompilerVersion (100*__GNUC__ + 10*__GNUC_MINOR__ + __GNUC_PATCHLEVEL__)
#elif defined(__BORLANDC__) /* this is in hex */
#define CompilerVersion (100*(__BORLANDC__ >> 8) + 10*((__BORLANDC__ >> 4) & 0xF) + (__BORLANDC__ & 0xF))
#endif

#endif

/********************** debug i/o helper routines **********************/
void FatalError(const char *s,...)
    { /* print out a msg and exit with an error code */
    va_list ap;
    va_start(ap,s);
    vprintf(s,ap);
    va_end(ap);
    exit(2);
    }

static uint_t katHash   = ~0u;  /* use as a quick check on KAT results */

void ShowBytes(uint_t cnt,const u08b_t *b)
    { /* formatted output of byte array */
    uint_t i;
    for (i=0;i < cnt;i++)
        {
        if (i %16 ==  0) printf("    ");
        printf(" %02X",b[i]);
        katHash = (katHash ^ b[i]) * 0xDEADBEEF;
        katHash = (katHash ^ (katHash >> 23) ^ (katHash >> 17) ^ (katHash >> 9)) * 0xCAFEF00D;
        if (i %16 == 15 || i==cnt-1) printf("\n");
        }
    }

#ifndef TWISTER_DEBUG
uint_t twister_DebugFlag     =   0;     /* dummy flags (if not defined elsewhere) */
#endif

#define TWISTER_DEBUG_DEFAULT (~TWISTER_DEBUG_ROUNDS_ALL)
#define TWISTER_DEBUG_SHORT   (TWISTER_DEBUG_KEY | TWISTER_DEBUG_INPUT_08 | TWISTER_DEBUG_FINAL)

void Show_Debug(const char *s,...)
    {
    if (twister_DebugFlag)              /* are we showing debug info? */
        {
        va_list ap;
        va_start(ap,s);
        vprintf(s,ap);
        va_end(ap);
        }
    }

/************** Timing routine (for performance measurements) ***********/
/* unfortunately, this is generally assembly code and not very portable */

#if defined(_M_IX86) || defined(__i386) || defined(_i386) || defined(__i386__) || defined(i386) || \
    defined(_X86_)   || defined(__x86_64__) || defined(_M_X64) || defined(__x86_64)
#define _Is_X86_    1
#endif

#if  defined(_Is_X86_) && (!defined(__STRICT_ANSI__)) && (defined(__GNUC__) || !defined(__STDC__)) && \
    (defined(__BORLANDC__) || defined(_MSC_VER) || defined(__MINGW_H) || defined(__GNUC__))
#define HI_RES_CLK_OK         1          /* it's ok to use RDTSC opcode */

#if defined(_MSC_VER) && defined(_M_X64)
#include <intrin.h>
#pragma intrinsic(__rdtsc)
#endif

#endif

uint_32t HiResTime(void)
    {
#if defined(HI_RES_CLK_OK)
    uint_32t x[2];
#if   defined(__BORLANDC__)
#define COMPILER_ID "BCC"
    __emit__(0x0F,0x31);            /* RDTSC instruction */
    _asm { mov x[0],eax };
#elif defined(_MSC_VER)
#define COMPILER_ID "MSC"
#if defined(_MSC_VER) && defined(_M_X64)
    x[0] = (uint_32t) __rdtsc();
#else
    _asm { _emit 0fh }; _asm { _emit 031h };
    _asm { mov x[0],eax };
#endif
#elif defined(__MINGW_H) || defined(__GNUC__)
#define COMPILER_ID "GCC"
    asm volatile("rdtsc" : "=a"(x[0]), "=d"(x[1]));
#else
#error  "HI_RES_CLK_OK -- but no assembler code for this platform (?)"
#endif
    return x[0];
#else
    /* avoid annoying MSVC 9.0 compiler warning #4720 in ANSI mode! */
#if (!defined(_MSC_VER)) || (!defined(__STDC__)) || (_MSC_VER < 1300)
    FatalError("No support for RDTSC on this CPU platform\n");
#endif
    return 0;
#endif /* defined(HI_RES_CLK_OK) */
    }

#if defined(_MSC_VER) && (_MSC_VER >= 1300) && !defined(__STRICT_ANSI__) && !defined(__STDC__)
#if defined(_M_X64) || defined(TWISTER_FORCE_LOCK_CPU)
#define  TWISTER_LOCK_CPU_OK (1)
#include <Windows.h>
#include <WinBase.h>
int Lock_CPU(void)
    {   /* lock this process to this CPU for perf timing */
        /*   -- thanks to Brian Gladman for this code    */
    HANDLE ph;
    DWORD_PTR afp;
    DWORD_PTR afs;
    ph = GetCurrentProcess();
    if(GetProcessAffinityMask(ph, &afp, &afs))
        {
        afp &= (((size_t)1u) << GetCurrentProcessorNumber());
        if(!SetProcessAffinityMask(ph, afp))
            return 1;
        }
    else
        {
        return 2;
        }
    return 0;   /* success */
    }
#endif
#endif

#ifndef COMPILER_ID
#define COMPILER_ID "(unknown)"
#endif
/********************** use RC4 to generate test data ******************/
/* Note: this works identically on all platforms (big/little-endian)   */
static struct
    {
    uint_t I,J;                         /* RC4 vars */
    u08b_t state[256];
    } prng;

void RandBytes(void *dst,uint_t byteCnt)
    {
    u08b_t a,b;
    u08b_t *d = (u08b_t *) dst;

    for (;byteCnt;byteCnt--,d++)        /* run RC4  */
        {
        prng.I  = (prng.I+1) & 0xFF;
        a       =  prng.state[prng.I];
        prng.J  = (prng.J+a) & 0xFF;
        b       =  prng.state[prng.J];
        prng.state[prng.I] = b;
        prng.state[prng.J] = a;
        *d      =  prng.state[(a+b) & 0xFF];
        }
    }

/* get a pseudo-random 32-bit integer in a portable way */
uint_t Rand32(void)
    {
    uint_t i,n;
    u08b_t tmp[4];

    RandBytes(tmp,sizeof(tmp));

    for (i=n=0;i<sizeof(tmp);i++)
        n = n*256 + tmp[i];
    
    return n;
    }

/* init the (RC4-based) prng */
void Rand_Init(u64b_t seed)
    {
    uint_t i,j;
    u08b_t tmp[512];

    /* init the "key" in an endian-independent fashion */
    for (i=0;i<8;i++)
        tmp[i] = (u08b_t) (seed >> (8*i));

    /* initialize the permutation */
    for (i=0;i<256;i++)
        prng.state[i]=(u08b_t) i;

    /* now run the RC4 key schedule */
    for (i=j=0;i<256;i++)
        {                   
        j = (j + prng.state[i] + tmp[i%8]) & 0xFF;
        tmp[256]      = prng.state[i];
        prng.state[i] = prng.state[j];
        prng.state[j] = tmp[256];
        }
    prng.I = prng.J = 0;  /* init I,J variables for RC4 */
    
    /* discard initial keystream before returning */
    RandBytes(tmp,sizeof(tmp));
    }
    

/* qsort routine */
int compare_uint_32t(const void *aPtr,const void *bPtr)
    {
    uint_32t a = * ((uint_32t *) aPtr);
    uint_32t b = * ((uint_32t *) bPtr);
    
    if (a > b) return  1;
    if (a < b) return -1;
    return 0;
    }


/* measure the speed (in CPU clks/byte) for a Twister implementation */
void Twister_MeasurePerformance()
{
  const uint_t MSG_BYTES[MSG_CNT] = {1,2,4,8,10,16,32,64,100,128,256,512,1000,1024,2048,4096,8192,10000,16384,32786};
  enum     {  TIMER_SAMPLE_CNT = 15, MAX_BUFFER=20000 };
  uint_32t dt[TIMER_SAMPLE_CNT],t0,t1;
  uint_32t dtMin = ~0u;
  uint_t   i,j,n,msgBytes;
  u08b_t   b[MAX_BUFFER],hashVal[64];
  hashState s;
  uint_t blkSize[] = { 256,384,512 };
#ifdef CompilerVersion
  char     CVER[20];                      /* avoid ANSI compiler warnings for sprintf()! :-(( */
  n          = CompilerVersion;
  CVER[0]    = '_';
  CVER[1]    = 'v';
  CVER[2]    = (char)('0'+((n /100)%10));
  CVER[3]    = '.';
  CVER[4]    = (char)('0'+((n / 10)%10));
  CVER[5]    = (char)('0'+((n /  1)%10));
  CVER[6]    = 0;
#else
#define CVER ""
#endif      
  
#ifdef TWISTER_LOCK_CPU_OK
  {
    int errNo = Lock_CPU();
    if (errNo)
      printf("Unable to lock CPU: error #%d\n",errNo);
    else
      printf("Locked CPU to this process\n");
  }
#endif
                
  RandBytes(b,sizeof(b));             /* use random data for testing */
  HiResTime();                        /* get the HiResTime() code in I-cache */
  for (i=0;i<TIMER_SAMPLE_CNT;i++)    /* calibrate the overhead for measuring time */
    {
      t0 = HiResTime();
      t1 = HiResTime();
      if (dtMin > t1-t0)              /* keep only the minimum time */
	dtMin = t1-t0;
    }

  printf("\nTwister performance, in clks per byte, dtMin = %4d clks.\n",dtMin);
  printf("         [compiled %s,%s  by  '%s%s', %u-bit]\n",__TIME__,__DATE__,COMPILER_ID,CVER,(uint_t)(8*sizeof(size_t)));
  printf("         =================================================================\n");
  printf("         ||                     Twister block size                       |\n");
  printf("         ||--------------------------------------------------------------|\n");
  printf(" Message ||       256 bits     |       384 bits     |      512 bits      |\n");
  printf(" Length  ||====================|====================|====================|\n");
  printf(" (bytes) ||     min    median  |     min    median  |     min    median  |\n"); 
  printf("=========||====================|====================|====================|\n");
    
  for(n=0;n<MSG_CNT;n++)
    {
      msgBytes = MSG_BYTES[n];       /* pick the message size (in bits) */
      if (msgBytes > MAX_BUFFER || msgBytes == 0)
	break;
      printf("%8d ||",msgBytes);
      for (j=0;j<3;j++)
	{                           /* cycle thru the different block sizes */
	  t0=HiResTime();
	  t1=HiResTime();
	  for (i=0;i<TIMER_SAMPLE_CNT;i++)
	    {
	      t0 = HiResTime();
	      Init(&s,blkSize[j]);
	      Update(&s,b,msgBytes<<3);
	      Final(&s,hashVal);
	      t1 = HiResTime();
	      dt[i] = (t1 - t0) - dtMin; /* adjust for HiResTime() overhead */
	    }
	  /* Here with dt[] full of time differences. Show min/median value in clks/byte */
	  qsort(dt,TIMER_SAMPLE_CNT,sizeof(dt[0]),compare_uint_32t);
	  printf(" %8.2f %8.2f  |",dt[0]/(double)msgBytes,dt[TIMER_SAMPLE_CNT/2]/(double)msgBytes);
	}
      printf(" //: %u-bit, %s%s\n",(uint_t)(8*sizeof(size_t)),COMPILER_ID,CVER);
    }
}


int main()
{
  Twister_MeasurePerformance();
  return 0;
}
