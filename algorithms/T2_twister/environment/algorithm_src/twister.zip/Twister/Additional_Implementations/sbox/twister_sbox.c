#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>


#include "aes_sbox.h"

static int counter=0;

/*****************************************************************************/

void output_tex_head()
{
  puts("\\documentclass[10pt]{article}\n"
       "\\setlength{\\evensidemargin}{0.1pt}\n"
       "\\setlength{\\oddsidemargin}{0.1pt}\n"
       "\\begin{document}\n");
}

/*****************************************************************************/

void output_tex_tail()
{
  puts("\\end{document}");
       
}

/*****************************************************************************/

void output_head(unsigned int x)
{
  unsigned int a;
  
  printf("\\begin{table}[ht]\n"
	 "\\caption{Distribution of the differences table %d}\n",++counter);
  puts("\\centering\n"
       "\\begin{tabular}{|c||c|c|c|c|c|c|c|c|c|c|c|c|c|c|c|c|}\n"
       "\\hline%\n");
  
  printf(" & ");
  for(a=x+15;x<a;x++) printf("%d & ", x);
  printf("%d\\\\\n",x);
  puts("\\hline%\n\\hline%");
  
}

/*****************************************************************************/

void output_tail()
{
  puts("\\end{tabular}\n\\end{table}\n\\clearpage\n\n");
}

/*****************************************************************************/

unsigned int byte_diff(byte a, byte b)
{
  int i;
  unsigned int counter=0;
  for(i=0;i<8;i++) counter+= ((a>>i)&1)^((b>>i)&1);
  return counter;
}

/*****************************************************************************/


unsigned int xor_diff(byte a, byte b)
{
  return a^b;
}

/*****************************************************************************/

unsigned int add_diff(byte a, byte b)
{
  return a+b;
}

/*****************************************************************************/


void init(ddst *d)
{
  memset(d,0,sizeof(*d));
}


/*****************************************************************************/

void output_sub_ddt(ddst *d, int a, int b)
{
  int i,j;
  output_head(b);  
  for(i=a;i<a+32;i++)
    {  
      printf("%d & ", i);
      for(j=b;j<b+16;j++) 
	{
	  printf("%d",d->ddt[i][j]);
	  if(j==b+15) puts("\\\\");
	  else        printf(" & ");
	}
      puts("\\hline%");
    }
  output_tail();  
}

/*****************************************************************************/


void output_ddt(ddst *d)
{
  int i,j;
  
  for(i=0;i<230;i+=32)
    for(j=0;j<250;j+=16)
      output_sub_ddt(d,i,j);
}

/*****************************************************************************/


void sbox_xor_diff(ddst *d)
{
  int i,j;
  unsigned int m=0;

  /* Compute xor diffrence distribution table */
  for(i=0;i<256;i++)
    for(j=0;j<256;j++)
      d->ddt[xor_diff(i,j)][add_diff(sbox[i],sbox[j])]+=1;
  
  for(i=0;i<256;i++)
    {
      m=0;
      for(j=0;j<256;j++)
	{
	  d->number[i]+=d->ddt[i][j];
	  if(d->ddt[i][j]> m)
	    { 
	      m=d->ddt[i][j];
	      d->max[i]=j;
	    }
	}
    }
}

/*****************************************************************************/


void output_statistic_table(ddst *d, int a)
{
  int i;

  printf("\\begin{table}[ht]\n\\caption{Statistic about "
	 "the distribution of differences table %d}\n",++counter);
  puts("\\centering\n"
       "\\begin{tabular}{|c||c|c|c||}\n"
       "\\hline%\n"
       "Output diff & Most common difference & "
       "standard expectation & Total commonness\\\\\n\\hline%\n\\hline%"); 
   for(i=a;i<a+32;i++)
     {
       double percent=(double)d->ddt[i][d->max[i]];
       double expectation=0;
       double variance=0;
       int k;
       percent/=(double)d->number[i];
       percent*=100;
       printf("%d & %d (%d $\\equiv$ %3.2lf\\%%) & ",i, d->max[i],
	      d->ddt[i][d->max[i]], percent);
       
       for(k=0;k<256;k++)
	 {
	   expectation+=((double)(k*d->ddt[i][k]))/((double) d->number[i]);
	   variance+=((double)(k*k*d->ddt[i][k]))/((double) d->number[i]);
	 }
       variance-=expectation;

       percent=(double)d->number[i];
       percent/=(256*256);
       percent*=100;
       printf("%3.2lf & %d (%3.2lf\\%%)\\\\\n",sqrt(variance),
	      d->number[i],percent);
       puts("\\hline%"); 
           
     }
   puts("\\end{tabular}\n\\end{table}\n\\clearpage\n\n");
}


/*****************************************************************************/

void output_statistics(ddst *d)
{
  int i;
  counter=0;
  for(i=0;i<256;i+=32) output_statistic_table(d,i);
}


/*****************************************************************************/

int main(int argc, char *argv[])
{
  ddst d; 

  init(&d);
  sbox_xor_diff(&d);
  output_tex_head();    
  output_statistics(&d);
  // output_ddt(&d);
  output_tex_tail();   
  
  return 0;
}
