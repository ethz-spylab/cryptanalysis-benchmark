/******************************************************************
 ** Optimized 32-bit Twister benchmark test  ANSI C source code
 **
 ** Author: Christian Forler <c.forler@sirrix.com>, 2008
 **
 ** This algorithm and source code is released into the public domain.
 **
 *******************************************************************/


#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifdef __GNUC__
#include <stdint.h>
#include <unistd.h>
#endif

#include "twister_o32_nist.h"

// please insert the "MhZ" of your computer here
#define HERTZ 1866e6

#define ITERATIONS 1000

static BitSequence data[256];
static BitSequence hashval[64];



/***************************************************************************/

void test_hash64_mb(int hashlen)
{
  int i;
  hashState state;
  uint64_t *hash = (uint64_t *) hashval;

  printf("\nHashing 64 mega byte with Twister-%d\n",hashlen);
  Init(&state,hashlen);
  for(i=0;i<1024*1024;i++) Update(&state,data,512);
  Final(&state,hashval);
  for(i=0;i<hashlen/64;i++) printf("%016llx ",hash[i]);
  puts("\n");
}

/***************************************************************************/

void test_hash_bitrotation(int hashlen)
{
  int i,j;
  hashState state;

  for(i=0;i<64;i++)
    for(j=0;j<8;j++)
      {
	memset(data,0,256);
	data[i]=1<<j;
	Init(&state,hashlen);
	Update(&state,data,512);
	Final(&state,hashval);
	write(1,hashval,hashlen>>3);
      }
}


/***************************************************************************/

double test_cpb_twister(int hashlen)
{
  hashState state;
  clock_t a;
  double result;
  int i,j;
   
  a=clock();
  for(i=0;i<ITERATIONS;i++)
    {
      Init(&state,hashlen);
      for(j=0;j<1024;j++) Update(&state,data,512);
      Final(&state,hashval);
    }
  result = clock()-a;
  return ((result*HERTZ)/((double)CLOCKS_PER_SEC*65536*ITERATIONS));
   
  
}


/***************************************************************************/

int main()
{
  printf("%s, %s, CPU: %u-bit, %4.0lf MHz\n",__DATE__,__TIME__,sizeof(long)<<3,HERTZ/1000000);
  test_hash64_mb(512);  
  printf("Clock cycle per byte Twister-224: %4.2lf\n",test_cpb_twister(256));
  printf("Clock cycle per byte Twister-256: %4.2lf\n",test_cpb_twister(256));
  printf("Clock cycle per byte Twister-384: %4.2lf\n",test_cpb_twister(384));
  printf("Clock cycle per byte Twister-512: %4.2lf\n",test_cpb_twister(512));
 
 return SUCCESS;
}
