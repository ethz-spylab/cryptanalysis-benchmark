can be compiled with vc++ 2005/2008, 64-Bit, No CPP extensions needed
