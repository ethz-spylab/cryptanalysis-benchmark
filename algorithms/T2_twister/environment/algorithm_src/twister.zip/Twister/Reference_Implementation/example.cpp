/******************************************************************
 ** Example for Twister Reference Code
 **
 ** Author: Ewan Fleischmann <ewan.fleischmann@uni-weimar.de> 2008
 **
 ** This algorithm and source code is released into the public domain.
 **
 *******************************************************************/

#include "ref_twister.h"


void main(int c, char**v )
{
	int i;
	BitSequence hashval[64]; 
	Hash( 512, "aaa", 24, hashval );
	for( i=0; i<64; i++ )
		printf( "%0x", hashval[i] );
	getchar();

}