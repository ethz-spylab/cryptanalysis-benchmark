#include <reg51.h>
#include <stdio.h>
typedef unsigned char BitSequence;  
typedef unsigned long DataLength;  
typedef unsigned long uint_32t;
typedef enum { SUCCESS = 0, FAIL = 1, BAD_HASHLEN = 2 } HashReturn; 
typedef struct
{
    DataLength databitlen[4];
    unsigned int hashbitlen;
    unsigned int blocksize;
    BitSequence block[129];
	unsigned long hashval[16];
} hashState;
xdata  const uint_32t  i384[16] =
{
    0xcbbb9d5d,  0xc1059ed8,  0x629a292a,  0x367cd507,
    0x9159015a,  0x3070dd17,  0x152fecd8,  0xf70e5939,
    0x67332667,  0xffc00b31,  0x8eb44a87,  0x68581511,
    0xdb0c2e0d,  0x64f98fa7,  0x47b5481d,  0xbefa4fa4
};
xdata   const uint_32t  i512[16] =
{
    0x6a09e667,  0xf3bcc908,  0xbb67ae85,  0x84caa73b,
    0x3c6ef372,  0xfe94f82b,  0xa54ff53a,  0x5f1d36f1,
    0x510e527f,  0xade682d1,  0x9b05688c,  0x2b3e6c1f,
    0x1f83d9ab,  0xfb41bd6b,  0x5be0cd19,  0x137e2179
};

void mix64(uint_32t a[], uint_32t b[], uint_32t c[], uint_32t t, uint_32t d[])
{
	switch (t) 
		{ case 0: d[0]=a[0] ^ b[0] ^ c[0];
				d[1]=a[1] ^ b[1] ^ c[1];
				break;
		case 1: d[0]=(a[0] & b[0]) ^ c[0];
				d[1]=(a[1] & b[1]) ^ c[1];
				break;
		case 2: d[0]=(~(a[0] | c[0])) | (a[0] & (b[0] ^ c[0]));
				d[1]=(~(a[1] | c[1])) | (a[1] & (b[1] ^ c[1]));
				break;
		case 3: d[0]=(~(a[0] | (b[0] ^ c[0]))) | (a[0] & (~(c[0])));
				d[1]=(~(a[1] | (b[1] ^ c[1]))) | (a[1] & (~(c[1])));
				break;
		}
}

void ro64(uint_32t h[], uint_32t rt, uint_32t temp[])
{
	if (rt> 32)	{
		temp[0]=(h[0] << (64-rt)) | (h[1] >> (rt-32));
		temp[1]=(h[1] << (64-rt)) | (h[0] >> (rt-32));
	}
	if (rt<32 && rt>0)	{	
		temp[0]=(h[1] << (32-rt)) | (h[0] >> rt);
		temp[1]=(h[0] << (32-rt)) | (h[1] >> rt);
	}
	if(rt==32) {
		temp[0]=h[1];
		temp[1]=h[0];
	}
	if(rt==0) {
		temp[0]=h[0];
		temp[1]=h[1];
	}
}
void rt64(uint_32t a[],uint_32t b[],uint_32t c[],uint_32t d[],uint_32t e[],uint_32t f[],uint_32t g[],uint_32t h[],uint_32t t[])
{
xdata 	uint_32t temp[2];
//temp=((((((ch[0]^ch[1])+ch[2])^ch[3])+ch[4])^ch[5])+ch[6])^ch[7];
	temp[1]=a[1]^b[1];
    temp[0]=a[0]^b[0];
	temp[1]=temp[1] + c[1];
	temp[0]=temp[0] + c[0];
    if (temp[1]<c[1]) temp[0]+=1;

	temp[1]=temp[1]^d[1];
    temp[0]=temp[0]^d[0];
	temp[1]=temp[1] + e[1];
	temp[0]=temp[0] + e[0];
    if (temp[1]<e[1]) temp[0]+=1;

	temp[1]=temp[1]^f[1];
    temp[0]=temp[0]^f[0];
	temp[1]=temp[1] + g[1];
	temp[0]=temp[0] + g[0];
    if (temp[1]<g[1]) temp[0]+=1;

	t[1]=temp[1]^h[1];
    t[0]=temp[0]^h[0];
}



HashReturn sha64_compile(hashState *state)
{  
 xdata uint_32t hash_64[8][2], ch[8][2], temp1[2], temp2[2], w[16][2];
 xdata uint_32t rt,tempd;
 xdata int i,i1,i2,i3;


for (i=0;i<16;i++)
{
	for (i1=0;i1<2;i1++) {
		tempd=(state->block)[8*i+4*i1];
		tempd=tempd<<8 | ((state->block)[8*i+4*i1+1]);
		tempd=tempd<<8 | ((state->block)[8*i+4*i1+2]);
		tempd=tempd<<8 | ((state->block)[8*i+4*i1+3]);
		w[i][i1]=tempd;
	}	
}

//Initialize eight working variables 
for (i=0;i<8;i++)
{	
		ch[i][0]=(state->hashval)[i*2];
		ch[i][1]=(state->hashval)[i*2+1];
		hash_64[i][0]=(state->hashval)[i*2];
		hash_64[i][1]=(state->hashval)[i*2+1];
}

//iterative part
for ( i=0; i < 8;i++)
{
 	for (i1=0;i1<9;i1=i1+8)
	{
		rt64(ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6],ch[7],temp1);
		rt=(w[i+i1][1] & 0x3f);
		ro64(temp1,rt,temp2);  //		temp=ROTR64(temp,);

		ch[7][0]=ch[6][0];
		ch[7][1]=ch[6][1];

		rt=(w[i+i1][1]>>6) & 0x3f;//		ch[6]=ROTR64(ch[5],((w[i+i1]>>6) & 63));
		ro64(ch[5],rt,ch[6]);		

		rt=(w[i+i1][1]>>12) & 0x3f;//		ch[5]=ROTR64(ch[4],((w[i+i1]>>12) & 63))+w[((i+3) & 7)+i1];	
		ro64(ch[4],rt,temp1);
		ch[5][0]=temp1[0]+w[((i+3) & 7)+i1][0];
		ch[5][1]=temp1[1]+w[((i+3) & 7)+i1][1];
		if (ch[5][1]<temp1[1]) ch[5][0]+=1;

		rt=(w[i+i1][1]>>18) & 0x3f;//		ch[4]=ROTR64(ch[3],((w[i+i1]>>18) & 63));
		ro64(ch[3],rt,ch[4]);

		rt=w[i+i1][0]>>30;
		mix64(ch[0], ch[1], ch[2], rt, temp1);
		ch[3][0]=temp1[0]+w[((i+2) & 7)+i1][0];
		ch[3][1]=temp1[1]+w[((i+2) & 7)+i1][1];
		if (ch[3][1]<temp1[1]) ch[3][0]+=1;  

		rt=(w[i+i1][1]>>24) & 0x3f;//		ch[2]=ROTR64(ch[1],((w[i+i1]>>24) & 63));
		ro64(ch[1],rt,ch[2]);

		ch[1][0]=ch[0][0];
		ch[1][1]=ch[0][1];

		ch[0][0]=temp2[0]+w[((i+1) & 7)+i1][0];
		ch[0][1]=temp2[1]+w[((i+1) & 7)+i1][1];
		if (ch[0][1]<temp2[1]) ch[0][0]+=1;

		rt64(ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6],ch[7],temp1);
		rt=((w[i+i1][0]<<2)  & 0x3f) + ((w[i+i1][1]>>30) & 0x3f);
		ro64(temp1,rt,temp2); 


		ch[7][0]=ch[6][0]+w[((i+7) & 7)+i1][0];
		ch[7][1]=ch[6][1]+w[((i+7) & 7)+i1][1];
		if (ch[7][1]<ch[6][1]) ch[7][0]+=1;

		rt=(w[i+i1][0]>>4) & 0x3f;//		ch[6]=ROTR64(ch[5],((w[i+i1]>>36) & 63));
		ro64(ch[5],rt,ch[6]);

		rt=(w[i+i1][0]>>10) & 0x3f;//		ch[5]=ROTR64(ch[4],((w[i+i1]>>42) & 63))+w[((i+6) & 7)+i1];
		ro64(ch[4],rt,temp1);
		ch[5][0]=temp1[0]+w[((i+6) & 7)+i1][0];
		ch[5][1]=temp1[1]+w[((i+6) & 7)+i1][1];
		if (ch[5][1]<temp1[1]) ch[5][0]+=1;

		rt=(w[i+i1][0]>>16) & 0x3f;
		ro64(ch[3],rt,ch[4]);
		
		rt=w[i+i1][0]>>28 & 0x3 ;
		mix64(ch[0], ch[1], ch[2], rt, temp1);
		ch[3][0]=temp1[0]+w[((i+5) & 7)+i1][0];
		ch[3][1]=temp1[1]+w[((i+5) & 7)+i1][1];
		if (ch[3][1]<temp1[1]) ch[3][0]+=1; 

		ch[2][0]=ch[1][0]+w[i+i1][0];
		ch[2][1]=ch[1][1]+w[i+i1][1];
		if (ch[2][1]<ch[1][1]) ch[2][0]+=1; 

		rt=(w[i+i1][0]>>22) & 0x3f;
		ro64(ch[0],rt,ch[1]);

		ch[0][0]=temp2[0]+w[((i+4) & 7)+i1][0];
		ch[0][1]=temp2[1]+w[((i+4) & 7)+i1][1];
		if (ch[0][1]<temp2[1]) ch[0][0]+=1;
	
	}

	if (i==0) {
		for (i1=0;i1<9;i1++) {
		    //temp=(((((ch[0]+ch[1])^ch[2])+ch[3])^ch[4])+ch[5])^ch[6];
			temp2[0]=0x0;
			temp2[1]=0x0;
			rt64(temp2,ch[0], ch[1], ch[2], ch[3], ch[4], ch[5], ch[6],temp1);
			temp1[1]=(temp1[0]>>4) ^temp1[1];     // temp=((temp>>36) ^ temp) & 0xfffffffff;
			temp1[0]=temp1[0] & 0xf;
			temp1[1]=temp1[1] ^ (temp1[1] >>18) ^ (temp1[0]<<14);   //temp=((temp>>18) ^ temp) & 0x3ffff;
			temp1[1]=temp1[1] & 0x3ffff;
			temp1[1]=((temp1[1]>>12) ^ temp1[1]) & 0xfff;
			temp1[1]=((temp1[1]>>6) ^ temp1[1]) & 0x3f;
			rt=temp1[1];
			ro64(ch[7],rt,temp2);

			ch[7][0]=ch[6][0];
            ch[6][0]=ch[5][0];
	        ch[5][0]=ch[4][0];
		    ch[4][0]=ch[3][0];
	        ch[3][0]=ch[2][0];
            ch[2][0]=ch[1][0];
	        ch[1][0]=ch[0][0];
		    ch[0][0]=temp2[0];	

            ch[7][1]=ch[6][1];
            ch[6][1]=ch[5][1];
	        ch[5][1]=ch[4][1];
		    ch[4][1]=ch[3][1];
	        ch[3][1]=ch[2][1];
            ch[2][1]=ch[1][1];
	        ch[1][1]=ch[0][1];
		    ch[0][1]=temp2[1];
		}
	}
}

// Compute intermediate hash value 
for ( i=0 ; i < 8; i++) 
{
    hash_64[i][0] +=ch[i][0];
	hash_64[i][1] +=ch[i][1];
	if (hash_64[i][1] < ch[i][1]) hash_64[i][0] +=1;
	(state->hashval)[i*2]= hash_64[i][0];
	(state->hashval)[i*2+1]= hash_64[i][1];
}
return SUCCESS;
}




HashReturn Final(hashState *state, BitSequence *hashval)
{
xdata   HashReturn HReturn;
xdata   BitSequence   hv[64],temp ;
xdata   DataLength dl;
xdata  int t,t1, i;

t1=((state->databitlen[3]) % (state->blocksize))/8;
t=7-(state->databitlen[3] % 8);
temp=((state->block)[t1] >> t) | 0x1;
(state->block)[t1]=temp << t; 

if ((state->databitlen[3] % (state->blocksize))>(state->blocksize-129))
{             
	 HReturn=sha64_compile(state); 	
    if (HReturn != SUCCESS) { return HReturn;}

    //  second block
    for ( i=0; i<128; i++ )  
        (state->block)[i]=0x0;
}

t=state->blocksize/8;

dl=state->databitlen[3];
for (i=1;i<5;i++){
	(state->block)[t-i]=dl & 0xff;	
	dl=(dl >> 8);
}
dl=state->databitlen[2];
for (i=5;i<9;i++){
	(state->block)[t-i]=dl & 0xff;	
	dl=(dl >> 8);
}

dl=state->databitlen[1];
for (i=9;i<13;i++){
	(state->block)[t-i]=dl & 0xff;	
	dl=(dl >> 8);
}
dl=state->databitlen[0];
for (i=13;i<17;i++){
	(state->block)[t-i]=dl & 0xff;	
	dl=(dl >> 8);
}

HReturn=sha64_compile(state);  

for(i=0;i<16;i++) {
		hv[4*i]=((state->hashval)[i] >> 24) & 0xff ;
		hv[4*i+1]=((state->hashval)[i] >> 16) & 0xff ;
		hv[4*i+2]=((state->hashval)[i] >> 8) & 0xff ;
		hv[4*i+3]=(state->hashval)[i] & 0xff ;			
}
t=state->blocksize/16;
for(i=0;i<t;i++) hashval[i]=hv[i];
return HReturn;
} 

HashReturn Update(hashState *state, const BitSequence *hdata, DataLength databitlen)
{
 xdata  HashReturn HReturn;
 xdata  BitSequence  tempc;
 xdata  unsigned int oldbitlen;
 xdata  int  i,sbyte, mbits;

oldbitlen=state->databitlen[3] % state->blocksize;
state->databitlen[3]+=databitlen;
if (state->databitlen[3]<databitlen) {
	state->databitlen[2]+=1;
	if (state->databitlen[2]<1) {
		state->databitlen[1]+=1;
		if (state->databitlen[1]<1) state->databitlen[0]+=1;	
	}
}

sbyte=oldbitlen >> 3;
mbits=oldbitlen & 0x7;
(state->block)[state->blocksize / 8] = 0x0;

for (i=0;i<(databitlen+7)/8;i++)
{
	tempc=hdata[i];
	(state->block)[sbyte]=(state->block)[sbyte] | (tempc >> mbits);
	(state->block)[sbyte+1]=tempc << (8-mbits);
	sbyte+=1;	
	if (sbyte==( state->blocksize/8))
	{
		HReturn=sha64_compile(state);  		
		if (HReturn != SUCCESS) { 	return HReturn;}		
		sbyte=0;
		(state->block)[0]=(state->block)[state->blocksize / 8] ;
	}
}
return SUCCESS;
}
HashReturn Init(hashState *state, int hashbitlen)
{
 xdata  	int i;

state->hashbitlen=hashbitlen ; 
state->databitlen[3]=0;
state->databitlen[2]=0;
state->databitlen[1]=0;
state->databitlen[0]=0;

for (i=0;i<129;i++) 
{(state->block)[i]= 0x0 ;}

if ((hashbitlen==384) || (hashbitlen==512))
{   state->blocksize=1024;
    
	if (hashbitlen==384)  {
		for(i=0;i<16;i++) {
		(state->hashval)[i]=i384[i];
		}
		} 
    if (hashbitlen==512) {
		for(i=0;i<16;i++) {
			(state->hashval)[i]=i512[i] ;
			}
			}			     
}
else
{
	return BAD_HASHLEN;
}
return SUCCESS;
}



 HashReturn Hash(int hashbitlen, const BitSequence *hdata, DataLength databitlen, BitSequence *hashval)
{
xdata   hashState state;
xdata HashReturn HReturn;

HReturn=Init(&state, hashbitlen); 
if (HReturn != SUCCESS) {	return HReturn;}

HReturn=Update(&state, hdata, databitlen); 
if (HReturn != SUCCESS) { 	return HReturn;}

HReturn=Final(&state, hashval); 
if (HReturn != SUCCESS) { return HReturn;}

return HReturn;
}

