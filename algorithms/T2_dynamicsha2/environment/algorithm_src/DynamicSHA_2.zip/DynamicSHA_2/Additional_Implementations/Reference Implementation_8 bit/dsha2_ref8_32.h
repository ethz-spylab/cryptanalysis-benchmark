#include <reg51.h>
#include <stdlib.h>
#define ROTR32(x,n)   (((x) >> (n)) | ((x) << (32 - (n))))
typedef unsigned char BitSequence;  
typedef unsigned long  DataLength; 
typedef unsigned long uint_32t;
typedef enum { SUCCESS = 0, FAIL = 1, BAD_HASHLEN = 2 } HashReturn; 
typedef struct
{
    DataLength databitlen[2];
    unsigned int hashbitlen;
    unsigned int blocksize;
    BitSequence block[129];
	unsigned long hashval[16];
} hashState;
xdata   const uint_32t i224[8] =
{
    0xc1059ed8ul, 0x367cd507ul, 0x3070dd17ul, 0xf70e5939ul,
    0xffc00b31ul, 0x68581511ul, 0x64f98fa7ul, 0xbefa4fa4ul
};
xdata  const uint_32t i256[8] =
{
    0x6a09e667ul, 0xbb67ae85ul, 0x3c6ef372ul, 0xa54ff53aul,
    0x510e527ful, 0x9b05688cul, 0x1f83d9abul, 0x5be0cd19ul
};

HashReturn Init(hashState *state, int hashbitlen);   
HashReturn Update(hashState *state, const BitSequence *data, DataLength databitlen); 
HashReturn Final(hashState *state, BitSequence *hashval); 
HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen, BitSequence *hashval);
HashReturn sha32_compile(hashState *state);

HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen, BitSequence *hashval)
{
xdata  hashState state;
xdata  HashReturn HReturn;

HReturn=Init(&state, hashbitlen); 
if (HReturn != SUCCESS) {	return HReturn;}

HReturn=Update(&state, data, databitlen); 
if (HReturn != SUCCESS) { 	return HReturn;}

HReturn=Final(&state, hashval); 
if (HReturn != SUCCESS) { return HReturn;}

return HReturn;
}

HashReturn Init(hashState *state, int hashbitlen)
{
xdata  	int i;

state->hashbitlen=hashbitlen ; 
state->databitlen[0]=0;
state->databitlen[1]=0;
for (i=0;i<129;i++) (state->block)[i]= 0x0 ;

if ((hashbitlen==224) || (hashbitlen==256) )
{
    state->blocksize=512;   
	if (hashbitlen==224)  for(i=0;i<(state->blocksize/64);i++) (state->hashval)[i]=i224[i] ;
    if (hashbitlen==256)  for(i=0;i<(state->blocksize/64);i++) (state->hashval)[i]=i256[i] ;
   
}
else
{
	return BAD_HASHLEN;
}
return SUCCESS;
}

HashReturn Update(hashState *state, const BitSequence *data, DataLength databitlen)
{
xdata  HashReturn HReturn;
xdata  BitSequence  tempc;
xdata  unsigned int oldbitlen;
xdata  int  i,sbyte, mbits;

oldbitlen=state->databitlen[1] % state->blocksize;
state->databitlen[1]+=databitlen;
if (state->databitlen[1]<databitlen) state->databitlen[0]+=1;
sbyte=oldbitlen >> 3;
mbits=oldbitlen & 0x7;
(state->block)[state->blocksize / 8] = 0x0;

for (i=0;i<(databitlen+7)/8;i++)
{
	tempc=data[i];
	(state->block)[sbyte]=(state->block)[sbyte] | (tempc >> mbits);
	(state->block)[sbyte+1]=tempc << (8-mbits);
	sbyte+=1;	
	if (sbyte==( state->blocksize/8))
	{
		HReturn=sha32_compile(state);
		
		if (HReturn != SUCCESS) { 	return HReturn;}		
		sbyte=0;
		(state->block)[0]=(state->block)[state->blocksize / 8] ;
	}
}
return SUCCESS;
}
HashReturn Final(hashState *state, BitSequence *hashval)
{
 xdata HashReturn HReturn;
xdata  BitSequence   hv[64],temp ;
xdata  DataLength dl;
xdata  int t,t1, i,maxl;

t1=((state->databitlen[1]) % (state->blocksize))/8;
t=7-(state->databitlen[1] % 8);
temp=((state->block)[t1] >> t) | 0x1;
(state->block)[t1]=temp << t; 

maxl=65;
if (state->blocksize==1024) maxl=129;
if ((state->databitlen[1] % (state->blocksize))>(state->blocksize-maxl))
{             
	HReturn=sha32_compile(state);
	
    if (HReturn != SUCCESS) { return HReturn;}

    //  second block
    for ( i=0; i<128; i++ )  
        (state->block)[i]=0x0;
}

t=state->blocksize/8;
dl=state->databitlen[1];
for (i=1;i<9;i++){
	(state->block)[t-i]=dl & 0xff;	
	dl=(dl >> 8);
}

HReturn=sha32_compile(state);


for(i=0;i<16;i++) {
		hv[4*i]=((state->hashval)[i] >> 24) & 0xff ;
		hv[4*i+1]=((state->hashval)[i] >> 16) & 0xff ;
		hv[4*i+2]=((state->hashval)[i] >> 8) & 0xff ;
		hv[4*i+3]=(state->hashval)[i] & 0xff ;			
}
t=state->blocksize/16;
for(i=0;i<t;i++) hashval[i]=hv[i];
return HReturn;
} 

HashReturn sha32_compile(hashState *state)
{  
 xdata uint_32t hash_32[8], ch[8], temp, w[16];
 xdata int i,i1;

for (i=0;i<16;i++)
{
	w[i]=(state->block)[4*i];
	w[i]=w[i]<<8 | ((state->block)[4*i+1]);
	w[i]=w[i]<<8 | ((state->block)[4*i+2]);
	w[i]=w[i]<<8 | ((state->block)[4*i+3]);	
}

for (i=0;i<8;i++) {
	ch[i]=state->hashval[i];
	hash_32[i]=state->hashval[i];
}

//iterative part
for ( i=0; i<8; i++ ) {
	for (i1=0; i1<9; i1=i1+8)
	{
		temp=((((((ch[0]^ch[1])+ch[2])^ch[3])+ch[4])^ch[5])+ch[6])^ch[7];
		temp=ROTR32(temp,(w[i+i1] & 31));
		ch[7]=ch[6];
		ch[6]=ROTR32(ch[5],((w[i+i1]>>5) & 31));		
		ch[5]=ch[4]+w[((i+3) % 8)+i1];		
		ch[4]=ROTR32(ch[3],((w[i+i1]>>10) & 31));	
		switch (w[i+i1]>>30) 
		{ case 0: ch[3]=w[((i+2) % 8)+i1]+(ch[0] ^ ch[1] ^ ch[2]);
				break;
		case 1: ch[3]=w[((i+2) % 8)+i1]+((ch[0] & ch[1]) ^ ch[2] );
				break;
		case 2: ch[3]=w[((i+2) % 8)+i1]+((~(ch[0] | ch[2])) | (ch[0] & (ch[1] ^ ch[2])));
				break;
		case 3: ch[3]=w[((i+2) % 8)+i1]+((~(ch[0] | (ch[1] ^ ch[2]))) | (ch[0] & ~(ch[2])));
				break;
		}
		ch[2]=ch[1];
		ch[1]=ch[0];
		ch[0]=temp+w[((i+1) % 8)+i1];

        temp=((((((ch[0]^ch[1])+ch[2])^ch[3])+ch[4])^ch[5])+ch[6])^ch[7];
		temp=ROTR32(temp,((w[i+i1]>>15) & 31));
		ch[7]=ch[6]+w[((i+7) % 8)+i1];
		ch[6]=ROTR32(ch[5],((w[i+i1]>>20) & 31));		
		ch[5]=ch[4]+w[((i+6) % 8)+i1];		
		ch[4]=ROTR32(ch[3],((w[i+i1]>>25) & 31));	
		switch (i % 4) 
		{ case 0: ch[3]=w[((i+5) % 8)+i1]+(ch[0] ^ ch[1] ^ ch[2]);
				break;
		case 1: ch[3]=w[((i+5) % 8)+i1]+((ch[0] & ch[1]) ^ ch[2] );
				break;
		case 2: ch[3]=w[((i+5) % 8)+i1]+((~(ch[0] | ch[2])) | (ch[0] & (ch[1] ^ ch[2])));
				break;
		case 3: ch[3]=w[((i+5) % 8)+i1]+((~(ch[0] | (ch[1] ^ ch[2]))) | (ch[0] & ~(ch[2])));
				break;
		}
		ch[2]=ch[1] + w[i+i1];
		ch[1]=ch[0];
		ch[0]=temp+w[((i+4) % 8)+i1];	
	}
	if (i==0) {
		for (i1=0;i1<9;i1++) {	
			temp=(((((ch[0]+ch[1])^ch[2])+ch[3])^ch[4])+ch[5])^ch[6];
            temp=((temp>>17) ^ temp) & 0x1ffff;			
	        temp=((temp>>10) ^ temp) & 0x3ff;
			temp=((temp>>5) ^ temp) & 0x1f;            
		    temp=ROTR32(ch[7],temp);
	        ch[7]=ch[6];
            ch[6]=ch[5];
	        ch[5]=ch[4];
	        ch[4]=ch[3];
	        ch[3]=ch[2];
            ch[2]=ch[1];
	        ch[1]=ch[0];
		    ch[0]=temp;	
		} 		
	}	
}                

for ( i=0;i<8;i++){
    hash_32[i] +=ch[i];
	state->hashval[i]=hash_32[i];
}
return SUCCESS;
}
