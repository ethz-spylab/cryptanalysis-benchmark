#include <reg51.h>
#include <stdlib.h>
#define ROTR32(x,n)   (((x) >> (n)) | ((x) << (32 - (n))))
typedef unsigned char BitSequence;  
typedef unsigned long  DataLength; 
typedef unsigned long uint_32t;
typedef enum { SUCCESS = 0, FAIL = 1, BAD_HASHLEN = 2 } HashReturn; 
typedef struct
{
    DataLength databitlen[2];
    unsigned int hashbitlen;
    unsigned int blocksize;
    BitSequence block[129];
	unsigned long hashval[16];
} hashState;
xdata   const uint_32t i224[8] =
{
    0xc1059ed8ul, 0x367cd507ul, 0x3070dd17ul, 0xf70e5939ul,
    0xffc00b31ul, 0x68581511ul, 0x64f98fa7ul, 0xbefa4fa4ul
};
xdata  const uint_32t i256[8] =
{
    0x6a09e667ul, 0xbb67ae85ul, 0x3c6ef372ul, 0xa54ff53aul,
    0x510e527ful, 0x9b05688cul, 0x1f83d9abul, 0x5be0cd19ul
};

HashReturn Init(hashState *state, int hashbitlen);   
HashReturn Update(hashState *state, const BitSequence *data, DataLength databitlen); 
HashReturn Final(hashState *state, BitSequence *hashval); 
HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen, BitSequence *hashval);
HashReturn sha32_compile(hashState *state);

HashReturn Hash(int hashbitlen, const BitSequence *data, DataLength databitlen, BitSequence *hashval)
{
 xdata hashState state;
xdata  HashReturn HReturn;

HReturn=Init(&state, hashbitlen); 
if (HReturn != SUCCESS) {	return HReturn;}

HReturn=Update(&state, data, databitlen); 
if (HReturn != SUCCESS) { 	return HReturn;}

HReturn=Final(&state, hashval); 
if (HReturn != SUCCESS) { return HReturn;}

return HReturn;
}

HashReturn Init(hashState *state, int hashbitlen)
{
 xdata 	int i;

state->hashbitlen=hashbitlen ; 
state->databitlen[0]=0;
state->databitlen[1]=0;
for (i=0;i<129;i++) (state->block)[i]= 0x0 ;

if ((hashbitlen==224) || (hashbitlen==256) )
{
    state->blocksize=512;   
	if (hashbitlen==224)  for(i=0;i<(state->blocksize/64);i++) (state->hashval)[i]=i224[i] ;
    if (hashbitlen==256)  for(i=0;i<(state->blocksize/64);i++) (state->hashval)[i]=i256[i] ;
   
}
else
{
	return BAD_HASHLEN;
}
return SUCCESS;
}

HashReturn Update(hashState *state, const BitSequence *data, DataLength databitlen)
{
xdata  HashReturn HReturn;
xdata  BitSequence  tempc;
xdata  unsigned int oldbitlen;
xdata  int  i,sbyte, mbits;

oldbitlen=state->databitlen[1] % state->blocksize;
state->databitlen[1]+=databitlen;
if (state->databitlen[1]<databitlen) state->databitlen[0]+=1;
sbyte=oldbitlen >> 3;
mbits=oldbitlen & 0x7;
(state->block)[state->blocksize / 8] = 0x0;

for (i=0;i<(databitlen+7)/8;i++)
{
	tempc=data[i];
	(state->block)[sbyte]=(state->block)[sbyte] | (tempc >> mbits);
	(state->block)[sbyte+1]=tempc << (8-mbits);
	sbyte+=1;	
	if (sbyte==( state->blocksize/8))
	{
		HReturn=sha32_compile(state);
		
		if (HReturn != SUCCESS) { 	return HReturn;}		
		sbyte=0;
		(state->block)[0]=(state->block)[state->blocksize / 8] ;
	}
}
return SUCCESS;
}
HashReturn Final(hashState *state, BitSequence *hashval)
{
xdata  HashReturn HReturn;
xdata  BitSequence   hv[64],temp ;
xdata  DataLength dl;
xdata  int t,t1, i,maxl;

t1=((state->databitlen[1]) % (state->blocksize))/8;
t=7-(state->databitlen[1] % 8);
temp=((state->block)[t1] >> t) | 0x1;
(state->block)[t1]=temp << t; 

maxl=65;
if (state->blocksize==1024) maxl=129;
if ((state->databitlen[1] % (state->blocksize))>(state->blocksize-maxl))
{             
	HReturn=sha32_compile(state);
	
    if (HReturn != SUCCESS) { return HReturn;}

    //  second block
    for ( i=0; i<128; i++ )  
        (state->block)[i]=0x0;
}

t=state->blocksize/8;
dl=state->databitlen[1];
for (i=1;i<9;i++){
	(state->block)[t-i]=dl & 0xff;	
	dl=(dl >> 8);
}

HReturn=sha32_compile(state);


for(i=0;i<16;i++) {
		hv[4*i]=((state->hashval)[i] >> 24) & 0xff ;
		hv[4*i+1]=((state->hashval)[i] >> 16) & 0xff ;
		hv[4*i+2]=((state->hashval)[i] >> 8) & 0xff ;
		hv[4*i+3]=(state->hashval)[i] & 0xff ;			
}
t=state->blocksize/16;
for(i=0;i<t;i++) hashval[i]=hv[i];
return HReturn;
} 

HashReturn sha32_compile(hashState *state)
{  
xdata  uint_32t hash_32[8], ch[8], temp, w[16];
xdata  int i;


for (i=0;i<16;i++)
{
	w[i]=(state->block)[4*i];
	w[i]=w[i]<<8 | ((state->block)[4*i+1]);
	w[i]=w[i]<<8 | ((state->block)[4*i+2]);
	w[i]=w[i]<<8 | ((state->block)[4*i+3]);	
}

for (i=0;i<8;i++) {
	ch[i]=state->hashval[i];
	hash_32[i]=state->hashval[i];
}

temp=((((((ch[0]^ch[1])+ch[2])^ch[3])+ch[4])^ch[5])+ch[6])^ch[7];
ch[7]=ROTR32(temp,(w[0] & 31))+w[1];
ch[5]=ROTR32(ch[5],((w[0]>>5) & 31));		
ch[4]=ch[4]+w[3];		
ch[3]=ROTR32(ch[3],((w[0]>>10) & 31));
switch (w[0]>>30) 
{ case 0: ch[2]=w[2]+(ch[0] ^ ch[1] ^ ch[2]);
		break;
case 1: ch[2]=w[2]+((ch[0] & ch[1]) ^ ch[2] );
		break;
case 2: ch[2]=w[2]+((~(ch[0] | ch[2])) | (ch[0] & (ch[1] ^ ch[2])));
		break;
case 3: ch[2]=w[2]+((~(ch[0] | (ch[1] ^ ch[2]))) | (ch[0] & ~(ch[2])));
		break;
}				

temp=((((((ch[7]^ch[0])+ch[1])^ch[2])+ch[3])^ch[4])+ch[5])^ch[6];
ch[6]=ROTR32(temp,((w[0]>>15) & 31))+w[4];
ch[5]=ch[5]+w[7];
ch[4]=ROTR32(ch[4],((w[0]>>20) & 31));	
ch[3]=ch[3]+w[6];		
ch[2]=ROTR32(ch[2],((w[0]>>25) & 31));	
ch[1]=w[5]+(ch[7] ^ ch[0] ^ ch[1]);
ch[0]=ch[0] + w[0];	


temp=((((((ch[6]^ch[7])+ch[0])^ch[1])+ch[2])^ch[3])+ch[4])^ch[5];
ch[5]=ROTR32(temp,(w[8] & 31))+w[9];
ch[3]=ROTR32(ch[3],((w[8]>>5) & 31));		
ch[2]=ch[2]+w[11];		
ch[1]=ROTR32(ch[1],((w[8]>>10) & 31));
switch (w[8]>>30) 
{ case 0: ch[0]=w[10]+(ch[6] ^ ch[7] ^ ch[0]);
		break;
case 1: ch[0]=w[10]+((ch[6] & ch[7]) ^ ch[0] );
		break;
case 2: ch[0]=w[10]+((~(ch[6] | ch[0])) | (ch[6] & (ch[7] ^ ch[0])));
		break;
case 3: ch[0]=w[10]+((~(ch[6] | (ch[7] ^ ch[0]))) | (ch[6] & ~(ch[0])));
		break;
}				

temp=((((((ch[5]^ch[6])+ch[7])^ch[0])+ch[1])^ch[2])+ch[3])^ch[4];
ch[4]=ROTR32(temp,((w[8]>>15) & 31))+w[12];
ch[3]=ch[3]+w[15];
ch[2]=ROTR32(ch[2],((w[8]>>20) & 31));	
ch[1]=ch[1]+w[14];		
ch[0]=ROTR32(ch[0],((w[8]>>25) & 31));	
ch[7]=w[13]+(ch[5] ^ ch[6] ^ ch[7]);
ch[6]=ch[6] + w[8];	


temp=(((((ch[ 4]+ch[ 5])^ch[ 6])+ch[ 7])^ch[ 0])+ch[ 1])^ch[ 2];
temp=((temp>>17) ^ temp) & 0x1ffff;
temp=((temp>>10) ^ temp) & 0x3ff;
temp=((temp>>5) ^ temp) & 0x1f;
ch[ 3]=ROTR32(ch[ 3],temp);

temp=(((((ch[ 3]+ch[ 4])^ch[ 5])+ch[ 6])^ch[ 7])+ch[ 0])^ch[ 1];
temp=((temp>>17) ^ temp) & 0x1ffff;
temp=((temp>>10) ^ temp) & 0x3ff;
temp=((temp>>5) ^ temp) & 0x1f;
ch[ 2]=ROTR32(ch[ 2],temp);

temp=(((((ch[ 2]+ch[ 3])^ch[ 4])+ch[ 5])^ch[ 6])+ch[ 7])^ch[ 0];
temp=((temp>>17) ^ temp) & 0x1ffff;
temp=((temp>>10) ^ temp) & 0x3ff;
temp=((temp>>5) ^ temp) & 0x1f;
ch[ 1]=ROTR32(ch[ 1],temp);

temp=(((((ch[ 1]+ch[ 2])^ch[ 3])+ch[ 4])^ch[ 5])+ch[ 6])^ch[ 7];
temp=((temp>>17) ^ temp) & 0x1ffff;
temp=((temp>>10) ^ temp) & 0x3ff;
temp=((temp>>5) ^ temp) & 0x1f;
ch[ 0]=ROTR32(ch[ 0],temp);

temp=(((((ch[ 0]+ch[ 1])^ch[ 2])+ch[ 3])^ch[ 4])+ch[ 5])^ch[ 6];
temp=((temp>>17) ^ temp) & 0x1ffff;
temp=((temp>>10) ^ temp) & 0x3ff;
temp=((temp>>5) ^ temp) & 0x1f;
ch[ 7]=ROTR32(ch[ 7],temp);

temp=(((((ch[ 7]+ch[ 0])^ch[ 1])+ch[ 2])^ch[ 3])+ch[ 4])^ch[ 5];
temp=((temp>>17) ^ temp) & 0x1ffff;
temp=((temp>>10) ^ temp) & 0x3ff;
temp=((temp>>5) ^ temp) & 0x1f;
ch[ 6]=ROTR32(ch[ 6],temp);

temp=(((((ch[ 6]+ch[ 7])^ch[ 0])+ch[ 1])^ch[ 2])+ch[ 3])^ch[ 4];
temp=((temp>>17) ^ temp) & 0x1ffff;
temp=((temp>>10) ^ temp) & 0x3ff;
temp=((temp>>5) ^ temp) & 0x1f;
ch[ 5]=ROTR32(ch[ 5],temp);

temp=(((((ch[ 5]+ch[ 6])^ch[ 7])+ch[ 0])^ch[ 1])+ch[ 2])^ch[ 3];
temp=((temp>>17) ^ temp) & 0x1ffff;
temp=((temp>>10) ^ temp) & 0x3ff;
temp=((temp>>5) ^ temp) & 0x1f;
ch[ 4]=ROTR32(ch[ 4],temp);

temp=(((((ch[ 4]+ch[ 5])^ch[ 6])+ch[ 7])^ch[ 0])+ch[ 1])^ch[ 2];
temp=((temp>>17) ^ temp) & 0x1ffff;
temp=((temp>>10) ^ temp) & 0x3ff;
temp=((temp>>5) ^ temp) & 0x1f;
ch[ 3]=ROTR32(ch[ 3],temp);



temp=((((((ch[3]^ch[4])+ch[5])^ch[6])+ch[7])^ch[0])+ch[1])^ch[2];
ch[2]=ROTR32(temp,(w[1] & 31))+w[2];
ch[0]=ROTR32(ch[0],((w[1]>>5) & 31));		
ch[7]=ch[7]+w[4];		
ch[6]=ROTR32(ch[6],((w[1]>>10) & 31));
switch (w[1]>>30) 
{ case 0: ch[5]=w[3]+(ch[3] ^ ch[4] ^ ch[5]);
		break;
case 1: ch[5]=w[3]+((ch[3] & ch[4]) ^ ch[5] );
		break;
case 2: ch[5]=w[3]+((~(ch[3] | ch[5])) | (ch[3] & (ch[4] ^ ch[5])));
		break;
case 3: ch[5]=w[3]+((~(ch[3] | (ch[4] ^ ch[5]))) | (ch[3] & ~(ch[5])));
		break;
}				

temp=((((((ch[2]^ch[3])+ch[4])^ch[5])+ch[6])^ch[7])+ch[0])^ch[1];
ch[1]=ROTR32(temp,((w[1]>>15) & 31))+w[5];
ch[0]=ch[0]+w[0];
ch[7]=ROTR32(ch[7],((w[1]>>20) & 31));	
ch[6]=ch[6]+w[7];		
ch[5]=ROTR32(ch[5],((w[1]>>25) & 31));	
ch[4]=w[6]+((ch[2] & ch[3]) ^ ch[4] );
ch[3]=ch[3] + w[1];	


temp=((((((ch[1]^ch[2])+ch[3])^ch[4])+ch[5])^ch[6])+ch[7])^ch[0];
ch[0]=ROTR32(temp,(w[9] & 31))+w[10];
ch[6]=ROTR32(ch[6],((w[9]>>5) & 31));		
ch[5]=ch[5]+w[12];		
ch[4]=ROTR32(ch[4],((w[9]>>10) & 31));
switch (w[9]>>30) 
{ case 0: ch[3]=w[11]+(ch[1] ^ ch[2] ^ ch[3]);
		break;
case 1: ch[3]=w[11]+((ch[1] & ch[2]) ^ ch[3] );
		break;
case 2: ch[3]=w[11]+((~(ch[1] | ch[3])) | (ch[1] & (ch[2] ^ ch[3])));
		break;
case 3: ch[3]=w[11]+((~(ch[1] | (ch[2] ^ ch[3]))) | (ch[1] & ~(ch[3])));
		break;
}				

temp=((((((ch[0]^ch[1])+ch[2])^ch[3])+ch[4])^ch[5])+ch[6])^ch[7];
ch[7]=ROTR32(temp,((w[9]>>15) & 31))+w[13];
ch[6]=ch[6]+w[8];
ch[5]=ROTR32(ch[5],((w[9]>>20) & 31));	
ch[4]=ch[4]+w[15];		
ch[3]=ROTR32(ch[3],((w[9]>>25) & 31));	
ch[2]=w[14]+((ch[0] & ch[1]) ^ ch[2] );
ch[1]=ch[1] + w[9];	


temp=((((((ch[7]^ch[0])+ch[1])^ch[2])+ch[3])^ch[4])+ch[5])^ch[6];
ch[6]=ROTR32(temp,(w[2] & 31))+w[3];
ch[4]=ROTR32(ch[4],((w[2]>>5) & 31));		
ch[3]=ch[3]+w[5];		
ch[2]=ROTR32(ch[2],((w[2]>>10) & 31));
switch (w[2]>>30) 
{ case 0: ch[1]=w[4]+(ch[7] ^ ch[0] ^ ch[1]);
		break;
case 1: ch[1]=w[4]+((ch[7] & ch[0]) ^ ch[1] );
		break;
case 2: ch[1]=w[4]+((~(ch[7] | ch[1])) | (ch[7] & (ch[0] ^ ch[1])));
		break;
case 3: ch[1]=w[4]+((~(ch[7] | (ch[0] ^ ch[1]))) | (ch[7] & ~(ch[1])));
		break;
}				

temp=((((((ch[6]^ch[7])+ch[0])^ch[1])+ch[2])^ch[3])+ch[4])^ch[5];
ch[5]=ROTR32(temp,((w[2]>>15) & 31))+w[6];
ch[4]=ch[4]+w[1];
ch[3]=ROTR32(ch[3],((w[2]>>20) & 31));	
ch[2]=ch[2]+w[0];		
ch[1]=ROTR32(ch[1],((w[2]>>25) & 31));	
ch[0]=w[7]+((~(ch[6] | ch[0])) | (ch[6] & (ch[7] ^ ch[0])));
ch[7]=ch[7] + w[2];	


temp=((((((ch[5]^ch[6])+ch[7])^ch[0])+ch[1])^ch[2])+ch[3])^ch[4];
ch[4]=ROTR32(temp,(w[10] & 31))+w[11];
ch[2]=ROTR32(ch[2],((w[10]>>5) & 31));		
ch[1]=ch[1]+w[13];		
ch[0]=ROTR32(ch[0],((w[10]>>10) & 31));
switch (w[10]>>30) 
{ case 0: ch[7]=w[12]+(ch[5] ^ ch[6] ^ ch[7]);
		break;
case 1: ch[7]=w[12]+((ch[5] & ch[6]) ^ ch[7] );
		break;
case 2: ch[7]=w[12]+((~(ch[5] | ch[7])) | (ch[5] & (ch[6] ^ ch[7])));
		break;
case 3: ch[7]=w[12]+((~(ch[5] | (ch[6] ^ ch[7]))) | (ch[5] & ~(ch[7])));
		break;
}				

temp=((((((ch[4]^ch[5])+ch[6])^ch[7])+ch[0])^ch[1])+ch[2])^ch[3];
ch[3]=ROTR32(temp,((w[10]>>15) & 31))+w[14];
ch[2]=ch[2]+w[9];
ch[1]=ROTR32(ch[1],((w[10]>>20) & 31));	
ch[0]=ch[0]+w[8];		
ch[7]=ROTR32(ch[7],((w[10]>>25) & 31));	
ch[6]=w[15]+((~(ch[4] | ch[6])) | (ch[4] & (ch[5] ^ ch[6])));
ch[5]=ch[5] + w[10];	


temp=((((((ch[3]^ch[4])+ch[5])^ch[6])+ch[7])^ch[0])+ch[1])^ch[2];
ch[2]=ROTR32(temp,(w[3] & 31))+w[4];
ch[0]=ROTR32(ch[0],((w[3]>>5) & 31));		
ch[7]=ch[7]+w[6];		
ch[6]=ROTR32(ch[6],((w[3]>>10) & 31));
switch (w[3]>>30) 
{ case 0: ch[5]=w[5]+(ch[3] ^ ch[4] ^ ch[5]);
		break;
case 1: ch[5]=w[5]+((ch[3] & ch[4]) ^ ch[5] );
		break;
case 2: ch[5]=w[5]+((~(ch[3] | ch[5])) | (ch[3] & (ch[4] ^ ch[5])));
		break;
case 3: ch[5]=w[5]+((~(ch[3] | (ch[4] ^ ch[5]))) | (ch[3] & ~(ch[5])));
		break;
}				

temp=((((((ch[2]^ch[3])+ch[4])^ch[5])+ch[6])^ch[7])+ch[0])^ch[1];
ch[1]=ROTR32(temp,((w[3]>>15) & 31))+w[7];
ch[0]=ch[0]+w[2];
ch[7]=ROTR32(ch[7],((w[3]>>20) & 31));	
ch[6]=ch[6]+w[1];		
ch[5]=ROTR32(ch[5],((w[3]>>25) & 31));	
ch[4]=w[0]+((~(ch[2] | (ch[3] ^ ch[4]))) | (ch[2] & ~(ch[4])));
ch[3]=ch[3] + w[3];	


temp=((((((ch[1]^ch[2])+ch[3])^ch[4])+ch[5])^ch[6])+ch[7])^ch[0];
ch[0]=ROTR32(temp,(w[11] & 31))+w[12];
ch[6]=ROTR32(ch[6],((w[11]>>5) & 31));		
ch[5]=ch[5]+w[14];		
ch[4]=ROTR32(ch[4],((w[11]>>10) & 31));
switch (w[11]>>30) 
{ case 0: ch[3]=w[13]+(ch[1] ^ ch[2] ^ ch[3]);
		break;
case 1: ch[3]=w[13]+((ch[1] & ch[2]) ^ ch[3] );
		break;
case 2: ch[3]=w[13]+((~(ch[1] | ch[3])) | (ch[1] & (ch[2] ^ ch[3])));
		break;
case 3: ch[3]=w[13]+((~(ch[1] | (ch[2] ^ ch[3]))) | (ch[1] & ~(ch[3])));
		break;
}				

temp=((((((ch[0]^ch[1])+ch[2])^ch[3])+ch[4])^ch[5])+ch[6])^ch[7];
ch[7]=ROTR32(temp,((w[11]>>15) & 31))+w[15];
ch[6]=ch[6]+w[10];
ch[5]=ROTR32(ch[5],((w[11]>>20) & 31));	
ch[4]=ch[4]+w[9];		
ch[3]=ROTR32(ch[3],((w[11]>>25) & 31));	
ch[2]=w[8]+((~(ch[0] | (ch[1] ^ ch[2]))) | (ch[0] & ~(ch[2])));
ch[1]=ch[1] + w[11];	


temp=((((((ch[7]^ch[0])+ch[1])^ch[2])+ch[3])^ch[4])+ch[5])^ch[6];
ch[6]=ROTR32(temp,(w[4] & 31))+w[5];
ch[4]=ROTR32(ch[4],((w[4]>>5) & 31));		
ch[3]=ch[3]+w[7];		
ch[2]=ROTR32(ch[2],((w[4]>>10) & 31));
switch (w[4]>>30) 
{ case 0: ch[1]=w[6]+(ch[7] ^ ch[0] ^ ch[1]);
		break;
case 1: ch[1]=w[6]+((ch[7] & ch[0]) ^ ch[1] );
		break;
case 2: ch[1]=w[6]+((~(ch[7] | ch[1])) | (ch[7] & (ch[0] ^ ch[1])));
		break;
case 3: ch[1]=w[6]+((~(ch[7] | (ch[0] ^ ch[1]))) | (ch[7] & ~(ch[1])));
		break;
}				

temp=((((((ch[6]^ch[7])+ch[0])^ch[1])+ch[2])^ch[3])+ch[4])^ch[5];
ch[5]=ROTR32(temp,((w[4]>>15) & 31))+w[0];
ch[4]=ch[4]+w[3];
ch[3]=ROTR32(ch[3],((w[4]>>20) & 31));	
ch[2]=ch[2]+w[2];		
ch[1]=ROTR32(ch[1],((w[4]>>25) & 31));	
ch[0]=w[1]+(ch[6] ^ ch[7] ^ ch[0]);
ch[7]=ch[7] + w[4];	


temp=((((((ch[5]^ch[6])+ch[7])^ch[0])+ch[1])^ch[2])+ch[3])^ch[4];
ch[4]=ROTR32(temp,(w[12] & 31))+w[13];
ch[2]=ROTR32(ch[2],((w[12]>>5) & 31));		
ch[1]=ch[1]+w[15];		
ch[0]=ROTR32(ch[0],((w[12]>>10) & 31));
switch (w[12]>>30) 
{ case 0: ch[7]=w[14]+(ch[5] ^ ch[6] ^ ch[7]);
		break;
case 1: ch[7]=w[14]+((ch[5] & ch[6]) ^ ch[7] );
		break;
case 2: ch[7]=w[14]+((~(ch[5] | ch[7])) | (ch[5] & (ch[6] ^ ch[7])));
		break;
case 3: ch[7]=w[14]+((~(ch[5] | (ch[6] ^ ch[7]))) | (ch[5] & ~(ch[7])));
		break;
}				

temp=((((((ch[4]^ch[5])+ch[6])^ch[7])+ch[0])^ch[1])+ch[2])^ch[3];
ch[3]=ROTR32(temp,((w[12]>>15) & 31))+w[8];
ch[2]=ch[2]+w[11];
ch[1]=ROTR32(ch[1],((w[12]>>20) & 31));	
ch[0]=ch[0]+w[10];		
ch[7]=ROTR32(ch[7],((w[12]>>25) & 31));	
ch[6]=w[9]+(ch[4] ^ ch[5] ^ ch[6]);
ch[5]=ch[5] + w[12];	


temp=((((((ch[3]^ch[4])+ch[5])^ch[6])+ch[7])^ch[0])+ch[1])^ch[2];
ch[2]=ROTR32(temp,(w[5] & 31))+w[6];
ch[0]=ROTR32(ch[0],((w[5]>>5) & 31));		
ch[7]=ch[7]+w[0];		
ch[6]=ROTR32(ch[6],((w[5]>>10) & 31));
switch (w[5]>>30) 
{ case 0: ch[5]=w[7]+(ch[3] ^ ch[4] ^ ch[5]);
		break;
case 1: ch[5]=w[7]+((ch[3] & ch[4]) ^ ch[5] );
		break;
case 2: ch[5]=w[7]+((~(ch[3] | ch[5])) | (ch[3] & (ch[4] ^ ch[5])));
		break;
case 3: ch[5]=w[7]+((~(ch[3] | (ch[4] ^ ch[5]))) | (ch[3] & ~(ch[5])));
		break;
}				

temp=((((((ch[2]^ch[3])+ch[4])^ch[5])+ch[6])^ch[7])+ch[0])^ch[1];
ch[1]=ROTR32(temp,((w[5]>>15) & 31))+w[1];
ch[0]=ch[0]+w[4];
ch[7]=ROTR32(ch[7],((w[5]>>20) & 31));	
ch[6]=ch[6]+w[3];		
ch[5]=ROTR32(ch[5],((w[5]>>25) & 31));	
ch[4]=w[2]+((ch[2] & ch[3]) ^ ch[4] );
ch[3]=ch[3] + w[5];	


temp=((((((ch[1]^ch[2])+ch[3])^ch[4])+ch[5])^ch[6])+ch[7])^ch[0];
ch[0]=ROTR32(temp,(w[13] & 31))+w[14];
ch[6]=ROTR32(ch[6],((w[13]>>5) & 31));		
ch[5]=ch[5]+w[8];		
ch[4]=ROTR32(ch[4],((w[13]>>10) & 31));
switch (w[13]>>30) 
{ case 0: ch[3]=w[15]+(ch[1] ^ ch[2] ^ ch[3]);
		break;
case 1: ch[3]=w[15]+((ch[1] & ch[2]) ^ ch[3] );
		break;
case 2: ch[3]=w[15]+((~(ch[1] | ch[3])) | (ch[1] & (ch[2] ^ ch[3])));
		break;
case 3: ch[3]=w[15]+((~(ch[1] | (ch[2] ^ ch[3]))) | (ch[1] & ~(ch[3])));
		break;
}				

temp=((((((ch[0]^ch[1])+ch[2])^ch[3])+ch[4])^ch[5])+ch[6])^ch[7];
ch[7]=ROTR32(temp,((w[13]>>15) & 31))+w[9];
ch[6]=ch[6]+w[12];
ch[5]=ROTR32(ch[5],((w[13]>>20) & 31));	
ch[4]=ch[4]+w[11];		
ch[3]=ROTR32(ch[3],((w[13]>>25) & 31));	
ch[2]=w[10]+((ch[0] & ch[1]) ^ ch[2] );
ch[1]=ch[1] + w[13];	


temp=((((((ch[7]^ch[0])+ch[1])^ch[2])+ch[3])^ch[4])+ch[5])^ch[6];
ch[6]=ROTR32(temp,(w[6] & 31))+w[7];
ch[4]=ROTR32(ch[4],((w[6]>>5) & 31));		
ch[3]=ch[3]+w[1];		
ch[2]=ROTR32(ch[2],((w[6]>>10) & 31));
switch (w[6]>>30) 
{ case 0: ch[1]=w[0]+(ch[7] ^ ch[0] ^ ch[1]);
		break;
case 1: ch[1]=w[0]+((ch[7] & ch[0]) ^ ch[1] );
		break;
case 2: ch[1]=w[0]+((~(ch[7] | ch[1])) | (ch[7] & (ch[0] ^ ch[1])));
		break;
case 3: ch[1]=w[0]+((~(ch[7] | (ch[0] ^ ch[1]))) | (ch[7] & ~(ch[1])));
		break;
}				

temp=((((((ch[6]^ch[7])+ch[0])^ch[1])+ch[2])^ch[3])+ch[4])^ch[5];
ch[5]=ROTR32(temp,((w[6]>>15) & 31))+w[2];
ch[4]=ch[4]+w[5];
ch[3]=ROTR32(ch[3],((w[6]>>20) & 31));	
ch[2]=ch[2]+w[4];		
ch[1]=ROTR32(ch[1],((w[6]>>25) & 31));	
ch[0]=w[3]+((~(ch[6] | ch[0])) | (ch[6] & (ch[7] ^ ch[0])));
ch[7]=ch[7] + w[6];	


temp=((((((ch[5]^ch[6])+ch[7])^ch[0])+ch[1])^ch[2])+ch[3])^ch[4];
ch[4]=ROTR32(temp,(w[14] & 31))+w[15];
ch[2]=ROTR32(ch[2],((w[14]>>5) & 31));		
ch[1]=ch[1]+w[9];		
ch[0]=ROTR32(ch[0],((w[14]>>10) & 31));
switch (w[14]>>30) 
{ case 0: ch[7]=w[8]+(ch[5] ^ ch[6] ^ ch[7]);
		break;
case 1: ch[7]=w[8]+((ch[5] & ch[6]) ^ ch[7] );
		break;
case 2: ch[7]=w[8]+((~(ch[5] | ch[7])) | (ch[5] & (ch[6] ^ ch[7])));
		break;
case 3: ch[7]=w[8]+((~(ch[5] | (ch[6] ^ ch[7]))) | (ch[5] & ~(ch[7])));
		break;
}				

temp=((((((ch[4]^ch[5])+ch[6])^ch[7])+ch[0])^ch[1])+ch[2])^ch[3];
ch[3]=ROTR32(temp,((w[14]>>15) & 31))+w[10];
ch[2]=ch[2]+w[13];
ch[1]=ROTR32(ch[1],((w[14]>>20) & 31));	
ch[0]=ch[0]+w[12];		
ch[7]=ROTR32(ch[7],((w[14]>>25) & 31));	
ch[6]=w[11]+((~(ch[4] | ch[6])) | (ch[4] & (ch[5] ^ ch[6])));
ch[5]=ch[5] + w[14];	


temp=((((((ch[3]^ch[4])+ch[5])^ch[6])+ch[7])^ch[0])+ch[1])^ch[2];
ch[2]=ROTR32(temp,(w[7] & 31))+w[0];
ch[0]=ROTR32(ch[0],((w[7]>>5) & 31));		
ch[7]=ch[7]+w[2];		
ch[6]=ROTR32(ch[6],((w[7]>>10) & 31));
switch (w[7]>>30) 
{ case 0: ch[5]=w[1]+(ch[3] ^ ch[4] ^ ch[5]);
		break;
case 1: ch[5]=w[1]+((ch[3] & ch[4]) ^ ch[5] );
		break;
case 2: ch[5]=w[1]+((~(ch[3] | ch[5])) | (ch[3] & (ch[4] ^ ch[5])));
		break;
case 3: ch[5]=w[1]+((~(ch[3] | (ch[4] ^ ch[5]))) | (ch[3] & ~(ch[5])));
		break;
}				

temp=((((((ch[2]^ch[3])+ch[4])^ch[5])+ch[6])^ch[7])+ch[0])^ch[1];
ch[1]=ROTR32(temp,((w[7]>>15) & 31))+w[3];
ch[0]=ch[0]+w[6];
ch[7]=ROTR32(ch[7],((w[7]>>20) & 31));	
ch[6]=ch[6]+w[5];		
ch[5]=ROTR32(ch[5],((w[7]>>25) & 31));	
ch[4]=w[4]+((~(ch[2] | (ch[3] ^ ch[4]))) | (ch[2] & ~(ch[4])));
ch[3]=ch[3] + w[7];	


temp=((((((ch[1]^ch[2])+ch[3])^ch[4])+ch[5])^ch[6])+ch[7])^ch[0];
ch[0]=ROTR32(temp,(w[15] & 31))+w[8];
ch[6]=ROTR32(ch[6],((w[15]>>5) & 31));		
ch[5]=ch[5]+w[10];		
ch[4]=ROTR32(ch[4],((w[15]>>10) & 31));
switch (w[15]>>30) 
{ case 0: ch[3]=w[9]+(ch[1] ^ ch[2] ^ ch[3]);
		break;
case 1: ch[3]=w[9]+((ch[1] & ch[2]) ^ ch[3] );
		break;
case 2: ch[3]=w[9]+((~(ch[1] | ch[3])) | (ch[1] & (ch[2] ^ ch[3])));
		break;
case 3: ch[3]=w[9]+((~(ch[1] | (ch[2] ^ ch[3]))) | (ch[1] & ~(ch[3])));
		break;
}				

temp=((((((ch[0]^ch[1])+ch[2])^ch[3])+ch[4])^ch[5])+ch[6])^ch[7];
ch[7]=ROTR32(temp,((w[15]>>15) & 31))+w[11];
ch[6]=ch[6]+w[14];
ch[5]=ROTR32(ch[5],((w[15]>>20) & 31));	
ch[4]=ch[4]+w[13];		
ch[3]=ROTR32(ch[3],((w[15]>>25) & 31));	
ch[2]=w[12]+((~(ch[0] | (ch[1] ^ ch[2]))) | (ch[0] & ~(ch[2])));
ch[1]=ch[1] + w[15];	




temp=ch[7];
for (i=7; i>0; i--) { 
	ch[i]=ch[i-1];
}
ch[0]=temp;

for ( i=0;i<8;i++){
    hash_32[i] +=ch[i];
	state->hashval[i]=hash_32[i];
}
return SUCCESS;
}
