#include <reg51.h>
#include <stdio.h>
typedef unsigned char BitSequence;  
typedef unsigned long DataLength;  
typedef unsigned long uint_32t;
typedef enum { SUCCESS = 0, FAIL = 1, BAD_HASHLEN = 2 } HashReturn; 
typedef struct
{
    DataLength databitlen[4];
    unsigned int hashbitlen;
    unsigned int blocksize;
    BitSequence block[129];
	unsigned long hashval[16];
} hashState;
typedef struct
{
    uint_32t w[16][2];
	uint_32t ch[8][2];
} workvariable;
xdata const uint_32t  i384[16] =
{
    0xcbbb9d5d,  0xc1059ed8,  0x629a292a,  0x367cd507,
    0x9159015a,  0x3070dd17,  0x152fecd8,  0xf70e5939,
    0x67332667,  0xffc00b31,  0x8eb44a87,  0x68581511,
    0xdb0c2e0d,  0x64f98fa7,  0x47b5481d,  0xbefa4fa4
};
xdata const uint_32t  i512[16] =
{
    0x6a09e667,  0xf3bcc908,  0xbb67ae85,  0x84caa73b,
    0x3c6ef372,  0xfe94f82b,  0xa54ff53a,  0x5f1d36f1,
    0x510e527f,  0xade682d1,  0x9b05688c,  0x2b3e6c1f,
    0x1f83d9ab,  0xfb41bd6b,  0x5be0cd19,  0x137e2179
};

void mix(uint_32t a[], uint_32t b[], uint_32t c[], uint_32t t, uint_32t d[])
{
	switch (t) 
		{ case 0: d[0]=a[0] ^ b[0] ^ c[0];
				d[1]=a[1] ^ b[1] ^ c[1];
				break;
		case 1: d[0]=(a[0] & b[0]) ^ c[0];
				d[1]=(a[1] & b[1]) ^ c[1];
				break;
		case 2: d[0]=(~(a[0] | c[0])) | (a[0] & (b[0] ^ c[0]));
				d[1]=(~(a[1] | c[1])) | (a[1] & (b[1] ^ c[1]));
				break;
		case 3: d[0]=(~(a[0] | (b[0] ^ c[0]))) | (a[0] & (~(c[0])));
				d[1]=(~(a[1] | (b[1] ^ c[1]))) | (a[1] & (~(c[1])));
				break;
		}
}


void ro64(uint_32t h[], uint_32t rt, uint_32t temp[])
{
	if (rt> 32)	{
		temp[0]=(h[0] << (64-rt)) | (h[1] >> (rt-32));
		temp[1]=(h[1] << (64-rt)) | (h[0] >> (rt-32));
	}
	if (rt<32 && rt>0)	{	
		temp[0]=(h[1] << (32-rt)) | (h[0] >> rt);
		temp[1]=(h[0] << (32-rt)) | (h[1] >> rt);
	}
	if(rt==32) {
		temp[0]=h[1];
		temp[1]=h[0];
	}
	if(rt==0) {
		temp[0]=h[0];
		temp[1]=h[1];
	}
}


void rt64(uint_32t a[],uint_32t b[],uint_32t c[],uint_32t d[],uint_32t e[],uint_32t f[],uint_32t g[],uint_32t h[],uint_32t t[])
{
xdata uint_32t temp[2];
//temp=((((((ch[0]^ch[1])+ch[2])^ch[3])+ch[4])^ch[5])+ch[6])^ch[7];
	temp[1]=a[1]^b[1];
    temp[0]=a[0]^b[0];
	temp[1]=temp[1] + c[1];
	temp[0]=temp[0] + c[0];
    if (temp[1]<c[1]) temp[0]+=1;

	temp[1]=temp[1]^d[1];
    temp[0]=temp[0]^d[0];
	temp[1]=temp[1] + e[1];
	temp[0]=temp[0] + e[0];
    if (temp[1]<e[1]) temp[0]+=1;

	temp[1]=temp[1]^f[1];
    temp[0]=temp[0]^f[0];
	temp[1]=temp[1] + g[1];
	temp[0]=temp[0] + g[0];
    if (temp[1]<g[1]) temp[0]+=1;

	t[1]=temp[1]^h[1];
    t[0]=temp[0]^h[0];
}


void sha64_com1(workvariable *wv)
{  
xdata uint_32t   temp1[2],rt,temp2[2];

rt64((wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],temp1);
rt=(wv->w)[0][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[0][1]>>6 & 0x3f; 
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][0]=temp1[0];
(wv->ch)[5][1]=temp1[1];
rt=(wv->w)[0][1]>>12 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][1]=temp1[1]+(wv->w)[3][1];
(wv->ch)[4][0]=temp1[0]+(wv->w)[3][0];
if ((wv->ch)[4][1]<(wv->w)[3][1]) (wv->ch)[4][0]+=1;
rt=(wv->w)[0][1]>>18 & 0x3f;
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][0]=temp1[0];
(wv->ch)[3][1]=temp1[1];

rt=(wv->w)[0][0]>>30;
mix((wv->ch)[0],(wv->ch)[1],(wv->ch)[2],rt,temp1);
(wv->ch)[2][1]=temp1[1]+(wv->w)[2][1];
(wv->ch)[2][0]=temp1[0]+(wv->w)[2][0];
if ((wv->ch)[2][1]<(wv->w)[2][1]) (wv->ch)[2][0]+=1; 

rt=(wv->w)[0][1]>>24 & 0x3f; 
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][0]=temp1[0];
(wv->ch)[1][1]=temp1[1];
(wv->ch)[7][1]=temp2[1]+(wv->w)[1][1];
(wv->ch)[7][0]=temp2[0]+(wv->w)[1][0];
if ((wv->ch)[7][1]<(wv->w)[1][1]) (wv->ch)[7][0]+=1; 

rt64((wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],temp1);
rt=((wv->w)[0][1]>>30) +(((wv->w)[0][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[5][1]=(wv->ch)[5][1]+(wv->w)[7][1];
(wv->ch)[5][0]=(wv->ch)[5][0]+(wv->w)[7][0];
if ((wv->ch)[5][1]<(wv->w)[7][1]) (wv->ch)[5][0]+=1;
rt=(wv->w)[0][0]>>4 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1]; 
rt=(wv->w)[0][0]>>10 & 0x3f; 
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][1]=temp1[1]+(wv->w)[6][1];
(wv->ch)[3][0]=temp1[0]+(wv->w)[6][0];
if ((wv->ch)[3][1]<(wv->w)[6][1]) (wv->ch)[3][0]+=1;
rt=(wv->w)[0][0]>>16 & 0x3f;
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1]; 

rt=(wv->w)[0][0]>>28 & 0x3;
mix((wv->ch)[7],(wv->ch)[0],(wv->ch)[1],rt,temp1);
(wv->ch)[1][1]=temp1[1]+(wv->w)[5][1];
(wv->ch)[1][0]=temp1[0]+(wv->w)[5][0];
if ((wv->ch)[1][1]<(wv->w)[5][1]) (wv->ch)[1][0]+=1;

(wv->ch)[0][1]+=(wv->w)[0][1];
(wv->ch)[0][0]+=(wv->w)[0][0];
if ((wv->ch)[0][1]<(wv->w)[0][1]) (wv->ch)[0][0]+=1; 
rt=(wv->w)[0][0]>>22 & 0x3f;
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][0]=temp1[0];
(wv->ch)[7][1]=temp1[1]; 
(wv->ch)[6][1]=temp2[1]+(wv->w)[4][1];
(wv->ch)[6][0]=temp2[0]+(wv->w)[4][0];
if ((wv->ch)[6][1]<(wv->w)[4][1]) (wv->ch)[6][0]+=1;


rt64((wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],temp1);
rt=(wv->w)[8][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[8][1]>>6 & 0x3f; 
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][0]=temp1[0];
(wv->ch)[3][1]=temp1[1];
rt=(wv->w)[8][1]>>12 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][1]=temp1[1]+(wv->w)[11][1];
(wv->ch)[2][0]=temp1[0]+(wv->w)[11][0];
if ((wv->ch)[2][1]<(wv->w)[11][1]) (wv->ch)[2][0]+=1;
rt=(wv->w)[8][1]>>18 & 0x3f;
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][0]=temp1[0];
(wv->ch)[1][1]=temp1[1];

rt=(wv->w)[8][0]>>30;
mix((wv->ch)[6],(wv->ch)[7],(wv->ch)[0],rt,temp1);
(wv->ch)[0][1]=temp1[1]+(wv->w)[10][1];
(wv->ch)[0][0]=temp1[0]+(wv->w)[10][0];
if ((wv->ch)[0][1]<(wv->w)[10][1]) (wv->ch)[0][0]+=1;

rt=(wv->w)[8][1]>>24 & 0x3f; 
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][0]=temp1[0];
(wv->ch)[7][1]=temp1[1];
(wv->ch)[5][1]=temp2[1]+(wv->w)[9][1];
(wv->ch)[5][0]=temp2[0]+(wv->w)[9][0];
if ((wv->ch)[5][1]<(wv->w)[9][1]) (wv->ch)[5][0]+=1; 

rt64((wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],temp1);
rt=((wv->w)[8][1]>>30) +(((wv->w)[8][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[3][1]=(wv->ch)[3][1]+(wv->w)[15][1];
(wv->ch)[3][0]=(wv->ch)[3][0]+(wv->w)[15][0];
if ((wv->ch)[3][1]<(wv->w)[15][1]) (wv->ch)[3][0]+=1;
rt=(wv->w)[8][0]>>4 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1]; 
rt=(wv->w)[8][0]>>10 & 0x3f; 
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][1]=temp1[1]+(wv->w)[14][1];
(wv->ch)[1][0]=temp1[0]+(wv->w)[14][0];
if ((wv->ch)[1][1]<(wv->w)[14][1]) (wv->ch)[1][0]+=1;
rt=(wv->w)[8][0]>>16 & 0x3f;
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1]; 

rt=(wv->w)[8][0]>>28 & 0x3;
mix((wv->ch)[5],(wv->ch)[6],(wv->ch)[7],rt,temp1);
(wv->ch)[7][1]=temp1[1]+(wv->w)[13][1];
(wv->ch)[7][0]=temp1[0]+(wv->w)[13][0];
if ((wv->ch)[7][1]<(wv->w)[13][1]) (wv->ch)[7][0]+=1;


(wv->ch)[6][1]+=(wv->w)[8][1];
(wv->ch)[6][0]+=(wv->w)[8][0];
if ((wv->ch)[6][1]<(wv->w)[8][1]) (wv->ch)[6][0]+=1; 
rt=(wv->w)[8][0]>>22 & 0x3f;
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][0]=temp1[0];
(wv->ch)[5][1]=temp1[1]; 
(wv->ch)[4][1]=temp2[1]+(wv->w)[12][1];
(wv->ch)[4][0]=temp2[0]+(wv->w)[12][0];
if ((wv->ch)[4][1]<(wv->w)[12][1]) (wv->ch)[4][0]+=1;


temp2[0]=0x0;
temp2[1]=0x0;
rt64(temp2,(wv->ch)[4], (wv->ch)[5], (wv->ch)[6], (wv->ch)[7], (wv->ch)[0], (wv->ch)[1], (wv->ch)[2],temp1);
temp1[1]=temp1[0]>>4 ^temp1[1];
temp1[0]=temp1[0] & 0xf;
temp1[1]=temp1[1] ^ (temp1[1] >>18) ^ (temp1[0]<<14);
temp1[1]=temp1[1] & 0x3ffff;
temp1[1]=((temp1[1]>>12) ^ temp1[1]) & 0xfff;
temp1[1]=((temp1[1]>>6) ^ temp1[1]) & 0x3f;
rt=temp1[1];
ro64((wv->ch)[3],rt,temp2);
(wv->ch)[3][0]=temp2[0];
(wv->ch)[3][1]=temp2[1];

temp2[0]=0x0;
temp2[1]=0x0;
rt64(temp2,(wv->ch)[3], (wv->ch)[4], (wv->ch)[5], (wv->ch)[6], (wv->ch)[7], (wv->ch)[0], (wv->ch)[1],temp1);
temp1[1]=temp1[0]>>4 ^temp1[1];
temp1[0]=temp1[0] & 0xf;
temp1[1]=temp1[1] ^ (temp1[1] >>18) ^ (temp1[0]<<14);
temp1[1]=temp1[1] & 0x3ffff;
temp1[1]=((temp1[1]>>12) ^ temp1[1]) & 0xfff;
temp1[1]=((temp1[1]>>6) ^ temp1[1]) & 0x3f;
rt=temp1[1];
ro64((wv->ch)[2],rt,temp2);
(wv->ch)[2][0]=temp2[0];
(wv->ch)[2][1]=temp2[1];

temp2[0]=0x0;
temp2[1]=0x0;
rt64(temp2,(wv->ch)[2], (wv->ch)[3], (wv->ch)[4], (wv->ch)[5], (wv->ch)[6], (wv->ch)[7], (wv->ch)[0],temp1);
temp1[1]=temp1[0]>>4 ^temp1[1];
temp1[0]=temp1[0] & 0xf;
temp1[1]=temp1[1] ^ (temp1[1] >>18) ^ (temp1[0]<<14);
temp1[1]=temp1[1] & 0x3ffff;
temp1[1]=((temp1[1]>>12) ^ temp1[1]) & 0xfff;
temp1[1]=((temp1[1]>>6) ^ temp1[1]) & 0x3f;
rt=temp1[1];
ro64((wv->ch)[1],rt,temp2);
(wv->ch)[1][0]=temp2[0];
(wv->ch)[1][1]=temp2[1];

temp2[0]=0x0;
temp2[1]=0x0;
rt64(temp2,(wv->ch)[1], (wv->ch)[2], (wv->ch)[3], (wv->ch)[4], (wv->ch)[5], (wv->ch)[6], (wv->ch)[7],temp1);
temp1[1]=temp1[0]>>4 ^temp1[1];
temp1[0]=temp1[0] & 0xf;
temp1[1]=temp1[1] ^ (temp1[1] >>18) ^ (temp1[0]<<14);
temp1[1]=temp1[1] & 0x3ffff;
temp1[1]=((temp1[1]>>12) ^ temp1[1]) & 0xfff;
temp1[1]=((temp1[1]>>6) ^ temp1[1]) & 0x3f;
rt=temp1[1];
ro64((wv->ch)[0],rt,temp2);
(wv->ch)[0][0]=temp2[0];
(wv->ch)[0][1]=temp2[1];

temp2[0]=0x0;
temp2[1]=0x0;
rt64(temp2,(wv->ch)[0], (wv->ch)[1], (wv->ch)[2], (wv->ch)[3], (wv->ch)[4], (wv->ch)[5], (wv->ch)[6],temp1);
temp1[1]=temp1[0]>>4 ^temp1[1];
temp1[0]=temp1[0] & 0xf;
temp1[1]=temp1[1] ^ (temp1[1] >>18) ^ (temp1[0]<<14);
temp1[1]=temp1[1] & 0x3ffff;
temp1[1]=((temp1[1]>>12) ^ temp1[1]) & 0xfff;
temp1[1]=((temp1[1]>>6) ^ temp1[1]) & 0x3f;
rt=temp1[1];
ro64((wv->ch)[7],rt,temp2);
(wv->ch)[7][0]=temp2[0];
(wv->ch)[7][1]=temp2[1];

temp2[0]=0x0;
temp2[1]=0x0;
rt64(temp2,(wv->ch)[7], (wv->ch)[0], (wv->ch)[1], (wv->ch)[2], (wv->ch)[3], (wv->ch)[4], (wv->ch)[5],temp1);
temp1[1]=temp1[0]>>4 ^temp1[1];
temp1[0]=temp1[0] & 0xf;
temp1[1]=temp1[1] ^ (temp1[1] >>18) ^ (temp1[0]<<14);
temp1[1]=temp1[1] & 0x3ffff;
temp1[1]=((temp1[1]>>12) ^ temp1[1]) & 0xfff;
temp1[1]=((temp1[1]>>6) ^ temp1[1]) & 0x3f;
rt=temp1[1];
ro64((wv->ch)[6],rt,temp2);
(wv->ch)[6][0]=temp2[0];
(wv->ch)[6][1]=temp2[1];

temp2[0]=0x0;
temp2[1]=0x0;
rt64(temp2,(wv->ch)[6], (wv->ch)[7], (wv->ch)[0], (wv->ch)[1], (wv->ch)[2], (wv->ch)[3], (wv->ch)[4],temp1);
temp1[1]=temp1[0]>>4 ^temp1[1];
temp1[0]=temp1[0] & 0xf;
temp1[1]=temp1[1] ^ (temp1[1] >>18) ^ (temp1[0]<<14);
temp1[1]=temp1[1] & 0x3ffff;
temp1[1]=((temp1[1]>>12) ^ temp1[1]) & 0xfff;
temp1[1]=((temp1[1]>>6) ^ temp1[1]) & 0x3f;
rt=temp1[1];
ro64((wv->ch)[5],rt,temp2);
(wv->ch)[5][0]=temp2[0];
(wv->ch)[5][1]=temp2[1];

temp2[0]=0x0;
temp2[1]=0x0;
rt64(temp2,(wv->ch)[5], (wv->ch)[6], (wv->ch)[7], (wv->ch)[0], (wv->ch)[1], (wv->ch)[2], (wv->ch)[3],temp1);
temp1[1]=temp1[0]>>4 ^temp1[1];
temp1[0]=temp1[0] & 0xf;
temp1[1]=temp1[1] ^ (temp1[1] >>18) ^ (temp1[0]<<14);
temp1[1]=temp1[1] & 0x3ffff;
temp1[1]=((temp1[1]>>12) ^ temp1[1]) & 0xfff;
temp1[1]=((temp1[1]>>6) ^ temp1[1]) & 0x3f;
rt=temp1[1];
ro64((wv->ch)[4],rt,temp2);
(wv->ch)[4][0]=temp2[0];
(wv->ch)[4][1]=temp2[1];

temp2[0]=0x0;
temp2[1]=0x0;
rt64(temp2,(wv->ch)[4], (wv->ch)[5], (wv->ch)[6], (wv->ch)[7], (wv->ch)[0], (wv->ch)[1], (wv->ch)[2],temp1);
temp1[1]=temp1[0]>>4 ^temp1[1];
temp1[0]=temp1[0] & 0xf;
temp1[1]=temp1[1] ^ (temp1[1] >>18) ^ (temp1[0]<<14);
temp1[1]=temp1[1] & 0x3ffff;
temp1[1]=((temp1[1]>>12) ^ temp1[1]) & 0xfff;
temp1[1]=((temp1[1]>>6) ^ temp1[1]) & 0x3f;
rt=temp1[1];
ro64((wv->ch)[3],rt,temp2);
(wv->ch)[3][0]=temp2[0];
(wv->ch)[3][1]=temp2[1];


rt64((wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],temp1);
rt=(wv->w)[1][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[1][1]>>6 & 0x3f; 
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1];
rt=(wv->w)[1][1]>>12 & 0x3f; 
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][1]=temp1[1]+(wv->w)[4][1];
(wv->ch)[7][0]=temp1[0]+(wv->w)[4][0];
if ((wv->ch)[7][1]<(wv->w)[4][1]) (wv->ch)[7][0]+=1;
rt=(wv->w)[1][1]>>18 & 0x3f;
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];

rt=(wv->w)[1][0]>>30;
mix((wv->ch)[3],(wv->ch)[4],(wv->ch)[5],rt,temp1);
(wv->ch)[5][1]=temp1[1]+(wv->w)[3][1];
(wv->ch)[5][0]=temp1[0]+(wv->w)[3][0];
if ((wv->ch)[5][1]<(wv->w)[3][1]) (wv->ch)[5][0]+=1;

rt=(wv->w)[1][1]>>24 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];
(wv->ch)[2][1]=temp2[1]+(wv->w)[2][1];
(wv->ch)[2][0]=temp2[0]+(wv->w)[2][0];
if ((wv->ch)[2][1]<(wv->w)[2][1]) (wv->ch)[2][0]+=1; 

rt64((wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],temp1);
rt=((wv->w)[1][1]>>30) +(((wv->w)[1][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[0][1]=(wv->ch)[0][1]+(wv->w)[0][1];
(wv->ch)[0][0]=(wv->ch)[0][0]+(wv->w)[0][0];
if ((wv->ch)[0][1]<(wv->w)[0][1]) (wv->ch)[0][0]+=1;
rt=(wv->w)[1][0]>>4 & 0x3f; 
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][0]=temp1[0];
(wv->ch)[7][1]=temp1[1]; 
rt=(wv->w)[1][0]>>10 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][1]=temp1[1]+(wv->w)[7][1];
(wv->ch)[6][0]=temp1[0]+(wv->w)[7][0];
if ((wv->ch)[6][1]<(wv->w)[7][1]) (wv->ch)[6][0]+=1;
rt=(wv->w)[1][0]>>16 & 0x3f;
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][0]=temp1[0];
(wv->ch)[5][1]=temp1[1]; 

rt=(wv->w)[1][0]>>28 & 0x3;
mix((wv->ch)[2],(wv->ch)[3],(wv->ch)[4],rt,temp1);
(wv->ch)[4][1]=temp1[1]+(wv->w)[6][1];
(wv->ch)[4][0]=temp1[0]+(wv->w)[6][0];
if ((wv->ch)[4][1]<(wv->w)[6][1]) (wv->ch)[4][0]+=1;

(wv->ch)[3][1]+=(wv->w)[1][1];
(wv->ch)[3][0]+=(wv->w)[1][0];
if ((wv->ch)[3][1]<(wv->w)[1][1]) (wv->ch)[3][0]+=1; 
rt=(wv->w)[1][0]>>22 & 0x3f;
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1]; 
(wv->ch)[1][1]=temp2[1]+(wv->w)[5][1];
(wv->ch)[1][0]=temp2[0]+(wv->w)[5][0];
if ((wv->ch)[1][1]<(wv->w)[5][1]) (wv->ch)[1][0]+=1;
}


void sha64_com2(workvariable *wv)
{
xdata  uint_32t   temp1[2],rt,temp2[2];
rt64((wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],temp1);
rt=(wv->w)[9][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[9][1]>>6 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];
rt=(wv->w)[9][1]>>12 & 0x3f; 
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][1]=temp1[1]+(wv->w)[12][1];
(wv->ch)[5][0]=temp1[0]+(wv->w)[12][0];
if ((wv->ch)[5][1]<(wv->w)[12][1]) (wv->ch)[5][0]+=1;
rt=(wv->w)[9][1]>>18 & 0x3f;
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];


rt=(wv->w)[9][0]>>30;
mix((wv->ch)[1],(wv->ch)[2],(wv->ch)[3],rt,temp1);
(wv->ch)[3][1]=temp1[1]+(wv->w)[11][1];
(wv->ch)[3][0]=temp1[0]+(wv->w)[11][0];
if ((wv->ch)[3][1]<(wv->w)[11][1]) (wv->ch)[3][0]+=1; 

rt=(wv->w)[9][1]>>24 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1];
(wv->ch)[0][1]=temp2[1]+(wv->w)[10][1];
(wv->ch)[0][0]=temp2[0]+(wv->w)[10][0];
if ((wv->ch)[0][1]<(wv->w)[10][1]) (wv->ch)[0][0]+=1; 

rt64((wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],temp1);
rt=((wv->w)[9][1]>>30) +(((wv->w)[9][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[6][1]=(wv->ch)[6][1]+(wv->w)[8][1];
(wv->ch)[6][0]=(wv->ch)[6][0]+(wv->w)[8][0];
if ((wv->ch)[6][1]<(wv->w)[8][1]) (wv->ch)[6][0]+=1;
rt=(wv->w)[9][0]>>4 & 0x3f; 
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][0]=temp1[0];
(wv->ch)[5][1]=temp1[1]; 
rt=(wv->w)[9][0]>>10 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][1]=temp1[1]+(wv->w)[15][1];
(wv->ch)[4][0]=temp1[0]+(wv->w)[15][0];
if ((wv->ch)[4][1]<(wv->w)[15][1]) (wv->ch)[4][0]+=1;
rt=(wv->w)[9][0]>>16 & 0x3f;
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][0]=temp1[0];
(wv->ch)[3][1]=temp1[1]; 

rt=(wv->w)[9][0]>>28 & 0x3;
mix((wv->ch)[0],(wv->ch)[1],(wv->ch)[2],rt,temp1);
(wv->ch)[2][1]=temp1[1]+(wv->w)[14][1];
(wv->ch)[2][0]=temp1[0]+(wv->w)[14][0];
if ((wv->ch)[2][1]<(wv->w)[14][1]) (wv->ch)[2][0]+=1;

(wv->ch)[1][1]+=(wv->w)[9][1];
(wv->ch)[1][0]+=(wv->w)[9][0];
if ((wv->ch)[1][1]<(wv->w)[9][1]) (wv->ch)[1][0]+=1; 
rt=(wv->w)[9][0]>>22 & 0x3f;
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1]; 
(wv->ch)[7][1]=temp2[1]+(wv->w)[13][1];
(wv->ch)[7][0]=temp2[0]+(wv->w)[13][0];
if ((wv->ch)[7][1]<(wv->w)[13][1]) (wv->ch)[7][0]+=1;


rt64((wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],temp1);
rt=(wv->w)[2][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[2][1]>>6 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];
rt=(wv->w)[2][1]>>12 & 0x3f; 
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][1]=temp1[1]+(wv->w)[5][1];
(wv->ch)[3][0]=temp1[0]+(wv->w)[5][0];
if ((wv->ch)[3][1]<(wv->w)[5][1]) (wv->ch)[3][0]+=1;
rt=(wv->w)[2][1]>>18 & 0x3f;
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1];

rt=(wv->w)[2][0]>>30;
mix((wv->ch)[7],(wv->ch)[0],(wv->ch)[1],rt,temp1);
(wv->ch)[1][1]=temp1[1]+(wv->w)[4][1];
(wv->ch)[1][0]=temp1[0]+(wv->w)[4][0];

if ((wv->ch)[1][1]<(wv->w)[4][1]) (wv->ch)[1][0]+=1; 
rt=(wv->w)[2][1]>>24 & 0x3f; 
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1];
(wv->ch)[6][1]=temp2[1]+(wv->w)[3][1];
(wv->ch)[6][0]=temp2[0]+(wv->w)[3][0];
if ((wv->ch)[6][1]<(wv->w)[3][1]) (wv->ch)[6][0]+=1; 

rt64((wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],temp1);
rt=((wv->w)[2][1]>>30) +(((wv->w)[2][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[4][1]=(wv->ch)[4][1]+(wv->w)[1][1];
(wv->ch)[4][0]=(wv->ch)[4][0]+(wv->w)[1][0];
if ((wv->ch)[4][1]<(wv->w)[1][1]) (wv->ch)[4][0]+=1;
rt=(wv->w)[2][0]>>4 & 0x3f; 
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][0]=temp1[0];
(wv->ch)[3][1]=temp1[1]; 
rt=(wv->w)[2][0]>>10 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][1]=temp1[1]+(wv->w)[0][1];
(wv->ch)[2][0]=temp1[0]+(wv->w)[0][0];
if ((wv->ch)[2][1]<(wv->w)[0][1]) (wv->ch)[2][0]+=1;
rt=(wv->w)[2][0]>>16 & 0x3f;
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][0]=temp1[0];
(wv->ch)[1][1]=temp1[1]; 

rt=(wv->w)[2][0]>>28 & 0x3;
mix((wv->ch)[6],(wv->ch)[7],(wv->ch)[0],rt,temp1);
(wv->ch)[0][1]=temp1[1]+(wv->w)[7][1];
(wv->ch)[0][0]=temp1[0]+(wv->w)[7][0];

if ((wv->ch)[0][1]<(wv->w)[7][1]) (wv->ch)[0][0]+=1;
(wv->ch)[7][1]+=(wv->w)[2][1];
(wv->ch)[7][0]+=(wv->w)[2][0];
if ((wv->ch)[7][1]<(wv->w)[2][1]) (wv->ch)[7][0]+=1; 
rt=(wv->w)[2][0]>>22 & 0x3f;
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1]; 
(wv->ch)[5][1]=temp2[1]+(wv->w)[6][1];
(wv->ch)[5][0]=temp2[0]+(wv->w)[6][0];
if ((wv->ch)[5][1]<(wv->w)[6][1]) (wv->ch)[5][0]+=1;


rt64((wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],temp1);
rt=(wv->w)[10][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[10][1]>>6 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1];
rt=(wv->w)[10][1]>>12 & 0x3f; 
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][1]=temp1[1]+(wv->w)[13][1];
(wv->ch)[1][0]=temp1[0]+(wv->w)[13][0];
if ((wv->ch)[1][1]<(wv->w)[13][1]) (wv->ch)[1][0]+=1;
rt=(wv->w)[10][1]>>18 & 0x3f;
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1];

rt=(wv->w)[10][0]>>30;
mix((wv->ch)[5],(wv->ch)[6],(wv->ch)[7],rt,temp1);
(wv->ch)[7][1]=temp1[1]+(wv->w)[12][1];
(wv->ch)[7][0]=temp1[0]+(wv->w)[12][0];
if ((wv->ch)[7][1]<(wv->w)[12][1]) (wv->ch)[7][0]+=1; 

rt=(wv->w)[10][1]>>24 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];
(wv->ch)[4][1]=temp2[1]+(wv->w)[11][1];
(wv->ch)[4][0]=temp2[0]+(wv->w)[11][0];
if ((wv->ch)[4][1]<(wv->w)[11][1]) (wv->ch)[4][0]+=1; 

rt64((wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],temp1);
rt=((wv->w)[10][1]>>30) +(((wv->w)[10][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[2][1]=(wv->ch)[2][1]+(wv->w)[9][1];
(wv->ch)[2][0]=(wv->ch)[2][0]+(wv->w)[9][0];
if ((wv->ch)[2][1]<(wv->w)[9][1]) (wv->ch)[2][0]+=1;
rt=(wv->w)[10][0]>>4 & 0x3f; 
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][0]=temp1[0];
(wv->ch)[1][1]=temp1[1]; 
rt=(wv->w)[10][0]>>10 & 0x3f; 
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][1]=temp1[1]+(wv->w)[8][1];
(wv->ch)[0][0]=temp1[0]+(wv->w)[8][0];
if ((wv->ch)[0][1]<(wv->w)[8][1]) (wv->ch)[0][0]+=1;
rt=(wv->w)[10][0]>>16 & 0x3f;
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][0]=temp1[0];
(wv->ch)[7][1]=temp1[1]; 

rt=(wv->w)[10][0]>>28 & 0x3;
mix((wv->ch)[4],(wv->ch)[5],(wv->ch)[6],rt,temp1);
(wv->ch)[6][1]=temp1[1]+(wv->w)[15][1];
(wv->ch)[6][0]=temp1[0]+(wv->w)[15][0];
if ((wv->ch)[6][1]<(wv->w)[15][1]) (wv->ch)[6][0]+=1;

(wv->ch)[5][1]+=(wv->w)[10][1];
(wv->ch)[5][0]+=(wv->w)[10][0];
if ((wv->ch)[5][1]<(wv->w)[10][1]) (wv->ch)[5][0]+=1; 
rt=(wv->w)[10][0]>>22 & 0x3f;
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1]; 
(wv->ch)[3][1]=temp2[1]+(wv->w)[14][1];
(wv->ch)[3][0]=temp2[0]+(wv->w)[14][0];
if ((wv->ch)[3][1]<(wv->w)[14][1]) (wv->ch)[3][0]+=1;


rt64((wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],temp1);
rt=(wv->w)[3][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[3][1]>>6 & 0x3f; 
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1];
rt=(wv->w)[3][1]>>12 & 0x3f; 
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][1]=temp1[1]+(wv->w)[6][1];
(wv->ch)[7][0]=temp1[0]+(wv->w)[6][0];
if ((wv->ch)[7][1]<(wv->w)[6][1]) (wv->ch)[7][0]+=1;
rt=(wv->w)[3][1]>>18 & 0x3f;
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];

rt=(wv->w)[3][0]>>30;
mix((wv->ch)[3],(wv->ch)[4],(wv->ch)[5],rt,temp1);
(wv->ch)[5][1]=temp1[1]+(wv->w)[5][1];
(wv->ch)[5][0]=temp1[0]+(wv->w)[5][0];
if ((wv->ch)[5][1]<(wv->w)[5][1]) (wv->ch)[5][0]+=1; 


rt=(wv->w)[3][1]>>24 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];
(wv->ch)[2][1]=temp2[1]+(wv->w)[4][1];
(wv->ch)[2][0]=temp2[0]+(wv->w)[4][0];
if ((wv->ch)[2][1]<(wv->w)[4][1]) (wv->ch)[2][0]+=1; 

rt64((wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],temp1);
rt=((wv->w)[3][1]>>30) +(((wv->w)[3][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[0][1]=(wv->ch)[0][1]+(wv->w)[2][1];
(wv->ch)[0][0]=(wv->ch)[0][0]+(wv->w)[2][0];
if ((wv->ch)[0][1]<(wv->w)[2][1]) (wv->ch)[0][0]+=1;
rt=(wv->w)[3][0]>>4 & 0x3f; 
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][0]=temp1[0];
(wv->ch)[7][1]=temp1[1]; 
rt=(wv->w)[3][0]>>10 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][1]=temp1[1]+(wv->w)[1][1];
(wv->ch)[6][0]=temp1[0]+(wv->w)[1][0];
if ((wv->ch)[6][1]<(wv->w)[1][1]) (wv->ch)[6][0]+=1;
rt=(wv->w)[3][0]>>16 & 0x3f;
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][0]=temp1[0];
(wv->ch)[5][1]=temp1[1];

rt=(wv->w)[3][0]>>28 & 0x3;
mix((wv->ch)[2],(wv->ch)[3],(wv->ch)[4],rt,temp1);
(wv->ch)[4][1]=temp1[1]+(wv->w)[0][1];
(wv->ch)[4][0]=temp1[0]+(wv->w)[0][0];
if ((wv->ch)[4][1]<(wv->w)[0][1]) (wv->ch)[4][0]+=1;

(wv->ch)[3][1]+=(wv->w)[3][1];
(wv->ch)[3][0]+=(wv->w)[3][0];
if ((wv->ch)[3][1]<(wv->w)[3][1]) (wv->ch)[3][0]+=1; 
rt=(wv->w)[3][0]>>22 & 0x3f;
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1]; 
(wv->ch)[1][1]=temp2[1]+(wv->w)[7][1];
(wv->ch)[1][0]=temp2[0]+(wv->w)[7][0];
if ((wv->ch)[1][1]<(wv->w)[7][1]) (wv->ch)[1][0]+=1;


rt64((wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],temp1);
rt=(wv->w)[11][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[11][1]>>6 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];
rt=(wv->w)[11][1]>>12 & 0x3f; 
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][1]=temp1[1]+(wv->w)[14][1];
(wv->ch)[5][0]=temp1[0]+(wv->w)[14][0];
if ((wv->ch)[5][1]<(wv->w)[14][1]) (wv->ch)[5][0]+=1;
rt=(wv->w)[11][1]>>18 & 0x3f;
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];

rt=(wv->w)[11][0]>>30;
mix((wv->ch)[1],(wv->ch)[2],(wv->ch)[3],rt,temp1);
(wv->ch)[3][1]=temp1[1]+(wv->w)[13][1];
(wv->ch)[3][0]=temp1[0]+(wv->w)[13][0];

if ((wv->ch)[3][1]<(wv->w)[13][1]) (wv->ch)[3][0]+=1; 

rt=(wv->w)[11][1]>>24 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1];
(wv->ch)[0][1]=temp2[1]+(wv->w)[12][1];
(wv->ch)[0][0]=temp2[0]+(wv->w)[12][0];
if ((wv->ch)[0][1]<(wv->w)[12][1]) (wv->ch)[0][0]+=1; 

rt64((wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],temp1);
rt=((wv->w)[11][1]>>30) +(((wv->w)[11][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[6][1]=(wv->ch)[6][1]+(wv->w)[10][1];
(wv->ch)[6][0]=(wv->ch)[6][0]+(wv->w)[10][0];
if ((wv->ch)[6][1]<(wv->w)[10][1]) (wv->ch)[6][0]+=1;
rt=(wv->w)[11][0]>>4 & 0x3f; 
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][0]=temp1[0];
(wv->ch)[5][1]=temp1[1]; 
rt=(wv->w)[11][0]>>10 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][1]=temp1[1]+(wv->w)[9][1];
(wv->ch)[4][0]=temp1[0]+(wv->w)[9][0];
if ((wv->ch)[4][1]<(wv->w)[9][1]) (wv->ch)[4][0]+=1;
rt=(wv->w)[11][0]>>16 & 0x3f;
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][0]=temp1[0];
(wv->ch)[3][1]=temp1[1];

rt=(wv->w)[11][0]>>28 & 0x3;
mix((wv->ch)[0],(wv->ch)[1],(wv->ch)[2],rt,temp1);
(wv->ch)[2][1]=temp1[1]+(wv->w)[8][1];
(wv->ch)[2][0]=temp1[0]+(wv->w)[8][0];
if ((wv->ch)[2][1]<(wv->w)[8][1]) (wv->ch)[2][0]+=1;

(wv->ch)[1][1]+=(wv->w)[11][1];
(wv->ch)[1][0]+=(wv->w)[11][0];
if ((wv->ch)[1][1]<(wv->w)[11][1]) (wv->ch)[1][0]+=1; 
rt=(wv->w)[11][0]>>22 & 0x3f;
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1]; 
(wv->ch)[7][1]=temp2[1]+(wv->w)[15][1];
(wv->ch)[7][0]=temp2[0]+(wv->w)[15][0];
if ((wv->ch)[7][1]<(wv->w)[15][1]) (wv->ch)[7][0]+=1;


rt64((wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],temp1);
rt=(wv->w)[4][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[4][1]>>6 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];
rt=(wv->w)[4][1]>>12 & 0x3f; 
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][1]=temp1[1]+(wv->w)[7][1];
(wv->ch)[3][0]=temp1[0]+(wv->w)[7][0];
if ((wv->ch)[3][1]<(wv->w)[7][1]) (wv->ch)[3][0]+=1;
rt=(wv->w)[4][1]>>18 & 0x3f;
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1];

rt=(wv->w)[4][0]>>30;
mix((wv->ch)[7],(wv->ch)[0],(wv->ch)[1],rt,temp1);
(wv->ch)[1][1]=temp1[1]+(wv->w)[6][1];
(wv->ch)[1][0]=temp1[0]+(wv->w)[6][0];

if ((wv->ch)[1][1]<(wv->w)[6][1]) (wv->ch)[1][0]+=1; 

rt=(wv->w)[4][1]>>24 & 0x3f; 
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1];
(wv->ch)[6][1]=temp2[1]+(wv->w)[5][1];
(wv->ch)[6][0]=temp2[0]+(wv->w)[5][0];
if ((wv->ch)[6][1]<(wv->w)[5][1]) (wv->ch)[6][0]+=1; 
}

void sha64_com3(workvariable *wv)
{
xdata  uint_32t   temp1[2],rt,temp2[2];
rt64((wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],temp1);
rt=((wv->w)[4][1]>>30) +(((wv->w)[4][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[4][1]=(wv->ch)[4][1]+(wv->w)[3][1];
(wv->ch)[4][0]=(wv->ch)[4][0]+(wv->w)[3][0];
if ((wv->ch)[4][1]<(wv->w)[3][1]) (wv->ch)[4][0]+=1;
rt=(wv->w)[4][0]>>4 & 0x3f; 
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][0]=temp1[0];
(wv->ch)[3][1]=temp1[1]; 
rt=(wv->w)[4][0]>>10 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][1]=temp1[1]+(wv->w)[2][1];
(wv->ch)[2][0]=temp1[0]+(wv->w)[2][0];
if ((wv->ch)[2][1]<(wv->w)[2][1]) (wv->ch)[2][0]+=1;
rt=(wv->w)[4][0]>>16 & 0x3f;
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][0]=temp1[0];
(wv->ch)[1][1]=temp1[1]; 

rt=(wv->w)[4][0]>>28 & 0x3;
mix((wv->ch)[6],(wv->ch)[7],(wv->ch)[0],rt,temp1);
(wv->ch)[0][1]=temp1[1]+(wv->w)[1][1];
(wv->ch)[0][0]=temp1[0]+(wv->w)[1][0];

if ((wv->ch)[0][1]<(wv->w)[1][1]) (wv->ch)[0][0]+=1;
(wv->ch)[7][1]+=(wv->w)[4][1];
(wv->ch)[7][0]+=(wv->w)[4][0];
if ((wv->ch)[7][1]<(wv->w)[4][1]) (wv->ch)[7][0]+=1; 
rt=(wv->w)[4][0]>>22 & 0x3f;
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1]; 
(wv->ch)[5][1]=temp2[1]+(wv->w)[0][1];
(wv->ch)[5][0]=temp2[0]+(wv->w)[0][0];
if ((wv->ch)[5][1]<(wv->w)[0][1]) (wv->ch)[5][0]+=1;


rt64((wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],temp1);
rt=(wv->w)[12][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[12][1]>>6 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1];
rt=(wv->w)[12][1]>>12 & 0x3f; 
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][1]=temp1[1]+(wv->w)[15][1];
(wv->ch)[1][0]=temp1[0]+(wv->w)[15][0];
if ((wv->ch)[1][1]<(wv->w)[15][1]) (wv->ch)[1][0]+=1;
rt=(wv->w)[12][1]>>18 & 0x3f;
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1];

rt=(wv->w)[12][0]>>30;
mix((wv->ch)[5],(wv->ch)[6],(wv->ch)[7],rt,temp1);
(wv->ch)[7][1]=temp1[1]+(wv->w)[14][1];
(wv->ch)[7][0]=temp1[0]+(wv->w)[14][0];
if ((wv->ch)[7][1]<(wv->w)[14][1]) (wv->ch)[7][0]+=1; 


rt=(wv->w)[12][1]>>24 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];
(wv->ch)[4][1]=temp2[1]+(wv->w)[13][1];
(wv->ch)[4][0]=temp2[0]+(wv->w)[13][0];
if ((wv->ch)[4][1]<(wv->w)[13][1]) (wv->ch)[4][0]+=1; 

rt64((wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],temp1);
rt=((wv->w)[12][1]>>30) +(((wv->w)[12][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[2][1]=(wv->ch)[2][1]+(wv->w)[11][1];
(wv->ch)[2][0]=(wv->ch)[2][0]+(wv->w)[11][0];
if ((wv->ch)[2][1]<(wv->w)[11][1]) (wv->ch)[2][0]+=1;
rt=(wv->w)[12][0]>>4 & 0x3f; 
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][0]=temp1[0];
(wv->ch)[1][1]=temp1[1]; 
rt=(wv->w)[12][0]>>10 & 0x3f; 
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][1]=temp1[1]+(wv->w)[10][1];
(wv->ch)[0][0]=temp1[0]+(wv->w)[10][0];
if ((wv->ch)[0][1]<(wv->w)[10][1]) (wv->ch)[0][0]+=1;
rt=(wv->w)[12][0]>>16 & 0x3f;
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][0]=temp1[0];
(wv->ch)[7][1]=temp1[1]; 

rt=(wv->w)[12][0]>>28 & 0x3;
mix((wv->ch)[4],(wv->ch)[5],(wv->ch)[6],rt,temp1);
(wv->ch)[6][1]=temp1[1]+(wv->w)[9][1];
(wv->ch)[6][0]=temp1[0]+(wv->w)[9][0];
if ((wv->ch)[6][1]<(wv->w)[9][1]) (wv->ch)[6][0]+=1;

(wv->ch)[5][1]+=(wv->w)[12][1];
(wv->ch)[5][0]+=(wv->w)[12][0];
if ((wv->ch)[5][1]<(wv->w)[12][1]) (wv->ch)[5][0]+=1; 
rt=(wv->w)[12][0]>>22 & 0x3f;
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1]; 
(wv->ch)[3][1]=temp2[1]+(wv->w)[8][1];
(wv->ch)[3][0]=temp2[0]+(wv->w)[8][0];
if ((wv->ch)[3][1]<(wv->w)[8][1]) (wv->ch)[3][0]+=1;


rt64((wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],temp1);
rt=(wv->w)[5][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[5][1]>>6 & 0x3f; 
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1];
rt=(wv->w)[5][1]>>12 & 0x3f; 
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][1]=temp1[1]+(wv->w)[0][1];
(wv->ch)[7][0]=temp1[0]+(wv->w)[0][0];
if ((wv->ch)[7][1]<(wv->w)[0][1]) (wv->ch)[7][0]+=1;
rt=(wv->w)[5][1]>>18 & 0x3f;
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];

rt=(wv->w)[5][0]>>30;
mix((wv->ch)[3],(wv->ch)[4],(wv->ch)[5],rt,temp1);
(wv->ch)[5][1]=temp1[1]+(wv->w)[7][1];
(wv->ch)[5][0]=temp1[0]+(wv->w)[7][0];
if ((wv->ch)[5][1]<(wv->w)[7][1]) (wv->ch)[5][0]+=1; 

rt=(wv->w)[5][1]>>24 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];
(wv->ch)[2][1]=temp2[1]+(wv->w)[6][1];
(wv->ch)[2][0]=temp2[0]+(wv->w)[6][0];
if ((wv->ch)[2][1]<(wv->w)[6][1]) (wv->ch)[2][0]+=1; 

rt64((wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],temp1);
rt=((wv->w)[5][1]>>30) +(((wv->w)[5][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[0][1]=(wv->ch)[0][1]+(wv->w)[4][1];
(wv->ch)[0][0]=(wv->ch)[0][0]+(wv->w)[4][0];
if ((wv->ch)[0][1]<(wv->w)[4][1]) (wv->ch)[0][0]+=1;
rt=(wv->w)[5][0]>>4 & 0x3f; 
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][0]=temp1[0];
(wv->ch)[7][1]=temp1[1]; 
rt=(wv->w)[5][0]>>10 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][1]=temp1[1]+(wv->w)[3][1];
(wv->ch)[6][0]=temp1[0]+(wv->w)[3][0];
if ((wv->ch)[6][1]<(wv->w)[3][1]) (wv->ch)[6][0]+=1;
rt=(wv->w)[5][0]>>16 & 0x3f;
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][0]=temp1[0];
(wv->ch)[5][1]=temp1[1];

rt=(wv->w)[5][0]>>28 & 0x3;
mix((wv->ch)[2],(wv->ch)[3],(wv->ch)[4],rt,temp1);
(wv->ch)[4][1]=temp1[1]+(wv->w)[2][1];
(wv->ch)[4][0]=temp1[0]+(wv->w)[2][0];
if ((wv->ch)[4][1]<(wv->w)[2][1]) (wv->ch)[4][0]+=1;


(wv->ch)[3][1]+=(wv->w)[5][1];
(wv->ch)[3][0]+=(wv->w)[5][0];
if ((wv->ch)[3][1]<(wv->w)[5][1]) (wv->ch)[3][0]+=1; 
rt=(wv->w)[5][0]>>22 & 0x3f;
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1]; 
(wv->ch)[1][1]=temp2[1]+(wv->w)[1][1];
(wv->ch)[1][0]=temp2[0]+(wv->w)[1][0];
if ((wv->ch)[1][1]<(wv->w)[1][1]) (wv->ch)[1][0]+=1;


rt64((wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],temp1);
rt=(wv->w)[13][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[13][1]>>6 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];
rt=(wv->w)[13][1]>>12 & 0x3f; 
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][1]=temp1[1]+(wv->w)[8][1];
(wv->ch)[5][0]=temp1[0]+(wv->w)[8][0];
if ((wv->ch)[5][1]<(wv->w)[8][1]) (wv->ch)[5][0]+=1;
rt=(wv->w)[13][1]>>18 & 0x3f;
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];

rt=(wv->w)[13][0]>>30;
mix((wv->ch)[1],(wv->ch)[2],(wv->ch)[3],rt,temp1);
(wv->ch)[3][1]=temp1[1]+(wv->w)[15][1];
(wv->ch)[3][0]=temp1[0]+(wv->w)[15][0];
if ((wv->ch)[3][1]<(wv->w)[15][1]) (wv->ch)[3][0]+=1; 

rt=(wv->w)[13][1]>>24 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1];
(wv->ch)[0][1]=temp2[1]+(wv->w)[14][1];
(wv->ch)[0][0]=temp2[0]+(wv->w)[14][0];
if ((wv->ch)[0][1]<(wv->w)[14][1]) (wv->ch)[0][0]+=1; 

rt64((wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],temp1);
rt=((wv->w)[13][1]>>30) +(((wv->w)[13][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[6][1]=(wv->ch)[6][1]+(wv->w)[12][1];
(wv->ch)[6][0]=(wv->ch)[6][0]+(wv->w)[12][0];
if ((wv->ch)[6][1]<(wv->w)[12][1]) (wv->ch)[6][0]+=1;
rt=(wv->w)[13][0]>>4 & 0x3f; 
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][0]=temp1[0];
(wv->ch)[5][1]=temp1[1]; 
rt=(wv->w)[13][0]>>10 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][1]=temp1[1]+(wv->w)[11][1];
(wv->ch)[4][0]=temp1[0]+(wv->w)[11][0];
if ((wv->ch)[4][1]<(wv->w)[11][1]) (wv->ch)[4][0]+=1;
rt=(wv->w)[13][0]>>16 & 0x3f;
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][0]=temp1[0];
(wv->ch)[3][1]=temp1[1];

rt=(wv->w)[13][0]>>28 & 0x3;
mix((wv->ch)[0],(wv->ch)[1],(wv->ch)[2],rt,temp1);
(wv->ch)[2][1]=temp1[1]+(wv->w)[10][1];
(wv->ch)[2][0]=temp1[0]+(wv->w)[10][0];
if ((wv->ch)[2][1]<(wv->w)[10][1]) (wv->ch)[2][0]+=1;


(wv->ch)[1][1]+=(wv->w)[13][1];
(wv->ch)[1][0]+=(wv->w)[13][0];
if ((wv->ch)[1][1]<(wv->w)[13][1]) (wv->ch)[1][0]+=1; 
rt=(wv->w)[13][0]>>22 & 0x3f;
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1]; 
(wv->ch)[7][1]=temp2[1]+(wv->w)[9][1];
(wv->ch)[7][0]=temp2[0]+(wv->w)[9][0];
if ((wv->ch)[7][1]<(wv->w)[9][1]) (wv->ch)[7][0]+=1;


rt64((wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],temp1);
rt=(wv->w)[6][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[6][1]>>6 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];
rt=(wv->w)[6][1]>>12 & 0x3f; 
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][1]=temp1[1]+(wv->w)[1][1];
(wv->ch)[3][0]=temp1[0]+(wv->w)[1][0];
if ((wv->ch)[3][1]<(wv->w)[1][1]) (wv->ch)[3][0]+=1;
rt=(wv->w)[6][1]>>18 & 0x3f;
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1];

rt=(wv->w)[6][0]>>30;
mix((wv->ch)[7],(wv->ch)[0],(wv->ch)[1],rt,temp1);
(wv->ch)[1][1]=temp1[1]+(wv->w)[0][1];
(wv->ch)[1][0]=temp1[0]+(wv->w)[0][0];
if ((wv->ch)[1][1]<(wv->w)[0][1]) (wv->ch)[1][0]+=1; 


rt=(wv->w)[6][1]>>24 & 0x3f; 
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1];
(wv->ch)[6][1]=temp2[1]+(wv->w)[7][1];
(wv->ch)[6][0]=temp2[0]+(wv->w)[7][0];
if ((wv->ch)[6][1]<(wv->w)[7][1]) (wv->ch)[6][0]+=1; 

rt64((wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],temp1);
rt=((wv->w)[6][1]>>30) +(((wv->w)[6][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[4][1]=(wv->ch)[4][1]+(wv->w)[5][1];
(wv->ch)[4][0]=(wv->ch)[4][0]+(wv->w)[5][0];
if ((wv->ch)[4][1]<(wv->w)[5][1]) (wv->ch)[4][0]+=1;
rt=(wv->w)[6][0]>>4 & 0x3f; 
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][0]=temp1[0];
(wv->ch)[3][1]=temp1[1]; 
rt=(wv->w)[6][0]>>10 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][1]=temp1[1]+(wv->w)[4][1];
(wv->ch)[2][0]=temp1[0]+(wv->w)[4][0];
if ((wv->ch)[2][1]<(wv->w)[4][1]) (wv->ch)[2][0]+=1;
rt=(wv->w)[6][0]>>16 & 0x3f;
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][0]=temp1[0];
(wv->ch)[1][1]=temp1[1];

rt=(wv->w)[6][0]>>28 & 0x3;
mix((wv->ch)[6],(wv->ch)[7],(wv->ch)[0],rt,temp1);
(wv->ch)[0][1]=temp1[1]+(wv->w)[3][1];
(wv->ch)[0][0]=temp1[0]+(wv->w)[3][0];
if ((wv->ch)[0][1]<(wv->w)[3][1]) (wv->ch)[0][0]+=1;


(wv->ch)[7][1]+=(wv->w)[6][1];
(wv->ch)[7][0]+=(wv->w)[6][0];
if ((wv->ch)[7][1]<(wv->w)[6][1]) (wv->ch)[7][0]+=1; 
rt=(wv->w)[6][0]>>22 & 0x3f;
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1]; 
(wv->ch)[5][1]=temp2[1]+(wv->w)[2][1];
(wv->ch)[5][0]=temp2[0]+(wv->w)[2][0];
if ((wv->ch)[5][1]<(wv->w)[2][1]) (wv->ch)[5][0]+=1;


rt64((wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],temp1);
rt=(wv->w)[14][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[14][1]>>6 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1];
rt=(wv->w)[14][1]>>12 & 0x3f; 
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][1]=temp1[1]+(wv->w)[9][1];
(wv->ch)[1][0]=temp1[0]+(wv->w)[9][0];
if ((wv->ch)[1][1]<(wv->w)[9][1]) (wv->ch)[1][0]+=1;
rt=(wv->w)[14][1]>>18 & 0x3f;
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1];

rt=(wv->w)[14][0]>>30;
mix((wv->ch)[5],(wv->ch)[6],(wv->ch)[7],rt,temp1);
(wv->ch)[7][1]=temp1[1]+(wv->w)[8][1];
(wv->ch)[7][0]=temp1[0]+(wv->w)[8][0];
if ((wv->ch)[7][1]<(wv->w)[8][1]) (wv->ch)[7][0]+=1; 

rt=(wv->w)[14][1]>>24 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];
(wv->ch)[4][1]=temp2[1]+(wv->w)[15][1];
(wv->ch)[4][0]=temp2[0]+(wv->w)[15][0];
if ((wv->ch)[4][1]<(wv->w)[15][1]) (wv->ch)[4][0]+=1; 

rt64((wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],temp1);
rt=((wv->w)[14][1]>>30) +(((wv->w)[14][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[2][1]=(wv->ch)[2][1]+(wv->w)[13][1];
(wv->ch)[2][0]=(wv->ch)[2][0]+(wv->w)[13][0];
if ((wv->ch)[2][1]<(wv->w)[13][1]) (wv->ch)[2][0]+=1;
rt=(wv->w)[14][0]>>4 & 0x3f; 
ro64((wv->ch)[1],rt,temp1);
(wv->ch)[1][0]=temp1[0];
(wv->ch)[1][1]=temp1[1]; 
rt=(wv->w)[14][0]>>10 & 0x3f; 
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][1]=temp1[1]+(wv->w)[12][1];
(wv->ch)[0][0]=temp1[0]+(wv->w)[12][0];
if ((wv->ch)[0][1]<(wv->w)[12][1]) (wv->ch)[0][0]+=1;
rt=(wv->w)[14][0]>>16 & 0x3f;
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][0]=temp1[0];
(wv->ch)[7][1]=temp1[1];

rt=(wv->w)[14][0]>>28 & 0x3;
mix((wv->ch)[4],(wv->ch)[5],(wv->ch)[6],rt,temp1);
(wv->ch)[6][1]=temp1[1]+(wv->w)[11][1];
(wv->ch)[6][0]=temp1[0]+(wv->w)[11][0];
if ((wv->ch)[6][1]<(wv->w)[11][1]) (wv->ch)[6][0]+=1;

(wv->ch)[5][1]+=(wv->w)[14][1];
(wv->ch)[5][0]+=(wv->w)[14][0];
if ((wv->ch)[5][1]<(wv->w)[14][1]) (wv->ch)[5][0]+=1; 
rt=(wv->w)[14][0]>>22 & 0x3f;
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1]; 
(wv->ch)[3][1]=temp2[1]+(wv->w)[10][1];
(wv->ch)[3][0]=temp2[0]+(wv->w)[10][0];
if ((wv->ch)[3][1]<(wv->w)[10][1]) (wv->ch)[3][0]+=1;

}


HashReturn sha64_com4(workvariable *wv, hashState *state)
{
 xdata int i;
xdata  uint_32t hash_64[8][2], temp2[2],temp1[2],rt;
rt64((wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],(wv->ch)[2],temp1);
rt=(wv->w)[7][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[7][1]>>6 & 0x3f; 
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1];
rt=(wv->w)[7][1]>>12 & 0x3f; 
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][1]=temp1[1]+(wv->w)[2][1];
(wv->ch)[7][0]=temp1[0]+(wv->w)[2][0];
if ((wv->ch)[7][1]<(wv->w)[2][1]) (wv->ch)[7][0]+=1;
rt=(wv->w)[7][1]>>18 & 0x3f;
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];

rt=(wv->w)[7][0]>>30;
mix((wv->ch)[3],(wv->ch)[4],(wv->ch)[5],rt,temp1);
(wv->ch)[5][1]=temp1[1]+(wv->w)[1][1];
(wv->ch)[5][0]=temp1[0]+(wv->w)[1][0];
if ((wv->ch)[5][1]<(wv->w)[1][1]) (wv->ch)[5][0]+=1; 

rt=(wv->w)[7][1]>>24 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];
(wv->ch)[2][1]=temp2[1]+(wv->w)[0][1];
(wv->ch)[2][0]=temp2[0]+(wv->w)[0][0];
if ((wv->ch)[2][1]<(wv->w)[0][1]) (wv->ch)[2][0]+=1; 

rt64((wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],(wv->ch)[1],temp1);
rt=((wv->w)[7][1]>>30) +(((wv->w)[7][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[0][1]=(wv->ch)[0][1]+(wv->w)[6][1];
(wv->ch)[0][0]=(wv->ch)[0][0]+(wv->w)[6][0];
if ((wv->ch)[0][1]<(wv->w)[6][1]) (wv->ch)[0][0]+=1;
rt=(wv->w)[7][0]>>4 & 0x3f; 
ro64((wv->ch)[7],rt,temp1);
(wv->ch)[7][0]=temp1[0];
(wv->ch)[7][1]=temp1[1]; 
rt=(wv->w)[7][0]>>10 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][1]=temp1[1]+(wv->w)[5][1];
(wv->ch)[6][0]=temp1[0]+(wv->w)[5][0];
if ((wv->ch)[6][1]<(wv->w)[5][1]) (wv->ch)[6][0]+=1;
rt=(wv->w)[7][0]>>16 & 0x3f;
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][0]=temp1[0];
(wv->ch)[5][1]=temp1[1];

rt=(wv->w)[7][0]>>28 & 0x3;
mix((wv->ch)[2],(wv->ch)[3],(wv->ch)[4],rt,temp1);
(wv->ch)[4][1]=temp1[1]+(wv->w)[4][1];
(wv->ch)[4][0]=temp1[0]+(wv->w)[4][0];
if ((wv->ch)[4][1]<(wv->w)[4][1]) (wv->ch)[4][0]+=1;

(wv->ch)[3][1]+=(wv->w)[7][1];
(wv->ch)[3][0]+=(wv->w)[7][0];
if ((wv->ch)[3][1]<(wv->w)[7][1]) (wv->ch)[3][0]+=1; 
rt=(wv->w)[7][0]>>22 & 0x3f;
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1]; 
(wv->ch)[1][1]=temp2[1]+(wv->w)[3][1];
(wv->ch)[1][0]=temp2[0]+(wv->w)[3][0];
if ((wv->ch)[1][1]<(wv->w)[3][1]) (wv->ch)[1][0]+=1;


rt64((wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],(wv->ch)[0],temp1);
rt=(wv->w)[15][1] & 0x3f;
ro64(temp1,rt,temp2);
rt=(wv->w)[15][1]>>6 & 0x3f; 
ro64((wv->ch)[6],rt,temp1);
(wv->ch)[6][0]=temp1[0];
(wv->ch)[6][1]=temp1[1];
rt=(wv->w)[15][1]>>12 & 0x3f; 
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][1]=temp1[1]+(wv->w)[10][1];
(wv->ch)[5][0]=temp1[0]+(wv->w)[10][0];
if ((wv->ch)[5][1]<(wv->w)[10][1]) (wv->ch)[5][0]+=1;
rt=(wv->w)[15][1]>>18 & 0x3f;
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][0]=temp1[0];
(wv->ch)[4][1]=temp1[1];

rt=(wv->w)[15][0]>>30;
mix((wv->ch)[1],(wv->ch)[2],(wv->ch)[3],rt,temp1);
(wv->ch)[3][1]=temp1[1]+(wv->w)[9][1];
(wv->ch)[3][0]=temp1[0]+(wv->w)[9][0];
if ((wv->ch)[3][1]<(wv->w)[9][1]) (wv->ch)[3][0]+=1; 


rt=(wv->w)[15][1]>>24 & 0x3f; 
ro64((wv->ch)[2],rt,temp1);
(wv->ch)[2][0]=temp1[0];
(wv->ch)[2][1]=temp1[1];
(wv->ch)[0][1]=temp2[1]+(wv->w)[8][1];
(wv->ch)[0][0]=temp2[0]+(wv->w)[8][0];
if ((wv->ch)[0][1]<(wv->w)[8][1]) (wv->ch)[0][0]+=1; 



rt64((wv->ch)[0],(wv->ch)[1],(wv->ch)[2],(wv->ch)[3],(wv->ch)[4],(wv->ch)[5],(wv->ch)[6],(wv->ch)[7],temp1);
rt=((wv->w)[15][1]>>30) +(((wv->w)[15][0]<<2) & 0x3f); 
ro64(temp1,rt,temp2);
(wv->ch)[6][1]=(wv->ch)[6][1]+(wv->w)[14][1];
(wv->ch)[6][0]=(wv->ch)[6][0]+(wv->w)[14][0];
if ((wv->ch)[6][1]<(wv->w)[14][1]) (wv->ch)[6][0]+=1;
rt=(wv->w)[15][0]>>4 & 0x3f; 
ro64((wv->ch)[5],rt,temp1);
(wv->ch)[5][0]=temp1[0];
(wv->ch)[5][1]=temp1[1]; 
rt=(wv->w)[15][0]>>10 & 0x3f; 
ro64((wv->ch)[4],rt,temp1);
(wv->ch)[4][1]=temp1[1]+(wv->w)[13][1];
(wv->ch)[4][0]=temp1[0]+(wv->w)[13][0];
if ((wv->ch)[4][1]<(wv->w)[13][1]) (wv->ch)[4][0]+=1;
rt=(wv->w)[15][0]>>16 & 0x3f;
ro64((wv->ch)[3],rt,temp1);
(wv->ch)[3][0]=temp1[0];
(wv->ch)[3][1]=temp1[1]; 

rt=(wv->w)[15][0]>>28 & 0x3;
mix((wv->ch)[0],(wv->ch)[1],(wv->ch)[2],rt,temp1);
(wv->ch)[2][1]=temp1[1]+(wv->w)[12][1];
(wv->ch)[2][0]=temp1[0]+(wv->w)[12][0];
if ((wv->ch)[2][1]<(wv->w)[12][1]) (wv->ch)[2][0]+=1;

(wv->ch)[1][1]+=(wv->w)[15][1];
(wv->ch)[1][0]+=(wv->w)[15][0];
if ((wv->ch)[1][1]<(wv->w)[15][1]) (wv->ch)[1][0]+=1; 
rt=(wv->w)[15][0]>>22 & 0x3f;
ro64((wv->ch)[0],rt,temp1);
(wv->ch)[0][0]=temp1[0];
(wv->ch)[0][1]=temp1[1]; 
(wv->ch)[7][1]=temp2[1]+(wv->w)[11][1];
(wv->ch)[7][0]=temp2[0]+(wv->w)[11][0];
if ((wv->ch)[7][1]<(wv->w)[11][1]) (wv->ch)[7][0]+=1;

temp1[1]=(wv->ch)[7][1];
temp1[0]=(wv->ch)[7][0];
for (i=7; i>0; i--) { 
	(wv->ch)[i][1]=(wv->ch)[i-1][1];
	(wv->ch)[i][0]=(wv->ch)[i-1][0];
}
(wv->ch)[0][1]=temp1[1];
(wv->ch)[0][0]=temp1[0];
// turn back

for (i=0;i<8;i++)
{			
		hash_64[i][0]=(state->hashval)[i*2];
		hash_64[i][1]=(state->hashval)[i*2+1];
}


// Compute intermediate hash value 
for (i=0;i<8;i++){
    hash_64[i][1] +=(wv->ch)[i][1];
	hash_64[i][0] +=(wv->ch)[i][0];
	if (hash_64[i][1] <(wv->ch)[i][1]) hash_64[i][0] +=1;

	(state->hashval)[2*i]=hash_64[i][0] ;
	(state->hashval)[2*i+1]=hash_64[i][1];
}
return SUCCESS;
}

HashReturn sha64_compile(hashState *state)
{
xdata  int i,i1;
 xdata workvariable wv;
 xdata uint_32t rt;
for (i=0;i<16;i++)
{
	for (i1=0;i1<2;i1++) {
		rt=(state->block)[8*i+4*i1];
		rt=rt<<8 | ((state->block)[8*i+4*i1+1]);
		rt=rt<<8 | ((state->block)[8*i+4*i1+2]);
		rt=rt<<8 | ((state->block)[8*i+4*i1+3]);
		wv.w[i][i1]=rt;
	}	
}

//Initialize eight working variables 
for (i=0;i<8;i++)
{	
		wv.ch[i][0]=(state->hashval)[i*2];
		wv.ch[i][1]=(state->hashval)[i*2+1];		
}
sha64_com1(&wv);
sha64_com2(&wv);
sha64_com3(&wv);
if (sha64_com4(&wv,state) != SUCCESS ) {return FAIL;}
return SUCCESS;

}

HashReturn Final(hashState *state, BitSequence *hashval)
{
xdata HashReturn HReturn;
 xdata  BitSequence   hv[64],temp ;
 xdata  DataLength dl;
 xdata  int t,t1, i;

t1=((state->databitlen[3]) % (state->blocksize))/8;
t=7-(state->databitlen[3] % 8);
temp=((state->block)[t1] >> t) | 0x1;
(state->block)[t1]=temp << t; 

if ((state->databitlen[3] % (state->blocksize))>(state->blocksize-129))
{             
	 HReturn=sha64_compile(state); 	
    if (HReturn != SUCCESS) { return HReturn;}

    //  second block
    for ( i=0; i<128; i++ )  
        (state->block)[i]=0x0;
}

t=state->blocksize/8;

dl=state->databitlen[3];
for (i=1;i<5;i++){
	(state->block)[t-i]=dl & 0xff;	
	dl=(dl >> 8);
}
dl=state->databitlen[2];
for (i=5;i<9;i++){
	(state->block)[t-i]=dl & 0xff;	
	dl=(dl >> 8);
}

dl=state->databitlen[1];
for (i=9;i<13;i++){
	(state->block)[t-i]=dl & 0xff;	
	dl=(dl >> 8);
}
dl=state->databitlen[0];
for (i=13;i<17;i++){
	(state->block)[t-i]=dl & 0xff;	
	dl=(dl >> 8);
}

HReturn=sha64_compile(state);  

for(i=0;i<16;i++) {
		hv[4*i]=((state->hashval)[i] >> 24) & 0xff ;
		hv[4*i+1]=((state->hashval)[i] >> 16) & 0xff ;
		hv[4*i+2]=((state->hashval)[i] >> 8) & 0xff ;
		hv[4*i+3]=(state->hashval)[i] & 0xff ;			
}
t=state->blocksize/16;
for(i=0;i<t;i++) hashval[i]=hv[i];
return HReturn;
} 

HashReturn Update(hashState *state, const BitSequence *hdata, DataLength databitlen)
{
xdata   HashReturn HReturn;
xdata   BitSequence  tempc;
 xdata  unsigned int oldbitlen;
 xdata  int  i,sbyte, mbits;

oldbitlen=state->databitlen[3] % state->blocksize;
state->databitlen[3]+=databitlen;
if (state->databitlen[3]<databitlen) {
	state->databitlen[2]+=1;
	if (state->databitlen[2]<1) {
		state->databitlen[1]+=1;
		if (state->databitlen[1]<1) state->databitlen[0]+=1;	
	}
}

sbyte=oldbitlen >> 3;
mbits=oldbitlen & 0x7;
(state->block)[state->blocksize / 8] = 0x0;

for (i=0;i<(databitlen+7)/8;i++)
{
	tempc=hdata[i];
	(state->block)[sbyte]=(state->block)[sbyte] | (tempc >> mbits);
	(state->block)[sbyte+1]=tempc << (8-mbits);
	sbyte+=1;	
	if (sbyte==( state->blocksize/8))
	{
		HReturn=sha64_compile(state);  		
		if (HReturn != SUCCESS) { 	return HReturn;}		
		sbyte=0;
		(state->block)[0]=(state->block)[state->blocksize / 8] ;
	}
}
return SUCCESS;
}
HashReturn Init(hashState *state, int hashbitlen)
{
 xdata  	int i;

state->hashbitlen=hashbitlen ; 
state->databitlen[3]=0;
state->databitlen[2]=0;
state->databitlen[1]=0;
state->databitlen[0]=0;

for (i=0;i<129;i++) 
{(state->block)[i]= 0x0 ;}

if ((hashbitlen==384) || (hashbitlen==512))
{   state->blocksize=1024;
    
	if (hashbitlen==384)  {
		for(i=0;i<16;i++) {
		(state->hashval)[i]=i384[i];
		}
		} 
    if (hashbitlen==512) {
		for(i=0;i<16;i++) {
			(state->hashval)[i]=i512[i] ;
			}
			}			     
}
else
{
	return BAD_HASHLEN;
}
return SUCCESS;
}



 HashReturn Hash(int hashbitlen, const BitSequence *hdata, DataLength databitlen, BitSequence *hashval)
{
 xdata  hashState state;
 xdata  HashReturn HReturn;

HReturn=Init(&state, hashbitlen); 
if (HReturn != SUCCESS) {	return HReturn;}

HReturn=Update(&state, hdata, databitlen); 
if (HReturn != SUCCESS) { 	return HReturn;}

HReturn=Final(&state, hashval); 
if (HReturn != SUCCESS) { return HReturn;}

return HReturn;
}


 