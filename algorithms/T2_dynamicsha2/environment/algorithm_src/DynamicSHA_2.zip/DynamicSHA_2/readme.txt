Contents                                        Description
---------------                          ------------------------------------------------
Readme.txt                                       This file

\Additional_Implementations\Ref\api2_ref8_32.pdf  API for the reference implementation at "8-bit processor" for Dynamic SHA2-224/256
\Additional_Implementations\Ref\api2_ref8_64.pdf  API for the reference implementation at "8-bit processor" for Dynamic SHA2-384/512
\Additional_Implementations\Ref\dsha2_ref8_32.h   The head file for the reference implementation at "8-bit processor" for Dynamic SHA2-224/256
\Additional_Implementations\Ref\dsha2_ref8_64.h   The head file for the reference implementation at "8-bit processor" for Dynamic SHA2-384/512

\Additional_Implementations\Opt\api2_opt8_32.pdf  API for the reference optimized at "8-bit processor" for Dynamic SHA2-224/256
\Additional_Implementations\Opt\api2_opt8_64.pdf  API for the reference optimized at "8-bit processor" for Dynamic SHA2-384/512
\Additional_Implementations\Opt\dsha2_opt8_32.h   The head file for the reference optimized at "8-bit processor" for Dynamic SHA2-224/256
\Additional_Implementations\Opt\dsha2_opt8_64.h   The head file for the reference optimized at "8-bit processor" for Dynamic SHA2-384/512

\KAT_MCT\ShortMsgKAT_224.txt                     The message digest for short messages for Dynamic SHA2-224.
\KAT_MCT\ShortMsgKAT_256.txt                     The message digest for short messages for Dynamic SHA2-256.
\KAT_MCT\ShortMsgKAT_384.txt                     The message digest for short messages for Dynamic SHA2-384.
\KAT_MCT\ShortMsgKAT_512.txt                     The message digest for short messages for Dynamic SHA2-512.
\KAT_MCT\LongMsgKAT_224.txt                      The message digest for long messages for Dynamic SHA2-224.
\KAT_MCT\LongMsgKAT_256.txt                      The message digest for long messages for Dynamic SHA2-256.
\KAT_MCT\LongMsgKAT_384.txt                      The message digest for long messages for Dynamic SHA2-384.
\KAT_MCT\LongMsgKAT_512.txt                      The message digest for long messages for Dynamic SHA2-512.
\KAT_MCT\ExtremelyLongMsgKAT_224.txt             The message digest for extremely long messages for Dynamic SHA2-224.
\KAT_MCT\ExtremelyLongMsgKAT_256.txt             The message digest for extremely long messages for Dynamic SHA2-256.
\KAT_MCT\ExtremelyLongMsgKAT_384.txt             The message digest for extremely long messages for Dynamic SHA2-384.
\KAT_MCT\ExtremelyLongMsgKAT_512.txt             The message digest for extremely long messages for Dynamic SHA2-512.
\KAT_MCT\MonteCarlo_224.txt                      The file for Monte Carlo Test for Dynamic SHA2-224.
\KAT_MCT\MonteCarlo_256.txt                      The file for Monte Carlo Test for Dynamic SHA2-256.
\KAT_MCT\MonteCarlo_384.txt                      The file for Monte Carlo Test for Dynamic SHA2-384.
\KAT_MCT\MonteCarlo_512.txt                      The file for Monte Carlo Test for Dynamic SHA2-512.
\KAT_MCT\example.c                               The c code that produce the example file of Dynamic SHA2.
\KAT_MCT\Example_224.txt                         The example for Dynamic SHA2-224.
\KAT_MCT\Example_256.txt                         The example for Dynamic SHA2-256.
\KAT_MCT\Example_384.txt                         The example for Dynamic SHA2-384.
\KAT_MCT\Example_512.txt                         The example for Dynamic SHA2-512.

\Reference Implementation\dsha2_Ref.h            The head file for reference implementation for Dynamic SHA2.
\Reference Implementation\api2_ref.pdf           API for the reference implementation for Dynamic SHA2.
\Reference Implementation\genKAT_ref.c           Source to generate KAT files for required digest sizes
\Reference Implementation\ShortMsgKAT.txt        Input file for Short Message KAT Test
\Reference Implementation\LongMsgKAT.txt         Input file for Long Message KAT Test
\Reference Implementation\ExtremelyLongMsg.txt   Input file for Extremely Long Message KAT Test
\Reference Implementation\MonteCarlo.txt         Input file for Monte Carlo Test

\Optimized_32 bit\dsha2_opt32.h                  The head file for optimized implementations for Dynamic SHA2.
\Optimized_32 bit\api2_opt32.pdf                 API for the optimized implementation for Dynamic SHA2.
\Optimized_32 bit\genKAT_opt32.c                 Source to generate KAT files for required digest sizes
\Optimized_32 bit\ShortMsgKAT.txt                Input file for Short Message KAT Test
\Optimized_32 bit\LongMsgKAT.txt                 Input file for Long Message KAT Test
\Optimized_32 bit\ExtremelyLongMsg.txt           Input file for Extremely Long Message KAT Test
\Optimized_32 bit\MonteCarlo.txt                 Input file for Monte Carlo Test

\Optimized_64 bit\dsha2_opt64.h                  The head file for optimized implementations for Dynamic SHA2.
\Optimized_64 bit\api2_opt64.pdf                 API for the optimized implementations for Dynamic SHA2.
\Optimized_64 bit\genKAT_64.c                    Source to generate KAT files for required digest sizes
\Optimized_64 bit\ShortMsgKAT.txt                Input file for Short Message KAT Test
\Optimized_64 bit\LongMsgKAT.txt                 Input file for Long Message KAT Test
\Optimized_64 bit\ExtremelyLongMsg.txt           Input file for Extremely Long Message KAT Test
\Optimized_64 bit\MonteCarlo.txt                 Input file for Monte Carlo Test

\Supporting Documentation\DSHA2.pdf              The expound file for Dynamic SHA2
\Supporting Documentation\thanks.pdf             Something else
\Supporting Documentation\implementations.pdf    Implementations for Dynamic SHA2