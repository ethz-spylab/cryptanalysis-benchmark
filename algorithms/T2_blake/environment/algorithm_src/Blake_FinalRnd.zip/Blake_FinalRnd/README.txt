
CONTENT OF THIS CD:



./Additional_Implementations/blake256.tar.gz

gzipped tar archive containing the implementations of BLAKE-256
submitted to eBASH, as of Jan 11, 2011

./Additional_Implementations/blake512.tar.gz

gzipped tar archive containing the implementations of BLAKE-512
submitted to eBASH, as of Jan 11, 2011


./KAT_MCT/blake_kat.c
./KAT_MCT/blake_kat.h

C program of BLAKE used for making KAT/MCT tests.


./KAT_MCT/IntermediateValues_224.txt
./KAT_MCT/IntermediateValues_256.txt
./KAT_MCT/IntermediateValues_384.txt
./KAT_MCT/IntermediateValues_512.txt

Intermediate values, for one- and two-block messages, for each of the
required message digest sizes.


./KAT_MCT/ExtremelyLongMsgKAT.txt
./KAT_MCT/genKAT.c
./KAT_MCT/LongMsgKAT.txt
./KAT_MCT/MonteCarlo.txt
./KAT_MCT/Readme.txt
./KAT_MCT/ShortMsgKAT.txt

 Files provided by NIST for making KAT/MCT tests.


./KAT_MCT/ShortMsgKAT_224.txt
./KAT_MCT/LongMsgKAT_224.txt
./KAT_MCT/ExtremelyLongMsgKAT_224.txt
./KAT_MCT/MonteCarlo_224.txt
./KAT_MCT/ShortMsgKAT_256.txt
./KAT_MCT/LongMsgKAT_256.txt
./KAT_MCT/ExtremelyLongMsgKAT_256.txt
./KAT_MCT/MonteCarlo_256.txt
./KAT_MCT/ShortMsgKAT_384.txt
./KAT_MCT/LongMsgKAT_384.txt
./KAT_MCT/ExtremelyLongMsgKAT_384.txt
./KAT_MCT/MonteCarlo_384.txt
./KAT_MCT/ShortMsgKAT_512.txt
./KAT_MCT/LongMsgKAT_512.txt
./KAT_MCT/ExtremelyLongMsgKAT_512.txt
./KAT_MCT/MonteCarlo_512.txt

 Files output by NIST's KAT/MCT program.


./Optimized_32bit
./Optimized_32bit/blake_opt32.c
./Optimized_32bit/blake_opt32.h

 Optimized ANSI C implementation of BLAKE, for 32-bit processors.


./Optimized_64bit
./Optimized_64bit/blake_opt64.c
./Optimized_64bit/blake_opt64.h

 Optimized ANSI C implementation of BLAKE, for 64-bit processors.


./README.txt

 This file.


./Reference_Implementation
./Reference_Implementation/blake_ref.c
./Reference_Implementation/blake_ref.h

 Reference ANSI C implementation of BLAKE.


./Supporting_Documentation
./Supporting_Documentation/blake.pdf

 PDF of the supporting document, which includes a complete
 specification of BLAKE, security claims, performance reports,
 preliminary analysis, and test values.

./Supporting_Documentation/Round3Mods.pdf

Description of the modifications made to BLAKE from round 2 to round
3.

./Supporting_Documentation/blake_changelist_1.2.txt
./Supporting_Documentation/blake_changelist_1.3.txt
./Supporting_Documentation/blake_changelist_1.4.txt

Descriptions of the modifications done from the original submitted
documentation to version 1.2, from version 1.2 to version 1.3, and
from version 1.3 to 1.4.
