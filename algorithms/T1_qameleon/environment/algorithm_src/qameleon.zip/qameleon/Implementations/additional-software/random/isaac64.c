/*
------------------------------------------------------------------------------
isaac64.c: My random number generator for 64-bit machines.
By Bob Jenkins, 1996.  Public Domain.
------------------------------------------------------------------------------
*/

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <ctype.h>
# include <termios.h>

#ifndef STANDARD
#include "standard.h"
#endif
#ifndef ISAAC64
#include "isaac64.h"
#endif

extern    ub8 randrsl[RANDSIZ], randcnt;
static    ub8 mm[RANDSIZ];
static    ub8 aa=0, bb=0, cc=0;

#define ind(mm,x)  (*(ub8 *)((ub1 *)(mm) + ((x) & ((RANDSIZ-1)<<3))))
#define rngstep(mix,a,b,mm,m,m2,r,x) \
{ \
  x = *m;  \
  a = (mix) + *(m2++); \
  *(m++) = y = ind(mm,x) + a + b; \
  *(r++) = b = ind(mm,y>>RANDSIZL) + x; \
}

void isaac64()
{
  register ub8 a,b,x,y,*m,*m2,*r,*mend;
  m=mm; r=randrsl;
  a = aa; b = bb + (++cc);
  for (m = mm, mend = m2 = m+(RANDSIZ/2); m<mend; )
  {
    rngstep(~(a^(a<<21)), a, b, mm, m, m2, r, x);
    rngstep(  a^(a>>5)  , a, b, mm, m, m2, r, x);
    rngstep(  a^(a<<12) , a, b, mm, m, m2, r, x);
    rngstep(  a^(a>>33) , a, b, mm, m, m2, r, x);
  }
  for (m2 = mm; m2<mend; )
  {
    rngstep(~(a^(a<<21)), a, b, mm, m, m2, r, x);
    rngstep(  a^(a>>5)  , a, b, mm, m, m2, r, x);
    rngstep(  a^(a<<12) , a, b, mm, m, m2, r, x);
    rngstep(  a^(a>>33) , a, b, mm, m, m2, r, x);
  }
  bb = b; aa = a;
}

#define mix(a,b,c,d,e,f,g,h) \
{ \
   a-=e; f^=h>>9;  h+=a; \
   b-=f; g^=a<<9;  a+=b; \
   c-=g; h^=b>>23; b+=c; \
   d-=h; a^=c<<15; c+=d; \
   e-=a; b^=d>>14; d+=e; \
   f-=b; c^=e<<20; e+=f; \
   g-=c; d^=f>>17; f+=g; \
   h-=d; e^=g<<14; g+=h; \
}

void randinit(flag)
word flag;
{
   word i;
   ub8 a,b,c,d,e,f,g,h;
   aa=bb=cc=(ub8)0;
   a=b=c=d=e=f=g=h=0x9e3779b97f4a7c13LL;  /* the golden ratio */

   for (i=0; i<4; ++i)                    /* scramble it */
   {
     mix(a,b,c,d,e,f,g,h);
   }

   for (i=0; i<RANDSIZ; i+=8)   /* fill in mm[] with messy stuff */
   {
     if (flag)                  /* use all the information in the seed */
     {
       a+=randrsl[i  ]; b+=randrsl[i+1]; c+=randrsl[i+2]; d+=randrsl[i+3];
       e+=randrsl[i+4]; f+=randrsl[i+5]; g+=randrsl[i+6]; h+=randrsl[i+7];
     }
     mix(a,b,c,d,e,f,g,h);
     mm[i  ]=a; mm[i+1]=b; mm[i+2]=c; mm[i+3]=d;
     mm[i+4]=e; mm[i+5]=f; mm[i+6]=g; mm[i+7]=h;
   }

   if (flag) 
   {        /* do a second pass to make all of the seed affect all of mm */
     for (i=0; i<RANDSIZ; i+=8)
     {
       a+=mm[i  ]; b+=mm[i+1]; c+=mm[i+2]; d+=mm[i+3];
       e+=mm[i+4]; f+=mm[i+5]; g+=mm[i+6]; h+=mm[i+7];
       mix(a,b,c,d,e,f,g,h);
       mm[i  ]=a; mm[i+1]=b; mm[i+2]=c; mm[i+3]=d;
       mm[i+4]=e; mm[i+5]=f; mm[i+6]=g; mm[i+7]=h;
     }
   }

   isaac64();          /* fill in the first set of results */
   randcnt=RANDSIZ;    /* prepare to use the first set of results */
}


int main()
{
  ub8 i,j;

  unsigned char initialiser[] =
	"The deployment of small computing devices such as RFID tags, ind"
	"ustrial controllers, sensor nodes and smart cards is becoming mu"
	"ch more common. The shift from desktop computers to small device"
	"s brings a wide range of new security and privacy concerns. In m"
	"any conventional cryptographic standards, the tradeoff between s"
	"ecurity, performance and resource requirements was optimized for"
	" desktop and server environments, and this makes them difficult "
	"or impossible to implement in resource-constrained devices. When"
	"they can be implemented, their performance may not be acceptable"
	". Lightweight cryptography is a subfield of cryptography that ai"
	"ms to provide solutions tailored for resource-constrained device"
	"s. There has been a significant amount of work done by the acade"
	"mic community related to lightweight cryptography; this includes"
	" efficient implementations of conventional cryptography standard"
	"s, and the design and analysis of new lightweight primitives and"
	" protocols. In 2013, NIST initiated a lightweight cryptography p"
	"roject to study the performance of the current NIST-approved cry"
	"ptographic standards on constrained devices and to understand th"
	"e need for dedicated lightweight cryptography standards, and if "
	"the need is identified, to design a transparent process for stan"
	"dardization. In July 2015, NIST held the first Lightweight Crypt"
	"ography Workshop in Gaithersburg, MD, to get public feedback on "
	"the constraints and limitations of the target devices, and requi"
	"rements and characteristics of real-world applications of lightw"
	"eight cryptography. A second workshop was held in October 2016. "
	"In March 2017, NIST published NISTIR 8114 Report on Lightweight "
	"Cryptography and announced that it has decided to create a portf"
	"olio of lightweight algorithms through an open process. In April"
	" 2017, NIST published the draft whitepaper Profiles for the Ligh"
	"tweight Cryptography Standardization Process to solicit feedback"
	" on proposed functionalities for initial inclusion in the portfo"
	"lio. In this call for submissions document, the submission requi"
	"rements and evaluation process for the lightweight cryptography "
	"standardization process are explained.";

  memcpy(randrsl,initialiser,RANDSIZ*sizeof(ub8));

  aa = bb = cc = (ub8)0;
  for (i=0; i<RANDSIZ; ++i) mm[i]=(ub8)0;
  randinit(TRUE);
  FILE *f;
  f = fopen("rand.txt", "w+");
  for (i=0; i<12; ++i)
  {
    isaac64();
    for (j=0; j<RANDSIZ; ++j)
    {
      fprintf(f,"%.8x%.8x,",(ub4)(randrsl[j]>>32),(ub4)randrsl[j]);
      if ((j&3)==3)
	fprintf(f,"\n");
    }
  }
  fclose(f);
}
