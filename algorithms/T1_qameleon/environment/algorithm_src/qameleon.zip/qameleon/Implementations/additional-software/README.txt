The ISAAC64-based PRNG that we use to compute the constants for the
tweak compression can be found in the directory random/ 

The software that is used to sieve all involutory 4x4 S-Boxes to
find the candidates for sigma_1 can be found in sbox-generator/

There are four files in MILP/

qarma-milp-linear.c generated the MILP program used to count the
number of active S-Boxes in QARMA in linear trails
qarma-milp-reltweak.c generated the MILP program used to count the
number of active S-Boxes in QARMA in related tweak, single key,
(linear and) differential trails

qarma-milp-constant-64.cpp and qarma-milp-constant-128.cpp are
the programs that generate the MILP program to count the number of
active S-Boxes in the tweak compression.

This software is provided as is and even though it should be 
architecture independent we make no guarantee about its compilability.
We expect however no bad surprises.
