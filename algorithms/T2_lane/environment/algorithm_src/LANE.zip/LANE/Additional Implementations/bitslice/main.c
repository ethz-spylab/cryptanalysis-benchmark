#include "lane.h"

#include <stdio.h>
#include <string.h>

static const char *const string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

unsigned char digest[32];

int
main()
{
  int i;

  printf("\"%s\" (%u bytes)\n", string, (unsigned int) strlen(string));

  Hash(256, (BitSequence*) string, 8*strlen(string), digest);
  for (i=0; i!=32; ++i)
    printf("%02x ", (int) digest[i]);
  printf("\n");

  return 0;
}
