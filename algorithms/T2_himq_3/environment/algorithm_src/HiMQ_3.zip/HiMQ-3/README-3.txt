The distribution media contains the following files (replace HiMQ-3 where HiMQ-3F where appropriate).


README.TXT      -    This file


In the subdirectory Reference_Implementation

api.h        - application programming interface file 
gf256.c    - GF(256) arithmetic - Implementation file
gf256.h    - GF(256) arithmetic - Header file
mq.c        - Matrix arithmetic - Implementation file
mq.h        - Matrix arithmetic - Header file 
sign.c        - HiMQ-3 signature - Implementation file
test.c       - test for example of HiMQ-3 signature - Implementation file


In the subdirectory Optimized_Implementation

api.h               - application programming interface file 
gf256.c       - GF(256) arithmetic - Implementation file
gf256.h       - GF(256) arithmetic - Header file
Makefile      - makefile
PQCgen_sign.c     - example of HiMQ-3 signature - Implementation file
rng.c             - random function - Implementation file
rng.h               - random function - Header file 
sign.c               - HiMQ-3 signature - Implementation file


In the subdirectory KAT

api.h                   - application programming interface file 
gf256.c            - GF(256) arithmetic - Implementation file
gf256.h            - GF(256) arithmetic - Header file
intermediate_values.pdf   - examples with several intermediate values 
Makefile           - makefile
PQCgenKAT_sign.c        - example of KAT of HiMQ-3 signature - Implementation file
PQCsignKAT_11489.req       - KAT output file 
PQCsignKAT_11489.rsp       - KAT output file 
rng.c                       - random function - Implementation file
rng.h                       - random function - Header file 
sign.c                   - HiMQ-3 signature - Implementation file


In the subdirectory Supporting_Documentation

KAT_req.pdf     - output file of KAT_req  
KAT_rsp.pdf     - output file of KAT_rsp  



In the subdirectory Supporting_Documentation

-cover page
-a complete written specification
-an analysis of HiMQ-3 with respect to known attacks
-exitential unforgeability of HiMQ-3
-a thorough description of the expected security strength of HimQ-3
-a family of HiMQ-3
-a detailed performance analysis
-a statement of advantages and limitations.