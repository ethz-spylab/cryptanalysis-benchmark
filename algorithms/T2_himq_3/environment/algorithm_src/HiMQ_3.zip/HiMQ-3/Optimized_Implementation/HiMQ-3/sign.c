//gcc -o PQCgen_sign -O3 PQCgen_sign.c sign.c gf256.c rng.c -lssl -lcrypt
//
//  sign.c
//  HiMQ-3F <256, 31, 15, 15, 14>
//
//  Created and Modifid by Kim, Aeyoung on 9/29/17. (last modification: 11/29/2017)
//  in the project HiMQ-3F designed by Park, Cheol-Min and Shim, Kyung-Ah
//  


#include <stdio.h>
#include <string.h>
#include <openssl/sha.h>

#include "gf256.h"
#include "api.h"
#include "rng.h"


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
int sha256(unsigned char *hash_msg, const unsigned char *plain_msg, const int plain_msg_len)
{
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, plain_msg, plain_msg_len);
    SHA256_Final(hash_msg, &sha256);

    return 1;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// generate keys: sk, pk
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//gen_key_multadd_uc(xx, O1, T, V1, Tj_index, F);    
//gen_key_multadd_uc(&xx[O1*len_NN], O2, T, V1, Tj_index, F);    
//gen_key_multadd_uc(&xx[(O1+O2)*len_NN], O3, T, V1+O1, Tj_index, F);    
void gen_key_multadd_uc(unsigned char *xx, int num_k, unsigned char *Tij, int num_i, unsigned char *idx_Tj, unsigned char *coef)
{   
    int idx_i=0, num_ull_N = (N+7)>>3;
    unsigned char *ptr_Ti=Tij, *ptr_Tj, *ptr_xx = xx, *ptr_idx;
    unsigned char *ptr_tbl_c;
    unsigned char Ti256[N][256], cTj, cxx[num_ull_N<<3];
    unsigned long long *ptr_cxx_ull = cxx, *ptr_xx_ull = xx;

    //set 0 to xx
    for(int k=0; k<num_k; k++)
    {
        for (int j = 0; j < N; j++)
        {
            for(int r=0; r<N; r++)            
                ptr_xx[r] = 0;
            ptr_xx += N;
        }
    }


    for(int i=0; i<num_i; i++)
    {
        ptr_xx = xx;
        ptr_Ti = &Tij[i*N];       

        //loading Ti from the large table
        for(int j=0; j<N; j++)
            memcpy(&Ti256[j][0], &__gf256_mul_largetbl[ptr_Ti[j]][0], 256);

        ptr_idx = &idx_Tj[i+1];

        for(int k=0; k<num_k; k++)
        {   
            ptr_Tj = &Tij[ptr_idx[k]*N];
            ptr_tbl_c = &__gf256_mul_largetbl[coef[k]][0];
            
            //Tj x Cij
            for (int j = 0; j < N; j++)
            {
                cTj = ptr_tbl_c[ptr_Tj[j]];       

                //(Ti x cTj)
                for(int r=0; r<N; r++)                
                    cxx[r] = Ti256[r][cTj];

                ptr_xx_ull = ptr_xx;
                for(int r=0; r<num_ull_N; r++)
                    ptr_xx_ull[r] ^= ptr_cxx_ull[r];

                ptr_xx+=N;                
            }            
        }        


        coef += num_k;
        idx_i += N;
        ptr_Ti += N; //for next Ti
    }    
}


//gen_key_mult_dxx_8(xx_8, O1, Tij_8, V1, ptr_F);
//gen_key_mult_dxx_8(&xx_8[O1*len_NN], O2, Tij_8, V1+O1, ptr_F);
void gen_key_mult_dxx_uc(unsigned char *xx, int num_k, unsigned char *Tij, int num_i, unsigned char *coef)
{
    unsigned char *ptr_T1, *ptr_T2, *ptr_xx = xx;
    unsigned char *ptr_tbl_c, *ptr_tbl_cTj;
    unsigned char cTj[N], cxx[N];
    unsigned long long *ptr_cxx_ull = cxx, *ptr_xx_ull = xx;

    ptr_T2 = &Tij[(num_i+1)*N]; //T2
    ptr_T1 = ptr_T2 - N;        //T1

    for(int k=0; k<(num_k-1); k++)
    {           
        ptr_tbl_c = &__gf256_mul_largetbl[__gf256_inv[coef[k]]][0];

        for(int j=0; j<N; j++)
        {           
            //(c x Ti+1)              
            ptr_tbl_cTj = &__gf256_mul_largetbl[ptr_tbl_c[ptr_T2[j]]][0];            
            
            //(Ti x cTi+1)  
            for(int r=0; r<N; r++)            
                ptr_xx[r] ^= ptr_tbl_cTj[ptr_T1[r]];
            ptr_xx += N;
                   
        }

        ptr_T1 = ptr_T2;
        ptr_T2 += N;
        
        num_i++;        
    }

    coef+=(num_k-1);
    //num_k-th fx
    num_i -= (num_k-1);
    ptr_T2 = &Tij[num_i*N];
    ptr_tbl_c = &__gf256_mul_largetbl[__gf256_inv[*coef]][0];
    for(int j=0; j<N; j++)
    {           
        //(c x Ti+1)  
        ptr_tbl_cTj = &__gf256_mul_largetbl[ptr_tbl_c[ptr_T2[j]]][0];                    
                
        //(Ti x cTi+1)  
        for(int r=0; r<N; r++)        
            ptr_xx[r] ^= ptr_tbl_cTj[ptr_T1[r]];
        ptr_xx += N;
    }
}


//gen_key_mult_tri_8(&xx_8[(O1+O2)*len_NN], O3, &Tij_8[V1*N], O1, ptr_F);  //exx
void gen_key_mult_tri_uc(unsigned char *xx, int num_k, unsigned char *Tij, int num_i, unsigned char *coef)
{
    unsigned char *ptr_Tj, *ptr_Ti, *ptr_xx;   
    unsigned char cTj[N]; 
    unsigned char *ptr_tbl_c, *ptr_tbl_cTj;
    
    for(int j=0; j<(num_i-1); j++)
    {
        ptr_Tj = &Tij[j*N]; //j-th Tj
        ptr_Ti = ptr_Tj + N; 

        for(int i=j+1; i<num_i; i++)
        {         
            ptr_xx = xx;   
            for(int k=0; k<num_k; k++)
            {
                ptr_tbl_c =&__gf256_mul_largetbl[coef[k]][0];
                for (int s = 0; s < N; s++)
                {
                    //(c x Tj)                
                    ptr_tbl_cTj = &__gf256_mul_largetbl[ptr_tbl_c[ptr_Tj[s]]][0];

                    //(Ti x cTj)
                    for(int r=0; r<N; r++)                    
                        ptr_xx[r] ^= ptr_tbl_cTj[ptr_Ti[r]];
                    ptr_xx+=N;
                }                
            }
            coef += num_k;  //to point next k-th coefficient
            ptr_Ti += N;  //next Ti
        }
    }  
}


//gen_key_multadd_rIIxx_8(&xx_8[(O1+O2)*len_NN], O3, Tij_8, ptr_F);
void gen_key_multadd_rIIxx_uc(unsigned char *xx, int num_k, unsigned char *Tij, unsigned char *coef)
{
    int num_VOO = N - num_k, num_idx = num_k*6;      
    unsigned char cTj[N], idx_Tj[num_idx]; 
    unsigned char _mat[num_VOO][num_VOO];    
    unsigned char *ptr_Tj, *ptr_Ti=Tij, *ptr_xx, *ptr_idx=idx_Tj, *ptr_c=coef;
    unsigned char *ptr_tbl_mat, *ptr_tbl_cTj;

    for(int i=0; i<num_idx; i++)
        idx_Tj[i] = i%num_k+num_VOO;

    memcpy(_mat, coef, num_VOO*num_k);    

    for(int i=0; i<num_VOO; i++)
    {   
        ptr_xx = xx;
        ptr_idx = &idx_Tj[i+1];

        for(int k=0; k<num_k; k++)  
        {   
            ptr_Tj = &Tij[ptr_idx[k]*N];
            ptr_tbl_mat = &__gf256_mul_largetbl[_mat[k][i]][0];
      
            for(int j=0; j<N; j++)
            {   
                //(c x Tj)                
                ptr_tbl_cTj = &__gf256_mul_largetbl[ptr_tbl_mat[ptr_Tj[j]]][0];

                //(Ti x cTj)
                for(int r=0; r<N; r++)                
                    ptr_xx[r] ^= ptr_tbl_cTj[ptr_Ti[r]];
                ptr_xx += N;
            }
        }

        ptr_Ti += N;
    }
}


//calling by gen_key_public(pk, S, T, F);
void gen_key_public(unsigned char *pk, unsigned char *S, unsigned char *T, unsigned char *F)
{    
    int len_NN = N*N;
    int len_NNM = len_NN*M;
    unsigned char xx[len_NNM], sxx[len_NNM];
    unsigned char *ptr_uc[O3], *ptr_idx;
    unsigned char *ptr_xx_8, *ptr_sxx_8;
    unsigned char xx_arr[N][N]={0}, *ptr_pk=pk;
    unsigned char Tj_index[N]={0}, _idx[N];
    unsigned char *ptr_tbl_s;

    for(int i=0; i<N; i++)
        _idx[i] = i;


    //////////////////////////////////////////////////////////////////////Layer1: F(1)~F(O1)    alpha*Ti*Tj    (considering T)
    //to arrange index of Tj
    ptr_uc[0] = &Tj_index[V1];
    for(int i=0; i<V1; i++)
        ptr_uc[0][i] = Tj_index[i] = _idx[i];
    
    gen_key_multadd_uc(xx, O1, T, V1, Tj_index, F);    
    F += Len_Alpha;

    gen_key_mult_dxx_uc(xx, O1, T, V1, F);    
    F += O1;


    //////////////////////////////////////////////////////////////////////Layer2: F(O1+1)~F(O1+O2)  beta*Ti*Tj
    //to arrange index of Tj
    ptr_uc[0] = &Tj_index[O1];    
    ptr_uc[1] = ptr_uc[0] + O1;
    ptr_uc[2] = ptr_uc[1] + O1;
    ptr_idx = &_idx[V1];
    for(int i=0; i<O1; i++)
        ptr_uc[2][i] = ptr_uc[1][i] = ptr_uc[0][i] = Tj_index[i] = ptr_idx[i];
    
    gen_key_multadd_uc(&xx[O1*len_NN], O2, T, V1, Tj_index, F);    
    F += Len_Beta;

    gen_key_mult_dxx_uc(&xx[O1*len_NN], O2, T, V1+O1, F);    
    F += O2;

 
    /////////////////////////////////////////////////////////////////////Layer3
    //Layer3-1: F(O1+O2+1)~F(O1+O2+O3)  gammaI*Ti*Tj    
    //to arrange index of Tj
    ptr_uc[0] = &Tj_index[O2];  //#2   
    ptr_uc[1] = ptr_uc[0] + O2; //#3
    ptr_uc[2] = ptr_uc[1] + O2; //#4
    ptr_uc[3] = ptr_uc[2] + O2; //#5
    ptr_idx = &_idx[V1+O1];
    for(int i=0; i<O2; i++)
        ptr_uc[3][i] = ptr_uc[2][i] = ptr_uc[1][i] = ptr_uc[0][i] = Tj_index[i] = ptr_idx[i];

    gen_key_multadd_uc(&xx[(O1+O2)*len_NN], O3, T, V1+O1, Tj_index, F);    
    F += Len_GammaI;

    //Layer3-2: F(O1+O2+1)~F(O1+O2+O3)  sigma[sigma[epsilon*Ti*Tj]]
    gen_key_mult_tri_uc(&xx[(O1+O2)*len_NN], O3, &T[V1*N], O1, F); //exx
    F += Len_Epsilon;

    //Layer3-3: F(O1+O2+1)~F(O1+O2+O3)  gammaII*Ti*Tj
    gen_key_multadd_rIIxx_uc(&xx[(O1+O2)*len_NN], O3, T, F);


    //////////////////////////////////////////////////////////////////////S(F)   
    for (int i = 0; i<len_NNM; i++)
        sxx[i] = 0;

    for(int k=0; k<M; k++)  //M:=(O1+O2+O3) // _sxx[N*M*3];
    {
        ptr_sxx_8 = &sxx[k*len_NN]; //k-th sxx_8(:=S(F))
        for(int i=0; i<M; i++)
        {
            ptr_tbl_s = &__gf256_mul_largetbl[S[i]][0];            
            ptr_xx_8 = &xx[i*len_NN]; //i-th F(:=xx)

            for(int j=0; j<len_NN; j++)            
                ptr_sxx_8[j] ^= ptr_tbl_s[ptr_xx_8[j]];
        }
        S+=M;
    }    


    //////////////////////////////////////////////////////////////////////Save pk
    //rearrange xx(including private keys) and save into pk (tri)
    for(int k=0; k<M; k++)
    {   
        memcpy(&xx_arr[0][0], &sxx[k*len_NN], len_NN); //to copy k-th S(F) into _xx_arr

        ptr_pk=pk+k;        
        for(int i=0; i<N; i++)
        {
            for(int j=0; j<i; j++)
            {
                xx_arr[i][j] ^= xx_arr[j][i];
                xx_arr[j][i]=0;

                *ptr_pk=xx_arr[i][j];
                ptr_pk += M;
            }
            *ptr_pk=xx_arr[i][i];
            ptr_pk += M;
        }
    }
}


int crypto_sign_keypair(unsigned char *pk, unsigned char *sk)
{    
    unsigned char S[Size_MM]={0}, *ptr_SI=sk;
    unsigned char T[Size_NN]={0}, *ptr_TI=sk+Size_MM;
    unsigned char *F = sk+Size_MM+Size_NN;
    
    randombytes(sk, CRYPTO_SECRETKEYBYTES);

    for(int i=0; i<CRYPTO_SECRETKEYBYTES; i++)
    {
        while(sk[i]==0) 
            randombytes(&sk[i], 1);
    }
       
    Mat_Guass_Elim_uc(S, ptr_SI, M);   //as get_mat_inv_8(S, sk->SI, M)    

    while(check_mat_inv_uc(S, ptr_SI, M) == 0) //(exist_inv == 0)
    {
        randombytes(ptr_SI, Size_MM);
        Mat_Guass_Elim_uc(S, ptr_SI, M);
    }
    
    Mat_Guass_Elim_uc(T, ptr_TI, N);   //as get_mat_inv_8(S, sk->SI, M)

    while(check_mat_inv_uc(T, ptr_TI, N) == 0)
    {
        randombytes(ptr_TI, Size_NN);
        Mat_Guass_Elim_uc(T, ptr_TI, N);        
    }

    trans_mat(ptr_SI, M);  //for sign, it is also useful for generating pk with S
    trans_mat(ptr_TI, N);

    gen_key_public(pk, S, T, F);

    return 0;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Sign
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//multadd_cxx_uc(&yy_8[0], O1, xi, V1, &xj_8[0], F_a);
void multadd_cxx_uc(unsigned char *yy, int num_k, unsigned char *list_xi, int num_i, unsigned char *list_xj, unsigned char *coef)
{   
    int num_k_ull = (num_k+7)>>3;   // (num+7)/8
    unsigned char cxj[num_k];
    unsigned char *ptr_tbl_xi;
    unsigned long long *ptr_coef_ull = cxj, *ptr_y_ull = yy;
    
    for(int k=0; k<num_k_ull; k++)
        ptr_y_ull[k] = 0;       
    
    for(int i=0; i<num_i; i++)
    {     
        list_xj++;           
        ptr_tbl_xi = &__gf256_mul_largetbl[list_xi[i]][0];
        for(int j=0; j<num_k; j++)            
            cxj[j] = ptr_tbl_xi[__gf256_mul_largetbl[list_xj[j]][coef[j]]];

        for(int k=0; k<num_k_ull; k++)
            ptr_y_ull[k] ^= ptr_coef_ull[k];

        coef += num_k;
    }
}


//multadd_cxx_tri_8(&yy_8[O3], O3, &xi[V1], O1, F_e);
void multadd_cxx_tri_uc(unsigned char *yy, int num_k, unsigned char *x, int num_i, unsigned char *coef)
{
    int num_k_ull = (num_k+7)>>3;   // (num+7)/8
    unsigned char cxj[num_k], cxi[num_k];
    unsigned char *ptr_tbl_xj, *ptr_tbl_xi;
    unsigned long long *ptr_cxj_ull = cxj, *ptr_cxi_ull= cxi, *ptr_y_ull = yy;
    
    for(int k=0; k<num_k_ull; k++)   
        ptr_cxi_ull[k]= ptr_y_ull[k] = 0;                
    
    for(int i=0; i<(num_i-1); i++)
    {     
        for(int j=i+1; j<num_i; j++)
        {            
            ptr_tbl_xj = &__gf256_mul_largetbl[x[j]][0];
            for(int k=0; k<num_k; k++)
                cxj[k] = ptr_tbl_xj[coef[k]];

            coef += num_k;        

            for(int k=0; k<num_k_ull; k++)
                ptr_cxi_ull[k] ^= ptr_cxj_ull[k];
        }

        ptr_tbl_xi = &__gf256_mul_largetbl[x[i]][0];

        for(int k=0; k<num_k; k++)
            cxi[k] = ptr_tbl_xi[cxi[k]];

        for(int k=0; k<num_k_ull; k++)
        {
            ptr_y_ull[k] ^= ptr_cxi_ull[k];
            ptr_cxi_ull[k] = 0;
        }
    }
}


//mult_rIIx_8(&rIIx_8[0], O3, &xi[0], V1+O1+O2, F_r2);
void mult_rIIx_uc(unsigned char *yy, int num_k, unsigned char *x, int num_i, unsigned char *coef) //k=1~O3 //xj i=oi
{
    int num_k_ull = (num_k+7)>>3;   // (num+7)/8
    int num_last; //=V1+O1+O2 = num_i
    unsigned char cxi[num_i], *ptr_uc, *ptr_yy_uc=yy+1, *ptr_cxi_uc; //8 for the garbage space of the last in each cxi
    unsigned long long *ptr_cxi_ull= cxi, *ptr_yy_ull = ptr_yy_uc;
        
    for(int j=0; j<num_k; j++)
    {     
        for(int i=0; i<num_i; i++)       
            cxi[i] = __gf256_mul_largetbl[x[i]][coef[i]];
            
        coef += num_i;

        for(int k=0; k<num_k_ull; k++)    
            ptr_yy_ull[k] = 0;       
    
        ptr_cxi_ull = cxi;
        ptr_uc = ptr_cxi_ull;
        num_last = num_i;
        for(int k=0; k<(num_i/num_k); k++)
        {
            ptr_yy_ull[0] ^= ptr_cxi_ull[0];
            ptr_yy_ull[1] ^= ptr_cxi_ull[1];
            ptr_uc += num_k;
            ptr_cxi_ull = ptr_uc;
            num_last -= num_k;
        }        

        //last part of cxi
        ptr_uc = ptr_yy_ull;
        ptr_cxi_uc = ptr_cxi_ull;
        for(int k=0; k<num_last; k++)              
            ptr_uc[k] ^= ptr_cxi_uc[k];

        memcpy(ptr_yy_uc-j-1, &ptr_uc[num_k-j-1], j+1);

        //shifting 1byte in next yy(=yy[j])
        ptr_yy_uc += num_k+1;
        ptr_yy_ull = ptr_yy_uc;
    }    
}


//with transpose matrix
void multadd_mat_x_uc(unsigned long long *yy, unsigned char *mat, unsigned char *x, int num)
{   
    int num_ull = (num+7)>>3;   // (num+7)/8
    unsigned char cx[num];
    unsigned char *ptr_tbl_xi=cx;
    unsigned long long *ptr_cx_ull = cx, *ptr_y_ull = yy;
    
    for(int k=0; k<num_ull; k++)
        ptr_y_ull[k] = 0;       
    
    for(int i=0; i<num; i++)
    {        
        ptr_tbl_xi = &__gf256_mul_largetbl[x[i]][0];

        for(int j=0; j<num; j++)
            cx[j] = ptr_tbl_xi[mat[j]];
        mat += num;

        for(int k=0; k<num_ull; k++)
            ptr_y_ull[k] ^= ptr_cx_ull[k];
    }
}


//solve_x_dxx_8(xj, xx1, O1)
void solve_x_dxx_uc(unsigned char *sol, unsigned char *fx, int num)
{    
    unsigned char odd, even;
    int i;

    odd = fx[0];
    even = fx[1];

    for(i=2; i<(num-1); i+=2)
    {
        odd = __gf256_mul_largetbl[odd][fx[i]]; 
        even = __gf256_mul_largetbl[even][fx[i+1]];
    }
    
    if((num-1)==i)    
        odd = __gf256_mul_largetbl[odd][fx[i]]; 
    
    odd = __gf256_mul_largetbl[odd][__gf256_inv[even]];
    sol[0] = __gf256_sqrt[odd]; 

    for(i=1; i<num; i++)    
        sol[i] = __gf256_mul_largetbl[__gf256_inv[sol[i-1]]][fx[i-1]];        
}



//modified: 2017.11.08 Wed.
int crypto_sign(unsigned char *sm, unsigned long long *smlen, const unsigned char *m, unsigned long long mlen, const unsigned char *sk)
{   
    unsigned char hm[CRYPTO_RANDOMBYTES]={0}, sham[32];
    unsigned char xi[N]={0}; 
    unsigned char *SInv=sk, *TInv=sk+Size_MM;
    unsigned char *F_a=TInv+Size_NN, *F_d1=F_a+Len_Alpha, *F_b=F_d1+O1, *F_d2=F_b+Len_Beta;
    unsigned char *F_r1=F_d2+O2, *F_e=F_r1+Len_GammaI, *F_r2=F_e+Len_Epsilon;
    
    int i, k, flag=0, num_ull = (M+7)>>3;    
    unsigned char xj_8[N<<2]={0}, yy_8[N]={0}, xx1[O1], xx2[O2]; //instead of xj 
    unsigned char *ptr_uc[O3];
    unsigned char fx_8[CRYPTO_RANDOMBYTES], rIIx_8[O3*O3+O3];

/*--------------------------------------------------------------------------------------*/

    sha256(hm, m, mlen); 
    sha256(sham, hm, 32); 
    memcpy(&hm[32], sham, CRYPTO_RANDOMBYTES-32);
     
/*--------------------------------------------------------------------------------------*/
    //SInv(hm)        
    multadd_mat_x_uc(fx_8, SInv, hm, M);   //output:fx_8=SInv(hm), SInv=SInv-M*M
    
/*--------------------------------------------------------------------------------------*/
    while(1)
    {
        /*--------------------------------------------------------------------------------------*/
        //L1: F1~FO1
        //k-th fx: F_k(x) = Phi_k(x) + delta_k * x_v+k * x_v+k+1
        //Phi_k(x) = sigma(i:1-V)[ alpha * xi * x_1+(i+j-1)%V ]     //j=1~O1
        /*--------------------------------------------------------------------------------------*/
        randombytes(xi, V1);

        //instead of applying operator "Mod"
        ptr_uc[0] = &xj_8[V1];
        for(int i=0; i<V1; i++)
            ptr_uc[0][i] = xj_8[i] = xi[i];

        multadd_cxx_uc(&yy_8[0], O1, xi, V1, &xj_8[0], F_a);        //k=1~O1     //for alpha: 31 elements * 15(j=1,...,O1) sets
        
        for(i=0; i<O1; i++)
        {
            yy_8[i] ^= fx_8[i];
            if(yy_8[i]==0)
                break;
        }
        if(i<O1)      
           continue;
          
        for(i=0; i<O1; i++)
        {
            xx1[i] = __gf256_mul_largetbl[yy_8[i]][F_d1[i]];            
            if(xx1[i] == 0)
                break;
        }        
        if(i<O1)
           continue;

        solve_x_dxx_uc(&xi[V1], xx1, O1); //to solve for getting variables x(v1+1)~x(v1+O1)        


        /*--------------------------------------------------------------------------------------*/
        //L2: FO1+1 ~ FO1+O2
        //F_k(x) = Psi_k(x) + delta_k * x_v1+k * x_v1+k+1
        //Psi_k(x) = sigma(i:1-V)[ beta * xi * x_v+1+(i+j-1)%O1 ]   ///j=1~O1
        /*--------------------------------------------------------------------------------------*/
        
        //instead of applying operator "Mod"
        //O1 variables: x32~x46
        ptr_uc[0] = &xj_8[O1];    
        ptr_uc[1] = ptr_uc[0] + O1;
        ptr_uc[2] = ptr_uc[1] + O1;
        ptr_uc[O3-1] = &xi[V1];
        for(int i=0; i<O1; i++)
            ptr_uc[2][i] = ptr_uc[1][i] = ptr_uc[0][i] = xj_8[i] = ptr_uc[O3-1][i];
    

        multadd_cxx_uc(&yy_8[0], O2, xi, V1, &xj_8[0], F_b);        
                
        for(i=0; i<O2; i++)
        {
            yy_8[i] ^= fx_8[O1+i];
            if(yy_8[i]==0)
                break;
        }
        if(i<O2)      
           continue;
        
        for(i=0; i<O2; i++)
        {
            xx2[i] = __gf256_mul_largetbl[yy_8[i]][F_d2[i]];            
            if(xx2[i] == 0)
                break;
        }        
        if(i<O2)
           continue;

        solve_x_dxx_uc(&xi[V1+O1], xx2, O2); //to solve for getting variables x(v1+1)~x(v1+O1)



        /*--------------------------------------------------------------------------------------*/
        //L3: 
        //Pi(x) with gamma rI, rII in L3
        /*--------------------------------------------------------------------------------------*/        

        //instead of applying operator "Mod"  
        //to prepare xj mod O2
        ptr_uc[0] = &xj_8[O2];  //#2   
        ptr_uc[1] = ptr_uc[0] + O2; //#3
        ptr_uc[2] = ptr_uc[1] + O2; //#4
        ptr_uc[3] = ptr_uc[2] + O2; //#5
        ptr_uc[O3-1] = &xi[V1+O1];
        for(int i=0; i<O2; i++)
            ptr_uc[3][i] = ptr_uc[2][i] = ptr_uc[1][i] = ptr_uc[0][i] = xj_8[i] = ptr_uc[O3-1][i];

        multadd_cxx_uc(&yy_8[0], O3, xi, V1+O1, &xj_8[0], F_r1); 

        for(i=0; i<O3; i++)
        {
            yy_8[i] ^= fx_8[O1+O2+i];
            if(yy_8[i]==0)
                break;
        }
        if(i<O3)      
           continue;

        multadd_cxx_tri_uc(&yy_8[O3], O3, &xi[V1], O1, F_e);
       
        for(i=0; i<O3; i++)
        {
            yy_8[O3+i] ^= yy_8[i];
            if(yy_8[O3+i]==0)
                break;
        }
        if(i<O3)
           continue;

        mult_rIIx_uc(&rIIx_8[0], O3, &xi[0], V1+O1+O2, F_r2); //k=1~O3 //xj i=oi
        
        //get solution with LU
        flag = solve_x_LU_uc(&xi[V1+O1+O2], &rIIx_8[0], &yy_8[O3], O3);    //(unsinged char, __m256i, __m256i, int)        
        if(flag)      
           continue;
        
        if (!flag)
            break;
    }


/*--------------------------------------------------------------------------------------*/
    //TInv(xi)        
    memcpy(sm, m, mlen);
    multadd_mat_x_uc(&sm[mlen], TInv, xi, N);
    *smlen = mlen+N;

    return 0;
}

 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Verify - general version (no SIMD) by using large lookup table
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int crypto_sign_open(unsigned char *m, unsigned long long *mlen, const unsigned char *sm, unsigned long long smlen, const unsigned char *pk)
{   
    *mlen = smlen - CRYPTO_BYTES;
    unsigned char cxx[CRYPTO_RANDOMBYTES];
    int num = (CRYPTO_RANDOMBYTES+7)>>3;
    unsigned char sham[32], hm[CRYPTO_RANDOMBYTES], rm[CRYPTO_RANDOMBYTES];
    unsigned char *ptr_sm;
    unsigned char *ptr_tbl_xi, *ptr_tbl_xx;
    unsigned long long  *ptr_cxx_ull = cxx, *ptr_rm_ull = rm;
    
/*--------------------------------------------------------------------------------------*/    
    ptr_sm = &sm[*mlen]; 
    for(int k=0; k<num; k++)
        ptr_rm_ull[k] =0;

    for(int i=0; i<CRYPTO_BYTES; i++)
    {         
        ptr_tbl_xi = &__gf256_mul_largetbl[ptr_sm[i]][0];

        for(int j=0; j<=i; j++) 
        {   
            ptr_tbl_xx = &__gf256_mul_largetbl[ptr_tbl_xi[ptr_sm[j]]][0];

            for(int k=0; k<CRYPTO_RANDOMBYTES; k++)                
                cxx[k] = ptr_tbl_xx[pk[k]];

            for(int k=0; k<num; k++)
                ptr_rm_ull[k] ^= ptr_cxx_ull[k];

            pk += CRYPTO_RANDOMBYTES;
        }                
    }

/*--------------------------------------------------------------------------------------*/    
    sha256(hm, sm, *mlen); 
    sha256(sham, hm, 32);
    memcpy(&hm[32], sham, CRYPTO_RANDOMBYTES-32);


    if ( memcmp(hm, rm, CRYPTO_RANDOMBYTES)==0 ) 
        memcpy(m, sm, *mlen); //if(pass), copy msg    
    else
        return -1;

    return 0;
}
