//gcc -o PQCgen_sign PQCgen_sign.c sign.c gf256.c rng.c -lssl -lcrypto -O3
//
//  PQCgen_sign.c
//  HiMQ-3F <256, 31, 15, 15, 14>
//
//  Created and Modifid by Kim, Aeyoung on 9/29/17. (last modification: 11/29/2017)
//  in the project HiMQ-3F designed by Park, Cheol-Min and Shim, Kyung-Ah
//  

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "api.h"
#include "rng.h"

#define MEASURE_ROUNDS 1000

int main()
{       
    unsigned char pk[CRYPTO_PUBLICKEYBYTES];
    unsigned char sk[CRYPTO_SECRETKEYBYTES];
    unsigned char msg[MEASURE_ROUNDS*33];    
    unsigned char *mout;    
    unsigned char sm[CRYPTO_BYTES+MEASURE_ROUNDS*33];
    unsigned long long mlen, moutlen;
    unsigned long long smlen;    
    int i, j, sum_pass=0;  
    
    

    for (i = 0; i < MEASURE_ROUNDS; i++) 
    {
        printf("i:%d\t", i);

        crypto_sign_keypair(pk, sk);    

        mlen = 33*(i+1);
        randombytes(msg, mlen); 

        crypto_sign(sm, &smlen, msg, mlen, sk);                

        mout = (unsigned char *)calloc(mlen+CRYPTO_BYTES, sizeof(unsigned char));
    
        crypto_sign_open(mout, &moutlen, sm, smlen, pk);
        

        if (mlen != moutlen)
            printf("mlen != moutlen\t");

        if ( memcmp(msg, mout, mlen) ) {
            printf("msg valid .... bad %d \n", i);  
        } 
        else
        {
            sum_pass++;
            printf("pass!\n");
        }   

        free(mout);
    }
    
    printf("HiMQ-3F:\nCorrectness...%d/%d(%g%%)\n", sum_pass, MEASURE_ROUNDS, (double)sum_pass/MEASURE_ROUNDS*100); 
    

    printf("\n");

    return 0;
}



