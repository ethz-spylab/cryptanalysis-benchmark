//
//  gf256.h
//
//  Modified on 11/15/17.
//  Created by Kim, Aeyoung on 9/29/17.
//  Copyright © 2017 Kim, Aeyoung. All rights reserved.
//
//  in the project HiMQ3-I designed by Park, Cheolmin and Shim, Kyung-Ah
//  

#ifndef gf256_H
#define gf256_H

unsigned char __gf256_inv[256];
unsigned char __gf256_sqrt[256];
unsigned char __gf256_mul_largetbl[256][256];

#endif
