//
//  api.h
//  HiMQ-3F <256, 31, 15, 15, 14>
//
//  Created and Modifid by Kim, Aeyoung on 9/29/17. (last modification: 11/29/2017)
//  in the project HiMQ-3F designed by Park, Cheol-Min and Shim, Kyung-Ah
//  

#ifndef API_H
#define API_H


#define P 256
#define V1 31	
#define O1 15	
#define O2 15
#define O3 14

#define M (O1+O2+O3)
#define N (V1+M)

#define Len_Alpha (V1*O1)
#define Len_Beta (V1*O2)
#define Len_GammaI ((V1+O1)*O3)
#define Len_GammaII ((V1+O1+O2)*O3)
#define Len_Epsilon ((1+O3)*O3*O3/2)

#define Size_MM (M*M)
#define Size_NN (N*N)

#define CRYPTO_SECRETKEYBYTES (Size_MM + Size_NN + Len_Alpha + O1 + Len_Beta + O2 + Len_GammaI + Len_GammaII + Len_Epsilon) 	//11489
#define CRYPTO_PUBLICKEYBYTES (((1+N)*N/2)*M)	//125400	//=((1+75)*75/2)*44
#define CRYPTO_BYTES N
#define CRYPTO_RANDOMBYTES M
#define CRYPTO_ALGNAME "HiMQ-3"



int crypto_sign_keypair(unsigned char *pk, unsigned char *sk);

int crypto_sign(unsigned char *sm, unsigned long long *smlen, const unsigned char *m, unsigned long long mlen, const unsigned char *sk);

int crypto_sign_open(unsigned char *m, unsigned long long *mlen, const unsigned char *sm, unsigned long long smlen, const unsigned char *pk);



/*************************************
//implementation environment

CPU: Intel(R) Core(TM) i7-6700 (Skylake) @3.4GHz, turbo boost diabled
Memory: 16GB
OS: x86_64-linux-gnu (Ubuntu 5.4.0-6ubuntu1~16.04.4)
gcc: 5.4.0 20160609
*************************************/

#endif