//
//  sign.c
//  HiMQ-3F <256, 24, 11, 17, 15>
//
//  Created and Modifid by Kim, Aeyoung on 9/29/17. (last modification: 11/27/2017)
//  in the project HiMQ-3F designed by Park, Cheol-Min and Shim, Kyung-Ah
//  

#include <stdio.h>
#include <string.h>
#include <openssl/sha.h>

#include "gf256.h"
#include "api.h"
#include "rng.h"
 
 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
int sha256(unsigned char *hash_msg, const unsigned char *plain_msg, const int plain_msg_len)
{
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, plain_msg, plain_msg_len);
    SHA256_Final(hash_msg, &sha256);

    return 1;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// generate keys: sk, pk
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//gen_key_multadd_uc(ptr_xx, O3, T, V1+O1, Tj_index, F);    
void gen_key_multadd_uc(unsigned char *y, int num_k, unsigned char *Tij, int num_i, unsigned char *idx_Tj, unsigned char *coef)
{   
    unsigned char *ptr_Ti = Tij, *ptr_Tj, *ptr_y, *ptr_idx;
    unsigned char cxx[N];
    unsigned char *ptr_tbl_c, *ptr_tbl_cTj;     
    unsigned long long *ptr_y_ull = y, *ptr_cxx_ull = cxx;

    
    for(int i=0; i<num_i; i++)
    {
        ptr_y = y;
        ptr_idx = &idx_Tj[i+1];
        for(int k=0; k<num_k; k++)
        {
            ptr_Tj = &Tij[ptr_idx[k]*N]; 
            ptr_tbl_c = &__gf256_mul_largetbl[coef[k]][0];
            
            //Tj x Cij
            for (int j = 0; j < N; j++)
            {                
                ptr_tbl_cTj = &__gf256_mul_largetbl[ptr_tbl_c[ptr_Tj[j]]][0];

                //(Ti x cTj)
                for(int r=0; r<N; r++)                
                    cxx[r] = ptr_tbl_cTj[ptr_Ti[r]];                     

                ptr_y_ull = ptr_y;               
                ptr_y_ull[0] ^= ptr_cxx_ull[0];
                ptr_y_ull[1] ^= ptr_cxx_ull[1];
                ptr_y_ull[2] ^= ptr_cxx_ull[2];
                ptr_y_ull[3] ^= ptr_cxx_ull[3];
                ptr_y_ull[4] ^= ptr_cxx_ull[4];
                ptr_y_ull[5] ^= ptr_cxx_ull[5];
                ptr_y_ull[6] ^= ptr_cxx_ull[6];
                ptr_y_ull[7] ^= ptr_cxx_ull[7];

                for(int r=64; r<N; r++)
                    ptr_y[r] ^= cxx[r];

                ptr_y += N;
            }            
        }        

        coef += num_k;       
        ptr_Ti += N; //for next Ti
    }
}


//gen_key_mult_tri_uc_full(xx, O1, T, V1, F);
//gen_key_mult_tri_uc_full(ptr_xx, O3, T, O1, F);
void gen_key_mult_tri_uc_full(unsigned char *xx, int num_k, unsigned char *T, int num_i, unsigned char *coef)
{   
    unsigned char *ptr_Tj=T, *ptr_Ti=T, *ptr_xx=xx;  
    unsigned char *ptr_tbl_c, *ptr_tbl_cTi;             
    unsigned char cxx[N];     
    int num = num_k*Size_NN;
    int num_ull = num>>3;
    unsigned long long *ptr_xx_ull = xx, *ptr_cxx_ull = cxx;

    //set 0 to xx
    for(int i=0; i<num_ull; i++)    
        ptr_xx_ull[i] = 0;
    for(int i=num_ull<<3; i<num; i++)    
        xx[i]=0;
    
    for(int i=0; i<num_i; i++)
    {        
        for(int j=i; j<num_i; j++)
        {                     
            ptr_xx = xx;  

            for(int k=0; k<num_k; k++)
            {
                ptr_tbl_c = &__gf256_mul_largetbl[coef[k]][0];                

                for (int s=0; s<N; s++)
                {
                    //(c x Tj)                     
                    ptr_tbl_cTi = &__gf256_mul_largetbl[ptr_tbl_c[ptr_Ti[s]]][0];

                    //(Ti x cTj)
                    for(int r=0; r<N; r++)                    
                        ptr_xx[r] ^= ptr_tbl_cTi[ptr_Tj[r]];                        
                    ptr_xx += N;
                }
            }
            coef += num_k;
            ptr_Tj += N;  //next Tj
        }
        ptr_Ti += N;  //next Ti  
        ptr_Tj = ptr_Ti;
    } 
}


//gen_key_mult_rect_uc_full(&xx[O1*len_NN], O2, T, V1, O1, F);
void gen_key_mult_rect_uc_full(unsigned char *y, int num_k, unsigned char *T, int num_i, int num_j, unsigned char *coef)
{       
    unsigned char *ptr_Ti, *ptr_Tj, *ptr_y=y, *ptr_T_num_i=&T[num_i*N];  
    unsigned char *ptr_tbl_c, *ptr_tbl_cTi;          
    unsigned char cTi, cxx[N];
    unsigned long long *ptr_y_ull = y, *ptr_cxx_ull = cxx;
        
    int num = num_k*Size_NN;
    int num_ull = num>>3;
    for(int i=0; i<num_ull; i++)    
        ptr_y_ull[i] = 0;
    for(int i=num_ull<<3; i<num; i++)    
        y[i]=0;

    ptr_Ti=T;
    for(int i=0; i<num_i; i++)
    {
        ptr_Tj = ptr_T_num_i;
        for(int j=0; j<num_j; j++)
        {                     
            ptr_y = y;  

            for(int k=0; k<num_k; k++)
            {
                ptr_tbl_c = &__gf256_mul_largetbl[coef[k]][0];    

                //k-th xx and c
                for (int s=0; s<N; s++)
                {
                    //(c x Ti)                
                    cTi = ptr_tbl_c[ptr_Ti[s]];
                    ptr_tbl_cTi = &__gf256_mul_largetbl[cTi][0];

                    //(Tj x cTi)
                    for(int r=0; r<N; r++)                    
                        cxx[r] = ptr_tbl_cTi[ptr_Tj[r]];                        

                    ptr_y_ull = ptr_y;
                    ptr_y_ull[0] ^= ptr_cxx_ull[0];
                    ptr_y_ull[1] ^= ptr_cxx_ull[1];
                    ptr_y_ull[2] ^= ptr_cxx_ull[2];
                    ptr_y_ull[3] ^= ptr_cxx_ull[3];
                    ptr_y_ull[4] ^= ptr_cxx_ull[4];
                    ptr_y_ull[5] ^= ptr_cxx_ull[5];
                    ptr_y_ull[6] ^= ptr_cxx_ull[6];
                    ptr_y_ull[7] ^= ptr_cxx_ull[7];

                    for(int r=64; r<N; r++)
                        ptr_y[r] ^= cxx[r];

                    ptr_y += N;
                }
            }
            coef += num_k;
            ptr_Tj += N;  //next Tj
        }
        ptr_Ti += N;  //next Ti        
    } 
}



//gen_key_mult_dxx_8(xx_8, O1, Tij_8, V1, ptr_F);
//gen_key_mult_dxx_8(&xx_8[O1*len_NN], O2, Tij_8, V1+O1, ptr_F);
void gen_key_mult_dxx_uc(unsigned char *y, int num_k, unsigned char *Tij, int num_i, unsigned char *coef)
{
    unsigned char *ptr_T1, *ptr_T2, *ptr_y = y;
    unsigned char *ptr_tbl_c, *ptr_tbl_cTj;
    unsigned char cxx[N];
    unsigned long long *ptr_y_ull = y, *ptr_cxx_ull = cxx;

    ptr_T2 = &Tij[(num_i+1)*N]; //T2
    ptr_T1 = ptr_T2 - N;        //T1
    
    for(int k=0; k<(num_k-1); k++)
    {           
        ptr_tbl_c = &__gf256_mul_largetbl[__gf256_inv[coef[k]]][0];
        for(int j=0; j<N; j++)
        {           
            //(c x Ti+1)              
            ptr_tbl_cTj = &__gf256_mul_largetbl[ptr_tbl_c[ptr_T2[j]]][0];
            //(Ti x cTi+1)  
            for(int r=0; r<N; r++)            
                cxx[r] = ptr_tbl_cTj[ptr_T1[r]];

            ptr_y_ull = ptr_y;
            ptr_y_ull[0] ^= ptr_cxx_ull[0];
            ptr_y_ull[1] ^= ptr_cxx_ull[1];
            ptr_y_ull[2] ^= ptr_cxx_ull[2];
            ptr_y_ull[3] ^= ptr_cxx_ull[3];
            ptr_y_ull[4] ^= ptr_cxx_ull[4];
            ptr_y_ull[5] ^= ptr_cxx_ull[5];
            ptr_y_ull[6] ^= ptr_cxx_ull[6];
            ptr_y_ull[7] ^= ptr_cxx_ull[7];

            for(int r=64; r<N; r++)
                ptr_y[r] ^= cxx[r];

            ptr_y += N;
        }
        
        ptr_T1 = ptr_T2; //next T1        
        ptr_T2 += N;        
    }
        
    //num_k-th fx
    coef += (num_k-1); 
    ptr_T2 = &Tij[num_i*N];
    ptr_tbl_c = &__gf256_mul_largetbl[__gf256_inv[*coef]][0];
    for(int j=0; j<N; j++)
    {           
        //(c x Ti+1)  
        ptr_tbl_cTj = &__gf256_mul_largetbl[ptr_tbl_c[ptr_T2[j]]][0];
        
        //(Ti x cTi+1)  
        for(int r=0; r<N; r++)        
            cxx[r] = ptr_tbl_cTj[ptr_T1[r]];

        ptr_y_ull = ptr_y;
        ptr_y_ull[0] ^= ptr_cxx_ull[0];
        ptr_y_ull[1] ^= ptr_cxx_ull[1];
        ptr_y_ull[2] ^= ptr_cxx_ull[2];
        ptr_y_ull[3] ^= ptr_cxx_ull[3];
        ptr_y_ull[4] ^= ptr_cxx_ull[4];
        ptr_y_ull[5] ^= ptr_cxx_ull[5];
        ptr_y_ull[6] ^= ptr_cxx_ull[6];
        ptr_y_ull[7] ^= ptr_cxx_ull[7];

        for(int r=64; r<N; r++)
            ptr_y[r] ^= cxx[r];

        ptr_y += N;
    }
}


//gen_key_multadd_rIIxx_uc(ptr_xx, O3, T, F);
void gen_key_multadd_rIIxx_uc(unsigned char *y, int num_k, unsigned char *Tij, unsigned char *coef)
{
    int num_VOO = N - num_k, num_idx = num_k<<3;      
    unsigned char idx_Tj[num_idx], cxx[N]; 
    unsigned char *ptr_tbl_c, *ptr_tbl_cTj;
    unsigned char *ptr_Tj, *ptr_Ti=Tij, *ptr_y, *ptr_idx=idx_Tj, *ptr_c=coef;
    unsigned long long *ptr_y_ull = y, *ptr_cxx_ull = cxx;

    for(int i=0; i<num_idx; i++)
        idx_Tj[i] = i%num_k+num_VOO;

    for(int i=0; i<num_VOO; i++)
    {   
        ptr_y = y;
        ptr_c = &coef[i];
        ptr_idx = &idx_Tj[i+1];

        for(int k=0; k<num_k; k++)  //for(int k=0; k<max_k; k++)
        {   
            ptr_Tj = &Tij[ptr_idx[k]*N];
            ptr_tbl_c = &__gf256_mul_largetbl[*ptr_c][0];
            
            for(int j=0; j<N; j++)
            {   
                //(c x Tj)                                
                ptr_tbl_cTj = &__gf256_mul_largetbl[ptr_tbl_c[ptr_Tj[j]]][0];

                //(Ti x cTj)
                for(int r=0; r<N; r++)
                    cxx[r] = ptr_tbl_cTj[ptr_Ti[r]];

                ptr_y_ull = ptr_y;
                ptr_y_ull[0] ^= ptr_cxx_ull[0];
                ptr_y_ull[1] ^= ptr_cxx_ull[1];
                ptr_y_ull[2] ^= ptr_cxx_ull[2];
                ptr_y_ull[3] ^= ptr_cxx_ull[3];
                ptr_y_ull[4] ^= ptr_cxx_ull[4];
                ptr_y_ull[5] ^= ptr_cxx_ull[5];
                ptr_y_ull[6] ^= ptr_cxx_ull[6];
                ptr_y_ull[7] ^= ptr_cxx_ull[7];

                for(int r=64; r<N; r++)
                    ptr_y[r] ^= cxx[r];

                ptr_y += N;
            }

            ptr_c += num_VOO;
        }

        ptr_Ti += N;
    }
}




//calling by gen_key_public(pk, S, T, F);
void gen_key_public(unsigned char *pk, unsigned char *S, unsigned char *T, unsigned char *F)
{
    register int ii, jj; 
    int len_NNM = Size_NN*M, idx = V1+O1;   //len_NNM:=N*N*M
    unsigned char xx[len_NNM];
    unsigned char sxx[len_NNM], cxx[len_NNM];
    unsigned char *ptr_uc[O3];
    unsigned char Tj_index[N]={0}, _idx[N];
    unsigned char *ptr_tbl_s;
    unsigned char *ptr_xx, *ptr_sxx=sxx, *ptr_pk=pk;
    unsigned long long *ptr_sxx_ull = sxx, *ptr_cxx_ull = cxx;
    

    //////////////////////////////////////////////////////////////////////Layer1: F(1)~F(O1)    alpha*Ti*Tj    (considering T)    
    int num = O1*Size_NN;
    for(int i=0; i<num; i++)        
        xx[i]=0;

    gen_key_mult_tri_uc_full(xx, O1, T, V1, F);
    F += Len_Alpha1; 

    gen_key_mult_dxx_uc(xx, O1, T, V1, F);    
    F += O1;


    //////////////////////////////////////////////////////////////////////Layer2: F(O1+1)~F(O1+O2)  beta*Ti*Tj
    ptr_xx = &xx[O1*Size_NN];
    gen_key_mult_rect_uc_full(ptr_xx, O2, T, V1, O1, F);
    F += Len_Alpha2;

    gen_key_mult_dxx_uc(ptr_xx, O2, T, V1+O1, F);    
    F += O2;
 

    /////////////////////////////////////////////////////////////////////Layer3: F(O1+O2+1)~F(O1+O2+O3)     
    //beta*Ti*Tj
    ptr_xx = &xx[(O1+O2)*Size_NN]; 
    gen_key_mult_tri_uc_full(ptr_xx, O3, T, O1, F);
    F += Len_Beta; 

    //gammaI*Ti*Tj    
    //to arrange index of Tj
    ptr_uc[0] = &Tj_index[O2];  //#2   
    ptr_uc[1] = ptr_uc[0] + O2; //#3
    ptr_uc[2] = ptr_uc[1] + O2; //#4
    ptr_uc[3] = ptr_uc[2] + O2; //#5
    
    for(int i=0; i<O2; i++)
        ptr_uc[3][i] = ptr_uc[2][i] = ptr_uc[1][i] = ptr_uc[0][i] = Tj_index[i] = idx+i; //ptr_idx[i];

    gen_key_multadd_uc(ptr_xx, O3, T, V1+O1, Tj_index, F);    
    F += Len_GammaI;
    
    //gammaII*Ti*Tj
    gen_key_multadd_rIIxx_uc(ptr_xx, O3, T, F);
    F += Len_GammaII;


    //////////////////////////////////////////////////////////////////////S(F)   
    //for (int i = 0; i<len_NNM>>3; i++)
    //    ptr_sxx_ull[i] = 0;
    for (int i = 0; i<len_NNM; i++)
        sxx[i]=0;

    for(int k=0; k<M; k++)  //M:=(O1+O2+O3) // _sxx[N*M*3];
    {
        ptr_sxx = &sxx[k*Size_NN];
        
        for(int i=0; i<M; i++)
        {
            ptr_tbl_s = &__gf256_mul_largetbl[S[i]][0];
            ptr_xx = &xx[i*Size_NN];            
            for(int j=0; j<Size_NN; j++)
                ptr_sxx[j] ^= ptr_tbl_s[ptr_xx[j]];
        }
        S += M;
    }    

    //////////////////////////////////////////////////////////////////////Save pk
    //rearrange xx(including private keys) and save into pk (tri)    
    ptr_sxx = sxx;
    for(int k=0; k<M; k++)
    {   
        ptr_pk=pk+k;        
        for(int i=0; i<N; i++)
        {
            ii = i*N;
            for(int j=0; j<i; j++)
            {
                jj = j*N;
                ptr_sxx[ii+j] ^= ptr_sxx[jj+i];
                ptr_sxx[jj+i]=0;

                *ptr_pk=ptr_sxx[ii+j]; //[i*N+j]
                ptr_pk += M;
            }
            *ptr_pk=ptr_sxx[ii+i];
            ptr_pk += M;
        }
        ptr_sxx += Size_NN;
    }
}


int crypto_sign_keypair(unsigned char *pk, unsigned char *sk)
{    
    unsigned char S[Size_MM]={0}, *ptr_SI=sk;
    unsigned char T[Size_NN]={0}, *ptr_TI=sk+Size_MM;
    unsigned char *F = ptr_TI+Size_NN;
   
    randombytes(sk, CRYPTO_SECRETKEYBYTES);

    for(int i=0; i<CRYPTO_SECRETKEYBYTES; i++)
    {
        while(sk[i]==0) 
            randombytes(&sk[i], 1);
    }
      
    Mat_Guass_Elim_uc(S, ptr_SI, M);   //as get_mat_inv_8(S, sk->SI, M)    

    while(check_mat_inv_uc(S, ptr_SI, M) == 0) 
    {
        randombytes(ptr_SI, Size_MM);
        Mat_Guass_Elim_uc(S, ptr_SI, M);
    }

    Mat_Guass_Elim_uc(T, ptr_TI, N);   //as get_mat_inv_8(S, sk->SI, M)

    while(check_mat_inv_uc(T, ptr_TI, N) == 0)
    {
        randombytes(ptr_TI, Size_NN);
        Mat_Guass_Elim_uc(T, ptr_TI, N);        
    }

    trans_mat(ptr_SI, M);  //for sign, it is also useful for generating pk with S
    trans_mat(ptr_TI, N);

    gen_key_public(pk, S, T, F);

    return 0;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Sign
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//multadd_cxx_uc(&yy_8[0], O3, xi, V1+O1, &xj_8[0], F_r1);   
void multadd_cxx_uc(unsigned char *yy, int num_k, unsigned char *list_xi, int num_i, unsigned char *list_xj, unsigned char *coef)
{   
    int num_k_ull = (num_k+7)>>3;   
    unsigned char cxj[num_k], *ptr_tbl_xi;
    unsigned long long *ptr_coef_ull = cxj, *ptr_y_ull = yy;
    
    for(int k=0; k<num_k_ull; k++)
        ptr_y_ull[k] = 0;       
    
    for(int i=0; i<num_i; i++)
    {     
        list_xj++;
        ptr_tbl_xi = &__gf256_mul_largetbl[list_xi[i]][0];

        for(int k=0; k<num_k; k++)
        {            
            cxj[k] = __gf256_mul_largetbl[list_xj[k]][coef[k]];            
            yy[k] ^= ptr_tbl_xi[cxj[k]];
        }

        coef += num_k;        
    }
}

//multadd_cxx_tri_uc_full(&yy_8[0], O1, xi, V1, F_a1); 
//multadd_cxx_tri_uc_full(&yy_8[0], O3, xi, O1, F_b);
void multadd_cxx_tri_uc_full(unsigned char *yy, int num_k, unsigned char *x, int num_i, unsigned char *coef)
{       
    int num_k_ull = (num_k+7)>>3;   
    unsigned char cxj[num_k_ull<<3], xx, *ptr_tbl_xi, *ptr_tbl_xx;
    unsigned long long *ptr_coef_ull = cxj, *ptr_y_ull = yy;
    
    for(int k=0; k<(num_k_ull+1); k++)    
        ptr_coef_ull[k] = ptr_y_ull[k] = 0;        
   
    for(int i=0; i<num_i; i++)
    {        
        ptr_tbl_xi = &__gf256_mul_largetbl[x[i]][0];

        for(int j=i; j<num_i; j++)
        {
            xx = ptr_tbl_xi[x[j]];
            ptr_tbl_xx = &__gf256_mul_largetbl[xx][0];

            for(int k=0; k<num_k; k++)                
                cxj[k] = ptr_tbl_xx[coef[k]];         

            for(int k=0; k<num_k_ull; k++)
                ptr_y_ull[k] ^= ptr_coef_ull[k];   

            coef += num_k;
        }
    }
}



//generated: 2017.11.23.
//multadd_cxx_rect_uc_full(&yy_8[0], O2, xi, V1, O1, F_a2);
void multadd_cxx_rect_uc_full(unsigned char *yy, int num_k, unsigned char *x, int num_i, int num_j, unsigned char *coef)
{       
    int num_k_ull = (num_k+7)>>3;   
    unsigned char cxx[num_k_ull<<3], xx, *ptr_tbl_xi, *ptr_tbl_xx, *ptr_xj=&x[num_i];
    unsigned long long *ptr_coef_ull = cxx, *ptr_y_ull = yy;
    
    for(int k=0; k<num_k_ull; k++)    
        ptr_coef_ull[k] = ptr_y_ull[k] = 0;    
    
    for(int i=0; i<num_i; i++)
    {        
        ptr_tbl_xi = &__gf256_mul_largetbl[x[i]][0];

        for(int j=0; j<num_j; j++)
        {
            xx = ptr_tbl_xi[ptr_xj[j]];
            ptr_tbl_xx = &__gf256_mul_largetbl[xx][0];

            for(int k=0; k<num_k; k++)
                cxx[k] = ptr_tbl_xx[coef[k]];         

            for(int k=0; k<num_k_ull; k++)
                ptr_y_ull[k] ^= ptr_coef_ull[k];   

            coef += num_k;
        }
    }
}


//mult_rIIx_8(&rIIx_8[0], O3, &xi[0], V1+O1+O2, F_r2);
void mult_rIIx_uc(unsigned char *yy, int num_k, unsigned char *x, int num_i, unsigned char *coef) //k=1~O3 //xj i=oi
{    
    unsigned char cxi[num_i], *ptr_yy_uc=yy+1;     
    unsigned char sum[num_k], *ptr_sum=sum, cnt_sum=0;
        
    for(int j=0; j<num_k; j++)
    {   
        cnt_sum=0;
        for(int k=0; k<num_k; k++)
            ptr_sum[k]=0;

        for(int i=0; i<num_i; i++)
        {
            cxi[i] = __gf256_mul_largetbl[x[i]][coef[i]];
            ptr_sum[cnt_sum] ^= cxi[i];
            cnt_sum++;
            if (cnt_sum==num_k)
                cnt_sum=0;            
        }
            
        coef += num_i;

        memcpy(ptr_yy_uc, sum, num_k-j-1);
        memcpy(ptr_yy_uc-j-1, &sum[num_k-j-1], j+1);

        //shifting 1byte in next yy(=yy[j])
        ptr_yy_uc += num_k+1;
    }
}


//with transpose matrix
//multadd_mat_x_uc(fx_8, SInv, m, M);  
//multadd_mat_x_uc(sm, TInv, xi, N);
void multadd_mat_x_uc(unsigned char *yy, unsigned char *mat, unsigned char *x, int num)
{       
    unsigned char cx[num];
    unsigned char *ptr_xi;
    unsigned long long *ptr_cx_ull = cx, *ptr_y_ull = yy;
        
    memset(yy, 0, num);
    
    for(int i=0; i<num; i++)
    {    
        ptr_xi = &__gf256_mul_largetbl[x[i]][0];

        for(int k=0; k<num; k++)
            yy[k] ^= ptr_xi[mat[k]];

        mat += num;
    }
}


//solve_x_dxx_uc(&xi[V1], xx, O1);
//solve_x_dxx_uc(&xi[V1+O1], xx, O2);
void solve_x_dxx_uc(unsigned char *sol, unsigned char *fx, int num)
{    
    unsigned char odd, even;
    int i;

    odd = fx[0];
    even = fx[1];

    for(i=2; i<(num-1); i+=2)
    {
        odd = __gf256_mul_largetbl[odd][fx[i]]; 
        even = __gf256_mul_largetbl[even][fx[i+1]];
    }
    
    if((num-1)==i)    
        odd = __gf256_mul_largetbl[odd][fx[i]]; 
    
    odd = __gf256_mul_largetbl[odd][__gf256_inv[even]];
    sol[0] = __gf256_sqrt[odd]; 

    for(i=1; i<num; i++)    
        sol[i] = __gf256_mul_largetbl[__gf256_inv[sol[i-1]]][fx[i-1]];        
}



//modified: 2017.11.08 Wed.
int crypto_sign(unsigned char *sm, unsigned long long *smlen, const unsigned char *m, unsigned long long mlen, const unsigned char *sk)
{
    unsigned char hm[CRYPTO_RANDOMBYTES]={0}, sham[32];
    unsigned char xi[N]={0}; 
    unsigned char *SInv=sk, *TInv=sk+Size_MM;
    unsigned char *F_a1=TInv+Size_NN, *F_d1=F_a1+Len_Alpha1, *F_a2=F_d1+O1, *F_d2=F_a2+Len_Alpha2;
    unsigned char *F_b=F_d2+O2, *F_r1=F_b+Len_Beta, *F_r2=F_r1+Len_GammaI;
    
    int i, k;
    unsigned char xj_8[N<<2]={0}, yy_8[M]={0}, xx[V1];
    unsigned char *ptr_mod[O3];
    unsigned char fx_8[M], rIIx_8[O3*O3];
    unsigned long long *ptr_y_ull = yy_8, *ptr_fx_ull = fx_8;
    
    //to generate hashed message from original message
    sha256(hm, m, mlen); 
    sha256(sham, hm, 32); 
    memcpy(&hm[32], sham, CRYPTO_RANDOMBYTES-32);

    //SInv(m)        
    multadd_mat_x_uc(fx_8, SInv, hm, M);   //output:fx_8=SInv(m), SInv=SInv-M*M
    
    while(1)
    {
        /*--------------------------------------------------------------------------------------*/
        //L1: F1~FO1
        //k-th fx: F_k(x) = Phi_k(x) + delta_k * x_v+k * x_v+k+1
        //Phi_k(x) = sigma(i:1-V)[ alpha * xi * x_1+(i+j-1)%V ]     //j=1~O1
        /*--------------------------------------------------------------------------------------*/        
        randombytes(xi, V1);


        multadd_cxx_tri_uc_full(&yy_8[0], O1, xi, V1, F_a1);     //k=1~O1     //for alpha: 31 elements * 15(j=1,...,O1) sets

        ptr_y_ull[0] ^= ptr_fx_ull[0];
        ptr_y_ull[1] ^= ptr_fx_ull[1];
        
        for(i=0; i<O1; i++)
            if(yy_8[i]==0)
                break;
        if(i<O1)
           continue;
        
        for(i=0; i<O1; i++)
        {
            xx[i] = __gf256_mul_largetbl[yy_8[i]][F_d1[i]];

            if(xx[i] == 0)
                break;
        }        
        if(i<O1)
           continue; 

        solve_x_dxx_uc(&xi[V1], xx, O1); //to solve for getting variables x(v1+1)~x(v1+O1)        


        /*--------------------------------------------------------------------------------------*/
        //L2: FO1+1 ~ FO1+O2
        //F_k(x) = Psi_k(x) + delta_k * x_v1+k * x_v1+k+1
        //Psi_k(x) = sigma(i:1-V)[ beta * xi * x_v+1+(i+j-1)%O1 ]   ///j=1~O1
        /*--------------------------------------------------------------------------------------*/

        multadd_cxx_rect_uc_full(&yy_8[0], O2, xi, V1, O1, F_a2); 



        for(i=0; i<O2; i++)
        {
            yy_8[i] ^= fx_8[O1+i];
            if(yy_8[i]==0)
                break;
        }
        if(i<O2)
           continue;
    
        for(i=0; i<O2; i++)
        {
            xx[i] = __gf256_mul_largetbl[yy_8[i]][F_d2[i]];            
            if(xx[i] == 0)
                break;
        }        
        if(i<O2)
           continue;

        solve_x_dxx_uc(&xi[V1+O1], xx, O2); //to solve for getting variables x(v1+1)~x(v1+O1)



        /*--------------------------------------------------------------------------------------*/
        //L3: 
        //Pi(x) with gamma rI, rII in L3
        /*--------------------------------------------------------------------------------------*/        
        multadd_cxx_tri_uc_full(&yy_8[0], O3, xi, O1, F_b);

        for(i=0; i<O3; i++)
        {
            yy_8[i] ^= fx_8[O1+O2+i];
            if(yy_8[i]==0)
                break;
        }
        if(i<O3)
           continue;


        //instead of applying operator "Mod"  
        //to prepare xj mod O2
        ptr_mod[0] = &xj_8[O2];  //#2   
        ptr_mod[1] = ptr_mod[0] + O2; //#3
        ptr_mod[2] = ptr_mod[1] + O2; //#4
        ptr_mod[3] = ptr_mod[2] + O2; //#5
        ptr_mod[O3-1] = &xi[V1+O1];
        for(int i=0; i<O2; i++)
            ptr_mod[3][i] = ptr_mod[2][i] = ptr_mod[1][i] = ptr_mod[0][i] = xj_8[i] = ptr_mod[O3-1][i];

        multadd_cxx_uc(&yy_8[O3], O3, xi, V1+O1, &xj_8[0], F_r1);         
               
        for(i=0; i<O3; i++)
        {
            yy_8[i] ^= yy_8[O3+i];
            if(yy_8[i]==0)
                break;
        }
        if(i<O3)
           continue;

        mult_rIIx_uc(&rIIx_8[0], O3, &xi[0], V1+O1+O2, F_r2); //k=1~O3 //xj i=oi

        i = solve_x_LU_uc(&xi[V1+O1+O2], &rIIx_8[0], yy_8, O3);    //(unsinged char, __m256i, __m256i, int)        
        
        if(i)
           continue;
       
        if (!i)
            break;
    }


/*--------------------------------------------------------------------------------------*/
    //TInv(xi)  
    memcpy(sm, m, mlen);      
    multadd_mat_x_uc(&sm[mlen], TInv, xi, N);
    *smlen = mlen+N;

    return 0;
}

 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Verify - general version (no SIMD) by using large lookup table
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int crypto_sign_open(unsigned char *m, unsigned long long *mlen, const unsigned char *sm, unsigned long long smlen, const unsigned char *pk)
{
    *mlen = smlen - CRYPTO_BYTES;
    unsigned char cxx[CRYPTO_RANDOMBYTES];
    int num = (CRYPTO_RANDOMBYTES+7)>>3;
    unsigned char sham[32], hm[CRYPTO_RANDOMBYTES], rm[CRYPTO_RANDOMBYTES];
    unsigned char *ptr_sm;
    unsigned char *ptr_tbl_xi, *ptr_tbl_xx;
    unsigned long long  *ptr_cxx_ull = cxx, *ptr_rm_ull = rm;
    
/*--------------------------------------------------------------------------------------*/    
    ptr_sm = &sm[*mlen]; 
    for(int k=0; k<num; k++)
        ptr_rm_ull[k] =0;

    for(int i=0; i<CRYPTO_BYTES; i++)
    {         
        ptr_tbl_xi = &__gf256_mul_largetbl[ptr_sm[i]][0];

        for(int j=0; j<=i; j++) 
        {   
            ptr_tbl_xx = &__gf256_mul_largetbl[ptr_tbl_xi[ptr_sm[j]]][0];

            for(int k=0; k<CRYPTO_RANDOMBYTES; k++)                
                cxx[k] = ptr_tbl_xx[pk[k]];

            for(int k=0; k<num; k++)
                ptr_rm_ull[k] ^= ptr_cxx_ull[k];

           pk += CRYPTO_RANDOMBYTES;
        }                
    }

/*--------------------------------------------------------------------------------------*/
    sha256(hm, sm, *mlen); //hm:=hash(original message of sm) //sm:=(original msg||signature)
    sha256(sham, hm, 32); 
    memcpy(&hm[32], sham, CRYPTO_RANDOMBYTES-32);


    if ( memcmp(hm, rm, CRYPTO_RANDOMBYTES)==0 ) 
        memcpy(m, sm, *mlen); //if(pass), copy msg
    else
        return -1;

    
    return 0;
}

