//
//  api.h
//
//  HiMQ-3F <256, 24, 11, 17, 15>
//
//  Created and Modifid by Kim, Aeyoung on 9/29/17. (last modification: 11/27/2017)
//  in the project HiMQ-3F designed by Park, Cheol-Min and Shim, Kyung-Ah
//  


#ifndef API_H
#define API_H

#define P 256
#define V1 24
#define O1 11
#define O2 17
#define O3 15

#define M (O1+O2+O3)
#define N (V1+M)	

#define Len_Alpha1 	(O1*(1+V1)*V1>>1)  
#define Len_Alpha2 	(O2*V1*O1)
#define Len_Beta 	(O3*(1+O1)*O1>>1)	
#define Len_GammaI 	(O3*(V1+O1))
#define Len_GammaII (O3*(V1+O1+O2))


#define Size_MM (M*M)
#define Size_NN (N*N)



#define CRYPTO_SECRETKEYBYTES (Size_MM + Size_NN + Len_Alpha1 + O1 + Len_Alpha2 + O2 + Len_Beta + Len_GammaI + Len_GammaII + O3)
#define CRYPTO_PUBLICKEYBYTES (((N+Size_NN)>>1)*M)	
#define CRYPTO_BYTES N
#define CRYPTO_RANDOMBYTES M
#define CRYPTO_ALGNAME "HiMQ-3F"


#define Num_ull_M ((CRYPTO_RANDOMBYTES+7)>>3)	//with length of msg
#define Num_ull_N ((CRYPTO_BYTES+7)>>3)			//with length of sign
#define Num_verify ((1+N)*N>>1)  //the number of lines(size:=M) for verification(crypto_sign_open())



int crypto_sign_keypair(unsigned char *pk, unsigned char *sk);

int crypto_sign(unsigned char *sm, unsigned long long *smlen, const unsigned char *m, unsigned long long mlen, const unsigned char *sk);

int crypto_sign_open(unsigned char *m, unsigned long long *mlen, const unsigned char *sm, unsigned long long smlen, const unsigned char *pk);



/*************************************
//implementation environment

CPU: Intel(R) Core(TM) i7-6700 (Skylake) @3.4GHz, turbo boost diabled
Memory: 16GB
OS: x86_64-linux-gnu (Ubuntu 5.4.0-6ubuntu1~16.04.4)
gcc: 5.4.0 20160609
*************************************/

#endif