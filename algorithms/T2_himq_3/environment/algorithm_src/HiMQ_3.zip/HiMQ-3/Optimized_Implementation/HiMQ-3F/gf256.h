//
//  gf256.h
//  HiMQ-3F <256, 24, 11, 17, 15>
//
//  Created and Modifid by Kim, Aeyoung on 9/29/17. (last modification: 11/27/2017)
//  in the project HiMQ-3F designed by Park, Cheol-Min and Shim, Kyung-Ah
//  
//  This program is only for the parameter <256, 24, 11, 17, 16>.

#ifndef gf256_H
#define gf256_H

unsigned char __gf256_inv[256];
unsigned char __gf256_sqrt[256];
unsigned char __gf256_mul_largetbl[256][256];

#endif
