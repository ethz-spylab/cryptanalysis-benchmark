//
//  mq.h
//
//  in the project HiMQ-3 submitted by Shim, Kyung-Ah, Park, Cheol-Min, and Kim, Aeyoung on 9/29/17
//  

#ifndef MQ_H
#define MQ_H

unsigned char Mat_Gauss_Elim(unsigned char *, unsigned char *, unsigned char);

void LU_decomp(unsigned char *, unsigned char *, unsigned char *, unsigned char len);

int LU_findsol(unsigned char *, unsigned char *, unsigned char *, unsigned char, unsigned char *);

int Solution_LU(unsigned char *, unsigned char *, unsigned char *, unsigned char);

unsigned char Gauss_Sol(unsigned char *, unsigned char *, unsigned char);

int exist_inv(unsigned char *, int);

void mult_tx(unsigned char *, const unsigned char*, unsigned char *, unsigned char);

void mult_fx(unsigned char *, const unsigned char *, unsigned char *);


void mult_invmatrix(unsigned char *, const unsigned char *, unsigned char *, unsigned char );

void mult_sf(unsigned char *, unsigned char *, unsigned char *);

void mult_ft(unsigned char *, unsigned char *, unsigned char *);
#endif
