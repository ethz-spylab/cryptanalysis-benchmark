//
//  sign.c
//
//  in the project HiMQ-3 submitted by Shim, Kyung-Ah, Park, Cheol-Min, and Kim, Aeyoung on 9/29/17
//    

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "gf256.h"
#include "api.h"
#include "mq.h"

/*
 * F[0] ~ F[O1+O2-1] <=> delta_1, ... , delta_(O1+O2)
 * F[O1+O2] ~ F[O1+O2 + V -1] <=> alpha[1, 1] , ..., alpha[1, V]
 * ...
 * F[O1+O2 + V*(O1-1)] ~ F[O1+O2 + V*O1 -1] <=> alpha[O1, 1], ..., alpha[O1, V]
 * F[O1+O2 + V*O1] ~ F[O1+O2 + V*O1 + V*O2 -1] <=> beta[1, 1], ..., beta[O2, V]
 * F[O1+O2 + V*O1 + V*O2] ~ F[O1+O2 + V*O1 + V*O2 + V1*O3 -1] <=> gamma
 * F[O1+O2 + V*O1 + V*O2 + V1*O3] ~ F[O1+O2+ V*O1 + V*O2 + V1*O3 + V2*O3 -1] <=> gamma'
 */

///////////////////////////////////////////////////////////
// generate keys:sk, pk
///////////////////////////////////////////////////////////

//used to generate alpha, beta, gamma
void gen_diag(unsigned char *F, unsigned char *F_prototype, int j, int loop, int mod, int start, int adj)
{
    int i, k;

    for (i = 0 ; i < loop ; i++)
    {
        k = start + (i+j+1) % mod;
        F_prototype[i*N+k] = rand()%255 + 1;
        F[loop*(j-adj) + i] = F_prototype[i*N+k];
    }
}

//generate sequence of coefficients delta
void gen_delta(unsigned char *F, unsigned char *F_prototype, int j, int mod, int start, int adj)
{
    int i, k;

    k = (j-adj+1) % mod;
    F_prototype[(start+j-adj)*N+start+k] = rand()%255 + 1;
    F[j] = F_prototype[(start+j-adj)*N+start+k];
}

//generate Layer3(FO1+O2+1, ..., FO1+O2+O3)
void gen_layer3(unsigned char *F, unsigned char *F_prototype, int j)
{
    int i, k;
    int start;

    //generate sequence of coefficients gamma
    gen_diag(F+gam, F_prototype, j, V1, O2, V1, O1+O2);

    //generate sequence of coefficients gamma'
    gen_diag(F+gam1, F_prototype, j, V2, O3, V2, O1+O2);

    //generate sequence of coefficients epsilon
    for (i = V+1 ; i < V1 ; i++)
    {
        start = (i-V-1) * (i-V) / 2;
        for (k = V ; k <= i-1 ; k++)
        {
            F_prototype[i*N+k] = rand() % 255 + 1;
            F[eps + epswid * (j-O1-O2) + start + k-V] = F_prototype[i*N+k];
        }
    }
}

//generate invertible matrix of given size
void gen_lin(unsigned char *T, int size)
{
    int i, j, loop = 1;

    while (loop)
    {
        for (i = 0 ; i < size ; i++)
        {
            for (j = 0 ; j < size ; j++)
            {
                T[i*size+j] = random() % 256;
            }
        }
       loop = !(exist_inv(T, size));
    }
}


//generate keypair
void crypto_sign_keypair(unsigned char *pk, unsigned char *sk)
{
    unsigned char *S, *T, *F;
    unsigned char *F_prototype;
    unsigned char *temp;

    temp = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));
    F_prototype = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));

    srand(time(NULL));

    S = sk;
    T = sk + MM;
    F = sk + MM + NN;

    //generate F
    for (int i = 0 ; i < O1 ; i++)
    {
        //generate sequence of coefficients alpha
        gen_diag(F+alp, F_prototype+i*PKWID, i, V, V, 0, 0);
        //generate gamma 1~O1
        gen_delta(F, F_prototype+i*PKWID, i, O1, V, 0);
    }
    for (int i = O1 ; i < O1+O2 ; i++)
    {
        //generate sequence of coefficients beta
        gen_diag(F+bet, F_prototype+i*PKWID, i, V, O1, V, O1);
        //generate gamma O1+1~O1+O2
        gen_delta(F, F_prototype+i*PKWID, i, O2, V1, O1);
    }
    for (int i = O1+O2 ; i < M ; i++)
    {
        gen_layer3(F, F_prototype+i*PKWID, i);
    }

    //generate S, T
    gen_lin(S, M);
    gen_lin(T, N);

    //generate publickey
    mult_sf(F_prototype, S, temp);

    for (int i = 0 ; i < M ; i++)
    {
        mult_ft(temp+i*PKWID, T, pk+(i*PKWID));
    }

    free(temp);
    return;
}

////////////////////////////////////////////////////////////
// Sign
///////////////////////////////////////////////////////////

//calculate sigma(i = 0 to max_i) coef[i]*list_xi[i]*list_xj[(i+j+1)%max_k]
//and store the result in *yy
unsigned char multadd_cxx(unsigned char *yy, const unsigned char *list_xi, const unsigned char *list_xj, unsigned char *coef, int j, int max_k, int max_i)
{
    int i, k;
    unsigned char result, temp;

    *yy = 0;
    for (i = 0 ; i < max_i ; i++)
    {
        k = (i+j+1) % max_k;
        temp = gf256_mul(list_xi[i], list_xj[k]);
        temp = gf256_mul(temp, coef[max_i*(j) + i]);
        *yy = *yy ^ temp;
    }
}

//sign layer 1, 2
int sign_layer12(unsigned char *sm, const unsigned char *m, int index, unsigned char *F)
{
    unsigned char all = 1, even = 1, yy;
    unsigned char *delta = F;
    int known, numfun, start, coeff_st, xj_st, mod;
    int j;

    if (index == 1)
    {
        known = V;
        numfun = O1;
        start = 0;
        coeff_st = alp;
        xj_st = 0;
        mod = V;
        for (j = 0 ; j < known ; j++)
        {
            sm[j] = rand()%256;
        }
    }
    else if (index == 2)
    {
        known = V1;
        numfun = O2;
        start = O1;
        coeff_st = bet;
        xj_st = V;
        mod = O1;
    }

    unsigned char temp_ans[numfun];

    //exclude diagonal element
    for (j = start ; j < start + numfun ; j++)
    {
        multadd_cxx(&yy, sm, sm+xj_st, F+coeff_st, j-start, mod, V);
        temp_ans[j] = gf256_mul(m[j]^yy, gf256_inv(delta[j]));

        //if there exist 0 among temp_ans, cannot find proper answer
        if (temp_ans[j] == 0)
        {
           return 0;
        }
    }

    for (j = 0 ; j < numfun ; j++)
    {
        all = gf256_mul(all, temp_ans[j+start]);
        if (j%2 == 1)
        {
            even = gf256_mul(even, temp_ans[j+start]);
        }
    }

    all = gf256_root(all);

    //find x_v+1
    sm[known] = gf256_mul(all, gf256_inv(even));
    sm[known+numfun-1] = gf256_mul(gf256_inv(sm[known]), temp_ans[start+numfun-1]);

    for (j = numfun-2 ; j > 0 ; j--)
    {
        sm[known+j] =gf256_mul(gf256_inv(sm[known+j+1]), temp_ans[start+j]);
    }

    return 1;

}

//calculate sigma(i=V+2 to V1)(j=V+1 to i-1)(epsilon_j, i)*xi*xj
unsigned char multadd_lowertriangle(unsigned char *F, unsigned char *sm)
{
    int i, j, t;
    unsigned char temp, result = 0;

    for (i = V+1 ; i < V1 ; i++)
    {
        t = (i-V-1) * (i-V) /2;
        for (j = V ; j < i ; j++)
        {
            temp = gf256_mul(F[t+j-V], sm[i]);
            temp = gf256_mul(temp, sm[j]);
            result = temp ^ result;
        }
    }

    return result;
}

//generate sign for layer 3
int sign_layer3(unsigned char *sm, const unsigned char *m, unsigned char *F)
{
    unsigned char *Lin;
    unsigned char *gamma1 = F+gam1;
    unsigned char temp_ans[N];
    unsigned char temp2[O3];
    unsigned char temp, yy;
    int i, j, k;

    //initialize Lin
    Lin = (unsigned char *)calloc(O3*O3, sizeof(unsigned char));

    for (i =0 ; i < O3*O3 ; i++)
    {
        Lin[i] = 0;
    }

    //exclude known elements
    for (j = O1+O2 ; j < M ; j++)
    {
        multadd_cxx(&yy, sm, sm+V1, F+gam, j-O1-O2, O2, V1);
        temp_ans[j-O1-O2] = m[j] ^ yy;
        temp_ans[j-O1-O2] ^= multadd_lowertriangle(F+eps+(j-O1-O2)*epswid, sm);
    }

    //get linear equations from F
    for (j = 0 ; j < O3 ; j++)
    {
        for (i = 0 ; i < V2 ; i++)
        {
            k = (i + O1+O2+j +1) % O3 + V2;

            temp = gf256_mul(sm[i], gamma1[j*V2+i]);
            Lin[j*O3+k-V2] = Lin[j*O3+k-V2] ^ temp;
        }
    }

    //find solution for above linear equations
    //if there is no unique solution, return 0
    if (Solution_LU(temp2, Lin, temp_ans, O3) == 0)
    {
        return 0;
    }

    //attach solution to previously generated signs
    for (i = 0 ; i < O3 ; i++)
    {
        sm[V2+i] = temp2[i];
    }

    free(Lin);
    return 1;
}

void crypto_sign(unsigned char *sm, unsigned long long *smlen, const unsigned char *m, unsigned long long mlen, const unsigned char *sk)
{

    unsigned char *temp, *S, *T, *F;
    int flag = 1;

    temp = (unsigned char *)calloc(N, sizeof(unsigned char));

    srand(time(NULL));

    S = sk;
    T = sk + MM;
    F = sk + MM + NN;

    //SInv(m)
    mult_invmatrix(S, m, temp, mlen);

    while (flag)
    {
        /*----------------------------------------*/
        //L1:
        //F1-FO1
        //k-th fx: F_k(x) = Phi_k(x) + delta_k * x_V+k * x_V+k+1
        //Phi_k(x) = sigma(i:1-V) [ alpha * xi * x_1+(i+j-1)%V ]
        /*----------------------------------------*/
        if (sign_layer12(sm, temp, 1, F) == 0)
        {
            continue;
        }
        /*----------------------------------------*/
        //L2:
        //FO1+1-FO1+O2
        //F_k(x)  = Psi_k(x) + delta_k * x_V1+k * x_V1+k+1
        //Phi_k(x) = sigma(i:1-V) [ beta * xi * x_V+(i+j-1)%O1 ]
        /*----------------------------------------*/
        if (sign_layer12(sm, temp, 2, F) == 0)
        {
            continue;
        }

        /*----------------------------------------*/
        //L3:
        //Pi(x) with gamma rl, rll in L3
        /*----------------------------------------*/
        flag = 1- sign_layer3(sm, temp, F);
    }

    //TInv(m)
    mult_invmatrix(T, sm, temp, *smlen);

    for (int i = 0 ; i < N ; i++)
    {
        sm[i] = temp[i];
    }
}

////////////////////////////////////////////////////////////
// Verify
////////////////////////////////////////////////////////////
int crypto_sign_open(unsigned char *m, unsigned long long *mlen, const unsigned char *sm, unsigned long long smlen, const unsigned char *pk)
{
    int i, j;
    int flag = 1;

    for (i = 0 ; i < *mlen ; i++)
    {
        mult_fx(pk+(i*PKWID), sm, &m[i]);
    }
}

