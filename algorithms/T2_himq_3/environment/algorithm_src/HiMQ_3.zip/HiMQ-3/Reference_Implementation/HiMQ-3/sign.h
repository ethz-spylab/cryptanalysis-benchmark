//
//  sign.h
//
//  in the project HiMQ-3 submitted by Shim, Kyung-Ah, Park, Cheol-Min, and Kim, Aeyoung on 9/29/17
//  

#ifndef SIGN_H
#define SIGN_H

void l12F(unsigned char *, unsigned int);

void L3F(unsigned char *, unsigned int);

void genlin(unsigned char *, int);

void crypto_sign_keypair(unsigned char *, unsigned char *);

unsigned char pi(unsigned char, unsigned char *, const unsigned char *, unsigned char);

void Layer(unsigned char *, const unsigned char *m, unsigned char, unsigned char*);

unsigned char L3assist(unsigned char*, unsigned char*);

void Layer3(unsigned char *, const unsigned char *, unsigned char*);

void crypto_sign(unsigned char*, unsigned long long *, const unsigned char *, unsigned long long, const unsigned char *);

int crypto_sign_open(const unsigned char *, unsigned long long *, const unsigned char *, unsigned long long, const unsigned char *);

#endif
