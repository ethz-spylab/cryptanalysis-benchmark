//
//  api.h
//
//  in the project HiMQ-3 submitted by Shim, Kyung-Ah, Park, Cheol-Min, and Kim, Aeyoung on 9/29/17
//  

#define P 256
#define V 31
#define O1 15
#define O2 15
#define O3 14
#define N 75
#define M 44
#define V1 46
#define V2 61
#define L_MSG M
#define L_SIGN N
#define MM 44*44
#define NN 75*75

#define CRYPTO_SECRETKEYBYTES 11489
#define CRYPTO_PUBLICKEYBYTES 125400
#define CRYPTO_BYTES N
#define CRYPTO_RANDOMBYTES M
#define CRYPTO_ALGNAME "HiMQ3"

#define PKSIZE 75*75*44
#define PKWID 75*75
#define SKSIZE 75*75*44 + 44*44 + 75*75


#define alp (15+15)
#define bet 15+15+31*15
#define gam 15+15+ 31*15 + 31*15
#define gam1 15+15+ 31*15 + 31*15 + 46*14
#define eps 15+15+ 31*15 + 31*15 + 46*14 + 61*14
#define sksize 15+15+31*15+31*15+4*14+61*14+105*14
#define epswid 105
