//
//  test.c
//  gcc -o test test.c sign.c gf256.c mq.c 
//
//  in the project HiMQ-3 submitted by Shim, Kyung-Ah, Park, Cheol-Min, and Kim, Aeyoung on 9/29/17
//  

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#include "api.h"
#include "sign.h"

#define MEASURE_ROUNDS 2
#define sksize 15+15+31*15+31*15+4*14+61*14+105*14

int signtest(void)
{
    unsigned char *sm, *m, *ver_m;
    unsigned char *skaddr, *pkaddr;
    unsigned char *S, *T, *F, *pk, *sk;
    unsigned long long smlen = N, mlen = M;

    int i, j, k;

    sm = (unsigned char *)calloc(N, sizeof(unsigned char));
    m = (unsigned char *)calloc(M, sizeof(unsigned char));
    ver_m = (unsigned char *)calloc(M, sizeof(unsigned char));

    F = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));
    T = (unsigned char *)calloc(NN, sizeof(unsigned char));
    S = (unsigned char *)calloc(MM, sizeof(unsigned char));
    pk = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));
    sk = (unsigned char *)calloc(sksize, sizeof(unsigned char));

    for (j =0 ; j < M ; j++)
    {
        m[j] = rand()%256;
    }

    crypto_sign_keypair(pk, sk);

    crypto_sign(sm, &smlen, m, mlen, sk);


    puts("msg");
    for (i = 0 ; i < M ; i++)
    {
        printf("%d ", m[i]);
    }
    puts("");
    return (crypto_sign_open(m, &mlen, sm, smlen, pk));
}

int signtest1(int index)
{
    unsigned char *sm, *m, *ver_m;
    unsigned char *skaddr, *pkaddr;
    unsigned char *S, *T, *F, *pk, *sk;    
    unsigned long long smlen = N, mlen = M;
    
    int i, j, k;

    sm = (unsigned char *)calloc(N, sizeof(unsigned char));
    m = (unsigned char *)calloc(M, sizeof(unsigned char));
    ver_m = (unsigned char *)calloc(M, sizeof(unsigned char));

    F = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));
    T = (unsigned char *)calloc(NN, sizeof(unsigned char));
    S = (unsigned char *)calloc(MM, sizeof(unsigned char));
    pk = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));
    sk = (unsigned char *)calloc(SKSIZE, sizeof(unsigned char));


    printf("index: %d\n", index);
    for (j =0 ; j < M ; j++)
    {
        m[j] = rand()%256;
    }

    
    crypto_sign_keypair(pk, sk);

    crypto_sign(sm, &smlen, m, mlen, sk);

    puts("sign");
    for (i = 0 ; i < N ; i++)
    {
        printf("%d ", sm[i]);
    }
    puts("");
    puts("msg");
    for (i = 0 ; i < M ; i++)
    {
        printf("%d ", m[i]);
    }
    puts("");


    crypto_sign_open(ver_m, &mlen, sm, smlen, pk);

    puts("veri");
    for (i = 0 ; i < M ; i++)
    {
        printf("%d ", ver_m[i]);
    }
    puts("");

}

int main()
{
    int i;
    int l1 = 0, l2= 0, l3= 0;

    for (i = 0 ; i < MEASURE_ROUNDS ; i++) signtest1(i);
    srand(time(NULL));
 
}
