//
//  mq.h
//
//  in the project HiMQ-3 submitted by Shim, Kyung-Ah, Park, Cheol-Min, and Kim, Aeyoung on 9/29/17
//  

#ifndef GF256_H
#define GF256_H

unsigned char gf256_mul(unsigned char a, unsigned char b);

unsigned char gf256_inv(unsigned char a);

unsigned char gf256_root(unsigned char a);

#endif
