#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "api.h"
#include "sign.h"

#define MEASURE_ROUNDS 1
//#define sksize 15+15+31*15+31*15+4*14+61*14+105*14

int signtest0(void)
{
    unsigned char *sm, *m, *ver_m;
    unsigned char *skaddr, *pkaddr;
    unsigned char *S, *T, *F, *pk, *sk;
    unsigned long long t, t1, t2;
    unsigned long long ta, t1a, t2a;
    unsigned long long smlen = N, mlen = M;

    int i, j, k;

    sm = (unsigned char *)calloc(N, sizeof(unsigned char));
    m = (unsigned char *)calloc(M, sizeof(unsigned char));
    ver_m = (unsigned char *)calloc(M, sizeof(unsigned char));

    F = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));
    T = (unsigned char *)calloc(NN, sizeof(unsigned char));
    S = (unsigned char *)calloc(MM, sizeof(unsigned char));
    pk = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));
    sk = (unsigned char *)calloc(SKSIZE, sizeof(unsigned char));

    for (j =0 ; j < M ; j++)
    {
        m[j] = rand()%256;
    }

    crypto_sign_keypair(pk, sk);

    return 1;

    crypto_sign(sm, &smlen, m, mlen, sk, 0, 0, -1);


    puts("msg");
    for (i = 0 ; i < M ; i++)
    {
        printf("%d ", m[i]);
    }
    puts("");
    return (crypto_sign_open(m, &mlen, sm, smlen, pk));
}

int signtest1(int index, int *l1, int *l2, int *l3)
{
    unsigned char *sm, *m, *ver_m;
    unsigned char *skaddr, *pkaddr;
    unsigned char *S, *T, *F, *pk, *sk;
    unsigned long long smlen = N, mlen = M;

    int i, j, k;

    sm = (unsigned char *)calloc(N, sizeof(unsigned char));
    m = (unsigned char *)calloc(M, sizeof(unsigned char));
    ver_m = (unsigned char *)calloc(M, sizeof(unsigned char));

    F = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));
    T = (unsigned char *)calloc(NN, sizeof(unsigned char));
    S = (unsigned char *)calloc(MM, sizeof(unsigned char));
    pk = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));
    sk = (unsigned char *)calloc(sksize, sizeof(unsigned char));

    *l3 = *l3 - 1;

    printf("index: %d\n", index);
    for (j =0 ; j < M ; j++)
    {
        m[j] = rand()%256;
    }

    int l1s =*l1, l2s = *l2, l3s = *l3;

    
    crypto_sign_keypair(pk, sk);
    
    
    crypto_sign(sm, &smlen, m, mlen, sk, l1, l2, l3);
    
    puts("sign");
    for (i = 0 ; i < N ; i++)
    {
        printf("%d ", sm[i]);
    }
    puts("");
    puts("msg");
    for (i = 0 ; i < M ; i++)
    {
        printf("%d ", m[i]);
    }
    puts("");
    
    
    puts("veri");
    for (i = 0 ; i < M ; i++)
    {
        printf("%d ", ver_m[i]);
    }
    puts("");

    return;

    if (*l1+*l2+*l3 == l1s+l2s+l3s)
    {
        char filename[80];
        char strindex[2];
        FILE *fp;

        filename[0] = '\0';

        strcat(filename, "cases/noerrorcase/case_");
        sprintf(strindex, "%d", index);
        strcat(filename, strindex);
        strcat(filename, strindex);
        strcat(filename, ".txt");

        fp = fopen(filename, "w");

        for (i = 0 ; i < sksize ; i++)
        {
            fprintf(fp, "%d ", sk[i]);
        }
        fprintf(fp, "\n");
        for (i = 0 ; i < M ; i++)
        {
            fprintf(fp, "%d ", m[i]);
        }
    }
    printf("\nl1: %d, l2: %d, l3: %d\n", *l1, *l2, *l3);
}


int main()
{
    int i;
    int l1 = 0, l2= 0, l3= 0;

    signtest1(i, &l1,&l2, &l3);
    
    printf("\nl1: %d, l2: %d, l3: %d\n", l1, l2, l3);

    return 0;
}
