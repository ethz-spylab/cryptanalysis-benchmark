#ifndef GF256_H
#define GF256_H

unsigned char gf256_mul(unsigned char a, unsigned char b);

unsigned char gf256_inv(unsigned char a);

unsigned char gf256_root(unsigned char a);

#endif
