#ifndef MQ_H
#define MQ_H

unsigned char Mat_Gauss_Elim(unsigned char *, unsigned char *, unsigned char);

void LU_decomp(unsigned char *, unsigned char *, unsigned char *, unsigned char len);

int LU_findsol(unsigned char *, unsigned char *, unsigned char *, unsigned char, unsigned char *);

int Solution_LU(unsigned char *, unsigned char *, unsigned char *, unsigned char);

unsigned char Gauss_Sol(unsigned char *, unsigned char *, unsigned char);

int invexist(unsigned char *, int);

void TMul(unsigned char *, const unsigned char*, unsigned char *, unsigned char);

void FMul(unsigned char *, const unsigned char *, unsigned char *);


void invmult(unsigned char *, const unsigned char *, unsigned char *, unsigned char );

void mult_sf(unsigned char *, unsigned char *, unsigned char *);

void mult_ft(unsigned char *, unsigned char *, unsigned char *);
#endif
