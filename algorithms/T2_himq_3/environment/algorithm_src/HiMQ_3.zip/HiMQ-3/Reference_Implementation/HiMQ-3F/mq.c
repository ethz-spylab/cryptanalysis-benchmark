#include <stdio.h>
#include <stdlib.h>

#include "api.h"
//Get inverse matrix(Sol) of given matrix(Org) of length L_Mat
int Mat_Gauss_Elim(unsigned char* Sol, unsigned char* Org, unsigned char L_Mat)
{
    char i, j, k;
    unsigned char Mii_Inv, Mjj;
    unsigned char Copy[L_Mat*L_Mat];
    unsigned char tmp;


    for (i = 0 ; i < L_Mat ; i++)
    {
        for (j = 0 ; j < L_Mat ; j++)
        {
            Copy[i*L_Mat+j] = Org[i*L_Mat+j];
            Sol[i*L_Mat+j] = 0;
        }
    }

    //Sol: Identity Matrix at first
    for (i=0; i<L_Mat; i++)
    {
        Sol[i*L_Mat+i] = 1;
    }

    for (i=0; i<L_Mat; i++)
    {
        //sort rows of Matorg
		for (k = L_Mat-1 ; k>i ;k--)
		{
			if (Copy[(k-1) * L_Mat + i] < Copy[k*L_Mat+i])
            {
                for (j=0 ; j < L_Mat ; j++)
                {
                    tmp = Copy[k*L_Mat+j];
                    Copy[k*L_Mat+j] = Copy[(k-1)*L_Mat+j];
                    Copy[(k-1)*L_Mat+j] = tmp;

                    tmp = Sol[k*L_Mat+j];
                    Sol[k*L_Mat+j] = Sol[(k-1)*L_Mat+j];
                    Sol[(k-1)*L_Mat+j] = tmp;
                }
            }
		}

        //make pivot = 1
        if (Copy[i*L_Mat+i]!=1)
        {
            //if rank < dimension, there is no inverse
            if (Copy[i*L_Mat+i] == 0) 
            {
                printf("no inv\n");
                return 0;
            }

            Mii_Inv = gf256_inv(Copy[i*L_Mat+i]);
            for (k=0; k<L_Mat; k++)
            {
                Copy[i*L_Mat+k] = gf256_mul(Copy[i*L_Mat+k], Mii_Inv);
                Sol[i*L_Mat+k] = gf256_mul(Sol[i*L_Mat+k], Mii_Inv);
            }
        }

        //elimination
        for (j=i+1; j<L_Mat; j++)
        {
            Mjj = Copy[j*L_Mat+i];
            for (k=0; k<L_Mat; k++)
            {
                Copy[j*L_Mat+k] = Copy[j*L_Mat+k] ^ gf256_mul(Copy[i*L_Mat+k], Mjj);
                Sol[j*L_Mat+k] = Sol[j*L_Mat+k] ^ gf256_mul(Sol[i*L_Mat+k], Mjj);
            }
        }
	}
    for (i = L_Mat-1 ; i >= 0; i--)
    {
        for (j = i-1 ; j >= 0; j--)
        {
            Mjj = Copy[j*L_Mat+i];
            for (k = L_Mat-1 ; k >= 0; k--)
            {
                Copy[j*L_Mat+k] = Copy[j*L_Mat+k] ^ gf256_mul(Copy[i*L_Mat+k], Mjj);
                Sol[j*L_Mat+k] = Sol[j*L_Mat+k] ^ gf256_mul(Sol[i*L_Mat+k], Mjj);
            }
        }
    }
    return 1;
}

//Get LU = Mat for given Matrix of length len
//L: Lower triangle Matrix
//U: Upper triangle Matrix
void LU_decomp(unsigned char *Mat, unsigned char *L, unsigned char *U, unsigned char len)
{
    int i, j, k;
    unsigned char temp;

    for (i = 0 ; i < len ; i++)
    {
        temp = U[i*len+i];
        L[i*len+i] = temp;
        for(j=i; j<len; j++)
        {
            if (temp != 0)
            {
                U[i*len+j] = gf256_mul(U[i*len+j],gf256_inv(temp));
            }
        }

        for (k = i+1; k < len; ++k)
        {
            temp = U[k*len+i];
            L[k*len+i] = temp;
            for(j = i; j < len; j ++)
            {
                U[k*len+j] = U[k*len+j] ^ gf256_mul(U[i*len+j], temp);
            }
        }
    }
}

//For given two matrices L, U and vector in,
//Solve LUx = in
//L: Lower triangle matrix
//U: Upper triangle matrix
int LU_findsol(unsigned char *U, unsigned char *L, unsigned char *in, unsigned char len, unsigned char *ans)
{
    int i, j, temp;
    unsigned char temp_ans[len];


    //If the rank(L) < len or rank(U) < len
    for (i = 0 ; i < len ; i++)
    {
        if (L[i*len+i] == 0 || U[i*len+i] == 0)
        {
            printf ("No solution\n");
            return 0;
        }
    }

    //LUx = a
    //Lb = a, Ux = b
    for (i = 0 ; i < len ; i++)
    {
        j = 0;
        temp = in[i];
        for (j = 0 ; j < i; j++)
        {
            temp = temp ^ gf256_mul(L[i*len+j], temp_ans[j]);
        }
        temp_ans[i] = gf256_mul(temp, gf256_inv(L[i*len+j]));
    }

    for (i = len-1 ; i >= 0 ; i--)
    {
        j = len-1;
        temp = temp_ans[i];
        for (j = len-1 ; j > i; j--)
        {
            temp = temp ^ gf256_mul(U[i*len+j], ans[j]);
        }
        ans[i] = gf256_mul(temp, gf256_inv(U[i*len+j]));
    }

    return 1;

}

//find the solution of the given equation using LU decompositon
int Solution_LU(unsigned char* ans, unsigned char* Mat, unsigned char* in, unsigned char len)
{
    unsigned char *L, *U;
    int result;


    L = (unsigned char *)calloc(len*len, sizeof(unsigned char));
    U = (unsigned char *)calloc(len*len, sizeof(unsigned char));

    //initialize U, L
    for (int i=0; i<len; i++)
    {
        for(int j=0; j<len; j++)
        {
            L[i*len+j] =0 ;
        }

        L[i*len+i] = 1;

        for (int j=0; j<len; j++)
        {
            U[i*len+j] = Mat[i*len+j];
        }
    }

    LU_decomp(Mat, L, U, len);

    result =  LU_findsol(U, L, in, len, ans);

    free(U);
    free(L);
    return result;

}

//Solve Ax = b using Gauss Elimination
unsigned char Gauss_Sol(unsigned char* Sol, unsigned char* MatOrg, unsigned char L_Mat)
{
    char i, j, k;
    char ii, jj, kk;
    unsigned char Mii, Mii_Inv, *ptr_Mi, *ptr_Mj, Mjj;
    unsigned char *ptr_Si, *ptr_Sj;
    int tmp;


    for(i=0; i<L_Mat; i++)
    {
		for(k = L_Mat-1 ; k>i ;k--)
		{
			if(MatOrg[(k-1)*L_Mat+i] < MatOrg[k*L_Mat+i])
            {
                for(j=0 ; j <= L_Mat ; j++)
                {
                    tmp=MatOrg[k*L_Mat+j];
                    MatOrg[k*L_Mat+j]=MatOrg[(k-1)*L_Mat+j];
                    MatOrg[(k-1)*L_Mat+j]=tmp;
                }
                tmp=Sol[k];
                Sol[k]=Sol[k-1];
                Sol[k-1]=tmp;
            }
		}

        if(MatOrg[i*L_Mat+i]!=1)
        {
            Mii_Inv = gf256_inv(MatOrg[i*L_Mat+i]);
            if (Mii_Inv == 0)
                return 0;
            for(k=0; k<L_Mat; k++)
            {
                MatOrg[i*L_Mat+k]= gf256_mul(MatOrg[i*L_Mat+k], Mii_Inv);
            }
            Sol[i] = gf256_mul(Sol[i], Mii_Inv);
        }

        for(j=i+1; j<L_Mat; j++)
        {
            Mjj = MatOrg[j*L_Mat+i];
            for(k=0; k<L_Mat; k++)
            {
                MatOrg[j*L_Mat+k] = MatOrg[j*L_Mat+k] ^ gf256_mul(MatOrg[i*L_Mat+k], Mjj);
            }
            Sol[j] = Sol[j] ^ gf256_mul(Sol[i], Mjj);
        }
	}


    for(i=L_Mat-1; i>=0; i--)
    {
        for(j=i-1; j>=0; j--)
        {
            Mjj = MatOrg[j*L_Mat+i];

            for(k=L_Mat-1; k>=0; k--)
            {
                MatOrg[j*L_Mat+k] = MatOrg[j*L_Mat+k] ^ gf256_mul(MatOrg[i*L_Mat+k], Mjj);
            }
            Sol[j] = Sol[j] ^ gf256_mul(Sol[i], Mjj);
        }
    }

    return 1;
}

//For given Matrix(Mat), determine if the inverse matrix exists
int exist_inv(unsigned char *Mat, int size)
{
    unsigned char *Inv;
    int result;
    Inv = (unsigned char *)calloc(size*size, sizeof(unsigned char));


    result = Mat_Gauss_Elim(Inv, Mat, size);

    free(Inv);
    return result;
}

//For given matrix T and vextor Input, calculate T(input)
void TMul(unsigned char *T, const unsigned char *Input, unsigned char *Out_Msg, unsigned char size)
{
    int i, j;

    for (i = 0 ; i < size ; i++)
    {
        Out_Msg[i] = 0;
        for (j = 0 ; j < size ; j++)
        {
            Out_Msg[i] = Out_Msg[i] ^ gf256_mul(T[i*size+j], Input[j]);
        }
    }
}

//For given quadratic function F and vector In_Sign, calculate F(In_Sign)
void mult_fx(unsigned char *F, const unsigned char *In_Sign, unsigned char *Temp_Out)
{
    int i, j;
    int temp;
    int test;

    *Temp_Out = 0;
    for (i = 0 ; i < N ; i++)
    {
        test = 0;
        for (j = 0 ; j < N ; j++)
        {
            temp = gf256_mul(F[j*N+i], In_Sign[i]);
            temp = gf256_mul(temp, In_Sign[j]);
            *Temp_Out = temp ^ *Temp_Out;
            if (i == V2 && temp != 0)
            {
                test = test ^ temp;
            }
        }
    }
}

//Calculate F(T), for given quadratic function F and invertible matrix T
void mult_ft(unsigned char *F,unsigned char *T,unsigned char *FT)
{
    int i, j, k, l, temp;

    for (i = 0; i < N ; i++)
    {
        for (j = 0 ; j < N ; j++)
        {
            //initialize resulting matrix
            FT[i*N+j] = 0;
            for (k = 0 ; k < N ; k++)
            {
                for (l = 0 ; l < N ; l++)
                {
                    temp = gf256_mul(F[k*N+l], T[k*N+i]);
                    temp = gf256_mul(temp, T[l*N+j]);
                    FT[i*N+j] ^= temp;
                }
            }
        }
    }
}

//Calculate S(F), for given quadratic function F and invertible matrix S
void mult_sf(unsigned char *Fs, unsigned char *S, unsigned char *SF)
{
    int i, j, k, l, temp;
/*
    for (k = 0 ; k < M ; k++)
    {
        for (i = 0 ; i < M ; i++)
        {
            printf("%d ", S[k*M+i]);
        }
        puts("");
    }*/
    for (k = 0 ; k < M ; k++)
    {
        for (i = 0 ; i < N ; i++)
        {
            for (j =0 ; j < N ; j++)
            {
                //initialize resulting matrix
                SF[k*PKWID+i*N+j] = 0;
                for (l = 0 ; l < M ; l++)
                {
                    SF[k*PKWID+i*N+j] ^= gf256_mul(Fs[l*PKWID+i*N+j], S[k*M+l]);
                }
            }
        }
    }
}

//For given invertible matrix T and vector m,
//calculate T^(-1)(m)
void mult_invmatrix(unsigned char *T, const unsigned char *m, unsigned char *result, unsigned char size)
{
    int i;
    unsigned char *inv;

    inv = (unsigned char *)calloc(size*size, sizeof(unsigned char));

    Mat_Gauss_Elim(inv, T, size);
    TMul(inv, m, result, size);
}

