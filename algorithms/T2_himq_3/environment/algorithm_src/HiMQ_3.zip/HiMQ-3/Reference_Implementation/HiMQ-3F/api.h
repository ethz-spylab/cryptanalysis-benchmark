#define P 256
#define V 31
#define O1 15
#define O2 15
#define O3 14
#define N 75
#define M 44
#define V1 46
#define V2 61
#define L_MSG M
#define L_SIGN N
#define MM 44*44
#define NN 75*75

#define CRYPTO_SECRETKEYBYTES 11489
#define CRYPTO_PUBLICKEYBYTES 125400
#define CRYPTO_BYTES N
#define CRYPTO_RANDOMBYTES M


#define PKSIZE 75*75*44
#define PKWID 75*75
#define SKSIZE 75*75*44 + 44*44 + 75*75

#define del 0
#define alp 30
#define bet (465*15 + 30)
#define gam (465*15*2 + 30)
#define gam1 (465*15*2 + 30 + 46*14)
#define eps (465*15*2 + 30 + 46*14 + 61*14)
#define sktemp (465*15*2 + 30 + 46*14 + 61*14 + 105*15)
#define sksize (465*15*2 + 30 + 46*14 + 61*14 + 105*15 + 75*75 + 44*44)
#define epswid 105
#define alpwid 465
#define betwid 465
