/* gcc -o test test.c sign.c gf256.c mq.c tools.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "gf256.h"
#include "api.h"
#include "mq.h"

/*
 * F[0] ~ F[O1+O2-1] <=> delta_1, ... , delta_(O1+O2)
 * F[O1+O2] ~ F[O1+O2 + V -1] <=> alpha[1, 1] , ..., alpha[1, V]
 * ...
 * F[O1+O2 + V*(O1-1)] ~ F[O1+O2 + V*O1 -1] <=> alpha[O1, 1], ..., alpha[O1, V]
 * F[O1+O2 + V*O1] ~ F[O1+O2 + V*O1 + V*O2 -1] <=> beta[1, 1], ..., beta[O2, V]
 * F[O1+O2 + V*O1 + V*O2] ~ F[O1+O2 + V*O1 + V*O2 + V1*O3 -1] <=> gamma
 * F[O1+O2 + V*O1 + V*O2 + V1*O3] ~ F[O1+O2+ V*O1 + V*O2 + V1*O3 + V2*O3 -1] <=> gamma'
 */

/*--------------------------------------------------------
 * generate keys:sk, pk
* -------------------------------------------------------*/

void gen_diag(unsigned char *F, unsigned char *F_prototype, int j, int loop, int mod, int start, int adj)
{
    int i, k;

    for (i = 0 ; i < loop ; i++)
    {
        k = start + (i+j+1) % mod;
        F_prototype[i*N+k] = rand()%255 + 1;
        F[loop*(j-adj) + i] = F_prototype[i*N+k];
    }
}

//generate Layer 1(F1, ..., FO1), Layer2(FO1+1, ..., FO1+O2)
void gen_delta(unsigned char *F, unsigned char *F_prototype, int j)
{
    int i, k, mod1, mod2, start1, start2, adj;
    int coeff_start;

    if (j < O1)
    {
        mod1 = V;
        mod2 = O1;
        start1 = 0;
        start2 = V;
        adj = 0;
        coeff_start = alp;
    }
    else
    {
        mod1 = O1;
        mod2 = O2;
        start1 = V;
        start2 = V1;
        adj = O1;
        coeff_start = bet;
    }

    //generate sequence of coefficients delta
    k = (j-adj+1) % mod2;
    F_prototype[(start2+j-adj)*N+start2+k] = rand()%255 + 1;
    F[j] = F_prototype[(start2+j-adj)*N+start2+k];

}

void gen_layer1(unsigned char *F, unsigned char *F_prototype, int j)
{
    int i, k, start;
    int count = 0;
    for (i = 1 ; i < V ; i++)
    {
        start = (i*(i-1))/2;
        for (k = 0 ; k < i ; k++)
        {
            count++;
            F_prototype[i*N+k] = rand()%255 + 1;
            F[alp+j*alpwid+start+k] = F_prototype[i*N+k];
        }
    }

    gen_delta(F, F_prototype, j);

}

void gen_layer2(unsigned char *F, unsigned char *F_prototype, int j)
{
    int i, k, ii;
    int count = 0;

    for (i = 0 ; i < O1 ; i++)
    {
        for (k = 0 ; k < V ; k++)
        {
            count++;
            F_prototype[(i+V)*N+k] = rand()%255 + 1;
            F[bet + (j-O1)*betwid + i*V + k] = F_prototype[(i+V)*N+k];
        }
    }

    gen_delta(F, F_prototype, j);
}

//generate Layer3(FO1+O2+1, ..., FO1+O2+O3)
void gen_layer3(unsigned char *F, unsigned char *F_prototype, int j)
{
    int i, k;
    int ii, kk, temp;
    int count = 0;

    //generate sequence of coefficients gamma
    gen_diag(F+gam, F_prototype, j, V1, O2, V1, O1+O2);

    //generate sequence of coefficients gamma'
    gen_diag(F+gam1, F_prototype, j, V2, O3, V2, O1+O2);

    //generate sequence of coefficients epsilon
    for (i = V+1 ; i < V1 ; i++)
    {
        ii = i -V-1;
        temp = (ii * (ii+1)) / 2;
        for (k = V ; k <= i-1 ; k++)
        {
            count++;
            kk = k - V;
            F_prototype[i*N+k] = rand() % 255 + 1;
            F[eps + epswid * (j-O1-O2) + temp + kk] = F_prototype[i*N+k];
        }
    }
}

//generate invertible matrix of given size
void gen_lin(unsigned char *T, int size)
{
    int i, j, loop = 1;

    while (loop)
    {
        for (i = 0 ; i < size ; i++)
        {
            for (j = 0 ; j < size ; j++)
            {
                if (i == j) T[i*size+j] = 1;
                else T[i*size+j] = 0;
                T[i*size+j] = random() % 256;
            }
        }
       loop = !(exist_inv(T, size));
    }
}


//generate keypair
void crypto_sign_keypair(unsigned char *pk, unsigned char *sk)
{
    unsigned char *S, *T, *F;
    unsigned char *F_prototype;
    unsigned char *temp;

    temp = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));
    F_prototype = (unsigned char *)calloc(PKSIZE, sizeof(unsigned char));

    srand(time(NULL));

    S = sk;
    T = sk + MM;
    F = sk + MM + NN;

    //generate F
    for (int i = 0 ; i < O1 ; i++)
    {
        gen_layer1(F, F_prototype+i*PKWID, i);
    }
    int count = 0;
    int cnt2 = 0;
    for (int i = O1 ; i < O1+O2 ; i++)
    {
        gen_layer2(F, F_prototype+i*PKWID, i);
    }
    for (int i = O1+O2 ; i < M ; i++)
    {
        gen_layer3(F, F_prototype+i*PKWID, i);
    }


    //generate S, T
    gen_lin(S, M);
    gen_lin(T, N);

    //generate publickey
    mult_sf(F_prototype, S, temp);

    for (int i = 0 ; i < M ; i++)
    {
        mult_ft(temp+i*PKWID, T, pk+(i*PKWID));
    }

    free(temp);
    return;
}

/*--------------------------------------------------------
 * sign
 * -------------------------------------------------------*/

//diagonal elements
unsigned char multadd_cxx(unsigned char *yy, unsigned char *coef, const unsigned char *list_xi, int index, int j)
{
    int i, k;
    unsigned char result, temp;
    int start, mod, loop = V;

    if (index == 1)
    {
        start = 0;
        mod = V;
    }
    else if (index == 2)
    {
        start = V;
        mod = O1;
    }
    else if (index == 3)
    {
        start = V1;
        mod = O2;
        loop = V1;
    }

    *yy = 0;
    for (i = 0 ; i < loop ; i++)
    {
        k = start + (i+j+1) % mod;
        temp = gf256_mul(list_xi[i], list_xi[k]);
        temp = gf256_mul(temp, coef[loop*(j) + i]);
        *yy = *yy ^ temp;
    }
}

unsigned char multadd_lowertriangle(unsigned char *F, unsigned char *sm, int start, int end)
{
    int i, j;
    int ii, jj;
    int t;
    unsigned char temp, result = 0, count = 0;

    for (i = start+1 ; i < end ; i++)
    {
        t = ((i-start)*(i-1-start))/2;
        for (j = start ; j < i ; j++)
        {
            count++;
            jj = j - start;
            temp = gf256_mul(F[t+jj], sm[i]);
            temp = gf256_mul(temp, sm[j]);
            result = temp ^ result;
        }
    }
    return result;
}

unsigned char multadd_square(unsigned char *F, unsigned char *sm)
{
    int i, j;
    unsigned char temp, result;

    result = 0;
    for (i = 0 ; i < O1 ; i++)
    {
        for (j = 0 ; j < V ; j++)
        {
            temp = gf256_mul(F[V*(i)+j], sm[i+V]);
            temp = gf256_mul(temp, sm[j]);
            result = result ^ temp;
        }
    }

    return result;
}

//Layer 1, 2
int sign_layer12(unsigned char *sm, const unsigned char *m, int index, unsigned char *F)
{
    unsigned char temp, yy;
    unsigned char all = 1, even = 1;
    unsigned char *delta = F;
    int known, numfun, start, coeff_st;
    int j;

    if (index == 1)
    {
        known = V;
        numfun = O1;
        start = 0;
        for (j = 0 ; j < known ; j++)
        {
            sm[j] = rand()%256;
        }
        coeff_st = alp;
    }
    else if (index == 2)
    {
        known = V1;
        numfun = O2;
        start = O1;
        coeff_st = bet;
    }

    unsigned char temp_ans[numfun];

    //exclude diagonal element
    for (j = start ; j < start + numfun ; j++)
    {
        if (index == 1)
        {
            yy = multadd_lowertriangle(F+alp+alpwid*(j-start), sm, 0, V);
        }
        else
        {
            yy = multadd_square(F+bet+betwid*(j-O1), sm);
        }
        temp =  m[j] ^ yy;
        temp_ans[j] = gf256_mul(temp, gf256_inv(delta[j]));
        //if cannot get answer, return 0
        if (temp_ans[j] == 0)
        {
            return 0;
        }
    }

    for (j = 0 ; j < numfun ; j++)
    {
        all = gf256_mul(all, temp_ans[j+start]);
        if (j%2 == 1)
        {
            even = gf256_mul(even, temp_ans[j+start]);
        }
    }

    all = gf256_root(all);
    temp = gf256_mul(all, gf256_inv(even));

    //find x_v+1
    sm[known] = temp;
    sm[known+numfun-1] = gf256_mul(gf256_inv(sm[known]), temp_ans[start+numfun-1]);

    for (j = numfun-2 ; j > 0 ; j--)
    {
        sm[known+j] =gf256_mul(gf256_inv(sm[known+j+1]), temp_ans[start+j]);
    }

    return 1;

}


//generate sign for layer 3
int sign_layer3(unsigned char *sm, const unsigned char *m, unsigned char *F)
{
    unsigned char *L;
    int i, j, k, l;
    unsigned char temp, yy;
    unsigned char temp_ans[N];
    unsigned char temp2[O3];
    unsigned char list_xj[O2];
    unsigned char *gamma1 = F+gam1;

    //initialize L
    L = (unsigned char *)calloc(O3*O3, sizeof(unsigned char));

    for (i =0 ; i < O3 ; i++)
    {
        for (j = 0 ; j < O3; j++)
        {
            L[i*O3+j] = 0;
        }
    }

    //exclude known elements
    for (j = O1+O2 ; j < M ; j++)
    {
        multadd_cxx(&yy, F+gam, sm, 3, j-O1-O2);
        temp_ans[j-O1-O2] = m[j] ^ yy;
        temp_ans[j-O1-O2] ^= multadd_lowertriangle(F+eps+(j-O1-O2)*epswid, sm, V, V1);
    }

    //get linear equations from F
    for (j = 0 ; j < O3 ; j++)
    {
        for (i = 0 ; i < V2 ; i++)
        {
            k = (i + O1+O2+j +1) % O3 + V2;
            l = k - (V2);

            temp = gf256_mul(sm[i], gamma1[j*V2+i]);
            L[j*O3+l] = L[j*O3+l] ^ temp;
        }
    }

    //find solution for above linear equations
    //if there is no unique solution, return 0
    if (Solution_LU(temp2, L, temp_ans, O3) == 0)
    {
        return 0;
    }

    //attach solution to known signs
    for (i = 0 ; i < O3 ; i++)
    {
        sm[V2+i] = temp2[i];
    }

    free(L);
    return 1;
}

void crypto_sign(unsigned char *sm, unsigned long long *smlen, const unsigned char *m, unsigned long long mlen, const unsigned char *sk)
{

    unsigned char *temp, *S, *T, *F;
    int flag = 1;

    temp = (unsigned char *)calloc(N, sizeof(unsigned char));

    srand(time(NULL));

    S = sk;
    T = sk + MM;
    F = sk + MM + NN;

    //Sinv(m)
    mult_invmatrix(S, m, temp, mlen);

    while (flag)
    {
        /*----------------------------------------*/
        //L1:
        //F1-FO1
        //k-th fx: F_k(x) = Phi_k(x) + delta_k * x_V+k * x_V+k+1
        //Phi_k(x) = sigma(i:1-V) [ alpha * xi * x_1+(i+j-1)%V ]
        /*----------------------------------------*/
        if (sign_layer12(sm, temp, 1, F) == 0)
        {
            printf("layer1\n");
            continue;
        }
        /*----------------------------------------*/
        //L2:
        //FO1+1-FO1+O2
        //F_k(x)  = Psi_k(x) + delta_k * x_V1+k * x_V1+k+1
        //Phi_k(x) = sigma(i:1-V) [ beta * xi * x_V+(i+j-1)%O1 ]
        /*----------------------------------------*/
        if (sign_layer12(sm, temp, 2, F) == 0)
        {
            puts("layer2");
            continue;
        }

        /*----------------------------------------*/
        //L3:
        //Pi(x) with gamma rl, rll in L3
        /*----------------------------------------*/
        flag = 1- sign_layer3(sm, temp, F);
    }

    //Tinv(sign)
    mult_invmatrix(T, sm, temp, *smlen);

    for (int i = 0 ; i < N ; i++)
    {
        sm[i] = temp[i];
    }
}

/*--------------------------------------------------------
 * verify
 * -------------------------------------------------------*/
int crypto_sign_open(const unsigned char *m, unsigned long long *mlen, const unsigned char *sm, unsigned long long smlen, const unsigned char *pk)
{
    int i, j;
    int flag = 1;

    for (i = 0 ; i < *mlen ; i++)
    {
        mult_fx(pk+(i*PKWID), sm, &m[i]);
    }
}

