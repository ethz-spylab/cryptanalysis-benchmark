/* Copyright (c) 2017 ISARA Corporation. All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * Neither the name of the ISARA Corporation nor the names of its
 * contributors may be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * (COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// Note: This implementation is provided for use in an ephemeral context so it
// is not constant time. Without further analysis this implementation should not
// be used with static keys or with a threat model which includes differential
// power analysis.

#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <libkeccak.a.headers/SP800-185.h>

#include "crypto_kem.h"

#include "api.h"
#include "internal.h"
#include "randombytes.h"

// ----------------------------------------------------------------------------
// Byte Functions
// ----------------------------------------------------------------------------

static void
print_bytes(uint8_t* x, size_t length)
{
    for (int i = 0; i < length; i++) {
        printf("%02X", x[i]);
    }
}

// Counts the number of bits set to one in a uint8_t.
static uint8_t
popcnt8(uint8_t x)
{
    x = x - ((x >> 1) & UINT8_C(0x55));
    x = (x & UINT8_C(0x33)) + ((x >> 2) & UINT8_C(0x33));
    x = (x + (x >> 4)) & UINT8_C(0x0F);

    return x & UINT8_C(15);
}

// ----------------------------------------------------------------------------
// Bit Array Functions
//
// For consistency imagine the byte numbering starting at zero on the right.
// ----------------------------------------------------------------------------

// Sets a specific bit in a bit array by index.
static void
set_bit(uint8_t* array, size_t index, bool value)
{
    array[index / 8] &= ~(UINT8_C(1) << index % 8);
    array[index / 8] |= ((uint8_t)value << index % 8);
}

// Gets a specific bit in a bit array by index.
static bool
get_bit(const uint8_t* array, size_t index)
{
    return (array[index / 8] >> index % 8) & UINT8_C(1);
}

// Shift up. i.e. 1010 -> 0100
static void
shift_up_one_bit(uint8_t* x)
{
    for (size_t i = MDPC_R_BYTES - 1; i > 0; i--) {
        x[i] = (x[i] << 1) | (x[i - 1] >> 7);
    }
    x[0] <<= 1;
    x[MDPC_R_BYTES - 1] &= MDPC_RMASK;
}

// Rotate up. i.e. 1010 -> 0101
static void
rotate_up_one_bit(uint8_t* x)
{
    bool carry_bit = get_bit(x, MDPC_R - 1);
    shift_up_one_bit(x);
    set_bit(x, 0, carry_bit);
}

// Compute the bitwise xor of two byte arrays of length n.
static void
xor_n(uint8_t* a, const uint8_t* b, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        a[i] ^= b[i];
    }
}

// Shift up. i.e. 1010 -> 0101
static void
shift_down_one_bit(uint8_t* x)
{
    for (size_t i = 0; i < MDPC_R_BYTES - 1; i++) {
        x[i] = (x[i] >> 1) | (x[i + 1] << 7);
    }
    x[MDPC_R_BYTES - 1] >>= 1;
}

// Rotate Down. i.e. 0101 -> 1010
static void
rotate_down_one_bit(uint8_t* x)
{
    bool carry_bit = get_bit(x, 0);
    shift_down_one_bit(x);
    set_bit(x, MDPC_R - 1, carry_bit);
}

// Flip a specific bit in a bit array by index.
// i.e. set it to the value of itself xor 1
static void
flip_bit(uint8_t* x, size_t index)
{
    x[index / 8] ^= UINT8_C(1) << index % 8;
}

// Checks if all bits are set to zero.
static bool
is_zero(const uint8_t* x)
{
    uint8_t ret = 0;
    for (size_t i = 0; i < MDPC_R_BYTES; ++i) {
        ret |= x[i];
    }

    return ret == 0;
}

// Set the input array to it's transpose as a circulant matrix.
static void
transpose(uint8_t* x)
{
    for (size_t i = 0; i < MDPC_R / 2; ++i) {
        const bool left_bit = get_bit(x, i);
        const bool right_bit = get_bit(x, MDPC_R - (i + 1));

        set_bit(x, i, right_bit);
        set_bit(x, MDPC_R - (i + 1), left_bit);
    }

    rotate_up_one_bit(x);
}

// Compute the number of bits set to one in `a xor b`.
static uint16_t
get_conjunctive_weight(const uint8_t* a, const uint8_t* b)
{
    uint16_t weight = 0;
    for (size_t i = 0; i < MDPC_R_BYTES; i++) {
        weight += popcnt8(a[i] & b[i]);
    }

    return weight;
}

// Multiplication: matrix * matrix
static void
multiply(const uint8_t* a, uint8_t* b, uint8_t* r)
{
    for (size_t i = 0; i < MDPC_R; i++) {
        const bool dot_parity = get_conjunctive_weight(a, b) % 2 == 1;
        set_bit(r, i, dot_parity);
        rotate_down_one_bit(b);
    }
}

// Multiplication: matrix * vector
static void
multiply_vec(uint8_t* m, const uint8_t* v, uint8_t* r)
{
    for (size_t i = 0; i < MDPC_R; i++) {
        const bool dot_parity = get_conjunctive_weight(v, m) % 2 == 1;
        set_bit(r, i, dot_parity);
        rotate_up_one_bit(m);
    }
}

// Set `dest` to the r bit subarray starting at the bit indicated by `start`.
static void
get_subarray(uint8_t* dest, const uint8_t* src, size_t start)
{
    const size_t shift = start % 8;
    const size_t unshift = 8 - shift;

    const size_t skip = start / 8;

    for (size_t i = 0; i < MDPC_R_BYTES - 1; ++i) {
        dest[i] = (src[skip + i] >> shift) | (src[skip + i + 1] << unshift);
    }

    dest[MDPC_R_BYTES - 1] = (src[skip + MDPC_R_BYTES - 1] >> shift) |
                             (src[skip + MDPC_R_BYTES] << unshift);
    dest[MDPC_R_BYTES - 1] &= MDPC_RMASK;
}

// Concatenate two r bit arrays.
static void
concat_bits(uint8_t* dest, const uint8_t* head, const uint8_t* tail)
{
    memcpy(dest, head, MDPC_R_BYTES);

    const size_t shift = MDPC_R % 8;
    const size_t unshift = 8 - shift;

    dest[MDPC_R_BYTES - 1] &= MDPC_RMASK;

    for (size_t i = 0; i < MDPC_R_BYTES - 1; ++i) {
        dest[MDPC_R_BYTES + i - 1] |= (tail[i] << shift) & ~MDPC_RMASK;
        dest[MDPC_R_BYTES + i] = (tail[i] >> unshift) & MDPC_RMASK;
    }

    dest[2 * MDPC_R_BYTES - 2] |=
      (tail[MDPC_R_BYTES - 1] << shift) & ~MDPC_RMASK;
    dest[2 * MDPC_R_BYTES - 1] =
      (tail[MDPC_R_BYTES - 1] >> unshift) & MDPC_RMASK;
}

// Computes the number of bits set to one.
static size_t
get_weight(uint8_t* x, size_t n)
{
    size_t weight = 0;
    for (size_t i = 0; i < n; ++i) {
        weight += popcnt8(x[i]);
    }

    return weight;
}

// Compute the sparse representation of the input `dense` and store it in
// `sparse`.
//
// Note: `dense_to_sparse` and `sparse_to_dense` are needed since the private
// key is
// stored as a sparse vector.
static void
dense_to_sparse(const uint8_t* dense, uint16_t* sparse)
{
    int pos = 0;
    for (int i = 0; i < MDPC_R; i++) {
        if (get_bit(dense, i)) {
            sparse[pos++] = i;
        }
    }
}

// Compute the dense representation of the input `sparse` and store it in
// `dense`.
//
// Note: `dense_to_sparse` and `sparse_to_dense` are needed since the private
// key is
// stored as a sparse vector.
static void
sparse_to_dense(const uint16_t* sparse, uint8_t* dense)
{
    for (int i = 0; i < MDPC_WI; i++) {
        set_bit(dense, sparse[i], 1);
    }
}

// ----------------------------------------------------------------------------
// Keygen Functions
// ----------------------------------------------------------------------------

// Generate a value uniformly within a range with rejection sampling using
// entropy.
static uint16_t
uniform_int(uint16_t bound)
{
    if (bound == 0) {
        return 0;
    }

    const uint16_t threshold = (UINT16_MAX / bound) * bound;
    uint16_t rand_sample = 0;

    while (true) {
        randombytes((unsigned char*)&rand_sample, sizeof(rand_sample));
        if (rand_sample < threshold) {
            return rand_sample % bound;
        }
    }
}

// Generate a value uniformly within a range with rejection sampling using an
// input PRF.
static uint16_t
uniform_int_prf(cSHAKE_Instance* cs_state, uint16_t bound)
{
    if (bound == 0) {
        return 0;
    }

    const uint16_t threshold = (UINT16_MAX / bound) * bound;
    uint16_t rand_sample = 0;

    while (true) {
        cSHAKE256_Squeeze(
          cs_state, (unsigned char*)&rand_sample, 8 * sizeof(rand_sample));

        if (rand_sample < threshold) {
            return rand_sample % bound;
        }
    }
}

// Generate an error vector from a seed.
static void
gen_ev(uint8_t* ev, uint8_t* seed)
{
    // e <- v(s)
    cSHAKE_Instance cs_state;
    cSHAKE256_Initialize(
      &cs_state, 0, (const unsigned char*)"", 0, (const unsigned char*)"e", 1);
    cSHAKE256_Update(&cs_state, seed, 8 * MDPC_R_BYTES);
    cSHAKE256_Final(&cs_state, NULL);
    // Durstenfeld inside-out shuffle.
    for (int i = 0; i < MDPC_N; i++) {
        const uint16_t j = uniform_int_prf(&cs_state, i);
        set_bit(ev, i, get_bit(ev, j));
        set_bit(ev, j, i < MDPC_T);
    }
}

// Generate an array with weight `weight` uniformly at random from entropy.
static void
uniform_weight_array(uint8_t* array, int weight, size_t size_bits)
{
    // Durstenfeld inside-out shuffle.
    for (int i = 0; i < size_bits; i++) {
        const uint16_t j = uniform_int(i);
        set_bit(array, i, get_bit(array, j));
        set_bit(array, j, i < weight);
    }
}

// Zero stripping step of the inversion algorithm below.
static void
zero_strip(uint8_t* operand,
           uint8_t* x,
           uint8_t* y,
           uint8_t* tmp1,
           uint8_t* tmp2)
{
    while (get_bit(operand, 0) == 0) {
        while (get_bit(tmp1, 0) == 0 && get_bit(tmp2, 0) == 0 &&
               get_bit(operand, 0) == 0) {
            shift_down_one_bit(tmp1);
            shift_down_one_bit(tmp2);
            shift_down_one_bit(operand);
        }
        if (get_bit(operand, 0) == 0) {
            shift_down_one_bit(operand);

            xor_n(tmp1, y, MDPC_R_BYTES);
            shift_down_one_bit(tmp1);

            xor_n(tmp2, x, MDPC_R_BYTES);
            shift_down_one_bit(tmp2);
        }
    }
}

// Comparison function for the inversion algorithm below.
static int
compare(const uint8_t* a, const uint8_t* b)
{
    for (int i = MDPC_R_BYTES - 1; i >= 0; --i) {
        if (a[i] > b[i]) {
            return 1;
        } else if (a[i] < b[i]) {
            return -1;
        }
    }

    return 0;
}

// Polynomial inversion using algorithm 14.61 "binary extended gcd algorithm"
// from "Handbook of Applied Cryptography" (Menezes, Oorschot, Vanstone).
static void
invert(uint8_t* poly_inverse, const uint8_t* poly)
{
    uint8_t y[MDPC_R_BYTES] = { 0 };
    uint8_t v[MDPC_R_BYTES] = { 0 };
    uint8_t tmp_A[MDPC_R_BYTES] = { 0 };
    uint8_t tmp_B[MDPC_R_BYTES] = { 0 };
    uint8_t tmp_C[MDPC_R_BYTES] = { 0 };
    uint8_t tmp_D[MDPC_R_BYTES] = { 0 };

    uint8_t x[MDPC_R_BYTES];
    memcpy(x, poly, MDPC_R_BYTES);

    uint8_t u[MDPC_R_BYTES];
    memcpy(u, poly, MDPC_R_BYTES);

    // Modulus: x^n + 1
    set_bit(y, 0, 1);
    set_bit(y, MDPC_R, 1);
    set_bit(v, 0, 1);
    set_bit(v, MDPC_R, 1);

    set_bit(tmp_A, 0, 1);
    set_bit(tmp_D, 0, 1);

    while (!is_zero(u)) {
        zero_strip(u, x, y, tmp_A, tmp_B);
        zero_strip(v, x, y, tmp_C, tmp_D);

        if (compare(u, v) >= 0) {
            xor_n(u, v, MDPC_R_BYTES);
            xor_n(tmp_A, tmp_C, MDPC_R_BYTES);
            xor_n(tmp_B, tmp_D, MDPC_R_BYTES);
        } else {
            xor_n(v, u, MDPC_R_BYTES);
            xor_n(tmp_C, tmp_A, MDPC_R_BYTES);
            xor_n(tmp_D, tmp_B, MDPC_R_BYTES);
        }
    }

    // MDPC_Test that v == 1.
    set_bit(v, 0, 0);
    if (!is_zero(v)) {
        printf("ERROR: Inversion failed.\n");
        assert(false);
    }

    memcpy(poly_inverse, tmp_C, MDPC_R_BYTES);
}

// ----------------------------------------------------------------------------
// Decryption Functions
// ----------------------------------------------------------------------------

static void
compute_syndrome(uint8_t* synd, const uint8_t* c, uint8_t* h)
{
    for (uint32_t i = 0; i < MDPC_N0; i++) {

        uint8_t c_i[MDPC_R_BYTES] = { 0 };
        get_subarray(c_i, c, i * MDPC_R);

        uint8_t prod[MDPC_R_BYTES] = { 0 };
        multiply_vec(h + i * MDPC_R_BYTES, c_i, prod);

        xor_n(synd, prod, MDPC_R_BYTES);
    }
}

// Performs one iteration of the bit flipping step of the decoder at some
// threshold.
static void
perform_bit_flipping(uint8_t* ev,
                     uint8_t* synd,
                     uint8_t* h,
                     size_t max_correlation)
{
    for (size_t i = 0; i < MDPC_N0; i++) {
        for (size_t j = 0; j < MDPC_R; j++) {
            const uint64_t correlation =
              get_conjunctive_weight(h + i * MDPC_R_BYTES, synd);
            if (correlation >= max_correlation) {
                flip_bit(ev, i * MDPC_R + j);
                xor_n(synd, h + i * MDPC_R_BYTES, MDPC_R_BYTES);
            }
            rotate_up_one_bit(h + i * MDPC_R_BYTES);
        }
    }
}

// Attempts to decode a message.
static void
decode(uint8_t* m, uint8_t* ev, const uint8_t* c, uint8_t* h)
{
    uint8_t synd[MDPC_R_BYTES] = { 0 };

    compute_syndrome(synd, c, h);

    for (size_t i = 0; i < MDPC_N0; i++) {
        transpose(&h[i * MDPC_R_BYTES]);
    }

    for (size_t i = 0; i < sizeof(thresholds) / sizeof(*thresholds); i++) {
        perform_bit_flipping(ev, synd, h, thresholds[i]);
    }

    if (is_zero(synd) == true) {
        get_subarray(m, c, 0);
        xor_n(m, ev, MDPC_R_BYTES);
        m[MDPC_R_BYTES - 1] &= MDPC_RMASK;
    }
}

// Attempt to decode a message and check for success. If decoding failed return
// 1. If it succeeded return 0.
static int
dec(uint8_t* m, uint8_t* ev, const uint8_t* c, uint8_t* h)
{
    decode(m, ev, c, h);
    if (get_weight(ev, 2 * MDPC_R_BYTES) != MDPC_T) {
        // Decoding error.
        return 1;
    }
    return 0;
}

// ----------------------------------------------------------------------------
// Encryption Functions
// ----------------------------------------------------------------------------

static void
compute_ciphertext(uint8_t* c, const uint8_t* m, uint8_t* g)
{
    for (size_t i = 0; i < MDPC_R; i++) {
        const uint64_t mask = UINT8_C(0xFF) * get_bit(m, i);
        for (size_t j = 0; j < MDPC_R_BYTES; j++) {
            c[j] = (mask & g[j]) ^ c[j];
        }
        rotate_up_one_bit(g);
    }
}

static void
encrypt_with_err(uint8_t* c,
                 const uint8_t* m,
                 const uint8_t* ev,
                 const uint8_t* pk)
{
    uint8_t mG[MDPC_R_BYTES] = { 0 };
    uint8_t g[MDPC_R_BYTES] = { 0 };

    memcpy(g, pk, MDPC_R_BYTES);
    compute_ciphertext(mG, m, g);
    concat_bits(c, m, mG);
    xor_n(c, ev, 2 * MDPC_R_BYTES);
}

// ----------------------------------------------------------------------------
// API Functions
// ----------------------------------------------------------------------------

int
crypto_kem_keypair(unsigned char* pk, unsigned char* sk)
{
    uint8_t sk_temp[2 * MDPC_R_BYTES] = { 0 };

    memset(pk, 0, MDPC_R_BYTES);

    for (int i = 0; i < MDPC_N0; i++) {
        uniform_weight_array(
          sk_temp + i * MDPC_R_BYTES, MDPC_W / MDPC_N0, MDPC_R);
    }

    uint8_t inverse[MDPC_R_BYTES] = { 0 };

    invert(inverse, sk_temp + MDPC_R_BYTES);
    transpose(inverse);
    for (int i = 0; i < MDPC_N0 - 1; i++) {
        multiply(inverse, sk_temp + i * MDPC_R_BYTES, pk + i * MDPC_R_BYTES);
        transpose(pk + i * MDPC_R_BYTES);
    }

    memset(sk, 0, 2 * MDPC_W);
    for (size_t i = 0; i < MDPC_N0; i++) {
        dense_to_sparse(sk_temp + i * MDPC_R_BYTES,
                        (uint16_t*)sk + i * MDPC_WI);
    }

    return 0;
}

int
crypto_kem_enc(unsigned char* cipher,
               unsigned char* key,
               const unsigned char* pk)
{
    uint8_t e[MDPC_N0 * MDPC_R_BYTES] = { 0 };
    uint8_t s[MDPC_R_BYTES] = { 0 };
    uint8_t x[MDPC_R_BYTES] = { 0 };
    uint8_t y[MDPC_R_BYTES] = { 0 };
    uint8_t c1[MDPC_N0 * MDPC_R_BYTES] = { 0 };
    uint8_t c[C2_SIZE + SHARED_KEY_SIZE] = { 0 };

    randombytes(s, sizeof(s));
    s[MDPC_R_BYTES - 1] &= MDPC_RMASK;

    // c <- kdf(s)
    cSHAKE256(s,
              MDPC_R,
              c,
              8 * sizeof(c),
              (const uint8_t*)"",
              0,
              (const uint8_t*)"c",
              1);

    // e <- v(s)
    gen_ev(e, s);

#ifdef KAT
    printf("Intermediate Error Vector = ");
    print_bytes(e, MDPC_N0 * MDPC_R_BYTES);
    printf("\n");
#endif

    // y <- KDF(e)
    cSHAKE256(e,
              MDPC_N0 * MDPC_R,
              y,
              8 * sizeof(y),
              (const uint8_t*)"",
              0,
              (const uint8_t*)"y",
              1);

    // x <- s + y
    for (size_t i = 0; i < sizeof(s); i++) {
        x[i] = s[i] ^ y[i];
    }
    x[MDPC_R_BYTES - 1] &= MDPC_RMASK;

    // C1 <- ENCRYPT(x,e,pk)
    encrypt_with_err(c1, x, e, pk);

    // key <- c[0:n]
    memcpy(key, c + C2_SIZE, SHARED_KEY_SIZE);

    // cipher <- (c1,c2)
    memcpy(cipher, c1, sizeof(c1));
    memcpy(cipher + sizeof(c1), c, C2_SIZE);

    return 0;
}

// Will return 1 in the case of a decryption failure. 0 otherwise.
int
crypto_kem_dec(unsigned char* k,
               const unsigned char* ct,
               const unsigned char* sk_in)
{
    uint8_t e[2 * MDPC_R_BYTES] = { 0 };
    uint8_t e_p[2 * MDPC_R_BYTES] = { 0 };
    uint8_t s[MDPC_R_BYTES] = { 0 };
    uint8_t x[MDPC_R_BYTES] = { 0 };
    uint8_t y[MDPC_R_BYTES] = { 0 };
    uint8_t c1[2 * MDPC_R_BYTES] = { 0 };
    uint8_t c_p[C2_SIZE + SHARED_KEY_SIZE] = { 0 };
    uint8_t sk[2 * MDPC_R_BYTES] = { 0 };

    for (size_t i = 0; i < MDPC_N0; i++) {
        sparse_to_dense((uint16_t*)sk_in + i * MDPC_WI, sk + i * MDPC_R_BYTES);
    }

    memcpy(c1, ct, sizeof(c1));

    // (x,e) <- DECRYPT(C1,sk)
    int decrypt_error = dec(x, e, c1, sk);

    // y <- KDF(e)
    cSHAKE256(e,
              MDPC_N0 * MDPC_R,
              y,
              8 * sizeof(y),
              (const uint8_t*)"",
              0,
              (const uint8_t*)"y",
              1);

    // s <- x + y
    for (size_t i = 0; i < sizeof(s); i++) {
        s[i] = x[i] ^ y[i];
    }
    s[MDPC_R_BYTES - 1] &= MDPC_RMASK;

    // e_p <- v(s)
    gen_ev(e_p, s);

    // c <- kdf(s)
    cSHAKE256(s,
              MDPC_R,
              c_p,
              8 * sizeof(c_p),
              (const uint8_t*)"",
              0,
              (const uint8_t*)"c",
              1);

    int vectors_diff = 0;
    for (size_t i = 0; i < sizeof(e); i++) {
        vectors_diff |= e[i] ^ e_p[i];
    }

    int c2_diff = 0;
    for (size_t i = 0; i < C2_SIZE; i++) {
        c2_diff |= (ct + sizeof(c1))[i] ^ c_p[i];
    }

    memcpy(k, c_p + C2_SIZE, SHARED_KEY_SIZE);

    uint8_t failure = vectors_diff | c2_diff | decrypt_error;
    if (failure) {
        return 1;
    } else {
        return 0;
    }
}
