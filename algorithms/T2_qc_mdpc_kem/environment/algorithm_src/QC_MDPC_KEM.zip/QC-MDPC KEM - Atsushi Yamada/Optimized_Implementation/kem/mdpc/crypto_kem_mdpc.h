#ifndef crypto_kem_mdpc_H
#define crypto_kem_mdpc_H

/* Copyright (c) 2017 ISARA Corporation. All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * Neither the name of the ISARA Corporation nor the names of its
 * contributors may be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * (COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#define crypto_kem_mdpc_portable_SECRETKEYBYTES 548
#define crypto_kem_mdpc_portable_PUBLICKEYBYTES 4097
#define crypto_kem_mdpc_portable_CIPHERTEXTBYTES 8226
#define crypto_kem_mdpc_portable_BYTES 32

int
crypto_kem_keypair(unsigned char* pk, unsigned char* sk);

int
crypto_kem_enc(unsigned char* cipher,
               unsigned char* key,
               const unsigned char* pk);

int
crypto_kem_dec(unsigned char* k,
               const unsigned char* ct,
               const unsigned char* sk);
 
#ifdef __cplusplus
extern "C" {
#endif
extern int crypto_kem_mdpc_portable_keypair(unsigned char *,unsigned char *);
extern int crypto_kem_mdpc_portable_enc(unsigned char *,unsigned char *,const unsigned char *);
extern int crypto_kem_mdpc_portable_dec(unsigned char *,const unsigned char *,const unsigned char *);
#ifdef __cplusplus
}
#endif

#define crypto_kem_mdpc_keypair crypto_kem_mdpc_portable_keypair
#define crypto_kem_mdpc_enc crypto_kem_mdpc_portable_enc
#define crypto_kem_mdpc_dec crypto_kem_mdpc_portable_dec
#define crypto_kem_mdpc_PUBLICKEYBYTES crypto_kem_mdpc_portable_PUBLICKEYBYTES
#define crypto_kem_mdpc_SECRETKEYBYTES crypto_kem_mdpc_portable_SECRETKEYBYTES
#define crypto_kem_mdpc_BYTES crypto_kem_mdpc_portable_BYTES
#define crypto_kem_mdpc_CIPHERTEXTBYTES crypto_kem_mdpc_portable_CIPHERTEXTBYTES

#endif
