#ifndef crypto_kem_H
#define crypto_kem_H

#include "crypto_kem_mdpc.h"

#define crypto_kem_keypair crypto_kem_mdpc_keypair
#define crypto_kem_enc crypto_kem_mdpc_enc
#define crypto_kem_dec crypto_kem_mdpc_dec
#define crypto_kem_PUBLICKEYBYTES crypto_kem_mdpc_PUBLICKEYBYTES
#define crypto_kem_SECRETKEYBYTES crypto_kem_mdpc_SECRETKEYBYTES
#define crypto_kem_BYTES crypto_kem_mdpc_BYTES
#define crypto_kem_CIPHERTEXTBYTES crypto_kem_mdpc_CIPHERTEXTBYTES
#define crypto_kem_PRIMITIVE "mdpc"

#endif
