/* Copyright (c) 2017 ISARA Corporation. All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * Neither the name of the ISARA Corporation nor the names of its
 * contributors may be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * (COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// Constants for internal use.
#ifndef MDPC_INTERNAL_H
#define MDPC_INTERNAL_H

#include <stdint.h>

#define MDPC_R 32771
#define MDPC_N0 2
#define MDPC_N (MDPC_R * MDPC_N0)
#define MDPC_W 274
#define MDPC_T 264
#define MDPC_WI (MDPC_W / MDPC_N0)

#define C2_SIZE 32
#define SHARED_KEY_SIZE 32

#define MDPC_R_BYTES (MDPC_R / 8 + 1)
#define MDPC_R_UINT64 (MDPC_R_BYTES / 8 + 1)
#define MDPC_RMASK (~(UINT8_C(0xFF) << (MDPC_R % 8)))
#define MDPC_R64MASK (~(~UINT64_C(0) << (MDPC_R % 64)))

// Decoder thresholds.
static const unsigned int thresholds[] = { 95, 85, 80, 76, 74, 73, 72, 72 };

#endif /* MDPC_INTERNAL_H */
