/* Copyright (c) 2017 ISARA Corporation. All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following
 * disclaimer in the documentation and/or other materials provided
 * with the distribution.
 * Neither the name of the ISARA Corporation nor the names of its
 * contributors may be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * (COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// Note: This implementation is provided for use in an ephemeral context so it
// is not constant time. Without further analysis this implementation should not
// be used with static keys or with a threat model which includes differential
// power analysis.
//
// Inversion during key generation and the bit flipping decoder both have
// branches.
// Additionally functions involving spare bit arrays often access memory in a
// data dependent way which could make them vulnerable to cache timing attacks.

#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <libkeccak.a.headers/SP800-185.h>

#include "crypto_kem.h"

#include "api.h"
#include "internal.h"
#include "randombytes.h"

// ----------------------------------------------------------------------------
// Byte Functions
// ----------------------------------------------------------------------------

static void
print_bytes(uint8_t* x, size_t length)
{
    for (int i = 0; i < length; i++) {
        printf("%02X", x[i]);
    }
}

static inline uint32_t
clz64(uint64_t x)
{
    x |= (x >> 1);
    x |= (x >> 2);
    x |= (x >> 4);
    x |= (x >> 8);
    x |= (x >> 16);
    x |= (x >> 32);
    x &= ~(x >> 1);

    uint32_t r = (x & UINT64_C(0xAAAAAAAAAAAAAAAA)) != 0;
    r |= (uint32_t)((x & UINT64_C(0xFFFFFFFF00000000)) != 0) << 5;
    r |= (uint32_t)((x & UINT64_C(0xFFFF0000FFFF0000)) != 0) << 4;
    r |= (uint32_t)((x & UINT64_C(0xFF00FF00FF00FF00)) != 0) << 3;
    r |= (uint32_t)((x & UINT64_C(0xF0F0F0F0F0F0F0F0)) != 0) << 2;
    r |= (uint32_t)((x & UINT64_C(0xCCCCCCCCCCCCCCCC)) != 0) << 1;

    return ~r & UINT32_C(0x3F);
}

static inline uint64_t
bitrev64(uint64_t x)
{
    uint64_t t;

    x = (x >> 32) | (x << 32);
    t = UINT64_C(0x0000FFFF0000FFFF);
    x = ((x >> 16) & t) | ((x << 16) & ~t);
    t = (t << 8) ^ t;
    x = ((x >> 8) & t) | ((x << 8) & ~t);
    t = (t << 4) ^ t;
    x = ((x >> 4) & t) | ((x << 4) & ~t);
    t = (t << 2) ^ t;
    x = ((x >> 2) & t) | ((x << 2) & ~t);
    t = (t << 1) ^ t;
    x = ((x >> 1) & t) | ((x << 1) & ~t);

    return x;
}

static inline uint32_t
popcnt64(uint64_t x)
{
    x = x - ((x >> 1) & UINT64_C(0x5555555555555555));
    x = (x & UINT64_C(0x3333333333333333)) +
        ((x >> 2) & UINT64_C(0x3333333333333333));
    x = (x + (x >> 4)) & UINT64_C(0x0F0F0F0F0F0F0F0F);
    x = (x * UINT64_C(0x0101010101010101)) >> 56;

    return (uint32_t)x & UINT32_C(127);
}

// ----------------------------------------------------------------------------
// Dense Array Functions
// ----------------------------------------------------------------------------

static void
set_bit(uint64_t* array, size_t index, bool value)
{
    array[index / 64] &= ~(UINT64_C(1) << index % 64);
    array[index / 64] |= ((uint64_t)value << index % 64);
}

static bool
get_bit(const uint64_t* array, int index)
{
    return (array[index / 64] >> index % 64) & UINT64_C(1);
}

static void
shift_up_one_bit(uint64_t* x)
{
    for (size_t i = MDPC_R_UINT64 - 1; i > 0; i--) {
        x[i] = (x[i] << 1) | (x[i - 1] >> 63);
    }
    x[0] <<= 1;
    x[MDPC_R_UINT64 - 1] &= MDPC_R64MASK;
}

static void
rotate_up_one_bit(uint64_t* x)
{
    bool carry_bit = get_bit(x, MDPC_R - 1);
    shift_up_one_bit(x);
    set_bit(x, 0, carry_bit);
}

static inline void
xor8(uint8_t* a, const uint8_t* b, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        a[i] ^= b[i];
    }
}

static inline void
xor64(uint64_t* a, const uint64_t* b, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        a[i] ^= b[i];
    }
}

static void
flip_bit(uint64_t* x, size_t index)
{
    x[index / 64] ^= UINT64_C(1) << index % 64;
}

static bool
is_zero(const uint64_t* x)
{
    uint64_t ret = 0;
    for (size_t i = 0; i < MDPC_R_UINT64; ++i) {
        ret |= x[i];
    }

    return ret == 0;
}

static void
transpose(uint64_t* x)
{
    for (size_t i = 0; i < MDPC_R / 2; ++i) {
        const bool left_bit = get_bit(x, i);
        const bool right_bit = get_bit(x, MDPC_R - (i + 1));

        set_bit(x, i, right_bit);
        set_bit(x, MDPC_R - (i + 1), left_bit);
    }

    rotate_up_one_bit(x);
}

static void
get_subarray(uint8_t* dest, const uint8_t* src, size_t start)
{
    const size_t shift = start % 8;
    const size_t unshift = 8 - shift;

    const size_t skip = start / 8;

    for (size_t i = 0; i < MDPC_R_BYTES - 1; ++i) {
        dest[i] = (src[skip + i] >> shift) | (src[skip + i + 1] << unshift);
    }

    dest[MDPC_R_BYTES - 1] = src[skip + MDPC_R_BYTES - 1] >> shift |
                             src[skip + MDPC_R_BYTES] << unshift;
    dest[MDPC_R_BYTES - 1] &= MDPC_RMASK;
}

static size_t
get_weight(uint64_t* x, size_t n)
{
    size_t weight = 0;
    for (size_t i = 0; i < n; ++i) {
        weight += popcnt64(x[i]);
    }

    return weight;
}

static void
shift_down_by(uint64_t* x, unsigned int n)
{
    for (size_t i = 0; i < MDPC_R_UINT64 - 1; i++) {
        x[i] = (x[i] >> n) | (x[i + 1] << (64 - n));
    }
    x[MDPC_R_UINT64 - 1] >>= n;
}

static void
rotate_down_by_helper(uint64_t* x, unsigned int n)
{
    assert(n <= 20);
    bool carry_bits[20];
    for (unsigned int i = 0; i < n; i++) {
        carry_bits[i] = get_bit(x, i);
    }
    shift_down_by(x, n);
    for (unsigned int i = 0; i < n; i++) {
        set_bit(x, MDPC_R - n + i, carry_bits[i]);
    }
}

static void
rotate_down_by(uint64_t* x, unsigned int n)
{
    while (n > 0) {
        if (n > 20) {
            rotate_down_by_helper(x, 20);
            n -= 20;
        } else {
            rotate_down_by_helper(x, n);
            n = 0;
        }
    }
}

// ----------------------------------------------------------------------------
// Sparse Array Functions
// ----------------------------------------------------------------------------

static void
dense_to_sparse(uint64_t* dense, uint16_t* sparse)
{
    for (int i = 0, j = 0; i < MDPC_R_UINT64; i++) {
        uint64_t element = bitrev64(dense[i]);

        while (element != 0) {
            const uint32_t pos = clz64(element);
            element ^= UINT64_C(1) << (63 - pos);
            sparse[j++] = (uint16_t)((i * 64) + pos);
        }
    }
}

static void
sparse_rotate_up(uint16_t* array)
{
    for (int i = 0; i < MDPC_WI; i++) {
        const uint16_t temp = array[i] + 1;
        array[i] = temp - (temp >= MDPC_R) * MDPC_R;
    }
}

static int
conj_weight(const uint64_t* dense, const uint16_t* sparse)
{
    int weight = 0;
    for (int i = 0; i < MDPC_WI; i++) {
        weight += get_bit(dense, sparse[i]);
    }

    return weight;
}

static void
sparse_matrix_vector_multiply(uint16_t* sparse,
                              uint64_t* dense,
                              uint64_t* product)
{
    memset(product, 0, MDPC_R_BYTES);

    for (int y = 0; y < MDPC_R; y++) {
        bool dot_parity = conj_weight(dense, sparse) % 2 == 1;
        set_bit(product, y, dot_parity);

        sparse_rotate_up(sparse);
    }
}

static void
sparse_matrix_transpose(uint16_t* array)
{
    for (int i = 0; i < MDPC_WI; i++) {
        array[i] = (uint16_t)((MDPC_R - 1) - array[i]);
    }

    sparse_rotate_up(array);
}

// ----------------------------------------------------------------------------
// Keygen Functions
// ----------------------------------------------------------------------------

static uint16_t
uniform_int_prf(cSHAKE_Instance* cs_state, uint16_t bound)
{
    if (bound == 0) {
        return 0;
    }

    const uint16_t threshold = (UINT16_MAX / bound) * bound;
    uint16_t rand_sample = 0;

    while (true) {
        cSHAKE256_Squeeze(
          cs_state, (unsigned char*)&rand_sample, 8 * sizeof(rand_sample));

        if (rand_sample < threshold) {
            return rand_sample % bound;
        }
    }
}

static uint16_t
uniform_int(uint16_t bound)
{
    if (bound == 0) {
        return 0;
    }

    const uint16_t threshold = (UINT16_MAX / bound) * bound;
    uint16_t rand_sample = 0;

    while (true) {
        randombytes((unsigned char*)&rand_sample, sizeof(rand_sample));
        if (rand_sample < threshold) {
            return rand_sample % bound;
        }
    }
}

static void
uniform_weight_array(uint64_t* array, int weight, size_t size_bits)
{
    // Durstenfeld inside-out shuffle.
    for (int i = 0; i < size_bits; i++) {
        const uint16_t j = uniform_int(i);
        set_bit(array, i, get_bit(array, j));
        set_bit(array, j, i < weight);
    }
}

static void
gen_ev(uint64_t* ev, uint8_t* seed)
{
    // e <- v(s)
    cSHAKE_Instance cs_state;
    cSHAKE256_Initialize(
      &cs_state, 0, (const unsigned char*)"", 0, (const unsigned char*)"e", 1);
    cSHAKE256_Update(&cs_state, seed, 8 * MDPC_R_BYTES);
    cSHAKE256_Final(&cs_state, NULL);
    // Durstenfeld inside-out shuffle.
    for (int i = 0; i < MDPC_N; i++) {
        const uint16_t j = uniform_int_prf(&cs_state, i);
        set_bit(ev, i, get_bit(ev, j));
        set_bit(ev, j, i < MDPC_T);
    }
}

static void
shift_3_down_by_helper(uint64_t* a1, uint64_t* a2, uint64_t* a3, int n)
{
    assert(n < 64);

    const int bit_shift = n % 64;
    if (bit_shift != 0) {
        const int shift_in = 64 - bit_shift;
        for (int i = 0; i < MDPC_R_UINT64 - 1; i++) {
            a1[i] = (a1[i] >> bit_shift) | (a1[i + 1] << shift_in);
            a2[i] = (a2[i] >> bit_shift) | (a2[i + 1] << shift_in);
            a3[i] = (a3[i] >> bit_shift) | (a3[i + 1] << shift_in);
        }
        a1[MDPC_R_UINT64 - 1] >>= bit_shift;
        a2[MDPC_R_UINT64 - 1] >>= bit_shift;
        a3[MDPC_R_UINT64 - 1] >>= bit_shift;
    }
}

static void
shift_3_down_by(uint64_t* a1, uint64_t* a2, uint64_t* a3, int n)
{
    while (n > 0) {
        if (n > 63) {
            shift_3_down_by_helper(a1, a2, a3, 63);
            n -= 63;
        } else {
            shift_3_down_by_helper(a1, a2, a3, n);
            n = 0;
        }
    }
}

static void
zero_strip(uint64_t* operand,
           uint64_t* x,
           uint64_t* y,
           uint64_t* tmp1,
           uint64_t* tmp2)
{
    while (get_bit(operand, 0) == 0) {
        int count = 0;
        while (get_bit(tmp1, count) == 0 && get_bit(tmp2, count) == 0 &&
               get_bit(operand, count) == 0) {
            count++;
        }
        shift_3_down_by(tmp1, tmp2, operand, count);

        if (get_bit(operand, 0) == 0) {
            xor64(tmp1, y, MDPC_R_UINT64);
            xor64(tmp2, x, MDPC_R_UINT64);

            shift_3_down_by(tmp1, tmp2, operand, 1);
        }
    }
}

static int
compare(const uint64_t* a, const uint64_t* b)
{
    for (int i = MDPC_R_UINT64 - 1; i >= 0; --i) {
        if (a[i] == b[i]) {
            continue;
        }
        return -1 * (a[i] < b[i]);
    }
    return 0;
}

// Polynomial inversion using algorithm 14.61 "binary extended gcd algorithm"
// from "Handbook of Applied Cryptography" (Menezes, Oorschot, Vanstone).
static void
invert(uint64_t* poly_inverse, const uint64_t* poly)
{
    uint64_t x[MDPC_R_UINT64] = { 0 };
    uint64_t u[MDPC_R_UINT64] = { 0 };
    uint64_t y[MDPC_R_UINT64] = { 0 };
    uint64_t v[MDPC_R_UINT64] = { 0 };
    uint64_t tmp_A[MDPC_R_UINT64] = { 0 };
    uint64_t tmp_B[MDPC_R_UINT64] = { 0 };
    uint64_t tmp_C[MDPC_R_UINT64] = { 0 };
    uint64_t tmp_D[MDPC_R_UINT64] = { 0 };

    memcpy(x, poly, MDPC_R_BYTES);
    memcpy(u, poly, MDPC_R_BYTES);

    // Modulus: x^n + 1
    set_bit(y, 0, 1);
    set_bit(y, MDPC_R, 1);
    set_bit(v, 0, 1);
    set_bit(v, MDPC_R, 1);

    set_bit(tmp_A, 0, 1);
    set_bit(tmp_D, 0, 1);

    while (!is_zero(u)) {
        zero_strip(u, x, y, tmp_A, tmp_B);
        zero_strip(v, x, y, tmp_C, tmp_D);

        if (compare(u, v) >= 0) {
            xor64(u, v, MDPC_R_UINT64);
            xor64(tmp_A, tmp_C, MDPC_R_UINT64);
            xor64(tmp_B, tmp_D, MDPC_R_UINT64);
        } else {
            xor64(v, u, MDPC_R_UINT64);
            xor64(tmp_C, tmp_A, MDPC_R_UINT64);
            xor64(tmp_D, tmp_B, MDPC_R_UINT64);
        }
    }

    // MDPC_Test that v == 1.
    flip_bit(v, 0);
    assert(is_zero(v));

    memcpy(poly_inverse, tmp_C, MDPC_R_BYTES);
}

// ----------------------------------------------------------------------------
// Decryption Functions
// ----------------------------------------------------------------------------

static void
compute_syndrome(uint64_t* synd, const uint8_t* c, uint16_t h[MDPC_N0][MDPC_WI])
{
    for (uint32_t i = 0; i < MDPC_N0; i++) {
        uint64_t c_i[MDPC_R_UINT64] = { 0 };
        get_subarray((uint8_t*)c_i, c, i * MDPC_R);

        uint64_t prod[MDPC_R_BYTES] = { 0 };
        sparse_matrix_vector_multiply(h[i], c_i, prod);

        xor64(synd, prod, MDPC_R_BYTES);
    }
}

static void
perform_bit_flipping(uint64_t* ev,
                     uint64_t* synd,
                     uint16_t sh[MDPC_N0][MDPC_WI],
                     size_t max_correlation)
{
    for (size_t i = 0; i < MDPC_N0; i++) {
        for (size_t j = 0; j < MDPC_R; j++) {
            if (conj_weight(synd, sh[i]) >= max_correlation) {
                flip_bit(ev, i * MDPC_R + j);
                for (size_t k = 0; k < MDPC_WI; k++) {
                    flip_bit(synd, sh[i][k]);
                }
            }
            sparse_rotate_up(sh[i]);
        }
    }
}

static void
decode(uint8_t* m, uint64_t* ev, const uint8_t* c, uint16_t h[MDPC_N0][MDPC_WI])
{
    uint64_t synd[MDPC_R_UINT64] = { 0 };
    compute_syndrome(synd, c, h);

    for (size_t i = 0; i < MDPC_N0; i++) {
        sparse_matrix_transpose(h[i]);
    }

    for (size_t i = 0; i < sizeof(thresholds) / sizeof(*thresholds); i++) {
        perform_bit_flipping(ev, synd, h, thresholds[i]);
        if (is_zero(synd)) {
            break;
        }
    }

    if (is_zero(synd)) {
        get_subarray(m, c, 0);
        xor8(m, (uint8_t*)ev, MDPC_R_BYTES);
        m[MDPC_R_BYTES - 1] &= MDPC_RMASK;
    }
}

static unsigned int
dec(uint8_t* m, uint64_t* ev, const uint8_t* c, const uint8_t* sk)
{
    uint16_t h[MDPC_N0][MDPC_WI];
    memcpy(h, sk, sizeof(h));

    decode(m, ev, c, h);
    if (get_weight(ev, 2 * MDPC_R_UINT64) != MDPC_T) {
        // Decoding error occurred.
        return 1;
    }
    return 0;
}

static void
concat_bits(uint8_t* dest, const uint8_t* head, const uint64_t* tail64)
{
    uint8_t* tail = (uint8_t*)tail64;

    memcpy(dest, head, MDPC_R_BYTES);

    const size_t shift = MDPC_R % 8;
    const size_t unshift = 8 - shift;

    dest[MDPC_R_BYTES - 1] &= MDPC_RMASK;

    for (size_t i = 0; i < MDPC_R_BYTES - 1; ++i) {
        dest[MDPC_R_BYTES + i - 1] |= (tail[i] << shift) & ~MDPC_RMASK;
        dest[MDPC_R_BYTES + i] = (tail[i] >> unshift) & MDPC_RMASK;
    }

    dest[2 * MDPC_R_BYTES - 2] |=
      (tail[MDPC_R_BYTES - 1] << shift) & ~MDPC_RMASK;
    dest[2 * MDPC_R_BYTES - 1] =
      (tail[MDPC_R_BYTES - 1] >> unshift) & MDPC_RMASK;
}

// ----------------------------------------------------------------------------
// Encryption Functions
// ----------------------------------------------------------------------------

static void
compute_ciphertext(uint64_t* c, const uint8_t* m, uint64_t* g)
{
    uint64_t m_temp[MDPC_R_UINT64] = { 0 };
    memcpy(m_temp, m, MDPC_R_BYTES);

    transpose(g);

    unsigned int count = 0;
    for (int i = 0; i < MDPC_R; i++) {
        if (get_bit(g, i)) {
            rotate_down_by(m_temp, count);
            count = 0;

            xor64(c, m_temp, MDPC_R_UINT64);
        }
        count++;
    }
}

static void
encrypt_with_err(uint8_t* c, uint8_t* m, const uint64_t* ev, const uint8_t* pk)
{
    uint64_t mG[MDPC_R_UINT64] = { 0 };
    uint64_t g[MDPC_R_UINT64] = { 0 };

    memcpy(g, pk, MDPC_R_BYTES);
    compute_ciphertext(mG, m, g);
    concat_bits(c, m, mG);
    xor8(c, (uint8_t*)ev, 2 * MDPC_R_BYTES);
}

// ----------------------------------------------------------------------------
// API Functions
// ----------------------------------------------------------------------------

int
crypto_kem_keypair(unsigned char* pk, unsigned char* sk)
{
    uint64_t pk_temp[MDPC_R_UINT64] = { 0 };
    uint16_t sk_temp[MDPC_W] = { 0 };
    uint64_t sk_dense[2 * MDPC_R_UINT64] = { 0 };

    for (int i = 0; i < MDPC_N0; i++) {
        uniform_weight_array(
          sk_dense + i * MDPC_R_UINT64, MDPC_W / MDPC_N0, MDPC_R);
    }

    for (size_t i = 0; i < MDPC_N0; i++) {
        dense_to_sparse(sk_dense + i * MDPC_R_UINT64, &sk_temp[i * MDPC_WI]);
    }

    uint64_t inverse[MDPC_R_UINT64] = { 0 };

    invert(inverse, sk_dense + MDPC_R_UINT64);
    transpose(inverse);

    for (int i = 0; i < MDPC_N0 - 1; i++) {
        sparse_matrix_vector_multiply(
          &sk_temp[i * MDPC_WI], inverse, pk_temp + i * MDPC_R_BYTES);
    }

    memcpy(sk, sk_temp, CRYPTO_SECRETKEYBYTES);
    memcpy(pk, pk_temp, CRYPTO_PUBLICKEYBYTES);

    return 0;
}

int
crypto_kem_enc(unsigned char* cipher,
               unsigned char* key,
               const unsigned char* pk)
{
    uint64_t e[MDPC_N0 * MDPC_R_UINT64] = { 0 };
    uint8_t s[MDPC_R_BYTES] = { 0 };
    uint8_t x[MDPC_R_BYTES] = { 0 };
    uint8_t y[MDPC_R_BYTES] = { 0 };
    uint8_t c1[MDPC_N0 * MDPC_R_BYTES] = { 0 };
    uint8_t c[C2_SIZE + SHARED_KEY_SIZE] = { 0 };

    randombytes(s, sizeof(s));
    s[MDPC_R_BYTES - 1] &= MDPC_RMASK;

    // c <- kdf(s)
    cSHAKE256(s,
              MDPC_R,
              c,
              8 * sizeof(c),
              (const uint8_t*)"",
              0,
              (const uint8_t*)"c",
              1);

    // e <- v(s)
    gen_ev(e, s);

#ifdef KAT
    printf("Intermediate Error Vector = ");
    print_bytes((uint8_t*)e, MDPC_N0 * MDPC_R_BYTES);
    printf("\n");
#endif

    // y <- KDF(e)
    cSHAKE256((uint8_t*)e,
              MDPC_N0 * MDPC_R,
              y,
              8 * sizeof(y),
              (const uint8_t*)"",
              0,
              (const uint8_t*)"y",
              1);

    // x <- s + y
    for (size_t i = 0; i < sizeof(s); i++) {
        x[i] = s[i] ^ y[i];
    }
    x[MDPC_R_BYTES - 1] &= MDPC_RMASK;

    // C1 <- ENCRYPT(x,e,pk)
    encrypt_with_err(c1, x, e, pk);

    // key <- c[0:n]
    memcpy(key, c + C2_SIZE, SHARED_KEY_SIZE);

    // cipher <- (c1,c2)
    memcpy(cipher, c1, sizeof(c1));
    memcpy(cipher + sizeof(c1), c, C2_SIZE);

    return 0;
}

// Will return 1 in the case of a decryption failure. 0 otherwise.
int
crypto_kem_dec(unsigned char* k,
               const unsigned char* ct,
               const unsigned char* sk)
{
    uint64_t e[2 * MDPC_R_UINT64] = { 0 };
    uint64_t e_p[2 * MDPC_R_UINT64] = { 0 };
    uint8_t s[MDPC_R_BYTES] = { 0 };
    uint8_t x[MDPC_R_BYTES] = { 0 };
    uint8_t y[MDPC_R_BYTES] = { 0 };
    uint8_t c1[2 * MDPC_R_BYTES] = { 0 };
    uint8_t c_p[C2_SIZE + SHARED_KEY_SIZE] = { 0 };

    memcpy(c1, ct, sizeof(c1));

    // (x,e) <- DECRYPT(C1,sk)
    unsigned int decrypt_error = dec(x, e, c1, sk);

    // y <- KDF(e)
    cSHAKE256((uint8_t*)e,
              MDPC_N0 * MDPC_R,
              y,
              8 * sizeof(y),
              (const uint8_t*)"",
              0,
              (const uint8_t*)"y",
              1);

    // s <- x + y
    for (size_t i = 0; i < sizeof(s); i++) {
        s[i] = x[i] ^ y[i];
    }
    s[MDPC_R_BYTES - 1] &= MDPC_RMASK;

    // e_p <- v(s)
    gen_ev(e_p, s);

    // c <- kdf(s)
    cSHAKE256(s,
              MDPC_R,
              c_p,
              8 * sizeof(c_p),
              (const uint8_t*)"",
              0,
              (const uint8_t*)"c",
              1);

    uint8_t vectors_diff = 0;
    for (size_t i = 0; i < 2 * MDPC_R_UINT64; i++) {
        vectors_diff |= e[i] ^ e_p[i];
    }

    uint8_t c2_diff = 0;
    for (size_t i = 0; i < C2_SIZE; i++) {
        c2_diff |= (ct + sizeof(c1))[i] ^ c_p[i];
    }

    memcpy(k, c_p + C2_SIZE, SHARED_KEY_SIZE);

    unsigned int failure = vectors_diff | c2_diff | decrypt_error;
    if (failure) {
        return 1;
    } else {
        return 0;
    }
}
